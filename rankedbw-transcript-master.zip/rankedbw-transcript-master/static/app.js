const fileInput = document.getElementById('file-input');
const transcriptView = document.getElementById('transcript-view');
const welcomeState = document.getElementById('welcome-state');
const closeButton = document.getElementById('close-transcript');
const ticketMeta = document.getElementById('ticket-meta');
const messagesContainer = document.getElementById('messages');
const messageCount = document.getElementById('message-count');

fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        try {
            const transcript = JSON.parse(event.target.result);
            displayTranscript(transcript);
        } catch (error) {
            alert('Error: Invalid JSON file');
            console.error(error);
        }
    };
    reader.readAsText(file);
});

closeButton.addEventListener('click', (e) => {
    e.preventDefault();
    transcriptView.classList.add('hidden');
    welcomeState.classList.remove('hidden');
    fileInput.value = '';
});

function displayTranscript(transcript) {
    welcomeState.classList.add('hidden');
    transcriptView.classList.remove('hidden');

    ticketMeta.innerHTML = `
        <div class="meta-row">
            <div class="meta-item">
                <span class="meta-label">Ticket ID</span>
                <span class="meta-value">${transcript.ticket_id || 'N/A'}</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Channel</span>
                <span class="meta-value">${transcript.channel_name || 'N/A'}</span>
            </div>
        </div>
        <div class="meta-row">
            <div class="meta-item">
                <span class="meta-label">Created by</span>
                <span class="meta-value">${transcript.creator_tag || 'N/A'}</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Closed by</span>
                <span class="meta-value">${transcript.closed_by_tag || 'N/A'}</span>
            </div>
        </div>
        <div class="meta-row">
            <div class="meta-item">
                <span class="meta-label">Closed at</span>
                <span class="meta-value">${formatTimestamp(transcript.closed_at)}</span>
            </div>
            <div class="meta-item">
                <span class="meta-label">Reason</span>
                <span class="meta-value close-reason-badge ${transcript.close_reason === 'Resolved' ? 'resolved' : 'other'}">
                    ${transcript.close_reason || 'N/A'}
                </span>
            </div>
        </div>
    `;

    messageCount.textContent = `Messages (${transcript.message_count || transcript.messages?.length || 0})`;
    
    messagesContainer.innerHTML = transcript.messages.map(msg => {
        const embedHTML = msg.embeds_count > 0 
            ? `<div class="embed-indicator">📎 ${msg.embeds_count} embed${msg.embeds_count > 1 ? 's' : ''}</div>`
            : '';
        
        const contentHTML = msg.content 
            ? msg.content 
            : '<span class="empty-message">No text content</span>';

        return `
            <div class="message">
                <div class="message-header">
                    <span class="author">${msg.author}</span>
                    <span class="timestamp">${formatTimestamp(msg.timestamp)}</span>
                </div>
                <div class="message-content">${contentHTML}</div>
                ${embedHTML}
            </div>
        `;
    }).join('');
}

function formatTimestamp(timestamp) {
    if (!timestamp) return 'N/A';
    
    const date = new Date(timestamp);
    const options = { 
        year: 'numeric', 
        month: 'short', 
        day: '2-digit',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    };
    
    return date.toLocaleString('en-US', options);
}
