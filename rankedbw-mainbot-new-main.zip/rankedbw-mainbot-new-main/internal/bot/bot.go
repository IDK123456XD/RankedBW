package bot

import (
	"context"
	"log"
	"os"
	"os/signal"
	"strings"
	"sync"
	"syscall"
	"time"

	"rbw-bot/internal/commands"
	"rbw-bot/internal/config"
	"rbw-bot/internal/discordutil"
	"rbw-bot/internal/party"
	"rbw-bot/internal/queue"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Bot struct {
	Cfg      config.Config
	Sess     *discordgo.Session
	Cmds     *commands.Registry
	PartySvc *party.Service
	QueueSvc *queue.Service
	regMu    sync.Mutex
	regGuild map[string]struct{}

	globalCleanup sync.Once
}

func New(cfg config.Config) (*Bot, error) {
	s, err := discordgo.New("Bot " + cfg.Token)
	if err != nil {
		return nil, err
	}

	// Intents for slash commands, member management, voice states, and message content
	s.Identify.Intents = discordgo.IntentsGuilds |
		discordgo.IntentsGuildMembers |
		discordgo.IntentsGuildVoiceStates |
		discordgo.IntentsGuildMessages |
		discordgo.IntentsDirectMessages |
		discordgo.IntentsMessageContent

	partySvc := party.NewService()

	discordutil.InitDefaultDeleter(s, time.Second)

	b := &Bot{
		Cfg:      cfg,
		Sess:     s,
		PartySvc: partySvc,
		regGuild: make(map[string]struct{}),
	}

	queueSvc := queue.NewService(cfg.QueueLogChannelID, cfg.TeamCategoryID)
	if queueSvc != nil {
		if err := queueSvc.ReloadConfigs(context.Background()); err != nil {
			log.Printf("queue: failed to load configs: %v", err)
		}
	}

	b.Cmds = commands.NewRegistry(partySvc, queueSvc)
	b.QueueSvc = queueSvc

	// Handlers
	s.AddHandler(b.onReady)
	s.AddHandler(b.onInteractionCreate)
	s.AddHandler(b.onVoiceStateUpdate)
	s.AddHandler(b.onGuildCreate)

	return b, nil
}

func (b *Bot) onReady(_ *discordgo.Session, r *discordgo.Ready) {
	log.Printf("�o. Logged in as %s#%s", r.User.Username, r.User.Discriminator)
	if b.Cfg.GuildID == "" {
		log.Printf("onReady: no guild configured; skipping command registration")
		return
	}
	if err := b.registerGuildCommands(b.Cfg.GuildID); err != nil {
		log.Printf("command registration failed for guild %s: %v", b.Cfg.GuildID, err)
	}
}

func (b *Bot) Start(ctx context.Context) error {
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	if err := b.Sess.Open(); err != nil {
		return err
	}
	if b.Cmds != nil {
		b.Cmds.SetSession(b.Sess)
	}
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		if err := storage.ApplyInfocardDefaults(ctx); err != nil {
			log.Printf("infocards: default sync failed: %v", err)
		}
	}()

	if b.Sess != nil {
		go b.enforceGuildMembership(ctx)
	}

	if b.PartySvc != nil && b.Sess != nil {
		b.PartySvc.StartMaintenance(b.Sess, b.Cfg.GuildID)
	}

	if b.QueueSvc != nil && b.Sess != nil {
		b.QueueSvc.StartMaintenance(b.Sess, b.Cfg.GuildID)
	}

	b.cleanupGlobalCommands()

	var regErr error
	if b.Cfg.GuildID != "" {
		if err := b.registerGuildCommands(b.Cfg.GuildID); err != nil && regErr == nil {
			regErr = err
		}
	}
	if regErr != nil {
		return regErr
	}

	go b.runPunishmentWatcher(ctx)

	// Graceful shutdown
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	select {
	case <-ctx.Done():
	case <-stop:
	}
	cancel()

	b.cleanupRegisteredCommands()
	return b.Sess.Close()
}

func (b *Bot) onInteractionCreate(s *discordgo.Session, i *discordgo.InteractionCreate) {
	defer func() {
		if r := recover(); r != nil {
			log.Printf("panic in interaction: %v", r)
			_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Content: "Something went wrong handling that command.",
					Flags:   64,
				},
			})
		}
	}()
	switch i.Type {
	case discordgo.InteractionApplicationCommand:
		b.Cmds.Dispatch(s, i)
	case discordgo.InteractionApplicationCommandAutocomplete:
		b.Cmds.DispatchAutocomplete(s, i)
	case discordgo.InteractionMessageComponent:
		b.Cmds.DispatchComponent(s, i)
	case discordgo.InteractionModalSubmit:
		b.Cmds.DispatchModal(s, i)
	}
}

func (b *Bot) onVoiceStateUpdate(s *discordgo.Session, vs *discordgo.VoiceStateUpdate) {
	if b.QueueSvc != nil {
		go b.QueueSvc.HandleVoiceStateUpdate(s, vs)
	}
	if vs.UserID == "" || vs.ChannelID == "" {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	party, err := storage.GetPartyByLeader(ctx, vs.UserID)
	if err != nil || party == nil || !party.AutoWarp {
		return
	}
	targets, err := b.PartySvc.WarpTargets(ctx, vs.UserID)
	if err != nil || len(targets) == 0 {
		return
	}
	for _, memberID := range targets {
		channelID := vs.ChannelID
		_ = s.GuildMemberMove(vs.GuildID, memberID, &channelID)
	}

}

func (b *Bot) onGuildCreate(_ *discordgo.Session, g *discordgo.GuildCreate) {
	if g == nil || g.Guild == nil {
		return
	}
	if b.Cfg.GuildID == "" {
		return
	}
	if g.ID != b.Cfg.GuildID {
		log.Printf("onGuildCreate: skipping guild %s (configured guild %s)", g.ID, b.Cfg.GuildID)
		return
	}
	if err := b.registerGuildCommands(g.ID); err != nil {
		log.Printf("command registration failed for guild %s: %v", g.ID, err)
	}
}

func (b *Bot) registerGuildCommands(guildID string) error {
	if guildID == "" {
		log.Printf("registerGuildCommands: skipping empty guild ID")
		return nil
	}
	if b.Cfg.GuildID != "" && guildID != b.Cfg.GuildID {
		log.Printf("registerGuildCommands: skipping guild %s; configured guild is %s", guildID, b.Cfg.GuildID)
		return nil
	}

	b.regMu.Lock()
	if _, ok := b.regGuild[guildID]; ok {
		b.regMu.Unlock()
		log.Printf("registerGuildCommands: guild %s already registered, skipping", guildID)
		return nil
	}
	b.regMu.Unlock()

	log.Printf("registerGuildCommands: attempting guild %s", guildID)

	if err := b.Cmds.RegisterGuild(b.Sess, b.Cfg.AppID, guildID); err != nil {
		log.Printf("command registration failed for guild %s: %v", guildID, err)
		return err
	}

	b.regMu.Lock()
	b.regGuild[guildID] = struct{}{}
	b.regMu.Unlock()
	log.Printf("registered commands for guild %s", guildID)
	return nil
}

func (b *Bot) cleanupRegisteredCommands() {
	b.regMu.Lock()
	ids := make([]string, 0, len(b.regGuild))
	for id := range b.regGuild {
		ids = append(ids, id)
	}
	b.regMu.Unlock()

	for _, id := range ids {
		if err := b.Cmds.CleanupGuild(b.Sess, b.Cfg.AppID, id); err != nil {
			log.Printf("command cleanup failed for guild %s: %v", id, err)
		}
	}
}

func (b *Bot) cleanupGlobalCommands() {
	if b == nil {
		return
	}
	b.globalCleanup.Do(func() {
		appID := strings.TrimSpace(b.Cfg.AppID)
		if b.Sess == nil || appID == "" {
			return
		}

		log.Printf("cleanupGlobalCommands: removing any global commands for application %s", appID)
		if _, err := b.Sess.ApplicationCommandBulkOverwrite(appID, "", []*discordgo.ApplicationCommand{}); err != nil {
			log.Printf("cleanupGlobalCommands: failed to clear global commands: %v", err)
		}
	})
}

// enforceGuildMembership logs current guilds and leaves any guild not whitelisted.
// Runs immediately and every 5 minutes.
func (b *Bot) enforceGuildMembership(ctx context.Context) {
	allowed := strings.TrimSpace(b.Cfg.GuildID)
	if allowed == "" || b.Sess == nil {
		return
	}
	runOnce := func() {
		guilds, err := b.fetchUserGuilds()
		if err != nil {
			log.Printf("guild guard: failed to list guilds: %v", err)
			return
		}
		for _, g := range guilds {
			if g == nil {
				continue
			}
			log.Printf("guild guard: in guild %s (%s)", g.Name, g.ID)
			if g.ID != allowed {
				log.Printf("guild guard: leaving unauthorized guild %s (%s)", g.Name, g.ID)
				if err := b.Sess.GuildLeave(g.ID); err != nil {
					log.Printf("guild guard: failed to leave %s: %v", g.ID, err)
				}
			}
		}
	}
	runOnce()
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			runOnce()
		}
	}
}

// fetchUserGuilds returns all guilds the bot is currently in.
func (b *Bot) fetchUserGuilds() ([]*discordgo.UserGuild, error) {
	var all []*discordgo.UserGuild
	after := ""
	for {
		guilds, err := b.Sess.UserGuilds(200, "", after)
		if err != nil {
			return nil, err
		}
		if len(guilds) == 0 {
			break
		}
		all = append(all, guilds...)
		if len(guilds) < 200 {
			break
		}
		after = guilds[len(guilds)-1].ID
	}
	return all, nil
}
