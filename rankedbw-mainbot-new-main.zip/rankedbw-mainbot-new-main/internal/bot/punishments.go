package bot

import (
	"context"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"rbw-bot/internal/assets"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

func (b *Bot) guildIDs() []string {
	if b.Cfg.GuildID != "" {
		return []string{b.Cfg.GuildID}
	}
	return nil
}

func (b *Bot) runPunishmentWatcher(ctx context.Context) {
	ticker := time.NewTicker(60 * time.Second)
	defer ticker.Stop()

	log.Println("punishment watcher: started")
	b.handleActiveRankedBans(ctx)
	b.handleExpiredMutes(ctx)
	b.handleExpiredRankedBans(ctx)

	for {
		select {
		case <-ctx.Done():
			log.Println("punishment watcher: context canceled, exiting")
			return
		case <-ticker.C:
			log.Println("punishment watcher: tick")
			b.handleActiveRankedBans(ctx)
			b.handleExpiredMutes(ctx)
			b.handleExpiredRankedBans(ctx)
		}
	}
}

func (b *Bot) handleExpiredMutes(ctx context.Context) {
	mutedRoleID := settingOrEnv("MUTED_ROLE_ID")
	if mutedRoleID == "" {
		return
	}

	queryCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	expired, err := storage.FetchExpiredMutePunishments(queryCtx)
	if err != nil {
		log.Printf("punishment watcher: fetch expired mutes: %v", err)
		return
	}
	if len(expired) == 0 {
		return
	}

	logChannelID, _ := storage.GetLogChannelID(queryCtx)
	punishmentsChannelID, _ := storage.GetPunishmentsChannelID(queryCtx)
	supportChannelID, _ := storage.GetSupportChannelID(queryCtx)

	log.Printf("punishment watcher: processing %d mute expirations", len(expired))

	for _, record := range expired {
		if err := b.processMuteExpiry(ctx, record, mutedRoleID, punishmentsChannelID, supportChannelID, logChannelID); err != nil {
			log.Printf("punishment watcher: process mute %s: %v", record.ID, err)
		}
	}
}

func (b *Bot) processMuteExpiry(ctx context.Context, record storage.PunishmentRecord, mutedRoleID, punishChannelID, supportChannelID, logChannelID string) error {
	for _, guildID := range b.guildIDs() {
		log.Printf("punishment watcher: checking mute expiry for user %s in guild %s", record.UserID, guildID)
		member, err := b.Sess.GuildMember(guildID, record.UserID)
		if err != nil {
			log.Printf("punishment watcher: failed to fetch member %s in guild %s: %v", record.UserID, guildID, err)
			continue
		}
		if hasRole(member, mutedRoleID) {
			if err := b.Sess.GuildMemberRoleRemove(guildID, record.UserID, mutedRoleID); err != nil {
				log.Printf("punishment watcher: failed to remove mute role for %s in guild %s: %v", record.UserID, guildID, err)
			}
		}
	}

	log.Printf("punishment watcher: notifying mute expiry for %s", record.UserID)
	b.notifyMuteExpired(punishChannelID, supportChannelID, record.UserID)
	b.logMuteRemoval(logChannelID, record.UserID, record.StaffID, record.Reason)

	updateCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	if err := storage.MarkPunishmentExpired(updateCtx, record.ID); err != nil {
		return err
	}
	log.Printf("punishment watcher: marked mute punishment %s expired", record.ID)
	return nil
}

func hasRole(member *discordgo.Member, roleID string) bool {
	if member == nil {
		return false
	}
	for _, r := range member.Roles {
		if r == roleID {
			return true
		}
	}
	return false
}

func settingOrEnv(key string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if val, err := storage.GetSettingValue(ctx, key); err == nil && strings.TrimSpace(val) != "" {
		return strings.TrimSpace(val)
	}
	return strings.TrimSpace(os.Getenv(key))
}

func (b *Bot) notifyMuteExpired(channelID, supportChannelID, userID string) {
	if channelID == "" {
		return
	}
	supportMention := "support"
	if strings.TrimSpace(supportChannelID) != "" {
		supportMention = fmt.Sprintf("<#%s>", supportChannelID)
	}

	embed := &discordgo.MessageEmbed{
		Title:       "Mute Expired",
		Description: fmt.Sprintf("**User:** <@%s>\n**Reason:** Expired.\n\nIn the future if you face another punishment, it will likely increase due to your punishment history.\n\nAppeal in %s if needed.", userID, supportMention),
		Color:       0x40ff56,
		Timestamp: time.Now().Format(time.RFC3339),
	}

	if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
		embed.Thumbnail = thumb
		_, err := b.Sess.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
			Content: fmt.Sprintf("<@%s>", userID),
			Embeds:  []*discordgo.MessageEmbed{embed},
			Files:   files,
		})
		cleanup()
		if err != nil {
			log.Printf("punishment watcher: failed to notify channel: %v", err)
		}
		return
	}

	if _, err := b.Sess.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
		Content: fmt.Sprintf("<@%s>", userID),
		Embeds:  []*discordgo.MessageEmbed{embed},
	}); err != nil {
		log.Printf("punishment watcher: failed to notify channel: %v", err)
	}
}

func (b *Bot) logMuteRemoval(channelID, userID, staffID, reason string) {
	if channelID == "" {
		return
	}

	embed := &discordgo.MessageEmbed{
		Title: "Mute Removed",
		Fields: []*discordgo.MessageEmbedField{
			{Name: "User", Value: fmt.Sprintf("<@%s>", userID), Inline: true},
			{Name: "Moderator", Value: fmt.Sprintf("<@%s>", staffID), Inline: true},
			{Name: "Reason", Value: fmt.Sprintf("`%s`", reason), Inline: true},
		},
		Color:     0x40ff56,
		Timestamp: time.Now().Format(time.RFC3339),
	}

	if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
		embed.Thumbnail = thumb
		_, err := b.Sess.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
			Embeds: []*discordgo.MessageEmbed{embed},
			Files:  files,
		})
		cleanup()
		if err != nil {
			log.Printf("punishment watcher: failed to send log embed: %v", err)
		}
		return
	}

	if _, err := b.Sess.ChannelMessageSendEmbed(channelID, embed); err != nil {
		log.Printf("punishment watcher: failed to send log embed: %v", err)
	}
}

func (b *Bot) handleExpiredRankedBans(ctx context.Context) {
	roleID := settingOrEnv("RANKED_BAN_ROLE_ID")
	if roleID == "" {
		return
	}

	queryCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	expired, err := storage.FetchExpiredRankedBans(queryCtx)
	if err != nil {
		log.Printf("punishment watcher: fetch expired ranked bans: %v", err)
		return
	}
	if len(expired) == 0 {
		return
	}

	logChannelID, _ := storage.GetLogChannelID(queryCtx)
	punishmentsChannelID, _ := storage.GetPunishmentsChannelID(queryCtx)
	supportChannelID, _ := storage.GetSupportChannelID(queryCtx)

	log.Printf("punishment watcher: processing %d ranked ban expirations", len(expired))

	for _, record := range expired {
		for _, guildID := range b.guildIDs() {
			log.Printf("punishment watcher: checking ranked ban expiry for user %s in guild %s", record.UserID, guildID)
			member, err := b.Sess.GuildMember(guildID, record.UserID)
			if err != nil {
				log.Printf("punishment watcher: failed to fetch member %s in guild %s: %v", record.UserID, guildID, err)
				continue
			}
			if hasRole(member, roleID) {
				if err := b.Sess.GuildMemberRoleRemove(guildID, record.UserID, roleID); err != nil {
					log.Printf("punishment watcher: failed to remove ranked ban role for %s in guild %s: %v", record.UserID, guildID, err)
				}
			}
		}

		log.Printf("punishment watcher: notifying ranked ban expiry for %s", record.UserID)
		notifyRankedBanExpired(b.Sess, punishmentsChannelID, supportChannelID, record.UserID, record.Reason)
		logRankedBanRemoval(b.Sess, logChannelID, record.UserID, record.StaffID, record.Reason)

		updateCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
		if err := storage.MarkPunishmentExpired(updateCtx, record.ID); err != nil {
			log.Printf("punishment watcher: mark ranked ban expired %s: %v", record.ID, err)
		}
		log.Printf("punishment watcher: marked ranked ban punishment %s expired", record.ID)
		cancel()
	}
}

func (b *Bot) handleActiveRankedBans(ctx context.Context) {
	roleID := settingOrEnv("RANKED_BAN_ROLE_ID")
	if roleID == "" {
		return
	}

	queryCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()

	active, err := storage.FetchActiveRankedBans(queryCtx)
	if err != nil {
		log.Printf("punishment watcher: fetch active ranked bans: %v", err)
		return
	}
	if len(active) == 0 {
		return
	}

	for _, record := range active {
		for _, guildID := range b.guildIDs() {
			member, err := b.Sess.GuildMember(guildID, record.UserID)
			if err != nil {
				continue
			}
			if !hasRole(member, roleID) {
				if err := b.Sess.GuildMemberRoleAdd(guildID, record.UserID, roleID); err != nil {
					log.Printf("punishment watcher: failed to apply ranked ban role for %s in guild %s: %v", record.UserID, guildID, err)
				}
			}
		}
	}
}

func notifyRankedBanExpired(s *discordgo.Session, punishChannelID, supportChannelID, userID, reason string) {
	if punishChannelID == "" {
		return
	}
	supportMention := "support"
	if strings.TrimSpace(supportChannelID) != "" {
		supportMention = fmt.Sprintf("<#%s>", supportChannelID)
	}

	embed := &discordgo.MessageEmbed{
		Title:       "Ranked Ban Expired",
		Description: fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n\nIf you wish to appeal future punishments, please open a ticket in %s.", userID, reason, supportMention),
		Color:       0x40ff56,
		Timestamp:   time.Now().Format(time.RFC3339),
	}

	if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
		embed.Thumbnail = thumb
		_, err := s.ChannelMessageSendComplex(punishChannelID, &discordgo.MessageSend{
			Content: fmt.Sprintf("<@%s>", userID),
			Embeds:  []*discordgo.MessageEmbed{embed},
			Files:   files,
		})
		cleanup()
		if err != nil {
			log.Printf("punishment watcher: failed to notify ranked ban expiry: %v", err)
		}
		return
	}

	if _, err := s.ChannelMessageSendComplex(punishChannelID, &discordgo.MessageSend{
		Content: fmt.Sprintf("<@%s>", userID),
		Embeds:  []*discordgo.MessageEmbed{embed},
	}); err != nil {
		log.Printf("punishment watcher: failed to notify ranked ban expiry: %v", err)
	}
}

func logRankedBanRemoval(s *discordgo.Session, channelID, userID, staffID, reason string) {
	if channelID == "" {
		return
	}

	embed := &discordgo.MessageEmbed{
		Title: "Ranked Ban Removed",
		Fields: []*discordgo.MessageEmbedField{
			{Name: "User", Value: fmt.Sprintf("<@%s>", userID), Inline: true},
			{Name: "Moderator", Value: fmt.Sprintf("<@%s>", staffID), Inline: true},
			{Name: "Reason", Value: fmt.Sprintf("`%s`", reason), Inline: true},
		},
		Color:     0x40ff56,
		Timestamp: time.Now().Format(time.RFC3339),
	}

	if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
		embed.Thumbnail = thumb
		_, err := s.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
			Embeds: []*discordgo.MessageEmbed{embed},
			Files:  files,
		})
		cleanup()
		if err != nil {
			log.Printf("punishment watcher: failed to log ranked ban removal: %v", err)
		}
		return
	}

	if _, err := s.ChannelMessageSendEmbed(channelID, embed); err != nil {
		log.Printf("punishment watcher: failed to log ranked ban removal: %v", err)
	}
}
