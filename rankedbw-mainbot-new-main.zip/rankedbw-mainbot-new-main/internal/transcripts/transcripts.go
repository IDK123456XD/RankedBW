package transcripts

import (
	"errors"
	"fmt"
	"html"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

const transcriptDir = "data/transcripts"

var invalidFileNameChars = regexp.MustCompile(`[<>:"/\\|?*]+`)

func sanitizeFileName(name string) string {
	name = strings.TrimSpace(name)
	if name == "" {
		return ""
	}
	name = invalidFileNameChars.ReplaceAllString(name, "_")
	return name
}

func ensureDir() error {
	return os.MkdirAll(transcriptDir, 0o755)
}

func filePath(season, gameID string) (string, error) {
	seasonSegment := sanitizeFileName(season)
	if seasonSegment == "" {
		seasonSegment = "unknown"
	}
	id := sanitizeFileName(gameID)
	if id == "" {
		return "", errors.New("empty game ID")
	}
	if err := ensureDir(); err != nil {
		return "", err
	}
	return filepath.Join(transcriptDir, fmt.Sprintf("season_%s_game_%s.html", seasonSegment, id)), nil
}

// Write writes the transcript for the provided game ID and returns the path.
func Write(season, gameID, text string) (string, error) {
	path, err := filePath(season, gameID)
	if err != nil {
		return "", err
	}
	escaped := html.EscapeString(text)
	doc := fmt.Sprintf("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>Transcript %s</title></head><body><pre>%s</pre></body></html>", sanitizeFileName(gameID), escaped)
	if err := os.WriteFile(path, []byte(doc), 0o644); err != nil {
		return "", err
	}
	return path, nil
}

// Read returns the stored transcript for the game, or empty string if missing.
func Read(season, gameID string) (string, error) {
	path, err := filePath(season, gameID)
	if err != nil {
		return "", err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return "", nil
		}
		return "", err
	}
	contents := string(data)
	start := strings.Index(contents, "<pre>")
	end := strings.LastIndex(contents, "</pre>")
	if start >= 0 && end > start {
		raw := contents[start+len("<pre>") : end]
		return html.UnescapeString(raw), nil
	}
	return "", nil
}

// FilePath returns the path to the stored transcript file.
func FilePath(season, gameID string) (string, error) {
	return filePath(season, gameID)
}

func linkPath(season, gameID string) (string, error) {
	path, err := filePath(season, gameID)
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("%s.link", path), nil
}

// TranscriptEmbed holds embed metadata captured from the thread.
type TranscriptEmbed struct {
	Title       string `json:"title,omitempty"`
	Description string `json:"description,omitempty"`
}

// TranscriptEntry describes a single captured message for optional logging purposes.
type TranscriptEntry struct {
	Timestamp   time.Time         `json:"timestamp"`
	Author      string            `json:"author"`
	AuthorID    string            `json:"authorId,omitempty"`
	Content     string            `json:"content"`
	Attachments []string          `json:"attachments,omitempty"`
	Embeds      []TranscriptEmbed `json:"embeds,omitempty"`
}

// WriteLink stores a reference (e.g., a Discord message URL) for the transcript.
func WriteLink(season, gameID, link string) error {
	path, err := linkPath(season, gameID)
	if err != nil {
		return err
	}
	return os.WriteFile(path, []byte(link), 0o644)
}

// ReadLink returns the stored transcript link for the game, or empty string if missing.
func ReadLink(season, gameID string) (string, error) {
	path, err := linkPath(season, gameID)
	if err != nil {
		return "", err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return "", nil
		}
		return "", err
	}
	return strings.TrimSpace(string(data)), nil
}
