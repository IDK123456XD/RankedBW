package rolecommands

import (
	"context"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Config struct {
	Name               string
	RoleEnv            string
	ManagerRoleEnv     string
	OwnerRoleEnv       string
	AnnounceChannelEnv string
	LogChannelEnv      string
}

const defaultEmbedColor = 0x004CFF
const embedColorAdded = 0x57F287
const embedColorRemoved = 0xED4245

func (cfg Config) RoleID() (string, error) {
	id := cfg.settingOrEnv(cfg.RoleEnv)
	if id == "" {
		return "", errors.New("missing env " + cfg.RoleEnv)
	}
	return id, nil
}

func (cfg Config) ManagerRoleID() string {
	if cfg.ManagerRoleEnv == "" {
		return ""
	}
	return cfg.settingOrEnv(cfg.ManagerRoleEnv)
}

func (cfg Config) OwnerRoleID() string {
	if cfg.OwnerRoleEnv == "" {
		return ""
	}
	return cfg.settingOrEnv(cfg.OwnerRoleEnv)
}

func (cfg Config) AnnounceChannelID() string {
	if cfg.AnnounceChannelEnv == "" {
		return ""
	}
	return cfg.settingOrEnv(cfg.AnnounceChannelEnv)
}

func (cfg Config) LogChannelID() string {
	if cfg.LogChannelEnv == "" {
		return ""
	}
	return cfg.settingOrEnv(cfg.LogChannelEnv)
}

func (cfg Config) settingOrEnv(env string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if val, err := storage.GetSettingValue(ctx, env); err == nil && strings.TrimSpace(val) != "" {
		return strings.TrimSpace(val)
	}
	return strings.TrimSpace(os.Getenv(env))
}

func PlayerMinecraftName(ctx context.Context, userID string) string {
	player, err := storage.GetPlayerByUserID(ctx, userID)
	if err != nil || player == nil {
		return ""
	}
	return player.MinecraftName
}

func (cfg Config) Announce(s *discordgo.Session, userID, ign, reason string) {
	channelID := cfg.AnnounceChannelID()
	if channelID == "" {
		return
	}
	message := fmt.Sprintf(":tada: Congratulations <@%s>", userID)
	if ign != "" {
		message += fmt.Sprintf(" (`%s`)", ign)
	}
	message += fmt.Sprintf("! You have been accepted into %s.", cfg.Name)
	if reason != "" {
		message += fmt.Sprintf("\n**Reason:** %s", reason)
	}
	if _, err := s.ChannelMessageSend(channelID, message); err != nil {
		fmt.Printf("rolecommands: failed to send announcement: %v\n", err)
	}
}

// AnnounceAction sends a colored embed to the announcement channel for add/remove flows.
func (cfg Config) AnnounceAction(s *discordgo.Session, added bool, actorID, targetID, ign, reason string) {
	channelID := cfg.AnnounceChannelID()
	if channelID == "" || s == nil {
		return
	}
	action := "Added"
	preposition := "to"
	color := embedColorAdded
	if !added {
		action = "Removed"
		preposition = "from"
		color = embedColorRemoved
	}

	actorMention := ""
	if id := strings.TrimSpace(actorID); id != "" {
		actorMention = fmt.Sprintf("<@%s>", id)
	}
	targetMention := fmt.Sprintf("<@%s>", strings.TrimSpace(targetID))
	targetLabel := targetMention
	if strings.TrimSpace(ign) != "" {
		targetLabel = fmt.Sprintf("%s (`%s`)", targetMention, strings.TrimSpace(ign))
	}

	desc := fmt.Sprintf("%s has %s %s %s %s.", actorMention, strings.ToLower(action), targetLabel, preposition, cfg.Name)
	if strings.TrimSpace(reason) != "" {
		desc += fmt.Sprintf("\n**Reason:** %s", strings.TrimSpace(reason))
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("%s %s", cfg.Name, action),
		Description: strings.TrimSpace(desc),
		Color:       color,
	}

	_, err := s.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
		Embeds: []*discordgo.MessageEmbed{embed},
		AllowedMentions: &discordgo.MessageAllowedMentions{
			Parse: []discordgo.AllowedMentionType{},
		},
	})
	if err != nil {
		fmt.Printf("rolecommands: failed to send announcement embed: %v\n", err)
	}
}

func (cfg Config) Log(s *discordgo.Session, content string) {
	channelID := cfg.LogChannelID()
	if channelID == "" {
		return
	}
	if _, err := s.ChannelMessageSend(channelID, content); err != nil {
		fmt.Printf("rolecommands: failed to send log: %v\n", err)
	}
}

// LogAction sends a styled embed for add/remove actions with an optional reason.
// Mentions are included in the embed text but AllowedMentions are disabled to avoid pings.
func (cfg Config) LogAction(s *discordgo.Session, added bool, actorID, targetID, reason string) {
	channelID := cfg.LogChannelID()
	if channelID == "" || s == nil {
		return
	}
	actorMention := fmt.Sprintf("<@%s>", strings.TrimSpace(actorID))
	targetMention := fmt.Sprintf("<@%s>", strings.TrimSpace(targetID))
	action := "added"
	preposition := "to"
	color := embedColorAdded
	if !added {
		action = "removed"
		preposition = "from"
		color = embedColorRemoved
	}

	desc := fmt.Sprintf("%s has %s %s %s %s.", actorMention, action, targetMention, preposition, cfg.Name)
	if strings.TrimSpace(reason) != "" {
		desc += fmt.Sprintf("\n**Reason:** %s", strings.TrimSpace(reason))
	}

	capitalized := action
	if len(action) > 0 {
		capitalized = strings.ToUpper(action[:1]) + action[1:]
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("%s %s", cfg.Name, capitalized),
		Description: desc,
		Color:       color,
	}

	_, err := s.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
		Embeds: []*discordgo.MessageEmbed{embed},
		AllowedMentions: &discordgo.MessageAllowedMentions{
			Parse: []discordgo.AllowedMentionType{},
		},
	})
	if err != nil {
		fmt.Printf("rolecommands: failed to send log embed: %v\n", err)
	}
}

func FetchAllMembers(s *discordgo.Session, guildID string) ([]*discordgo.Member, error) {
	var members []*discordgo.Member
	after := ""
	for {
		chunk, err := s.GuildMembers(guildID, after, 1000)
		if err != nil {
			return nil, err
		}
		if len(chunk) == 0 {
			break
		}
		members = append(members, chunk...)
		if len(chunk) < 1000 {
			break
		}
		after = chunk[len(chunk)-1].User.ID
	}
	return members, nil
}

func FormatMember(ctx context.Context, member *discordgo.Member) string {
	mcName := PlayerMinecraftName(ctx, member.User.ID)
	if mcName != "" {
		return fmt.Sprintf("%s | `%s`", member.Mention(), mcName)
	}
	if member.Nick != "" {
		return fmt.Sprintf("%s | `%s`", member.Mention(), member.Nick)
	}
	return member.Mention()
}

func FormatReason(reason string) string {
	reason = strings.TrimSpace(reason)
	if reason == "" {
		return ""
	}
	return fmt.Sprintf("Reason: %s", reason)
}

// IsManagerOrOwner returns true if the member has the configured manager or owner role.
func (cfg Config) IsManagerOrOwner(member *discordgo.Member) bool {
	if member == nil {
		return false
	}
	manager := strings.TrimSpace(cfg.ManagerRoleID())
	owner := strings.TrimSpace(cfg.OwnerRoleID())
	if manager == "" && owner == "" {
		return false
	}
	for _, r := range member.Roles {
		if r == manager || r == owner {
			return true
		}
	}
	return false
}
