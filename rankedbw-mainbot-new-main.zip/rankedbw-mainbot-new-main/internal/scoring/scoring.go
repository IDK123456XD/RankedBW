package scoring

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"rbw-bot/internal/leveling"
	"rbw-bot/internal/ranks"
	"rbw-bot/internal/storage"
)

var (
	ErrGameNotFound     = errors.New("game not found")
	ErrAlreadyScored    = errors.New("game already scored")
	ErrGameVoided       = errors.New("game has been voided")
	ErrNoGamePlayers    = errors.New("no players recorded for this game")
	ErrInvalidTeam      = errors.New("winning team must be 1 or 2")
	ErrMissingMVP       = errors.New("at least one MVP must be provided")
	ErrParticipantCheck = errors.New("you are not a participant in this game")
)

type ScoreRequest struct {
	GameID             string
	WinningTeam        int
	Reason             string
	MVPDiscordIDs      []string
	RequireParticipant string
	AllowRescore       bool
	AllowNoMVP         bool
}

type ScoreResult struct {
	Game           *storage.GameRecord
	WinningTeam    int
	Reason         string
	WinnerMentions []string
	LoserMentions  []string
	MVPMentions    []string
	MVPDiscordIDs  []string
	PlayerUpdates  []storage.ScoreUpdate
	ScoreLines     []ScoreLine
}

// ScoreLine contains before/after ELO data for a player in the scored game.
type ScoreLine struct {
	DiscordID string
	PreElo    int
	PostElo   int
	EloDiff   int
	Win       bool
}

func ScoreGame(ctx context.Context, req ScoreRequest) (*ScoreResult, error) {
	if req.GameID == "" {
		return nil, ErrGameNotFound
	}
	if req.WinningTeam != 1 && req.WinningTeam != 2 {
		return nil, ErrInvalidTeam
	}
	if len(req.MVPDiscordIDs) == 0 && !req.AllowNoMVP {
		return nil, ErrMissingMVP
	}

	game, players, seasonID, err := storage.GetGameWithPlayersActiveSeason(ctx, req.GameID)
	if err != nil {
		return nil, err
	}
	if game == nil {
		return nil, ErrGameNotFound
	}
	status := strings.ToUpper(strings.TrimSpace(game.Status))
	alreadyScored := status == "FINISHED" || status == "SCORED"
	isCancelled := status == "CANCELLED"
	isVoided := status == "VOIDED"

	if alreadyScored && !req.AllowRescore {
		return nil, ErrAlreadyScored
	}
	if isCancelled {
		return nil, ErrGameVoided
	}
	if isVoided && !req.AllowRescore {
		return nil, ErrGameVoided
	}
	if len(players) == 0 {
		return nil, ErrNoGamePlayers
	}
	if status == "SCORED" && req.AllowRescore {
		if err := revertExistingScore(ctx, game, players, seasonID); err != nil {
			return nil, fmt.Errorf("failed to revert existing score: %w", err)
		}
	}

	playerByDiscord := make(map[string]*storage.GamePlayerRecord)
	winnerCount := 0
	for idx := range players {
		player := &players[idx]
		if player.DiscordTeam == req.WinningTeam {
			winnerCount++
		}
		if trimmed := strings.TrimSpace(player.DiscordID); trimmed != "" {
			playerByDiscord[trimmed] = player
		}
	}
	if winnerCount == 0 {
		return nil, fmt.Errorf("no players recorded for team %d", req.WinningTeam)
	}

	if trimmed := strings.TrimSpace(req.RequireParticipant); trimmed != "" {
		if _, ok := playerByDiscord[trimmed]; !ok {
			return nil, ErrParticipantCheck
		}
	}

	uniqueMVPs := make(map[string]struct{}, len(req.MVPDiscordIDs))
	var normalizedMVPs []string
	for _, id := range req.MVPDiscordIDs {
		id = strings.TrimSpace(id)
		if id == "" {
			continue
		}
		if _, exists := uniqueMVPs[id]; exists {
			continue
		}
		if _, ok := playerByDiscord[id]; !ok {
			return nil, fmt.Errorf("selected MVP <@%s> is not part of this game", id)
		}
		uniqueMVPs[id] = struct{}{}
		normalizedMVPs = append(normalizedMVPs, id)
	}
	if len(normalizedMVPs) == 0 && !req.AllowNoMVP {
		return nil, ErrMissingMVP
	}

	var updates []storage.ScoreUpdate
	var winnerMentions, loserMentions []string
	var scoreLines []ScoreLine

	for _, player := range players {
		stats, err := storage.GetPlayerSeasonStats(ctx, player.PlayerID, seasonID)
		if err != nil {
			return nil, fmt.Errorf("failed to load stats for player %s: %w", player.PlayerID, err)
		}
		if stats == nil {
			return nil, fmt.Errorf("player %s has no stats for this season", player.PlayerID)
		}

		isWinner := player.DiscordTeam == req.WinningTeam
		isMVP := false
		if trimmed := strings.TrimSpace(player.DiscordID); trimmed != "" {
			if _, ok := uniqueMVPs[trimmed]; ok {
				isMVP = true
			}
		}

		if mention := mentionFromDiscordID(player.DiscordID); mention != "" {
			if isWinner {
				winnerMentions = append(winnerMentions, mention)
			} else {
				loserMentions = append(loserMentions, mention)
			}
		}

		skipStats := stats.LastReset.Valid && game.CreatedAt.Before(stats.LastReset.Time)
		preElo := stats.Elo
		if skipStats {
			preElo = player.PreElo
		}
		if skipStats {
			updates = append(updates, storage.ScoreUpdate{
				GamePlayerID: player.ID,
				PlayerID:     player.PlayerID,
				StatsID:      stats.ID,
				SeasonID:     stats.SeasonID,
				Win:          isWinner,
				MVP:          isMVP,
				NewElo:       preElo,
				EloDiff:      0,
				XPDelta:      0,
				Streak:       stats.Streak,
				EloReason:    "ManualAdjustment",
				ExtraReason:  scoreExtraReason(game.GameID, isWinner, isMVP, req.Reason),
				SkipStats:    true,
			})
			scoreLines = append(scoreLines, ScoreLine{
				DiscordID: strings.TrimSpace(player.DiscordID),
				PreElo:    preElo,
				PostElo:   preElo,
				EloDiff:   0,
				Win:       isWinner,
			})
			continue
		}

		eloDelta, ok := ranks.CalculateEloChange(isWinner, isMVP, player.PreElo, stats.Streak)
		if !ok {
			return nil, fmt.Errorf("unable to determine elo change for player %s", player.PlayerID)
		}

		newElo := stats.Elo + eloDelta
		if newElo < 0 {
			newElo = 0
		}
		xpReward := leveling.GameXPReward(player.PreElo, isWinner, isMVP)
		newStreak := streakAfterResult(stats.Streak, isWinner)
		extraReason := scoreExtraReason(game.GameID, isWinner, isMVP, req.Reason)

		eloReason := "GameLoss"
		if isMVP {
			eloReason = "MVP"
		} else if isWinner {
			eloReason = "GameWin"
		}

		updates = append(updates, storage.ScoreUpdate{
			GamePlayerID: player.ID,
			PlayerID:     player.PlayerID,
			StatsID:      stats.ID,
			SeasonID:     stats.SeasonID,
			Win:          isWinner,
			MVP:          isMVP,
			NewElo:       newElo,
			EloDiff:      newElo - stats.Elo,
			XPDelta:      xpReward,
			Streak:       newStreak,
			EloReason:    eloReason,
			ExtraReason:  extraReason,
		})

		scoreLines = append(scoreLines, ScoreLine{
			DiscordID: strings.TrimSpace(player.DiscordID),
			PreElo:    preElo,
			PostElo:   newElo,
			EloDiff:   newElo - preElo,
			Win:       isWinner,
		})
	}

	if err := storage.ApplyGameScore(ctx, game.ID, req.Reason, updates); err != nil {
		return nil, err
	}

	var mvpMentions []string
	for _, id := range normalizedMVPs {
		mvpMentions = append(mvpMentions, mentionFromDiscordID(id))
	}

	return &ScoreResult{
		Game:           game,
		WinningTeam:    req.WinningTeam,
		Reason:         req.Reason,
		WinnerMentions: winnerMentions,
		LoserMentions:  loserMentions,
		MVPMentions:    mvpMentions,
		MVPDiscordIDs:  normalizedMVPs,
		PlayerUpdates:  updates,
		ScoreLines:     scoreLines,
	}, nil
}

func revertExistingScore(ctx context.Context, game *storage.GameRecord, players []storage.GamePlayerRecord, seasonID string) error {
	var updates []storage.UnscoreUpdate
	for _, player := range players {
		stats, err := storage.GetPlayerSeasonStats(ctx, player.PlayerID, seasonID)
		if err != nil {
			return fmt.Errorf("failed to load stats for player %s: %w", player.PlayerID, err)
		}
		if stats == nil {
			return fmt.Errorf("player %s has no stats for this season", player.PlayerID)
		}

		skipStats := stats.LastReset.Valid && game.CreatedAt.Before(stats.LastReset.Time)
		if skipStats {
			updates = append(updates, storage.UnscoreUpdate{
				GamePlayerID: player.ID,
				PlayerID:     player.PlayerID,
				StatsID:      stats.ID,
				SeasonID:     stats.SeasonID,
				Win:          player.Win,
				MVP:          player.MVP,
				XPDelta:      0,
				Streak:       stats.Streak,
				NewElo:       stats.Elo,
				ExtraReason:  fmt.Sprintf("Game Rescore Revert: %s", game.GameID),
				SkipStats:    true,
			})
			continue
		}

		diff := player.EloDiff
		if diff == 0 && player.PostElo != 0 {
			diff = player.PostElo - player.PreElo
		}
		newElo := stats.Elo - diff
		if newElo < 0 {
			newElo = 0
		}
		xpToRemove := leveling.GameXPReward(player.PreElo, player.Win, player.MVP)
		newStreak := streakAfterRevert(stats.Streak, player.Win)

		updates = append(updates, storage.UnscoreUpdate{
			GamePlayerID: player.ID,
			PlayerID:     player.PlayerID,
			StatsID:      stats.ID,
			SeasonID:     stats.SeasonID,
			Win:          player.Win,
			MVP:          player.MVP,
			XPDelta:      xpToRemove,
			Streak:       newStreak,
			NewElo:       newElo,
			ExtraReason:  fmt.Sprintf("Game Rescore Revert: %s", game.GameID),
		})
	}
	if len(updates) == 0 {
		return errors.New("no player updates to revert")
	}
	return storage.RevertGameScore(ctx, game.ID, updates)
}
