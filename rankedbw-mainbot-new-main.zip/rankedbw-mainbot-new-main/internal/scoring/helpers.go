package scoring

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"rbw-bot/internal/storage"
)

func seasonIDForGame(ctx context.Context, game *storage.GameRecord) (string, error) {
	if game == nil {
		return "", errors.New("game not found")
	}
	if game.SeasonID.Valid {
		if trimmed := strings.TrimSpace(game.SeasonID.String); trimmed != "" {
			return trimmed, nil
		}
	}
	id, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		return "", err
	}
	if strings.TrimSpace(id) == "" {
		return "", errors.New("unable to determine active season")
	}
	return id, nil
}

func streakAfterResult(current int, win bool) int {
	if win {
		return current + 1
	}
	if current > 0 {
		return 0
	}
	return current - 1
}

func streakAfterRevert(current int, wasWin bool) int {
	if wasWin {
		return current - 1
	}
	if current == 0 {
		return 0
	}
	if current < 0 {
		return current + 1
	}
	return current
}

func mentionFromDiscordID(id string) string {
	id = strings.TrimSpace(id)
	if id == "" {
		return ""
	}
	return fmt.Sprintf("<@%s>", id)
}

func formatList(items []string) string {
	if len(items) == 0 {
		return "None"
	}
	return strings.Join(items, ", ")
}

func scoreExtraReason(gameID string, win, mvp bool, reason string) string {
	result := "LOSS"
	if win {
		result = "WIN"
	}
	mvpSuffix := ""
	if mvp {
		mvpSuffix = " + MVP"
	}
	base := fmt.Sprintf("Game Scored: %s (%s)%s", gameID, result, mvpSuffix)
	if trimmed := strings.TrimSpace(reason); trimmed != "" {
		return fmt.Sprintf("%s - %s", base, trimmed)
	}
	return base
}

func StreakAfterRevert(current int, wasWin bool) int {
	return streakAfterRevert(current, wasWin)
}

func MentionFromDiscordID(id string) string {
	return mentionFromDiscordID(id)
}

func FormatList(items []string) string {
	return formatList(items)
}

func SeasonIDForGame(ctx context.Context, game *storage.GameRecord) (string, error) {
	return seasonIDForGame(ctx, game)
}
