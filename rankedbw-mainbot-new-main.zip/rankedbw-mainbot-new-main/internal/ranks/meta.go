package ranks

// RankMeta describes a named elo bracket for presentation.
type RankMeta struct {
	Name string
	Min  int
	Max  int
}

var rankMeta = []RankMeta{
	{Name: "Coal", Min: 0, Max: 99},
	{Name: "Iron", Min: 100, Max: 199},
	{Name: "Gold", Min: 200, Max: 299},
	{Name: "Diamond", Min: 300, Max: 399},
	{Name: "Emerald", Min: 400, Max: 499},
	{Name: "Sapphire", Min: 500, Max: 599},
	{Name: "Ruby", Min: 600, Max: 699},
	{Name: "Crystal", Min: 700, Max: 799},
	{Name: "Opal", Min: 800, Max: 899},
	{Name: "Amethyst", Min: 900, Max: 999},
	{Name: "Obsidian", Min: 1000, Max: 1099},
	{Name: "Aquamarine", Min: 1100, Max: 1199},
	{Name: "Aventurine", Min: 1200, Max: 1299},
	{Name: "Onyx", Min: 1300, Max: 1399},
	{Name: "Quartz", Min: 1400, Max: 1499},
	{Name: "Topaz", Min: 1500, Max: 1599},
	{Name: "Zircon", Min: 1600, Max: 1699},
	{Name: "Pearl", Min: 1700, Max: 1799},
	{Name: "Moonstone", Min: 1800, Max: 1899},
	{Name: "Celestite", Min: 1900, Max: 1999},
	{Name: "Elite", Min: 2000, Max: 5000},
}

// RankForElo returns the presentation rank for the provided elo.
func RankForElo(elo int) RankMeta {
	for _, r := range rankMeta {
		if elo >= r.Min && elo <= r.Max {
			return r
		}
	}
	return RankMeta{Name: "Unranked", Min: 0, Max: 0}
}
