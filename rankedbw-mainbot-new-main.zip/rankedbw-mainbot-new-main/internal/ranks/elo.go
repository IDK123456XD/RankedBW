package ranks

type EloBracket struct {
	Min  int
	Max  int
	Gain int
	Loss int
	MVP  int
}

var eloData = []EloBracket{
	{Min: 0, Max: 99, Gain: 35, Loss: 10, MVP: 15},
	{Min: 100, Max: 199, Gain: 30, Loss: 10, MVP: 15},
	{Min: 200, Max: 299, Gain: 30, Loss: 15, MVP: 15},
	{Min: 300, Max: 399, Gain: 25, Loss: 15, MVP: 10},
	{Min: 400, Max: 499, Gain: 25, Loss: 20, MVP: 10},
	{Min: 500, Max: 599, Gain: 20, Loss: 20, MVP: 10},
	{Min: 600, Max: 699, Gain: 20, Loss: 25, MVP: 5},
	{Min: 700, Max: 799, Gain: 15, Loss: 25, MVP: 5},
	{Min: 800, Max: 899, Gain: 15, Loss: 30, MVP: 5},
	{Min: 900, Max: 999, Gain: 10, Loss: 30, MVP: 5},
	{Min: 1000, Max: 1099, Gain: 10, Loss: 35, MVP: 5},
	{Min: 1100, Max: 1199, Gain: 10, Loss: 35, MVP: 5},
	{Min: 1200, Max: 1299, Gain: 10, Loss: 35, MVP: 5},
	{Min: 1300, Max: 1399, Gain: 10, Loss: 40, MVP: 5},
	{Min: 1400, Max: 1499, Gain: 5, Loss: 45, MVP: 5},
	{Min: 1500, Max: 1599, Gain: 5, Loss: 50, MVP: 5},
	{Min: 1600, Max: 1699, Gain: 5, Loss: 55, MVP: 5},
	{Min: 1700, Max: 1799, Gain: 5, Loss: 60, MVP: 5},
	{Min: 1800, Max: 1899, Gain: 5, Loss: 65, MVP: 5},
	{Min: 1900, Max: 1999, Gain: 5, Loss: 70, MVP: 5},
	{Min: 2000, Max: 5000, Gain: 5, Loss: 75, MVP: 5},
}

func LossAmountForElo(elo int) (int, bool) {
	if bracket, ok := bracketForElo(elo); ok {
		return bracket.Loss, true
	}
	return 0, false
}

func MVPBonusForElo(elo int) (int, bool) {
	if bracket, ok := bracketForElo(elo); ok {
		return bracket.MVP, bracket.MVP > 0
	}
	return 0, false
}

func CalculateEloChange(winner, mvp bool, elo, winStreak int) (int, bool) {
	bracket, ok := bracketForElo(elo)
	if !ok {
		return 0, false
	}
	total := 0
	if winner {
		total += bracket.Gain
	} else {
		total -= bracket.Loss
	}
	if mvp {
		total += bracket.MVP
	}
	if winStreak >= 10 {
		total += 10
	}
	return total, true
}

func bracketForElo(elo int) (*EloBracket, bool) {
	for idx := range eloData {
		bracket := &eloData[idx]
		if elo >= bracket.Min && elo <= bracket.Max {
			return bracket, true
		}
	}
	return nil, false
}
