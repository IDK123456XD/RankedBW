package leveling

// GameXPReward calculates the XP reward for a player based on their elo,
// whether they won, and whether they received MVP.
func GameXPReward(currentElo int, isWinner, isMVP bool) int {
	if currentElo < 0 {
		currentElo = 0
	}

	var total int
	if isWinner {
		total += 30 * currentElo
	} else {
		total += 15 * currentElo
	}
	if isMVP {
		total += 5 * currentElo
	}
	return total
}
