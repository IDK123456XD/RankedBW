package leveling

import "math"

const (
	baseIncrement = 2500
	baseOffset    = 7500
)

// XPForNextLevel returns the XP required to advance from the supplied level to the next one.
func XPForNextLevel(level int) int {
	if level < 1 {
		level = 1
	}
	return baseIncrement*level + baseOffset
}

// TotalXPToReachLevel returns the total cumulative XP needed to reach a specific level.
func TotalXPToReachLevel(level int) int {
	if level < 1 {
		level = 1
	}
	n := level - 1
	return 1250*n*(n+1) + baseOffset*n
}

// Progress describes a player's standing within their current level.
type Progress struct {
	Level           int
	XPIntoLevel     int
	XPNeededForNext int
	XPRemaining     int
}

// ProgressFromTotalXP calculates the current level and XP progress based on a total XP value.
func ProgressFromTotalXP(totalXP int) Progress {
	if totalXP < 0 {
		totalXP = 0
	}

	const (
		a = 1250.0
		b = 8750.0
	)
	c := float64(-totalXP)
	discriminant := b*b - 4*a*c
	if discriminant < 0 {
		discriminant = 0
	}
	n := int(math.Floor((-b + math.Sqrt(discriminant)) / (2 * a)))
	if n < 0 {
		n = 0
	}

	level := n + 1
	xpIntoLevel := totalXP - TotalXPToReachLevel(level)
	if xpIntoLevel < 0 {
		xpIntoLevel = 0
	}
	xpNeeded := XPForNextLevel(level)
	xpRemaining := xpNeeded - xpIntoLevel
	if xpRemaining < 0 {
		xpRemaining = 0
	}

	return Progress{
		Level:           level,
		XPIntoLevel:     xpIntoLevel,
		XPNeededForNext: xpNeeded,
		XPRemaining:     xpRemaining,
	}
}
