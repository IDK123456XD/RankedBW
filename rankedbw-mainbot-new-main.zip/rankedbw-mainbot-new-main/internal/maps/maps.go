package maps

import (
	"context"
	"crypto/rand"
	"errors"
	"math/big"
	"strings"

	"rbw-bot/internal/storage"
)

// Info describes a queue map option.
type Info struct {
	Name       string
	Height     int
	GameStyles []string
}

var fallbackMaps = []Info{
	{Name: "Antenna", Height: 89, GameStyles: []string{"4v4"}},
	{Name: "Aquarium", Height: 111, GameStyles: []string{"4v4"}},
	{Name: "Archway", Height: 87, GameStyles: []string{"4v4"}},
	{Name: "Artemis", Height: 100, GameStyles: []string{"4v4"}},
	{Name: "Boletum", Height: 122, GameStyles: []string{"4v4"}},
	{Name: "Caraplace", Height: 91, GameStyles: []string{"4v4"}},
	{Name: "Catalyst", Height: 102, GameStyles: []string{"4v4"}},
	{Name: "Chained", Height: 91, GameStyles: []string{"4v4"}},
	{Name: "Eastwood/Deadwood/Coastal", Height: 101, GameStyles: []string{"4v4"}},
	{Name: "Extinction", Height: 87, GameStyles: []string{"4v4"}},
	{Name: "Invasion/Comet", Height: 116, GameStyles: []string{"4v4"}},
	{Name: "Katsu", Height: 97, GameStyles: []string{"4v4"}},
	{Name: "Lectus/Mortuus", Height: 91, GameStyles: []string{"4v4"}},
	{Name: "Obelisk", Height: 115, GameStyles: []string{"4v4"}},
	{Name: "Paladin", Height: 99, GameStyles: []string{"4v4"}},
	{Name: "Planet 98", Height: 106, GameStyles: []string{"4v4"}},
	{Name: "Rise", Height: 92, GameStyles: []string{"4v4"}},
	{Name: "Stonekeep/Snowkeep", Height: 96, GameStyles: []string{"4v4"}},
	{Name: "Swashbuckle/Pumpkin Bay", Height: 86, GameStyles: []string{"4v4"}},
	{Name: "Treenan", Height: 96, GameStyles: []string{"4v4"}},
}

// QueueMaps returns the map list from DB if available, otherwise falls back to bundled maps.
func QueueMaps(ctx context.Context) []Info {
	list, err := storage.ListMaps(ctx)
	if err == nil && len(list) > 0 {
		var out []Info
		for _, rec := range list {
			out = append(out, Info{Name: rec.Name, Height: rec.Height})
		}
		return out
	}
	out := make([]Info, len(fallbackMaps))
	copy(out, fallbackMaps)
	return out
}

// RandomForStyle returns a random map supporting the provided style.
// Style is ignored when DB-provided maps lack style metadata.
func RandomForStyle(ctx context.Context, style string) (Info, error) {
	style = strings.ToLower(strings.TrimSpace(style))
	maps := QueueMaps(ctx)

	var matches []Info
	for _, info := range maps {
		if len(info.GameStyles) == 0 {
			continue
		}
		for _, s := range info.GameStyles {
			if style == "" || strings.ToLower(s) == style {
				matches = append(matches, info)
				break
			}
		}
	}
	if len(matches) == 0 {
		matches = maps
	}
	if len(matches) == 0 {
		return Info{}, errors.New("no queue maps configured")
	}
	idx, err := rand.Int(rand.Reader, big.NewInt(int64(len(matches))))
	if err != nil {
		return matches[0], nil
	}
	return matches[idx.Int64()], nil
}
