package images

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"os"
	"path/filepath"
	"strings"

	"rbw-bot/internal/ranks"

	"golang.org/x/image/font"
	"golang.org/x/image/math/fixed"
)

const (
	scorecardBackgroundPath = "data/scorecard/scoring_background.png"
	scorecardArrowPath      = "data/scorecard/arrow.png"
	scorecardMVPTagPath     = "data/scorecard/mvp_tag.png"
	scorecardFontPath       = "data/fonts/AcherusFeral-Light.otf"
)

// ScorecardPlayer carries the per-player info needed to render a scorecard row.
type ScorecardPlayer struct {
	Name      string
	DiscordID string
	UUID      string
	HeadSkin  string
	PreElo    int
	PostElo   int
	EloDiff   int
	Win       bool
	MVP       bool
	Team      int
}

// ScorecardData bundles the metadata and roster for a scorecard image.
type ScorecardData struct {
	GameID     string
	MapName    string
	SeasonName string
	ScoredBy   string
	Players    []ScorecardPlayer
}

// Scorecard renders a PNG scorecard similar to the legacy bot layout.
func Scorecard(data ScorecardData) ([]byte, error) {
	const (
		canvasW      = 1400
		canvasH      = 800
		headSize     = 50
		headPadding  = 15
		rankCenterX  = 825
		eloCenterX   = 1150
		rowSpacing   = 74
		winnerStartY = 170
		loserStartY  = 480
		rowStartX    = 133
		rankIconSize = 64
		arrowDrawW   = 30
		arrowDrawH   = 20
		gameInfoX    = 50
		gameInfoY    = 766
	)

	bg := loadFirstPNG(scorecardBackgroundPath, filepath.Join("data", "scorecard", "scoring_background.png"))
	canvas := image.NewRGBA(image.Rect(0, 0, canvasW, canvasH))
	if bg != nil {
		draw.Draw(canvas, canvas.Bounds(), bg, image.Point{}, draw.Src)
	}

	arrow := loadFirstPNG(scorecardArrowPath, filepath.Join("data", "scorecard", "arrow.png"))
	mvpTag := loadFirstPNG(scorecardMVPTagPath, filepath.Join("data", "scorecard", "mvp_tag.png"))

	nameFont, _ := loadFont(resolveAssetPath(scorecardFontPath), 40)
	eloFont, _ := loadFont(resolveAssetPath(scorecardFontPath), 32)
	infoFont, _ := loadFont(resolveAssetPath(scorecardFontPath), 28)

	textColor := image.NewUniform(color.RGBA{R: 255, G: 255, B: 255, A: 255})
	greyText := image.NewUniform(color.RGBA{R: 0x98, G: 0x98, B: 0x98, A: 255})
	eloPos := image.NewUniform(color.RGBA{R: 0x84, G: 0xFF, B: 0xC4, A: 255})
	eloNeg := image.NewUniform(color.RGBA{R: 0xFF, G: 0x97, B: 0x97, A: 255})

	var winners, losers []ScorecardPlayer
	for _, p := range data.Players {
		if p.Win {
			winners = append(winners, p)
		} else {
			losers = append(losers, p)
		}
	}

	for idx, p := range winners {
		y := winnerStartY + idx*rowSpacing
		drawScorecardRow(canvas, p, rowStartX, y, headSize, headPadding, rankCenterX, eloCenterX, rankIconSize, arrowDrawW, arrowDrawH, nameFont, eloFont, textColor, greyText, eloPos, eloNeg, arrow, mvpTag)
	}

	for idx, p := range losers {
		y := loserStartY + idx*rowSpacing
		drawScorecardRow(canvas, p, rowStartX, y, headSize, headPadding, rankCenterX, eloCenterX, rankIconSize, arrowDrawW, arrowDrawH, nameFont, eloFont, textColor, greyText, eloPos, eloNeg, arrow, mvpTag)
	}

	gameLabel := fmt.Sprintf("Game %s", strings.TrimSpace(data.GameID))
	drawText(canvas, infoFont, textColor, gameInfoX, gameInfoY, gameLabel, alignLeft, noShadow())

	var buf bytes.Buffer
	if err := png.Encode(&buf, canvas); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func drawScorecardRow(canvas *image.RGBA, player ScorecardPlayer, startX, centerY, headSize, headPadding, rankCenterX, eloCenterX, rankIconSize, arrowW, arrowH int, nameFont, eloFont font.Face, textColor, greyText, eloPos, eloNeg image.Image, arrow, mvpTag image.Image) {
	if canvas == nil {
		return
	}
	name := strings.TrimSpace(player.Name)
	if name == "" {
		name = "Unknown"
	}

	// Head
	head := decodeHead(player.HeadSkin, player.UUID, name)
	if head != nil {
		scaleAndDraw(canvas, head, image.Point{X: startX, Y: centerY - headSize/2}, headSize, headSize)
	}

	nameX := startX + headSize + headPadding
	drawTextMid(canvas, nameFont, textColor, nameX, centerY, name)

	if player.MVP && mvpTag != nil {
		metrics := measureText(nameFont, name)
		tagX := nameX + metrics
		tagY := centerY - 21
		scaleAndDraw(canvas, mvpTag, image.Point{X: tagX + 20, Y: tagY}, 118, 42)
	}

	preElo := player.PreElo
	postElo := player.PostElo
	diff := player.EloDiff
	if diff == 0 {
		diff = postElo - preElo
	}
	if postElo == 0 {
		postElo = preElo + diff
	}

	preRank := ranks.RankForElo(preElo)
	postRank := ranks.RankForElo(postElo)

	preRankImg := loadRankIcon(preRank.Name)
	postRankImg := loadRankIcon(postRank.Name)

	rankChanged := preRank.Name != postRank.Name
	if rankChanged && postRankImg != nil {
		totalW := rankIconSize + arrowW + rankIconSize
		start := rankCenterX - totalW/2
		if preRankImg != nil {
			scaleAndDraw(canvas, preRankImg, image.Point{X: start, Y: centerY - rankIconSize/2}, rankIconSize, rankIconSize)
		}
		if arrow != nil {
			scaleAndDraw(canvas, arrow, image.Point{X: start + rankIconSize, Y: centerY - arrowH/2}, arrowW, arrowH)
		}
		scaleAndDraw(canvas, postRankImg, image.Point{X: start + rankIconSize + arrowW, Y: centerY - rankIconSize/2}, rankIconSize, rankIconSize)
	} else if preRankImg != nil {
		scaleAndDraw(canvas, preRankImg, image.Point{X: rankCenterX - rankIconSize/2, Y: centerY - rankIconSize/2}, rankIconSize, rankIconSize)
	}

	preText := fmt.Sprintf("%d", preElo)
	postText := fmt.Sprintf("%d", postElo)
	diffText := fmt.Sprintf("(%+d)", diff)

	preW := measureText(eloFont, preText)
	postW := measureText(eloFont, postText)
	diffW := measureText(eloFont, diffText)

	totalEloW := preW + arrowW + postW + diffW + 50
	startElo := eloCenterX - totalEloW/2
	x := startElo

	drawTextMid(canvas, eloFont, greyText, x, centerY, preText)
	x += preW

	if arrow != nil {
		scaleAndDraw(canvas, arrow, image.Point{X: x + 10, Y: centerY - arrowH/2}, arrowW, arrowH)
	}
	x += arrowW + 20

	drawTextMid(canvas, eloFont, textColor, x, centerY, postText)
	x += postW + 10

	if diff >= 0 {
		drawTextMid(canvas, eloFont, eloPos, x, centerY, diffText)
	} else {
		drawTextMid(canvas, eloFont, eloNeg, x, centerY, diffText)
	}
}

func decodeHead(encoded, uuid, fallbackName string) image.Image {
	data := strings.TrimSpace(encoded)
	if data != "" {
		if raw, err := base64.StdEncoding.DecodeString(data); err == nil {
			if img, err := png.Decode(bytes.NewReader(raw)); err == nil {
				return img
			}
		}
	}
	colorVal := colorFromString(uuid + fallbackName)
	img := image.NewRGBA(image.Rect(0, 0, 64, 64))
	draw.Draw(img, img.Bounds(), image.NewUniform(colorVal), image.Point{}, draw.Src)
	return img
}

func colorFromString(seed string) color.RGBA {
	seed = strings.TrimSpace(seed)
	if seed == "" {
		return color.RGBA{R: 90, G: 90, B: 90, A: 255}
	}
	hash := 0
	for _, c := range seed {
		hash = int(c) + ((hash << 5) - hash)
	}
	r := uint8((hash >> 0) & 0xFF)
	g := uint8((hash >> 8) & 0xFF)
	b := uint8((hash >> 16) & 0xFF)
	return color.RGBA{R: r, G: g, B: b, A: 255}
}

func drawTextMid(img draw.Image, face font.Face, clr image.Image, x, centerY int, text string) {
	if img == nil || face == nil {
		return
	}
	d := &font.Drawer{
		Dst:  img,
		Src:  clr,
		Face: face,
	}
	bounds, _ := d.BoundString(text)
	height := (bounds.Max.Y - bounds.Min.Y).Ceil()
	d.Dot = fixed.P(x, centerY+height/2)
	d.DrawString(text)
}

func loadFirstPNG(paths ...string) image.Image {
	for _, p := range paths {
		full := resolveAssetPath(p)
		if full == "" {
			continue
		}
		file, err := os.Open(full)
		if err != nil {
			continue
		}
		img, err := png.Decode(file)
		file.Close()
		if err != nil {
			continue
		}
		return img
	}
	return nil
}
