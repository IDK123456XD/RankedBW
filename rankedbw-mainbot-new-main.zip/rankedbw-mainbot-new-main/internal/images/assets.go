package images

import (
	"os"
	"path/filepath"
	"strings"
)

// resolveAssetPath tries to find an asset relative to common roots (env, cwd, executable dir, /app).
// Returns an empty string if no candidate exists.
func resolveAssetPath(rel string) string {
	rel = strings.TrimSpace(rel)
	if rel == "" {
		return ""
	}
	candidates := []string{}

	// Environment override
	if root := strings.TrimSpace(os.Getenv("RANKEDBW_ASSET_ROOT")); root != "" {
		candidates = append(candidates, filepath.Join(root, rel))
	}

	// If already absolute, check as-is first.
	if filepath.IsAbs(rel) {
		candidates = append(candidates, rel)
	}

	// Current working directory.
	if cwd, err := os.Getwd(); err == nil {
		candidates = append(candidates, filepath.Join(cwd, rel))
	}

	// Executable directory.
	if exe, err := os.Executable(); err == nil {
		candidates = append(candidates, filepath.Join(filepath.Dir(exe), rel))
	}

	// Common container root.
	candidates = append(candidates, filepath.Join("/app", rel))

	// Fallback to raw relative.
	if !filepath.IsAbs(rel) {
		candidates = append(candidates, rel)
	}

	for _, cand := range candidates {
		if info, err := os.Stat(cand); err == nil && !info.IsDir() {
			return cand
		}
	}
	return ""
}
