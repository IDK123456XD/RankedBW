package images

import (
	"bytes"
	"context"
	"encoding/base64"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"rbw-bot/internal/leveling"
	"rbw-bot/internal/ranks"
	"rbw-bot/internal/storage"

	xdraw "golang.org/x/image/draw"
	"golang.org/x/image/font"
	"golang.org/x/image/font/opentype"
	"golang.org/x/image/math/fixed"
)

const (
	defaultInfocardPath = "data/light.png"
	fontArchive         = "data/fonts/OpenSans-Bold.ttf"
	rankIconFolder      = "data/ranks"
	streakIconPath      = "data/streakicon.png"
)

// InfoCard renders a stat card PNG mirroring the legacy bot output.
func InfoCard(ctx context.Context, player *storage.PlayerRecord, stats *storage.PlayerSeasonStats) ([]byte, error) {
	if player == nil || stats == nil {
		return nil, fmt.Errorf("missing player or stats")
	}

	cardImage, _, _ := storage.PlayerInfocard(ctx, player.ID)
	cardPath := resolveAssetPath(filepath.Join("data", strings.TrimSpace(cardImage)))
	if cardPath == "" {
		cardPath = resolveAssetPath(filepath.Join("data/dark", strings.TrimSpace(cardImage)))
	}
	if cardPath == "" {
		cardPath = resolveAssetPath(defaultInfocardPath)
	}
	if cardPath == "" {
		return nil, fmt.Errorf("infocard base image not found")
	}

	bgFile, err := openFile(cardPath)
	if err != nil {
		return nil, fmt.Errorf("open base card: %w", err)
	}
	defer bgFile.Close()
	bgImg, err := png.Decode(bgFile)
	if err != nil {
		return nil, fmt.Errorf("decode base card: %w", err)
	}
	canvas := image.NewRGBA(bgImg.Bounds())
	draw.Draw(canvas, canvas.Bounds(), bgImg, image.Point{}, draw.Src)

	fontPath := resolveAssetPath(fontArchive)
	font36, _ := loadFont(fontPath, 36)
	font30, _ := loadFont(fontPath, 30)

	// Username (centered above skin, smoothly scaled to fit width)
	const baseNameSize = 60.0
	maxNameWidth := 430 // adjust if you tweak the nameplate width
	nameFont := adaptiveNameFont(fontPath, baseNameSize, 32.0, player.MinecraftName, maxNameWidth)
	drawGlowText(canvas, nameFont, color.RGBA{255, 255, 255, 255}, 280, 130, player.MinecraftName, alignCenter)

	// Skin render
	if body, encoded := fullBodyImage(ctx, player); body != nil {
		// Slimmer render, shifted slightly left.
		scaleAndDraw(canvas, body, image.Point{X: 180, Y: 170}, 230, 500)
		if encoded != "" {
			_ = storage.UpdatePlayerProfile(ctx, player.ID, player.MinecraftName, player.UUID, encoded, player.HeadSkin.String, player.SelectedInfocardID.String)
		}
	}

	// Elo
	eloFont, _ := loadFont(fontPath, 100)
	drawGlowText(canvas, eloFont, color.RGBA{255, 255, 255, 255}, 722, 500, fmt.Sprintf("%d", stats.Elo), alignCenter)

	// Rank place (#)
	rankPos, _ := storage.SeasonRankPosition(ctx, stats.SeasonID, player.ID, stats.Elo)
	rankPosColor := image.NewUniform(color.RGBA{0xAA, 0xAA, 0xAA, 0xFF})
	switch rankPos {
	case 1:
		rankPosColor = image.NewUniform(color.RGBA{0xEF, 0xBF, 0x04, 0xFF})
	case 2:
		rankPosColor = image.NewUniform(color.RGBA{0xB0, 0xB0, 0xB0, 0xFF})
	case 3:
		rankPosColor = image.NewUniform(color.RGBA{0xA0, 0xA0, 0xA0, 0xFF})
	}
	if rankPos > 0 {
		numberRankFont, _ := loadFont(fontPath, 75)
		drawText(canvas, numberRankFont, rankPosColor, 715, 225, fmt.Sprintf("#%d", rankPos), alignCenter, noShadow())
	}

	rankText := image.NewUniform(color.RGBA{255, 255, 255, 255})

	// Level + XP
	const (
		xpBarX = 945
		xpBarY = 125
		xpBarW = 375
		xpBarH = 24
	)
	progress := leveling.ProgressFromTotalXP(player.TotalXP)

	lvlX := xpBarX + xpBarW - 10
	lvlY := 90
	drawText(canvas, font36, rankText, lvlX, lvlY, fmt.Sprintf("LVL %d", progress.Level), alignRight, noShadow())

	xpInto := fmt.Sprintf("%d", progress.XPIntoLevel)
	xpNeed := fmt.Sprintf("%d XP", progress.XPNeededForNext)
	xpLeft := xpBarX + 10
	xpY := lvlY

	drawText(canvas, font30, rankText, xpLeft, xpY, xpInto, alignLeft, noShadow())
	xpLeft += measureText(font30, xpInto)

	drawText(canvas, font30, image.NewUniform(color.RGBA{0xC0, 0xC0, 0xC0, 0xFF}), xpLeft, xpY, "/", alignLeft, noShadow())
	xpLeft += measureText(font30, "/")

	drawText(canvas, font30, image.NewUniform(color.RGBA{0x80, 0x80, 0x80, 0xFF}), xpLeft, xpY, xpNeed, alignLeft, noShadow())

	drawXPBar(canvas, xpBarX, xpBarY, xpBarW, xpBarH, progress.XPIntoLevel, progress.XPNeededForNext, color.RGBA{0xAC, 0x8F, 0xFF, 0xFF})

	// Rank icon + division name
	rankMeta := ranks.RankForElo(stats.Elo)
	if icon := loadRankIcon(rankMeta.Name); icon != nil {
		scaleAndDraw(canvas, icon, image.Point{X: 1250, Y: 210}, 100, 100)
	}
	drawText(canvas, font36, rankText, 287, 745, strings.ToUpper(rankMeta.Name), alignCenter, noShadow())

	// Peak elo
	peakEloText := image.NewUniform(color.RGBA{255, 255, 255, 255})
	peakEloFont, _ := loadFont(fontPath, 52)
	drawText(canvas, peakEloFont, peakEloText, 722, 745, fmt.Sprintf("%d", stats.PeakElo), alignCenter, noShadow())

	// Stats column
	sideStatFont, _ := loadFont(fontPath, 55)
	drawText(canvas, sideStatFont, rankText, 1315, 455, fmt.Sprintf("%d", stats.Losses), alignRight, noShadow())
	wlr := 0.0
	if stats.Losses == 0 {
		wlr = float64(stats.Wins)
	} else {
		wlr = float64(stats.Wins) / float64(stats.Losses)
	}
	drawText(canvas, sideStatFont, rankText, 1315, 545, fmt.Sprintf("%.2f", wlr), alignRight, noShadow())
	drawText(canvas, sideStatFont, rankText, 1315, 630, fmt.Sprintf("%d", stats.MVPs), alignRight, noShadow())

	// Wins and streak
	if stats.Streak > 1 {
		winsText := fmt.Sprintf("%d", stats.Wins)
		streakText := fmt.Sprintf("%d", stats.Streak)
		winsWidth := measureText(sideStatFont, winsText)
		streakWidth := measureText(sideStatFont, streakText)
		streakX := 1315 - winsWidth - 24

		drawText(canvas, sideStatFont, image.NewUniform(color.RGBA{0xFF, 0xA7, 0x00, 0xFF}), streakX, 370, streakText, alignRight, noShadow())

		if streakIcon := loadFirstPNG(streakIconPath); streakIcon != nil {
			iconSizeX := 50
			iconSizeY := 65
			iconX := streakX - streakWidth - iconSizeX - 5
			iconY := 360 - iconSizeY/2 - 10
			scaleAndDraw(canvas, streakIcon, image.Point{X: iconX, Y: iconY}, iconSizeX, iconSizeY)
		}
		drawText(canvas, sideStatFont, rankText, 1315, 370, winsText, alignRight, noShadow())
	} else {
		drawText(canvas, sideStatFont, rankText, 1315, 370, fmt.Sprintf("%d", stats.Wins), alignRight, noShadow())
	}

	var buf bytes.Buffer
	if err := png.Encode(&buf, canvas); err != nil {
		return nil, fmt.Errorf("encode card: %w", err)
	}
	return buf.Bytes(), nil
}

func loadFont(path string, size float64) (font.Face, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	ft, err := opentype.Parse(data)
	if err != nil {
		return nil, err
	}
	return opentype.NewFace(ft, &opentype.FaceOptions{
		Size:    size,
		DPI:     72,
		Hinting: font.HintingFull,
	})
}

type textAlign int

const (
	alignLeft textAlign = iota
	alignCenter
	alignRight
)

type textShadow struct {
	offset image.Point
	color  image.Image
}

func shadow(clr image.Image) *textShadow {
	return &textShadow{offset: image.Point{X: 0, Y: 0}, color: clr}
}

func noShadow() *textShadow { return nil }

func drawText(img draw.Image, face font.Face, clr image.Image, x, y int, text string, align textAlign, sh *textShadow) {
	if face == nil || img == nil {
		return
	}
	d := &font.Drawer{
		Dst:  img,
		Src:  clr,
		Face: face,
	}
	width := measureText(face, text)
	switch align {
	case alignCenter:
		d.Dot = fixed.P(x-width/2, y)
	case alignRight:
		d.Dot = fixed.P(x-width, y)
	default:
		d.Dot = fixed.P(x, y)
	}
	if sh != nil {
		sd := *d
		sd.Dot = fixed.Point26_6{
			X: d.Dot.X + fixed.I(sh.offset.X),
			Y: d.Dot.Y + fixed.I(sh.offset.Y),
		}
		sd.Src = sh.color
		sd.DrawString(text)
	}
	d.DrawString(text)
}

// simpleBoxBlur applies a separable box blur for a smooth glow
func simpleBoxBlur(src *image.RGBA, radius int) *image.RGBA {
	if radius <= 0 {
		return src
	}

	w, h := src.Bounds().Dx(), src.Bounds().Dy()
	temp := image.NewRGBA(src.Bounds())
	dst := image.NewRGBA(src.Bounds())

	// horizontal pass
	for y := 0; y < h; y++ {
		var r, g, b, a int
		for x := -radius; x <= radius; x++ {
			xx := x
			if xx < 0 {
				xx = 0
			}
			if xx >= w {
				xx = w - 1
			}
			cr, cg, cb, ca := src.At(xx, y).RGBA()
			r += int(cr)
			g += int(cg)
			b += int(cb)
			a += int(ca)
		}
		for x := 0; x < w; x++ {
			dstColor := color.RGBA{
				uint8((r / (radius*2 + 1)) >> 8),
				uint8((g / (radius*2 + 1)) >> 8),
				uint8((b / (radius*2 + 1)) >> 8),
				uint8((a / (radius*2 + 1)) >> 8),
			}
			temp.SetRGBA(x, y, dstColor)

			// subtract left
			xl := x - radius
			if xl < 0 {
				xl = 0
			}
			cr, cg, cb, ca := src.At(xl, y).RGBA()
			r -= int(cr)
			g -= int(cg)
			b -= int(cb)
			a -= int(ca)

			// add right
			xr := x + radius
			if xr >= w {
				xr = w - 1
			}
			cr, cg, cb, ca = src.At(xr, y).RGBA()
			r += int(cr)
			g += int(cg)
			b += int(cb)
			a += int(ca)
		}
	}

	// vertical pass
	for x := 0; x < w; x++ {
		var r, g, b, a int
		for y := -radius; y <= radius; y++ {
			yy := y
			if yy < 0 {
				yy = 0
			}
			if yy >= h {
				yy = h - 1
			}
			cr, cg, cb, ca := temp.At(x, yy).RGBA()
			r += int(cr)
			g += int(cg)
			b += int(cb)
			a += int(ca)
		}
		for y := 0; y < h; y++ {
			dst.SetRGBA(x, y, color.RGBA{
				uint8((r / (radius*2 + 1)) >> 8),
				uint8((g / (radius*2 + 1)) >> 8),
				uint8((b / (radius*2 + 1)) >> 8),
				uint8((a / (radius*2 + 1)) >> 8),
			})

			// subtract top
			yt := y - radius
			if yt < 0 {
				yt = 0
			}
			cr, cg, cb, ca := temp.At(x, yt).RGBA()
			r -= int(cr)
			g -= int(cg)
			b -= int(cb)
			a -= int(ca)

			// add bottom
			yb := y + radius
			if yb >= h {
				yb = h - 1
			}
			cr, cg, cb, ca = temp.At(x, yb).RGBA()
			r += int(cr)
			g += int(cg)
			b += int(cb)
			a += int(ca)
		}
	}

	return dst
}

func drawGlowText(img draw.Image, face font.Face, base color.RGBA, x, y int, text string, align textAlign) {
	if face == nil || img == nil {
		return
	}

	// measure text width for alignment
	width := measureText(face, text)
	ax := x
	switch align {
	case alignCenter:
		ax = x - width/2
	case alignRight:
		ax = x - width
	}

	// --- Glow layer ---
	glowLayer := image.NewRGBA(img.Bounds())

	// bright glow color
	glowColor := image.NewUniform(color.RGBA{base.R, base.G, base.B, 255})

	// draw once (sharp) onto the glow layer
	drawText(glowLayer, face, glowColor, ax, y, text, alignLeft, noShadow())

	// medium blur: keeps the glow tight and bright
	blurred := simpleBoxBlur(glowLayer, 8)

	// draw blurred glow BEHIND the text, twice for extra strength
	draw.Draw(img, img.Bounds(), blurred, image.Point{}, draw.Over)
	draw.Draw(img, img.Bounds(), blurred, image.Point{}, draw.Over)

	// --- Crisp main text on top ---
	drawText(img, face, image.NewUniform(base), ax, y, text, alignLeft, noShadow())
}

func drawXPBar(img *image.RGBA, x, y, w, h, value, max int, fill color.RGBA) {
	if img == nil || w <= 0 || h <= 0 || max <= 0 {
		return
	}

	// clamp ratio
	ratio := float64(value) / float64(max)
	if ratio < 0 {
		ratio = 0
	}
	if ratio > 1 {
		ratio = 1
	}
	filledWidth := int(float64(w) * ratio)

	// pill radius
	r := h / 2
	if r <= 0 {
		r = 1
	}

	// colors: dark track, bright fill (similar to original)
	bgCol := color.RGBA{R: 30, G: 34, B: 60, A: 255} // dark bluish track
	fillCol := fill

	barImg := image.NewRGBA(image.Rect(0, 0, w, h))

	// helper: check if a point is inside the rounded-rect shape
	inside := func(xx, yy int) bool {
		// center rectangle
		if xx >= r && xx < w-r {
			return true
		}
		// left / right caps
		cx := r
		if xx >= w-r {
			cx = w - r - 1
		}
		dx := xx - cx
		dy := yy - r
		return dx*dx+dy*dy <= r*r
	}

	// draw background track
	for yy := 0; yy < h; yy++ {
		for xx := 0; xx < w; xx++ {
			if !inside(xx, yy) {
				continue
			}
			barImg.SetRGBA(xx, yy, bgCol)
		}
	}

	// draw filled portion on top (left side only)
	for yy := 0; yy < h; yy++ {
		for xx := 0; xx < filledWidth; xx++ {
			if !inside(xx, yy) {
				continue
			}
			barImg.SetRGBA(xx, yy, fillCol)
		}
	}

	// blit onto main canvas at (x, y)
	dstRect := image.Rect(x, y, x+w, y+h)
	draw.Draw(img, dstRect, barImg, image.Point{}, draw.Over)
}

func measureText(face font.Face, text string) int {
	if face == nil {
		return 0
	}
	return font.MeasureString(face, text).Round()
}

// adaptiveNameFont loads a font starting from baseSize and scales it down
// so that "text" fits within maxWidth pixels, but never below minSize.
func adaptiveNameFont(fontPath string, baseSize, minSize float64, text string, maxWidth int) font.Face {
	if text == "" || maxWidth <= 0 {
		f, _ := loadFont(fontPath, baseSize)
		return f
	}

	baseFace, err := loadFont(fontPath, baseSize)
	if err != nil || baseFace == nil {
		return nil
	}
	width := measureText(baseFace, text)
	if width <= maxWidth {
		return baseFace
	}

	scale := float64(maxWidth) / float64(width)
	newSize := baseSize * scale
	if newSize < minSize {
		newSize = minSize
	}

	scaledFace, err := loadFont(fontPath, newSize)
	if err != nil || scaledFace == nil {
		return baseFace
	}
	return scaledFace
}

func scaleAndDraw(dst *image.RGBA, src image.Image, at image.Point, w, h int) {
	if dst == nil || src == nil {
		return
	}
	scaled := image.NewRGBA(image.Rect(0, 0, w, h))
	xdraw.ApproxBiLinear.Scale(scaled, scaled.Bounds(), src, src.Bounds(), xdraw.Over, nil)
	rect := image.Rect(at.X, at.Y, at.X+w, at.Y+h)
	draw.Draw(dst, rect, scaled, image.Point{}, draw.Over)
}

func loadRankIcon(name string) image.Image {
	if strings.TrimSpace(name) == "" {
		return nil
	}
	filename := fmt.Sprintf("%s rank.png", strings.ToLower(strings.TrimSpace(name)))
	path := filepath.Join(rankIconFolder, filename)
	full := resolveAssetPath(path)
	if full == "" {
		return nil
	}
	f, err := openFile(full)
	if err != nil {
		return nil
	}
	defer f.Close()
	img, err := png.Decode(f)
	if err != nil {
		return nil
	}
	return img
}

func fetchPNG(ctx context.Context, url string) (image.Image, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}

	req.Header.Set("User-Agent", "rbw-info-card")

	client := &http.Client{
		Timeout: 8 * time.Second,
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return nil, fmt.Errorf("status %d", resp.StatusCode)
	}

	img, _, err := image.Decode(resp.Body)
	if err != nil {
		return nil, err
	}

	return img, nil
}

func fullBodyImage(ctx context.Context, player *storage.PlayerRecord) (image.Image, string) {
	if player == nil {
		return nil, ""
	}
	if player.FullBodySkin.Valid && strings.TrimSpace(player.FullBodySkin.String) != "" {
		if img, err := decodeBase64Image(player.FullBodySkin.String); err == nil {
			return img, ""
		}
	}

	var urls []string
	if uuid := strings.TrimSpace(player.UUID); uuid != "" {
		urls = append(urls, fmt.Sprintf("https://mc-heads.net/body/%s/320.png", uuid))
	}
	if ign := strings.TrimSpace(player.MinecraftName); ign != "" {
		urls = append(urls, fmt.Sprintf("https://mc-heads.net/body/%s/320.png", ign))
	}
	urls = append(urls, "https://mc-heads.net/body/MHF_Steve/320.png")

	for _, u := range urls {
		img, err := fetchPNG(ctx, u)
		if err == nil && img != nil {
			if encoded, encErr := encodeImageBase64(img); encErr == nil {
				return img, encoded
			}
			return img, ""
		}
	}
	return nil, ""
}

func decodeBase64Image(data string) (image.Image, error) {
	raw, err := base64.StdEncoding.DecodeString(strings.TrimSpace(data))
	if err != nil {
		return nil, err
	}
	return png.Decode(bytes.NewReader(raw))
}

func encodeImageBase64(img image.Image) (string, error) {
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(buf.Bytes()), nil
}

func openFile(path string) (*os.File, error) {
	return os.Open(path)
}
