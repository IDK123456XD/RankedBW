package party

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

const InviteTTL = 5 * time.Minute
const idlePartyTTL = 2 * time.Hour

type Service struct {
	now func() time.Time
}

func NewService() *Service {
	return &Service{
		now: time.Now,
	}
}

// StartMaintenance disbands idle parties every 5 minutes.
func (s *Service) StartMaintenance(sess *discordgo.Session, guildID string) {
	if sess == nil {
		return
	}
	log.Printf("party: starting idle cleanup loop")
	go s.cleanupIdleParties(sess, guildID)
	go func() {
		ticker := time.NewTicker(5 * time.Minute)
		defer ticker.Stop()
		for range ticker.C {
			s.cleanupIdleParties(sess, guildID)
		}
	}()
}

func (s *Service) cleanupIdleParties(sess *discordgo.Session, guildID string) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	parties, err := storage.ListParties(ctx)
	if err != nil {
		log.Printf("party: failed to list parties for cleanup: %v", err)
		return
	}
	now := s.now()
	alertsChannel, _ := storage.GetAlertsChannelID(ctx)

	disbanded := 0
	for _, p := range parties {
		last := p.CreatedAt
		if p.LastVCJoin.Valid && p.LastVCJoin.Time.After(last) {
			last = p.LastVCJoin.Time
		}
		if now.Sub(last) < idlePartyTTL {
			continue
		}
		_ = storage.DeleteParty(ctx, p.ID)
		disbanded++
		if strings.TrimSpace(alertsChannel) != "" && len(p.Members) > 0 {
			var mentions []string
			for _, m := range p.Members {
				mentions = append(mentions, mentionFromID(m))
			}
			embed := &discordgo.MessageEmbed{
				Description: "Your party has been disbanded due to inactivity.",
				Color:       0xED4245,
			}
			content := strings.Join(mentions, " ")
			_, _ = sess.ChannelMessageSendComplex(alertsChannel, &discordgo.MessageSend{
				Content: content,
				Embeds:  []*discordgo.MessageEmbed{embed},
			})
		}
	}
	if disbanded > 0 {
		log.Printf("party: disbanded %d idle parties", disbanded)
	}
}

func mentionFromID(id string) string {
	id = strings.TrimSpace(id)
	if id == "" {
		return ""
	}
	return fmt.Sprintf("<@%s>", id)
}

func (s *Service) Invite(ctx context.Context, leaderID, targetID string) (*storage.Party, error) {
	if leaderID == targetID {
		return nil, errors.New("you cannot invite yourself")
	}
	if err := s.ensurePartiesEnabled(ctx); err != nil {
		return nil, err
	}

	party, err := storage.GetPartyByMember(ctx, leaderID)
	if err != nil {
		return nil, err
	}
	if party == nil {
		party, err = storage.CreateParty(ctx, leaderID)
		if err != nil {
			return nil, err
		}
	}

	if party.LeaderID != leaderID {
		return nil, errors.New("only the party leader can invite")
	}

	_, size, err := storage.GetPartySettings(ctx)
	if err != nil {
		return nil, err
	}
	if len(party.Members) >= size {
		return nil, errors.New("party is full")
	}

	if existing, err := storage.GetPartyByMember(ctx, targetID); err != nil {
		return nil, err
	} else if existing != nil {
		return nil, errors.New("that player is already in a party")
	}

	ignores, err := storage.GetPartyIgnoreList(ctx, targetID)
	if err != nil {
		return nil, err
	}
	for _, ignored := range ignores {
		if ignored == leaderID {
			return nil, errors.New("that player is not accepting your invites")
		}
	}

	now := s.now()
	party.Invites = filterInvites(party.Invites, now)
	for _, inv := range party.Invites {
		if inv.UserID == targetID {
			return nil, errors.New("that player already has an invite")
		}
	}

	party.Invites = append(party.Invites, storage.PartyInvite{
		UserID:    targetID,
		InvitedAt: now,
	})
	if err := storage.UpdateParty(ctx, party); err != nil {
		return nil, err
	}
	return party, nil
}

func (s *Service) Accept(ctx context.Context, leaderID, targetID string) (*storage.Party, error) {
	party, err := storage.GetPartyByLeader(ctx, leaderID)
	if err != nil {
		return nil, err
	}
	if party == nil {
		return nil, errors.New("that player does not have a party")
	}
	now := s.now()
	party.Invites = filterInvites(party.Invites, now)

	var haveInvite bool
	for idx := range party.Invites {
		if party.Invites[idx].UserID == targetID {
			haveInvite = true
			party.Invites = append(party.Invites[:idx], party.Invites[idx+1:]...)
			break
		}
	}
	if !haveInvite {
		return nil, errors.New("you do not have an invite to that party")
	}

	if existing, err := storage.GetPartyByMember(ctx, targetID); err != nil {
		return nil, err
	} else if existing != nil {
		if err := s.Leave(ctx, targetID); err != nil {
			return nil, err
		}
	}

	_, size, err := storage.GetPartySettings(ctx)
	if err != nil {
		return nil, err
	}
	if len(party.Members) >= size {
		return nil, errors.New("that party is full")
	}

	party.Members = append(party.Members, targetID)
	if err := storage.UpdateParty(ctx, party); err != nil {
		return nil, err
	}
	return party, nil
}

func (s *Service) Decline(ctx context.Context, leaderID, targetID string) (*storage.Party, error) {
	party, err := storage.GetPartyByLeader(ctx, leaderID)
	if err != nil {
		return nil, err
	}
	if party == nil {
		return nil, errors.New("that player does not have a party")
	}

	now := s.now()
	party.Invites = filterInvites(party.Invites, now)

	var removed bool
	for idx := range party.Invites {
		if party.Invites[idx].UserID == targetID {
			party.Invites = append(party.Invites[:idx], party.Invites[idx+1:]...)
			removed = true
			break
		}
	}
	if !removed {
		return nil, errors.New("you do not have an invite to that party")
	}

	if err := storage.UpdateParty(ctx, party); err != nil {
		return nil, err
	}
	return party, nil
}

func (s *Service) Leave(ctx context.Context, userID string) error {
	party, err := storage.GetPartyByMember(ctx, userID)
	if err != nil {
		return err
	}
	if party == nil {
		return errors.New("you are not in a party")
	}

	if party.LeaderID == userID {
		if len(party.Members) == 1 {
			return storage.DeleteParty(ctx, party.ID)
		}
		party.Members = party.Members[1:]
		party.LeaderID = party.Members[0]
	} else {
		idx := indexOf(party.Members, userID)
		if idx == -1 {
			return errors.New("member not found in party")
		}
		party.Members = append(party.Members[:idx], party.Members[idx+1:]...)
	}
	return storage.UpdateParty(ctx, party)
}

func (s *Service) Disband(ctx context.Context, leaderID string) error {
	party, err := storage.GetPartyByLeader(ctx, leaderID)
	if err != nil {
		return err
	}
	if party == nil {
		return errors.New("you do not have a party")
	}
	return storage.DeleteParty(ctx, party.ID)
}

func (s *Service) DisbandAll(ctx context.Context) error {
	parties, err := storage.ListParties(ctx)
	if err != nil {
		return err
	}
	for _, p := range parties {
		if err := storage.DeleteParty(ctx, p.ID); err != nil {
			return err
		}
	}
	return nil
}

func (s *Service) Promote(ctx context.Context, leaderID, targetID string) error {
	party, err := storage.GetPartyByLeader(ctx, leaderID)
	if err != nil {
		return err
	}
	if party == nil {
		return errors.New("you do not have a party")
	}
	idx := indexOf(party.Members, targetID)
	if idx <= 0 {
		return errors.New("that player is not in your party")
	}
	party.Members[0], party.Members[idx] = party.Members[idx], party.Members[0]
	party.LeaderID = party.Members[0]
	return storage.UpdateParty(ctx, party)
}

func (s *Service) Kick(ctx context.Context, leaderID, targetID string) error {
	party, err := storage.GetPartyByLeader(ctx, leaderID)
	if err != nil {
		return err
	}
	if party == nil {
		return errors.New("only the party leader can kick members")
	}
	idx := indexOf(party.Members, targetID)
	if idx == -1 || idx == 0 {
		return errors.New("that user is not in your party")
	}
	party.Members = append(party.Members[:idx], party.Members[idx+1:]...)
	return storage.UpdateParty(ctx, party)
}

func (s *Service) ToggleAutoWarp(ctx context.Context, leaderID string, enabled bool) (*storage.Party, error) {
	party, err := storage.GetPartyByLeader(ctx, leaderID)
	if err != nil {
		return nil, err
	}
	if party == nil {
		return nil, errors.New("you do not have a party")
	}
	party.AutoWarp = enabled
	if err := storage.UpdateParty(ctx, party); err != nil {
		return nil, err
	}
	return party, nil
}

func (s *Service) Ignore(ctx context.Context, userID, targetID string, add bool) error {
	if userID == targetID {
		return errors.New("you cannot ignore yourself")
	}
	entries, err := storage.GetPartyIgnoreList(ctx, userID)
	if err != nil {
		return err
	}
	if add {
		if !contains(entries, targetID) {
			entries = append(entries, targetID)
		}
	} else {
		entries = remove(entries, targetID)
	}
	return storage.SetPartyIgnoreList(ctx, userID, entries)
}

func (s *Service) WarpTargets(ctx context.Context, leaderID string) ([]string, error) {
	party, err := storage.GetPartyByLeader(ctx, leaderID)
	if err != nil {
		return nil, err
	}
	if party == nil {
		return nil, errors.New("you do not have a party")
	}
	return party.Members[1:], nil
}

func filterInvites(invites []storage.PartyInvite, now time.Time) []storage.PartyInvite {
	var filtered []storage.PartyInvite
	for _, inv := range invites {
		if now.Sub(inv.InvitedAt) <= InviteTTL {
			filtered = append(filtered, inv)
		}
	}
	return filtered
}

func indexOf(list []string, value string) int {
	for idx, v := range list {
		if v == value {
			return idx
		}
	}
	return -1
}

func contains(list []string, value string) bool {
	return indexOf(list, value) != -1
}

func remove(list []string, value string) []string {
	idx := indexOf(list, value)
	if idx == -1 {
		return list
	}
	return append(list[:idx], list[idx+1:]...)
}

func (s *Service) ensurePartiesEnabled(ctx context.Context) error {
	enabled, _, err := storage.GetPartySettings(ctx)
	if err != nil {
		return err
	}
	if !enabled {
		return errors.New("parties are disabled")
	}
	return nil
}

func (s *Service) ActiveInvites(p *storage.Party) []storage.PartyInvite {
	if p == nil {
		return nil
	}
	return filterInvites(p.Invites, s.now())
}
