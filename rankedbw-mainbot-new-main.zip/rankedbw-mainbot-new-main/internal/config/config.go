package config

import (
	"log"
	"os"
	"strconv"
	"strings"
)

type Config struct {
	Token             string // Bot token: "Bot <token>" not required; discordgo expects raw token
	AppID             string // Application (client) ID
	GuildID           string // Guild ID to register commands and operate in
	QueueLogChannelID string
	ScoringChannelID  string
	TeamCategoryID    string
	QueueConfigs      []QueueConfig
	LogVerbose        bool
}

type QueueConfig struct {
	ChannelID string
	Mode      string
	Capacity  int
	MinElo    int
	MaxElo    int
	Roles     []string
}

func FromEnv() Config {
	guildID := strings.TrimSpace(os.Getenv("DISCORD_GUILD_ID"))
	c := Config{
		Token:             os.Getenv("DISCORD_BOT_TOKEN"),
		AppID:             os.Getenv("DISCORD_APP_ID"),
		GuildID:           guildID,
		QueueLogChannelID: strings.TrimSpace(os.Getenv("queueLogChannelId")),
		ScoringChannelID:  strings.TrimSpace(os.Getenv("SCORING_CHANNEL_ID")),
		TeamCategoryID:    strings.TrimSpace(os.Getenv("TEAMS_VC_CATEGORY_ID")),
		LogVerbose:        os.Getenv("LOG_VERBOSE") == "1",
	}
	c.QueueConfigs = parseQueueConfigs(os.Getenv("QUEUE_CONFIGS"))
	if c.Token == "" || c.AppID == "" || c.GuildID == "" {
		log.Fatal("Missing env: DISCORD_BOT_TOKEN, DISCORD_APP_ID, DISCORD_GUILD_ID")
	}
	return c
}

func parseQueueConfigs(raw string) []QueueConfig {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	var configs []QueueConfig
	for _, entry := range strings.Split(raw, ",") {
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		// Format: channelID:min:max:capacity:mode[:role1|role2|...]
		parts := strings.Split(entry, ":")
		if len(parts) < 5 {
			continue
		}
		minElo, errMin := strconv.Atoi(strings.TrimSpace(parts[1]))
		maxElo, errMax := strconv.Atoi(strings.TrimSpace(parts[2]))
		capacity, errCap := strconv.Atoi(strings.TrimSpace(parts[3]))
		if errMin != nil || errMax != nil || errCap != nil {
			continue
		}
		cfg := QueueConfig{
			ChannelID: strings.TrimSpace(parts[0]),
			MinElo:    minElo,
			MaxElo:    maxElo,
			Capacity:  capacity,
			Mode:      strings.TrimSpace(parts[4]),
		}
		if len(parts) > 5 {
			cfg.Roles = parseIDList(strings.ReplaceAll(parts[5], "|", ","))
		}
		configs = append(configs, cfg)
	}
	return configs
}

func parseIDList(raw string) []string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	parts := strings.Split(raw, ",")
	var ids []string
	for _, part := range parts {
		id := strings.TrimSpace(part)
		if id != "" {
			ids = append(ids, id)
		}
	}
	return ids
}
