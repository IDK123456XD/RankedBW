package queue

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"math"
	"math/rand"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"rbw-bot/internal/discordutil"
	"rbw-bot/internal/maps"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Config struct {
	ChannelID string
	MinElo    int
	MaxElo    int
	Setup     string
}

const gameCategoryBaseName = "[TEAM CALLS]"
const scoreSubmitButtonPrefix = "score_submit_btn:"
const pickingSelectPrefix = "picking_select:"
const queueAPIDelay = 50 * time.Millisecond
const voiceAllowMask = int64(discordgo.PermissionVoiceConnect | discordgo.PermissionVoiceSpeak)
const pickingTimeout = 10 * time.Minute

var pickingOrder = []int{1, 2, 2, 1, 1}

type Entry struct {
	UserID   string
	PlayerID string
	Username string
	Elo      int
	JoinedAt time.Time
	GuildID  string
}

type State struct {
	Config     Config
	Entries    []Entry
	Processing bool
}

type Snapshot struct {
	ChannelID string
	Config    Config
	Entries   []Entry
}

type Store interface {
	WithLock(channelID string, fn func(*State) error) error
}

type memoryStore struct {
	mu      sync.Mutex
	states  map[string]*State
	configs map[string]Config
}

func newMemoryStore(cfgs map[string]Config) Store {
	states := make(map[string]*State, len(cfgs))
	for id, cfg := range cfgs {
		states[id] = &State{Config: cfg}
	}
	return &memoryStore{
		states:  states,
		configs: cfgs,
	}
}

func (m *memoryStore) WithLock(channelID string, fn func(*State) error) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	state, ok := m.states[channelID]
	if !ok {
		if cfg, exists := m.configs[channelID]; exists {
			state = &State{Config: cfg}
			m.states[channelID] = state
		} else {
			return nil
		}
	}
	return fn(state)
}

type Service struct {
	store           Store
	configs         map[string]Config
	logChannelID    string
	threadChannelID string
	teamCategoryID  string
	waitingRoomID   string
	membership      sync.Map // userID -> channelID
	capacity        int
	teamSize        int
	gameStyle       string
	randMu          sync.Mutex
	rng             *rand.Rand
	silentLeaves    sync.Map
	categoryMu      sync.Mutex
	noticeMu        sync.Mutex
	noticeTimes     map[string]time.Time
	teamMu          sync.Mutex
	teamChannels    map[string]time.Time // channelID -> last seen empty (zero if occupied)
	voiceTableOnce  sync.Once
	threadTableOnce sync.Once
	threadSyncOnce  sync.Once
	pickingMu       sync.Mutex
	pickingChannels map[string]string // channelID -> sessionID
}

func NewService(logChannelID, teamCategoryID string) *Service {
	resolvedLog := loadSettingOrEnv("QUEUE_LOG_CHANNEL_ID")
	log.Printf("queue: init queue log channel (settings/env)=%q", strings.TrimSpace(resolvedLog))
	if strings.TrimSpace(resolvedLog) == "" {
		resolvedLog = strings.TrimSpace(logChannelID)
	}

	resolvedThread := loadSettingOrEnv("QUEUE_THREAD_CHANNEL_ID")

	return &Service{
		store:           newMemoryStore(make(map[string]Config)),
		configs:         make(map[string]Config),
		logChannelID:    strings.TrimSpace(resolvedLog),
		threadChannelID: strings.TrimSpace(resolvedThread),
		teamCategoryID:  strings.TrimSpace(teamCategoryID),
		waitingRoomID:   loadSettingOrEnv("WAITING_ROOM_VC_ID"),
		capacity:        8,
		teamSize:        4,
		rng:             rand.New(rand.NewSource(time.Now().UnixNano())),
		noticeTimes:     make(map[string]time.Time),
		teamChannels:    make(map[string]time.Time),
		pickingChannels: make(map[string]string),
	}
}

// StartMaintenance launches background cleanup of team voice channels and stale threads.
func (s *Service) StartMaintenance(sess *discordgo.Session, guildID string) {
	if s == nil || sess == nil || strings.TrimSpace(guildID) == "" {
		return
	}
	s.ensureVoiceChannelsTable()
	// Recover queue membership for users already sitting in queue VCs on startup.
	go s.recoverQueueMembership(sess, guildID)
	go s.voiceChannelWatcher(sess, guildID)
	go s.autoClosePendingGamesWatcher(sess, guildID)
	go s.resumePickingSessions(sess, guildID)
	go s.pickingCleanupWatcher(sess, guildID)

	go func() {
		ticker := time.NewTicker(1 * time.Minute)
		defer ticker.Stop()
		for range ticker.C {
			s.cleanupTeamChannels(sess, guildID)
			s.cleanupOldThreads(sess)
		}
	}()
	s.cleanupOldThreads(sess)
}

// recoverQueueMembership scans current voice states and re-adds users already sitting in queue channels.
// This is used at startup so queue counts/logs reflect the real state after a restart.
func (s *Service) recoverQueueMembership(sess *discordgo.Session, guildID string) {
	recoverOnce := func() int {
		guild, err := sess.State.Guild(guildID)
		if err != nil || guild == nil {
			guild, err = sess.Guild(guildID)
		}
		if err != nil || guild == nil {
			log.Printf("queue: recover failed to load guild %s: %v", guildID, err)
			return 0
		}

		count := 0
		for _, vs := range guild.VoiceStates {
			channelID := strings.TrimSpace(vs.ChannelID)
			if channelID == "" {
				continue
			}
			if _, ok := s.configs[channelID]; !ok {
				continue
			}
			// Reuse existing voice handler to apply eligibility checks and log joins.
			vsCopy := vs
			s.HandleVoiceStateUpdate(sess, &discordgo.VoiceStateUpdate{VoiceState: vsCopy})
			count++
		}
		return count
	}

	// Try immediately; if nothing found, retry shortly to allow caches to warm up after startup.
	if n := recoverOnce(); n == 0 {
		time.Sleep(3 * time.Second)
		_ = recoverOnce()
	}
}

func (s *Service) ensureVoiceChannelsTable() {
	if s == nil {
		return
	}
	s.voiceTableOnce.Do(func() {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		if err := storage.EnsureVoiceChannelsTable(ctx); err != nil {
			log.Printf("queue: voicechannels table init failed: %v", err)
		}
		cancel()
	})
}

func (s *Service) ensureQueueThreadsTable() {
	if s == nil {
		return
	}
	s.threadTableOnce.Do(func() {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		if err := storage.EnsureQueueThreadsTable(ctx); err != nil {
			log.Printf("queue: queue threads table init failed: %v", err)
		}
		cancel()
	})
}

func (s *Service) voiceChannelWatcher(sess *discordgo.Session, guildID string) {
	s.ensureVoiceChannelsTable()

	runOnce := func() {
		log.Printf("queue: voice watcher tick for guild %s", guildID)
		guild, err := sess.State.Guild(guildID)
		if err != nil || guild == nil {
			guild, err = sess.Guild(guildID)
		}
		if err != nil || guild == nil {
			log.Printf("queue: voice watcher failed to load guild %s: %v", guildID, err)
			return
		}
		channels, err := sess.GuildChannels(guildID)
		if err != nil {
			log.Printf("queue: voice watcher failed to list channels: %v", err)
			return
		}
		channelIDs := make(map[string]struct{}, len(channels))
		for _, ch := range channels {
			if ch != nil && strings.TrimSpace(ch.ID) != "" {
				channelIDs[strings.TrimSpace(ch.ID)] = struct{}{}
			}
		}
		categoryNames := make(map[string]string, len(channels))
		for _, ch := range channels {
			if ch != nil && ch.Type == discordgo.ChannelTypeGuildCategory {
				categoryNames[ch.ID] = strings.TrimSpace(ch.Name)
			}
		}

		occupied := make(map[string]struct{})
		for _, vs := range guild.VoiceStates {
			if strings.TrimSpace(vs.ChannelID) != "" {
				occupied[vs.ChannelID] = struct{}{}
			}
		}

		now := time.Now().UTC()
		for _, ch := range channels {
			if ch == nil {
				continue
			}
			if ch.Type != discordgo.ChannelTypeGuildVoice && ch.Type != discordgo.ChannelTypeGuildStageVoice {
				continue
			}
			parentName := strings.TrimSpace(categoryNames[ch.ParentID])
			if !strings.Contains(strings.ToUpper(parentName), "TEAM CALLS") {
				continue
			}
			if _, ok := occupied[ch.ID]; ok {
				log.Printf("queue: voice watcher %s occupied; updating last_joined", ch.Name)
				lastJoined := now
				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				if err := storage.UpsertVoiceChannel(ctx, ch.ID, ch.Name, createdAtForChannel(ch, now), &lastJoined); err != nil {
					log.Printf("queue: voice watcher failed to upsert %s: %v", ch.Name, err)
				}
				cancel()
				continue
			}
			chCreated := createdAtForChannel(ch, now)
			age := now.Sub(chCreated)
			log.Printf("queue: voice watcher %s empty; created_at_age=%s", ch.Name, age)
			if now.Sub(chCreated) >= 10*time.Minute {
				if s.voiceChannelIdleOver(sess, ch.ID, ch.Name, chCreated, now) {
					continue
				}
			}
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			if err := storage.UpsertVoiceChannel(ctx, ch.ID, ch.Name, chCreated, nil); err != nil {
				log.Printf("queue: voice watcher failed to upsert %s: %v", ch.Name, err)
			}
			cancel()
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		ids, err := storage.ListVoiceChannelIDs(ctx)
		cancel()
		if err != nil {
			log.Printf("queue: voice watcher failed to list stored channels: %v", err)
			return
		}
		for _, id := range ids {
			if _, ok := channelIDs[id]; ok {
				continue
			}
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			if err := storage.DeleteVoiceChannel(ctx, id); err != nil {
				log.Printf("queue: voice watcher failed to purge %s: %v", id, err)
			}
			cancel()
		}
	}

	runOnce()
	ticker := time.NewTicker(2 * time.Minute)
	defer ticker.Stop()
	for range ticker.C {
		runOnce()
	}
}

func createdAtForChannel(ch *discordgo.Channel, fallback time.Time) time.Time {
	if ch == nil {
		return fallback
	}
	if ts, err := discordgo.SnowflakeTimestamp(ch.ID); err == nil {
		return ts.UTC()
	}
	return fallback
}

func (s *Service) voiceChannelIdleOver(sess *discordgo.Session, channelID, channelName string, createdAt, now time.Time) bool {
	if s == nil {
		return false
	}
	if now.Sub(createdAt) < 10*time.Minute {
		return false
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	lastJoined, err := storage.GetVoiceChannelLastJoined(ctx, channelID)
	if err != nil {
		log.Printf("queue: voice watcher failed to read last_joined for %s: %v", channelName, err)
		cancel()
		return false
	}
	cancel()
	if lastJoined != nil && now.Sub(*lastJoined) < 10*time.Minute {
		log.Printf("queue: voice watcher skip delete %s (%s): last_joined=%s", channelName, channelID, lastJoined.UTC().Format(time.RFC3339))
		return false
	}
	log.Printf("queue: voice watcher deleting channel %s (%s): created_at=%s last_joined=%v", channelName, channelID, createdAt.UTC().Format(time.RFC3339), lastJoined)
	ctx, cancel = context.WithTimeout(context.Background(), 5*time.Second)
	if err := storage.DeleteVoiceChannel(ctx, channelID); err != nil {
		log.Printf("queue: voice watcher failed to delete %s: %v", channelName, err)
	}
	cancel()
	if sess != nil {
		if _, err := sess.ChannelDelete(channelID); err != nil {
			log.Printf("queue: voice watcher failed to delete channel %s (%s): %v", channelName, channelID, err)
		}
	}
	return true
}

func (s *Service) updateVoiceChannelJoin(sess *discordgo.Session, guildID, channelID string) {
	if s == nil || sess == nil || strings.TrimSpace(channelID) == "" || strings.TrimSpace(guildID) == "" {
		return
	}
	ch, err := sess.State.Channel(channelID)
	if err != nil || ch == nil {
		ch, err = sess.Channel(channelID)
	}
	if err != nil || ch == nil {
		return
	}
	if ch.Type != discordgo.ChannelTypeGuildVoice && ch.Type != discordgo.ChannelTypeGuildStageVoice {
		return
	}
	if !s.isTeamCallsChannel(sess, ch.ParentID) {
		return
	}
	s.ensureVoiceChannelsTable()
	createdAt := time.Now().UTC()
	if ts, err := discordgo.SnowflakeTimestamp(ch.ID); err == nil {
		createdAt = ts.UTC()
	}
	now := time.Now().UTC()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	if err := storage.UpsertVoiceChannel(ctx, ch.ID, ch.Name, createdAt, &now); err != nil {
		log.Printf("queue: voice join upsert failed for %s: %v", ch.Name, err)
	}
	cancel()
}

func (s *Service) isTeamCallsChannel(sess *discordgo.Session, parentID string) bool {
	parentID = strings.TrimSpace(parentID)
	if parentID == "" || sess == nil {
		return false
	}
	parent, err := sess.State.Channel(parentID)
	if err != nil || parent == nil {
		parent, err = sess.Channel(parentID)
	}
	if err != nil || parent == nil {
		return false
	}
	return strings.Contains(strings.ToUpper(strings.TrimSpace(parent.Name)), "TEAM CALLS")
}

func (s *Service) ReloadConfigs(ctx context.Context) error {
	configs, err := storage.ListQueueConfigs(ctx)
	if err != nil {
		return err
	}
	cfgMap := make(map[string]Config, len(configs))
	for _, cfg := range configs {
		if strings.TrimSpace(cfg.ChannelID) == "" {
			continue
		}
		cfgMap[cfg.ChannelID] = Config{
			ChannelID: cfg.ChannelID,
			MinElo:    cfg.MinElo,
			MaxElo:    cfg.MaxElo,
			Setup:     strings.TrimSpace(cfg.Setup),
		}
	}
	s.configs = cfgMap
	s.store = newMemoryStore(cfgMap)

	style, err := storage.GetGameStyle(ctx)
	if err != nil {
		log.Printf("queue: failed to load game style: %v", err)
	}
	s.gameStyle = style
	if cap := deriveCapacity(style); cap > 0 {
		s.capacity = cap
	} else {
		s.capacity = 8
	}
	if s.capacity < 2 {
		s.capacity = 2
	}
	s.teamSize = s.capacity / 2
	if s.teamSize == 0 {
		s.teamSize = 1
	}
	return nil
}

func (s *Service) Capacity() int {
	if s == nil {
		return 0
	}
	return s.capacity
}

// UpdateLogChannel sets the log channel ID for queue events.
func (s *Service) UpdateLogChannel(id string) {
	if s == nil {
		return
	}
	s.logChannelID = strings.TrimSpace(id)
}

// UpdateThreadChannel sets the parent channel for queue threads.
func (s *Service) UpdateThreadChannel(id string) {
	if s == nil {
		return
	}
	s.threadChannelID = strings.TrimSpace(id)
}

func (s *Service) HandleVoiceStateUpdate(sess *discordgo.Session, vs *discordgo.VoiceStateUpdate) {
	if s == nil || vs == nil {
		return
	}
	userID := vs.UserID
	if userID == "" {
		return
	}
	currentChannel := vs.ChannelID
	var previous string
	if val, ok := s.membership.Load(userID); ok {
		previous, _ = val.(string)
	}
	if previous != "" && previous != currentChannel {
		removed, count := s.removeFromQueue(previous, userID)
		s.membership.Delete(userID)
		if removed != nil && !s.consumeSilentLeave(userID) {
			if cfgPrev, ok := s.configs[previous]; ok {
				s.logLeave(sess, cfgPrev, userID, count)
			}
		}
	}
	if currentChannel == "" {
		return
	}
	if vs.GuildID != "" {
		s.updateVoiceChannelJoin(sess, vs.GuildID, currentChannel)
	}
	if s.isPickingChannel(currentChannel) {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_ = s.removePartyForPicking(ctx, userID)
		cancel()
		return
	}
	cfg, ok := s.configs[currentChannel]
	if !ok {
		return
	}
	if previous == currentChannel {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	member, err := sess.GuildMember(vs.GuildID, userID)
	if err != nil {
		log.Printf("queue: failed to fetch member %s: %v", userID, err)
		s.queueSkip(sess, cfg, "skip:member:"+userID, fmt.Sprintf("<@%s> not queued: unable to load member.", userID))
		return
	}

	var player *storage.PlayerRecord
	var playerErr error
	for attempt := 1; attempt <= 5; attempt++ {
		player, playerErr = storage.GetPlayerByUserID(ctx, userID)
		if playerErr == nil {
			break
		}
		log.Printf("queue: player lookup failed for %s (attempt %d): %v", userID, attempt, playerErr)
		time.Sleep(200 * time.Millisecond)
	}
	if playerErr != nil {
		log.Printf("queue: player lookup failed for %s: %v", userID, playerErr)
		s.queueSkip(sess, cfg, "skip:playerlookup:"+userID, fmt.Sprintf("<@%s> not queued: player lookup failed.", userID))
		return
	}
	if player == nil {
		log.Printf("queue: %s is not registered", userID)
		s.queueSkip(sess, cfg, "skip:notregistered:"+userID, fmt.Sprintf("<@%s> not queued: not registered.", userID))
		return
	}

	ban, err := storage.ActiveRankedBanForPlayer(ctx, player.ID)
	if err != nil {
		log.Printf("queue: ranked ban lookup failed for %s: %v", userID, err)
		s.queueSkip(sess, cfg, "skip:banlookup:"+userID, fmt.Sprintf("<@%s> not queued: ban lookup failed.", userID))
		return
	}
	if ban != nil {
		s.queueSkip(sess, cfg, "skip:banned:"+userID, fmt.Sprintf("<@%s> not queued: ranked banned.", userID))
		s.queueRankedBanAlert(ctx, sess, userID)
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		log.Printf("queue: failed to get active season: %v", err)
		s.queueSkip(sess, cfg, "skip:noseason:"+userID, fmt.Sprintf("<@%s> not queued: no active season.", userID))
		return
	}
	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil {
		log.Printf("queue: failed to load stats for %s: %v", userID, err)
		s.queueSkip(sess, cfg, "skip:statserr:"+userID, fmt.Sprintf("<@%s> not queued: failed to load season stats.", userID))
		return
	}
	if stats == nil {
		log.Printf("queue: %s has no season stats", userID)
		s.queueSkip(sess, cfg, "skip:nostats:"+userID, fmt.Sprintf("<@%s> not queued: no season stats. Play a game first.", userID))
		return
	}
	if stats.Elo < cfg.MinElo || stats.Elo > cfg.MaxElo {
		s.queueSkip(sess, cfg, "skip:elorange:"+userID, fmt.Sprintf("<@%s> not queued: elo %d outside range %d-%d.", userID, stats.Elo, cfg.MinElo, cfg.MaxElo))
		return
	}

	party, err := storage.GetPartyByMember(ctx, userID)
	if err != nil {
		log.Printf("queue: failed to fetch party for %s: %v", userID, err)
		s.queueSkip(sess, cfg, "skip:partylookup:"+userID, fmt.Sprintf("<@%s> not queued: party lookup failed.", userID))
		return
	}
	if party != nil {
		now := time.Now().UTC()
		// Disband stale parties: older than 24h or idle >1h without queuing.
		expired := false
		if now.Sub(party.CreatedAt) > 24*time.Hour {
			expired = true
		} else if !party.LastVCJoin.Valid && now.Sub(party.CreatedAt) > time.Hour {
			expired = true
		} else if party.LastVCJoin.Valid && now.Sub(party.LastVCJoin.Time) > time.Hour {
			expired = true
		}
		if expired {
			if err := storage.DeleteParty(ctx, party.ID); err != nil {
				log.Printf("queue: failed to disband stale party %s: %v", party.ID, err)
			} else if s.logChannelID != "" {
				if s.allowNotice("disband:"+party.ID, 5*time.Minute) {
					_, _ = sess.ChannelMessageSend(s.logChannelID, fmt.Sprintf("Disbanded stale party led by <@%s>.", party.LeaderID))
				}
			}
			party = nil
		} else {
			_ = storage.UpdatePartyLastVC(ctx, party.ID, now)
		}
	}
	if party != nil && s.teamSize > 0 && len(party.Members) > s.teamSize {
		s.notifyPartyTooLarge(sess, cfg, member.User, len(party.Members))
		if s.logChannelID != "" {
			if s.allowNotice("partytooLarge:"+party.ID, time.Minute) {
				_, _ = sess.ChannelMessageSend(s.logChannelID, fmt.Sprintf("<@%s> could not queue in <#%s> because their party has %d members (max %d).", userID, currentChannel, len(party.Members), s.teamSize))
			}
		}
		return
	}

	entry := Entry{
		UserID:   userID,
		PlayerID: player.ID,
		Username: member.User.Username,
		Elo:      stats.Elo,
		JoinedAt: time.Now().UTC(),
		GuildID:  vs.GuildID,
	}

	count, shouldStart, err := s.addEntry(cfg.ChannelID, entry)
	if err != nil {
		log.Printf("queue: add entry failed: %v", err)
		return
	}
	s.membership.Store(userID, cfg.ChannelID)
	s.logEvent(sess, cfg, member.User, count)
	if shouldStart {
		go s.processQueueChannel(sess, vs.GuildID, cfg.ChannelID)
	}
}

func (s *Service) addEntry(channelID string, entry Entry) (int, bool, error) {
	count := 0
	shouldStart := false
	err := s.store.WithLock(channelID, func(state *State) error {
		if state == nil {
			return nil
		}
		for idx, existing := range state.Entries {
			if existing.UserID == entry.UserID {
				state.Entries[idx] = entry
				count = len(state.Entries)
				return nil
			}
		}
		state.Entries = append(state.Entries, entry)
		count = len(state.Entries)
		if !state.Processing && s.capacity > 0 && len(state.Entries) >= s.capacity {
			state.Processing = true
			shouldStart = true
		}
		return nil
	})
	return count, shouldStart, err
}

func (s *Service) removeFromQueue(channelID, userID string) (*Entry, int) {
	var removed *Entry
	count := 0
	_ = s.store.WithLock(channelID, func(state *State) error {
		if state == nil || len(state.Entries) == 0 {
			return nil
		}
		for idx, entry := range state.Entries {
			if entry.UserID == userID {
				entryCopy := entry
				removed = &entryCopy
				state.Entries = append(state.Entries[:idx], state.Entries[idx+1:]...)
				break
			}
		}
		count = len(state.Entries)
		return nil
	})
	return removed, count
}

func (s *Service) processQueueChannel(sess *discordgo.Session, guildID, channelID string) {

	if s.teamSize <= 0 || s.capacity <= 0 {
		log.Printf("queue: invalid team size/capacity, skipping match")
		// time.Sleep(queueAPIDelay)
		_ = s.resetProcessing(channelID)
		return
	}
	if strings.TrimSpace(s.logChannelID) == "" {
		// Lazy refresh in case settings/env were populated after startup or initial lookup failed.
		if refreshed := strings.TrimSpace(loadSettingOrEnv("QUEUE_LOG_CHANNEL_ID")); refreshed != "" {
			s.logChannelID = refreshed
		}
		if strings.TrimSpace(s.logChannelID) == "" {
			ctxLog, cancelLog := context.WithTimeout(context.Background(), 3*time.Second)
			if fromDB, err := storage.GetQueueLogChannelID(ctxLog); err == nil && strings.TrimSpace(fromDB) != "" {
				s.logChannelID = strings.TrimSpace(fromDB)
			} else if err != nil {
				log.Printf("queue: failed to load queue log channel id: %v", err)
			}
			cancelLog()
		}
	}
	if strings.TrimSpace(s.logChannelID) == "" {
		log.Printf("queue: log channel not configured, cannot start games")
		// time.Sleep(queueAPIDelay)
		_ = s.resetProcessing(channelID)
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	started := time.Now()
	stepStart := started
	log.Printf("queue: process start channel=%s guild=%s", channelID, guildID)

	stateEntries, cfg := s.snapshotEntries(channelID)
	if len(stateEntries) < s.capacity {
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}

	activeEntries, removed := s.filterDisconnected(sess, guildID, channelID, stateEntries)
	if len(removed) > 0 {
		log.Printf("queue: removed %d disconnected entries before selection: %v", len(removed), mapKeys(removed))
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, removed)
		return
	}
	if len(activeEntries) < s.capacity {
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}

	activeEntries, missingPlayers, err := s.refreshPlayerRecords(ctx, activeEntries)
	if err != nil {
		log.Printf("queue: failed to refresh players: %v", err)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=refresh_players dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()
	if len(missingPlayers) > 0 {
		log.Printf("queue: skipping queue because %d players disappeared from DB (%v)", len(missingPlayers), mapKeys(missingPlayers))
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, missingPlayers)
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		log.Printf("queue: failed to load season id: %v", err)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}

	activeEntries, removedByElo, err := s.refreshEntryElos(ctx, activeEntries, seasonID, cfg)
	if err != nil {
		log.Printf("queue: failed to refresh entry elos: %v", err)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=refresh_elos dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()
	if len(removedByElo) > 0 {
		log.Printf("queue: removed %d entries due to elo/range changes: %v", len(removedByElo), mapKeys(removedByElo))
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, removedByElo)
		return
	}
	if len(activeEntries) < s.capacity {
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}

	groups, err := s.groupEntries(sess, ctx, activeEntries)
	if err != nil {
		log.Printf("queue: grouping failed: %v", err)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	if s.capacity > 0 {
		sizes := make([]int, len(groups))
		total := 0
		for idx, g := range groups {
			sizes[idx] = g.Size
			total += g.Size
		}
		if s.allowNotice("select:"+channelID, time.Minute) {
			s.queueLog(sess, "selecting groups for channel %s capacity=%d groups=%v total=%d", channelID, s.capacity, sizes, total)
		}
		if total < s.capacity {
			if s.allowNotice("selectInsufficient:"+channelID, time.Minute) {
				s.queueLog(sess, "insufficient eligible seats after filtering (%d/%d); waiting for more players", total, s.capacity)
			}
			// time.Sleep(queueAPIDelay)
			s.finishProcessing(sess, guildID, channelID, nil)
			return
		}
	}
	selectedGroups, err := s.selectGroups(groups)
	if err != nil {
		log.Printf("queue: selection failed: %v", err)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=select_groups dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()
	if strings.EqualFold(cfg.Setup, "picking") {
		selectedEntries := flattenGroups(selectedGroups)
		if err := s.startPickingSession(ctx, sess, guildID, channelID, cfg, selectedEntries, seasonID); err != nil {
			log.Printf("queue: picking session failed: %v", err)
			s.finishProcessing(sess, guildID, channelID, nil)
			return
		}
		removed := make(map[string]struct{}, len(selectedEntries))
		for _, entry := range selectedEntries {
			removed[entry.UserID] = struct{}{}
		}
		s.finishProcessing(sess, guildID, channelID, removed)
		return
	}
	team1, team2, err := splitTeams(selectedGroups, s.teamSize)
	if err != nil {
		log.Printf("queue: failed to split teams: %v", err)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=split_teams dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()

	gameCode, err := storage.GenerateGameCode(ctx, seasonID)
	if err != nil {
		log.Printf("queue: failed to generate game code: %v", err)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	mapChoice, err := maps.RandomForStyle(ctx, s.gameStyle)
	if err != nil {
		log.Printf("queue: failed to choose map: %v", err)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=choose_map dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()

	team1Voice, team2Voice, createdChannels, err := s.createTeamChannels(sess, guildID, channelID, gameCode, team1, team2)
	if err != nil {
		log.Printf("queue: failed to create team voice channels: %v", err)
		s.queueLog(sess, "failed to create team voice channels for game %s: %v", gameCode, err)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=create_team_vcs dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()

	threadID, err := s.createGameThread(sess, gameCode)
	if err != nil {
		log.Printf("queue: failed to create game thread: %v", err)
		s.queueLog(sess, "failed to create game thread for game %s: %v", gameCode, err)
		// time.Sleep(queueAPIDelay)
		s.cleanupChannels(sess, guildID, createdChannels)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=create_thread dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()

	if err := s.movePlayers(sess, guildID, team1Voice, team1); err != nil {
		log.Printf("queue: failed to move team 1: %v", err)
		s.queueLog(sess, "failed to move team 1 for game %s: %v", gameCode, err)
		// time.Sleep(queueAPIDelay)
		s.movePlayersToChannel(sess, guildID, channelID, team1)
		// time.Sleep(queueAPIDelay)
		s.deleteThread(sess, threadID)
		// time.Sleep(queueAPIDelay)
		s.cleanupChannels(sess, guildID, createdChannels)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=move_team1 dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()
	if err := s.movePlayers(sess, guildID, team2Voice, team2); err != nil {
		log.Printf("queue: failed to move team 2: %v", err)
		s.queueLog(sess, "failed to move team 2 for game %s: %v", gameCode, err)
		// time.Sleep(queueAPIDelay)
		s.movePlayersToChannel(sess, guildID, channelID, team1)
		// time.Sleep(queueAPIDelay)
		s.movePlayersToChannel(sess, guildID, channelID, team2)
		// time.Sleep(queueAPIDelay)
		s.deleteThread(sess, threadID)
		// time.Sleep(queueAPIDelay)
		s.cleanupChannels(sess, guildID, createdChannels)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=move_team2 dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()

	assignments := make([]storage.GameCreatePlayer, 0, len(team1)+len(team2))
	for _, e := range team1 {
		assignments = append(assignments, storage.GameCreatePlayer{
			PlayerID:    e.PlayerID,
			DiscordID:   e.UserID,
			DiscordTeam: 1,
			PreElo:      e.Elo,
		})
	}
	for _, e := range team2 {
		assignments = append(assignments, storage.GameCreatePlayer{
			PlayerID:    e.PlayerID,
			DiscordID:   e.UserID,
			DiscordTeam: 2,
			PreElo:      e.Elo,
		})
	}

	input := storage.GameCreateInput{
		GameCode:          gameCode,
		Team1VoiceID:      team1Voice,
		Team2VoiceID:      team2Voice,
		QueueThreadID:     threadID,
		SeasonID:          seasonID,
		GameStyle:         s.gameStyle,
		MapName:           mapChoice.Name,
		PlayerAssignments: assignments,
	}
	log.Printf("queue: inserting game %s with players: %s", gameCode, formatEntryMapping(append(team1, team2...)))
	dbCtx, dbCancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer dbCancel()
	if _, err := storage.CreateGameWithPlayers(dbCtx, input); err != nil {
		log.Printf("queue: failed to create game row for %s (players: %s): %v", gameCode, formatAssignments(assignments, append(team1, team2...)), err)
		s.queueLog(sess, "failed to create game row for game %s: %v", gameCode, err)
		// time.Sleep(queueAPIDelay)
		s.movePlayersToChannel(sess, guildID, channelID, team1)
		// time.Sleep(queueAPIDelay)
		s.movePlayersToChannel(sess, guildID, channelID, team2)
		// time.Sleep(queueAPIDelay)
		s.deleteThread(sess, threadID)
		// time.Sleep(queueAPIDelay)
		s.cleanupChannels(sess, guildID, createdChannels)
		// time.Sleep(queueAPIDelay)
		s.finishProcessing(sess, guildID, channelID, nil)
		return
	}
	log.Printf("queue: timing step=create_game_row dur=%s total=%s", time.Since(stepStart), time.Since(started))
	stepStart = time.Now()
	s.upsertQueueThreadRow(ctx, threadID, gameCode)
	// time.Sleep(queueAPIDelay)
	s.sendThreadRoster(sess, threadID, gameCode, mapChoice, team1, team2, team1Voice, team2Voice)
	// time.Sleep(queueAPIDelay)
	s.announceMatch(ctx, sess, cfg, gameCode, mapChoice, team1, team2, team1Voice, team2Voice, threadID)
	log.Printf("queue: timing step=announce_game dur=%s total=%s", time.Since(stepStart), time.Since(started))

	selectedIDs := make(map[string]struct{}, len(team1)+len(team2))
	for _, entry := range append(team1, team2...) {
		selectedIDs[entry.UserID] = struct{}{}
	}
	s.finishProcessing(sess, guildID, channelID, selectedIDs)
	log.Printf("queue: process complete game=%s total=%s", gameCode, time.Since(started))
}

// HandlePickingComponent processes pick dropdown selections.
func (s *Service) HandlePickingComponent(sess *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if s == nil || sess == nil || i == nil || i.Type != discordgo.InteractionMessageComponent {
		return false
	}
	data := i.MessageComponentData()
	customID := strings.TrimSpace(data.CustomID)
	if !strings.HasPrefix(customID, pickingSelectPrefix) {
		return false
	}
	payload := strings.TrimPrefix(customID, pickingSelectPrefix)
	parts := strings.Split(payload, ":")
	if len(parts) < 1 {
		return true
	}
	sessionID := strings.TrimSpace(parts[0])
	expectedPick := -1
	if len(parts) > 1 {
		if parsed, err := strconv.Atoi(strings.TrimSpace(parts[1])); err == nil {
			expectedPick = parsed
		}
	}
	if sessionID == "" {
		respondEphemeral(sess, i, "Picking session is invalid.")
		return true
	}
	if len(data.Values) == 0 {
		respondEphemeral(sess, i, "Select a player to pick.")
		return true
	}
	pickedUserID := strings.TrimSpace(data.Values[0])
	if pickedUserID == "" {
		respondEphemeral(sess, i, "Select a valid player to pick.")
		return true
	}

	requesterID := interactionUserID(i)
	if requesterID == "" {
		respondEphemeral(sess, i, "Unable to resolve your account.")
		return true
	}
	log.Printf("picking: pick request session=%s picker=%s picked=%s expected=%d", sessionID, requesterID, pickedUserID, expectedPick)

	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredMessageUpdate,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	session, err := storage.GetPickingSession(ctx, sessionID)
	if err != nil || session == nil {
		log.Printf("picking: pick request session=%s failed to load: %v", sessionID, err)
		respondEphemeral(sess, i, "Picking session has ended.")
		return true
	}
	log.Printf("picking: pick request loaded session=%s game=%s currentPick=%d", session.ID, session.GameCode, session.PickIndex)
	if time.Now().UTC().After(session.ExpiresAt) {
		log.Printf("picking: pick request expired session=%s game=%s expiresAt=%s", session.ID, session.GameCode, session.ExpiresAt.UTC().Format(time.RFC3339))
		s.cancelPickingSession(ctx, sess, i.GuildID, session, "Picking session expired.")
		respondEphemeral(sess, i, "Picking session expired.")
		return true
	}
	if expectedPick >= 0 && session.PickIndex != expectedPick {
		log.Printf("picking: pick request stale session=%s game=%s expected=%d current=%d", session.ID, session.GameCode, expectedPick, session.PickIndex)
		respondEphemeral(sess, i, "This pick is no longer active.")
		return true
	}
	pickerID, team := s.currentPickingCaptain(*session)
	if pickerID == "" {
		log.Printf("picking: pick request no current picker session=%s game=%s", session.ID, session.GameCode)
		respondEphemeral(sess, i, "Picking is already complete.")
		return true
	}
	if requesterID != pickerID {
		log.Printf("picking: pick request unauthorized session=%s game=%s requester=%s expectedPicker=%s", session.ID, session.GameCode, requesterID, pickerID)
		respondEphemeral(sess, i, "Only the current captain can pick.")
		return true
	}

	nextIndex, err := storage.ApplyPickingSelection(ctx, session.ID, pickedUserID, session.PickIndex, team)
	if err != nil {
		log.Printf("picking: apply pick failed session=%s game=%s picker=%s picked=%s team=%d: %v", session.ID, session.GameCode, pickerID, pickedUserID, team, err)
		switch err {
		case storage.ErrPickingSessionChanged:
			respondEphemeral(sess, i, "This pick is no longer active.")
		case storage.ErrPickingPlayerUnavailable:
			respondEphemeral(sess, i, "That player is already picked.")
		default:
			respondEphemeral(sess, i, "Failed to record the pick.")
		}
		return true
	}
	log.Printf("picking: pick recorded session=%s game=%s picker=%s picked=%s team=%d nextIndex=%d", session.ID, session.GameCode, pickerID, pickedUserID, team, nextIndex)

	s.announcePick(sess, *session, pickerID, pickedUserID)
	session.PickIndex = nextIndex

	if session.PickIndex >= len(pickingOrder) {
		log.Printf("picking: picks complete session=%s game=%s auto-assigning last player", session.ID, session.GameCode)
		if err := s.autoAssignRemaining(ctx, sess, i.GuildID, session); err != nil {
			log.Printf("picking: auto-assign failed session=%s game=%s: %v", session.ID, session.GameCode, err)
			respondEphemeral(sess, i, "Picking could not complete. Session canceled.")
			return true
		}
		if err := s.sendPickingPrompt(ctx, sess, i.GuildID, *session); err != nil {
			log.Printf("picking: failed to update final prompt session=%s game=%s: %v", session.ID, session.GameCode, err)
		}
		if err := s.finalizePickingSession(ctx, sess, i.GuildID, session); err != nil {
			log.Printf("picking: finalize failed session=%s game=%s: %v", session.ID, session.GameCode, err)
			respondEphemeral(sess, i, "Failed to finalize the game.")
			return true
		}
		log.Printf("picking: finalize complete session=%s game=%s", session.ID, session.GameCode)
		return true
	}

	if err := s.sendPickingPrompt(ctx, sess, i.GuildID, *session); err != nil {
		log.Printf("queue: failed to send next pick prompt: %v", err)
	}
	return true
}

func (s *Service) snapshotEntries(channelID string) ([]Entry, Config) {
	var entries []Entry
	var cfg Config
	_ = s.store.WithLock(channelID, func(state *State) error {
		if state == nil {
			return nil
		}
		cfg = state.Config
		entries = append(entries, state.Entries...)
		return nil
	})
	return entries, cfg
}

func (s *Service) filterDisconnected(sess *discordgo.Session, guildID, channelID string, entries []Entry) ([]Entry, map[string]struct{}) {
	if sess == nil {
		return entries, nil
	}
	var active []Entry
	removed := make(map[string]struct{})
	for _, entry := range entries {
		if s.userInChannel(sess, guildID, channelID, entry.UserID) {
			active = append(active, entry)
		} else {
			removed[entry.UserID] = struct{}{}
		}
	}
	if len(removed) == 0 {
		return entries, nil
	}
	return active, removed
}

func (s *Service) refreshEntryElos(ctx context.Context, entries []Entry, seasonID string, cfg Config) ([]Entry, map[string]struct{}, error) {
	seasonID = strings.TrimSpace(seasonID)
	if seasonID == "" || len(entries) == 0 {
		return entries, nil, nil
	}
	refreshed := make([]Entry, 0, len(entries))
	removed := make(map[string]struct{})
	for _, entry := range entries {
		stats, err := storage.GetPlayerSeasonStats(ctx, entry.PlayerID, seasonID)
		if err != nil {
			return nil, nil, err
		}
		if stats == nil {
			removed[entry.UserID] = struct{}{}
			continue
		}
		entry.Elo = stats.Elo
		if entry.Elo < cfg.MinElo || entry.Elo > cfg.MaxElo {
			removed[entry.UserID] = struct{}{}
			continue
		}
		refreshed = append(refreshed, entry)
	}
	if len(removed) == 0 {
		return refreshed, nil, nil
	}
	return refreshed, removed, nil
}

func (s *Service) groupEntries(sess *discordgo.Session, ctx context.Context, entries []Entry) ([]queueGroup, error) {
	result := make([]queueGroup, 0)
	entryMap := make(map[string]Entry, len(entries))
	for _, entry := range entries {
		entryMap[entry.UserID] = entry
	}
	processed := make(map[string]struct{})

	for _, entry := range entries {
		if _, seen := processed[entry.UserID]; seen {
			continue
		}
		party, err := storage.GetPartyByMember(ctx, entry.UserID)
		if err != nil {
			return nil, err
		}
		if party == nil || len(party.Members) <= 1 {
			result = append(result, queueGroup{
				Members:   []Entry{entry},
				Size:      1,
				TotalElo:  entry.Elo,
				Effective: entry.JoinedAt,
			})
			processed[entry.UserID] = struct{}{}
			continue
		}
		var members []Entry
		var missing bool
		for _, memberID := range party.Members {
			ent, ok := entryMap[memberID]
			if !ok {
				missing = true
				break
			}
			members = append(members, ent)
		}
		if missing {
			if s.allowNotice("partyMissing:"+party.ID, time.Minute) {
				s.queueLog(sess, "party for %s missing members in queue; skipping party %v", entry.UserID, party.Members)
				s.queuePartyMissingAlert(ctx, sess, party)
			}
			for _, memberID := range party.Members {
				processed[memberID] = struct{}{}
			}
			continue
		}
		size := len(members)
		if size > s.teamSize {
			if s.allowNotice("partyTooLarge:"+party.ID, time.Minute) {
				log.Printf("queue: party too large (size %d, team size %d), skipping party %v", size, s.teamSize, party.Members)
			}
			for _, memberID := range party.Members {
				processed[memberID] = struct{}{}
			}
			continue
		}
		total := 0
		effective := members[0].JoinedAt
		for _, m := range members {
			total += m.Elo
			if m.JoinedAt.Before(effective) {
				effective = m.JoinedAt
			}
			processed[m.UserID] = struct{}{}
		}
		result = append(result, queueGroup{
			Members:   members,
			Size:      size,
			TotalElo:  total,
			Effective: effective,
		})
	}
	return result, nil
}

func (s *Service) selectGroups(groups []queueGroup) ([]queueGroup, error) {
	slots := s.capacity
	if slots <= 0 {
		return nil, errors.New("invalid capacity")
	}
	ordered := make([]queueGroup, len(groups))
	copy(ordered, groups)
	sort.SliceStable(ordered, func(i, j int) bool {
		return ordered[i].Effective.Before(ordered[j].Effective)
	})
	remaining := make([]int, len(ordered)+1)
	for i := len(ordered) - 1; i >= 0; i-- {
		remaining[i] = remaining[i+1] + ordered[i].Size
	}

	var best []queueGroup
	var bestMax time.Time
	found := false

	var dfs func(idx, size int, maxEff time.Time, chosen []int)
	dfs = func(idx, size int, maxEff time.Time, chosen []int) {
		if size > slots {
			return
		}
		if size+remaining[idx] < slots {
			return
		}
		if found && !bestMax.IsZero() && maxEff.After(bestMax) {
			return
		}
		if size == slots {
			selected := make([]queueGroup, len(chosen))
			for i, c := range chosen {
				selected[i] = ordered[c]
			}
			if _, _, err := splitTeams(selected, s.teamSize); err == nil {
				if !found || maxEff.Before(bestMax) {
					found = true
					bestMax = maxEff
					best = selected
				}
			}
			return
		}
		if idx >= len(ordered) {
			return
		}

		grp := ordered[idx]
		nextMax := maxEff
		if nextMax.IsZero() || grp.Effective.After(nextMax) {
			nextMax = grp.Effective
		}
		dfs(idx+1, size+grp.Size, nextMax, append(chosen, idx))
		dfs(idx+1, size, maxEff, chosen)
	}

	dfs(0, 0, time.Time{}, nil)
	if !found {
		return nil, errors.New("no valid combination found")
	}
	return best, nil
}

func splitTeams(groups []queueGroup, teamSize int) ([]Entry, []Entry, error) {
	bestDiff := math.MaxInt32
	bestAssign := make([]bool, len(groups))
	current := make([]bool, len(groups))
	var dfs func(idx, t1Count, t2Count, t1Elo, t2Elo int)
	dfs = func(idx, t1Count, t2Count, t1Elo, t2Elo int) {
		if idx == len(groups) {
			if t1Count == teamSize && t2Count == teamSize {
				diff := int(math.Abs(float64(t1Elo - t2Elo)))
				if diff < bestDiff {
					bestDiff = diff
					copy(bestAssign, current)
				}
			}
			return
		}
		grp := groups[idx]
		if t1Count+grp.Size <= teamSize {
			current[idx] = true
			dfs(idx+1, t1Count+grp.Size, t2Count, t1Elo+grp.TotalElo, t2Elo)
			current[idx] = false
		}
		if t2Count+grp.Size <= teamSize {
			dfs(idx+1, t1Count, t2Count+grp.Size, t1Elo, t2Elo+grp.TotalElo)
		}
	}
	dfs(0, 0, 0, 0, 0)
	if bestDiff == math.MaxInt32 {
		return nil, nil, errors.New("unable to split teams evenly")
	}
	var team1, team2 []Entry
	for idx, grp := range groups {
		if bestAssign[idx] {
			team1 = append(team1, grp.Members...)
		} else {
			team2 = append(team2, grp.Members...)
		}
	}
	if len(team1) != teamSize || len(team2) != teamSize {
		return nil, nil, errors.New("team sizes mismatch after split")
	}
	return team1, team2, nil
}

func flattenGroups(groups []queueGroup) []Entry {
	if len(groups) == 0 {
		return nil
	}
	entries := make([]Entry, 0)
	for _, group := range groups {
		entries = append(entries, group.Members...)
	}
	return entries
}

func (s *Service) createTeamChannels(sess *discordgo.Session, guildID, baseChannelID, gameCode string, team1, team2 []Entry) (string, string, []string, error) {
	base, err := sess.Channel(baseChannelID)
	if err != nil {
		log.Printf("picking: create team vcs failed to load base channel game=%s base=%s: %v", gameCode, baseChannelID, err)
		return "", "", nil, err
	}
	if base.Type != discordgo.ChannelTypeGuildVoice {
		log.Printf("picking: create team vcs base not voice game=%s base=%s type=%d", gameCode, baseChannelID, base.Type)
		return "", "", nil, errors.New("queue channel is not voice")
	}
	parentID, pickErr := s.pickTeamCategory(sess, guildID, base.ParentID)
	if pickErr != nil {
		log.Printf("queue: failed to select team category: %v", pickErr)
	}
	if parentID == "" {
		parentID = base.ParentID
	}
	log.Printf("picking: creating team vcs game=%s parent=%s team1=%d team2=%d", gameCode, parentID, len(team1), len(team2))
	// Remove user limits on team voice channels so only permissions govern access.
	userLimit := 0
	bitrate := base.Bitrate
	baseOverwrites := s.inheritCategoryOverwrites(sess, parentID)
	overwrites1 := s.buildVoiceOverwrites(baseOverwrites, guildID, userIDsFromEntries(team1), voiceAllowMask)
	overwrites2 := s.buildVoiceOverwrites(baseOverwrites, guildID, userIDsFromEntries(team2), voiceAllowMask)

	name1 := fmt.Sprintf("Game %s - Team 1", gameCode)
	name2 := fmt.Sprintf("Game %s - Team 2", gameCode)

	data1 := discordgo.GuildChannelCreateData{
		Name:                 name1,
		Type:                 discordgo.ChannelTypeGuildVoice,
		ParentID:             parentID,
		UserLimit:            userLimit,
		PermissionOverwrites: overwrites1,
		Bitrate:              bitrate,
	}
	data2 := discordgo.GuildChannelCreateData{
		Name:                 name2,
		Type:                 discordgo.ChannelTypeGuildVoice,
		ParentID:             parentID,
		UserLimit:            userLimit,
		PermissionOverwrites: overwrites2,
		Bitrate:              bitrate,
	}
	ch1, err := sess.GuildChannelCreateComplex(guildID, data1)
	if err != nil {
		log.Printf("picking: failed to create team 1 vc game=%s: %v", gameCode, err)
		return "", "", nil, err
	}
	ch2, err := sess.GuildChannelCreateComplex(guildID, data2)
	if err != nil {
		log.Printf("picking: failed to create team 2 vc game=%s: %v", gameCode, err)
		_, _ = sess.ChannelDelete(ch1.ID)
		return "", "", nil, err
	}
	log.Printf("picking: created team vcs game=%s team1vc=%s team2vc=%s", gameCode, ch1.ID, ch2.ID)
	s.trackTeamChannel(ch1.ID)
	s.trackTeamChannel(ch2.ID)
	s.ensureVoiceChannelsTable()
	s.upsertVoiceChannelCreated(ch1)
	s.upsertVoiceChannelCreated(ch2)
	return ch1.ID, ch2.ID, []string{ch1.ID, ch2.ID}, nil
}

func (s *Service) createPickingChannel(sess *discordgo.Session, guildID, baseChannelID, gameCode string, entries []Entry) (string, error) {
	if sess == nil {
		return "", errors.New("session is nil")
	}
	base, err := sess.Channel(baseChannelID)
	if err != nil {
		log.Printf("picking: create picking vc failed to load base channel game=%s base=%s: %v", gameCode, baseChannelID, err)
		return "", err
	}
	if base.Type != discordgo.ChannelTypeGuildVoice {
		log.Printf("picking: create picking vc base not voice game=%s base=%s type=%d", gameCode, baseChannelID, base.Type)
		return "", errors.New("queue channel is not voice")
	}
	parentID, pickErr := s.pickTeamCategory(sess, guildID, base.ParentID)
	if pickErr != nil {
		log.Printf("queue: failed to select picking category: %v", pickErr)
	}
	if parentID == "" {
		parentID = base.ParentID
	}
	log.Printf("picking: creating picking vc game=%s parent=%s entries=%d", gameCode, parentID, len(entries))
	userLimit := 0
	bitrate := base.Bitrate
	baseOverwrites := s.inheritCategoryOverwrites(sess, parentID)
	overwrites := s.buildVoiceOverwrites(baseOverwrites, guildID, userIDsFromEntries(entries), voiceAllowMask)
	name := fmt.Sprintf("Picking %s", gameCode)
	data := discordgo.GuildChannelCreateData{
		Name:                 name,
		Type:                 discordgo.ChannelTypeGuildVoice,
		ParentID:             parentID,
		UserLimit:            userLimit,
		PermissionOverwrites: overwrites,
		Bitrate:              bitrate,
	}
	ch, err := sess.GuildChannelCreateComplex(guildID, data)
	if err != nil {
		log.Printf("picking: failed to create picking vc game=%s: %v", gameCode, err)
		return "", err
	}
	log.Printf("picking: created picking vc game=%s vc=%s", gameCode, ch.ID)
	s.ensureVoiceChannelsTable()
	s.upsertVoiceChannelCreated(ch)
	return ch.ID, nil
}

func (s *Service) startPickingSession(ctx context.Context, sess *discordgo.Session, guildID, channelID string, cfg Config, entries []Entry, seasonID string) error {
	if sess == nil {
		return errors.New("session is nil")
	}
	if len(entries) != s.capacity {
		return fmt.Errorf("expected %d entries, got %d", s.capacity, len(entries))
	}
	log.Printf("picking: start queue=%s guild=%s entries=%d season=%s", channelID, guildID, len(entries), strings.TrimSpace(seasonID))
	if err := storage.EnsurePickingSessionsTable(ctx); err != nil {
		return err
	}
	captain1, captain2, err := s.pickCaptains(entries)
	if err != nil {
		return err
	}
	gameCode, err := storage.GenerateGameCode(ctx, seasonID)
	if err != nil {
		return err
	}
	log.Printf("picking: captains selected game=%s c1=%s c2=%s", gameCode, captain1.UserID, captain2.UserID)
	threadID, err := s.createGameThread(sess, gameCode)
	if err != nil {
		return err
	}
	pickingChannelID, err := s.createPickingChannel(sess, guildID, channelID, gameCode, entries)
	if err != nil {
		s.deleteThread(sess, threadID)
		return err
	}

	now := time.Now().UTC()
	session := storage.PickingSession{
		ID:               gameCode,
		QueueChannelID:   channelID,
		PickingChannelID: pickingChannelID,
		ThreadID:         threadID,
		GameCode:         gameCode,
		SeasonID:         seasonID,
		Captain1ID:       captain1.UserID,
		Captain2ID:       captain2.UserID,
		PickIndex:        0,
		CreatedAt:        now,
		ExpiresAt:        now.Add(pickingTimeout),
	}
	players := make([]storage.PickingSessionPlayer, 0, len(entries))
	for _, entry := range entries {
		team := 0
		if entry.UserID == captain1.UserID {
			team = 1
		} else if entry.UserID == captain2.UserID {
			team = 2
		}
		players = append(players, storage.PickingSessionPlayer{
			SessionID: session.ID,
			UserID:    entry.UserID,
			PlayerID:  entry.PlayerID,
			Elo:       entry.Elo,
			Team:      team,
		})
	}
	if err := storage.CreatePickingSession(ctx, session, players); err != nil {
		s.deleteThread(sess, threadID)
		_, _ = sess.ChannelDelete(pickingChannelID)
		return err
	}
	log.Printf("picking: session created game=%s session=%s expires=%s thread=%s pickingvc=%s", session.GameCode, session.ID, session.ExpiresAt.UTC().Format(time.RFC3339), session.ThreadID, session.PickingChannelID)

	s.trackPickingChannel(pickingChannelID, session.ID)

	for _, entry := range entries {
		_ = s.removePartyForPicking(ctx, entry.UserID)
	}

	s.movePlayersIfConnected(sess, guildID, pickingChannelID, entries)

	s.announcePickingStart(sess, cfg, session, entries)
	_ = s.sendPickingPrompt(ctx, sess, guildID, session)
	return nil
}

func (s *Service) pickCaptains(entries []Entry) (Entry, Entry, error) {
	if len(entries) < 8 {
		return Entry{}, Entry{}, errors.New("not enough entries for picking")
	}
	ordered := make([]Entry, len(entries))
	copy(ordered, entries)
	sort.SliceStable(ordered, func(i, j int) bool {
		if ordered[i].Elo == ordered[j].Elo {
			return ordered[i].JoinedAt.Before(ordered[j].JoinedAt)
		}
		return ordered[i].Elo < ordered[j].Elo
	})
	bottom := ordered[:4]
	top := ordered[len(ordered)-4:]
	s.randMu.Lock()
	captain1 := bottom[s.rng.Intn(len(bottom))]
	captain2 := top[s.rng.Intn(len(top))]
	s.randMu.Unlock()
	return captain1, captain2, nil
}

func (s *Service) announcePickingStart(sess *discordgo.Session, cfg Config, session storage.PickingSession, entries []Entry) {
	if sess == nil {
		return
	}
	channelID := s.pickingMessageChannelID(session)
	if channelID == "" {
		return
	}
	log.Printf("picking: announce start game=%s session=%s channel=%s entries=%d", session.GameCode, session.ID, channelID, len(entries))
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	nameMap := s.loadPlayerNames(ctx, entries)
	playerNames := formatNames(entries, nameMap)
	mentionLine := formatMentions(entries)
	if mentionLine != "None" {
		_, _ = sess.ChannelMessageSend(channelID, mentionLine)
	}
	msg := fmt.Sprintf(
		"Picking started for game `%s` from <#%s>.\nPicking VC: <#%s>\nCaptain 1: <@%s>\nCaptain 2: <@%s>\nPlayers: %s\nPick order: 1-2-2-1 (last player auto to Team 2).",
		session.GameCode,
		cfg.ChannelID,
		session.PickingChannelID,
		session.Captain1ID,
		session.Captain2ID,
		playerNames,
	)
	if _, err := sess.ChannelMessageSend(channelID, msg); err != nil {
		log.Printf("queue: failed to announce picking start: %v", err)
	}
}

func (s *Service) sendPickingPrompt(ctx context.Context, sess *discordgo.Session, guildID string, session storage.PickingSession) error {
	if sess == nil {
		return errors.New("session is nil")
	}
	channelID := s.pickingMessageChannelID(session)
	if channelID == "" {
		return errors.New("picking message channel is not configured")
	}

	players, err := storage.ListPickingSessionPlayers(ctx, session.ID)
	if err != nil {
		return err
	}
	nameMap := s.loadPickingPlayerNames(ctx, players)

	pickerID := ""
	team := 0
	var content string
	var components []discordgo.MessageComponent
	if session.PickIndex < len(pickingOrder) {
		pickerID, team = s.currentPickingCaptain(session)
		if pickerID == "" {
			return errors.New("no current picker")
		}
		pickable := s.filterPickablePlayers(sess, guildID, session.PickingChannelID, players)
		if len(pickable) == 0 {
			log.Printf("picking: send prompt no pickable players session=%s game=%s", session.ID, session.GameCode)
			s.cancelPickingSession(ctx, sess, guildID, &session, "Picking canceled: no available players to pick.")
			return errors.New("no pickable players")
		}
		log.Printf("picking: send prompt session=%s game=%s pickIndex=%d picker=%s team=%d options=%d", session.ID, session.GameCode, session.PickIndex, pickerID, team, len(pickable))

		options := make([]plainSelectMenuOption, 0, len(pickable))
		for _, p := range pickable {
			label := strings.TrimSpace(nameMap[p.PlayerID])
			if label == "" {
				label = p.UserID
			}
			if len(label) > 100 {
				label = label[:100]
			}
			options = append(options, plainSelectMenuOption{
				Label: label,
				Value: p.UserID,
			})
		}
		if len(options) == 0 {
			log.Printf("picking: send prompt no options session=%s game=%s", session.ID, session.GameCode)
			s.cancelPickingSession(ctx, sess, guildID, &session, "Picking canceled: no available players to pick.")
			return errors.New("no pickable options")
		}

		content = fmt.Sprintf("<@%s>, pick a player for **Game %s** (team %d).", pickerID, session.GameCode, team)
		components = []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					plainSelectMenu{
						CustomID:    fmt.Sprintf("%s%s:%d", pickingSelectPrefix, session.ID, session.PickIndex),
						Placeholder: "Select a player",
						Options:     options,
						MenuType:    discordgo.StringSelectMenu,
					},
				},
			},
		}
	} else {
		content = fmt.Sprintf("Picking complete for **Game %s**.", session.GameCode)
		components = []discordgo.MessageComponent{}
	}

	embed := s.buildPickingEmbed(session, players, pickerID, team, nameMap)
	messageID := strings.TrimSpace(session.MessageID)
	if messageID != "" {
		_, err = sess.ChannelMessageEditComplex(&discordgo.MessageEdit{
			ID:         messageID,
			Channel:    channelID,
			Content:    &content,
			Embeds:     []*discordgo.MessageEmbed{embed},
			Components: components,
		})
		if err == nil {
			return nil
		}
		log.Printf("picking: edit prompt failed session=%s game=%s: %v", session.ID, session.GameCode, err)
	}

	msg, err := sess.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
		Content:    content,
		Embeds:     []*discordgo.MessageEmbed{embed},
		Components: components,
	})
	if err != nil {
		log.Printf("picking: send prompt failed session=%s game=%s: %v", session.ID, session.GameCode, err)
		return err
	}

	ctxUpdate, cancelUpdate := context.WithTimeout(context.Background(), 5*time.Second)
	if err := storage.UpdatePickingSessionMessageID(ctxUpdate, session.ID, msg.ID); err != nil {
		log.Printf("picking: failed to store prompt message id session=%s game=%s: %v", session.ID, session.GameCode, err)
	}
	cancelUpdate()
	return nil
}

func (s *Service) currentPickingCaptain(session storage.PickingSession) (string, int) {
	if session.PickIndex < 0 || session.PickIndex >= len(pickingOrder) {
		return "", 0
	}
	team := pickingOrder[session.PickIndex]
	if team == 1 {
		return session.Captain1ID, team
	}
	return session.Captain2ID, team
}

func (s *Service) buildPickingEmbed(session storage.PickingSession, players []storage.PickingSessionPlayer, pickerID string, pickerTeam int, nameMap map[string]string) *discordgo.MessageEmbed {
	team1 := formatPickingTeamList(1, session.Captain1ID, players, nameMap)
	team2 := formatPickingTeamList(2, session.Captain2ID, players, nameMap)

	pickTotal := len(pickingOrder)
	pickNumber := session.PickIndex + 1
	if pickNumber > pickTotal {
		pickNumber = pickTotal
	}
	description := fmt.Sprintf("Pick %d/%d", pickNumber, pickTotal)
	if session.PickIndex < pickTotal && strings.TrimSpace(pickerID) != "" {
		pickerName := pickingNameByUser(pickerID, players, nameMap)
		description = fmt.Sprintf("Current pick: %s (Team %d)\nPick %d/%d", pickerName, pickerTeam, pickNumber, pickTotal)
	}

	return &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Game %s Picking", session.GameCode),
		Description: description,
		Color:       0x3498db,
		Fields: []*discordgo.MessageEmbedField{
			{
				Name:   "Team 1",
				Value:  team1,
				Inline: true,
			},
			{
				Name:   "Team 2",
				Value:  team2,
				Inline: true,
			},
			{
				Name:   "Unpicked",
				Value:  formatPickingUnpickedList(players, nameMap),
				Inline: false,
			},
		},
	}
}

func formatPickingTeamList(team int, captainID string, players []storage.PickingSessionPlayer, nameMap map[string]string) string {
	captainName := "Unknown"
	if strings.TrimSpace(captainID) != "" {
		captainName = captainID
	}
	var members []storage.PickingSessionPlayer
	for _, p := range players {
		if p.Team != team {
			continue
		}
		if p.UserID == captainID {
			captainName = pickingDisplayName(p.UserID, p.PlayerID, nameMap)
			continue
		}
		members = append(members, p)
	}
	sort.SliceStable(members, func(i, j int) bool {
		ti := members[i].PickedAt
		tj := members[j].PickedAt
		if ti.Valid && tj.Valid {
			return ti.Time.Before(tj.Time)
		}
		if ti.Valid != tj.Valid {
			return ti.Valid
		}
		return members[i].UserID < members[j].UserID
	})
	lines := []string{fmt.Sprintf("Cap: %s", captainName)}
	for _, p := range members {
		lines = append(lines, pickingDisplayName(p.UserID, p.PlayerID, nameMap))
	}
	return strings.Join(lines, "\n")
}

func pickingNameByUser(userID string, players []storage.PickingSessionPlayer, nameMap map[string]string) string {
	for _, p := range players {
		if p.UserID == userID {
			return pickingDisplayName(p.UserID, p.PlayerID, nameMap)
		}
	}
	if strings.TrimSpace(userID) != "" {
		return userID
	}
	return "Unknown"
}

func formatPickingUnpickedList(players []storage.PickingSessionPlayer, nameMap map[string]string) string {
	var unpicked []storage.PickingSessionPlayer
	for _, p := range players {
		if p.Team == 0 {
			unpicked = append(unpicked, p)
		}
	}
	if len(unpicked) == 0 {
		return "None"
	}
	sort.SliceStable(unpicked, func(i, j int) bool {
		if unpicked[i].Elo != unpicked[j].Elo {
			return unpicked[i].Elo > unpicked[j].Elo
		}
		return unpicked[i].UserID < unpicked[j].UserID
	})
	lines := make([]string, 0, len(unpicked))
	for _, p := range unpicked {
		lines = append(lines, pickingDisplayName(p.UserID, p.PlayerID, nameMap))
	}
	return strings.Join(lines, "\n")
}

func pickingDisplayName(userID, playerID string, nameMap map[string]string) string {
	if name := strings.TrimSpace(nameMap[playerID]); name != "" {
		return name
	}
	if strings.TrimSpace(userID) != "" {
		return userID
	}
	return "Unknown"
}

func (s *Service) filterPickablePlayers(sess *discordgo.Session, guildID, pickingChannelID string, players []storage.PickingSessionPlayer) []storage.PickingSessionPlayer {
	var out []storage.PickingSessionPlayer
	for _, p := range players {
		if p.Team != 0 {
			continue
		}
		out = append(out, p)
	}
	return out
}

func (s *Service) loadPickingPlayerNames(ctx context.Context, players []storage.PickingSessionPlayer) map[string]string {
	ids := make([]string, 0, len(players))
	for _, p := range players {
		if strings.TrimSpace(p.PlayerID) != "" {
			ids = append(ids, p.PlayerID)
		}
	}
	names, err := storage.PlayerNameMap(ctx, ids)
	if err != nil {
		log.Printf("queue: failed to load picking player names: %v", err)
	}
	return names
}

func (s *Service) pickingMessageChannelID(session storage.PickingSession) string {
	if strings.TrimSpace(session.ThreadID) != "" {
		return strings.TrimSpace(session.ThreadID)
	}
	return strings.TrimSpace(s.logChannelID)
}

func (s *Service) announcePick(sess *discordgo.Session, session storage.PickingSession, captainID, pickedUserID string) {
	if sess == nil {
		return
	}
	channelID := s.pickingMessageChannelID(session)
	if channelID == "" {
		return
	}
	msg := fmt.Sprintf("Game `%s`: <@%s> picked <@%s>.", session.GameCode, captainID, pickedUserID)
	if _, err := sess.ChannelMessageSend(channelID, msg); err != nil {
		log.Printf("queue: failed to announce pick: %v", err)
	}
}

func (s *Service) autoAssignRemaining(ctx context.Context, sess *discordgo.Session, guildID string, session *storage.PickingSession) error {
	if session == nil {
		return errors.New("session is nil")
	}
	players, err := storage.ListPickingSessionPlayers(ctx, session.ID)
	if err != nil {
		return err
	}
	remaining := s.filterPickablePlayers(sess, guildID, session.PickingChannelID, players)
	if len(remaining) != 1 {
		log.Printf("picking: auto-assign remaining mismatch session=%s game=%s remaining=%d", session.ID, session.GameCode, len(remaining))
		s.cancelPickingSession(ctx, sess, guildID, session, "Picking canceled: remaining players mismatch.")
		return errors.New("remaining players mismatch")
	}
	last := remaining[0]
	log.Printf("picking: auto-assign remaining session=%s game=%s user=%s", session.ID, session.GameCode, last.UserID)
	if err := storage.AssignPickingSessionPlayer(ctx, session.ID, last.UserID, 2); err != nil {
		return err
	}
	if sess != nil {
		channelID := s.pickingMessageChannelID(*session)
		if channelID != "" {
			msg := fmt.Sprintf("Game `%s`: <@%s> auto-assigned to Team 2.", session.GameCode, last.UserID)
			_, _ = sess.ChannelMessageSend(channelID, msg)
		}
	}
	return nil
}

func (s *Service) finalizePickingSession(ctx context.Context, sess *discordgo.Session, guildID string, session *storage.PickingSession) error {
	if session == nil {
		return errors.New("session is nil")
	}
	players, err := storage.ListPickingSessionPlayers(ctx, session.ID)
	if err != nil {
		return err
	}
	var team1 []Entry
	var team2 []Entry
	for _, p := range players {
		entry := Entry{
			UserID:   p.UserID,
			PlayerID: p.PlayerID,
			Elo:      p.Elo,
		}
		switch p.Team {
		case 1:
			team1 = append(team1, entry)
		case 2:
			team2 = append(team2, entry)
		}
	}
	if len(team1) != s.teamSize || len(team2) != s.teamSize {
		log.Printf("picking: finalize teams incomplete session=%s game=%s team1=%d team2=%d", session.ID, session.GameCode, len(team1), len(team2))
		s.cancelPickingSession(ctx, sess, guildID, session, "Picking canceled: incomplete teams.")
		return errors.New("picking teams are incomplete")
	}

	gameCode := session.GameCode
	log.Printf("picking: finalize game=%s team1=%d team2=%d", gameCode, len(team1), len(team2))
	mapChoice, err := maps.RandomForStyle(ctx, s.gameStyle)
	if err != nil {
		log.Printf("picking: finalize failed to choose map game=%s: %v", gameCode, err)
		s.cancelPickingSession(ctx, sess, guildID, session, "Picking canceled: failed to choose map.")
		return err
	}

	team1Voice, team2Voice, createdChannels, err := s.createTeamChannels(sess, guildID, session.QueueChannelID, gameCode, team1, team2)
	if err != nil {
		log.Printf("picking: finalize failed to create team vcs game=%s: %v", gameCode, err)
		s.cancelPickingSession(ctx, sess, guildID, session, "Picking canceled: failed to create team channels.")
		return err
	}

	threadID := strings.TrimSpace(session.ThreadID)
	if threadID == "" {
		threadID, err = s.createGameThread(sess, gameCode)
		if err != nil {
			log.Printf("picking: finalize failed to create thread game=%s: %v", gameCode, err)
			s.cleanupChannels(sess, guildID, createdChannels)
			s.cancelPickingSession(ctx, sess, guildID, session, "Picking canceled: failed to create thread.")
			return err
		}
		session.ThreadID = threadID
	}
	log.Printf("picking: finalize created vcs game=%s team1vc=%s team2vc=%s thread=%s", gameCode, team1Voice, team2Voice, threadID)

	s.movePlayersIfConnected(sess, guildID, team1Voice, team1)
	s.movePlayersIfConnected(sess, guildID, team2Voice, team2)

	assignments := make([]storage.GameCreatePlayer, 0, len(team1)+len(team2))
	for _, e := range team1 {
		assignments = append(assignments, storage.GameCreatePlayer{
			PlayerID:    e.PlayerID,
			DiscordID:   e.UserID,
			DiscordTeam: 1,
			PreElo:      e.Elo,
		})
	}
	for _, e := range team2 {
		assignments = append(assignments, storage.GameCreatePlayer{
			PlayerID:    e.PlayerID,
			DiscordID:   e.UserID,
			DiscordTeam: 2,
			PreElo:      e.Elo,
		})
	}

	input := storage.GameCreateInput{
		GameCode:          gameCode,
		Team1VoiceID:      team1Voice,
		Team2VoiceID:      team2Voice,
		QueueThreadID:     threadID,
		SeasonID:          session.SeasonID,
		GameStyle:         s.gameStyle,
		MapName:           mapChoice.Name,
		PlayerAssignments: assignments,
	}
	dbCtx, dbCancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer dbCancel()
	if _, err := storage.CreateGameWithPlayers(dbCtx, input); err != nil {
		log.Printf("picking: finalize failed to create game row game=%s: %v", gameCode, err)
		s.movePlayersToChannel(sess, guildID, session.QueueChannelID, team1)
		s.movePlayersToChannel(sess, guildID, session.QueueChannelID, team2)
		s.cleanupChannels(sess, guildID, createdChannels)
		s.cancelPickingSession(ctx, sess, guildID, session, "Picking canceled: failed to create game.")
		return err
	}

	s.upsertQueueThreadRow(ctx, threadID, gameCode)
	s.sendThreadRoster(sess, threadID, gameCode, mapChoice, team1, team2, team1Voice, team2Voice)
	s.announceMatch(ctx, sess, Config{ChannelID: session.QueueChannelID}, gameCode, mapChoice, team1, team2, team1Voice, team2Voice, threadID)
	s.completePickingSession(ctx, sess, guildID, session)
	log.Printf("picking: finalize success game=%s session=%s", gameCode, session.ID)
	return nil
}

func (s *Service) cancelPickingSession(ctx context.Context, sess *discordgo.Session, guildID string, session *storage.PickingSession, reason string) {
	s.cleanupPickingSession(ctx, sess, guildID, session, reason, true)
}

func (s *Service) completePickingSession(ctx context.Context, sess *discordgo.Session, guildID string, session *storage.PickingSession) {
	s.cleanupPickingSession(ctx, sess, guildID, session, "", false)
}

func (s *Service) cleanupPickingSession(ctx context.Context, sess *discordgo.Session, guildID string, session *storage.PickingSession, reason string, deleteThread bool) {
	if session == nil {
		return
	}
	log.Printf("picking: cleanup session=%s game=%s reason=%q deleteThread=%t pickingvc=%s thread=%s", session.ID, session.GameCode, reason, deleteThread, session.PickingChannelID, session.ThreadID)
	_ = storage.DeletePickingSession(ctx, session.ID)
	s.untrackPickingChannel(session.PickingChannelID)
	if sess != nil && session.PickingChannelID != "" {
		waiting := strings.TrimSpace(s.waitingRoomID)
		queued := discordutil.EnqueueDelete(discordutil.DeleteTask{
			ChannelID:     session.PickingChannelID,
			GuildID:       guildID,
			Hide:          true,
			MoveMembersTo: waiting,
			Reason:        "picking cleanup",
		})
		if !queued {
			_, _ = sess.ChannelDelete(session.PickingChannelID)
		}
	}
	if deleteThread && sess != nil && strings.TrimSpace(session.ThreadID) != "" {
		s.deleteThread(sess, session.ThreadID)
	}
	if strings.TrimSpace(reason) != "" && sess != nil && strings.TrimSpace(s.logChannelID) != "" {
		_, _ = sess.ChannelMessageSend(s.logChannelID, reason)
	}
}

func (s *Service) resumePickingSessions(sess *discordgo.Session, guildID string) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := storage.EnsurePickingSessionsTable(ctx); err != nil {
		log.Printf("queue: picking table init failed: %v", err)
		return
	}
	sessions, err := storage.ListActivePickingSessions(ctx)
	if err != nil {
		log.Printf("queue: failed to load picking sessions: %v", err)
		return
	}
	for _, session := range sessions {
		if strings.TrimSpace(session.PickingChannelID) == "" {
			_ = storage.DeletePickingSession(ctx, session.ID)
			continue
		}
		if sess != nil {
			if _, err := sess.Channel(session.PickingChannelID); err != nil {
				_ = storage.DeletePickingSession(ctx, session.ID)
				continue
			}
		}
		s.trackPickingChannel(session.PickingChannelID, session.ID)
		if sess != nil {
			_ = s.sendPickingPrompt(ctx, sess, guildID, session)
		}
	}
}

func (s *Service) pickingCleanupWatcher(sess *discordgo.Session, guildID string) {
	s.cleanupExpiredPickingSessions(sess, guildID)
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	for range ticker.C {
		s.cleanupExpiredPickingSessions(sess, guildID)
	}
}

func (s *Service) cleanupExpiredPickingSessions(sess *discordgo.Session, guildID string) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.EnsurePickingSessionsTable(ctx); err != nil {
		return
	}
	sessions, err := storage.ListExpiredPickingSessions(ctx, time.Now().UTC())
	if err != nil {
		log.Printf("queue: failed to load expired picking sessions: %v", err)
		return
	}
	if len(sessions) > 0 {
		log.Printf("picking: expired sessions=%d", len(sessions))
	}
	for _, session := range sessions {
		log.Printf("picking: expiring session=%s game=%s expiresAt=%s", session.ID, session.GameCode, session.ExpiresAt.UTC().Format(time.RFC3339))
		s.cancelPickingSession(ctx, sess, guildID, &session, "Picking session expired.")
	}
}

func (s *Service) createGameThread(sess *discordgo.Session, gameCode string) (string, error) {
	parentID := s.threadChannelID
	if parentID == "" {
		parentID = s.logChannelID
	}
	log.Printf("picking: create thread game=%s parent=%s", gameCode, strings.TrimSpace(parentID))
	thread, err := sess.ThreadStartComplex(parentID, &discordgo.ThreadStart{
		Name:      fmt.Sprintf("Game %s", gameCode),
		Type:      discordgo.ChannelTypeGuildPrivateThread,
		Invitable: false,
	})
	if err != nil {
		log.Printf("picking: create thread failed game=%s: %v", gameCode, err)
		return "", err
	}
	log.Printf("picking: created thread game=%s thread=%s", gameCode, thread.ID)
	s.trackThread(thread, gameCode)
	return thread.ID, nil
}

func (s *Service) movePlayersIfConnected(sess *discordgo.Session, guildID, channelID string, team []Entry) {
	if sess == nil || strings.TrimSpace(channelID) == "" {
		return
	}
	for _, entry := range team {
		userID := strings.TrimSpace(entry.UserID)
		if userID == "" {
			continue
		}
		if s.userVoiceChannelID(sess, guildID, userID) == "" {
			log.Printf("picking: skip move user=%s not in voice target=%s", userID, channelID)
			continue
		}
		target := channelID
		s.markSilentLeave(userID)
		if err := sess.GuildMemberMove(guildID, userID, &target); err != nil {
			log.Printf("picking: failed to move user=%s to=%s: %v", userID, channelID, err)
		}
	}
}

func (s *Service) movePlayers(sess *discordgo.Session, guildID, channelID string, team []Entry) error {
	for _, entry := range team {
		// time.Sleep(queueAPIDelay)
		target := channelID
		s.markSilentLeave(entry.UserID)
		if err := sess.GuildMemberMove(guildID, entry.UserID, &target); err != nil {
			return fmt.Errorf("move %s to %s: %w", entry.UserID, channelID, err)
		}
	}
	return nil
}

func (s *Service) removePartyForPicking(ctx context.Context, userID string) error {
	removed, err := storage.RemovePartyMember(ctx, userID)
	if err != nil {
		return err
	}
	if removed {
		log.Printf("queue: removed %s from party for picking", userID)
	}
	return nil
}

func (s *Service) upsertVoiceChannelCreated(ch *discordgo.Channel) {
	if s == nil || ch == nil {
		return
	}
	createdAt := time.Now().UTC()
	if ts, err := discordgo.SnowflakeTimestamp(ch.ID); err == nil {
		createdAt = ts.UTC()
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	if err := storage.UpsertVoiceChannel(ctx, ch.ID, ch.Name, createdAt, nil); err != nil {
		log.Printf("queue: voice create upsert failed for %s: %v", ch.Name, err)
	}
	cancel()
}

func (s *Service) announceMatch(ctx context.Context, sess *discordgo.Session, cfg Config, gameCode string, mapInfo maps.Info, team1, team2 []Entry, team1Voice, team2Voice, threadID string) {
	if sess == nil {
		return
	}
	channelID := strings.TrimSpace(s.logChannelID)
	if channelID == "" {
		channelID = s.threadAnnouncementChannelID(ctx, threadID)
	}
	if channelID == "" {
		return
	}
	threadLine := ""
	if strings.TrimSpace(threadID) != "" {
		threadLine = fmt.Sprintf("Thread: <#%s>\n", strings.TrimSpace(threadID))
	}
	content := fmt.Sprintf(
		"Game `%s` ready on map **%s** from <#%s>!\n%sTeam 1 (<#%s>): %s\nTeam 2 (<#%s>): %s",
		gameCode,
		mapInfo.Name,
		cfg.ChannelID,
		threadLine,
		team1Voice,
		formatMentions(team1),
		team2Voice,
		formatMentions(team2),
	)
	if _, err := sess.ChannelMessageSend(channelID, content); err != nil {
		log.Printf("queue: failed to announce match: %v", err)
	}
}

func (s *Service) sendThreadRoster(sess *discordgo.Session, threadID, gameCode string, mapInfo maps.Info, team1, team2 []Entry, team1Voice, team2Voice string) {
	if sess == nil || threadID == "" {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	nameMap := s.loadPlayerNames(ctx, append(team1, team2...))

	// Ping everyone once at the top (same as before)
	mentionLine := fmt.Sprintf("%s, %s", formatMentions(team1), formatMentions(team2))
	_, _ = sess.ChannelMessageSend(threadID, mentionLine)

	team1Names := formatNames(team1, nameMap)
	team2Names := formatNames(team2, nameMap)

	// Party commands
	party1 := fmt.Sprintf("/p invite %s", formatInviteCommand(team1, nameMap))
	party2 := fmt.Sprintf("/p invite %s", formatInviteCommand(team2, nameMap))

	embed := &discordgo.MessageEmbed{
		Title: fmt.Sprintf("Game %s • %s", strings.TrimSpace(gameCode), mapInfo.Name),
		Description: "Use `/submit` in this thread to upload your screenshot once the match ends. " +
			"Proof is automatically forwarded to #staff-scoring for staff review.\n\n" +
			"**Team 1 Party:**\n```" + party1 + "```\n\n" +
			"**Team 2 Party:**\n```" + party2 + "```",
		Fields: []*discordgo.MessageEmbedField{
			{Name: fmt.Sprintf("Team 1 (<#%s>)", team1Voice), Value: team1Names},
			{Name: fmt.Sprintf("Team 2 (<#%s>)", team2Voice), Value: team2Names},
		},
		Color: 0x3498db,
	}

	components := []discordgo.MessageComponent{
		discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{
				discordgo.Button{
					Label:    "Submit Score",
					Style:    discordgo.PrimaryButton,
					CustomID: scoreSubmitButtonPrefix + strings.TrimSpace(gameCode),
					Emoji:    discordgo.ComponentEmoji{Name: "\U0001F4DD"},
				},
			},
		},
	}

	_, err := sess.ChannelMessageSendComplex(threadID, &discordgo.MessageSend{
		Embeds:     []*discordgo.MessageEmbed{embed},
		Components: components,
	})
	if err != nil {
		log.Printf("queue: failed to send thread roster: %v", err)
	}

	// (Optional) keep rules embed as a separate message like before
	if rules, err := storage.LoadRuleset(); err == nil && strings.TrimSpace(rules) != "" {
		_, _ = sess.ChannelMessageSendEmbed(threadID, &discordgo.MessageEmbed{
			Title:       "Rules",
			Description: rules,
			Color:       0x7289da,
		})
	}
}

func formatMentions(entries []Entry) string {
	if len(entries) == 0 {
		return "None"
	}
	parts := make([]string, 0, len(entries))
	for _, entry := range entries {
		parts = append(parts, fmt.Sprintf("<@%s>", entry.UserID))
	}
	return strings.Join(parts, ", ")
}

func (s *Service) cleanupChannels(sess *discordgo.Session, guildID string, channelIDs []string) {
	waiting := strings.TrimSpace(s.waitingRoomID)
	for _, id := range channelIDs {
		if id == "" {
			continue
		}
		ok := discordutil.EnqueueDelete(discordutil.DeleteTask{
			ChannelID:     id,
			GuildID:       guildID,
			Hide:          true,
			MoveMembersTo: waiting,
			Reason:        "queue cleanup",
		})
		if !ok && sess != nil {
			_, _ = sess.ChannelDelete(id)
		}
	}
}

func (s *Service) deleteThread(sess *discordgo.Session, threadID string) {
	if sess == nil || threadID == "" {
		return
	}
	if _, err := sess.ChannelDelete(threadID); err != nil {
		log.Printf("queue: failed to delete thread %s: %v", threadID, err)
		if isUnknownThread(err) {
			s.deleteThreadRow(threadID)
		}
		return
	}
	s.deleteThreadRow(threadID)
}

func (s *Service) movePlayersToChannel(sess *discordgo.Session, guildID, channelID string, entries []Entry) {
	if sess == nil || channelID == "" {
		return
	}
	for _, entry := range entries {
		// time.Sleep(queueAPIDelay)
		target := channelID
		s.markSilentLeave(entry.UserID)
		_ = sess.GuildMemberMove(guildID, entry.UserID, &target)
	}
}

func (s *Service) markSilentLeave(userID string) {
	if userID == "" {
		return
	}
	s.silentLeaves.Store(userID, struct{}{})
}

func (s *Service) consumeSilentLeave(userID string) bool {
	if userID == "" {
		return false
	}
	if _, ok := s.silentLeaves.Load(userID); ok {
		s.silentLeaves.Delete(userID)
		return true
	}
	return false
}

func (s *Service) refreshPlayerRecords(ctx context.Context, entries []Entry) ([]Entry, map[string]struct{}, error) {
	refreshed := make([]Entry, 0, len(entries))
	removed := make(map[string]struct{})
	for _, entry := range entries {
		player, err := storage.GetPlayerByUserID(ctx, entry.UserID)
		if err != nil {
			return nil, nil, err
		}
		if player == nil || strings.TrimSpace(player.ID) == "" {
			log.Printf("queue: refresh missing player row for user %s", entry.UserID)
			removed[entry.UserID] = struct{}{}
			continue
		}
		entry.PlayerID = player.ID
		refreshed = append(refreshed, entry)
	}
	return refreshed, removed, nil
}

func (s *Service) finishProcessing(sess *discordgo.Session, guildID, channelID string, removed map[string]struct{}) {
	triggerNext := false
	if err := s.store.WithLock(channelID, func(state *State) error {
		if state == nil {
			return nil
		}
		if len(removed) > 0 {
			var remaining []Entry
			for _, entry := range state.Entries {
				if _, ok := removed[entry.UserID]; !ok {
					remaining = append(remaining, entry)
				}
			}
			state.Entries = remaining
		}
		state.Processing = false
		if s.capacity > 0 && len(state.Entries) >= s.capacity {
			state.Processing = true
			triggerNext = true
		}
		return nil
	}); err != nil {
		log.Printf("queue: failed to finalize state: %v", err)
	}
	if len(removed) > 0 {
		for userID := range removed {
			s.membership.Delete(userID)
		}
	}
	if triggerNext {
		go s.processQueueChannel(sess, guildID, channelID)
	}
}

func (s *Service) resetProcessing(channelID string) error {
	return s.store.WithLock(channelID, func(state *State) error {
		if state != nil {
			state.Processing = false
		}
		return nil
	})
}

func (s *Service) userInChannel(sess *discordgo.Session, guildID, channelID, userID string) bool {
	if sess == nil {
		return false
	}
	if vs, err := sess.State.VoiceState(guildID, userID); err == nil && vs != nil {
		return vs.ChannelID == channelID
	}
	guild, err := sess.State.Guild(guildID)
	if err != nil {
		return false
	}
	for _, vs := range guild.VoiceStates {
		if vs.UserID == userID {
			return vs.ChannelID == channelID
		}
	}
	return false
}

func (s *Service) userVoiceChannelID(sess *discordgo.Session, guildID, userID string) string {
	if sess == nil {
		return ""
	}
	if vs, err := sess.State.VoiceState(guildID, userID); err == nil && vs != nil {
		return strings.TrimSpace(vs.ChannelID)
	}
	guild, err := sess.State.Guild(guildID)
	if err != nil {
		return ""
	}
	for _, vs := range guild.VoiceStates {
		if vs.UserID == userID {
			return strings.TrimSpace(vs.ChannelID)
		}
	}
	return ""
}

type queueGroup struct {
	Members   []Entry
	Size      int
	TotalElo  int
	Effective time.Time
}

type queueCombo struct {
	MaxJoined time.Time
	Indices   []int
}

/*
This probably needs to be removed because it causes many people to be annoyed because they
get pinged every time they join the queue. Additionally pings should be reserved for important
notifications such as match start issues or other issues. For now I will take the approach of
removing the ping by replacing it with just the persons Discord ID instead of a mention If
you or any other contributors have issues with my approach and decision please raise it with me.
change:
user.Mention() -> user.ID

- wirespider87
*/
func (s *Service) logEvent(sess *discordgo.Session, cfg Config, user *discordgo.User, count int) {
	if s.logChannelID == "" || sess == nil || user == nil {
		return
	}
	label := fmt.Sprintf("Queue [%d-%d]", cfg.MinElo, cfg.MaxElo)
	content := fmt.Sprintf("[%s] <#%s> %s joined queue (%s players)", label, cfg.ChannelID, user.ID, formatCount(count, s.capacity))
	if _, err := sess.ChannelMessageSend(s.logChannelID, content); err != nil {
		log.Printf("queue: failed to send log message: %v", err)
	}
}

/*
Apply the same change here as above in logEvent function except change <@s> to %s for queue leave
extreme apologies for this being another commit but I forgot to do it here initially.
- wirespider87
*/
func (s *Service) logLeave(sess *discordgo.Session, cfg Config, userID string, count int) {
	if s.logChannelID == "" || sess == nil || userID == "" {
		return
	}
	label := fmt.Sprintf("Queue [%d-%d]", cfg.MinElo, cfg.MaxElo)
	content := fmt.Sprintf("[%s] <#%s> %s left queue (%s players)", label, cfg.ChannelID, userID, formatCount(count, s.capacity))
	if _, err := sess.ChannelMessageSend(s.logChannelID, content); err != nil {
		log.Printf("queue: failed to send leave log: %v", err)
	}
}

func (s *Service) notifyPartyTooLarge(sess *discordgo.Session, cfg Config, user *discordgo.User, size int) {
	if user == nil {
		return
	}
	message := fmt.Sprintf("You cannot queue because your party has %d members while teams are size %d. Reduce your party size and try again.", size, s.teamSize)
	if sess != nil {
		if dm, err := sess.UserChannelCreate(user.ID); err == nil {
			_, _ = sess.ChannelMessageSend(dm.ID, message)
		}
	}
	if s.logChannelID != "" && sess != nil {
		logMsg := fmt.Sprintf("[%d-%d] <#%s> %s could not queue: party size %d exceeds team size %d.", cfg.MinElo, cfg.MaxElo, cfg.ChannelID, user.Mention(), size, s.teamSize)
		if _, err := sess.ChannelMessageSend(s.logChannelID, logMsg); err != nil {
			log.Printf("queue: failed to log party-too-large message: %v", err)
		}
	}
}

func formatCount(count, capacity int) string {
	if capacity <= 0 {
		return strconv.Itoa(count)
	}
	return fmt.Sprintf("%d/%d", count, capacity)
}

func deriveCapacity(style string) int {
	style = strings.TrimSpace(strings.ToLower(style))
	if style == "" {
		return 0
	}
	if strings.Contains(style, "v") {
		parts := strings.Split(style, "v")
		if len(parts) >= 2 {
			a, errA := strconv.Atoi(strings.TrimSpace(parts[0]))
			b, errB := strconv.Atoi(strings.TrimSpace(parts[1]))
			if errA == nil && errB == nil && a > 0 && b > 0 {
				return a + b
			}
		}
	}
	if val, err := strconv.Atoi(style); err == nil && val > 0 {
		return val
	}
	return 0
}

func formatAssignments(assignments []storage.GameCreatePlayer, _ []Entry) string {
	if len(assignments) == 0 {
		return "none"
	}
	var builder strings.Builder
	for idx, a := range assignments {
		if idx > 0 {
			builder.WriteString(", ")
		}
		if strings.TrimSpace(a.DiscordID) != "" {
			builder.WriteString(a.DiscordID)
		} else {
			builder.WriteString(a.PlayerID)
		}
	}
	return builder.String()
}

func mapKeys(m map[string]struct{}) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	return out
}

// allowNotice rate-limits notices by key to avoid spamming the queue log channel.
func (s *Service) allowNotice(key string, interval time.Duration) bool {
	s.noticeMu.Lock()
	defer s.noticeMu.Unlock()
	now := time.Now()
	if prev, ok := s.noticeTimes[key]; ok {
		if now.Sub(prev) < interval {
			return false
		}
	}
	s.noticeTimes[key] = now
	return true
}

func (s *Service) queueSkip(sess *discordgo.Session, cfg Config, key string, msg string) {
	if s == nil || s.logChannelID == "" || sess == nil {
		return
	}
	if key != "" && !s.allowNotice(key, 10*time.Minute) {
		return
	}
	label := fmt.Sprintf("Queue [%d-%d]", cfg.MinElo, cfg.MaxElo)
	_, _ = sess.ChannelMessageSend(s.logChannelID, fmt.Sprintf("[%s] <#%s> %s", label, cfg.ChannelID, msg))
}

func (s *Service) queueRankedBanAlert(ctx context.Context, sess *discordgo.Session, userID string) {
	if s == nil || sess == nil || strings.TrimSpace(userID) == "" {
		return
	}
	if !s.allowNotice("alert:rankedban:"+userID, 10*time.Minute) {
		return
	}
	alertsChannel, err := storage.GetAlertsChannelID(ctx)
	if err != nil || strings.TrimSpace(alertsChannel) == "" {
		return
	}
	supportChannelID, _ := storage.GetSupportChannelID(ctx)
	supportMention := "#support"
	if strings.TrimSpace(supportChannelID) != "" {
		supportMention = fmt.Sprintf("<#%s>", supportChannelID)
	}
	msg := fmt.Sprintf("<@%s> you are unable to join queue since you are rank banned. If you think this is incorrect please make a ticket %s.", userID, supportMention)
	_, _ = sess.ChannelMessageSend(alertsChannel, msg)
}

func (s *Service) queuePartyMissingAlert(ctx context.Context, sess *discordgo.Session, party *storage.Party) {
	if s == nil || sess == nil || party == nil {
		return
	}
	if !s.allowNotice("alert:partyMissing:"+party.ID, time.Minute) {
		return
	}
	alertsChannel, err := storage.GetAlertsChannelID(ctx)
	if err != nil || strings.TrimSpace(alertsChannel) == "" {
		return
	}
	mentions := make([]string, 0, len(party.Members))
	for _, member := range party.Members {
		member = strings.TrimSpace(member)
		if member == "" {
			continue
		}
		mentions = append(mentions, fmt.Sprintf("<@%s>", member))
	}
	if len(mentions) == 0 {
		return
	}
	msg := fmt.Sprintf("%s your party is missing members in the queue, so it was skipped. Please have everyone join the queue VC.", strings.Join(mentions, " "))
	_, _ = sess.ChannelMessageSend(alertsChannel, msg)
}

func (s *Service) autoClosePendingGamesWatcher(sess *discordgo.Session, guildID string) {
	if s == nil || sess == nil {
		return
	}
	runOnce := func() {
		ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
		defer cancel()

		seasonID, err := storage.ActiveSeasonID(ctx)
		if err != nil || strings.TrimSpace(seasonID) == "" {
			return
		}
		cutoff := time.Now().UTC().Add(-3 * time.Hour)
		games, err := storage.AutoClosePendingGames(ctx, seasonID, cutoff)
		if err != nil {
			log.Printf("queue: auto-close lookup failed: %v", err)
			return
		}
		if len(games) == 0 {
			return
		}
		channelID := strings.TrimSpace(loadSettingOrEnv("game_resultls_channel"))
		if channelID == "" {
			return
		}
		for _, game := range games {
			_, players, err := storage.GetGameWithPlayersForSeason(ctx, game.GameID, seasonID)
			if err != nil {
				log.Printf("queue: auto-close players load failed for %s: %v", game.GameID, err)
				continue
			}
			userSet := make(map[string]struct{})
			for _, p := range players {
				id := strings.TrimSpace(p.DiscordID)
				if id != "" {
					userSet[id] = struct{}{}
				}
			}
			mentions := make([]string, 0, len(userSet))
			userIDs := make([]string, 0, len(userSet))
			for id := range userSet {
				userIDs = append(userIDs, id)
				mentions = append(mentions, fmt.Sprintf("<@%s>", id))
			}
			content := strings.Join(mentions, " ")
			if strings.TrimSpace(content) != "" {
				content += " "
			}
			content += fmt.Sprintf("Game `%s` was voided because no one submitted proof within 3 hours of game creation.", game.GameID)
			msg := &discordgo.MessageSend{
				Content: content,
				AllowedMentions: &discordgo.MessageAllowedMentions{
					Users: userIDs,
				},
			}
			_, _ = sess.ChannelMessageSendComplex(channelID, msg)
		}
	}

	runOnce()
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()
	for range ticker.C {
		runOnce()
	}
}

func (s *Service) queueLog(sess *discordgo.Session, format string, args ...interface{}) {
	msg := fmt.Sprintf("queue: "+format, args...)
	log.Println(msg)
	if sess == nil {
		return
	}
	channelID := strings.TrimSpace(s.logChannelID)
	if channelID == "" {
		return
	}
	if _, err := sess.ChannelMessageSend(channelID, msg); err != nil {
		log.Printf("queue: failed to post log to %s: %v", channelID, err)
	}
}

func (s *Service) trackTeamChannel(id string) {
	s.teamMu.Lock()
	defer s.teamMu.Unlock()
	if s.teamChannels == nil {
		s.teamChannels = make(map[string]time.Time)
	}
	s.teamChannels[id] = time.Time{} // empty last-empty marker
}

func (s *Service) trackPickingChannel(channelID, sessionID string) {
	if strings.TrimSpace(channelID) == "" || strings.TrimSpace(sessionID) == "" {
		return
	}
	s.pickingMu.Lock()
	defer s.pickingMu.Unlock()
	if s.pickingChannels == nil {
		s.pickingChannels = make(map[string]string)
	}
	s.pickingChannels[channelID] = sessionID
}

func (s *Service) untrackPickingChannel(channelID string) {
	channelID = strings.TrimSpace(channelID)
	if channelID == "" {
		return
	}
	s.pickingMu.Lock()
	defer s.pickingMu.Unlock()
	delete(s.pickingChannels, channelID)
}

func (s *Service) isPickingChannel(channelID string) bool {
	channelID = strings.TrimSpace(channelID)
	if channelID == "" {
		return false
	}
	s.pickingMu.Lock()
	defer s.pickingMu.Unlock()
	_, ok := s.pickingChannels[channelID]
	return ok
}

func (s *Service) trackThread(thread *discordgo.Channel, gameCode string) {
	if s == nil || thread == nil || strings.TrimSpace(thread.ID) == "" {
		return
	}
	s.ensureQueueThreadsTable()
	createdAt := time.Now().UTC()
	if ts, err := discordgo.SnowflakeTimestamp(thread.ID); err == nil {
		createdAt = ts.UTC()
	}
	parentID := strings.TrimSpace(thread.ParentID)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.UpsertQueueThread(ctx, thread.ID, gameCode, parentID, createdAt); err != nil {
		log.Printf("queue: failed to record thread %s: %v", thread.ID, err)
	}
}

func (s *Service) upsertQueueThreadRow(ctx context.Context, threadID, gameCode string) {
	threadID = strings.TrimSpace(threadID)
	if s == nil || threadID == "" {
		return
	}
	s.ensureQueueThreadsTable()
	if ctx == nil {
		ctx = context.Background()
	}
	createdAt := time.Now().UTC()
	if ts, err := discordgo.SnowflakeTimestamp(threadID); err == nil {
		createdAt = ts.UTC()
	}
	parentID := s.threadListChannelID()
	if err := storage.UpsertQueueThread(ctx, threadID, gameCode, parentID, createdAt); err != nil {
		log.Printf("queue: failed to upsert thread row %s: %v", threadID, err)
	}
}

func (s *Service) ensureThreadRows(sess *discordgo.Session) {
	if s == nil || sess == nil {
		return
	}
	s.threadSyncOnce.Do(func() {
		s.ensureQueueThreadsTable()
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		count, err := storage.CountQueueThreads(ctx)
		if err != nil {
			log.Printf("queue: failed to count queue threads: %v", err)
			return
		}
		if count > 0 {
			return
		}
		channelID := s.threadListChannelID()
		if channelID == "" {
			return
		}
		total := s.syncThreadsFromDiscord(ctx, sess, channelID)
		if total > 0 {
			log.Printf("queue: synced %d existing threads for watcher", total)
		}
	})
}

func (s *Service) syncThreadsFromDiscord(ctx context.Context, sess *discordgo.Session, channelID string) int {
	if sess == nil || strings.TrimSpace(channelID) == "" {
		return 0
	}
	total := 0
	if list, err := sess.ThreadsActive(channelID); err == nil {
		total += s.syncThreadsFromList(ctx, list, channelID)
	} else {
		log.Printf("queue: failed to list active threads for watcher: %v", err)
	}
	if list, err := sess.ThreadsPrivateArchived(channelID, nil, 100); err == nil {
		total += s.syncThreadsFromList(ctx, list, channelID)
	} else {
		log.Printf("queue: failed to list private archived threads for watcher: %v", err)
	}
	if list, err := sess.ThreadsArchived(channelID, nil, 100); err == nil {
		total += s.syncThreadsFromList(ctx, list, channelID)
	} else {
		log.Printf("queue: failed to list public archived threads for watcher: %v", err)
	}
	return total
}

func (s *Service) syncThreadsFromList(ctx context.Context, list *discordgo.ThreadsList, fallbackParent string) int {
	if list == nil || len(list.Threads) == 0 {
		return 0
	}
	added := 0
	for _, th := range list.Threads {
		if th == nil || strings.TrimSpace(th.ID) == "" {
			continue
		}
		createdAt := time.Now().UTC()
		if ts, err := discordgo.SnowflakeTimestamp(th.ID); err == nil {
			createdAt = ts.UTC()
		}
		parentID := strings.TrimSpace(th.ParentID)
		if parentID == "" {
			parentID = strings.TrimSpace(fallbackParent)
		}
		gameCode := parseGameCodeFromThreadName(th.Name)
		if err := storage.UpsertQueueThread(ctx, th.ID, gameCode, parentID, createdAt); err != nil {
			log.Printf("queue: failed to sync thread %s: %v", th.ID, err)
			continue
		}
		added++
	}
	return added
}

func (s *Service) threadListChannelID() string {
	if id := strings.TrimSpace(s.threadChannelID); id != "" {
		return id
	}
	return strings.TrimSpace(s.logChannelID)
}

func (s *Service) threadAnnouncementChannelID(ctx context.Context, threadID string) string {
	threadID = strings.TrimSpace(threadID)
	if s == nil {
		return ""
	}
	if threadID == "" {
		return s.threadListChannelID()
	}
	s.ensureQueueThreadsTable()
	if ctx == nil {
		ctx = context.Background()
	}
	th, err := storage.GetQueueThread(ctx, threadID)
	if err != nil {
		log.Printf("queue: failed to load thread %s info: %v", threadID, err)
		return s.threadListChannelID()
	}
	if th != nil && strings.TrimSpace(th.ParentChannelID) != "" {
		return strings.TrimSpace(th.ParentChannelID)
	}
	return s.threadListChannelID()
}

func parseGameCodeFromThreadName(name string) string {
	name = strings.TrimSpace(name)
	if name == "" {
		return ""
	}
	const prefix = "Game "
	if strings.HasPrefix(name, prefix) {
		return strings.TrimSpace(strings.TrimPrefix(name, prefix))
	}
	return ""
}

func (s *Service) cleanupTeamChannels(sess *discordgo.Session, guildID string) {
	if s == nil || sess == nil {
		return
	}
	s.teamMu.Lock()
	channels := make(map[string]time.Time, len(s.teamChannels))
	for k, v := range s.teamChannels {
		channels[k] = v
	}
	s.teamMu.Unlock()
	if len(channels) == 0 {
		return
	}

	voiceCounts := make(map[string]int)
	if guild, err := sess.State.Guild(guildID); err == nil && guild != nil {
		for _, vs := range guild.VoiceStates {
			if vs != nil && vs.ChannelID != "" {
				voiceCounts[vs.ChannelID]++
			}
		}
	}

	now := time.Now()
	for chID, lastEmpty := range channels {
		count := voiceCounts[chID]
		if count > 0 {
			s.teamMu.Lock()
			s.teamChannels[chID] = time.Time{}
			s.teamMu.Unlock()
			continue
		}
		if lastEmpty.IsZero() {
			s.teamMu.Lock()
			s.teamChannels[chID] = now
			s.teamMu.Unlock()
			continue
		}
		if now.Sub(lastEmpty) >= 10*time.Minute {
			waiting := strings.TrimSpace(s.waitingRoomID)
			ok := discordutil.EnqueueDelete(discordutil.DeleteTask{
				ChannelID:     chID,
				GuildID:       guildID,
				Hide:          true,
				MoveMembersTo: waiting,
				Reason:        "team vc idle cleanup",
			})
			if !ok {
				_, _ = sess.ChannelDelete(chID)
			}
			s.teamMu.Lock()
			delete(s.teamChannels, chID)
			s.teamMu.Unlock()
		}
	}
}

func (s *Service) cleanupOldThreads(sess *discordgo.Session) {
	if s == nil || sess == nil {
		return
	}
	s.ensureQueueThreadsTable()
	s.ensureThreadRows(sess)
	now := time.Now()
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	threads, err := storage.ListQueueThreads(ctx)
	if err != nil {
		log.Printf("queue: failed to load tracked threads: %v", err)
		return
	}
	if len(threads) == 0 {
		return
	}
	log.Printf("queue: running thread watcher (%d tracked)", len(threads))
	for _, thread := range threads {
		threadID := strings.TrimSpace(thread.ThreadID)
		if threadID == "" {
			continue
		}
		age := now.Sub(thread.CreatedAt)
		locked := false
		if age < 3*time.Hour {
			var lockErr error
			locked, lockErr = s.isThreadLocked(sess, threadID)
			if lockErr != nil {
				if isUnknownThread(lockErr) {
					s.deleteThreadRow(threadID)
					continue
				}
				log.Printf("queue: failed to read thread %s info: %v", threadID, lockErr)
				continue
			}
			if !locked {
				continue
			}
		}
		log.Printf("queue: deleting stale thread %s (age %s locked=%t)", threadID, age, locked)
		s.deleteThread(sess, threadID)
	}
}

func (s *Service) isThreadLocked(sess *discordgo.Session, threadID string) (bool, error) {
	if sess == nil || threadID == "" {
		return false, errors.New("session or thread id missing")
	}
	ch, err := sess.Channel(threadID)
	if err != nil {
		return false, err
	}
	if ch == nil {
		return false, errors.New("thread channel missing")
	}
	if ch.ThreadMetadata == nil {
		return false, nil
	}
	return ch.ThreadMetadata.Locked, nil
}

func (s *Service) deleteThreadRow(threadID string) {
	if s == nil {
		return
	}
	threadID = strings.TrimSpace(threadID)
	if threadID == "" {
		return
	}
	s.ensureQueueThreadsTable()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.DeleteQueueThread(ctx, threadID); err != nil {
		log.Printf("queue: failed to delete thread row %s: %v", threadID, err)
	}
}

func isUnknownThread(err error) bool {
	var restErr *discordgo.RESTError
	return errors.As(err, &restErr) && restErr.Message != nil && restErr.Message.Code == 10003
}

func formatEntryMapping(entries []Entry) string {
	if len(entries) == 0 {
		return "none"
	}
	var b strings.Builder
	for idx, e := range entries {
		if idx > 0 {
			b.WriteString(", ")
		}
		b.WriteString(fmt.Sprintf("<@%s>", e.UserID))
	}
	return b.String()
}

func userIDsFromEntries(entries []Entry) []string {
	if len(entries) == 0 {
		return nil
	}
	ids := make([]string, 0, len(entries))
	for _, e := range entries {
		if strings.TrimSpace(e.UserID) != "" {
			ids = append(ids, strings.TrimSpace(e.UserID))
		}
	}
	return ids
}

func (s *Service) loadPlayerNames(ctx context.Context, entries []Entry) map[string]string {
	ids := make([]string, 0, len(entries))
	for _, e := range entries {
		if strings.TrimSpace(e.PlayerID) != "" {
			ids = append(ids, e.PlayerID)
		}
	}
	names, err := storage.PlayerNameMap(ctx, ids)
	if err != nil {
		log.Printf("queue: failed to load player names: %v", err)
	}
	return names
}

func formatNames(entries []Entry, nameMap map[string]string) string {
	if len(entries) == 0 {
		return "None"
	}
	parts := make([]string, 0, len(entries))
	for _, e := range entries {
		name := strings.TrimSpace(nameMap[e.PlayerID])
		if name == "" {
			name = strings.TrimSpace(e.Username)
		}
		if name == "" {
			name = e.UserID
		}
		parts = append(parts, name)
	}
	return strings.Join(parts, ", ")
}

func formatInviteCommand(entries []Entry, nameMap map[string]string) string {
	if len(entries) == 0 {
		return ""
	}
	names := make([]string, 0, len(entries))
	for _, e := range entries {
		name := strings.TrimSpace(nameMap[e.PlayerID])
		if name == "" {
			name = strings.TrimSpace(e.Username)
		}
		if name == "" {
			name = e.UserID
		}

		// Remove any hidden whitespace that could break lines
		name = strings.ReplaceAll(name, "\r", "")
		name = strings.ReplaceAll(name, "\n", "")
		name = strings.ReplaceAll(name, "\t", "")

		names = append(names, name)
	}
	return strings.Join(names, " ")
}

func clonePermissionOverwrites(src []*discordgo.PermissionOverwrite) []*discordgo.PermissionOverwrite {
	if len(src) == 0 {
		return nil
	}
	out := make([]*discordgo.PermissionOverwrite, len(src))
	for i, ow := range src {
		if ow == nil {
			continue
		}
		copy := *ow
		out[i] = &copy
	}
	return out
}

func (s *Service) inheritCategoryOverwrites(sess *discordgo.Session, parentID string) []*discordgo.PermissionOverwrite {
	if sess == nil || strings.TrimSpace(parentID) == "" {
		return nil
	}
	parent, err := sess.Channel(parentID)
	if err != nil || parent == nil || parent.Type != discordgo.ChannelTypeGuildCategory {
		return nil
	}
	return clonePermissionOverwrites(parent.PermissionOverwrites)
}

func (s *Service) buildVoiceOverwrites(base []*discordgo.PermissionOverwrite, guildID string, allowedUsers []string, allowMask int64) []*discordgo.PermissionOverwrite {
	overwrites := clonePermissionOverwrites(base)
	denyMask := allowMask
	// Deny @everyone from connecting/speaking by default.
	overwrites = upsertOverwrite(overwrites, guildID, discordgo.PermissionOverwriteTypeRole, 0, denyMask)
	for _, userID := range allowedUsers {
		if strings.TrimSpace(userID) == "" {
			continue
		}
		overwrites = upsertOverwrite(overwrites, userID, discordgo.PermissionOverwriteTypeMember, allowMask, 0)
	}
	return overwrites
}

// BuildTeamVoiceOverwrites prepares permission overwrites for a team voice channel,
// allowing the provided users plus any configured bypass roles.
func (s *Service) BuildTeamVoiceOverwrites(base []*discordgo.PermissionOverwrite, guildID string, allowedUsers []string) []*discordgo.PermissionOverwrite {
	return s.buildVoiceOverwrites(base, guildID, allowedUsers, voiceAllowMask)
}

// BuildTeamVoiceOverwritesWithGuests prepares overwrites where team members can speak,
// but guests can only connect (muted). Guests receive a deny on speak to enforce mute.
func (s *Service) BuildTeamVoiceOverwritesWithGuests(base []*discordgo.PermissionOverwrite, guildID string, teamUsers, guestUsers []string) []*discordgo.PermissionOverwrite {
	overwrites := clonePermissionOverwrites(base)
	// Deny connect/speak by default.
	overwrites = upsertOverwrite(overwrites, guildID, discordgo.PermissionOverwriteTypeRole, 0, voiceAllowMask)

	// Team: allow connect + speak.
	for _, userID := range teamUsers {
		if strings.TrimSpace(userID) == "" {
			continue
		}
		overwrites = upsertOverwrite(overwrites, userID, discordgo.PermissionOverwriteTypeMember, voiceAllowMask, 0)
	}
	// Guests: allow connect, deny speak.
	for _, userID := range guestUsers {
		if strings.TrimSpace(userID) == "" {
			continue
		}
		overwrites = upsertOverwrite(overwrites, userID, discordgo.PermissionOverwriteTypeMember, int64(discordgo.PermissionVoiceConnect), int64(discordgo.PermissionVoiceSpeak))
	}
	return overwrites
}

func upsertOverwrite(list []*discordgo.PermissionOverwrite, id string, typ discordgo.PermissionOverwriteType, allowMask, denyMask int64) []*discordgo.PermissionOverwrite {
	for _, ow := range list {
		if ow != nil && ow.ID == id && ow.Type == typ {
			applyPermissionBits(ow, allowMask, denyMask)
			return list
		}
	}
	newOw := &discordgo.PermissionOverwrite{ID: id, Type: typ}
	applyPermissionBits(newOw, allowMask, denyMask)
	return append(list, newOw)
}

func applyPermissionBits(ow *discordgo.PermissionOverwrite, allowMask, denyMask int64) {
	if ow == nil {
		return
	}
	if allowMask != 0 {
		ow.Allow |= allowMask
		ow.Deny &^= allowMask
	}
	if denyMask != 0 {
		ow.Deny |= denyMask
		ow.Allow &^= denyMask
	}
}

func parseGameCategoryIndex(name string) int {
	name = strings.TrimSpace(name)
	if name == "" {
		return 0
	}
	if name == gameCategoryBaseName {
		return 1
	}
	prefix := gameCategoryBaseName + " #"
	if strings.HasPrefix(name, prefix) {
		numStr := strings.TrimSpace(strings.TrimPrefix(name, prefix))
		if num, err := strconv.Atoi(numStr); err == nil && num > 1 {
			return num
		}
	}
	return 0
}

func (s *Service) pickTeamCategory(sess *discordgo.Session, guildID, fallbackParentID string) (string, error) {
	s.categoryMu.Lock()
	defer s.categoryMu.Unlock()

	if sess == nil {
		if s.teamCategoryID != "" {
			return s.teamCategoryID, nil
		}
		return fallbackParentID, nil
	}

	channels, err := sess.GuildChannels(guildID)
	if err != nil {
		if s.teamCategoryID != "" {
			return s.teamCategoryID, err
		}
		return fallbackParentID, err
	}

	counts := make(map[string]int, len(channels))
	for _, ch := range channels {
		if ch != nil && ch.ParentID != "" {
			counts[ch.ParentID]++
		}
	}

	type catInfo struct {
		id    string
		index int
		count int
	}

	var preferred *catInfo
	var matches []catInfo
	maxIndex := 0

	for _, ch := range channels {
		if ch == nil || ch.Type != discordgo.ChannelTypeGuildCategory {
			continue
		}
		count := counts[ch.ID]
		if s.teamCategoryID != "" && ch.ID == s.teamCategoryID {
			preferred = &catInfo{id: ch.ID, index: 1, count: count}
		}
		if idx := parseGameCategoryIndex(ch.Name); idx > 0 {
			matches = append(matches, catInfo{id: ch.ID, index: idx, count: count})
			if idx > maxIndex {
				maxIndex = idx
			}
		}
	}

	if preferred != nil && preferred.count < 50 {
		return preferred.id, nil
	}

	var best catInfo
	found := false
	for _, cat := range matches {
		if cat.count >= 50 {
			continue
		}
		if !found || cat.index < best.index {
			best = cat
			found = true
		}
	}
	if found {
		return best.id, nil
	}

	nextIndex := 1
	if maxIndex > 0 {
		nextIndex = maxIndex + 1
	}

	name := gameCategoryBaseName
	if nextIndex > 1 {
		name = fmt.Sprintf("%s #%d", gameCategoryBaseName, nextIndex)
	}

	newCat, createErr := sess.GuildChannelCreateComplex(guildID, discordgo.GuildChannelCreateData{
		Name: name,
		Type: discordgo.ChannelTypeGuildCategory,
	})
	if createErr != nil {
		if s.teamCategoryID != "" {
			return s.teamCategoryID, createErr
		}
		if fallbackParentID != "" {
			return fallbackParentID, createErr
		}
		return "", createErr
	}
	return newCat.ID, nil
}

func (s *Service) Snapshots() []Snapshot {
	ms, ok := s.store.(*memoryStore)
	if !ok {
		return nil
	}
	ms.mu.Lock()
	defer ms.mu.Unlock()
	snaps := make([]Snapshot, 0, len(ms.states))
	for id, state := range ms.states {
		entries := make([]Entry, len(state.Entries))
		copy(entries, state.Entries)
		snaps = append(snaps, Snapshot{
			ChannelID: id,
			Config:    state.Config,
			Entries:   entries,
		})
	}
	return snaps
}

func loadSettingOrEnv(key string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if val, err := storage.GetSettingValue(ctx, key); err == nil && strings.TrimSpace(val) != "" {
		return strings.TrimSpace(val)
	}
	return strings.TrimSpace(os.Getenv(key))
}

func parseIDList(raw string) []string {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return nil
	}
	normalized := strings.ReplaceAll(raw, "|", ",")
	parts := strings.Split(normalized, ",")
	var ids []string
	for _, part := range parts {
		id := strings.TrimSpace(part)
		if id != "" {
			ids = append(ids, id)
		}
	}
	return ids
}

func interactionUserID(i *discordgo.InteractionCreate) string {
	if i == nil {
		return ""
	}
	if i.Member != nil && i.Member.User != nil {
		return strings.TrimSpace(i.Member.User.ID)
	}
	if i.User != nil {
		return strings.TrimSpace(i.User.ID)
	}
	return ""
}

func respondEphemeral(sess *discordgo.Session, i *discordgo.InteractionCreate, msg string) {
	if sess == nil || i == nil {
		return
	}
	content := strings.TrimSpace(msg)
	if content == "" {
		return
	}
	if err := sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Flags:   64,
			Content: content,
		},
	}); err != nil {
		_, _ = sess.FollowupMessageCreate(i.Interaction, true, &discordgo.WebhookParams{
			Content: content,
			Flags:   64,
		})
	}
}

// plainSelectMenuOption mirrors discordgo.SelectMenuOption but omits empty emoji fields.
type plainSelectMenuOption struct {
	Label       string                    `json:"label,omitempty"`
	Value       string                    `json:"value"`
	Description string                    `json:"description,omitempty"`
	Emoji       *discordgo.ComponentEmoji `json:"emoji,omitempty"`
	Default     bool                      `json:"default,omitempty"`
}

// plainSelectMenu mirrors discordgo.SelectMenu but uses plain options to avoid empty emoji payloads.
type plainSelectMenu struct {
	MenuType     discordgo.SelectMenuType `json:"-"`
	CustomID     string                   `json:"custom_id,omitempty"`
	Placeholder  string                   `json:"placeholder,omitempty"`
	MinValues    *int                     `json:"min_values,omitempty"`
	MaxValues    int                      `json:"max_values,omitempty"`
	Options      []plainSelectMenuOption  `json:"options,omitempty"`
	Disabled     bool                     `json:"disabled,omitempty"`
	ChannelTypes []discordgo.ChannelType  `json:"channel_types,omitempty"`
}

func (s plainSelectMenu) Type() discordgo.ComponentType {
	if s.MenuType != 0 {
		return discordgo.ComponentType(s.MenuType)
	}
	return discordgo.SelectMenuComponent
}

func (s plainSelectMenu) MarshalJSON() ([]byte, error) {
	type selectMenu plainSelectMenu
	return json.Marshal(struct {
		selectMenu
		Type discordgo.ComponentType `json:"type"`
	}{
		selectMenu: selectMenu(s),
		Type:       s.Type(),
	})
}
