package assets

import (
	"os"
	"path/filepath"

	"github.com/bwmarrin/discordgo"
)

// ThumbnailAttachment returns a thumbnail + attachment for a file in the data folder.
// If the file can't be opened, it returns nils and a no-op cleanup.
func ThumbnailAttachment(filename string) (*discordgo.MessageEmbedThumbnail, []*discordgo.File, func()) {
	path := filepath.Join("data", filename)
	file, err := os.Open(path)
	if err != nil {
		return nil, nil, func() {}
	}

	files := []*discordgo.File{
		{Name: filename, Reader: file},
	}
	thumb := &discordgo.MessageEmbedThumbnail{URL: "attachment://" + filename}
	return thumb, files, func() {
		_ = file.Close()
	}
}
