package help

import (
	"fmt"
	"log"
	"sort"
	"strings"

	"rbw-bot/internal/commands/shared"

	"github.com/bwmarrin/discordgo"
)

const helpSelectIDPrefix = "help_select:"

type Help struct{}

func NewHelp() *Help         { return &Help{} }
func (h *Help) Name() string { return "help" }

func (h *Help) Build() *discordgo.ApplicationCommand {
	var choices []*discordgo.ApplicationCommandOptionChoice
	for _, c := range HELP_ORDER {
		choices = append(choices, &discordgo.ApplicationCommandOptionChoice{Name: c, Value: c})
	}
	return &discordgo.ApplicationCommand{
		Name:        h.Name(),
		Description: "Show help categories and commands.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "category",
				Description: "Show a specific category",
				Choices:     choices,
			},
		},
	}
}

func (h *Help) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	log.Println("help: invoked")

	if err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	}); err != nil {
		log.Printf("help: respond (defer) error: %v", err)
		return
	}

	var (
		embed *discordgo.MessageEmbed
		comps []discordgo.MessageComponent
	)

	opts := i.ApplicationCommandData().Options
	if len(opts) > 0 && opts[0].Name == "category" {
		cat := opts[0].StringValue()
		embed = h.categoryEmbed(s, cat)
		if embed == nil {
			embed = &discordgo.MessageEmbed{Description: "Unknown category."}
		}
		comps = h.selectRow(cat, i.Member.User.ID)
	} else {
		embed = h.mainEmbed(s)
		comps = h.selectRow("", i.Member.User.ID)
	}

	embeds := []*discordgo.MessageEmbed{embed}
	if _, err := s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds:     &embeds,
		Components: &comps,
	}); err != nil {
		log.Printf("help: edit response error: %v", err)
	}
}

func (h *Help) HandleComponent(s *discordgo.Session, i *discordgo.InteractionCreate) bool {
	data := i.MessageComponentData()
	if !strings.HasPrefix(data.CustomID, helpSelectIDPrefix) {
		return false
	}
	ownerID := strings.TrimPrefix(data.CustomID, helpSelectIDPrefix)
	userID := i.Member.User.ID
	if userID == "" && i.User != nil {
		userID = i.User.ID
	}
	if userID != ownerID {
		shared.RespondEphemeral(s, i, "Only the original user can use this help menu.")
		return true
	}

	vals := data.Values
	cat := ""
	if len(vals) > 0 {
		cat = vals[0]
	}
	if cat == "all" {
		cat = ""
	}

	var embed *discordgo.MessageEmbed
	if cat == "" {
		embed = h.mainEmbed(s)
	} else {
		embed = h.categoryEmbed(s, cat)
		if embed == nil {
			embed = &discordgo.MessageEmbed{Description: "Unknown category."}
		}
	}

	return s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseUpdateMessage,
		Data: &discordgo.InteractionResponseData{
			Embeds:     []*discordgo.MessageEmbed{embed},
			Components: h.selectRow(cat, ownerID),
		},
	}) == nil
}

func (h *Help) mainEmbed(s *discordgo.Session) *discordgo.MessageEmbed {
	lines := make([]string, 0, len(HELP_ORDER))
	for idx, name := range HELP_ORDER {
		blurb := HELP_BLURB[name]
		lines = append(lines, fmt.Sprintf("**%d. %s** %s\n", idx+1, name, blurb))
	}
	return &discordgo.MessageEmbed{
		Title:       "Ranked Bedwars Help Menu",
		Description: strings.Join(lines, ""),
		Thumbnail:   &discordgo.MessageEmbedThumbnail{URL: shared.BotAvatarURL(s)},
		Color:       shared.DefaultEmbedColor,
		Footer:      &discordgo.MessageEmbedFooter{Text: "Ranked Bedwars"},
	}
}

func (h *Help) categoryEmbed(s *discordgo.Session, category string) *discordgo.MessageEmbed {
	items, ok := HELP_CATEGORIES[category]
	if !ok {
		return nil
	}

	sort.SliceStable(items, func(i, j int) bool { return items[i].Cmd < items[j].Cmd })
	descLines := make([]string, 0, len(items))
	for _, it := range items {
		descLines = append(descLines, fmt.Sprintf("**%s**\n%s", it.Cmd, it.Desc))
	}
	return &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Ranked Bedwars Help Menu - %s", category),
		Description: strings.Join(descLines, "\n"),
		Thumbnail:   &discordgo.MessageEmbedThumbnail{URL: shared.BotAvatarURL(s)},
		Color:       shared.DefaultEmbedColor,
		Footer:      &discordgo.MessageEmbedFooter{Text: "Ranked Bedwars"},
	}
}

func (h *Help) selectRow(current, ownerID string) []discordgo.MessageComponent {
	mk := func(label, value, desc, emoji string, def bool) discordgo.SelectMenuOption {
		return discordgo.SelectMenuOption{
			Label:       label,
			Value:       value,
			Description: desc,
			Emoji:       discordgo.ComponentEmoji{Name: emoji},
			Default:     def,
		}
	}

	emojiByCat := map[string]string{
		"Embeds":     "🖼️",
		"Game":       "🎮",
		"Moderation": "🛡️",
		"Party":      "🎉",
		"Pit":        "🔥",
		"Premium":    "💎",
		"Pugs":       "🐶",
		"PUGS Spec":  "🔍",
		"PUGS Trial": "📝",
		"Pups":       "🐾",
		"Season":     "📅",
		"Settings":   "⚙️",
	}

	var opts []discordgo.SelectMenuOption
	opts = append(opts, mk("All Categories", "all", "Show the main menu", "📚", current == ""))
	for _, name := range HELP_ORDER {
		opts = append(opts, mk(name, name, HELP_BLURB[name], emojiByCat[name], current == name))
	}

	return []discordgo.MessageComponent{
		discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{
				discordgo.SelectMenu{
					CustomID:    helpSelectIDPrefix + ownerID,
					Placeholder: "Select a Category",
					Options:     opts,
					MenuType:    discordgo.StringSelectMenu,
				},
			},
		},
	}
}
