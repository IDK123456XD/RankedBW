package registration

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
)

const (
	fullSkinURL = "https://starlightskins.lunareclipse.studio/render/ultimate/%s/full"
	headSkinURL = "https://starlightskins.lunareclipse.studio/render/head/%s/full"
)

// MojangUUID resolves a Minecraft username to its UUID using Mojang's API.
func MojangUUID(ctx context.Context, ign string) (string, error) {
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet,
		"https://api.mojang.com/users/profiles/minecraft/"+ign, nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode == http.StatusNoContent || resp.StatusCode == http.StatusNotFound {
		return "", fmt.Errorf("IGN not found on Mojang")
	}
	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(resp.Body)
		return "", fmt.Errorf("mojang %d: %s", resp.StatusCode, string(b))
	}
	var obj struct {
		ID string `json:"id"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&obj); err != nil {
		return "", err
	}
	if obj.ID == "" {
		return "", fmt.Errorf("mojang returned empty id")
	}
	return obj.ID, nil
}

// HypixelDiscord fetches the linked Discord username and display name from the Hypixel API.
func HypixelDiscord(ctx context.Context, apiKey, uuid string) (string, string, error) {
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet,
		"https://api.hypixel.net/player?uuid="+uuid, nil)
	req.Header.Set("API-Key", apiKey)

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(resp.Body)
		return "", "", fmt.Errorf("hypixel %d: %s", resp.StatusCode, string(b))
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", "", err
	}

	var obj struct {
		Success bool `json:"success"`
		Player  *struct {
			DisplayName string `json:"displayname"`
			SocialMedia *struct {
				Links map[string]string `json:"links"`
			} `json:"socialMedia"`
		} `json:"player"`
	}
	if err := json.Unmarshal(body, &obj); err != nil {
		return "", "", err
	}

	if !obj.Success || obj.Player == nil || obj.Player.SocialMedia == nil {
		return "", "", fmt.Errorf("no player/social media found")
	}
	log.Printf("Hypixel lookup: uuid=%s displayName=%s discord=%s", uuid, obj.Player.DisplayName, obj.Player.SocialMedia.Links["DISCORD"])
	return obj.Player.SocialMedia.Links["DISCORD"], obj.Player.DisplayName, nil
}

// FetchSkinBase64 downloads the image at the provided URL and returns its base64 encoding.
func FetchSkinBase64(ctx context.Context, url string) (string, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return "", err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("skin fetch %d", resp.StatusCode)
	}
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(data), nil
}
