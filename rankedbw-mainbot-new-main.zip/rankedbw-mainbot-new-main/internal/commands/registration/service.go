package registration

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"rbw-bot/internal/storage"

	"github.com/jackc/pgx/v5/pgconn"
)

// Params represents the profile data required to store/update a player.
type Params struct {
	UserID      string
	IGN         string
	DisplayName string
	UUID        string
}

// Result summarizes the outcome of a registration action.
type Result struct {
	PlayerID      string
	MinecraftName string
	Refreshed     bool
	Elo           int
}

// ErrDuplicatePlayer indicates a record already exists with conflicting data.
var ErrDuplicatePlayer = errors.New("player already registered to another discord account")

// UpsertPlayer stores or updates a player's profile and ensures seasonal stats.
func UpsertPlayer(ctx context.Context, params Params) (*Result, error) {
	name := strings.TrimSpace(params.DisplayName)
	if name == "" {
		name = strings.TrimSpace(params.IGN)
	}
	uuid := strings.TrimSpace(params.UUID)
	if params.UserID == "" || name == "" || uuid == "" {
		return nil, errors.New("invalid registration payload")
	}

	fullSkin, err := FetchSkinBase64(ctx, fmt.Sprintf(fullSkinURL, uuid))
	if err != nil {
		return nil, fmt.Errorf("failed to fetch player skin: %w", err)
	}
	headSkin, err := FetchSkinBase64(ctx, fmt.Sprintf(headSkinURL, uuid))
	if err != nil {
		return nil, fmt.Errorf("failed to fetch player skin: %w", err)
	}

	defaultInfocard, err := storage.DefaultInfocardID(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch default infocard: %w", err)
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch active season: %w", err)
	}

	player, err := storage.GetPlayerByUserID(ctx, params.UserID)
	if err != nil {
		return nil, fmt.Errorf("failed to look up player: %w", err)
	}

	refreshed := player != nil
	var playerID string
	if refreshed {
		if err := storage.UpdatePlayerProfile(ctx, player.ID, name, uuid, fullSkin, headSkin, defaultInfocard); err != nil {
			return nil, fmt.Errorf("failed to update profile: %w", err)
		}
		playerID = player.ID
	} else {
		playerID, err = storage.CreatePlayer(ctx, params.UserID, name, uuid, fullSkin, headSkin, defaultInfocard)
		if err != nil {
			var pgErr *pgconn.PgError
			if errors.As(err, &pgErr) && pgErr.Code == "23505" {
				return nil, ErrDuplicatePlayer
			}
			return nil, fmt.Errorf("failed to create player: %w", err)
		}
	}

	if err := storage.GrantStandardInfocards(ctx, playerID); err != nil {
		return nil, fmt.Errorf("failed to grant standard infocards: %w", err)
	}

	if err := storage.EnsurePlayerSeasonStats(ctx, playerID, seasonID); err != nil {
		return nil, fmt.Errorf("failed to ensure season stats: %w", err)
	}

	elo, err := storage.PlayerSeasonElo(ctx, playerID, seasonID)
	if err != nil {
		return nil, fmt.Errorf("failed to fetch player elo: %w", err)
	}

	return &Result{
		PlayerID:      playerID,
		MinecraftName: name,
		Refreshed:     refreshed,
		Elo:           elo,
	}, nil
}

// BuildNickname returns the standard nickname format with elo prefix.
func BuildNickname(elo int, ign string) string {
	return fmt.Sprintf("[%d] %s", elo, ign)
}
