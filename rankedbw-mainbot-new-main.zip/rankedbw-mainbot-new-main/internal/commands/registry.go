package commands

import (
	"log"

	embedscmd "rbw-bot/internal/commands/embeds"
	gamecmd "rbw-bot/internal/commands/game"
	helpcmd "rbw-bot/internal/commands/help"
	howtocmd "rbw-bot/internal/commands/howtoregister"
	misccmd "rbw-bot/internal/commands/misc"
	partycmd "rbw-bot/internal/commands/party"
	seasoncmd "rbw-bot/internal/commands/season"
	settingscmd "rbw-bot/internal/commands/settings"
	staffcmd "rbw-bot/internal/commands/staff"
	"rbw-bot/internal/commands/types"
	"rbw-bot/internal/party"
	"rbw-bot/internal/queue"

	"github.com/bwmarrin/discordgo"
)

type Registry struct {
	cmds      []types.Slash
	compCmds  []types.ComponentHandler
	modalCmds []types.ModalHandler
}

func NewRegistry(partySvc *party.Service, queueSvc *queue.Service) *Registry {
	r := &Registry{}

	help := helpcmd.NewHelp()
	partyCmd := partycmd.NewParty(partySvc)
	submitCmd := staffcmd.NewScore()     // /submit proof upload
	scoreCmd := staffcmd.NewStaffScore() // /score staff scoring
	voidCmd := staffcmd.NewVoid()        // /void staff + player vote
	leaderboard := gamecmd.NewLeaderboard()
	historyCmd := gamecmd.NewHistory()
	lockerCmd := gamecmd.NewLocker()
	pickingCmd := gamecmd.NewPicking(queueSvc)
	screenshare := staffcmd.NewScreenshare()
	roleListPager := staffcmd.NewRoleListPager()
	r.cmds = append(r.cmds,
		misccmd.NewPing(),
		partycmd.NewParty(partySvc),
		help,
		settingscmd.NewSettings(queueSvc),
		seasoncmd.NewSeason(),
		staffcmd.NewEmbed(),
		staffcmd.NewStaff(),
		staffcmd.NewForceRegister(),
		staffcmd.NewLossVoid(),
		voidCmd,
		staffcmd.NewUndo(),
		submitCmd,
		scoreCmd,
		staffcmd.NewUnscore(),
		staffcmd.NewPit(),
		staffcmd.NewPremium(),
		staffcmd.NewPugs(),
		staffcmd.NewPugsSpec(),
		staffcmd.NewPugsTrial(),
		staffcmd.NewPups(),
		staffcmd.NewMute(),
		staffcmd.NewModify(),
		staffcmd.NewMVP(),
		staffcmd.NewStrike(),
		staffcmd.NewClaimEloConfig(),
		staffcmd.NewStrikeRemove(),
		staffcmd.NewUnmute(),
		staffcmd.NewUnregister(),
		staffcmd.NewResetStats(),
		staffcmd.NewStatResetConfig(),
		staffcmd.NewPunishments(),
		staffcmd.NewInfocard(),
		staffcmd.NewRankedBan(),
		staffcmd.NewRankedUnban(),
		staffcmd.NewScoringLeaderboard(),
		staffcmd.NewSSLeaderboard(),
		staffcmd.NewAudit(),
		staffcmd.NewRefresh(),
		staffcmd.NewRescore(),
		staffcmd.NewRankConfig(),
		staffcmd.NewQueueConfig(queueSvc),
		staffcmd.NewClean(),
		staffcmd.NewClose(),
		staffcmd.NewVoiceCleanup(),
		embedscmd.NewRules(),
		howtocmd.New(),
		gamecmd.NewRegister(),
		lockerCmd,
		gamecmd.NewInfo(),
		gamecmd.NewTogglePrefix(),
		gamecmd.NewTestScore(),
		gamecmd.NewStatReset(),
		gamecmd.NewGame(),
		gamecmd.NewGames(),
		gamecmd.NewNick(),
		gamecmd.NewRemoveNick(),
		gamecmd.NewRename(),
		leaderboard,
		historyCmd,
		gamecmd.NewMap(),
		staffcmd.NewMapConfig(),
		gamecmd.NewRanks(),
		gamecmd.NewUpdate(),
		gamecmd.NewUserInfo(),
		gamecmd.NewQueueStats(queueSvc),
		gamecmd.NewClaimElo(),
		gamecmd.NewCall(queueSvc),
		screenshare,
		staffcmd.NewFreezeCmd(),
		staffcmd.NewUnfreezeCmd(),
		staffcmd.NewSSCloseCmd(screenshare),
		staffcmd.NewScreenshareManage(),
	)

	r.compCmds = append(r.compCmds, help, partyCmd, submitCmd, voidCmd, screenshare, leaderboard, historyCmd, lockerCmd, pickingCmd)
	r.compCmds = append(r.compCmds, roleListPager)
	r.modalCmds = append(r.modalCmds, submitCmd)

	return r
}

func (r *Registry) RegisterGuild(s *discordgo.Session, appID, guildID string) error {
	var defs []*discordgo.ApplicationCommand
	for _, c := range r.cmds {
		defs = append(defs, c.Build())
	}
	_, err := s.ApplicationCommandBulkOverwrite(appID, guildID, defs)
	if err != nil {
		log.Printf("command registration failed: %v", err)
	}
	return err
}

func (r *Registry) CleanupGuild(s *discordgo.Session, appID, guildID string) error {
	current, err := s.ApplicationCommands(appID, guildID)
	if err != nil {
		return err
	}
	for _, c := range current {
		_ = s.ApplicationCommandDelete(appID, guildID, c.ID)
	}
	return nil
}

func (r *Registry) Dispatch(s *discordgo.Session, i *discordgo.InteractionCreate) {
	name := i.ApplicationCommandData().Name
	for _, c := range r.cmds {
		if c.Name() == name {
			c.Handle(s, i)
			return
		}
	}
}

func (r *Registry) DispatchAutocomplete(s *discordgo.Session, i *discordgo.InteractionCreate) {
	name := i.ApplicationCommandData().Name
	for _, c := range r.cmds {
		if c.Name() == name {
			if handler, ok := c.(types.Autocomplete); ok {
				handler.HandleAutocomplete(s, i)
			}
			return
		}
	}
}

func (r *Registry) DispatchComponent(s *discordgo.Session, i *discordgo.InteractionCreate) {
	for _, h := range r.compCmds {
		if handled := h.HandleComponent(s, i); handled {
			return
		}
	}
}

func (r *Registry) DispatchModal(s *discordgo.Session, i *discordgo.InteractionCreate) {
	for _, h := range r.modalCmds {
		if handled := h.HandleModal(s, i); handled {
			return
		}
	}
}

// SetSession forwards the session to any handlers that need it at startup.
func (r *Registry) SetSession(s *discordgo.Session) {
	if s == nil {
		return
	}
	for _, c := range r.cmds {
		if aware, ok := c.(types.SessionAware); ok {
			aware.SetSession(s)
		}
	}
	for _, c := range r.compCmds {
		if aware, ok := c.(types.SessionAware); ok {
			aware.SetSession(s)
		}
	}
	for _, c := range r.modalCmds {
		if aware, ok := c.(types.SessionAware); ok {
			aware.SetSession(s)
		}
	}
}
