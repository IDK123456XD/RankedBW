package game

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

var forbiddenNickWords = []string{"nigger", "nigga", "faggot", "cunt", "whore"}

type Nick struct{}

func NewNick() *Nick         { return &Nick{} }
func (c *Nick) Name() string { return "nick" }
func (c *Nick) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Set your Hypixel nickname in discord.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "nickname",
				Description: "Your Hypixel nickname.",
				Required:    true,
			},
		},
	}
}

func (c *Nick) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	raw := strings.TrimSpace(i.ApplicationCommandData().Options[0].StringValue())
	if err := validateNickname(raw); err != nil {
		shared.Respond(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, stats, err := loadPlayerAndStats(ctx, i.Member.User.ID)
	if err != nil {
		shared.EditError(s, i, err.Error())
		return
	}

	if err := storage.SetPlayerNickname(ctx, player.ID, raw); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update nickname: %v", err))
		return
	}

	display := shared.SanitizeNickname(composeDisplayName(player, stats, &raw))
	if err := s.GuildMemberNickname(i.GuildID, player.UserID, display); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to change Discord nickname: %v", err))
		return
	}

	msg := fmt.Sprintf("Your Hypixel nickname has been set to `%s`.", raw)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}

func validateNickname(nick string) error {
	if len(nick) == 0 {
		return fmt.Errorf("Please provide a nickname.")
	}
	if len(nick) > 16 {
		return fmt.Errorf("Your nickname cannot be longer than 16 characters.")
	}
	if strings.Contains(nick, " ") {
		return fmt.Errorf("Your nickname cannot contain spaces.")
	}
	lower := strings.ToLower(nick)
	for _, bad := range forbiddenNickWords {
		if strings.Contains(lower, bad) {
			return fmt.Errorf("Your nickname contains forbidden language.")
		}
	}
	return nil
}

func loadPlayerAndStats(ctx context.Context, userID string) (*storage.PlayerRecord, *storage.PlayerSeasonStats, error) {
	player, err := storage.GetPlayerByUserID(ctx, userID)
	if err != nil {
		return nil, nil, fmt.Errorf("Failed to load your profile: %v", err)
	}
	if player == nil {
		return nil, nil, fmt.Errorf("You are not registered yet. Please use `/register` first.")
	}
	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		return nil, nil, fmt.Errorf("Failed to determine active season: %v", err)
	}
	if err := storage.EnsurePlayerSeasonStats(ctx, player.ID, seasonID); err != nil {
		return nil, nil, fmt.Errorf("Failed to prepare your stats: %v", err)
	}
	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil {
		return nil, nil, fmt.Errorf("Failed to load your stats: %v", err)
	}
	if stats == nil {
		return nil, nil, fmt.Errorf("You do not have stats for the active season.")
	}
	return player, stats, nil
}
