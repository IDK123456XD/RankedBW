package game

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/maps"

	"github.com/bwmarrin/discordgo"
)

type Map struct{}

func NewMap() *Map          { return &Map{} }
func (c *Map) Name() string { return "map" }
func (c *Map) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "View the maps in the queue.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "name",
				Description: "Filter by map name.",
			},
		},
	}
}

func (c *Map) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	filter := ""
	for _, opt := range i.ApplicationCommandData().Options {
		if opt.Name == "name" {
			filter = strings.ToLower(strings.TrimSpace(opt.StringValue()))
			break
		}
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	allMaps := maps.QueueMaps(ctx)
	var selected []maps.Info
	if filter == "" {
		selected = allMaps
	} else {
		for _, m := range allMaps {
			if strings.Contains(strings.ToLower(m.Name), filter) {
				selected = append(selected, m)
			}
		}
	}

	if len(selected) == 0 {
		shared.RespondEphemeral(s, i, "No maps matched that search.")
		return
	}

	const maxFields = 25 // Discord embed field limit
	embeds := make([]*discordgo.MessageEmbed, 0, (len(selected)+maxFields-1)/maxFields)
	for start := 0; start < len(selected); start += maxFields {
		end := start + maxFields
		if end > len(selected) {
			end = len(selected)
		}
		fields := make([]*discordgo.MessageEmbedField, 0, end-start)
		for _, m := range selected[start:end] {
			value := fmt.Sprintf("Height Limit: **%d**", m.Height)
			fields = append(fields, &discordgo.MessageEmbedField{
				Name:  m.Name,
				Value: value,
			})
		}
		title := "Queue Maps"
		if len(selected) > maxFields {
			title = fmt.Sprintf("Queue Maps (%d-%d of %d)", start+1, end, len(selected))
		}
		embeds = append(embeds, &discordgo.MessageEmbed{
			Title:       title,
			Description: "Here are the maps currently in the rotation.",
			Color:       shared.DefaultEmbedColor,
			Fields:      fields,
		})
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: embeds,
		},
	})
}
