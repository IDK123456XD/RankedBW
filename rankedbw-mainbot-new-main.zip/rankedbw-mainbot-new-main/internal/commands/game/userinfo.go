package game

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type UserInfo struct{}

func NewUserInfo() *UserInfo     { return &UserInfo{} }
func (c *UserInfo) Name() string { return "userinfo" }
func (c *UserInfo) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Shows Discord ID, Minecraft UUID, and registration date.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "discord",
				Description: "Discord user to inspect (defaults to yourself).",
				Required:    false,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "uuid",
				Description: "Minecraft UUID to lookup (overrides discord option).",
				Required:    false,
			},
		},
	}
}

func (c *UserInfo) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	targetUser := i.Member.User
	var uuid string

	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "discord":
			if user := opt.UserValue(s); user != nil {
				targetUser = user
			}
		case "uuid":
			uuid = strings.TrimSpace(opt.StringValue())
		}
	}

	if targetUser == nil && uuid == "" {
		shared.RespondEphemeral(s, i, "Unable to determine which user to look up.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var (
		player *storage.PlayerRecord
		err    error
	)
	if uuid != "" {
		player, err = storage.GetPlayerByUUID(ctx, uuid)
	} else if targetUser != nil {
		player, err = storage.GetPlayerByUserID(ctx, targetUser.ID)
	}
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "Player not found in the database.")
		return
	}

	regTime := "Unknown"
	if !player.CreatedAt.IsZero() {
		sec := player.CreatedAt.Unix()
		regTime = fmt.Sprintf("<t:%d:F> (<t:%d:R>)", sec, sec)
	}

	discordTag := "Unknown"
	if player.UserID != "" {
		discordTag = fmt.Sprintf("<@%s>", player.UserID)
	}

	desc := fmt.Sprintf("**Discord ID:** `%s`\n**Discord Tag:** %s\n**Minecraft IGN:** %s\n**Minecraft UUID:** `%s`\n**Registered:** %s",
		player.UserID, discordTag, player.MinecraftName, player.UUID, regTime)

	embed := &discordgo.MessageEmbed{
		Title:       "User Information",
		Description: desc,
		Color:       0x3498DB,
	}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{embed},
	})
}
