package game

import "github.com/bwmarrin/discordgo"

// Games is an alias for /history.
type Games struct{}

func NewGames() *Games        { return &Games{} }
func (c *Games) Name() string { return "games" }

func (c *Games) Build() *discordgo.ApplicationCommand {
	cmd := NewHistory().Build()
	cmd.Name = c.Name()
	cmd.Description = "Alias for /history."
	return cmd
}

func (c *Games) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	NewHistory().Handle(s, i)
}

func (c *Games) HandleAutocomplete(s *discordgo.Session, i *discordgo.InteractionCreate) {
	NewHistory().HandleAutocomplete(s, i)
}

