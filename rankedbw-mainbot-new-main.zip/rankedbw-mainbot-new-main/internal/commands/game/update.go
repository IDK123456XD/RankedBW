package game

import (
	"context"
	"fmt"
	"log"
	"regexp"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/rolecommands"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Update struct{}

func NewUpdate() *Update       { return &Update{} }
func (c *Update) Name() string { return "update" }

func (c *Update) Build() *discordgo.ApplicationCommand {
	scopeChoices := []*discordgo.ApplicationCommandOptionChoice{
		{Name: "Self", Value: "self"},
		{Name: "ALL (admin only)", Value: "all"},
	}
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Sync your roles and nickname with your current ELO.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "scope",
				Description: "Who to update (default: self).",
				Choices:     scopeChoices,
			},
		},
	}
}

func (c *Update) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	scope := "self"
	for _, opt := range i.ApplicationCommandData().Options {
		if opt.Name == "scope" && strings.TrimSpace(opt.StringValue()) != "" {
			scope = strings.ToLower(strings.TrimSpace(opt.StringValue()))
		}
	}

	if scope == "all" {
		c.handleAll(s, i)
		return
	}

	c.handleSelf(s, i)
}

func (c *Update) handleSelf(s *discordgo.Session, i *discordgo.InteractionCreate) {
	var user *discordgo.User
	if i.Member != nil && i.Member.User != nil {
		user = i.Member.User
	} else if i.User != nil {
		user = i.User
	}
	if user == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve your Discord user.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, user.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load your player data: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "You are not registered. Please use `/register` first.")
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to locate active season: %v", err))
		return
	}
	if err := storage.EnsurePlayerSeasonStats(ctx, player.ID, seasonID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to prepare your stats: %v", err))
		return
	}
	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil || stats == nil {
		shared.EditError(s, i, "Unable to load your seasonal stats.")
		return
	}

	var warnings []string
	if warn := c.updateNickname(s, i.GuildID, player, stats); warn != "" {
		warnings = append(warnings, warn)
	}
	if warn := c.updateEloRoles(s, i.GuildID, user.ID, stats.Elo); warn != "" {
		warnings = append(warnings, warn)
	}
	if warn := shared.ApplyRegisterRole(s, i.GuildID, user.ID, "update command"); warn != "" {
		warnings = append(warnings, warn)
	}

	msg := "Done. Your roles and nickname have been synced with the database."
	if len(warnings) > 0 {
		msg += "\nWarnings:\n- " + strings.Join(warnings, "\n- ")
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &msg,
	})
}

func (c *Update) updateNickname(s *discordgo.Session, guildID string, player *storage.PlayerRecord, stats *storage.PlayerSeasonStats) string {
	if player == nil || !player.EloPrefix {
		return ""
	}
	display := shared.BuildDisplayName(player, stats)
	if strings.TrimSpace(display) == "" {
		return "Could not determine a nickname format from your profile."
	}
	if err := s.GuildMemberNickname(guildID, player.UserID, display); err != nil {
		log.Printf("update command: failed to update nickname for %s: %v", player.UserID, err)
		return "Failed to update your nickname (missing permissions?)."
	}
	return ""
}

func (c *Update) updateEloRoles(s *discordgo.Session, guildID, userID string, elo int) string {
	return shared.ApplyRankRole(s, guildID, userID, elo, "update command")
}

type bulkUpdateStats struct {
	membersTotal   int
	botsSkipped    int
	membersScanned int
	playersFound   int

	seasonStatsInserted int

	nickUpdated       int
	nickMismatchCount int
	nickFailedCount   int
	nickFailed        []string

	roleWarnCount int
	roleWarn      []string
	regWarnCount  int
	regWarn       []string

	unregisteredSuspectsCount int
	unregisteredSuspects      []string
	dbErrorCount              int
	dbErrors                  []string
}

func (c *Update) handleAll(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if i == nil || i.GuildID == "" {
		shared.RespondEphemeral(s, i, "This command can only be used in a server.")
		return
	}
	if i.Member == nil || (i.Member.Permissions&discordgo.PermissionAdministrator) == 0 {
		shared.RespondEphemeral(s, i, "You do not have permission to run `/update scope: all`.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	start := time.Now()

	seasonCtx, seasonCancel := context.WithTimeout(context.Background(), 15*time.Second)
	seasonID, err := storage.ActiveSeasonID(seasonCtx)
	seasonCancel()
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to locate active season: %v", err))
		return
	}

	rankCtx, rankCancel := context.WithTimeout(context.Background(), 15*time.Second)
	ranks, err := storage.ListRanks(rankCtx)
	rankCancel()
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load rank configuration: %v", err))
		return
	}
	rankRoleIDs := make(map[string]struct{}, len(ranks))
	for _, r := range ranks {
		if strings.TrimSpace(r.RoleID) != "" {
			rankRoleIDs[strings.TrimSpace(r.RoleID)] = struct{}{}
		}
	}

	registerRoleID := strings.TrimSpace(shared.SettingOrEnv("REGISTER_RANK"))

	ensureCtx, ensureCancel := context.WithTimeout(context.Background(), 60*time.Second)
	inserted, err := storage.EnsureAllPlayerSeasonStats(ensureCtx, seasonID)
	ensureCancel()
	if err != nil {
		log.Printf("update all: failed to ensure season stats for all players: %v", err)
	}

	playerCtx, playerCancel := context.WithTimeout(context.Background(), 30*time.Second)
	players, err := storage.AllPlayers(playerCtx)
	playerCancel()
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load players from DB: %v", err))
		return
	}
	playerByUserID := make(map[string]*storage.PlayerRecord, len(players))
	for idx := range players {
		p := &players[idx]
		if strings.TrimSpace(p.UserID) == "" {
			continue
		}
		playerByUserID[p.UserID] = p
	}

	eloCtx, eloCancel := context.WithTimeout(context.Background(), 30*time.Second)
	eloByPlayerID, err := storage.SeasonEloByPlayerID(eloCtx, seasonID)
	eloCancel()
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load season stats from DB: %v", err))
		return
	}

	members, err := rolecommands.FetchAllMembers(s, i.GuildID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch server members: %v", err))
		return
	}

	stats := bulkUpdateStats{membersTotal: len(members), seasonStatsInserted: inserted}

	initial := fmt.Sprintf("Starting bulk `/update`...\nMembers: %d", stats.membersTotal)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &initial,
		AllowedMentions: &discordgo.MessageAllowedMentions{
			Parse: []discordgo.AllowedMentionType{},
		},
	})

	eloNick := regexp.MustCompile(`^\\[(\\d+)\\]\\s+`)
	maxList := 25

	for idx, member := range members {
		if member == nil || member.User == nil {
			continue
		}
		if member.User.Bot {
			stats.botsSkipped++
			continue
		}
		stats.membersScanned++

		userID := member.User.ID

		player := playerByUserID[userID]
		if player == nil {
			if looksRegistered(member, registerRoleID, rankRoleIDs, eloNick) {
				stats.unregisteredSuspectsCount++
				appendCapped(&stats.unregisteredSuspects, fmt.Sprintf("<@%s>", userID), maxList)
			}
			continue
		}
		stats.playersFound++

		elo, ok := eloByPlayerID[player.ID]
		if !ok {
			stats.dbErrorCount++
			appendCapped(&stats.dbErrors, fmt.Sprintf("<@%s> (missing season stats row)", userID), maxList)
			elo = 0
		}
		ps := &storage.PlayerSeasonStats{Elo: elo}

		if player.EloPrefix {
			expected := strings.TrimSpace(shared.BuildDisplayName(player, ps))
			if expected == "" {
				stats.nickFailedCount++
				appendCapped(&stats.nickFailed, fmt.Sprintf("<@%s> (could not build nickname)", userID), maxList)
			} else if member.Nick != expected {
				stats.nickMismatchCount++
				if err := s.GuildMemberNickname(i.GuildID, userID, expected); err != nil {
					stats.nickFailedCount++
					appendCapped(&stats.nickFailed, fmt.Sprintf("<@%s> (%s)", userID, trimMiddle(err.Error(), 80)), maxList)
				} else {
					stats.nickUpdated++
				}
			}
		}

		if warn := applyRankRoleBulk(s, i.GuildID, userID, member.Roles, ranks, elo); warn != "" {
			stats.roleWarnCount++
			appendCapped(&stats.roleWarn, fmt.Sprintf("<@%s> (%s)", userID, warn), maxList)
		}
		if warn := applyRegisterRoleBulk(s, i.GuildID, userID, member.Roles, registerRoleID); warn != "" {
			stats.regWarnCount++
			appendCapped(&stats.regWarn, fmt.Sprintf("<@%s> (%s)", userID, warn), maxList)
		}

		if idx > 0 && idx%50 == 0 {
			progress := fmt.Sprintf(
				"Bulk `/update` running...\nProcessed: %d/%d\nPlayers found: %d\nNicknames updated: %d\nNickname mismatches: %d",
				idx+1,
				stats.membersTotal,
				stats.playersFound,
				stats.nickUpdated,
				stats.nickMismatchCount,
			)
			_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
				Content: &progress,
				AllowedMentions: &discordgo.MessageAllowedMentions{
					Parse: []discordgo.AllowedMentionType{},
				},
			})
		}
	}

	final := formatBulkUpdateSummary(stats, start, len(ranks), registerRoleID != "")
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &final,
		AllowedMentions: &discordgo.MessageAllowedMentions{
			Parse: []discordgo.AllowedMentionType{},
		},
	})
}

func looksRegistered(member *discordgo.Member, registerRoleID string, rankRoleIDs map[string]struct{}, eloNick *regexp.Regexp) bool {
	if member == nil {
		return false
	}
	if strings.TrimSpace(registerRoleID) != "" {
		for _, rid := range member.Roles {
			if rid == registerRoleID {
				return true
			}
		}
	}
	for _, rid := range member.Roles {
		if _, ok := rankRoleIDs[rid]; ok {
			return true
		}
	}
	if member.Nick != "" && eloNick != nil && eloNick.MatchString(member.Nick) {
		return true
	}
	if member.User != nil && member.User.Username != "" && eloNick != nil && eloNick.MatchString(member.User.Username) {
		return true
	}
	return false
}

func applyRegisterRoleBulk(s *discordgo.Session, guildID, userID string, currentRoles []string, registerRoleID string) string {
	registerRoleID = strings.TrimSpace(registerRoleID)
	if s == nil || guildID == "" || userID == "" || registerRoleID == "" {
		return ""
	}
	for _, rid := range currentRoles {
		if rid == registerRoleID {
			return ""
		}
	}
	if err := s.GuildMemberRoleAdd(guildID, userID, registerRoleID); err != nil {
		log.Printf("update all: failed to add register role %s to %s: %v", registerRoleID, userID, err)
		return "failed to assign register role"
	}
	return ""
}

func applyRankRoleBulk(s *discordgo.Session, guildID, userID string, currentRoles []string, ranks []storage.RankRecord, elo int) string {
	if s == nil || guildID == "" || userID == "" {
		return ""
	}
	if len(ranks) == 0 {
		return ""
	}

	var target *storage.RankRecord
	for idx := range ranks {
		r := &ranks[idx]
		if elo >= r.Min && elo <= r.Max {
			target = r
			break
		}
	}
	if target == nil || strings.TrimSpace(target.RoleID) == "" {
		return ""
	}

	roleSet := make(map[string]struct{}, len(currentRoles))
	for _, rid := range currentRoles {
		roleSet[rid] = struct{}{}
	}

	for _, r := range ranks {
		roleID := strings.TrimSpace(r.RoleID)
		if roleID == "" || roleID == target.RoleID {
			continue
		}
		if _, ok := roleSet[roleID]; !ok {
			continue
		}
		if err := s.GuildMemberRoleRemove(guildID, userID, roleID); err != nil {
			log.Printf("update all: failed to remove rank role %s from %s: %v", roleID, userID, err)
		}
	}

	if _, ok := roleSet[target.RoleID]; ok {
		return ""
	}
	if err := s.GuildMemberRoleAdd(guildID, userID, target.RoleID); err != nil {
		log.Printf("update all: failed to add rank role %s to %s: %v", target.RoleID, userID, err)
		return "failed to assign rank role"
	}
	return ""
}

func appendCapped(list *[]string, item string, cap int) {
	if list == nil {
		return
	}
	if cap <= 0 {
		cap = 25
	}
	if len(*list) >= cap {
		return
	}
	*list = append(*list, item)
}

func trimMiddle(s string, max int) string {
	s = strings.TrimSpace(s)
	if max <= 0 || len(s) <= max {
		return s
	}
	if max < 8 {
		return s[:max]
	}
	head := (max - 3) / 2
	tail := max - 3 - head
	return s[:head] + "..." + s[len(s)-tail:]
}

func formatBulkUpdateSummary(stats bulkUpdateStats, started time.Time, rankCount int, registerRoleConfigured bool) string {
	duration := time.Since(started).Round(time.Second)
	lines := []string{
		fmt.Sprintf("Bulk `/update` complete in %s.", duration),
		fmt.Sprintf("Members scanned: %d (bots skipped: %d, total fetched: %d).", stats.membersScanned, stats.botsSkipped, stats.membersTotal),
		fmt.Sprintf("Players found in DB: %d.", stats.playersFound),
		fmt.Sprintf("Season stats rows inserted: %d.", stats.seasonStatsInserted),
		fmt.Sprintf("Nicknames updated: %d (mismatches: %d, failures: %d).", stats.nickUpdated, stats.nickMismatchCount, stats.nickFailedCount),
	}
	if rankCount == 0 {
		lines = append(lines, "Rank roles: not configured.")
	}
	if !registerRoleConfigured {
		lines = append(lines, "Register role: not configured.")
	}
	if stats.unregisteredSuspectsCount > 0 {
		trunc := ""
		if stats.unregisteredSuspectsCount > len(stats.unregisteredSuspects) {
			trunc = " (truncated)"
		}
		lines = append(lines, fmt.Sprintf("Unregistered suspects (have rank/register role or ELO prefix): %d%s", stats.unregisteredSuspectsCount, trunc))
		if len(stats.unregisteredSuspects) > 0 {
			lines = append(lines, stats.unregisteredSuspects...)
		}
	}
	if stats.nickFailedCount > 0 {
		trunc := ""
		if stats.nickFailedCount > len(stats.nickFailed) {
			trunc = " (truncated)"
		}
		lines = append(lines, fmt.Sprintf("Nickname update failures: %d%s", stats.nickFailedCount, trunc))
		if len(stats.nickFailed) > 0 {
			lines = append(lines, stats.nickFailed...)
		}
	}
	if stats.roleWarnCount > 0 {
		trunc := ""
		if stats.roleWarnCount > len(stats.roleWarn) {
			trunc = " (truncated)"
		}
		lines = append(lines, fmt.Sprintf("Rank role warnings: %d%s", stats.roleWarnCount, trunc))
		if len(stats.roleWarn) > 0 {
			lines = append(lines, stats.roleWarn...)
		}
	}
	if stats.regWarnCount > 0 {
		trunc := ""
		if stats.regWarnCount > len(stats.regWarn) {
			trunc = " (truncated)"
		}
		lines = append(lines, fmt.Sprintf("Register role warnings: %d%s", stats.regWarnCount, trunc))
		if len(stats.regWarn) > 0 {
			lines = append(lines, stats.regWarn...)
		}
	}
	if stats.dbErrorCount > 0 {
		trunc := ""
		if stats.dbErrorCount > len(stats.dbErrors) {
			trunc = " (truncated)"
		}
		lines = append(lines, fmt.Sprintf("DB errors: %d%s", stats.dbErrorCount, trunc))
		if len(stats.dbErrors) > 0 {
			lines = append(lines, stats.dbErrors...)
		}
	}

	out := strings.Join(lines, "\n")
	if len(out) <= 1900 {
		return out
	}
	return out[:1900] + "\n... (truncated)"
}
