package game

import (
	"context"
	"fmt"
	"os"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type ClaimElo struct{}

func NewClaimElo() *ClaimElo     { return &ClaimElo{} }
func (c *ClaimElo) Name() string { return "claimelo" }
func (c *ClaimElo) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Claim elo depending on what role you have.",
	}
}

func (c *ClaimElo) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	user := interactionUserGame(i)
	if user == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve your Discord user.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	enabled, err := storage.GetClaimEloEnabled(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to check claim status: %v", err))
		return
	}
	if !enabled {
		shared.EditError(s, i, "Claim ELO is currently disabled.")
		return
	}

	rules, err := storage.ListClaimEloRules(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load claim rules: %v", err))
		return
	}
	if len(rules) == 0 {
		shared.EditError(s, i, "No claim rules configured.")
		return
	}

	member, err := s.GuildMember(i.GuildID, user.ID)
	if err != nil {
		shared.EditError(s, i, "You must be a member of the server to run this command.")
		return
	}

	roleReward := selectClaimRule(member, rules)
	if roleReward == nil {
		failEmbed(s, i, "You do not have a role that can claim ELO.")
		return
	}

	player, err := storage.GetPlayerByUserID(ctx, user.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load your profile: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "You must be registered to use this command.")
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to find the active season: %v", err))
		return
	}

	// Prevent claiming after entering queue / starting a game, which can desync pre-game ELO snapshots.
	if voiceID := currentVoiceChannelID(s, i.GuildID, user.ID); voiceID != "" {
		if cfgs, err := storage.ListQueueConfigs(ctx); err == nil {
			for _, cfg := range cfgs {
				if strings.TrimSpace(cfg.ChannelID) == voiceID {
					failEmbed(s, i, fmt.Sprintf("Leave <#%s> before claiming ELO.", voiceID))
					return
				}
			}
		}
	}
	if pending, err := storage.LatestPendingGameCodeForPlayer(ctx, player.ID, seasonID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to check active games: %v", err))
		return
	} else if strings.TrimSpace(pending) != "" {
		failEmbed(s, i, fmt.Sprintf("You cannot claim ELO while you have an unscored ranked game (Game %s).", pending))
		return
	}

	if err := storage.EnsurePlayerSeasonStats(ctx, player.ID, seasonID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to prepare your stats: %v", err))
		return
	}
	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil || stats == nil {
		shared.EditError(s, i, "Unable to load your seasonal stats.")
		return
	}

	if stats.GamesPlayed > 0 {
		failEmbed(s, i, "You cannot claim ELO after playing a game.")
		return
	}
	if stats.Elo > 0 {
		failEmbed(s, i, "You cannot claim ELO if you already have ELO this season.")
		return
	}

	claimsUsed, err := storage.CountClaimEloUses(ctx, player.ID, seasonID, roleReward.RoleID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to check claims: %v", err))
		return
	}
	if roleReward.MaxClaims > 0 && claimsUsed >= roleReward.MaxClaims {
		failEmbed(s, i, "You have already claimed the maximum times for your role this season.")
		return
	}

	newElo := roleReward.Amount
	_, updated, err := storage.UpdatePlayerElo(ctx, stats.ID, player.ID, seasonID, newElo, "ClaimElo", "ELO Claimed")
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update your ELO: %v", err))
		return
	}

	if err := storage.RecordClaimEloUse(ctx, player.ID, seasonID, roleReward.RoleID, roleReward.Amount); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to record your claim: %v", err))
		return
	}

	// Keep compatibility with legacy flag.
	_ = storage.SetPlayerClaimedElo(ctx, stats.ID, true)

	stats.Elo = updated
	shared.ApplyNickname(s, i.GuildID, player, stats, "claimelo")

	var warnings []string
	if warn := shared.ApplyRankRole(s, i.GuildID, user.ID, updated, "claimelo command"); warn != "" {
		warnings = append(warnings, warn)
	}
	if warn := shared.ApplyRegisterRole(s, i.GuildID, user.ID, "claimelo command"); warn != "" {
		warnings = append(warnings, warn)
	}

	msg := fmt.Sprintf("You have claimed **%d** ELO. Current ELO: %d.", roleReward.Amount, updated)
	if len(warnings) > 0 {
		msg += "\nWarnings:\n- " + strings.Join(warnings, "\n- ")
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{
			{
				Description: msg,
				Color:       0x2ecc71,
			},
		},
	})

	// Log to staff log channel, if configured.
	if logChannelID, _ := storage.GetLogChannelID(ctx); strings.TrimSpace(logChannelID) != "" {
		_, _ = s.ChannelMessageSendEmbed(logChannelID, &discordgo.MessageEmbed{
			Description: fmt.Sprintf("<@%s> claimed **%d** ELO. Current ELO: %d.", user.ID, roleReward.Amount, updated),
			Color:       0x2ecc71,
			Timestamp:   time.Now().Format(time.RFC3339),
		})
	}
}

func failEmbed(s *discordgo.Session, i *discordgo.InteractionCreate, msg string) {
	shared.EditError(s, i, "")
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{
			{
				Description: msg,
				Color:       0xe74c3c,
			},
		},
	})
}

func selectClaimRule(member *discordgo.Member, roles []storage.ClaimEloRule) *storage.ClaimEloRule {
	if member == nil {
		return nil
	}
	roleSet := make(map[string]struct{}, len(member.Roles))
	for _, id := range member.Roles {
		roleSet[id] = struct{}{}
	}
	var best *storage.ClaimEloRule
	for idx := range roles {
		rule := roles[idx]
		if rule.MaxClaims <= 0 {
			rule.MaxClaims = 1
		}
		if _, ok := roleSet[rule.RoleID]; !ok {
			continue
		}
		if best == nil || rule.Amount > best.Amount {
			copy := rule
			best = &copy
		}
	}
	return best
}

func interactionUserGame(i *discordgo.InteractionCreate) *discordgo.User {
	if i == nil {
		return nil
	}
	if i.Member != nil && i.Member.User != nil {
		return i.Member.User
	}
	return i.User
}

func settingOrEnv(key string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if val, err := storage.GetSettingValue(ctx, key); err == nil && strings.TrimSpace(val) != "" {
		return strings.TrimSpace(val)
	}
	return strings.TrimSpace(os.Getenv(key))
}

func currentVoiceChannelID(s *discordgo.Session, guildID, userID string) string {
	if s == nil || strings.TrimSpace(guildID) == "" || strings.TrimSpace(userID) == "" {
		return ""
	}
	if vs, err := s.State.VoiceState(guildID, userID); err == nil && vs != nil {
		return strings.TrimSpace(vs.ChannelID)
	}
	guild, err := s.State.Guild(guildID)
	if err != nil || guild == nil {
		return ""
	}
	for _, vs := range guild.VoiceStates {
		if vs != nil && vs.UserID == userID {
			return strings.TrimSpace(vs.ChannelID)
		}
	}
	return ""
}
