package game

import (
	"fmt"
	"sort"
	"strings"

	"rbw-bot/internal/queue"

	"github.com/bwmarrin/discordgo"
)

type QueueStats struct {
	queueSvc *queue.Service
}

func NewQueueStats(queueSvc *queue.Service) *QueueStats { return &QueueStats{queueSvc: queueSvc} }
func (c *QueueStats) Name() string                      { return "queuestats" }
func (c *QueueStats) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Shows who is currently queued per channel.",
	}
}

func (c *QueueStats) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if c.queueSvc == nil {
		_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "Queue tracking is not enabled.",
				Flags:   64,
			},
		})
		return
	}

	snapshots := c.queueSvc.Snapshots()
	if len(snapshots) == 0 {
		_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "No queue channels are configured.",
				Flags:   64,
			},
		})
		return
	}

	sort.Slice(snapshots, func(a, b int) bool {
		return snapshots[a].ChannelID < snapshots[b].ChannelID
	})

	fields := make([]*discordgo.MessageEmbedField, 0, len(snapshots))
	capacity := c.queueSvc.Capacity()
	for _, snap := range snapshots {
		count := len(snap.Entries)
		label := fmt.Sprintf("<#%s>", snap.ChannelID)
		if count == 0 {
			fields = append(fields, &discordgo.MessageEmbedField{
				Name:  label,
				Value: fmt.Sprintf("0/%d players in queue.", capacity),
			})
			continue
		}
		players := make([]string, 0, count)
		for idx, entry := range snap.Entries {
			players = append(players, fmt.Sprintf("%d. <@%s> — %d Elo", idx+1, entry.UserID, entry.Elo))
		}
		value := fmt.Sprintf("**%d/%d players queued**\n%s", count, capacity, strings.Join(players, "\n"))
		fields = append(fields, &discordgo.MessageEmbedField{Name: label, Value: value})
	}

	embed := &discordgo.MessageEmbed{
		Title:  "Current Queue Status",
		Color:  0x7289DA,
		Fields: fields,
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}
