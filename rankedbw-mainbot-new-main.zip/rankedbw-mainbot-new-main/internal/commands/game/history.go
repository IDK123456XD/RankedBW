package game

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

const historyNavPrefix = "history_nav:"

type History struct{}

func NewHistory() *History      { return &History{} }
func (c *History) Name() string { return "history" }
func (c *History) Build() *discordgo.ApplicationCommand {
	minPage := float64(1)
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Shows recent games and ELO changes for a season.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "user",
				Description: "Player to inspect (defaults to yourself).",
			},
			{
				Type:         discordgo.ApplicationCommandOptionString,
				Name:         "season",
				Description:  "Season name (default: active). Use \"active\" for current.",
				Autocomplete: true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionInteger,
				Name:        "page",
				Description: "Page number (10 per page).",
				MinValue:    &minPage,
			},
		},
	}
}

func (c *History) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	page := int64(1)
	target := i.Member.User
	seasonNameInput := ""
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "user":
			if user := opt.UserValue(s); user != nil {
				target = user
			}
		case "season":
			seasonNameInput = strings.TrimSpace(opt.StringValue())
		case "page":
			page = opt.IntValue()
		}
	}
	if page < 1 {
		page = 1
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "That user is not registered.")
		return
	}

	seasonID, seasonName, err := resolveSeason(ctx, seasonNameInput)
	if err != nil {
		shared.EditError(s, i, err.Error())
		return
	}

	embed, components, err := c.renderHistory(ctx, player.ID, player.MinecraftName, seasonID, seasonName, int(page), requesterID(i))
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load history: %v", err))
		return
	}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds:     &[]*discordgo.MessageEmbed{embed},
		Components: &components,
	})
}

// HandleAutocomplete returns season name suggestions.
func (c *History) HandleAutocomplete(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if i == nil {
		return
	}
	data := i.ApplicationCommandData()

	choices := []*discordgo.ApplicationCommandOptionChoice{
		{Name: "Active season", Value: "active"},
	}

	term := ""
	for _, opt := range data.Options {
		if opt.Name == "season" {
			term = opt.StringValue()
			break
		}
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if seasons, err := storage.SearchSeasons(ctx, term, 10); err == nil {
		for _, season := range seasons {
			label := season.Name
			if season.Active {
				label += " (active)"
			} else if season.Archived {
				label += " (archived)"
			}
			choices = append(choices, &discordgo.ApplicationCommandOptionChoice{
				Name:  label,
				Value: season.Name,
			})
		}
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionApplicationCommandAutocompleteResult,
		Data: &discordgo.InteractionResponseData{
			Choices: choices,
		},
	})
}

// HandleComponent manages pagination buttons for history.
func (c *History) HandleComponent(s *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if i == nil || i.MessageComponentData().CustomID == "" {
		return false
	}
	cid := i.MessageComponentData().CustomID
	if !strings.HasPrefix(cid, historyNavPrefix) {
		return false
	}

	parts := strings.Split(strings.TrimPrefix(cid, historyNavPrefix), ":")
	if len(parts) != 5 {
		return false
	}

	seasonID := strings.TrimSpace(parts[0])
	page, err := strconv.Atoi(strings.TrimSpace(parts[1]))
	if err != nil {
		shared.RespondEphemeral(s, i, "Invalid page data.")
		return true
	}
	requester := strings.TrimSpace(parts[2])
	playerID := strings.TrimSpace(parts[3])
	direction := strings.TrimSpace(parts[4])

	if requester == "" || requester != requesterID(i) {
		shared.RespondEphemeral(s, i, "Only the user who ran this command can use these buttons.")
		return true
	}

	if direction == "prev" {
		page--
	} else if direction == "next" {
		page++
	} else {
		return false
	}
	if page < 1 {
		page = 1
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	playerRec, err := storage.GetPlayerByID(ctx, playerID)
	if err != nil || playerRec == nil {
		shared.RespondEphemeral(s, i, "Could not resolve the player for this history.")
		return true
	}

	seasonName := ""
	if season, err := storage.SeasonByID(ctx, seasonID); err == nil && season != nil {
		seasonName = strings.TrimSpace(season.Name)
	}

	embed, components, err := c.renderHistory(ctx, playerID, playerRec.MinecraftName, seasonID, seasonName, page, requester)
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to load history: %v", err))
		return true
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseUpdateMessage,
		Data: &discordgo.InteractionResponseData{
			Embeds:     []*discordgo.MessageEmbed{embed},
			Components: components,
		},
	})

	return true
}

func (c *History) renderHistory(ctx context.Context, playerID, playerName, seasonID, seasonName string, page int, requester string) (*discordgo.MessageEmbed, []discordgo.MessageComponent, error) {
	if page < 1 {
		page = 1
	}
	limit := 10

	totalCount, err := storage.CountGamesForPlayerSeason(ctx, playerID, seasonID)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to count games: %w", err)
	}
	if totalCount == 0 {
		return nil, nil, fmt.Errorf("no games recorded yet for that season")
	}

	totalPages := (totalCount + limit - 1) / limit
	if totalPages < 1 {
		totalPages = 1
	}
	if page > totalPages {
		page = totalPages
	}

	offset := (page - 1) * limit

	games, err := storage.RecentGamesForPlayerSeason(ctx, playerID, seasonID, limit, offset)
	if err != nil {
		return nil, nil, err
	}
	if len(games) == 0 {
		return nil, nil, fmt.Errorf("no games recorded yet for that season")
	}

	lines := make([]string, 0, len(games))
	for _, entry := range games {
		status := formatGameStatus(entry.Game.Status)
		delta := entry.EloDiff
		if delta == 0 {
			delta = entry.PostElo - entry.PreElo
		}
		deltaLabel := fmt.Sprintf("%+d", delta)
		if strings.EqualFold(status, "PENDING") {
			deltaLabel = "??"
		} else if isGameVoidedStatus(entry.Game.Status) {
			deltaLabel = "+0"
		}

		when := fmt.Sprintf("<t:%d:R>", entry.Game.CreatedAt.Unix())
		if time.Since(entry.Game.CreatedAt) > 48*time.Hour {
			when = entry.Game.CreatedAt.Format("Jan 2 15:04")
		}

		result := "Loss"
		if strings.EqualFold(status, "PENDING") {
			result = "Pending"
		} else if isGameVoidedStatus(entry.Game.Status) {
			result = "Voided"
		} else {
			if entry.Win {
				result = "Win"
			}
			if entry.MVP {
				result += " + MVP"
			}
		}
		lines = append(lines, fmt.Sprintf("[%s] - %s - [Game ID: %s] - [%s]", deltaLabel, when, entry.Game.GameID, result))
	}

	title := fmt.Sprintf("%s's recent games", playerName)
	if strings.TrimSpace(seasonName) != "" {
		title += fmt.Sprintf(" (%s)", seasonName)
	} else {
		title += " (active season)"
	}

	embed := &discordgo.MessageEmbed{
		Title:       title,
		Description: strings.Join(lines, "\n"),
		Color:       0x004CFF,
		Footer: &discordgo.MessageEmbedFooter{
			Text: fmt.Sprintf("Page %d/%d", page, totalPages),
		},
	}

	components := buildHistoryNav(seasonID, playerID, page, totalPages, requester)
	return embed, components, nil
}

func buildHistoryNav(seasonID, playerID string, page int, totalPages int, requester string) []discordgo.MessageComponent {
	if requester == "" || seasonID == "" || playerID == "" {
		return nil
	}
	prev := plainButton{
		Label:    "< Prev",
		Style:    discordgo.SecondaryButton,
		CustomID: fmt.Sprintf("%s%s:%d:%s:%s:prev", historyNavPrefix, seasonID, page, requester, playerID),
		Disabled: page <= 1,
	}
	next := plainButton{
		Label:    "Next >",
		Style:    discordgo.SecondaryButton,
		CustomID: fmt.Sprintf("%s%s:%d:%s:%s:next", historyNavPrefix, seasonID, page, requester, playerID),
		Disabled: page >= totalPages,
	}
	return []discordgo.MessageComponent{discordgo.ActionsRow{Components: []discordgo.MessageComponent{prev, next}}}
}

func resolveSeason(ctx context.Context, seasonNameInput string) (string, string, error) {
	if strings.EqualFold(strings.TrimSpace(seasonNameInput), "active") || strings.TrimSpace(seasonNameInput) == "" {
		active, err := storage.ActiveSeason(ctx)
		if err != nil {
			return "", "", fmt.Errorf("Failed to load active season: %v", err)
		}
		if active == nil || strings.TrimSpace(active.ID) == "" {
			return "", "", fmt.Errorf("No active season is configured.")
		}
		return strings.TrimSpace(active.ID), strings.TrimSpace(active.Name), nil
	}

	season, err := storage.SeasonByName(ctx, seasonNameInput)
	if err != nil {
		return "", "", fmt.Errorf("Failed to load season: %v", err)
	}
	if season == nil {
		return "", "", fmt.Errorf("Season \"%s\" not found.", seasonNameInput)
	}
	return strings.TrimSpace(season.ID), strings.TrimSpace(season.Name), nil
}

