package game

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/commands/registration"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Register struct{}

func NewRegister() *Register     { return &Register{} }
func (r *Register) Name() string { return "register" }

func (r *Register) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        r.Name(),
		Description: "Link your Discord to your Minecraft (Hypixel) account.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "ign",
				Description: "Your Minecraft username (IGN)",
				Required:    true,
			},
		},
	}
}

func (r *Register) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	data := i.ApplicationCommandData()
	ign := strings.TrimSpace(data.Options[0].StringValue())
	if ign == "" {
		shared.Respond(s, i, "Please provide a valid Minecraft IGN.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	key, err := storage.GetHypixelAPIKey(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Hypixel API key not configured: %v", err))
		return
	}

	uuid, err := registration.MojangUUID(ctx, ign)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Could not resolve IGN: %v", err))
		return
	}

	linked, hypixelName, err := registration.HypixelDiscord(ctx, key, uuid)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Hypixel lookup failed: %v", err))
		return
	}

	user := i.Member.User
	fullTag := user.Username
	if user.Discriminator != "0" && user.Discriminator != "" {
		fullTag = user.Username + "#" + user.Discriminator
	}

	candidates := []string{
		strings.ToLower(fullTag),
		strings.ToLower(user.Username),
	}
	linkedLower := strings.ToLower(strings.TrimSpace(linked))

	match := false
	for _, c := range candidates {
		if c == linkedLower {
			match = true
			break
		}
	}
	if !match {
		msg := "Your Hypixel **Social > Discord** isn't set to your current Discord username.\n" +
			"Open **Hypixel > Social Media > Discord** and set it to **" + fullTag + "**, then try again."
		shared.EditError(s, i, msg)
		return
	}

	if record, err := storage.GetPlayerByMinecraftName(ctx, ign); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to validate IGN: %v", err))
		return
	} else if record != nil && record.UserID != user.ID {
		shared.EditError(s, i, "You are already registered! Please use `/update` or `/rename` instead.")
		return
	}

	if record, err := storage.GetPlayerByUUID(ctx, uuid); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to validate UUID: %v", err))
		return
	} else if record != nil && record.UserID != user.ID {
		shared.EditError(s, i, fmt.Sprintf("You are already registered to another Discord account, create a ticket to get your account merged. (%s)", record.UserID))
		return
	}

	displayName := hypixelName
	if strings.TrimSpace(displayName) == "" {
		displayName = ign
	}

	result, err := registration.UpsertPlayer(ctx, registration.Params{
		UserID:      user.ID,
		IGN:         ign,
		DisplayName: displayName,
		UUID:        uuid,
	})
	if err != nil {
		if errors.Is(err, registration.ErrDuplicatePlayer) {
			shared.EditError(s, i, "You are already registered to another Discord account, create a ticket to get your account merged.")
			return
		}
		shared.EditError(s, i, fmt.Sprintf("Failed to save your profile: %v", err))
		return
	}

	var warnings []string
	nickname := registration.BuildNickname(result.Elo, result.MinecraftName)
	if err := s.GuildMemberNickname(i.GuildID, user.ID, nickname); err != nil {
		log.Printf("failed to update nickname for %s: %v", user.ID, err)
		warnings = append(warnings, "Failed to update your nickname (check bot permissions).")
	}
	if warn := shared.ApplyRankRole(s, i.GuildID, user.ID, result.Elo, "register command"); warn != "" {
		warnings = append(warnings, warn)
	}
	if warn := shared.ApplyRegisterRole(s, i.GuildID, user.ID, "register command"); warn != "" {
		warnings = append(warnings, warn)
	}
	{
		ban, err := storage.ActiveRankedBanForPlayer(ctx, result.PlayerID)
		if err != nil {
			log.Printf("register: ranked ban lookup failed for %s: %v", user.ID, err)
		} else if ban != nil {
			roleID := strings.TrimSpace(shared.SettingOrEnv("RANKED_BAN_ROLE_ID"))
			if roleID != "" {
				if err := s.GuildMemberRoleAdd(i.GuildID, user.ID, roleID); err != nil {
					log.Printf("register: failed to apply ranked ban role for %s: %v", user.ID, err)
				}
			}
		}
	}

	response := fmt.Sprintf("You have been registered as **%s**!", result.MinecraftName)
	if result.Refreshed {
		response = fmt.Sprintf("You have refreshed your data and been registered as **%s**!", result.MinecraftName)
	}
	if len(warnings) > 0 {
		response += "\nWarning: " + strings.Join(warnings, "\nWarning: ")
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &response})
}
