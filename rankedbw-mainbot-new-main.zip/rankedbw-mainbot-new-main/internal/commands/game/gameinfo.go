package game

import (
	"context"
	"fmt"
	"strings"
	"time"
	"unicode/utf8"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"
	"rbw-bot/internal/transcripts"

	"github.com/bwmarrin/discordgo"
)

type GameInfo struct{}

func NewGame() *GameInfo         { return &GameInfo{} }
func (c *GameInfo) Name() string { return "game" }
func (c *GameInfo) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Shows information about a specified game.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "id",
				Description: "Game ID (e.g., 1).",
				Required:    true,
			},
		},
	}
}

func (c *GameInfo) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	gameID := strings.TrimSpace(i.ApplicationCommandData().Options[0].StringValue())
	if gameID == "" {
		shared.RespondEphemeral(s, i, "Please provide a valid game ID.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	game, players, err := storage.GetGameWithPlayers(ctx, gameID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load that game: %v", err))
		return
	}
	if game == nil {
		shared.EditError(s, i, "Game not found.")
		return
	}

	ids := make([]string, 0, len(players))
	for _, gp := range players {
		ids = append(ids, gp.PlayerID)
	}
	names, err := storage.PlayerNameMap(ctx, ids)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player data: %v", err))
		return
	}

	showPost := isGameScoredStatus(game.Status) || isGameVoidedStatus(game.Status)
	var winners, losers []string
	for _, gp := range players {
		display := mentionValue(gp.DiscordID, names[gp.PlayerID], gp.PlayerID)
		line := formatPlayerEloLine(display, gp.PreElo, gp.PostElo, gp.EloDiff, showPost)
		if gp.MVP {
			line += " 🏆"
		}
		if gp.Win {
			winners = append(winners, line)
		} else {
			losers = append(losers, line)
		}
	}
	if len(winners) == 0 {
		winners = []string{"None"}
	}
	if len(losers) == 0 {
		losers = []string{"None"}
	}

	status := formatGameStatus(game.Status)
	voided := isGameVoidedStatus(game.Status)
	description := fmt.Sprintf("Status: **%s**\nVoided: **%t**\nLoss Voided: **%t**\nCreated: <t:%d:F>", status, voided, game.LossVoided, game.CreatedAt.Unix())
	if game.Reason.Valid && strings.TrimSpace(game.Reason.String) != "" {
		description += "\nReason: " + game.Reason.String
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Game %s", game.GameID),
		Description: description,
		Color:       0x6F9CFF,
		Fields: []*discordgo.MessageEmbedField{
			{Name: "Winners", Value: strings.Join(winners, "\n")},
			{Name: "Losers", Value: strings.Join(losers, "\n")},
		},
	}
	if game.ProofURL.Valid && strings.TrimSpace(game.ProofURL.String) != "" {
		embed.Image = &discordgo.MessageEmbedImage{URL: strings.TrimSpace(game.ProofURL.String)}
	}
	if game.ProofBy.Valid && strings.TrimSpace(game.ProofBy.String) != "" {
		embed.Fields = append(embed.Fields, &discordgo.MessageEmbedField{
			Name:   "Proof Submitted By",
			Value:  fmt.Sprintf("<@%s>", strings.TrimSpace(game.ProofBy.String)),
			Inline: true,
		})
	}

	season := ""
	if game.SeasonID.Valid {
		season = strings.TrimSpace(game.SeasonID.String)
	}
	if text, err := transcripts.Read(season, game.GameID); err != nil {
		fmt.Printf("gameinfo: failed to read transcript for game %s: %v\n", game.GameID, err)
	} else if preview := formatTranscriptPreview(text); preview != "" {
		embed.Fields = append(embed.Fields, &discordgo.MessageEmbedField{
			Name:  "Thread Transcript (preview)",
			Value: preview,
		})
	}
	if link, err := transcripts.ReadLink(season, game.GameID); err != nil {
		fmt.Printf("gameinfo: failed to read transcript link for game %s: %v\n", game.GameID, err)
	} else if link != "" {
		embed.Fields = append(embed.Fields, &discordgo.MessageEmbedField{
			Name:  "Transcript (full)",
			Value: fmt.Sprintf("[View transcript](%s)", link),
		})
	}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{embed},
	})
}

func mentionValue(discordID, fallback, alt string) string {
	id := strings.TrimSpace(discordID)
	if id != "" {
		return fmt.Sprintf("<@%s>", id)
	}
	if name := strings.TrimSpace(fallback); name != "" {
		return name
	}
	return alt
}

func formatPlayerEloLine(display string, pre, post, diff int, showPost bool) string {
	if !showPost {
		return fmt.Sprintf("%s - %d ELO (pre)", display, pre)
	}
	targetPost := post
	if targetPost == 0 {
		// Fallback for legacy rows missing postElo.
		targetPost = pre + diff
	}
	if targetPost < 0 {
		targetPost = 0
	}

	// Display the ELO at the time the game was scored (pre-score) vs after scoring.
	preScore := targetPost - diff
	if preScore < 0 {
		preScore = pre
	}

	diffStr := ""
	if diff != 0 {
		diffStr = fmt.Sprintf(" (%+d)", diff)
	}
	return fmt.Sprintf("%s - %d -> %d ELO%s", display, preScore, targetPost, diffStr)
}

const transcriptPreviewBytes = 900

func formatTranscriptPreview(raw string) string {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		return ""
	}
	if len(trimmed) <= transcriptPreviewBytes {
		return trimmed
	}
	start := len(trimmed)
	for start > 0 && len(trimmed)-start < transcriptPreviewBytes {
		_, size := utf8.DecodeLastRuneInString(trimmed[:start])
		if size <= 0 {
			size = 1
		}
		start -= size
	}
	if start < 0 {
		start = 0
	}
	preview := strings.TrimLeft(trimmed[start:], "\n")
	return fmt.Sprintf("... (truncated)\n%s", preview)
}
