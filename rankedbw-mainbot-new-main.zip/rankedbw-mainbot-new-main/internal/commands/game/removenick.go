package game

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type RemoveNick struct{}

func NewRemoveNick() *RemoveNick   { return &RemoveNick{} }
func (c *RemoveNick) Name() string { return "removenick" }
func (c *RemoveNick) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Remove your nick from discord and the bot.",
	}
}

func (c *RemoveNick) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, stats, err := loadPlayerAndStats(ctx, i.Member.User.ID)
	if err != nil {
		shared.EditError(s, i, err.Error())
		return
	}
	if !player.Nickname.Valid || strings.TrimSpace(player.Nickname.String) == "" {
		shared.EditError(s, i, "You do not have a nickname set.")
		return
	}

	if err := storage.SetPlayerNickname(ctx, player.ID, ""); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update nickname: %v", err))
		return
	}

	empty := ""
	display := composeDisplayName(player, stats, &empty)
	if err := s.GuildMemberNickname(i.GuildID, player.UserID, display); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to change Discord nickname: %v", err))
		return
	}

	msg := "Your nickname has been removed."
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}
