package game

import (
	"rbw-bot/internal/queue"

	"github.com/bwmarrin/discordgo"
)

// Picking handles pick dropdown interactions for queue sessions.
type Picking struct {
	queueSvc *queue.Service
}

func NewPicking(queueSvc *queue.Service) *Picking {
	return &Picking{queueSvc: queueSvc}
}

func (p *Picking) HandleComponent(s *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if p == nil || p.queueSvc == nil {
		return false
	}
	return p.queueSvc.HandlePickingComponent(s, i)
}
