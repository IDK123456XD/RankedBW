package game

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/registration"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type TogglePrefix struct{}

func NewTogglePrefix() *TogglePrefix { return &TogglePrefix{} }
func (c *TogglePrefix) Name() string { return "toggleprefix" }
func (c *TogglePrefix) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Toggle your discord elo prefix.",
	}
}

func (c *TogglePrefix) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, i.Member.User.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load your profile: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "You are not registered yet. Please use `/register` first.")
		return
	}

	enabled := !player.EloPrefix
	if err := storage.SetPlayerEloPrefix(ctx, player.ID, enabled); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update your settings: %v", err))
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to determine active season: %v", err))
		return
	}
	if err := storage.EnsurePlayerSeasonStats(ctx, player.ID, seasonID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to prepare your stats: %v", err))
		return
	}
	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load your stats: %v", err))
		return
	}
	if stats == nil {
		shared.EditError(s, i, "Unable to load your season stats. Play a game and try again.")
		return
	}

	baseName := player.MinecraftName
	if player.Nickname.Valid && strings.TrimSpace(player.Nickname.String) != "" {
		baseName += " | " + strings.TrimSpace(player.Nickname.String)
	}

	finalNickname := baseName
	if enabled {
		finalNickname = registration.BuildNickname(stats.Elo, baseName)
	}

	if err := s.GuildMemberNickname(i.GuildID, player.UserID, finalNickname); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update nickname: %v", err))
		return
	}

	msg := "Your elo prefix has been disabled."
	if enabled {
		msg = "Your elo prefix has been enabled."
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}
