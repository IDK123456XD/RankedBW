package game

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type StatReset struct{}

func NewStatReset() *StatReset    { return &StatReset{} }
func (c *StatReset) Name() string { return "statreset" }
func (c *StatReset) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Reset your player statistics.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "confirm",
				Description: "Type CONFIRM to reset your stats.",
				Required:    true,
			},
		},
	}
}

func (c *StatReset) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	confirm := strings.TrimSpace(i.ApplicationCommandData().Options[0].StringValue())
	if !strings.EqualFold(confirm, "confirm") {
		respondStatResetError(s, i, "You must type CONFIRM to reset your statistics.")
		return
	}
	if i.Member == nil {
		respondStatResetError(s, i, "This command can only be used inside the guild.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	rules, err := storage.ListStatResetRules(ctx)
	if err != nil {
		editStatResetError(s, i, fmt.Sprintf("Failed to load stat reset rules: %v", err))
		return
	}
	if len(rules) == 0 {
		if envRules, err := parseStatResetLimitsEnv(); err == nil {
			rules = envRules
		}
	}

	limit, allowed, unlimited := highestResetAllowance(i.Member.Roles, rules)
	if !allowed {
		editStatResetError(s, i, "You do not have a role that allows stat resets.")
		return
	}
	if !unlimited && limit <= 0 {
		editStatResetError(s, i, "Your roles do not grant any stat resets.")
		return
	}

	player, err := storage.GetPlayerByUserID(ctx, i.Member.User.ID)
	if err != nil {
		editStatResetError(s, i, fmt.Sprintf("Failed to load your profile: %v", err))
		return
	}
	if player == nil {
		editStatResetError(s, i, "You are not registered yet. Use `/register` first.")
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		editStatResetError(s, i, fmt.Sprintf("Failed to determine the active season: %v", err))
		return
	}
	if err := storage.EnsurePlayerSeasonStats(ctx, player.ID, seasonID); err != nil {
		editStatResetError(s, i, fmt.Sprintf("Failed to prepare your stats: %v", err))
		return
	}
	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil {
		editStatResetError(s, i, fmt.Sprintf("Failed to load your stats: %v", err))
		return
	}
	if stats == nil {
		editStatResetError(s, i, "Unable to locate your current season stats.")
		return
	}

	if !unlimited && stats.ResetCount >= limit {
		editStatResetError(s, i, fmt.Sprintf("You have already used all %d stat resets allowed for your roles.", limit))
		return
	}

	if err := storage.ResetPlayerSeasonStats(ctx, stats.ID); err != nil {
		editStatResetError(s, i, fmt.Sprintf("Failed to reset your stats: %v", err))
		return
	}
	stats.ResetCount++
	stats.Elo = 0
	shared.ApplyNickname(s, i.GuildID, player, stats, "statreset")

	logChannelID, _ := storage.GetLogChannelID(ctx)
	if logChannelID != "" {
		content := fmt.Sprintf("<@%s> reset their stats. Total resets this season: %d.", player.UserID, stats.ResetCount)
		if _, err := s.ChannelMessageSendEmbed(logChannelID, &discordgo.MessageEmbed{
			Description: content,
			Color:       0x2ecc71,
			Timestamp:   time.Now().Format(time.RFC3339),
		}); err != nil {
			log.Printf("statreset: failed to log reset: %v", err)
		}
	}

	message := fmt.Sprintf("Your statistics have been reset. You have used %d stat reset(s)%s.", stats.ResetCount, formatLimitSuffix(limit, unlimited))
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{
			{
				Description: message,
				Color:       0x2ecc71,
			},
		},
	})
}

func highestResetAllowance(memberRoles []string, rules []storage.StatResetRule) (limit int, allowed bool, unlimited bool) {
	roleSet := make(map[string]struct{}, len(memberRoles))
	for _, roleID := range memberRoles {
		roleSet[roleID] = struct{}{}
	}
	for _, rule := range rules {
		if _, ok := roleSet[strings.TrimSpace(rule.RoleID)]; !ok {
			continue
		}
		allowed = true
		if rule.MaxResets <= 0 {
			return 0, true, true
		}
		if rule.MaxResets > limit {
			limit = rule.MaxResets
		}
	}
	// Fallback to legacy env if no DB rules configured.
	if !allowed && len(rules) == 0 {
		if envRules, err := parseStatResetLimitsEnv(); err == nil {
			return highestResetAllowance(memberRoles, envRules)
		}
	}
	return
}

func formatLimitSuffix(limit int, unlimited bool) string {
	if unlimited {
		return " (unlimited resets available)"
	}
	return fmt.Sprintf(" out of %d allowed", limit)
}

// parseStatResetLimitsEnv preserves the old env-based configuration as a fallback.
func parseStatResetLimitsEnv() ([]storage.StatResetRule, error) {
	raw := strings.TrimSpace(os.Getenv("STATRESET_ROLE_LIMITS"))
	if raw == "" {
		return nil, errors.New("STATRESET_ROLE_LIMITS is not set")
	}
	var rules []storage.StatResetRule
	for _, entry := range strings.Split(raw, ",") {
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		parts := strings.Split(entry, ":")
		if len(parts) != 2 {
			return nil, fmt.Errorf("invalid entry %q", entry)
		}
		roleID := strings.TrimSpace(parts[0])
		value := strings.TrimSpace(parts[1])
		if roleID == "" || value == "" {
			return nil, fmt.Errorf("invalid entry %q", entry)
		}
		if strings.EqualFold(value, "inf") || strings.EqualFold(value, "infinite") {
			rules = append(rules, storage.StatResetRule{RoleID: roleID, MaxResets: 0})
			continue
		}
		num, err := strconv.Atoi(value)
		if err != nil || num < 0 {
			return nil, fmt.Errorf("invalid limit %q", value)
		}
		rules = append(rules, storage.StatResetRule{RoleID: roleID, MaxResets: num})
	}
	if len(rules) == 0 {
		return nil, errors.New("STATRESET_ROLE_LIMITS does not contain any entries")
	}
	return rules, nil
}

func respondStatResetError(s *discordgo.Session, i *discordgo.InteractionCreate, msg string) {
	if s == nil || i == nil {
		return
	}
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Flags: 64,
			Embeds: []*discordgo.MessageEmbed{
				{Description: msg, Color: 0xe74c3c},
			},
		},
	})
}

func editStatResetError(s *discordgo.Session, i *discordgo.InteractionCreate, msg string) {
	if s == nil || i == nil {
		return
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{
			{Description: msg, Color: 0xe74c3c},
		},
	})
}
