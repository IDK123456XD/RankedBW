package game

import (
	"fmt"
	"strings"

	"github.com/bwmarrin/discordgo"
)

type TestScore struct{}

func NewTestScore() *TestScore    { return &TestScore{} }
func (c *TestScore) Name() string { return "testscore" }
func (c *TestScore) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Generate a test scoring card with mock data.",
	}
}

func (c *TestScore) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	winners := []string{
		"SOUNDLESS — 972 ➜ 1012 (+40) *(MVP)*",
		"thupi — 1030 ➜ 1055 (+25)",
		"SOUNDLESS — 870 ➜ 895 (+25)",
		"KOREANESE — 910 ➜ 930 (+20)",
	}
	losers := []string{
		"idzi — 1102 ➜ 1070 (-32)",
		"oBluee — 1220 ➜ 1185 (-35)",
		"Balu_u — 980 ➜ 950 (-30)",
		"chroot — 1015 ➜ 990 (-25)",
	}

	description := strings.Builder{}
	description.WriteString("**Game ID:** `1`\n")
	description.WriteString("**Map:** Lotus\n")
	description.WriteString("**Season:** Season XIV\n")
	description.WriteString("**Status:** Final • Score submitted\n\n")
	description.WriteString("**Winners**\n" + strings.Join(winners, "\n") + "\n\n")
	description.WriteString("**Losers**\n" + strings.Join(losers, "\n") + "\n\n")
	description.WriteString("**Highlights**\n")
	description.WriteString("• SOUNDLESS dropped 23 finals and claimed MVP.\n")
	description.WriteString("• Team 1 won in 9m32s with a +14 bed advantage.")

	embed := &discordgo.MessageEmbed{
		Title:       "Test Scoring Card",
		Description: description.String(),
		Color:       0x00be90,
		Fields: []*discordgo.MessageEmbedField{
			{
				Name:  "Screenshot Link",
				Value: "[View Attachment](https://example.com/mock-scorecard)",
			},
			{
				Name:  "Notes",
				Value: fmt.Sprintf("This output uses mock data and mirrors the layout shown in design tickets. "),
			},
		},
		Footer: &discordgo.MessageEmbedFooter{
			Text: "Mock data only - Use /submit to process real matches",
		},
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}
