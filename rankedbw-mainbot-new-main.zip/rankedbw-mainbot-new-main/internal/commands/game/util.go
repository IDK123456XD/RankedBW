package game

import "strings"

func isGameVoidedStatus(status string) bool {
	switch strings.ToUpper(strings.TrimSpace(status)) {
	case "VOIDED", "CANCELLED", "AUTO_CLOSED":
		return true
	default:
		return false
	}
}

func formatGameStatus(status string) string {
	if isGameVoidedStatus(status) {
		return "VOIDED"
	}
	trimmed := strings.TrimSpace(status)
	if trimmed == "" {
		return "UNKNOWN"
	}
	return strings.ToUpper(trimmed)
}

func isGameScoredStatus(status string) bool {
	switch strings.ToUpper(strings.TrimSpace(status)) {
	case "FINISHED", "SCORED":
		return true
	default:
		return false
	}
}
