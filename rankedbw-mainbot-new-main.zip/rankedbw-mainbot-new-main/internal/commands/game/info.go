package game

import (
	"bytes"
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/images"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Info struct{}

func NewInfo() *Info         { return &Info{} }
func (c *Info) Name() string { return "info" }
func (c *Info) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Get your player info card.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "user",
				Description: "View info for another Discord user.",
			},
		},
	}
}

func (c *Info) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	target := i.Member.User
	for _, opt := range i.ApplicationCommandData().Options {
		if opt.Name == "user" {
			if user := opt.UserValue(s); user != nil {
				target = user
			}
			break
		}
	}
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the requested user.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player profile: %v", err))
		return
	}
	if player == nil {
		msg := fmt.Sprintf("%s is not registered yet.", target.Mention())
		shared.EditError(s, i, msg)
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to determine active season: %v", err))
		return
	}

	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load season stats: %v", err))
		return
	}
	if stats == nil {
		msg := fmt.Sprintf("%s has no stats recorded for the current season.", player.MinecraftName)
		shared.EditError(s, i, msg)
		return
	}
	if err := storage.GrantStandardInfocards(ctx, player.ID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to sync info cards: %v", err))
		return
	}
	if _, err := storage.ApplySeasonalInfocardSelection(ctx, player); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to select info card: %v", err))
		return
	}
	cardBytes, err := images.InfoCard(ctx, player, stats)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to render card: %v", err))
		return
	}

	filename := fmt.Sprintf("%s_infocard.png", strings.ReplaceAll(player.MinecraftName, " ", "_"))
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Files: []*discordgo.File{
			{
				Name:   filename,
				Reader: bytes.NewReader(cardBytes),
			},
		},
	})
}
