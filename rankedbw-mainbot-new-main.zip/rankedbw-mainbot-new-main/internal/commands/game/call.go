package game

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/queue"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

const voiceAllowMask = int64(discordgo.PermissionVoiceConnect | discordgo.PermissionVoiceSpeak)
const callAPIDelay = 50 * time.Millisecond

// Call manages temporary access to team voice channels for the current game.
type Call struct {
	queueSvc *queue.Service
}

func NewCall(queueSvc *queue.Service) *Call { return &Call{queueSvc: queueSvc} }

func (c *Call) Name() string { return "call" }

func (c *Call) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Manage who can join your team voice channel for the current game.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Allow a user to join your team voice channel for this game.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "User to allow into the call.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove a user's access to your team voice channel.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "User to remove from the call.",
						Required:    true,
					},
				},
			},
		},
	}
}

func (c *Call) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if c.queueSvc == nil {
		shared.RespondEphemeral(s, i, "Queue service is unavailable.")
		return
	}
	if i.GuildID == "" || i.Member == nil || i.Member.User == nil {
		shared.RespondEphemeral(s, i, "This command can only be used in a guild.")
		return
	}
	data := i.ApplicationCommandData()
	if len(data.Options) == 0 {
		shared.RespondEphemeral(s, i, "Please choose add or remove.")
		return
	}

	sub := data.Options[0]
	opts := mapOptions(sub.Options)
	userOpt, ok := opts["user"]
	if !ok {
		shared.RespondEphemeral(s, i, "Please choose a user.")
		return
	}

	targetUser := userOpt.UserValue(s)
	if targetUser == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	channelID := currentVoiceChannel(s, i.GuildID, i.Member.User.ID)
	if channelID == "" {
		shared.RespondEphemeral(s, i, "Join your team voice channel first.")
		return
	}

	game, players, err := storage.GetGameWithPlayersByVoice(ctx, channelID)
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to load game for this channel: %v", err))
		return
	}
	if game == nil {
		shared.RespondEphemeral(s, i, "This voice channel is not tied to an active game.")
		return
	}

	teamNumber := channelTeam(game, channelID)
	if teamNumber == 0 {
		shared.RespondEphemeral(s, i, "Unable to determine which team owns this channel.")
		return
	}

	teamUsers, teamSet, actorOnTeam := buildTeamUsers(players, teamNumber, i.Member.User.ID)
	if !actorOnTeam {
		shared.RespondEphemeral(s, i, "Only players on this team can manage call access.")
		return
	}

	channel, err := s.Channel(channelID)
	if err != nil || channel == nil {
		shared.RespondEphemeral(s, i, "Unable to load the voice channel.")
		return
	}

	guestSet := extractGuests(channel.PermissionOverwrites, teamSet)

	switch sub.Name {
	case "add":
		c.handleAdd(s, i, channel, teamUsers, teamSet, guestSet, targetUser.ID)
	case "remove":
		c.handleRemove(s, i, channel, teamUsers, teamSet, guestSet, targetUser.ID)
	default:
		shared.RespondEphemeral(s, i, "Unknown call subcommand.")
	}
}

func (c *Call) handleAdd(s *discordgo.Session, i *discordgo.InteractionCreate, channel *discordgo.Channel, teamUsers []string, teamSet map[string]struct{}, guests map[string]struct{}, targetID string) {
	if targetID == "" {
		shared.RespondEphemeral(s, i, "Please choose a user to add.")
		return
	}
	if _, ok := teamSet[targetID]; ok {
		shared.RespondEphemeral(s, i, "That user is already on your team.")
		return
	}
	if _, ok := guests[targetID]; ok {
		shared.RespondEphemeral(s, i, "That user already has access to this call.")
		return
	}

	guests[targetID] = struct{}{}
	guestList := make([]string, 0, len(guests))
	for id := range guests {
		guestList = append(guestList, id)
	}

	managed := unionIDs(teamSet, guests)
	managed[targetID] = struct{}{}
	base := filterManagedOverwrites(channel.PermissionOverwrites, managed)

	time.Sleep(callAPIDelay)
	overwrites := c.queueSvc.BuildTeamVoiceOverwritesWithGuests(base, channel.GuildID, teamUsers, guestList)
	_, err := s.ChannelEditComplex(channel.ID, &discordgo.ChannelEdit{PermissionOverwrites: overwrites})
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to update channel: %v", err))
		return
	}
	shared.RespondEphemeral(s, i, fmt.Sprintf("Added <@%s> to the call.", targetID))
}

func (c *Call) handleRemove(s *discordgo.Session, i *discordgo.InteractionCreate, channel *discordgo.Channel, teamUsers []string, teamSet map[string]struct{}, guests map[string]struct{}, targetID string) {
	if targetID == "" {
		shared.RespondEphemeral(s, i, "Please choose a user to remove.")
		return
	}
	if _, ok := teamSet[targetID]; ok {
		shared.RespondEphemeral(s, i, "You cannot remove a teammate from the call.")
		return
	}
	if _, ok := guests[targetID]; !ok {
		shared.RespondEphemeral(s, i, "That user does not currently have access to this call.")
		return
	}

	delete(guests, targetID)
	guestList := make([]string, 0, len(guests))
	for id := range guests {
		guestList = append(guestList, id)
	}

	managed := unionIDs(teamSet, guests)
	managed[targetID] = struct{}{}
	base := filterManagedOverwrites(channel.PermissionOverwrites, managed)

	time.Sleep(callAPIDelay)
	overwrites := c.queueSvc.BuildTeamVoiceOverwritesWithGuests(base, channel.GuildID, teamUsers, guestList)
	if _, err := s.ChannelEditComplex(channel.ID, &discordgo.ChannelEdit{PermissionOverwrites: overwrites}); err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to update channel: %v", err))
		return
	}

	// Kick the user if they are currently in this channel.
	if current := currentVoiceChannel(s, channel.GuildID, targetID); current == channel.ID {
		waiting := shared.WaitingRoomID()
		time.Sleep(callAPIDelay)
		if strings.TrimSpace(waiting) == "" {
			_ = s.GuildMemberMove(channel.GuildID, targetID, nil)
		} else {
			target := waiting
			_ = s.GuildMemberMove(channel.GuildID, targetID, &target)
		}
	}

	shared.RespondEphemeral(s, i, fmt.Sprintf("Removed <@%s> from the call.", targetID))
}

func channelTeam(game *storage.GameRecord, channelID string) int {
	if game == nil {
		return 0
	}
	if game.Team1Voice.Valid && strings.TrimSpace(game.Team1Voice.String) == channelID {
		return 1
	}
	if game.Team2Voice.Valid && strings.TrimSpace(game.Team2Voice.String) == channelID {
		return 2
	}
	return 0
}

func buildTeamUsers(players []storage.GamePlayerRecord, team int, actorID string) ([]string, map[string]struct{}, bool) {
	var list []string
	set := make(map[string]struct{})
	onTeam := false
	for _, p := range players {
		if p.DiscordTeam != team {
			continue
		}
		id := strings.TrimSpace(p.DiscordID)
		if id == "" {
			continue
		}
		set[id] = struct{}{}
		list = append(list, id)
		if id == actorID {
			onTeam = true
		}
	}
	return list, set, onTeam
}

func extractGuests(overwrites []*discordgo.PermissionOverwrite, teamSet map[string]struct{}) map[string]struct{} {
	guests := make(map[string]struct{})
	for _, ow := range overwrites {
		if ow == nil || ow.Type != discordgo.PermissionOverwriteTypeMember {
			continue
		}
		if _, isTeam := teamSet[ow.ID]; isTeam {
			continue
		}
		if (ow.Allow & voiceAllowMask) != 0 {
			guests[ow.ID] = struct{}{}
		}
	}
	return guests
}

func currentVoiceChannel(s *discordgo.Session, guildID, userID string) string {
	if s == nil || guildID == "" || userID == "" {
		return ""
	}
	if vs, err := s.State.VoiceState(guildID, userID); err == nil && vs != nil {
		return vs.ChannelID
	}
	if guild, err := s.State.Guild(guildID); err == nil && guild != nil {
		for _, vs := range guild.VoiceStates {
			if vs != nil && vs.UserID == userID {
				return vs.ChannelID
			}
		}
	}
	return ""
}

func mapOptions(opts []*discordgo.ApplicationCommandInteractionDataOption) map[string]*discordgo.ApplicationCommandInteractionDataOption {
	m := make(map[string]*discordgo.ApplicationCommandInteractionDataOption, len(opts))
	for _, opt := range opts {
		m[opt.Name] = opt
	}
	return m
}

func unionIDs(teamSet map[string]struct{}, guests map[string]struct{}) map[string]struct{} {
	result := make(map[string]struct{}, len(teamSet)+len(guests))
	for id := range teamSet {
		result[id] = struct{}{}
	}
	for id := range guests {
		result[id] = struct{}{}
	}
	return result
}

func filterManagedOverwrites(base []*discordgo.PermissionOverwrite, managed map[string]struct{}) []*discordgo.PermissionOverwrite {
	if len(base) == 0 {
		return nil
	}
	var out []*discordgo.PermissionOverwrite
	for _, ow := range base {
		if ow == nil {
			continue
		}
		if ow.Type == discordgo.PermissionOverwriteTypeMember {
			if _, ok := managed[ow.ID]; ok {
				continue
			}
		}
		out = append(out, ow)
	}
	return out
}
