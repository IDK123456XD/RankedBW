package game

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

const (
	lockerSelectPrefix = "locker_select:"
	lockerNavPrefix    = "locker_nav:"
	lockerPageSize     = 10
)

type Locker struct{}

func NewLocker() *Locker       { return &Locker{} }
func (c *Locker) Name() string { return "locker" }
func (c *Locker) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "View and equip your info cards.",
	}
}

func (c *Locker) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if s == nil || i == nil {
		return
	}
	userID := requesterID(i)
	if userID == "" {
		shared.RespondEphemeral(s, i, "Unable to resolve your user account.")
		return
	}
	if err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	}); err != nil {
		log.Printf("locker: defer response failed: %v", err)
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	embed, components, err := c.renderLocker(ctx, userID, 1)
	if err != nil {
		editLockerError(s, i, err.Error())
		return
	}

	if err := editLockerResponse(s, i, embed, components); err != nil {
		log.Printf("locker: edit response failed: %v", err)
	}
}

func editLockerResponse(s *discordgo.Session, i *discordgo.InteractionCreate, embed *discordgo.MessageEmbed, components []discordgo.MessageComponent) error {
	if s == nil || i == nil {
		return nil
	}
	_, err := s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds:     &[]*discordgo.MessageEmbed{embed},
		Components: &components,
	})
	if err != nil {
		_, _ = s.FollowupMessageCreate(i.Interaction, true, &discordgo.WebhookParams{
			Content: "Locker failed to update. Please try again.",
			Flags:   64,
		})
	}
	return err
}

func (c *Locker) HandleComponent(s *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if s == nil || i == nil {
		return false
	}
	customID := i.MessageComponentData().CustomID
	switch {
	case strings.HasPrefix(customID, lockerNavPrefix):
		return c.handleNav(s, i, customID)
	case strings.HasPrefix(customID, lockerSelectPrefix):
		return c.handleSelect(s, i, customID)
	default:
		return false
	}
}

func (c *Locker) handleNav(s *discordgo.Session, i *discordgo.InteractionCreate, customID string) bool {
	parts := strings.Split(strings.TrimPrefix(customID, lockerNavPrefix), ":")
	if len(parts) != 3 {
		return false
	}
	ownerID := strings.TrimSpace(parts[0])
	pageVal := strings.TrimSpace(parts[1])
	direction := strings.TrimSpace(parts[2])

	if ownerID == "" || requesterID(i) != ownerID {
		shared.RespondEphemeral(s, i, "Only the original user can use this locker.")
		return true
	}
	page, err := strconv.Atoi(pageVal)
	if err != nil {
		shared.RespondEphemeral(s, i, "Invalid locker page.")
		return true
	}
	switch direction {
	case "prev":
		page--
	case "next":
		page++
	default:
		return false
	}
	if page < 1 {
		page = 1
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	embed, components, err := c.renderLocker(ctx, ownerID, page)
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return true
	}

	if err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseUpdateMessage,
		Data: &discordgo.InteractionResponseData{
			Embeds:     []*discordgo.MessageEmbed{embed},
			Components: components,
		},
	}); err != nil {
		log.Printf("locker: nav update failed: %v", err)
		_, _ = s.FollowupMessageCreate(i.Interaction, true, &discordgo.WebhookParams{
			Content: "Failed to update the locker page. Please try again.",
			Flags:   64,
		})
	}
	return true
}

func (c *Locker) handleSelect(s *discordgo.Session, i *discordgo.InteractionCreate, customID string) bool {
	data := i.MessageComponentData()
	parts := strings.Split(strings.TrimPrefix(customID, lockerSelectPrefix), ":")
	if len(parts) != 2 {
		return false
	}
	ownerID := strings.TrimSpace(parts[0])
	pageVal := strings.TrimSpace(parts[1])
	if ownerID == "" || requesterID(i) != ownerID {
		shared.RespondEphemeral(s, i, "Only the original user can use this locker.")
		return true
	}
	page, err := strconv.Atoi(pageVal)
	if err != nil || page < 1 {
		page = 1
	}
	if len(data.Values) == 0 {
		shared.RespondEphemeral(s, i, "Select a card to equip.")
		return true
	}
	cardID := strings.TrimSpace(data.Values[0])
	if cardID == "" {
		shared.RespondEphemeral(s, i, "Select a valid card to equip.")
		return true
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, ownerID)
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to load your profile: %v", err))
		return true
	}
	if player == nil {
		shared.RespondEphemeral(s, i, "You are not registered yet.")
		return true
	}

	if err := storage.GrantStandardInfocards(ctx, player.ID); err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to update your locker: %v", err))
		return true
	}

	card, err := storage.InfocardByID(ctx, cardID)
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to load that card: %v", err))
		return true
	}
	if card == nil {
		shared.RespondEphemeral(s, i, "That card no longer exists.")
		return true
	}

	owned, err := storage.PlayerOwnsInfocard(ctx, player.ID, cardID)
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to check locker status: %v", err))
		return true
	}
	if !owned {
		shared.RespondEphemeral(s, i, "You do not own that card.")
		return true
	}

	selectedID := strings.TrimSpace(player.SelectedInfocardID.String)
	if player.SelectedInfocardID.Valid && selectedID == cardID {
		shared.RespondEphemeral(s, i, "That card is already equipped.")
		return true
	}

	if err := storage.SetPlayerSelectedInfocard(ctx, player.ID, cardID); err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to equip card: %v", err))
		return true
	}

	embed, components, err := c.renderLocker(ctx, ownerID, page)
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return true
	}

	if err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseUpdateMessage,
		Data: &discordgo.InteractionResponseData{
			Embeds:     []*discordgo.MessageEmbed{embed},
			Components: components,
		},
	}); err != nil {
		log.Printf("locker: select update failed: %v", err)
		_, _ = s.FollowupMessageCreate(i.Interaction, true, &discordgo.WebhookParams{
			Content: "Failed to update the locker. Please try again.",
			Flags:   64,
		})
	}
	return true
}

func (c *Locker) renderLocker(ctx context.Context, userID string, page int) (*discordgo.MessageEmbed, []discordgo.MessageComponent, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if page < 1 {
		page = 1
	}
	userID = strings.TrimSpace(userID)
	if userID == "" {
		return nil, nil, fmt.Errorf("unable to resolve your user account")
	}

	if err := storage.EnsurePlayerInfocardsTable(ctx); err != nil {
		return nil, nil, fmt.Errorf("locker setup failed: %w", err)
	}

	player, err := storage.GetPlayerByUserID(ctx, userID)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to load your profile: %w", err)
	}
	if player == nil {
		return nil, nil, fmt.Errorf("you are not registered yet")
	}

	if err := storage.GrantStandardInfocards(ctx, player.ID); err != nil {
		return nil, nil, fmt.Errorf("failed to update locker: %w", err)
	}

	selectedID, err := storage.ApplySeasonalInfocardSelection(ctx, player)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to resolve equipped card: %w", err)
	}

	defaultID, err := storage.DefaultInfocardID(ctx)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to load default card: %w", err)
	}
	if selectedID == "" {
		selectedID = defaultID
		if err := storage.SetPlayerSelectedInfocard(ctx, player.ID, selectedID); err != nil {
			return nil, nil, fmt.Errorf("failed to set default card: %w", err)
		}
	}
	if selectedID != "" && selectedID != defaultID {
		card, err := storage.InfocardByID(ctx, selectedID)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to load equipped card: %w", err)
		}
		if card == nil {
			if err := storage.SetPlayerSelectedInfocard(ctx, player.ID, defaultID); err != nil {
				return nil, nil, fmt.Errorf("failed to reset equipped card: %w", err)
			}
			player, err = storage.GetPlayerByUserID(ctx, userID)
			if err != nil {
				return nil, nil, fmt.Errorf("failed to load your profile: %w", err)
			}
			if player == nil {
				return nil, nil, fmt.Errorf("you are not registered yet")
			}
			selectedID, err = storage.ApplySeasonalInfocardSelection(ctx, player)
			if err != nil {
				return nil, nil, fmt.Errorf("failed to resolve equipped card: %w", err)
			}
		}
	}

	if selectedID != "" && selectedID != defaultID {
		if err := storage.GrantPlayerInfocard(ctx, player.ID, selectedID, ""); err != nil {
			return nil, nil, fmt.Errorf("failed to sync equipped card: %w", err)
		}
	}

	cards, err := storage.ListInfocardsForPlayer(ctx, player.ID)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to load locker: %w", err)
	}
	if len(cards) == 0 {
		return nil, nil, fmt.Errorf("no info cards are configured")
	}

	ownedCount := 0
	selectedName := ""
	for _, card := range cards {
		if card.Owned {
			ownedCount++
		}
		if card.ID == selectedID {
			selectedName = card.Name
		}
	}
	if selectedName == "" {
		selectedName = "Unknown"
	}

	totalPages := (len(cards) + lockerPageSize - 1) / lockerPageSize
	if totalPages < 1 {
		totalPages = 1
	}
	if page > totalPages {
		page = totalPages
	}

	start := (page - 1) * lockerPageSize
	if start < 0 {
		start = 0
	}
	end := start + lockerPageSize
	if end > len(cards) {
		end = len(cards)
	}
	pageCards := cards[start:end]

	lines := make([]string, 0, len(pageCards))
	for idx, card := range pageCards {
		status := "Locked"
		if card.Owned {
			status = "Owned"
		}
		if card.ID == selectedID {
			if card.Owned {
				status = "Owned, Equipped"
			} else {
				status = "Equipped"
			}
		}
		line := fmt.Sprintf("`%d` %s [%s]", start+idx+1, card.Name, status)
		lines = append(lines, line)
	}

	header := fmt.Sprintf("Owned: %d/%d\nEquipped: %s\nUse the menu below to equip a card you own.\n", ownedCount, len(cards), selectedName)
	desc := header + "\n" + strings.Join(lines, "\n")
	embed := &discordgo.MessageEmbed{
		Title:       "Info Card Locker",
		Description: desc,
		Color:       shared.DefaultEmbedColor,
		Footer:      &discordgo.MessageEmbedFooter{Text: fmt.Sprintf("Page %d/%d", page, totalPages)},
	}

	components := buildLockerComponents(userID, page, totalPages, pageCards, selectedID)
	return embed, components, nil
}

func buildLockerComponents(ownerID string, page, totalPages int, cards []storage.PlayerInfocardStatus, selectedID string) []discordgo.MessageComponent {
	ownerID = strings.TrimSpace(ownerID)
	if ownerID == "" || len(cards) == 0 {
		return nil
	}

	opts := make([]plainSelectMenuOption, 0, len(cards))
	for _, card := range cards {
		label := card.Name
		if label == "" {
			label = card.ID
		}
		if len(label) > 100 {
			label = label[:100]
		}
		desc := "Locked"
		if card.Owned {
			desc = "Owned"
		}
		if card.ID == selectedID {
			if card.Owned {
				desc = "Owned, Equipped"
			} else {
				desc = "Equipped"
			}
		}
		opts = append(opts, plainSelectMenuOption{
			Label:       label,
			Value:       card.ID,
			Description: desc,
			Default:     card.ID == selectedID,
		})
	}

	components := []discordgo.MessageComponent{
		discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{
				plainSelectMenu{
					CustomID:    fmt.Sprintf("%s%s:%d", lockerSelectPrefix, ownerID, page),
					Placeholder: "Select a card to equip",
					Options:     opts,
					MenuType:    discordgo.StringSelectMenu,
				},
			},
		},
	}

	if totalPages > 1 {
		prev := plainButton{
			Label:    "< Prev",
			Style:    discordgo.SecondaryButton,
			CustomID: fmt.Sprintf("%s%s:%d:prev", lockerNavPrefix, ownerID, page),
			Disabled: page <= 1,
		}
		next := plainButton{
			Label:    "Next >",
			Style:    discordgo.SecondaryButton,
			CustomID: fmt.Sprintf("%s%s:%d:next", lockerNavPrefix, ownerID, page),
			Disabled: page >= totalPages,
		}
		components = append(components, discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{prev, next},
		})
	}

	return components
}

func editLockerError(s *discordgo.Session, i *discordgo.InteractionCreate, msg string) {
	if s == nil || i == nil {
		return
	}
	if msg == "" {
		msg = "Locker failed to load."
	}
	if _, err := s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg}); err != nil {
		log.Printf("locker: edit error failed: %v", err)
		_, _ = s.FollowupMessageCreate(i.Interaction, true, &discordgo.WebhookParams{
			Content: msg,
			Flags:   64,
		})
	}
}

// plainSelectMenuOption mirrors discordgo.SelectMenuOption but omits empty emoji fields.
type plainSelectMenuOption struct {
	Label       string                    `json:"label,omitempty"`
	Value       string                    `json:"value"`
	Description string                    `json:"description,omitempty"`
	Emoji       *discordgo.ComponentEmoji `json:"emoji,omitempty"`
	Default     bool                      `json:"default,omitempty"`
}

// plainSelectMenu mirrors discordgo.SelectMenu but uses plain options to avoid empty emoji payloads.
type plainSelectMenu struct {
	MenuType     discordgo.SelectMenuType `json:"-"`
	CustomID     string                   `json:"custom_id,omitempty"`
	Placeholder  string                   `json:"placeholder,omitempty"`
	MinValues    *int                     `json:"min_values,omitempty"`
	MaxValues    int                      `json:"max_values,omitempty"`
	Options      []plainSelectMenuOption  `json:"options,omitempty"`
	Disabled     bool                     `json:"disabled,omitempty"`
	ChannelTypes []discordgo.ChannelType  `json:"channel_types,omitempty"`
}

func (s plainSelectMenu) Type() discordgo.ComponentType {
	if s.MenuType != 0 {
		return discordgo.ComponentType(s.MenuType)
	}
	return discordgo.SelectMenuComponent
}

func (s plainSelectMenu) MarshalJSON() ([]byte, error) {
	type selectMenu plainSelectMenu
	return json.Marshal(struct {
		selectMenu
		Type discordgo.ComponentType `json:"type"`
	}{
		selectMenu: selectMenu(s),
		Type:       s.Type(),
	})
}
