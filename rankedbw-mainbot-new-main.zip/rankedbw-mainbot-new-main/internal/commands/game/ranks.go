package game

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Ranks struct{}

func NewRanks() *Ranks        { return &Ranks{} }
func (c *Ranks) Name() string { return "ranks" }
func (c *Ranks) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Checkout all the ranks available.",
	}
}

func (c *Ranks) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	dbRanks, err := storage.ListRanks(ctx)
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to load ranks: %v", err))
		return
	}
	if len(dbRanks) == 0 {
		shared.RespondEphemeral(s, i, "No ranks are configured in the database.")
		return
	}

	var builder strings.Builder
	for _, rank := range dbRanks {
		emojiName := strings.ToLower(strings.ReplaceAll(strings.TrimSpace(rank.Name), " ", ""))

		emoji := fmt.Sprintf(":rank%s:", emojiName)
		if id := strings.TrimSpace(rank.EmojiID); id != "" {
			emoji = fmt.Sprintf("<:rank%s:%s>", emojiName, id)
		}

		displayName := fmt.Sprintf("@%s", rank.Name)
		if roleID := strings.TrimSpace(rank.RoleID); roleID != "" {
			// Use role mention format so it looks like a tag; AllowedMentions blocks actual pings.
			displayName = fmt.Sprintf("<@&%s>", roleID)
		}

		line := fmt.Sprintf("%s %s: **%d Elo** `+%d -%d` MVP: `+%d`\n",
			emoji, displayName, rank.Min, rank.Gain, rank.Loss, rank.MVP)
		builder.WriteString(line)
	}

	embed := &discordgo.MessageEmbed{
		Title:       "Ranked Bedwars Ranks",
		Description: builder.String(),
		Color:       shared.DefaultEmbedColor,
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
			AllowedMentions: &discordgo.MessageAllowedMentions{
				Parse: []discordgo.AllowedMentionType{},
			},
		},
	})
}
