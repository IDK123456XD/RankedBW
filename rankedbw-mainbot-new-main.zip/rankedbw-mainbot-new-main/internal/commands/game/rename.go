package game

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/commands/registration"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Rename struct{}

func NewRename() *Rename       { return &Rename{} }
func (c *Rename) Name() string { return "rename" }
func (c *Rename) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Rename yourself to Ranked Bedwars format.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "minecraft_name",
				Description: "Your Minecraft username.",
				Required:    true,
			},
		},
	}
}

func (c *Rename) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	ign := strings.TrimSpace(i.ApplicationCommandData().Options[0].StringValue())
	if ign == "" {
		shared.Respond(s, i, "Please provide a valid Minecraft name.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	key, err := storage.GetHypixelAPIKey(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Hypixel API key not configured: %v", err))
		return
	}

	uuid, err := registration.MojangUUID(ctx, ign)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Could not resolve IGN: %v", err))
		return
	}

	linked, hypixelName, err := registration.HypixelDiscord(ctx, key, uuid)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Hypixel lookup failed: %v", err))
		return
	}

	user := i.Member.User
	fullTag := user.Username
	if user.Discriminator != "0" && user.Discriminator != "" {
		fullTag = user.Username + "#" + user.Discriminator
	}
	candidates := []string{
		strings.ToLower(fullTag),
		strings.ToLower(user.Username),
	}
	match := false
	linkedLower := strings.ToLower(strings.TrimSpace(linked))
	for _, candidate := range candidates {
		if candidate == linkedLower {
			match = true
			break
		}
	}
	if !match {
		msg := "Your Hypixel **Social > Discord** isn't set to your current Discord username.\n" +
			"Open **Hypixel > Social Media > Discord** and set it to **" + fullTag + "**, then try again."
		shared.EditError(s, i, msg)
		return
	}

	if record, err := storage.GetPlayerByMinecraftName(ctx, ign); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to validate IGN: %v", err))
		return
	} else if record != nil && record.UserID != user.ID {
		shared.EditError(s, i, "That Minecraft name is already linked to another Discord user.")
		return
	}

	if record, err := storage.GetPlayerByUUID(ctx, uuid); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to validate UUID: %v", err))
		return
	} else if record != nil && record.UserID != user.ID {
		shared.EditError(s, i, "That Minecraft account is already linked to another Discord user.")
		return
	}

	displayName := hypixelName
	if strings.TrimSpace(displayName) == "" {
		displayName = ign
	}

	result, err := registration.UpsertPlayer(ctx, registration.Params{
		UserID:      user.ID,
		IGN:         ign,
		DisplayName: displayName,
		UUID:        uuid,
	})
	if err != nil {
		if errors.Is(err, registration.ErrDuplicatePlayer) {
			shared.EditError(s, i, "That Minecraft account is linked to another Discord user.")
			return
		}
		shared.EditError(s, i, fmt.Sprintf("Failed to update your profile: %v", err))
		return
	}

	message := fmt.Sprintf("You have been renamed to **%s**!", result.MinecraftName)
	if result.Refreshed {
		message = fmt.Sprintf("You have refreshed your data and have been renamed to **%s**!", result.MinecraftName)
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})

	nickname := registration.BuildNickname(result.Elo, result.MinecraftName)
	if err := s.GuildMemberNickname(i.GuildID, user.ID, nickname); err != nil {
		log.Printf("rename: failed to update nickname for %s: %v", user.ID, err)
	}
}
