package game

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type leaderboardMetric struct {
	Column string
	Name   string
	Desc   bool
}

// plainButton mirrors discordgo.Button but omits the emoji field entirely to avoid sending empty emoji payloads.
type plainButton struct {
	Label    string                `json:"label,omitempty"`
	Style    discordgo.ButtonStyle `json:"style"`
	Disabled bool                  `json:"disabled,omitempty"`
	CustomID string                `json:"custom_id,omitempty"`
}

func (plainButton) Type() discordgo.ComponentType {
	return discordgo.ButtonComponent
}

func (b plainButton) MarshalJSON() ([]byte, error) {
	// match discordgo.Button marshal behavior minus emoji/url fields
	type btn plainButton
	if b.Style == 0 {
		b.Style = discordgo.PrimaryButton
	}
	return discordgo.Marshal(struct {
		btn
		Type discordgo.ComponentType `json:"type"`
	}{
		btn:  btn(b),
		Type: b.Type(),
	})
}

const leaderboardNavPrefix = "lb_nav:"

var leaderboardMetrics = map[string]leaderboardMetric{
	"elo":    {Column: `ps."elo"`, Name: "Highest ELO", Desc: true},
	"wins":   {Column: `ps."wins"`, Name: "Most Wins", Desc: true},
	"losses": {Column: `ps."losses"`, Name: "Most Losses", Desc: true},
	"games":  {Column: `ps."gamesPlayed"`, Name: "Most Games Played", Desc: true},
	"mvps":   {Column: `ps."mvps"`, Name: "Most MVPs", Desc: true},
	"streak": {Column: `ps."streak"`, Name: "Best Streak", Desc: true},
}

type Leaderboard struct{}

func NewLeaderboard() *Leaderboard  { return &Leaderboard{} }
func (c *Leaderboard) Name() string { return "leaderboard" }
func (c *Leaderboard) Build() *discordgo.ApplicationCommand {
	metricChoices := []*discordgo.ApplicationCommandOptionChoice{
		{Name: "ELO", Value: "elo"},
		{Name: "Wins", Value: "wins"},
		{Name: "Losses", Value: "losses"},
		{Name: "Games Played", Value: "games"},
		{Name: "MVPs", Value: "mvps"},
		{Name: "Streak", Value: "streak"},
	}
	min := float64(1)
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "View leaderboards for different categories.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "category",
				Description: "Leaderboard category (default: elo).",
				Choices:     metricChoices,
			},
			{
				Type:        discordgo.ApplicationCommandOptionInteger,
				Name:        "page",
				Description: "Page number (10 per page).",
				MinValue:    &min,
			},
		},
	}
}

func (c *Leaderboard) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	metricKey := "elo"
	page := int64(1)
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "category":
			metricKey = opt.StringValue()
		case "page":
			page = opt.IntValue()
		}
	}
	if _, ok := leaderboardMetrics[metricKey]; !ok {
		shared.Respond(s, i, "Unknown leaderboard category.")
		return
	}
	if page < 1 {
		page = 1
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	userID := requesterID(i)
	embed, components, err := c.renderLeaderboard(ctx, metricKey, page, userID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to render leaderboard: %v", err))
		return
	}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds:     &[]*discordgo.MessageEmbed{embed},
		Components: &components,
	})
}

// HandleComponent processes pagination button clicks.
func (c *Leaderboard) HandleComponent(s *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if i == nil || i.MessageComponentData().CustomID == "" {
		return false
	}
	customID := i.MessageComponentData().CustomID
	if !strings.HasPrefix(customID, leaderboardNavPrefix) {
		return false
	}

	parts := strings.Split(strings.TrimPrefix(customID, leaderboardNavPrefix), ":")
	if len(parts) != 4 {
		return false
	}

	metricKey := strings.TrimSpace(parts[0])
	currentPage, err := strconv.ParseInt(strings.TrimSpace(parts[1]), 10, 64)
	if err != nil {
		shared.RespondEphemeral(s, i, "Invalid page data for this leaderboard.")
		return true
	}
	requester := strings.TrimSpace(parts[2])
	direction := strings.TrimSpace(parts[3])

	if requester == "" || requester != requesterID(i) {
		shared.RespondEphemeral(s, i, "Only the user who ran this command can use these buttons.")
		return true
	}

	if direction == "prev" {
		currentPage--
	} else if direction == "next" {
		currentPage++
	} else {
		return false
	}
	if currentPage < 1 {
		currentPage = 1
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	embed, components, err := c.renderLeaderboard(ctx, metricKey, currentPage, requester)
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to load leaderboard: %v", err))
		return true
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseUpdateMessage,
		Data: &discordgo.InteractionResponseData{
			Embeds:     []*discordgo.MessageEmbed{embed},
			Components: components,
		},
	})

	return true
}

func (c *Leaderboard) renderLeaderboard(ctx context.Context, metricKey string, page int64, requester string) (*discordgo.MessageEmbed, []discordgo.MessageComponent, error) {
	if page < 1 {
		page = 1
	}

	metric, ok := leaderboardMetrics[metricKey]
	if !ok {
		return nil, nil, fmt.Errorf("unknown leaderboard category")
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to determine active season: %w", err)
	}

	offset := int((page - 1) * 10)
	rows, err := storage.SeasonLeaderboard(ctx, seasonID, metric.Column, 10, offset, metric.Desc)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to fetch leaderboard: %w", err)
	}
	if len(rows) == 0 {
		return nil, nil, fmt.Errorf("no data available for this leaderboard")
	}

	totalCount, err := storage.SeasonLeaderboardTotal(ctx, seasonID)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to count leaderboard: %w", err)
	}
	totalPages := (totalCount + 9) / 10
	if totalPages < 1 {
		totalPages = 1
	}

	if page > int64(totalPages) {
		page = int64(totalPages)
		offset = int((page - 1) * 10)
		rows, err = storage.SeasonLeaderboard(ctx, seasonID, metric.Column, 10, offset, metric.Desc)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to fetch leaderboard: %w", err)
		}
	}

	lines := make([]string, 0, len(rows))
	for idx, row := range rows {
		pos := offset + idx + 1
		lines = append(lines, fmt.Sprintf("`#%d` **%s** - %d", pos, row.MinecraftName, row.Value))
	}

	description := fmt.Sprintf("**%s** (Page %d)\n%s", metric.Name, page, strings.Join(lines, "\n"))
	embed := &discordgo.MessageEmbed{
		Title:       "Leaderboard",
		Description: description,
		Color:       0x004CFF,
		Footer: &discordgo.MessageEmbedFooter{
			Text: fmt.Sprintf("Page %d/%d", page, totalPages),
		},
	}

	components := buildLeaderboardNav(metricKey, page, totalPages, requester)
	return embed, components, nil
}

func buildLeaderboardNav(metricKey string, page int64, totalPages int, requester string) []discordgo.MessageComponent {
	if requester == "" {
		return nil
	}

	prev := plainButton{
		Label:    "< Prev",
		Style:    discordgo.SecondaryButton,
		CustomID: fmt.Sprintf("%s%s:%d:%s:prev", leaderboardNavPrefix, metricKey, page, requester),
		Disabled: page <= 1,
	}
	next := plainButton{
		Label:    "Next >",
		Style:    discordgo.SecondaryButton,
		CustomID: fmt.Sprintf("%s%s:%d:%s:next", leaderboardNavPrefix, metricKey, page, requester),
		Disabled: page >= int64(totalPages),
	}

	row := discordgo.ActionsRow{Components: []discordgo.MessageComponent{prev, next}}
	return []discordgo.MessageComponent{row}
}

func requesterID(i *discordgo.InteractionCreate) string {
	if i == nil {
		return ""
	}
	if i.Member != nil && i.Member.User != nil {
		return strings.TrimSpace(i.Member.User.ID)
	}
	if i.User != nil {
		return strings.TrimSpace(i.User.ID)
	}
	return ""
}
