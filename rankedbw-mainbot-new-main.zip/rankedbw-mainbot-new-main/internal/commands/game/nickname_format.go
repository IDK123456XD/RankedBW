package game

import (
	"strings"

	"rbw-bot/internal/commands/registration"
	"rbw-bot/internal/storage"
)

func composeDisplayName(player *storage.PlayerRecord, stats *storage.PlayerSeasonStats, override *string) string {
	base := player.MinecraftName

	var nick string
	if override != nil {
		nick = strings.TrimSpace(*override)
	} else if player.Nickname.Valid {
		nick = strings.TrimSpace(player.Nickname.String)
	}
	if nick != "" {
		base += " | " + nick
	}

	if player.EloPrefix && stats != nil {
		return registration.BuildNickname(stats.Elo, base)
	}
	return base
}
