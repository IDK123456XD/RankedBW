package partycmd

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/party"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

const (
	partyInviteComponentPrefix = "party_invite:"
	inviteEmbedColor           = 0x5865F2
	inviteAcceptedColor        = 0x57F287
	inviteDeclinedColor        = 0xED4245
)

type Party struct {
	svc *party.Service
}

func NewParty(svc *party.Service) *Party {
	return &Party{svc: svc}
}

func (p *Party) Name() string { return "party" }

func (p *Party) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        p.Name(),
		Description: "Manage Ranked Bedwars parties.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "invite",
				Description: "Invite someone to your party.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "Who to invite.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "accept",
				Description: "Accept a party invite.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "leader",
						Description: "Which party leader you're accepting.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List members of a party.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "member",
						Description: "Show the party for this player (defaults to you).",
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "scope",
						Description: "Set to ALL to list every party.",
						Choices: []*discordgo.ApplicationCommandOptionChoice{
							{Name: "ALL", Value: "ALL"},
						},
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "leave",
				Description: "Leave your current party.",
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "disband",
				Description: "Disband a party.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "leader",
						Description: "Party leader to disband (admins only).",
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "disbandall",
				Description: "Disband every party (admins only).",
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "promote",
				Description: "Promote a member to party leader.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "Member to promote.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "kick",
				Description: "Kick a member from your party.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "Member to remove.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "ignore",
				Description: "Ignore or unignore party invites from a player.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "Player to ignore.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionBoolean,
						Name:        "enabled",
						Description: "Enable ignore (true) or remove ignore (false).",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "autowarp",
				Description: "Toggle party auto-warp.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionBoolean,
						Name:        "enabled",
						Description: "Enable auto-warp.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "warp",
				Description: "Warp party members to your voice channel.",
			},
		},
	}
}

func (p *Party) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	sub := i.ApplicationCommandData().Options[0]
	switch sub.Name {
	case "invite":
		p.handleInvite(s, i, sub)
	case "accept":
		p.handleAccept(s, i, sub)
	case "list":
		p.handleList(s, i, sub)
	case "leave":
		p.handleLeave(s, i)
	case "disband":
		p.handleDisband(s, i, sub)
	case "disbandall":
		p.handleDisbandAll(s, i)
	case "promote":
		p.handlePromote(s, i, sub)
	case "kick":
		p.handleKick(s, i, sub)
	case "ignore":
		p.handleIgnore(s, i, sub)
	case "autowarp":
		p.handleAutoWarp(s, i, sub)
	case "warp":
		p.handleWarp(s, i)
	}
}

func (p *Party) HandleComponent(s *discordgo.Session, i *discordgo.InteractionCreate) bool {
	data := i.MessageComponentData()
	if !strings.HasPrefix(data.CustomID, partyInviteComponentPrefix) {
		return false
	}

	payload := strings.TrimPrefix(data.CustomID, partyInviteComponentPrefix)
	parts := strings.Split(payload, ":")
	if len(parts) != 3 {
		shared.RespondEphemeral(s, i, "Invalid invite action.")
		return true
	}

	action, leaderID, targetID := parts[0], parts[1], parts[2]
	user := interactionUser(i)
	if user == nil || user.ID != targetID {
		shared.RespondEphemeral(s, i, "This invite is not for you.")
		return true
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	switch action {
	case "accept":
		if _, err := p.svc.Accept(ctx, leaderID, targetID); err != nil {
			shared.RespondEphemeral(s, i, err.Error())
			return true
		}
		content := fmt.Sprintf("%s accepted %s's party invite.", mentionOrID(user), mentionFromID(leaderID))
		embed := &discordgo.MessageEmbed{
			Title:       "Party Invite Accepted",
			Description: fmt.Sprintf("%s joined %s's party.", mentionOrID(user), mentionFromID(leaderID)),
			Color:       inviteAcceptedColor,
		}
		return respondInviteUpdate(s, i, content, embed)
	case "decline":
		if _, err := p.svc.Decline(ctx, leaderID, targetID); err != nil {
			shared.RespondEphemeral(s, i, err.Error())
			return true
		}
		content := fmt.Sprintf("%s declined %s's party invite.", mentionOrID(user), mentionFromID(leaderID))
		embed := &discordgo.MessageEmbed{
			Title:       "Party Invite Declined",
			Description: content,
			Color:       inviteDeclinedColor,
		}
		return respondInviteUpdate(s, i, content, embed)
	default:
		shared.RespondEphemeral(s, i, "Unknown invite action.")
		return true
	}
}

func (p *Party) handleInvite(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	target := opt.Options[0].UserValue(s)
	if target == nil {
		shared.Respond(s, i, "Unable to resolve that user.")
		return
	}
	leader := interactionUser(i)
	if leader == nil {
		shared.Respond(s, i, "Unable to determine your Discord user.")
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if _, err := p.svc.Invite(ctx, leader.ID, target.ID); err != nil {
		shared.Respond(s, i, err.Error())
		return
	}

	response := fmt.Sprintf("Invited %s to your party.", target.Mention())
	shared.Respond(s, i, response)
	p.sendInviteMessage(s, i.ChannelID, leader, target)
}

func (p *Party) handleAccept(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	leader := opt.Options[0].UserValue(s)
	if leader == nil {
		shared.Respond(s, i, "Please select a valid player.")
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if _, err := p.svc.Accept(ctx, leader.ID, i.Member.User.ID); err != nil {
		shared.Respond(s, i, err.Error())
		return
	}

	embed := &discordgo.MessageEmbed{
		Title:       "Party Invite Accepted",
		Description: fmt.Sprintf("You have joined %s's party.", leader.Mention()),
		Color:       inviteAcceptedColor,
	}
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}

func (p *Party) handleList(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	targetUser := interactionUser(i)
	listAll := false
	if opt != nil {
		for _, sub := range opt.Options {
			switch sub.Type {
			case discordgo.ApplicationCommandOptionUser:
				if user := sub.UserValue(s); user != nil {
					targetUser = user
				} else {
					shared.Respond(s, i, "Please select a valid player.")
					return
				}
			case discordgo.ApplicationCommandOptionString:
				if strings.EqualFold(sub.StringValue(), "all") {
					listAll = true
				}
			}
		}
	}

	if listAll {
		p.handleListAll(ctx, s, i)
		return
	}
	if targetUser == nil {
		shared.Respond(s, i, "Unable to determine that player.")
		return
	}

	requester := interactionUser(i)
	if requester == nil {
		shared.Respond(s, i, "Unable to determine your Discord user.")
		return
	}

	targetID := targetUser.ID
	actorID := requester.ID

	party, err := storage.GetPartyByMember(ctx, targetID)
	if err != nil {
		shared.Respond(s, i, fmt.Sprintf("Failed to load party info: %v", err))
		return
	}
	if party == nil {
		msg := fmt.Sprintf("%s is not currently in a party.", mentionOrID(targetUser))
		if targetID == actorID {
			msg = "You are not currently in a party."
		}
		shared.Respond(s, i, msg)
		return
	}

	invites := p.svc.ActiveInvites(party)

	leader := mentionFromID(party.LeaderID)
	memberMentions := make([]string, 0, len(party.Members))
	for _, member := range party.Members {
		if member == party.LeaderID {
			continue
		}
		memberMentions = append(memberMentions, mentionFromID(member))
	}

	inviteLines := "None"
	if len(invites) > 0 {
		var parts []string
		for _, inv := range invites {
			parts = append(parts, fmt.Sprintf("<@%s> (<t:%d:R>)", inv.UserID, inv.InvitedAt.Unix()))
		}
		inviteLines = strings.Join(parts, "\n")
	}

	_, size, err := storage.GetPartySettings(ctx)
	if err != nil {
		size = 4
	}
	capacity := fmt.Sprintf("%d/%d", len(party.Members), size)
	autoWarp := "Off"
	if party.AutoWarp {
		autoWarp = "On"
	}
	created := party.CreatedAt
	createdDisplay := fmt.Sprintf("<t:%d:F> (<t:%d:R>)", created.Unix(), created.Unix())

	title := "Your Party"
	if targetID != actorID {
		title = fmt.Sprintf("%s's Party", displayName(targetUser))
	}

	embed := &discordgo.MessageEmbed{
		Title: title,
		Color: 0x004CFF,
		Fields: []*discordgo.MessageEmbedField{
			{Name: "Created", Value: createdDisplay, Inline: true},
			{Name: "Auto-Warp", Value: autoWarp, Inline: true},
			{Name: "Capacity", Value: capacity, Inline: true},
			{Name: "Leader", Value: leader, Inline: true},
			{Name: "Members", Value: formatMemberList(memberMentions)},
			{Name: "Invites", Value: inviteLines},
		},
	}
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}

func (p *Party) handleListAll(ctx context.Context, s *discordgo.Session, i *discordgo.InteractionCreate) {
	parties, err := storage.ListParties(ctx)
	if err != nil {
		shared.Respond(s, i, fmt.Sprintf("Failed to load parties: %v", err))
		return
	}
	if len(parties) == 0 {
		shared.Respond(s, i, "There are no active parties.")
		return
	}

	totalEligible := 0
	fields := make([]*discordgo.MessageEmbedField, 0, len(parties))
	var shown int
	for idx := range parties {
		party := parties[idx]
		if len(party.Members) <= 1 {
			continue
		}
		totalEligible++
		field := p.buildPartyField(&party)
		field.Name = fmt.Sprintf("Party %d — Leader %s", idx+1, mentionFromID(party.LeaderID))
		fields = append(fields, field)
		shown++
		if len(fields) == 25 {
			break
		}
	}

	if shown == 0 {
		shared.Respond(s, i, "There are no parties with more than one member.")
		return
	}

	desc := fmt.Sprintf("Showing %d party(ies).", shown)
	if shown < totalEligible {
		desc = fmt.Sprintf("Showing %d of %d parties.", shown, totalEligible)
	}

	embed := &discordgo.MessageEmbed{
		Title:       "All Parties",
		Description: desc,
		Color:       0x004CFF,
		Fields:      fields,
	}
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}

func (p *Party) buildPartyField(party *storage.Party) *discordgo.MessageEmbedField {
	leader := mentionFromID(party.LeaderID)
	memberMentions := make([]string, 0, len(party.Members))
	for _, member := range party.Members {
		if member == party.LeaderID {
			continue
		}
		memberMentions = append(memberMentions, mentionFromID(member))
	}
	memberValue := formatMemberList(memberMentions)

	invites := p.svc.ActiveInvites(party)
	inviteValue := "None"
	if len(invites) > 0 {
		lines := make([]string, 0, len(invites))
		for _, inv := range invites {
			lines = append(lines, fmt.Sprintf("<@%s> (<t:%d:R>)", inv.UserID, inv.InvitedAt.Unix()))
		}
		inviteValue = strings.Join(lines, "\n")
	}

	autoWarp := "Off"
	if party.AutoWarp {
		autoWarp = "On"
	}
	createdDisplay := fmt.Sprintf("<t:%d:F>", party.CreatedAt.Unix())

	return &discordgo.MessageEmbedField{
		Name:  "Party",
		Value: fmt.Sprintf("Leader: %s\nCreated: %s\nAuto-Warp: %s\nMembers:\n%s\nInvites:\n%s", leader, createdDisplay, autoWarp, memberValue, inviteValue),
	}
}

func formatMemberList(members []string) string {
	if len(members) == 0 {
		return "None"
	}
	return strings.Join(members, "\n")
}

func (p *Party) handleLeave(s *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := p.svc.Leave(ctx, i.Member.User.ID); err != nil {
		shared.Respond(s, i, err.Error())
		return
	}
	shared.Respond(s, i, "You have left the party.")
}

func (p *Party) handleDisband(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	var targetLeader string
	if len(opt.Options) > 0 {
		target := opt.Options[0].UserValue(s)
		if target == nil {
			shared.Respond(s, i, "Please choose a valid leader.")
			return
		}
		if !hasAdminPermission(i.Member) {
			shared.Respond(s, i, "Only moderators can disband other parties.")
			return
		}
		targetLeader = target.ID
	} else {
		targetLeader = i.Member.User.ID
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if targetLeader == i.Member.User.ID {
		if err := p.svc.Disband(ctx, targetLeader); err != nil {
			shared.Respond(s, i, err.Error())
			return
		}
		shared.Respond(s, i, "Your party has been disbanded.")
		return
	}

	if err := p.svc.Disband(ctx, targetLeader); err != nil {
		shared.Respond(s, i, err.Error())
		return
	}
	shared.Respond(s, i, "That party has been disbanded.")
}

func (p *Party) handleDisbandAll(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasAdminPermission(i.Member) {
		shared.Respond(s, i, "Only moderators can disband all parties.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := p.svc.DisbandAll(ctx); err != nil {
		shared.Respond(s, i, fmt.Sprintf("Failed to disband parties: %v", err))
		return
	}
	shared.Respond(s, i, "All parties have been disbanded.")
}

func (p *Party) handlePromote(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	target := opt.Options[0].UserValue(s)
	if target == nil {
		shared.Respond(s, i, "Select a valid member to promote.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := p.svc.Promote(ctx, i.Member.User.ID, target.ID); err != nil {
		shared.Respond(s, i, err.Error())
		return
	}
	shared.Respond(s, i, fmt.Sprintf("Promoted %s to leader.", target.Mention()))
}

func (p *Party) handleKick(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	target := opt.Options[0].UserValue(s)
	if target == nil {
		shared.Respond(s, i, "Select a valid member to kick.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := p.svc.Kick(ctx, i.Member.User.ID, target.ID); err != nil {
		shared.Respond(s, i, err.Error())
		return
	}
	shared.Respond(s, i, fmt.Sprintf("Removed %s from the party.", target.Mention()))
}

func (p *Party) handleIgnore(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	target := opt.Options[0].UserValue(s)
	if target == nil {
		shared.Respond(s, i, "Select a valid user.")
		return
	}
	enabled := opt.Options[1].BoolValue()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := p.svc.Ignore(ctx, i.Member.User.ID, target.ID, enabled); err != nil {
		shared.Respond(s, i, err.Error())
		return
	}
	if enabled {
		shared.Respond(s, i, fmt.Sprintf("You are now ignoring invites from %s.", target.Mention()))
	} else {
		shared.Respond(s, i, fmt.Sprintf("You will now receive invites from %s.", target.Mention()))
	}
}

func (p *Party) handleAutoWarp(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	enabled := opt.Options[0].BoolValue()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if _, err := p.svc.ToggleAutoWarp(ctx, i.Member.User.ID, enabled); err != nil {
		shared.Respond(s, i, err.Error())
		return
	}
	state := "disabled"
	if enabled {
		state = "enabled"
	}
	shared.Respond(s, i, fmt.Sprintf("Auto-warp has been %s.", state))
}

func (p *Party) handleWarp(s *discordgo.Session, i *discordgo.InteractionCreate) {
	vs := findVoiceState(s.State, i.GuildID, i.Member.User.ID)
	if vs == nil || vs.ChannelID == "" {
		shared.Respond(s, i, "You must be connected to a voice channel to warp your party.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	targets, err := p.svc.WarpTargets(ctx, i.Member.User.ID)
	if err != nil {
		shared.Respond(s, i, err.Error())
		return
	}
	if len(targets) == 0 {
		shared.Respond(s, i, "There are no members to warp.")
		return
	}
	for _, memberID := range targets {
		_ = s.GuildMemberMove(i.GuildID, memberID, &vs.ChannelID)
	}
	shared.Respond(s, i, "Warped your party to your voice channel.")
}

func (p *Party) sendInviteMessage(s *discordgo.Session, channelID string, leader, target *discordgo.User) {
	if s == nil || channelID == "" || leader == nil || target == nil {
		return
	}
	expiresAt := time.Now().Add(party.InviteTTL)
	expiry := fmt.Sprintf("<t:%d:R>", expiresAt.Unix())
	content := fmt.Sprintf("%s, you have been invited to %s's party.", mentionOrID(target), mentionOrID(leader))
	embed := &discordgo.MessageEmbed{
		Title:       "Party Invite",
		Description: fmt.Sprintf("%s has invited you to join their party.\nThis invite expires %s.", mentionOrID(leader), expiry),
		Color:       inviteEmbedColor,
		Fields: []*discordgo.MessageEmbedField{
			{Name: "Leader", Value: mentionOrID(leader), Inline: true},
			{Name: "Invited", Value: mentionOrID(target), Inline: true},
			{Name: "Expires", Value: expiry, Inline: true},
		},
	}
	_, _ = s.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
		Content:    content,
		Embeds:     []*discordgo.MessageEmbed{embed},
		Components: partyInviteComponents(leader.ID, target.ID),
		AllowedMentions: &discordgo.MessageAllowedMentions{
			Users: []string{target.ID},
		},
	})
}

func respondInviteUpdate(s *discordgo.Session, i *discordgo.InteractionCreate, content string, embed *discordgo.MessageEmbed) bool {
	data := &discordgo.InteractionResponseData{
		Content:    content,
		Embeds:     []*discordgo.MessageEmbed{embed},
		Components: []discordgo.MessageComponent{},
	}
	return s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseUpdateMessage,
		Data: data,
	}) == nil
}

func partyInviteComponents(leaderID, targetID string) []discordgo.MessageComponent {
	if leaderID == "" || targetID == "" {
		return nil
	}
	return []discordgo.MessageComponent{
		discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{
				discordgo.Button{
					Label:    "Accept",
					Style:    discordgo.PrimaryButton,
					Emoji:    discordgo.ComponentEmoji{Name: "✅"},
					CustomID: partyInviteComponentID("accept", leaderID, targetID),
				},
				discordgo.Button{
					Label:    "Decline",
					Style:    discordgo.DangerButton,
					Emoji:    discordgo.ComponentEmoji{Name: "✖"},
					CustomID: partyInviteComponentID("decline", leaderID, targetID),
				},
			},
		},
	}
}

func partyInviteComponentID(action, leaderID, targetID string) string {
	return fmt.Sprintf("%s%s:%s:%s", partyInviteComponentPrefix, action, leaderID, targetID)
}

func interactionUser(i *discordgo.InteractionCreate) *discordgo.User {
	if i == nil {
		return nil
	}
	if i.Member != nil && i.Member.User != nil {
		return i.Member.User
	}
	return i.User
}

func mentionOrID(u *discordgo.User) string {
	if u == nil {
		return ""
	}
	if mention := u.Mention(); mention != "" {
		return mention
	}
	return fmt.Sprintf("<@%s>", u.ID)
}

func mentionFromID(userID string) string {
	if userID == "" {
		return ""
	}
	return fmt.Sprintf("<@%s>", userID)
}

func displayName(u *discordgo.User) string {
	if u == nil {
		return "Unknown"
	}
	if u.Username != "" {
		return u.Username
	}
	return u.ID
}

func findVoiceState(state *discordgo.State, guildID, userID string) *discordgo.VoiceState {
	if state == nil {
		return nil
	}
	guild, err := state.Guild(guildID)
	if err != nil || guild == nil {
		return nil
	}
	for _, vs := range guild.VoiceStates {
		if vs.UserID == userID {
			return vs
		}
	}
	return nil
}

func hasAdminPermission(member *discordgo.Member) bool {
	if member == nil {
		return false
	}
	return member.Permissions&int64(discordgo.PermissionAdministrator) != 0
}
