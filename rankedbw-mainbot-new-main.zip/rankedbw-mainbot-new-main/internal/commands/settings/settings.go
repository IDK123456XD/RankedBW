package settings

import (
	"context"
	"fmt"
	"log"
	"path/filepath"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/queue"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

var channelSettingChoices = []*discordgo.ApplicationCommandOptionChoice{
	{Name: "logChannelId", Value: "logChannelId"},
	{Name: "punishmentsChannelId", Value: "punishmentsChannelId"},
	{Name: "staff_punishment_logs", Value: "staff_punishment_logs"},
	{Name: "supportChannelId", Value: "supportChannelId"},
	{Name: "queueLogChannelId", Value: "queueLogChannelId"},
	{Name: "queueThreadChannelId", Value: "queueThreadChannelId"},
	{Name: "waitingRoomVcId", Value: "waitingRoomVcId"},
	{Name: "scoringChannelId", Value: "scoringChannelId"},
	{Name: "game_resultls_channel", Value: "game_resultls_channel"},
	{Name: "transcript_channel_id", Value: "transcript_channel_id"},
	{Name: "screen_share_category", Value: "screen_share_category"},
	{Name: "alerts", Value: "alerts"},
	{Name: "pitAnnouncementsChannelId", Value: "pitAnnouncementsChannelId"},
	{Name: "pitLogChannelId", Value: "pitLogChannelId"},
	{Name: "premiumAnnouncementsChannelId", Value: "premiumAnnouncementsChannelId"},
	{Name: "premiumLogChannelId", Value: "premiumLogChannelId"},
	{Name: "pugsAnnouncementsChannelId", Value: "pugsAnnouncementsChannelId"},
	{Name: "pugsLogChannelId", Value: "pugsLogChannelId"},
	{Name: "pupsAnnouncementsChannelId", Value: "pupsAnnouncementsChannelId"},
	{Name: "pupsLogChannelId", Value: "pupsLogChannelId"},
	{Name: "screenshare_logs_channel", Value: "screenshare_logs_channel"},
	{Name: "ss_transcript", Value: "ss_transcript"},
}

var roleSettingChoices = []*discordgo.ApplicationCommandOptionChoice{
	{Name: "register_rank", Value: "register_rank"},
	{Name: "rankedBanRoleId", Value: "rankedBanRoleId"},
	{Name: "mutedRoleId", Value: "mutedRoleId"},
	{Name: "pitRoleId", Value: "pitRoleId"},
	{Name: "pitManagerRoleId", Value: "pitManagerRoleId"},
	{Name: "pitOwnerRoleId", Value: "pitOwnerRoleId"},
	{Name: "premiumRoleId", Value: "premiumRoleId"},
	{Name: "premiumManagerRoleId", Value: "premiumManagerRoleId"},
	{Name: "pugsRoleId", Value: "pugsRoleId"},
	{Name: "pugsManagerRoleId", Value: "pugsManagerRoleId"},
	{Name: "pugsOwnerRoleId", Value: "pugsOwnerRoleId"},
	{Name: "pugsTrialRoleId", Value: "pugsTrialRoleId"},
	{Name: "pugsSpecRoleId", Value: "pugsSpecRoleId"},
	{Name: "pupsRoleId", Value: "pupsRoleId"},
	{Name: "pupsManagerRoleId", Value: "pupsManagerRoleId"},
	{Name: "pupsOwnerRoleId", Value: "pupsOwnerRoleId"},
	{Name: "pupsTrialRoleId", Value: "pupsTrialRoleId"},
	{Name: "staff", Value: "staff"},
	{Name: "screensharer_role_id", Value: "screensharer_role_id"},
	{Name: "ss_manager_role_id", Value: "ss_manager_role_id"},
	{Name: "frozen_role_id", Value: "frozen_role_id"},
}

var channelColumns = map[string]string{
	"logChannelId":                  "logChannelId",
	"punishmentsChannelId":          "punishmentsChannelId",
	"staff_punishment_logs":         "staff_punishment_logs",
	"supportChannelId":              "supportChannelId",
	"queueLogChannelId":             "queueLogChannelId",
	"queueThreadChannelId":          "queueThreadChannelId",
	"waitingRoomVcId":               "waitingRoomVcId",
	"scoringChannelId":              "scoringChannelId",
	"game_resultls_channel":         "game_resultls_channel",
	"transcript_channel_id":         "transcript_channel_id",
	"screen_share_category":         "screen_share_category",
	"alerts":                        "alerts",
	"pitAnnouncementsChannelId":     "pitAnnouncementsChannelId",
	"pitLogChannelId":               "pitLogChannelId",
	"premiumAnnouncementsChannelId": "premiumAnnouncementsChannelId",
	"premiumLogChannelId":           "premiumLogChannelId",
	"pugsAnnouncementsChannelId":    "pugsAnnouncementsChannelId",
	"pugsLogChannelId":              "pugsLogChannelId",
	"pupsAnnouncementsChannelId":    "pupsAnnouncementsChannelId",
	"pupsLogChannelId":              "pupsLogChannelId",
	"screenshare_logs_channel":      "screenshare_logs_channel",
	"ss_transcript":                 "ss_transcript",
}

var roleColumns = map[string]string{
	"register_rank":        "register_rank",
	"rankedBanRoleId":      "rankedBanRoleId",
	"mutedRoleId":          "mutedRoleId",
	"pitRoleId":            "pitRoleId",
	"pitManagerRoleId":     "pitManagerRoleId",
	"pitOwnerRoleId":       "pitOwnerRoleId",
	"premiumRoleId":        "premiumRoleId",
	"premiumManagerRoleId": "premiumManagerRoleId",
	"pugsRoleId":           "pugsRoleId",
	"pugsManagerRoleId":    "pugsManagerRoleId",
	"pugsOwnerRoleId":      "pugsOwnerRoleId",
	"pugsTrialRoleId":      "pugsTrialRoleId",
	"pugsSpecRoleId":       "pugsSpecRoleId",
	"pupsRoleId":           "pupsRoleId",
	"pupsManagerRoleId":    "pupsManagerRoleId",
	"pupsOwnerRoleId":      "pupsOwnerRoleId",
	"pupsTrialRoleId":      "pupsTrialRoleId",
	"staff":                "staff",
	"screensharer_role_id": "screensharer_role_id",
	"ss_manager_role_id":   "ss_manager_role_id",
	"frozen_role_id":       "frozen_role_id",
}

type Settings struct {
	queueSvc *queue.Service
}

func NewSettings(queueSvc *queue.Service) *Settings {
	return &Settings{queueSvc: queueSvc}
}
func (s *Settings) Name() string { return "settings" }

func (s *Settings) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        s.Name(),
		Description: "Change Ranked Bedwars settings.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Name:        "ruleset",
				Description: "Upload a .txt file that /rules will display.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "file",
						Description: "The .txt ruleset file",
						Type:        discordgo.ApplicationCommandOptionAttachment,
						Required:    true,
					},
				},
			},
			{
				Name:        "claimelo",
				Description: "Toggle claim elo on or off.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "toggle",
						Description: "true to enable, false to disable",
						Type:        discordgo.ApplicationCommandOptionBoolean,
						Required:    true,
					},
				},
			},
			{
				Name:        "gamestyle",
				Description: "The style of bedwars.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "style",
						Description: "Pick the game style",
						Type:        discordgo.ApplicationCommandOptionString,
						Required:    true,
						Choices: []*discordgo.ApplicationCommandOptionChoice{
							{Name: "2v2", Value: "2v2"},
							{Name: "4v4", Value: "4v4"},
						},
					},
				},
			},
			{
				Name:        "hypixelapikey",
				Description: "Set the current API key.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "key",
						Description: "Hypixel API key (UUID)",
						Type:        discordgo.ApplicationCommandOptionString,
						Required:    true,
					},
				},
			},
			{
				Name:        "party",
				Description: "Toggle parties on or off.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "toggle",
						Description: "Turn party system on or off",
						Type:        discordgo.ApplicationCommandOptionString,
						Required:    true,
						Choices: []*discordgo.ApplicationCommandOptionChoice{
							{Name: "on", Value: "on"},
							{Name: "off", Value: "off"},
						},
					},
				},
			},
			{
				Name:        "partysize",
				Description: "Set a party size. (ex. 1, 2, 3, 4)",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "party-size",
						Description: "Party size",
						Type:        discordgo.ApplicationCommandOptionInteger,
						Required:    true,
						MinValue:    &[]float64{1}[0],
						MaxValue:    4,
					},
				},
			},
			{
				Name:        "picking",
				Description: "Select the picking phase setup.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "pick-type",
						Description: "1, or 2",
						Type:        discordgo.ApplicationCommandOptionString,
						Required:    true,
						Choices: []*discordgo.ApplicationCommandOptionChoice{
							{Name: "1", Value: "1"},
							{Name: "2", Value: "2"},
						},
					},
				},
			},
			{
				Name:        "logchannel",
				Description: "Set the channel where bot commands are logged.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:         "channel",
						Description:  "Channel to post logs (leave empty to clear).",
						Type:         discordgo.ApplicationCommandOptionChannel,
						ChannelTypes: []discordgo.ChannelType{discordgo.ChannelTypeGuildText, discordgo.ChannelTypeGuildNews},
					},
				},
			},
			{
				Name:        "punishchannel",
				Description: "Set the channel for punishment notifications.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:         "channel",
						Description:  "Channel to post punishment notifications (leave empty to clear).",
						Type:         discordgo.ApplicationCommandOptionChannel,
						ChannelTypes: []discordgo.ChannelType{discordgo.ChannelTypeGuildText, discordgo.ChannelTypeGuildNews},
					},
				},
			},
			{
				Name:        "supportchannel",
				Description: "Set the channel mentioned for support tickets.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:         "channel",
						Description:  "Support channel mention (leave empty to clear).",
						Type:         discordgo.ApplicationCommandOptionChannel,
						ChannelTypes: []discordgo.ChannelType{discordgo.ChannelTypeGuildText, discordgo.ChannelTypeGuildNews},
					},
				},
			},
			{
				Name:        "setchannel",
				Description: "Set a channel-based setting.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "key",
						Description: "Which setting to update.",
						Type:        discordgo.ApplicationCommandOptionString,
						Required:    true,
						Choices:     channelSettingChoices,
					},
					{
						Name:        "channel",
						Description: "Channel to set (leave empty to clear).",
						Type:        discordgo.ApplicationCommandOptionChannel,
						ChannelTypes: []discordgo.ChannelType{
							discordgo.ChannelTypeGuildText,
							discordgo.ChannelTypeGuildNews,
							discordgo.ChannelTypeGuildVoice,
							discordgo.ChannelTypeGuildCategory,
						},
					},
				},
			},
			{
				Name:        "setrole",
				Description: "Set a role-based setting.",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "key",
						Description: "Which setting to update.",
						Type:        discordgo.ApplicationCommandOptionString,
						Required:    true,
						Choices:     roleSettingChoices,
					},
					{
						Name:        "role",
						Description: "Role to set (required).",
						Type:        discordgo.ApplicationCommandOptionRole,
						Required:    true,
					},
				},
			},
			{
				Name:        "addrole",
				Description: "Set a role-based setting (alias of setrole).",
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Options: []*discordgo.ApplicationCommandOption{
					{
						Name:        "key",
						Description: "Setting key to update.",
						Type:        discordgo.ApplicationCommandOptionString,
						Required:    true,
						Choices:     roleSettingChoices,
					},
					{
						Name:        "role",
						Description: "Role to set (required).",
						Type:        discordgo.ApplicationCommandOptionRole,
						Required:    true,
					},
				},
			},
		},
		DefaultMemberPermissions: &[]int64{
			int64(discordgo.PermissionAdministrator),
		}[0],
	}
}

func (s *Settings) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	data := i.ApplicationCommandData()
	if len(data.Options) == 0 {
		return
	}
	switch data.Options[0].Name {
	case "ruleset":
		// Defer so we don’t time out
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64}, // ephemeral
		})

		opt := data.Options[0].Options[0] // "file"
		attID := opt.Value.(string)
		att := data.Resolved.Attachments[attID]
		if att == nil {
			shared.EditError(sess, i, "Could not resolve attachment.")
			return
		}

		// Validate extension and size (Discord provides .Size)
		ext := strings.ToLower(filepath.Ext(att.Filename))
		if ext != ".txt" {
			shared.EditError(sess, i, "Please upload a .txt file.")
			return
		}
		if att.Size > 64*1024 {
			shared.EditError(sess, i, "File too large. Max 64 KiB.")
			return
		}

		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		if err := storage.SaveRulesetFromURL(ctx, att.URL); err != nil {
			log.Printf("settings ruleset: save failed: %v", err)
			shared.EditError(sess, i, fmt.Sprintf("Failed to save ruleset: %v", err))
			return
		}

		emb := &discordgo.MessageEmbed{
			Title:       "Ruleset updated",
			Description: fmt.Sprintf("Stored **%s** (%d bytes). Use `/rules` to view it.", att.Filename, att.Size),
		}
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
			Embeds: &[]*discordgo.MessageEmbed{emb},
		})
	case "claimelo":
		// Defer ephemeral ack
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64},
		})

		enabled := false
		if len(data.Options[0].Options) > 0 {
			enabled = data.Options[0].Options[0].BoolValue()
		}

		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()

		if err := storage.SetClaimElo(ctx, enabled); err != nil {
			msg := fmt.Sprintf("Failed to update claim elo: %v", err)
			_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
			return
		}

		ok := "disabled"
		if enabled {
			ok = "enabled"
		}
		msg := "Claim elo has been **" + ok + "**."
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
	case "gamestyle":
		// Defer (ephemeral) to avoid timeouts
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64},
		})

		style := "2v2"
		if len(data.Options[0].Options) > 0 {
			style = data.Options[0].Options[0].StringValue() // guaranteed by choices
		}

		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := storage.SetGameStyle(ctx, style); err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to update game style: %v", err))
			return
		}

		if s.queueSvc != nil {
			if err := s.queueSvc.ReloadConfigs(ctx); err != nil {
				log.Printf("settings: failed to reload queue configs after style change: %v", err)
			}
		}

		msg := fmt.Sprintf("Game style set to **%s**.", style)
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
			Content: &msg,
		})
	case "hypixelapikey":
		// Defer (ephemeral)
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64},
		})

		key := ""
		if len(data.Options[0].Options) > 0 {
			key = strings.TrimSpace(data.Options[0].Options[0].StringValue())
		}
		// Optional light validation (UUID-ish)
		if len(key) < 32 {
			shared.EditError(sess, i, "That key looks invalid. Please paste the full UUID.")
			return
		}

		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := storage.SetHypixelAPIKey(ctx, key); err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to update Hypixel API key: %v", err))
			return
		}

		msg := "Hypixel API key updated."
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
			Content: &msg,
		})
	case "party":
		// Defer to avoid timeout
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64},
		})

		toggle := ""
		if len(data.Options[0].Options) > 0 {
			toggle = data.Options[0].Options[0].StringValue()
		}

		var enabled bool
		switch strings.ToLower(toggle) {
		case "on":
			enabled = true
		case "off":
			enabled = false
		default:
			shared.EditError(sess, i, "Invalid option. Use `on` or `off`.")
			return
		}

		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := storage.SetPartyEnabled(ctx, enabled); err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to update party setting: %v", err))
			return
		}

		msg := fmt.Sprintf("Party system has been turned **%s**.", toggle)
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
			Content: &msg,
		})
	case "partysize":
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64},
		})

		var size int64 = 2
		if len(data.Options[0].Options) > 0 {
			size = data.Options[0].Options[0].IntValue()
		}
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := storage.SetPartySize(ctx, size); err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to update party size: %v", err))
			return
		}
		msg := fmt.Sprintf("Party size set to **%d**.", size)
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})

	case "picking":
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64},
		})
		pick := "1"

		if len(data.Options[0].Options) > 0 {
			pick = strings.ToLower(data.Options[0].Options[0].StringValue())
		}
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := storage.SetPickingType(ctx, pick); err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to update picking type: %v", err))
			return
		}
		msg := "Picking type set to **" + pick + "**."
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
	case "logchannel":
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64},
		})

		var channelID string
		if len(data.Options[0].Options) > 0 {
			if ch := data.Options[0].Options[0].ChannelValue(sess); ch != nil {
				channelID = ch.ID
			}
		}

		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := storage.SetLogChannelID(ctx, channelID); err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to update log channel: %v", err))
			return
		}

		msg := "Command log channel cleared."
		if channelID != "" {
			msg = fmt.Sprintf("Command log channel set to <#%s>.", channelID)
		}
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
	case "punishchannel":
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64},
		})

		var channelID string
		if len(data.Options[0].Options) > 0 {
			if ch := data.Options[0].Options[0].ChannelValue(sess); ch != nil {
				channelID = ch.ID
			}
		}

		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := storage.SetPunishmentsChannelID(ctx, channelID); err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to update punishment channel: %v", err))
			return
		}

		msg := "Punishment channel cleared."
		if channelID != "" {
			msg = fmt.Sprintf("Punishment channel set to <#%s>.", channelID)
		}
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
	case "supportchannel":
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Flags: 64},
		})

		var channelID string
		if len(data.Options[0].Options) > 0 {
			if ch := data.Options[0].Options[0].ChannelValue(sess); ch != nil {
				channelID = ch.ID
			}
		}

		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := storage.SetSupportChannelID(ctx, channelID); err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to update support channel: %v", err))
			return
		}

		msg := "Support channel cleared."
		if channelID != "" {
			msg = fmt.Sprintf("Support channel set to <#%s>.", channelID)
		}
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
	case "setchannel":
		s.handleSetChannel(sess, i)
	case "setrole":
		s.handleSetRole(sess, i)
	case "addrole":
		s.handleSetRole(sess, i)
	}
}

func (s *Settings) handleSetChannel(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	sub := i.ApplicationCommandData().Options[0]
	var key string
	var channelID string
	if len(sub.Options) > 0 {
		key = sub.Options[0].StringValue()
		if len(sub.Options) > 1 {
			if ch := sub.Options[1].ChannelValue(sess); ch != nil {
				channelID = ch.ID
			}
		}
	}
	col, ok := channelColumns[key]
	if !ok {
		shared.EditError(sess, i, "Invalid channel key.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	var valPtr *string
	if strings.TrimSpace(channelID) != "" {
		val := strings.TrimSpace(channelID)
		valPtr = &val
	}
	if err := storage.SetSettingsColumn(ctx, col, valPtr); err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to update %s: %v", key, err))
		return
	}
	if s.queueSvc != nil {
		switch key {
		case "queueThreadChannelId":
			s.queueSvc.UpdateThreadChannel(channelID)
		case "queueLogChannelId":
			s.queueSvc.UpdateLogChannel(channelID)
		}
	}
	msg := fmt.Sprintf("%s cleared.", key)
	if valPtr != nil {
		msg = fmt.Sprintf("%s set to <#%s>.", key, channelID)
	}
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}

func (s *Settings) handleSetRole(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	sub := i.ApplicationCommandData().Options[0]
	var key string
	var roleID string
	if len(sub.Options) > 0 {
		key = sub.Options[0].StringValue()
		if len(sub.Options) > 1 {
			if role := sub.Options[1].RoleValue(sess, i.GuildID); role != nil {
				roleID = role.ID
			}
		}
	}
	col, ok := roleColumns[key]
	if !ok || strings.TrimSpace(roleID) == "" {
		shared.EditError(sess, i, "Invalid role key or role.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	val := strings.TrimSpace(roleID)
	if err := storage.SetSettingsColumn(ctx, col, &val); err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to update %s: %v", key, err))
		return
	}
	msg := fmt.Sprintf("%s set to <@&%s>.", key, roleID)
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})

}
