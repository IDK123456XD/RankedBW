package misc

import "github.com/bwmarrin/discordgo"

type Ping struct{}

func NewPing() *Ping         { return &Ping{} }
func (p *Ping) Name() string { return "ping" }

func (p *Ping) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        p.Name(),
		Description: "Check if the bot is alive.",
	}
}

func (p *Ping) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Content: "Pong!"},
	})
}
