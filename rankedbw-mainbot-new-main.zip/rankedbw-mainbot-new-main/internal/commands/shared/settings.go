package shared

import (
	"context"
	"os"
	"strings"
	"time"

	"rbw-bot/internal/storage"
)

// SettingOrEnv returns a setting value from the Settings table, falling back to the environment.
func SettingOrEnv(key string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if val, err := storage.GetSettingValue(ctx, key); err == nil && strings.TrimSpace(val) != "" {
		return strings.TrimSpace(val)
	}
	return strings.TrimSpace(os.Getenv(key))
}
