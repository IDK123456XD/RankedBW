package shared

import (
	"context"
	"database/sql"
	"fmt"
	"os"
	"strings"
	"sync"
	"time"

	"rbw-bot/internal/discordutil"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

const DefaultEmbedColor = 0x004CFF

// BotAvatarURL safely returns the bot's avatar URL when available.
func BotAvatarURL(s *discordgo.Session) string {
	if s != nil && s.State != nil && s.State.User != nil {
		return s.State.User.AvatarURL("")
	}
	return ""
}

// RespondEphemeral sends an ephemeral interaction response with the provided message.
func RespondEphemeral(s *discordgo.Session, i *discordgo.InteractionCreate, msg string) {
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Flags: 64,
			Embeds: []*discordgo.MessageEmbed{
				{Description: msg, Color: DefaultEmbedColor},
			},
		},
	})
}

// Respond sends a normal (non-ephemeral) interaction response with the provided message.
func Respond(s *discordgo.Session, i *discordgo.InteractionCreate, msg string) {
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				{Description: msg, Color: DefaultEmbedColor},
			},
		},
	})
}

// EditError edits an interaction response with an error string.
func EditError(s *discordgo.Session, i *discordgo.InteractionCreate, msg string) {
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &msg,
	})
}

var (
	waitingRoomOnce sync.Once
	waitingRoomID   string
)

func WaitingRoomID() string {
	return getWaitingRoomID()
}

func getWaitingRoomID() string {
	waitingRoomOnce.Do(func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		if val, err := storage.GetSettingValue(ctx, "WAITING_ROOM_VC_ID"); err == nil && strings.TrimSpace(val) != "" {
			waitingRoomID = strings.TrimSpace(val)
			return
		}
		waitingRoomID = strings.TrimSpace(os.Getenv("WAITING_ROOM_VC_ID"))
	})
	return waitingRoomID
}

// CleanupGameResources deletes the team voice channels and queue thread associated with a game.
func CleanupGameResources(s *discordgo.Session, guildID string, game *storage.GameRecord) (actions []string, warnings []string) {
	if s == nil || game == nil {
		return
	}
	waitingRoom := getWaitingRoomID()

	deleteChannel := func(field sql.NullString, label string) {
		if !field.Valid {
			return
		}
		id := strings.TrimSpace(field.String)
		if id == "" {
			return
		}
		if waitingRoom != "" && guildID != "" {
			if errs := moveMembersToWaitingRoom(s, guildID, id, waitingRoom); len(errs) > 0 {
				warnings = append(warnings, errs...)
			}
		}
		queued := discordutil.EnqueueDelete(discordutil.DeleteTask{
			ChannelID:     id,
			GuildID:       guildID,
			Hide:          true,
			MoveMembersTo: waitingRoom,
			Reason:        label + " cleanup",
		})
		if queued {
			actions = append(actions, fmt.Sprintf("%s channel queued for deletion (<#%s>)", label, id))
			return
		}
		if _, err := s.ChannelDelete(id); err != nil {
			if isDiscordNotFound(err) {
				actions = append(actions, fmt.Sprintf("%s channel already removed (<#%s>)", label, id))
			} else {
				warnings = append(warnings, fmt.Sprintf("%s: %v", label, err))
			}
		} else {
			actions = append(actions, fmt.Sprintf("%s channel deleted (<#%s>)", label, id))
		}
	}

	deleteChannel(game.Team1Voice, "Team 1")
	deleteChannel(game.Team2Voice, "Team 2")
	deleteChannel(game.ThreadID, "Thread")
	return
}

// CleanupGameVoiceChannels hides + deletes voice channels for a game but keeps the thread.
func CleanupGameVoiceChannels(s *discordgo.Session, guildID string, game *storage.GameRecord, players []storage.GamePlayerRecord) (actions []string, warnings []string) {
	if s == nil || game == nil {
		return
	}
	waitingRoom := getWaitingRoomID()

	var voiceStates []*discordgo.VoiceState
	if guild, err := s.State.Guild(guildID); err == nil && guild != nil {
		voiceStates = guild.VoiceStates
	} else if guild, err := s.Guild(guildID); err == nil && guild != nil {
		voiceStates = guild.VoiceStates
	}

	deleteChannel := func(field sql.NullString, label string) {
		if !field.Valid {
			return
		}
		id := strings.TrimSpace(field.String)
		if id == "" {
			return
		}

		var channelMembers []string
		for _, vs := range voiceStates {
			if vs == nil || vs.ChannelID != id {
				continue
			}
			channelMembers = append(channelMembers, vs.UserID)
		}

		// Move everyone currently in this channel to the waiting room (participants or not).
		if waitingRoom != "" && guildID != "" {
			for _, uid := range channelMembers {
				target := waitingRoom
				if err := s.GuildMemberMove(guildID, uid, &target); err != nil {
					warnings = append(warnings, fmt.Sprintf("move %s: %v", uid, err))
				}
			}
		}

		queued := discordutil.EnqueueDelete(discordutil.DeleteTask{
			ChannelID:     id,
			GuildID:       guildID,
			Hide:          true,
			MoveMembersTo: waitingRoom,
			Reason:        label + " cleanup",
		})
		if queued {
			actions = append(actions, fmt.Sprintf("%s channel queued for deletion (<#%s>)", label, id))
			return
		}
		if _, err := s.ChannelDelete(id); err != nil {
			if isDiscordNotFound(err) {
				actions = append(actions, fmt.Sprintf("%s channel already removed (<#%s>)", label, id))
			} else {
				warnings = append(warnings, fmt.Sprintf("%s: %v", label, err))
			}
		} else {
			actions = append(actions, fmt.Sprintf("%s channel deleted (<#%s>)", label, id))
		}
	}

	deleteChannel(game.Team1Voice, "Team 1")
	deleteChannel(game.Team2Voice, "Team 2")
	return
}

func moveMembersToWaitingRoom(s *discordgo.Session, guildID, sourceChannelID, waitingRoomID string) []string {
	if waitingRoomID == "" || guildID == "" || sourceChannelID == "" || sourceChannelID == waitingRoomID {
		return nil
	}
	var warnings []string
	guild, err := s.State.Guild(guildID)
	if err != nil || guild == nil {
		if guild, err = s.Guild(guildID); err != nil {
			warnings = append(warnings, fmt.Sprintf("failed to fetch guild state: %v", err))
			return warnings
		}
	}
	for _, vs := range guild.VoiceStates {
		if vs.ChannelID == sourceChannelID {
			target := waitingRoomID
			if moveErr := s.GuildMemberMove(guildID, vs.UserID, &target); moveErr != nil {
				warnings = append(warnings, fmt.Sprintf("move %s: %v", vs.UserID, moveErr))
			}
		}
	}
	return warnings
}

func isDiscordNotFound(err error) bool {
	if rest, ok := err.(*discordgo.RESTError); ok {
		if rest.Response != nil && rest.Response.StatusCode == 404 {
			return true
		}
		if rest.Message != nil && rest.Message.Code == discordgo.ErrCodeUnknownChannel {
			return true
		}
	}
	return false
}
