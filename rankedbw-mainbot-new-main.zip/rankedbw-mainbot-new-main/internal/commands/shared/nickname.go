package shared

import (
	"context"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/commands/registration"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

// BuildDisplayName returns the nickname that should be applied after an ELO update.
// It respects the player's stored nickname and prefix preference.
func BuildDisplayName(player *storage.PlayerRecord, stats *storage.PlayerSeasonStats) string {
	if player == nil {
		return ""
	}

	base := strings.TrimSpace(player.MinecraftName)
	if base == "" {
		base = strings.TrimSpace(player.UserID)
	}
	if player.Nickname.Valid && strings.TrimSpace(player.Nickname.String) != "" {
		base += " | " + strings.TrimSpace(player.Nickname.String)
	}

	if player.EloPrefix && stats != nil {
		return registration.BuildNickname(stats.Elo, base)
	}
	return base
}

const maxDiscordNicknameLength = 32

// SanitizeNickname ensures the nickname fits Discord's length limit.
func SanitizeNickname(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return ""
	}
	runes := []rune(value)
	if len(runes) <= maxDiscordNicknameLength {
		return value
	}
	return string(runes[:maxDiscordNicknameLength])
}

// ApplyNickname updates the member's Discord nickname to reflect their current ELO state.
func ApplyNickname(s *discordgo.Session, guildID string, player *storage.PlayerRecord, stats *storage.PlayerSeasonStats, context string) {
	if s == nil || player == nil || stats == nil || guildID == "" {
		return
	}
	display := SanitizeNickname(BuildDisplayName(player, stats))
	if strings.TrimSpace(display) == "" {
		return
	}
	if err := s.GuildMemberNickname(guildID, player.UserID, display); err != nil {
		log.Printf("%s: failed to update nickname for %s: %v", context, player.UserID, err)
	}
}

// ApplyRankRole assigns the appropriate rank role for the given elo and removes other rank roles.
// Returns a warning string on failure (for user-facing messaging) or "" on success.
func ApplyRankRole(s *discordgo.Session, guildID, userID string, elo int, source string) string {
	if s == nil || guildID == "" || userID == "" {
		return ""
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	ranks, err := storage.ListRanks(ctx)
	if err != nil {
		log.Printf("%s: failed to load ranks: %v", source, err)
		return "Failed to load rank configuration."
	}
	if len(ranks) == 0 {
		return "Rank roles are not configured."
	}

	var target *storage.RankRecord
	for idx := range ranks {
		r := &ranks[idx]
		if elo >= r.Min && elo <= r.Max {
			target = r
			break
		}
	}
	if target == nil {
		return ""
	}

	member, err := s.GuildMember(guildID, userID)
	if err != nil || member == nil {
		log.Printf("%s: failed to load member %s: %v", source, userID, err)
		return "Could not load member to adjust rank role."
	}

	roleSet := make(map[string]struct{}, len(member.Roles))
	for _, rid := range member.Roles {
		roleSet[rid] = struct{}{}
	}

	// Remove other rank roles.
	for _, r := range ranks {
		if r.RoleID == "" || r.RoleID == target.RoleID {
			continue
		}
		if _, ok := roleSet[r.RoleID]; ok {
			if err := s.GuildMemberRoleRemove(guildID, userID, r.RoleID); err != nil {
				log.Printf("%s: failed to remove role %s from %s: %v", source, r.RoleID, userID, err)
			}
		}
	}

	// Add target role if missing.
	if _, ok := roleSet[target.RoleID]; !ok && strings.TrimSpace(target.RoleID) != "" {
		if err := s.GuildMemberRoleAdd(guildID, userID, target.RoleID); err != nil {
			log.Printf("%s: failed to add role %s to %s: %v", source, target.RoleID, userID, err)
			return "Failed to assign the rank role; check bot permissions."
		}
	}

	return ""
}

// ApplyRegisterRole grants the generic "registered" role if configured.
// Returns a warning string for user-facing messaging, or "" on success/no-op.
func ApplyRegisterRole(s *discordgo.Session, guildID, userID, source string) string {
	if s == nil || guildID == "" || userID == "" {
		return ""
	}

	roleID := strings.TrimSpace(SettingOrEnv("REGISTER_RANK"))
	if roleID == "" {
		return ""
	}

	member, err := s.GuildMember(guildID, userID)
	if err != nil || member == nil {
		log.Printf("%s: failed to load member %s for register role: %v", source, userID, err)
		return "Could not load member to assign register role."
	}
	for _, r := range member.Roles {
		if r == roleID {
			return ""
		}
	}
	if err := s.GuildMemberRoleAdd(guildID, userID, roleID); err != nil {
		log.Printf("%s: failed to add register role %s to %s: %v", source, roleID, userID, err)
		return "Failed to assign the register role; check bot permissions."
	}
	return ""
}
