package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/rolecommands"

	"github.com/bwmarrin/discordgo"
)

var pugsConfig = rolecommands.Config{
	Name:               "PUGS",
	RoleEnv:            "PUGS_ROLE_ID",
	ManagerRoleEnv:     "PUGS_MANAGER_ROLE_ID",
	OwnerRoleEnv:       "PUGS_OWNER_ROLE_ID",
	AnnounceChannelEnv: "PUGS_ANNOUNCEMENTS_CHANNEL_ID",
	LogChannelEnv:      "PUGS_LOG_CHANNEL_ID",
}

type Pugs struct{}

func NewPugs() *Pugs         { return &Pugs{} }
func (p *Pugs) Name() string { return "pugs" }

func (p *Pugs) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        p.Name(),
		Description: "Manage PUGS players.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Add a player to PUGS.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "member",
						Description: "Discord user to add.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "reason",
						Description: "Reason for adding.",
					},
					{
						Name:        "announce",
						Description: "Whether to post an announcement.",
						Type:        discordgo.ApplicationCommandOptionBoolean,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List current PUGS players.",
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove a player from PUGS.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "member",
						Description: "Discord user to remove.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "reason",
						Description: "Reason for removal.",
					},
					{
						Type:        discordgo.ApplicationCommandOptionBoolean,
						Name:        "announce",
						Description: "Whether to announce the removal.",
					},
				},
			},
		},
		// Runtime permission checks ensure only managers/owners/admins can act.
		DefaultMemberPermissions: nil,
	}
}

func (p *Pugs) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	switch i.ApplicationCommandData().Options[0].Name {
	case "add":
		p.handleAdd(s, i)
	case "list":
		p.handleList(s, i)
	case "remove":
		p.handleRemove(s, i)
	}
}

func (p *Pugs) handleAdd(s *discordgo.Session, i *discordgo.InteractionCreate) {
	opts := optionMap(i.ApplicationCommandData().Options[0].Options)
	target := opts["member"].UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	if !pugsConfig.IsManagerOrOwner(i.Member) && (i.Member == nil || i.Member.Permissions&discordgo.PermissionAdministrator == 0) {
		shared.RespondEphemeral(s, i, "Only PUGS managers/owners or admins can manage PUGS membership.")
		return
	}
	reason := ""
	if opt, ok := opts["reason"]; ok {
		reason = strings.TrimSpace(opt.StringValue())
	}
	announce := false
	if opt, ok := opts["announce"]; ok {
		announce = opt.BoolValue()
	}

	roleID, err := pugsConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "That user is not in this guild.")
		return
	}
	for _, id := range member.Roles {
		if id == roleID {
			shared.EditError(s, i, "That user is already in PUGS.")
			return
		}
	}
	if err := s.GuildMemberRoleAdd(i.GuildID, target.ID, roleID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to assign role: %v", err))
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	mcName := rolecommands.PlayerMinecraftName(ctx, target.ID)

	if announce {
		actorID := ""
		if i.Member != nil && i.Member.User != nil {
			actorID = i.Member.User.ID
		} else if i.User != nil {
			actorID = i.User.ID
		}
		pugsConfig.AnnounceAction(s, true, actorID, target.ID, mcName, reason)
	}
	actorID := ""
	if i.Member != nil && i.Member.User != nil {
		actorID = i.Member.User.ID
	} else if i.User != nil {
		actorID = i.User.ID
	}
	pugsConfig.LogAction(s, true, actorID, target.ID, reason)
	updatedRoles := append(append([]string{}, member.Roles...), roleID)
	updateRoleListCacheFromMember(i.GuildID, roleListKindPugs, member, updatedRoles, mcName)

	message := fmt.Sprintf("%s has been added to PUGS.", target.Mention())
	if reason != "" {
		message += " Reason: " + reason
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (p *Pugs) handleRemove(s *discordgo.Session, i *discordgo.InteractionCreate) {
	opts := optionMap(i.ApplicationCommandData().Options[0].Options)
	target := opts["member"].UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	if !pugsConfig.IsManagerOrOwner(i.Member) && (i.Member == nil || i.Member.Permissions&discordgo.PermissionAdministrator == 0) {
		shared.RespondEphemeral(s, i, "Only PUGS managers/owners or admins can manage PUGS membership.")
		return
	}
	reason := ""
	if opt, ok := opts["reason"]; ok {
		reason = strings.TrimSpace(opt.StringValue())
	}

	roleID, err := pugsConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "That user is not in this guild.")
		return
	}
	hasRole := false
	for _, id := range member.Roles {
		if id == roleID {
			hasRole = true
			break
		}
	}
	if !hasRole {
		shared.EditError(s, i, "That user is not in PUGS.")
		return
	}

	if err := s.GuildMemberRoleRemove(i.GuildID, target.ID, roleID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to remove role: %v", err))
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	mcName := rolecommands.PlayerMinecraftName(ctx, target.ID)

	actorID := ""
	if i.Member != nil && i.Member.User != nil {
		actorID = i.Member.User.ID
	} else if i.User != nil {
		actorID = i.User.ID
	}
	announceRemove := false
	if opt, ok := opts["announce"]; ok {
		announceRemove = opt.BoolValue()
	}
	if announceRemove {
		pugsConfig.AnnounceAction(s, false, actorID, target.ID, mcName, reason)
	}
	pugsConfig.LogAction(s, false, actorID, target.ID, reason)
	var updatedRoles []string
	for _, r := range member.Roles {
		if strings.TrimSpace(r) != strings.TrimSpace(roleID) {
			updatedRoles = append(updatedRoles, r)
		}
	}
	updateRoleListCacheFromMember(i.GuildID, roleListKindPugs, member, updatedRoles, mcName)

	message := fmt.Sprintf("%s has been removed from PUGS.", target.Mention())
	if reason != "" {
		message += " Reason: " + reason
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (p *Pugs) handleList(s *discordgo.Session, i *discordgo.InteractionCreate) {
	sendRoleList(s, i, roleListKindPugs)
}
