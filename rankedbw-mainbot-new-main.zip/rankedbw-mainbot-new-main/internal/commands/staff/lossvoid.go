package staff

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/ranks"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type LossVoid struct{}

func NewLossVoid() *LossVoid     { return &LossVoid{} }
func (l *LossVoid) Name() string { return "lossvoid" }

func (l *LossVoid) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        l.Name(),
		Description: "Void a loss and restore elo for the losing team.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "gameid",
				Description: "Game ID (e.g. ABC123).",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for voiding the loss.",
				Required:    true,
			},
		},
	}
}

func (l *LossVoid) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to lossvoid games.")
		return
	}

	var gameOpt, reasonOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "gameid":
			gameOpt = opt
		case "reason":
			reasonOpt = opt
		}
	}

	if gameOpt == nil || reasonOpt == nil {
		shared.RespondEphemeral(s, i, "Both `gameid` and `reason` must be provided.")
		return
	}

	gameID := strings.TrimSpace(gameOpt.StringValue())
	reason := strings.TrimSpace(reasonOpt.StringValue())
	if gameID == "" || reason == "" {
		shared.RespondEphemeral(s, i, "Game ID and reason must not be empty.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	logChannelID, err := storage.GetLogChannelID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load log channel: %v", err))
		return
	}

	game, players, _, err := storage.GetGameWithPlayersActiveSeason(ctx, gameID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load game: %v", err))
		return
	}
	if game == nil {
		shared.EditError(s, i, fmt.Sprintf("Game `%s` was not found.", gameID))
		return
	}
	status := strings.ToUpper(strings.TrimSpace(game.Status))
	if status != "FINISHED" && status != "SCORED" {
		shared.EditError(s, i, fmt.Sprintf("Game `%s` has not been scored yet.", gameID))
		return
	}
	if game.LossVoided {
		shared.EditError(s, i, fmt.Sprintf("Game `%s` has already been lossvoided.", gameID))
		return
	}

	var seasonID string
	if game.SeasonID.Valid && strings.TrimSpace(game.SeasonID.String) != "" {
		seasonID = game.SeasonID.String
	} else {
		seasonID, err = storage.ActiveSeasonID(ctx)
		if err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to determine active season: %v", err))
			return
		}
	}

	var losers []storage.GamePlayerRecord
	for _, gp := range players {
		if !gp.Win {
			losers = append(losers, gp)
		}
	}
	if len(losers) == 0 {
		shared.EditError(s, i, fmt.Sprintf("Game `%s` has no losing players recorded.", gameID))
		return
	}

	successful := 0
	for _, player := range losers {
		playerRecord, err := storage.GetPlayerByID(ctx, player.PlayerID)
		if err != nil {
			log.Printf("lossvoid: player lookup failed for %s: %v", player.PlayerID, err)
			continue
		}
		if playerRecord == nil {
			playerRecord, err = storage.GetPlayerByUserID(ctx, player.DiscordID)
			if err != nil {
				log.Printf("lossvoid: user lookup failed for %s: %v", player.DiscordID, err)
				continue
			}
		}
		if playerRecord == nil {
			log.Printf("lossvoid: no player record found for %s", player.PlayerID)
			continue
		}

		stats, err := storage.GetPlayerSeasonStats(ctx, playerRecord.ID, seasonID)
		if err != nil {
			log.Printf("lossvoid: stats lookup failed for %s: %v", playerRecord.ID, err)
			continue
		}
		if stats == nil {
			continue
		}
		if stats.LastReset.Valid && game.CreatedAt.Before(stats.LastReset.Time) {
			continue
		}
		if stats.Losses <= 0 || stats.GamesPlayed <= 0 {
			continue
		}
		lossAmt, ok := ranks.LossAmountForElo(player.PreElo)
		if !ok {
			continue
		}

		newElo := stats.Elo + lossAmt
		reasonText := fmt.Sprintf("Loss Voided %s - %s", gameID, reason)
		if _, _, err := storage.UpdatePlayerElo(ctx, stats.ID, playerRecord.ID, seasonID, newElo, "ManualAdjustment", reasonText); err != nil {
			log.Printf("lossvoid: update elo failed for %s: %v", playerRecord.ID, err)
			continue
		}

		if err := storage.DecrementLossAndGames(ctx, stats.ID); err != nil {
			log.Printf("lossvoid: failed to adjust stats for %s: %v", playerRecord.ID, err)
			continue
		}

		stats.Elo = newElo
		shared.ApplyNickname(s, i.GuildID, playerRecord, stats, "lossvoid")
		successful++
	}

	if successful == 0 {
		shared.EditError(s, i, "No losing players could be adjusted (stats may be missing or already reset).")
		return
	}

	updatedReason := fmt.Sprintf("Loss Voided: %s", reason)
	if game.Reason.Valid && strings.TrimSpace(game.Reason.String) != "" {
		updatedReason = fmt.Sprintf("%s | %s", game.Reason.String, updatedReason)
	}
	if err := storage.MarkGameLossVoided(ctx, game.ID, updatedReason); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update game record: %v", err))
		return
	}

	msg := fmt.Sprintf("Game `%s` lossvoided. Restored elo for %d players.", gameID, successful)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})

	l.logResult(s, logChannelID, i.Member.User.ID, gameID, reason, successful)
}

func (l *LossVoid) logResult(s *discordgo.Session, channelID, moderatorID, gameID, reason string, count int) {
	if channelID == "" {
		return
	}
	embed := &discordgo.MessageEmbed{
		Title: "Loss Void Executed",
		Fields: []*discordgo.MessageEmbedField{
			{Name: "Game", Value: gameID, Inline: true},
			{Name: "Moderator", Value: fmt.Sprintf("<@%s>", moderatorID), Inline: true},
			{Name: "Players Adjusted", Value: fmt.Sprintf("%d", count), Inline: true},
			{Name: "Reason", Value: fmt.Sprintf("`%s`", reason), Inline: false},
		},
		Color:     0xffa500,
		Timestamp: time.Now().Format(time.RFC3339),
	}

	if _, err := s.ChannelMessageSendEmbed(channelID, embed); err != nil {
		log.Printf("lossvoid: failed to send log embed: %v", err)
	}
}
