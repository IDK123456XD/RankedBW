package staff

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/commands/registration"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type ForceRegister struct{}

func NewForceRegister() *ForceRegister       { return &ForceRegister{} }
func (f *ForceRegister) Name() string        { return "forceregister" }
func (f *ForceRegister) description() string { return "Force register a player to Ranked Bedwars." }

func (f *ForceRegister) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        f.Name(),
		Description: f.description(),
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "member",
				Description: "Discord user to register.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "ign",
				Description: "Minecraft username to link.",
				Required:    true,
			},
		},
	}
}

func (f *ForceRegister) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to force-register players.")
		return
	}

	var ign string
	var memberOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "ign":
			ign = strings.TrimSpace(opt.StringValue())
		case "member":
			memberOpt = opt
		}
	}

	if ign == "" || memberOpt == nil {
		shared.RespondEphemeral(s, i, "Both `ign` and `member` must be provided.")
		return
	}

	targetUser := memberOpt.UserValue(s)
	if targetUser == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the provided member.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	uuid, err := registration.MojangUUID(ctx, ign)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Could not resolve IGN: %v", err))
		return
	}

	if record, err := storage.GetPlayerByMinecraftName(ctx, ign); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to validate IGN: %v", err))
		return
	} else if record != nil && record.UserID != targetUser.ID {
		shared.EditError(s, i, fmt.Sprintf("That IGN is already registered to <@%s>.", record.UserID))
		return
	}

	if record, err := storage.GetPlayerByUUID(ctx, uuid); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to validate UUID: %v", err))
		return
	} else if record != nil && record.UserID != targetUser.ID {
		shared.EditError(s, i, fmt.Sprintf("This UUID is already linked to another Discord account (%s).", record.UserID))
		return
	}

	displayName := ign

	result, err := registration.UpsertPlayer(ctx, registration.Params{
		UserID:      targetUser.ID,
		IGN:         ign,
		DisplayName: displayName,
		UUID:        uuid,
	})
	if err != nil {
		if errors.Is(err, registration.ErrDuplicatePlayer) {
			shared.EditError(s, i, "This player is already registered to another Discord account.")
			return
		}
		shared.EditError(s, i, fmt.Sprintf("Failed to store profile: %v", err))
		return
	}

	if dump, err := storage.DumpPlayerJSON(ctx, targetUser.ID); err == nil && dump != "" {
		log.Printf("Force register stored player row: %s", dump)
	}

	var warnings []string
	nickname := registration.BuildNickname(result.Elo, result.MinecraftName)
	if err := s.GuildMemberNickname(i.GuildID, targetUser.ID, nickname); err != nil {
		log.Printf("failed to update nickname for %s: %v", targetUser.ID, err)
		warnings = append(warnings, "Failed to update their nickname (check bot permissions).")
	}
	if warn := shared.ApplyRankRole(s, i.GuildID, targetUser.ID, result.Elo, "forceregister command"); warn != "" {
		warnings = append(warnings, warn)
	}
	if warn := shared.ApplyRegisterRole(s, i.GuildID, targetUser.ID, "forceregister command"); warn != "" {
		warnings = append(warnings, warn)
	}

	targetMention := "<@" + targetUser.ID + ">"
	msg := fmt.Sprintf("Registered %s as **%s**.", targetMention, result.MinecraftName)
	if result.Refreshed {
		msg = fmt.Sprintf("Refreshed %s and set them as **%s**.", targetMention, result.MinecraftName)
	}
	if len(warnings) > 0 {
		msg += "\nWarning: " + strings.Join(warnings, "\nWarning: ")
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})

	log.Printf("%s force registered %s as %s", i.Member.User.ID, targetUser.ID, result.MinecraftName)
}
