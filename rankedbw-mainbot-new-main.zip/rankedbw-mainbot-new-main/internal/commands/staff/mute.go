package staff

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"rbw-bot/internal/assets"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Mute struct{}

func NewMute() *Mute         { return &Mute{} }
func (m *Mute) Name() string { return "mute" }

func (m *Mute) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        m.Name(),
		Description: "Mute a player.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "member",
				Description: "Discord user to mute.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "duration",
				Description: "Duration (e.g. `1d 12h`, `30m`).",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for the mute.",
				Required:    true,
			},
		},
	}
}

func (m *Mute) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to mute players.")
		return
	}

	var memberOpt, durationOpt, reasonOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "member":
			memberOpt = opt
		case "duration":
			durationOpt = opt
		case "reason":
			reasonOpt = opt
		}
	}

	if memberOpt == nil || durationOpt == nil || reasonOpt == nil {
		shared.RespondEphemeral(s, i, "Missing required options.")
		return
	}

	targetUser := memberOpt.UserValue(s)
	if targetUser == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the selected user.")
		return
	}

	durationStr := strings.TrimSpace(durationOpt.StringValue())
	reason := strings.TrimSpace(reasonOpt.StringValue())
	if durationStr == "" || reason == "" {
		shared.RespondEphemeral(s, i, "Duration and reason must be provided.")
		return
	}

	mutedRoleID := shared.SettingOrEnv("MUTED_ROLE_ID")
	if mutedRoleID == "" {
		shared.RespondEphemeral(s, i, "MUTED_ROLE_ID is not configured.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	logChannelID, err := storage.GetStaffPunishmentLogChannelID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load log settings: %v", err))
		return
	}

	punishmentsChannelID, err := storage.GetPunishmentsChannelID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load punishment settings: %v", err))
		return
	}

	supportChannelID, err := storage.GetSupportChannelID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load support settings: %v", err))
		return
	}

	member, err := s.GuildMember(i.GuildID, targetUser.ID)
	if err != nil {
		shared.EditError(s, i, "Could not fetch that member from the guild.")
		return
	}
	for _, roleID := range member.Roles {
		if roleID == mutedRoleID {
			shared.EditError(s, i, "That user is already muted.")
			return
		}
	}

	player, err := storage.GetPlayerByUserID(ctx, targetUser.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to look up player: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "That user is not registered, so a punishment record cannot be created for auto-unmute. Ask them to /register first.")
		return
	}

	duration, err := parseDuration(durationStr)
	if err != nil || duration <= 0 {
		shared.EditError(s, i, "Please provide a valid duration (e.g. `1d 2h`, `30m`).")
		return
	}

	if err := s.GuildMemberRoleAdd(i.GuildID, targetUser.ID, mutedRoleID); err != nil {
		log.Printf("mute: failed to assign muted role %s to %s: %v", mutedRoleID, targetUser.ID, err)
		logMuteDiagnostics(s, i.GuildID, mutedRoleID)
		shared.EditError(s, i, fmt.Sprintf("Failed to assign muted role: %v", err))
		return
	}

	expiresAt := time.Now().Add(duration)
	if _, err := storage.CreatePunishment(ctx, player.ID, i.Member.User.ID, reason, storage.PunishmentTypeMute, expiresAt); err != nil {
		_ = s.GuildMemberRoleRemove(i.GuildID, targetUser.ID, mutedRoleID)
		shared.EditError(s, i, fmt.Sprintf("Failed to record punishment: %v", err))
		return
	}

	m.notifyPunishmentsChannel(s, punishmentsChannelID, supportChannelID, targetUser.ID, reason, durationStr, expiresAt)
	m.logMute(s, logChannelID, targetUser.ID, i.Member.User.ID, reason, durationStr, expiresAt, i.ChannelID, supportChannelID)

	msg := fmt.Sprintf("`%s` has been muted for **%s**.", targetUser.Username, reason)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}

func removeMuteRole(s *discordgo.Session, guildID, userID, mutedRoleID string) {
	member, err := s.GuildMember(guildID, userID)
	if err != nil {
		return
	}
	for _, role := range member.Roles {
		if role == mutedRoleID {
			_ = s.GuildMemberRoleRemove(guildID, userID, mutedRoleID)
			break
		}
	}
}

func (m *Mute) notifyPunishmentsChannel(s *discordgo.Session, channelID, supportChannelID, userID, reason, duration string, expires time.Time) {
	if channelID == "" {
		return
	}

	supportMention := "support"
	if strings.TrimSpace(supportChannelID) != "" {
		supportMention = fmt.Sprintf("<#%s>", supportChannelID)
	}

	expiryUnix := expires.Unix()
	description := fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n**Duration:** %s (<t:%d:R>)\n\nIf you wish to appeal this punishment, please create an appeal ticket %s and staff will be swift to help.",
		userID, reason, duration, expiryUnix, supportMention)

	embed := &discordgo.MessageEmbed{
		Title:       "Server Muted",
		Description: description,
		Color:       0xFAE773,
		Timestamp: time.Now().Format(time.RFC3339),
	}

	var err error
	if thumb, files, cleanup := assets.ThumbnailAttachment("muted.png"); thumb != nil {
		embed.Thumbnail = thumb
		_, err = s.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
			Content: fmt.Sprintf("<@%s>", userID),
			Embeds:  []*discordgo.MessageEmbed{embed},
			Files:   files,
		})
		cleanup()
	} else {
		_, err = s.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
			Content: fmt.Sprintf("<@%s>", userID),
			Embeds:  []*discordgo.MessageEmbed{embed},
		})
	}
	if err != nil {
		log.Printf("mute: failed to send punishment embed: %v", err)
	}
}

func (m *Mute) logMute(s *discordgo.Session, channelID, targetID, moderatorID, reason, duration string, expires time.Time, originChannelID, supportChannelID string) {
	if channelID == "" {
		return
	}

	supportMention := "support"
	if strings.TrimSpace(supportChannelID) != "" {
		supportMention = fmt.Sprintf("<#%s>", supportChannelID)
	}

	embed := &discordgo.MessageEmbed{
		Title: "Player Muted",
		Fields: []*discordgo.MessageEmbedField{
			{Name: "User", Value: fmt.Sprintf("<@%s>", targetID), Inline: true},
			{Name: "Moderator", Value: fmt.Sprintf("<@%s>", moderatorID), Inline: true},
			{Name: "Duration", Value: duration, Inline: true},
			{
				Name:   "Expires",
				Value:  fmt.Sprintf("<t:%d> (<t:%d:R>)", expires.Unix(), expires.Unix()),
				Inline: true,
			},
			{Name: "Reason", Value: fmt.Sprintf("`%s`", reason), Inline: false},
			{Name: "Appeal", Value: fmt.Sprintf("Appeal in %s", supportMention), Inline: false},
			{Name: "Channel", Value: fmt.Sprintf("<#%s>", originChannelID), Inline: false},
		},
		Color:     0xFAE773,
		Timestamp: time.Now().Format(time.RFC3339),
	}

	if thumb, files, cleanup := assets.ThumbnailAttachment("muted.png"); thumb != nil {
		embed.Thumbnail = thumb
		_, err := s.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
			Embeds: []*discordgo.MessageEmbed{embed},
			Files:  files,
		})
		cleanup()
		if err != nil {
			log.Printf("mute: failed to send log embed: %v", err)
		}
		return
	}

	if _, err := s.ChannelMessageSendEmbed(channelID, embed); err != nil {
		log.Printf("mute: failed to send log embed: %v", err)
	}
}

func parseDuration(input string) (time.Duration, error) {
	parts := strings.Fields(strings.ToLower(input))
	if len(parts) == 0 {
		return 0, errors.New("invalid duration")
	}

	var total time.Duration
	for _, part := range parts {
		if len(part) < 2 {
			return 0, fmt.Errorf("invalid duration token %s", part)
		}
		valueStr := part[:len(part)-1]
		unit := part[len(part)-1]
		value, err := strconv.Atoi(valueStr)
		if err != nil || value <= 0 {
			return 0, fmt.Errorf("invalid duration token %s", part)
		}
		switch unit {
		case 'd':
			total += time.Duration(value) * 24 * time.Hour
		case 'h':
			total += time.Duration(value) * time.Hour
		case 'm':
			total += time.Duration(value) * time.Minute
		case 's':
			total += time.Duration(value) * time.Second
		default:
			return 0, fmt.Errorf("invalid duration unit %c", unit)
		}
	}

	if total <= 0 {
		return 0, errors.New("duration must be positive")
	}
	return total, nil
}

// logMuteDiagnostics logs useful context when role assignment fails (hierarchy/managed).
func logMuteDiagnostics(s *discordgo.Session, guildID, mutedRoleID string) {
	guild, err := s.State.Guild(guildID)
	if err != nil || guild == nil {
		if guild, err = s.Guild(guildID); err != nil {
			log.Printf("mute diagnostics: failed to load guild %s: %v", guildID, err)
			return
		}
	}

	var mutedRole *discordgo.Role
	for _, r := range guild.Roles {
		if r != nil && r.ID == mutedRoleID {
			mutedRole = r
			break
		}
	}
	if mutedRole == nil {
		log.Printf("mute diagnostics: muted role %s not found in guild %s", mutedRoleID, guildID)
		return
	}

	// Determine bot's highest role position
	botID := ""
	if s.State != nil && s.State.User != nil {
		botID = s.State.User.ID
	}
	botMember, _ := s.GuildMember(guildID, botID)
	highestPos := -1
	for _, r := range guild.Roles {
		if r == nil {
			continue
		}
		for _, mr := range botMember.Roles {
			if mr == r.ID && r.Position > highestPos {
				highestPos = r.Position
			}
		}
	}

	log.Printf("mute diagnostics: mutedRoleID=%s position=%d managed=%t botTopPosition=%d",
		mutedRoleID, mutedRole.Position, mutedRole.Managed, highestPos)
}
