package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

// StatResetConfig manages per-role stat reset limits.
type StatResetConfig struct{}

func NewStatResetConfig() *StatResetConfig { return &StatResetConfig{} }
func (c *StatResetConfig) Name() string    { return "statresetconfig" }

func (c *StatResetConfig) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:                     c.Name(),
		Description:              "Manage stat reset rules (staff only).",
		DefaultMemberPermissions: &perm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "set",
				Description: "Create or update a stat reset rule for a role.",
				Options: []*discordgo.ApplicationCommandOption{
					{Name: "role", Type: discordgo.ApplicationCommandOptionRole, Description: "Role allowed to reset stats", Required: true},
					{Name: "max_resets", Type: discordgo.ApplicationCommandOptionInteger, Description: "Number of resets per season (<=0 = unlimited)", Required: true},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "delete",
				Description: "Delete a stat reset rule for a role.",
				Options: []*discordgo.ApplicationCommandOption{
					{Name: "role", Type: discordgo.ApplicationCommandOptionRole, Description: "Role to remove", Required: true},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List all stat reset rules.",
			},
		},
	}
}

func (c *StatResetConfig) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if i == nil || len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	sub := i.ApplicationCommandData().Options[0]
	switch sub.Name {
	case "set":
		c.handleSet(sess, i, sub)
	case "delete":
		c.handleDelete(sess, i, sub)
	case "list":
		c.handleList(sess, i)
	}
}

func (c *StatResetConfig) handleSet(sess *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	var roleOpt, maxOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, o := range opt.Options {
		switch o.Name {
		case "role":
			roleOpt = o
		case "max_resets":
			maxOpt = o
		}
	}
	if roleOpt == nil || maxOpt == nil {
		shared.RespondEphemeral(sess, i, "Provide role and max_resets.")
		return
	}
	role := roleOpt.RoleValue(sess, i.GuildID)
	if role == nil || strings.TrimSpace(role.ID) == "" {
		shared.RespondEphemeral(sess, i, "Invalid role.")
		return
	}
	maxResets := int(maxOpt.IntValue())

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.UpsertStatResetRule(ctx, role.ID, maxResets); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to save rule: %v", err))
		return
	}
	limitText := "unlimited"
	if maxResets > 0 {
		limitText = fmt.Sprintf("%d", maxResets)
	}
	shared.RespondEphemeral(sess, i, fmt.Sprintf("Saved stat reset rule: <@&%s> -> %s reset(s) per season.", role.ID, limitText))
}

func (c *StatResetConfig) handleDelete(sess *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	role := opt.Options[0].RoleValue(sess, i.GuildID)
	if role == nil || strings.TrimSpace(role.ID) == "" {
		shared.RespondEphemeral(sess, i, "Invalid role.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.DeleteStatResetRule(ctx, role.ID); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to delete rule: %v", err))
		return
	}
	shared.RespondEphemeral(sess, i, fmt.Sprintf("Deleted stat reset rule for <@&%s> (if it existed).", role.ID))
}

func (c *StatResetConfig) handleList(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	rules, err := storage.ListStatResetRules(ctx)
	if err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to load rules: %v", err))
		return
	}
	if len(rules) == 0 {
		shared.RespondEphemeral(sess, i, "No stat reset rules configured.")
		return
	}
	var lines []string
	for _, r := range rules {
		limitText := "unlimited"
		if r.MaxResets > 0 {
			limitText = fmt.Sprintf("%d", r.MaxResets)
		}
		lines = append(lines, fmt.Sprintf("<@&%s>: %s reset(s) per season", strings.TrimSpace(r.RoleID), limitText))
	}
	embed := &discordgo.MessageEmbed{
		Title:       "Stat Reset Rules",
		Description: strings.Join(lines, "\n"),
		Color:       shared.DefaultEmbedColor,
	}
	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}
