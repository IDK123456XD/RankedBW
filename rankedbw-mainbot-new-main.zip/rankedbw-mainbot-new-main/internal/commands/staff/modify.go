package staff

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/commands/registration"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/leveling"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

const eloHistoryManual = "ManualAdjustment"

var statChoices = []*discordgo.ApplicationCommandOptionChoice{
	{Name: "ELO", Value: "elo"},
	{Name: "Wins", Value: "wins"},
	{Name: "Losses", Value: "losses"},
	{Name: "MVPs", Value: "mvps"},
	{Name: "Games Played", Value: "gamesPlayed"},
	{Name: "Level", Value: "level"},
	{Name: "XP", Value: "xp"},
	{Name: "Streak", Value: "streak"},
}

var statLabels = map[string]string{
	"elo":         "ELO",
	"wins":        "Wins",
	"losses":      "Losses",
	"mvps":        "MVPs",
	"gamesPlayed": "Games Played",
	"level":       "Level",
	"xp":          "XP",
	"streak":      "Streak",
}

type Modify struct{}

func NewModify() *Modify       { return &Modify{} }
func (m *Modify) Name() string { return "modify" }

func (m *Modify) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        m.Name(),
		Description: "Modify a specific stat for a player.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "member",
				Description: "Discord user to update.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "stat",
				Description: "Stat to modify.",
				Required:    true,
				Choices:     statChoices,
			},
			{
				Type:        discordgo.ApplicationCommandOptionInteger,
				Name:        "value",
				Description: "New value for the stat.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for the change.",
				Required:    true,
			},
		},
	}
}

func (m *Modify) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to modify player stats.")
		return
	}

	var memberOpt, statOpt, valueOpt, reasonOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "member":
			memberOpt = opt
		case "stat":
			statOpt = opt
		case "value":
			valueOpt = opt
		case "reason":
			reasonOpt = opt
		}
	}

	if memberOpt == nil || statOpt == nil || valueOpt == nil || reasonOpt == nil {
		shared.RespondEphemeral(s, i, "Missing required options.")
		return
	}

	targetUser := memberOpt.UserValue(s)
	if targetUser == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the provided user.")
		return
	}

	member, err := s.GuildMember(i.GuildID, targetUser.ID)
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("%s is not in the server.", targetUser.Username))
		return
	}

	stat := strings.TrimSpace(statOpt.StringValue())
	value := int(valueOpt.IntValue())
	reason := strings.TrimSpace(reasonOpt.StringValue())
	if reason == "" {
		shared.RespondEphemeral(s, i, "A reason is required.")
		return
	}

	label, ok := statLabels[stat]
	if !ok {
		shared.RespondEphemeral(s, i, "Invalid stat selection.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	logChannelID, err := storage.GetLogChannelID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load log settings: %v", err))
		return
	}

	player, err := storage.GetPlayerByUserID(ctx, targetUser.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to look up player: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, fmt.Sprintf("%s is not registered.", targetUser.Username))
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to locate active season: %v", err))
		return
	}

	if err := storage.EnsurePlayerSeasonStats(ctx, player.ID, seasonID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to ensure season stats: %v", err))
		return
	}

	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch stats: %v", err))
		return
	}
	if stats == nil {
		shared.EditError(s, i, "Player has no statistics for the active season.")
		return
	}

	var originalValue int
	newValue := value

	switch stat {
	case "elo":
		prev, updated, err := storage.UpdatePlayerElo(ctx, stats.ID, player.ID, seasonID, value, eloHistoryManual, reason)
		if err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to update ELO: %v", err))
			return
		}
		originalValue = prev
		newValue = updated
		nickname := registration.BuildNickname(updated, player.MinecraftName)
		if err := s.GuildMemberNickname(i.GuildID, member.User.ID, nickname); err != nil {
			log.Printf("modify: failed to update nickname for %s: %v", member.User.ID, err)
		}
	case "level":
		if value < 1 {
			shared.EditError(s, i, "Level must be at least 1.")
			return
		}
		progress := leveling.ProgressFromTotalXP(player.TotalXP)
		originalValue = progress.Level
		targetXP := leveling.TotalXPToReachLevel(value)
		if err := storage.UpdatePlayerTotalXP(ctx, player.ID, targetXP); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to update level: %v", err))
			return
		}
	case "xp":
		if value < 0 {
			shared.EditError(s, i, "XP cannot be negative.")
			return
		}
		progress := leveling.ProgressFromTotalXP(player.TotalXP)
		originalValue = progress.XPIntoLevel
		baseXP := leveling.TotalXPToReachLevel(progress.Level)
		if err := storage.UpdatePlayerTotalXP(ctx, player.ID, baseXP+value); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to update XP: %v", err))
			return
		}
	case "wins":
		originalValue = stats.Wins
		if err := storage.UpdatePlayerStatsColumn(ctx, stats.ID, "wins", value); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to update wins: %v", err))
			return
		}
	case "losses":
		originalValue = stats.Losses
		if err := storage.UpdatePlayerStatsColumn(ctx, stats.ID, "losses", value); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to update losses: %v", err))
			return
		}
	case "mvps":
		originalValue = stats.MVPs
		if err := storage.UpdatePlayerStatsColumn(ctx, stats.ID, "mvps", value); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to update MVPs: %v", err))
			return
		}
	case "gamesPlayed":
		originalValue = stats.GamesPlayed
		if err := storage.UpdatePlayerStatsColumn(ctx, stats.ID, "gamesPlayed", value); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to update games played: %v", err))
			return
		}
	case "streak":
		originalValue = stats.Streak
		if err := storage.UpdatePlayerStatsColumn(ctx, stats.ID, "streak", value); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to update streak: %v", err))
			return
		}
	default:
		shared.EditError(s, i, "Unsupported stat.")
		return
	}

	log.Printf("modify: %s set %s's %s from %d to %d (reason: %s)", i.Member.User.ID, player.UserID, stat, originalValue, newValue, reason)

	msg := fmt.Sprintf("Modified `%s`'s %s from `%d` to `%d`. Reason: `%s`", player.MinecraftName, label, originalValue, newValue, reason)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})

	m.logChangeEmbed(s, logChannelID, player.MinecraftName, label, originalValue, newValue, reason, i.Member.User, targetUser)

	if statsAfter, _ := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID); statsAfter != nil {
		_ = shared.ApplyRankRole(s, i.GuildID, player.UserID, statsAfter.Elo, "modify command")
	}
}

func (m *Modify) logChangeEmbed(s *discordgo.Session, channelID string, playerName, stat string, before, after int, reason string, moderator, target *discordgo.User) {
	if channelID == "" {
		return
	}

	description := fmt.Sprintf("**Player:** %s\n**Discord:** <@%s>\n**Stat:** %s\n**Old Value:** `%d`\n**New Value:** `%d`\n**Reason:** %s",
		playerName, target.ID, stat, before, after, reason)

	embed := &discordgo.MessageEmbed{
		Title:       "Player Stat Modified",
		Description: description,
		Color:       0xF5A623,
		Footer: &discordgo.MessageEmbedFooter{
			Text: fmt.Sprintf("Modified by %s#%s", moderator.Username, moderator.Discriminator),
		},
		Timestamp: time.Now().Format(time.RFC3339),
	}

	if _, err := s.ChannelMessageSendEmbed(channelID, embed); err != nil {
		log.Printf("modify: failed to send log embed: %v", err)
	}
}
