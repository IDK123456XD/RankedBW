package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/rolecommands"

	"github.com/bwmarrin/discordgo"
)

var pugsSpecConfig = rolecommands.Config{
	Name:               "PUGS Spec",
	RoleEnv:            "PUGS_SPEC_ROLE_ID",
	AnnounceChannelEnv: "PUGS_SPEC_ANNOUNCEMENTS_CHANNEL_ID",
	LogChannelEnv:      "PUGS_SPEC_LOG_CHANNEL_ID",
}

type PugsSpec struct{}

func NewPugsSpec() *PugsSpec     { return &PugsSpec{} }
func (p *PugsSpec) Name() string { return "pugsspec" }

func (p *PugsSpec) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:        p.Name(),
		Description: "Manage PUGS Spec players.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Add a player to PUGS Spec.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "member",
						Description: "Discord user to add.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "reason",
						Description: "Reason for adding.",
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove a player from PUGS Spec.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "member",
						Description: "Discord user to remove.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "reason",
						Description: "Reason for removal.",
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List current PUGS Spec members.",
			},
		},
		DefaultMemberPermissions: &perm,
	}
}

func (p *PugsSpec) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	switch i.ApplicationCommandData().Options[0].Name {
	case "add":
		p.handleAdd(s, i)
	case "remove":
		p.handleRemove(s, i)
	case "list":
		p.handleList(s, i)
	}
}

func (p *PugsSpec) handleAdd(s *discordgo.Session, i *discordgo.InteractionCreate) {
	opts := optionMap(i.ApplicationCommandData().Options[0].Options)
	target := opts["member"].UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the user.")
		return
	}
	reason := ""
	if opt, ok := opts["reason"]; ok {
		reason = strings.TrimSpace(opt.StringValue())
	}

	roleID, err := pugsSpecConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "That user is not in this guild.")
		return
	}
	for _, id := range member.Roles {
		if id == roleID {
			shared.EditError(s, i, "That user is already a PUGS Spec.")
			return
		}
	}
	if err := s.GuildMemberRoleAdd(i.GuildID, target.ID, roleID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to assign role: %v", err))
		return
	}

	pugsSpecConfig.Log(s, fmt.Sprintf("%s added <@%s> to PUGS Spec. %s", i.Member.User.Mention(), target.ID, rolecommands.FormatReason(reason)))
	updatedRoles := append(append([]string{}, member.Roles...), roleID)
	updateRoleListCacheFromMember(i.GuildID, roleListKindPugs, member, updatedRoles, "")
	message := fmt.Sprintf("%s has been added to PUGS Spec.", target.Mention())
	if reason != "" {
		message += " Reason: " + reason
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (p *PugsSpec) handleRemove(s *discordgo.Session, i *discordgo.InteractionCreate) {
	opts := optionMap(i.ApplicationCommandData().Options[0].Options)
	target := opts["member"].UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the user.")
		return
	}
	reason := ""
	if opt, ok := opts["reason"]; ok {
		reason = strings.TrimSpace(opt.StringValue())
	}

	roleID, err := pugsSpecConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "That user is not in this guild.")
		return
	}
	hasRole := false
	for _, id := range member.Roles {
		if id == roleID {
			hasRole = true
			break
		}
	}
	if !hasRole {
		shared.EditError(s, i, "That user is not a PUGS Spec.")
		return
	}
	if err := s.GuildMemberRoleRemove(i.GuildID, target.ID, roleID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to remove role: %v", err))
		return
	}

	pugsSpecConfig.Log(s, fmt.Sprintf("%s removed <@%s> from PUGS Spec. %s", i.Member.User.Mention(), target.ID, rolecommands.FormatReason(reason)))
	var updatedRoles []string
	for _, r := range member.Roles {
		if strings.TrimSpace(r) != strings.TrimSpace(roleID) {
			updatedRoles = append(updatedRoles, r)
		}
	}
	updateRoleListCacheFromMember(i.GuildID, roleListKindPugs, member, updatedRoles, "")
	message := fmt.Sprintf("%s has been removed from PUGS Spec.", target.Mention())
	if reason != "" {
		message += " Reason: " + reason
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (p *PugsSpec) handleList(s *discordgo.Session, i *discordgo.InteractionCreate) {
	roleID, err := pugsSpecConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	members, err := rolecommands.FetchAllMembers(s, i.GuildID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch members: %v", err))
		return
	}

	var list []string
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	for _, member := range members {
		for _, role := range member.Roles {
			if role == roleID {
				list = append(list, rolecommands.FormatMember(ctx, member))
				break
			}
		}
	}

	if len(list) == 0 {
		shared.EditError(s, i, "No PUGS Spec members found.")
		return
	}

	content := fmt.Sprintf("**PUGS Spec Members (%d):**\n%s", len(list), strings.Join(list, "\n"))
	if len(content) > 1900 {
		content = content[:1900] + "\n..."
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}
