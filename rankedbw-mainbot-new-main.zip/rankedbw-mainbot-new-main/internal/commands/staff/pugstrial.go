package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/rolecommands"

	"github.com/bwmarrin/discordgo"
)

var pugsTrialConfig = rolecommands.Config{
	Name:               "PUGS Trial",
	RoleEnv:            "PUGS_TRIAL_ROLE_ID",
	AnnounceChannelEnv: "PUGS_TRIAL_ANNOUNCEMENTS_CHANNEL_ID",
	LogChannelEnv:      "PUGS_TRIAL_LOG_CHANNEL_ID",
}

type PugsTrial struct{}

func NewPugsTrial() *PugsTrial    { return &PugsTrial{} }
func (p *PugsTrial) Name() string { return "pugstrial" }

func (p *PugsTrial) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        p.Name(),
		Description: "Manage PUGS Trial players.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Add a player to PUGS Trial.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "member",
						Description: "Discord user to add.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "reason",
						Description: "Reason for adding.",
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove a player from PUGS Trial.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "member",
						Description: "Discord user to remove.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "reason",
						Description: "Reason for removal.",
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List current PUGS Trial members.",
			},
		},
		// Runtime permission checks ensure only PUGS managers/owners/admins can act.
		DefaultMemberPermissions: nil,
	}
}

func (p *PugsTrial) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	switch i.ApplicationCommandData().Options[0].Name {
	case "add":
		p.handleAdd(s, i)
	case "remove":
		p.handleRemove(s, i)
	case "list":
		p.handleList(s, i)
	}
}

func (p *PugsTrial) handleAdd(s *discordgo.Session, i *discordgo.InteractionCreate) {
	opts := optionMap(i.ApplicationCommandData().Options[0].Options)
	target := opts["member"].UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the user.")
		return
	}
	if !pugsConfig.IsManagerOrOwner(i.Member) && (i.Member == nil || i.Member.Permissions&discordgo.PermissionAdministrator == 0) {
		shared.RespondEphemeral(s, i, "Only PUGS managers/owners or admins can manage PUGS Trial membership.")
		return
	}
	reason := ""
	if opt, ok := opts["reason"]; ok {
		reason = strings.TrimSpace(opt.StringValue())
	}

	roleID, err := pugsTrialConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "That user is not in this guild.")
		return
	}
	for _, id := range member.Roles {
		if id == roleID {
			shared.EditError(s, i, "That user is already PUGS Trial.")
			return
		}
	}
	if err := s.GuildMemberRoleAdd(i.GuildID, target.ID, roleID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to assign role: %v", err))
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	mcName := rolecommands.PlayerMinecraftName(ctx, target.ID)

	pugsTrialConfig.Log(s, fmt.Sprintf("%s added <@%s> to PUGS Trial. %s", i.Member.User.Mention(), target.ID, rolecommands.FormatReason(reason)))
	if strings.TrimSpace(pugsTrialConfig.AnnounceChannelEnv) != "" {
		pugsTrialConfig.Announce(s, target.ID, mcName, reason)
	}
	updatedRoles := append(append([]string{}, member.Roles...), roleID)
	updateRoleListCacheFromMember(i.GuildID, roleListKindPugs, member, updatedRoles, mcName)

	message := fmt.Sprintf("%s has been added to PUGS Trial.", target.Mention())
	if reason != "" {
		message += " Reason: " + reason
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (p *PugsTrial) handleRemove(s *discordgo.Session, i *discordgo.InteractionCreate) {
	opts := optionMap(i.ApplicationCommandData().Options[0].Options)
	target := opts["member"].UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the user.")
		return
	}
	if !pugsConfig.IsManagerOrOwner(i.Member) && (i.Member == nil || i.Member.Permissions&discordgo.PermissionAdministrator == 0) {
		shared.RespondEphemeral(s, i, "Only PUGS managers/owners or admins can manage PUGS Trial membership.")
		return
	}
	reason := ""
	if opt, ok := opts["reason"]; ok {
		reason = strings.TrimSpace(opt.StringValue())
	}

	roleID, err := pugsTrialConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "That user is not in this guild.")
		return
	}
	hasRole := false
	for _, id := range member.Roles {
		if id == roleID {
			hasRole = true
			break
		}
	}
	if !hasRole {
		shared.EditError(s, i, "That user is not PUGS Trial.")
		return
	}
	if err := s.GuildMemberRoleRemove(i.GuildID, target.ID, roleID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to remove role: %v", err))
		return
	}

	pugsTrialConfig.Log(s, fmt.Sprintf("%s removed <@%s> from PUGS Trial. %s", i.Member.User.Mention(), target.ID, rolecommands.FormatReason(reason)))
	var updatedRoles []string
	for _, r := range member.Roles {
		if strings.TrimSpace(r) != strings.TrimSpace(roleID) {
			updatedRoles = append(updatedRoles, r)
		}
	}
	updateRoleListCacheFromMember(i.GuildID, roleListKindPugs, member, updatedRoles, "")
	message := fmt.Sprintf("%s has been removed from PUGS Trial.", target.Mention())
	if reason != "" {
		message += " Reason: " + reason
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (p *PugsTrial) handleList(s *discordgo.Session, i *discordgo.InteractionCreate) {
	roleID, err := pugsTrialConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	members, err := rolecommands.FetchAllMembers(s, i.GuildID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch members: %v", err))
		return
	}

	var list []string
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	for _, member := range members {
		for _, role := range member.Roles {
			if role == roleID {
				list = append(list, rolecommands.FormatMember(ctx, member))
				break
			}
		}
	}

	if len(list) == 0 {
		shared.EditError(s, i, "No PUGS Trial members found.")
		return
	}

	content := fmt.Sprintf("**PUGS Trial Members (%d):**\n%s", len(list), strings.Join(list, "\n"))
	if len(content) > 1900 {
		content = content[:1900] + "\n..."
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}
