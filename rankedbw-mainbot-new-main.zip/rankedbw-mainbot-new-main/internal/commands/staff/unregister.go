package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Unregister struct{}

func NewUnregister() *Unregister   { return &Unregister{} }
func (c *Unregister) Name() string { return "unregister" }
func (c *Unregister) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Unregister a player.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "player",
				Description: "Player to remove.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for unregistering.",
				Required:    true,
			},
		},
	}
}

func (c *Unregister) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to unregister players.")
		return
	}

	opts := optionMap(i.ApplicationCommandData().Options)
	target := opts["player"].UserValue(s)
	reason := strings.TrimSpace(opts["reason"].StringValue())

	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	if reason == "" {
		shared.RespondEphemeral(s, i, "Please provide a reason.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "That user is not registered.")
		return
	}

	if err := storage.DeletePlayerByUserID(ctx, target.ID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to unregister player: %v", err))
		return
	}

	_ = s.GuildMemberNickname(i.GuildID, target.ID, "")

	logChannel, _ := storage.GetLogChannelID(ctx)
	if logChannel != "" {
		desc := fmt.Sprintf("<@%s> unregistered <@%s>. Reason: `%s`", i.Member.User.ID, target.ID, reason)
		embed := &discordgo.MessageEmbed{
			Title:       "Player Unregistered",
			Description: desc,
			Color:       0xE74C3C,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
	}

	content := fmt.Sprintf("%s has been unregistered.", target.Mention())
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}
