package staff

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"

	"github.com/bwmarrin/discordgo"
)

type RoleListPager struct{}

func NewRoleListPager() *RoleListPager { return &RoleListPager{} }

func (p *RoleListPager) HandleComponent(sess *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if sess == nil || i == nil || i.Type != discordgo.InteractionMessageComponent {
		return false
	}
	customID := strings.TrimSpace(i.MessageComponentData().CustomID)
	if !strings.HasPrefix(customID, roleListNavPrefix) {
		return false
	}

	payload := strings.TrimPrefix(customID, roleListNavPrefix)
	parts := strings.Split(payload, ":")
	if len(parts) != 4 {
		return false
	}

	kind := strings.TrimSpace(parts[0])
	pageRaw := strings.TrimSpace(parts[1])
	requester := strings.TrimSpace(parts[2])
	direction := strings.TrimSpace(parts[3])

	if requester == "" || requester != interactionUserID(i) {
		shared.RespondEphemeral(sess, i, "Only the user who ran this command can use these buttons.")
		return true
	}

	page, err := strconv.Atoi(pageRaw)
	if err != nil {
		shared.RespondEphemeral(sess, i, "Invalid page.")
		return true
	}
	if direction == "prev" {
		page--
	} else if direction == "next" {
		page++
	} else {
		return false
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	entry, err := ensureRoleListCacheBuilt(ctx, sess, i.GuildID, kind)
	if err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to load list: %v", err))
		return true
	}
	embeds, err := entry.embedsForDisplay()
	if err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to build list: %v", err))
		return true
	}
	if len(embeds) == 0 {
		shared.RespondEphemeral(sess, i, "No members found.")
		return true
	}

	totalPages := len(embeds)
	if page < 1 {
		page = 1
	}
	if page > totalPages {
		page = totalPages
	}

	components := roleListNavComponents(kind, page, totalPages, requester)
	allowed := &discordgo.MessageAllowedMentions{Parse: []discordgo.AllowedMentionType{}}

	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseUpdateMessage,
		Data: &discordgo.InteractionResponseData{
			Embeds:          []*discordgo.MessageEmbed{embeds[page-1]},
			Components:      components,
			AllowedMentions: allowed,
		},
	})
	return true
}

