package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Close struct{}

func NewClose() *Close        { return &Close{} }
func (c *Close) Name() string { return "close" }

func (c *Close) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Close a game by cleaning up its team channels and thread.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "gameid",
				Description: "Game ID (e.g. 1).",
				Required:    true,
			},
		},
		DefaultMemberPermissions: &perm,
	}
}

func (c *Close) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	gameID := strings.ToUpper(strings.TrimSpace(i.ApplicationCommandData().Options[0].StringValue()))
	if gameID == "" {
		shared.RespondEphemeral(s, i, "Provide a valid game ID.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	game, _, _, err := storage.GetGameWithPlayersActiveSeason(ctx, gameID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load game: %v", err))
		return
	}
	if game == nil {
		shared.EditError(s, i, fmt.Sprintf("Game `%s` was not found.", gameID))
		return
	}

	actions, warnings := shared.CleanupGameResources(s, i.GuildID, game)

	var msg strings.Builder
	msg.WriteString(fmt.Sprintf("Game `%s` cleaned up.", game.GameID))
	if len(actions) > 0 {
		msg.WriteString("\nActions:")
		for _, entry := range actions {
			msg.WriteString("\n- ")
			msg.WriteString(entry)
		}
	}
	if len(warnings) > 0 {
		msg.WriteString("\nWarnings:")
		for _, entry := range warnings {
			msg.WriteString("\n- ")
			msg.WriteString(entry)
		}
	}
	if len(actions) == 0 && len(warnings) == 0 {
		msg.WriteString("\nNo channels or thread were associated with this game.")
	}

	content := msg.String()
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &content,
	})

	if logChannel, _ := storage.GetLogChannelID(ctx); strings.TrimSpace(logChannel) != "" && i.Member != nil && i.Member.User != nil {
		embed := &discordgo.MessageEmbed{
			Description: fmt.Sprintf("User <@%s> closed game `%s`.", i.Member.User.ID, game.GameID),
			Color:       shared.DefaultEmbedColor,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
	}
}
