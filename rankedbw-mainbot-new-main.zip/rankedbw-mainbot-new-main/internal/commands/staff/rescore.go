package staff

import "github.com/bwmarrin/discordgo"

// Rescore is an alias for /refresh.
type Rescore struct{}

func NewRescore() *Rescore { return &Rescore{} }
func (c *Rescore) Name() string {
	return "rescore"
}

func (c *Rescore) Build() *discordgo.ApplicationCommand {
	cmd := NewRefresh().Build()
	cmd.Name = c.Name()
	cmd.Description = "Alias for /refresh (staff)."
	return cmd
}

func (c *Rescore) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	NewRefresh().Handle(sess, i)
}

