package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/assets"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type RankedUnban struct{}

func NewRankedUnban() *RankedUnban  { return &RankedUnban{} }
func (c *RankedUnban) Name() string { return "rankedunban" }
func (c *RankedUnban) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Unban a player from ranked.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "player",
				Description: "Player to unban.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for unbanning.",
				Required:    true,
			},
		},
	}
}

func (c *RankedUnban) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to unban players from ranked.")
		return
	}

	target := i.ApplicationCommandData().Options[0].UserValue(s)
	reason := strings.TrimSpace(i.ApplicationCommandData().Options[1].StringValue())
	roleID := shared.SettingOrEnv("RANKED_BAN_ROLE_ID")

	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	if roleID == "" {
		shared.RespondEphemeral(s, i, "RANKED_BAN_ROLE_ID is not configured.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "Failed to fetch guild member.")
		return
	}
	hasRankedRole := memberHasRole(member, roleID)

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	if player == nil {
		if !hasRankedRole {
			shared.EditError(s, i, "This player is not currently ranked banned.")
			return
		}
		_ = s.GuildMemberRoleRemove(i.GuildID, target.ID, roleID)
		notifyRankedUnban(ctx, s, target.ID, i.Member.User.ID, reason)
		content := fmt.Sprintf("%s has been unbanned from ranked.", target.Mention())
		_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
		return
	}

	record, err := storage.LatestActiveRankedBan(ctx, player.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to locate ban: %v", err))
		return
	}
	if record == nil {
		shared.EditError(s, i, "This player is not currently ranked banned.")
		return
	}

	if err := storage.MarkPunishmentsExpiredByPlayerType(ctx, player.ID, storage.PunishmentTypeRankedBan); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to mark punishment expired: %v", err))
		return
	}
	if _, err := storage.CreatePunishment(ctx, player.ID, i.Member.User.ID, reason, storage.PunishmentTypeRankedUnban, time.Time{}); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to log unban: %v", err))
		return
	}

	_ = s.GuildMemberRoleRemove(i.GuildID, target.ID, roleID)
	notifyRankedUnban(ctx, s, target.ID, i.Member.User.ID, reason)

	content := fmt.Sprintf("%s has been unbanned from ranked.", target.Mention())
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}

func notifyRankedUnban(ctx context.Context, s *discordgo.Session, userID, staffID, reason string) {
	punishChannel, _ := storage.GetPunishmentsChannelID(ctx)
	logChannel, _ := storage.GetStaffPunishmentLogChannelID(ctx)

	if punishChannel != "" {
		desc := fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n\nYou may now queue ranked matches again.", userID, reason)
		embed := &discordgo.MessageEmbed{
			Title:       "Ranked Ban Removed",
			Description: desc,
			Color:       0x40FF56,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
				Files:   files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
			})
		}
	}

	if logChannel != "" {
		desc := fmt.Sprintf("<@%s> removed the ranked ban on <@%s>. Reason: `%s`", staffID, userID, reason)
		embed := &discordgo.MessageEmbed{
			Title:       "Ranked Ban Removal Logged",
			Description: desc,
			Color:       0x40FF56,
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(logChannel, &discordgo.MessageSend{
				Embeds: []*discordgo.MessageEmbed{embed},
				Files:  files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
		}
	}
}
