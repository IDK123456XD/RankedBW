package staff

import (
	"fmt"
	"regexp"
	"strings"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/discordutil"

	"github.com/bwmarrin/discordgo"
)

var teamChannelPattern = regexp.MustCompile(`^Game\s+.+\s+-\s+Team\s+[12]$`)

type VoiceCleanup struct{}

func NewVoiceCleanup() *VoiceCleanup { return &VoiceCleanup{} }
func (v *VoiceCleanup) Name() string { return "voicecleanup" }
func (v *VoiceCleanup) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:                     v.Name(),
		Description:              "Force delete empty game voice channels.",
		DefaultMemberPermissions: &perm,
	}
}

func (v *VoiceCleanup) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if i.GuildID == "" {
		shared.RespondEphemeral(s, i, "This command can only be used inside a guild.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	channels, err := s.GuildChannels(i.GuildID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load guild channels: %v", err))
		return
	}

	guild, err := s.State.Guild(i.GuildID)
	if err != nil || guild == nil {
		shared.EditError(s, i, "Guild voice data is unavailable right now. Please try again shortly.")
		return
	}

	occupancy := make(map[string]int, len(guild.VoiceStates))
	for _, vs := range guild.VoiceStates {
		if vs.ChannelID != "" {
			occupancy[vs.ChannelID]++
		}
	}

	var removed, inUse, failed []string
	for _, ch := range channels {
		if ch == nil || ch.Type != discordgo.ChannelTypeGuildVoice {
			continue
		}
		if !isTeamVoiceChannel(ch.Name) {
			continue
		}
		if occupancy[ch.ID] > 0 {
			inUse = append(inUse, fmt.Sprintf("<#%s>", ch.ID))
			continue
		}
		task := discordutil.DeleteTask{
			ChannelID:     ch.ID,
			GuildID:       i.GuildID,
			Hide:          true,
			MoveMembersTo: shared.WaitingRoomID(),
			Reason:        "voicecleanup command",
		}
		if discordutil.EnqueueDelete(task) {
			removed = append(removed, fmt.Sprintf("`%s` (queued)", ch.Name))
			continue
		}
		if _, err := s.ChannelDelete(ch.ID); err != nil {
			failed = append(failed, fmt.Sprintf("<#%s>: %v", ch.ID, err))
			continue
		}
		removed = append(removed, fmt.Sprintf("`%s`", ch.Name))
	}

	var msg strings.Builder
	if len(removed) == 0 && len(inUse) == 0 && len(failed) == 0 {
		msg.WriteString("No temporary team voice channels were found.")
	} else {
		msg.WriteString(fmt.Sprintf("Removed %d empty voice channel(s).", len(removed)))
		if len(inUse) > 0 {
			msg.WriteString(fmt.Sprintf("\nSkipped %d channel(s) that still had members.", len(inUse)))
		}
		if len(failed) > 0 {
			msg.WriteString("\nFailed to remove:")
			for _, entry := range failed {
				msg.WriteString("\n- ")
				msg.WriteString(entry)
			}
		}
	}

	content := msg.String()
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &content,
	})
}

func isTeamVoiceChannel(name string) bool {
	name = strings.TrimSpace(name)
	if name == "" {
		return false
	}
	return teamChannelPattern.MatchString(name)
}
