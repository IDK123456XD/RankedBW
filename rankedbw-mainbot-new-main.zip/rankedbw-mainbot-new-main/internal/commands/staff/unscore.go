package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/leveling"
	"rbw-bot/internal/scoring"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Unscore struct{}

func NewUnscore() *Unscore      { return &Unscore{} }
func (u *Unscore) Name() string { return "unscore" }
func (u *Unscore) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:        u.Name(),
		Description: "Unscore a previously scored game.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "gameid",
				Description: "The game to unscore.",
				Required:    true,
			},
		},
		DefaultMemberPermissions: &perm,
	}
}

func (u *Unscore) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if len(i.ApplicationCommandData().Options) == 0 {
		shared.RespondEphemeral(sess, i, "Provide a game ID to unscore.")
		return
	}
	gameID := strings.TrimSpace(i.ApplicationCommandData().Options[0].StringValue())
	if gameID == "" {
		shared.RespondEphemeral(sess, i, "Provide a valid game ID.")
		return
	}

	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	logChannelID, err := storage.GetLogChannelID(ctx)
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to load log channel: %v", err))
		return
	}

	game, players, _, err := storage.GetGameWithPlayersActiveSeason(ctx, gameID)
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to load game: %v", err))
		return
	}
	if game == nil {
		shared.EditError(sess, i, fmt.Sprintf("Game `%s` was not found.", gameID))
		return
	}
	status := strings.ToUpper(strings.TrimSpace(game.Status))
	if status != "FINISHED" && status != "SCORED" {
		shared.EditError(sess, i, fmt.Sprintf("Game `%s` has not been scored yet.", gameID))
		return
	}
	if len(players) == 0 {
		shared.EditError(sess, i, "No players are recorded for this game.")
		return
	}

	seasonID, err := scoring.SeasonIDForGame(ctx, game)
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to determine season: %v", err))
		return
	}

	var updates []storage.UnscoreUpdate
	var adjustedMentions []string
	for _, player := range players {
		playerLabel := scoring.MentionFromDiscordID(player.DiscordID)
		if playerLabel == "" {
			playerLabel = fmt.Sprintf("`%s`", player.PlayerID)
		}
		stats, err := storage.GetPlayerSeasonStats(ctx, player.PlayerID, seasonID)
		if err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to load stats for %s: %v", playerLabel, err))
			return
		}
		if stats == nil {
			shared.EditError(sess, i, fmt.Sprintf("%s has no stats for this season.", playerLabel))
			return
		}
		skipStats := stats.LastReset.Valid && game.CreatedAt.Before(stats.LastReset.Time)
		if skipStats {
			updates = append(updates, storage.UnscoreUpdate{
				GamePlayerID: player.ID,
				PlayerID:     player.PlayerID,
				StatsID:      stats.ID,
				SeasonID:     stats.SeasonID,
				Win:          player.Win,
				MVP:          player.MVP,
				XPDelta:      0,
				Streak:       stats.Streak,
				NewElo:       stats.Elo,
				ExtraReason:  fmt.Sprintf("Game Unscored: %s", game.GameID),
				SkipStats:    true,
			})
			continue
		}
		if stats.GamesPlayed <= 0 {
			shared.EditError(sess, i, fmt.Sprintf("Cannot unscore because %s has no recorded games.", playerLabel))
			return
		}
		if player.Win && stats.Wins <= 0 {
			shared.EditError(sess, i, fmt.Sprintf("Cannot unscore because wins for %s would become negative.", playerLabel))
			return
		}
		if !player.Win && stats.Losses <= 0 {
			shared.EditError(sess, i, fmt.Sprintf("Cannot unscore because losses for %s would become negative.", playerLabel))
			return
		}
		if player.MVP && stats.MVPs <= 0 {
			shared.EditError(sess, i, fmt.Sprintf("Cannot unscore because MVPs for %s would become negative.", playerLabel))
			return
		}

		newElo := stats.Elo - player.EloDiff
		if newElo < 0 {
			newElo = 0
		}
		xpToRemove := leveling.GameXPReward(player.PreElo, player.Win, player.MVP)
		newStreak := scoring.StreakAfterRevert(stats.Streak, player.Win)

		updates = append(updates, storage.UnscoreUpdate{
			GamePlayerID: player.ID,
			PlayerID:     player.PlayerID,
			StatsID:      stats.ID,
			SeasonID:     stats.SeasonID,
			Win:          player.Win,
			MVP:          player.MVP,
			XPDelta:      xpToRemove,
			Streak:       newStreak,
			NewElo:       newElo,
			ExtraReason:  fmt.Sprintf("Game Unscored: %s", game.GameID),
		})

		if mention := scoring.MentionFromDiscordID(player.DiscordID); mention != "" {
			adjustedMentions = append(adjustedMentions, mention)
		}
	}

	if err := storage.RevertGameScore(ctx, game.ID, updates); err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to unscore game: %v", err))
		return
	}

	refreshNicknamesFromUnscore(ctx, sess, i.GuildID, updates, "unscore")

	msg := fmt.Sprintf("Game `%s` has been unscored.", gameID)
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})

	u.logUnscoreResult(sess, logChannelID, i, gameID, adjustedMentions)
}

func (u *Unscore) logUnscoreResult(sess *discordgo.Session, channelID string, i *discordgo.InteractionCreate, gameID string, players []string) {
	if channelID == "" {
		return
	}
	moderator := "Unknown"
	if i.Member != nil && i.Member.User != nil {
		moderator = fmt.Sprintf("<@%s>", i.Member.User.ID)
	} else if i.User != nil {
		moderator = fmt.Sprintf("<@%s>", i.User.ID)
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Game %s Unscored", gameID),
		Description: fmt.Sprintf("Adjusted players: %s", scoring.FormatList(players)),
		Color:       0xe67e22,
		Fields: []*discordgo.MessageEmbedField{
			{Name: "Moderator", Value: moderator, Inline: true},
		},
		Timestamp: time.Now().Format(time.RFC3339),
	}

	if _, err := sess.ChannelMessageSendEmbed(channelID, embed); err != nil {
		fmt.Printf("unscore: failed to send log embed: %v\n", err)
	}
}
