package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/queue"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type QueueConfigCmd struct {
	queueSvc *queue.Service
}

func NewQueueConfig(queueSvc *queue.Service) *QueueConfigCmd {
	return &QueueConfigCmd{queueSvc: queueSvc}
}

func (c *QueueConfigCmd) Name() string { return "queueconfig" }

func (c *QueueConfigCmd) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Manage queue channel configurations.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "set",
				Description: "Create or update a queue channel config.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionChannel,
						Name:        "channel",
						Description: "Voice channel queued players join.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionInteger,
						Name:        "minelo",
						Description: "Minimum ELO allowed.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionInteger,
						Name:        "maxelo",
						Description: "Maximum ELO allowed.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "setup",
				Description: "Set the queue channel setup mode.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionChannel,
						Name:        "channel",
						Description: "Queue voice channel.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "mode",
						Description: "Setup mode.",
						Required:    true,
						Choices: []*discordgo.ApplicationCommandOptionChoice{
							{Name: "default", Value: "default"},
							{Name: "picking", Value: "picking"},
						},
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "delete",
				Description: "Remove a queue config.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionChannel,
						Name:        "channel",
						Description: "Channel to remove.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List all queue configs.",
			},
		},
		DefaultMemberPermissions: &perm,
	}
}

func (c *QueueConfigCmd) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	sub := i.ApplicationCommandData().Options[0]
	switch sub.Name {
	case "set":
		c.handleSet(s, i, sub)
	case "setup":
		c.handleSetup(s, i, sub)
	case "delete":
		c.handleDelete(s, i, sub)
	case "list":
		c.handleList(s, i)
	}
}

func (c *QueueConfigCmd) handleSet(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	channelOpt := opt.Options[0].ChannelValue(s)
	if channelOpt == nil || channelOpt.Type != discordgo.ChannelTypeGuildVoice {
		shared.RespondEphemeral(s, i, "Select a valid voice channel.")
		return
	}
	minElo := int(opt.Options[1].IntValue())
	maxElo := int(opt.Options[2].IntValue())
	if minElo < 0 || maxElo < minElo {
		shared.RespondEphemeral(s, i, "ELO values must be positive and min <= max.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	err := storage.UpsertQueueConfig(ctx, storage.QueueConfig{
		ChannelID: channelOpt.ID,
		MinElo:    minElo,
		MaxElo:    maxElo,
	})
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to save queue config: %v", err))
		return
	}
	c.reload(ctx, s)
	content := fmt.Sprintf("Queue config saved for <#%s> (%d-%d ELO).", channelOpt.ID, minElo, maxElo)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &content,
	})
}

func (c *QueueConfigCmd) handleSetup(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	channelOpt := opt.Options[0].ChannelValue(s)
	if channelOpt == nil || channelOpt.Type != discordgo.ChannelTypeGuildVoice {
		shared.RespondEphemeral(s, i, "Select a valid voice channel.")
		return
	}
	mode := strings.TrimSpace(opt.Options[1].StringValue())
	if mode == "" {
		shared.RespondEphemeral(s, i, "Select a valid setup mode.")
		return
	}
	if strings.EqualFold(mode, "default") {
		mode = ""
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	configs, err := storage.ListQueueConfigs(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load queue configs: %v", err))
		return
	}
	var existing *storage.QueueConfig
	for idx := range configs {
		if configs[idx].ChannelID == channelOpt.ID {
			existing = &configs[idx]
			break
		}
	}
	if existing == nil {
		shared.EditError(s, i, "Queue config not found. Use /queueconfig set first.")
		return
	}
	existing.Setup = mode
	if err := storage.UpsertQueueConfig(ctx, *existing); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update queue config: %v", err))
		return
	}
	c.reload(ctx, s)
	label := "default"
	if existing.Setup != "" {
		label = existing.Setup
	}
	content := fmt.Sprintf("Queue setup updated for <#%s> (%s).", channelOpt.ID, label)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &content,
	})
}

func (c *QueueConfigCmd) handleDelete(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	channelOpt := opt.Options[0].ChannelValue(s)
	if channelOpt == nil {
		shared.RespondEphemeral(s, i, "Select a valid channel.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := storage.DeleteQueueConfig(ctx, channelOpt.ID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to delete config: %v", err))
		return
	}
	c.reload(ctx, s)
	content := fmt.Sprintf("Removed queue config for <#%s>.", channelOpt.ID)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &content,
	})
}

func (c *QueueConfigCmd) handleList(s *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	configs, err := storage.ListQueueConfigs(ctx)
	if err != nil {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Failed to load queue configs: %v", err))
		return
	}
	if len(configs) == 0 {
		shared.Respond(s, i, "No queue configs have been set.")
		return
	}
	var b strings.Builder
	for _, cfg := range configs {
		setup := "default"
		if strings.TrimSpace(cfg.Setup) != "" {
			setup = strings.TrimSpace(cfg.Setup)
		}
		b.WriteString(fmt.Sprintf("<#%s>: %d - %d ELO (setup: %s)\n", cfg.ChannelID, cfg.MinElo, cfg.MaxElo, setup))
	}
	shared.Respond(s, i, b.String())
}

func (c *QueueConfigCmd) reload(ctx context.Context, sess *discordgo.Session) {
	if c.queueSvc == nil {
		return
	}
	if err := c.queueSvc.ReloadConfigs(ctx); err != nil {
		fmt.Printf("queueconfig reload failed: %v\n", err)
	}
}
