package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

// Refresh resends the scoring card for a game using the stored proof.
type Refresh struct{}

func NewRefresh() *Refresh { return &Refresh{} }
func (c *Refresh) Name() string {
	return "refresh"
}

func (c *Refresh) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Resend the scoring card for a game (staff).",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "gameid",
				Description: "Game ID to refresh.",
				Required:    true,
			},
		},
	}
}

func (c *Refresh) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(sess, i, "You do not have permission to refresh scoring cards.")
		return
	}
	if len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	gameID := strings.TrimSpace(i.ApplicationCommandData().Options[0].StringValue())
	if gameID == "" {
		shared.RespondEphemeral(sess, i, "Provide a game ID.")
		return
	}

	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	game, _, _, err := storage.GetGameWithPlayersActiveSeason(ctx, gameID)
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to load game: %v", err))
		return
	}
	if game == nil {
		shared.EditError(sess, i, "Game not found.")
		return
	}

	proof := ""
	if game.ProofURL.Valid && strings.TrimSpace(game.ProofURL.String) != "" {
		proof = strings.TrimSpace(game.ProofURL.String)
	}

	scoreCmd := NewScore()
	if err := scoreCmd.createScoringCard(ctx, sess, i.GuildID, i.Member.User.ID, game.GameID, proof, "", "refresh", true); err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to refresh scoring card: %v", err))
		return
	}

	msg := fmt.Sprintf("Resent scoring card for game `%s`.", game.GameID)
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}
