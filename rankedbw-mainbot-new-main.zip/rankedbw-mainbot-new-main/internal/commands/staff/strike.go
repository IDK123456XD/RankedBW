package staff

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/assets"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

const strikeEloPenalty = 30

type Strike struct{}

func NewStrike() *Strike       { return &Strike{} }
func (c *Strike) Name() string { return "strike" }
func (c *Strike) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Strike a player.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "player",
				Description: "Player to strike.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for the strike.",
				Required:    true,
			},
		},
	}
}

func (c *Strike) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to strike players.")
		return
	}

	opts := optionMap(i.ApplicationCommandData().Options)
	targetOpt := opts["player"]
	reasonOpt := opts["reason"]
	if targetOpt == nil || reasonOpt == nil {
		shared.RespondEphemeral(s, i, "Player and reason are required.")
		return
	}
	target := targetOpt.UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	reason := strings.TrimSpace(reasonOpt.StringValue())
	if reason == "" {
		shared.RespondEphemeral(s, i, "Please provide a reason for the strike.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "That player is not registered.")
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to find active season: %v", err))
		return
	}
	if err := storage.EnsurePlayerSeasonStats(ctx, player.ID, seasonID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to prepare stats: %v", err))
		return
	}
	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load season stats: %v", err))
		return
	}
	if stats == nil {
		shared.EditError(s, i, "Player has no stats for the active season.")
		return
	}

	newElo := stats.Elo - strikeEloPenalty
	prev, updated, err := storage.UpdatePlayerElo(ctx, stats.ID, player.ID, seasonID, newElo, "Strike", reason)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update ELO: %v", err))
		return
	}

	if _, err := storage.CreateStrike(ctx, player.ID, i.Member.User.ID, reason); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to record strike: %v", err))
		return
	}

	stats.Elo = updated
	display := shared.BuildDisplayName(player, stats)
	if err := s.GuildMemberNickname(i.GuildID, player.UserID, display); err != nil {
		log.Printf("strike: failed to update nickname for %s: %v", player.UserID, err)
	}

	season, _ := storage.ActiveSeason(ctx)
	count := 0
	if season != nil {
		if c, err := storage.ActiveStrikeCountForSeason(ctx, player.ID, season); err == nil {
			count = c
		}
	} else if c, err := storage.ActiveStrikeCount(ctx, player.ID); err == nil {
		count = c
	}
	notifyStrikeChannels(ctx, s, i.GuildID, target.ID, i.Member.User.ID, reason, strikeEloPenalty, updated, count)
	c.maybeAutoRankedBan(ctx, s, i, player, target.ID, count)

	content := fmt.Sprintf("%s has been striked. ELO: %d ➜ %d.", target.Mention(), prev, updated)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}

func notifyStrikeChannels(ctx context.Context, s *discordgo.Session, guildID, userID, staffID, reason string, eloDelta, newElo, totalStrikes int) {
	punishChannel, _ := storage.GetPunishmentsChannelID(ctx)
	supportChannel, _ := storage.GetSupportChannelID(ctx)
	logChannel, _ := storage.GetStaffPunishmentLogChannelID(ctx)

	if punishChannel != "" {
		supportMention := "support"
		if strings.TrimSpace(supportChannel) != "" {
			supportMention = fmt.Sprintf("<#%s>", supportChannel)
		}
		desc := fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n**ELO Deducted:** -%d\n\nAppeal in %s if you believe this is an error.", userID, reason, eloDelta, supportMention)
		embed := &discordgo.MessageEmbed{
			Title:       "Strike Issued",
			Description: desc,
			Color:       0xD8833B,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("strike.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
				Files:   files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
			})
		}
	}

	if logChannel != "" {
		desc := fmt.Sprintf("<@%s> issued a strike to <@%s>.\nReason: `%s`\nELO now: %d\nActive strikes: %d", staffID, userID, reason, newElo, totalStrikes)
		embed := &discordgo.MessageEmbed{
			Title:       "Strike Logged",
			Description: desc,
			Color:       0xD8833B,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("strike.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(logChannel, &discordgo.MessageSend{
				Embeds: []*discordgo.MessageEmbed{embed},
				Files:  files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
		}
	}
}

func (c *Strike) maybeAutoRankedBan(ctx context.Context, s *discordgo.Session, i *discordgo.InteractionCreate, player *storage.PlayerRecord, userID string, strikes int) {
	if ctx == nil || s == nil || i == nil || player == nil || strikes < 2 {
		return
	}
	duration, ok := autoRankedBanDurations()[strikes]
	if !ok || duration <= 0 {
		return
	}
	roleID := strings.TrimSpace(shared.SettingOrEnv("RANKED_BAN_ROLE_ID"))
	if roleID == "" {
		return
	}
	reason := fmt.Sprintf("Auto ranked ban: %d strikes this season", strikes)
	if active, err := storage.ActiveRankedBanForPlayer(ctx, player.ID); err == nil && active != nil {
		oldExpiry := time.Now()
		if active.ExpiresAt.Valid {
			oldExpiry = active.ExpiresAt.Time
		}
		newExpiry := oldExpiry.Add(duration)
		if err := storage.UpdatePunishmentExpiry(ctx, active.ID, newExpiry); err != nil {
			log.Printf("strike: failed to extend ranked ban %s: %v", active.ID, err)
			return
		}
		_ = s.GuildMemberRoleAdd(i.GuildID, userID, roleID)
		notifyAutoStrikeBanExtension(ctx, s, userID, i.Member.User.ID, reason, formatDurationLabel(duration), oldExpiry, newExpiry)
		return
	}

	expiry := time.Now().Add(duration)
	if _, err := storage.CreatePunishment(ctx, player.ID, i.Member.User.ID, reason, storage.PunishmentTypeRankedBan, expiry); err != nil {
		log.Printf("strike: failed to auto-ban %s: %v", player.ID, err)
		return
	}
	_ = s.GuildMemberRoleAdd(i.GuildID, userID, roleID)
	notifyAutoStrikeBan(ctx, s, userID, i.Member.User.ID, reason, formatDurationLabel(duration), expiry)
}

func autoRankedBanDurations() map[int]time.Duration {
	return map[int]time.Duration{
		2:  12 * time.Hour,
		3:  24 * time.Hour,
		4:  3 * 24 * time.Hour,
		5:  7 * 24 * time.Hour,
		6:  14 * 24 * time.Hour,
		7:  30 * 24 * time.Hour,
		8:  60 * 24 * time.Hour,
	}
}

func formatDurationLabel(d time.Duration) string {
	if d%(24*time.Hour) == 0 {
		days := int(d / (24 * time.Hour))
		return fmt.Sprintf("%dd", days)
	}
	if d%time.Hour == 0 {
		hours := int(d / time.Hour)
		return fmt.Sprintf("%dh", hours)
	}
	return d.String()
}

func notifyAutoStrikeBan(ctx context.Context, s *discordgo.Session, userID, staffID, reason, duration string, expiry time.Time) {
	punishChannel, _ := storage.GetPunishmentsChannelID(ctx)
	supportChannel, _ := storage.GetSupportChannelID(ctx)
	logChannel, _ := storage.GetStaffPunishmentLogChannelID(ctx)
	expiryUnix := expiry.Unix()

	if punishChannel != "" {
		supportMention := "support"
		if strings.TrimSpace(supportChannel) != "" {
			supportMention = fmt.Sprintf("<#%s>", supportChannel)
		}
		desc := fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n**Duration:** %s (<t:%d:R>)\n\nIf you wish to appeal, open a ticket in %s.", userID, reason, duration, expiryUnix, supportMention)
		embed := &discordgo.MessageEmbed{
			Title:       "Auto Ranked Ban (Strikes)",
			Description: desc,
			Color:       0xFF3643,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
				Files:   files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
			})
		}
	}

	if logChannel != "" {
		desc := fmt.Sprintf("<@%s> auto-banned <@%s> from ranked.\nReason: `%s`\nDuration: %s\nExpires: <t:%d:F>", staffID, userID, reason, duration, expiryUnix)
		embed := &discordgo.MessageEmbed{
			Title:       "Auto Ranked Ban Logged",
			Description: desc,
			Color:       0xFF3643,
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(logChannel, &discordgo.MessageSend{
				Embeds: []*discordgo.MessageEmbed{embed},
				Files:  files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
		}
	}
}

func notifyAutoStrikeBanExtension(ctx context.Context, s *discordgo.Session, userID, staffID, reason, duration string, oldExpiry, newExpiry time.Time) {
	punishChannel, _ := storage.GetPunishmentsChannelID(ctx)
	supportChannel, _ := storage.GetSupportChannelID(ctx)
	logChannel, _ := storage.GetStaffPunishmentLogChannelID(ctx)
	oldUnix := oldExpiry.Unix()
	newUnix := newExpiry.Unix()

	if punishChannel != "" {
		supportMention := "support"
		if strings.TrimSpace(supportChannel) != "" {
			supportMention = fmt.Sprintf("<#%s>", supportChannel)
		}
		desc := fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n**Extension:** %s\n**Old Expiry:** <t:%d:F>\n**New Expiry:** <t:%d:F> (<t:%d:R>)\n\nIf you wish to appeal, open a ticket in %s.", userID, reason, duration, oldUnix, newUnix, newUnix, supportMention)
		embed := &discordgo.MessageEmbed{
			Title:       "Auto Ranked Ban Extended",
			Description: desc,
			Color:       0xFF3643,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
				Files:   files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
			})
		}
	}

	if logChannel != "" {
		desc := fmt.Sprintf("<@%s> extended auto ranked ban for <@%s>.\nReason: `%s`\nExtension: %s\nOld expiry: <t:%d:F>\nNew expiry: <t:%d:F>", staffID, userID, reason, duration, oldUnix, newUnix)
		embed := &discordgo.MessageEmbed{
			Title:       "Auto Ranked Ban Extended",
			Description: desc,
			Color:       0xFF3643,
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(logChannel, &discordgo.MessageSend{
				Embeds: []*discordgo.MessageEmbed{embed},
				Files:  files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
		}
	}
}
