package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/assets"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Unmute struct{}

func NewUnmute() *Unmute       { return &Unmute{} }
func (c *Unmute) Name() string { return "unmute" }
func (c *Unmute) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Unmute a player.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "player",
				Description: "Player to unmute.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for unmuting.",
			},
		},
	}
}

func (c *Unmute) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to unmute players.")
		return
	}

	target := i.ApplicationCommandData().Options[0].UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	reason := ""
	if len(i.ApplicationCommandData().Options) > 1 {
		reason = strings.TrimSpace(i.ApplicationCommandData().Options[1].StringValue())
	}

	mutedRoleID := shared.SettingOrEnv("MUTED_ROLE_ID")
	if mutedRoleID == "" {
		shared.RespondEphemeral(s, i, "MUTED_ROLE_ID is not configured.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	punishChannel, _ := storage.GetPunishmentsChannelID(ctx)
	logChannel, _ := storage.GetStaffPunishmentLogChannelID(ctx)

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "Failed to fetch guild member.")
		return
	}
	hasMuteRole := memberHasRole(member, mutedRoleID)

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	if player == nil {
		if !hasMuteRole {
			shared.EditError(s, i, "This player is not currently muted.")
			return
		}
		removeMuteRole(s, i.GuildID, target.ID, mutedRoleID)
		notifyUnmute(ctx, s, punishChannel, logChannel, i.Member.User.ID, target.ID, reason)
		content := fmt.Sprintf("%s has been unmuted.", target.Mention())
		_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
		return
	}

	record, err := storage.LatestActiveMute(ctx, player.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to locate mute: %v", err))
		return
	}
	if record == nil {
		shared.EditError(s, i, "This player is not currently muted.")
		return
	}

	if err := storage.MarkPunishmentExpired(ctx, record.ID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to mark punishment expired: %v", err))
		return
	}

	removeMuteRole(s, i.GuildID, target.ID, mutedRoleID)

	notifyUnmute(ctx, s, punishChannel, logChannel, i.Member.User.ID, target.ID, reason)

	content := fmt.Sprintf("%s has been unmuted.", target.Mention())
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}

func notifyUnmute(ctx context.Context, s *discordgo.Session, punishChannel, logChannel, moderatorID, targetID, reason string) {
	if punishChannel != "" {
		desc := fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n\nYour mute has been lifted.", targetID, reason)
		embed := &discordgo.MessageEmbed{
			Title:       "Mute Removed",
			Description: desc,
			Color:       0x40FF56,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", targetID),
				Embeds:  []*discordgo.MessageEmbed{embed},
				Files:   files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", targetID),
				Embeds:  []*discordgo.MessageEmbed{embed},
			})
		}
	}
	if logChannel != "" {
		embed := &discordgo.MessageEmbed{
			Title:       "Mute Removed",
			Description: fmt.Sprintf("<@%s> unmuted <@%s>. Reason: `%s`", moderatorID, targetID, reason),
			Color:       0x40FF56,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(logChannel, &discordgo.MessageSend{
				Embeds: []*discordgo.MessageEmbed{embed},
				Files:  files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
		}
	}
}
