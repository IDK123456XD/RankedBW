package staff

import (
	"context"
	"fmt"
	"log"
	"regexp"
	"strconv"
	"strings"
	"time"

	"rbw-bot/internal/assets"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

var banDurationRegex = regexp.MustCompile(`(?i)(\d+)([smhdw])`)

type RankedBan struct{}

func NewRankedBan() *RankedBan    { return &RankedBan{} }
func (c *RankedBan) Name() string { return "rankedban" }
func (c *RankedBan) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Ban a player from ranked.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "player",
				Description: "Player to ban.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "duration",
				Description: "Duration (e.g., 7d12h).",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for the ban.",
				Required:    true,
			},
		},
	}
}

func (c *RankedBan) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to ban players from ranked.")
		return
	}

	opts := optionMap(i.ApplicationCommandData().Options)
	target := opts["player"].UserValue(s)
	durationInput := strings.TrimSpace(opts["duration"].StringValue())
	reason := strings.TrimSpace(opts["reason"].StringValue())

	rankedRole := shared.SettingOrEnv("RANKED_BAN_ROLE_ID")
	if rankedRole == "" {
		shared.RespondEphemeral(s, i, "RANKED_BAN_ROLE_ID is not configured.")
		return
	}
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	dur, err := parseBanDuration(durationInput)
	if err != nil || dur <= 0 {
		shared.RespondEphemeral(s, i, "Please provide a valid duration like 7d12h or 48h.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	registered := player != nil

	expiry := time.Now().Add(dur)
	if registered {
		if _, err := storage.CreatePunishment(ctx, player.ID, i.Member.User.ID, reason, storage.PunishmentTypeRankedBan, expiry); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to create punishment: %v", err))
			return
		}
	} else {
		log.Printf("rankedban: user %s is not registered; applying role only", target.ID)
	}

	_ = s.GuildMemberRoleAdd(i.GuildID, target.ID, rankedRole)
	notifyRankedBan(ctx, s, target.ID, i.Member.User.ID, reason, durationInput, expiry)

	content := fmt.Sprintf("%s has been banned from ranked for **%s**.", target.Mention(), reason)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}

func notifyRankedBan(ctx context.Context, s *discordgo.Session, userID, staffID, reason, duration string, expiry time.Time) {
	punishChannel, _ := storage.GetPunishmentsChannelID(ctx)
	supportChannel, _ := storage.GetSupportChannelID(ctx)
	logChannel, _ := storage.GetStaffPunishmentLogChannelID(ctx)
	expiryUnix := expiry.Unix()

	if punishChannel != "" {
		supportMention := "support"
		if strings.TrimSpace(supportChannel) != "" {
			supportMention = fmt.Sprintf("<#%s>", supportChannel)
		}
		desc := fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n**Duration:** %s (<t:%d:R>)\n\nIf you wish to appeal, open a ticket in %s.", userID, reason, duration, expiryUnix, supportMention)
		embed := &discordgo.MessageEmbed{
			Title:       "Ranked Ban",
			Description: desc,
			Color:       0xFF3643,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
				Files:   files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
			})
		}
	}

	if logChannel != "" {
		desc := fmt.Sprintf("<@%s> banned <@%s> from ranked.\nReason: `%s`\nDuration: %s\nExpires: <t:%d:F>", staffID, userID, reason, duration, expiryUnix)
		embed := &discordgo.MessageEmbed{
			Title:       "Ranked Ban Logged",
			Description: desc,
			Color:       0xFF3643,
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(logChannel, &discordgo.MessageSend{
				Embeds: []*discordgo.MessageEmbed{embed},
				Files:  files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
		}
	}
}

func parseBanDuration(input string) (time.Duration, error) {
	matches := banDurationRegex.FindAllStringSubmatch(strings.ToLower(input), -1)
	if len(matches) == 0 {
		return 0, fmt.Errorf("invalid duration")
	}
	var total time.Duration
	for _, m := range matches {
		value := m[1]
		unit := m[2]
		num, err := strconv.Atoi(value)
		if err != nil {
			return 0, err
		}
		switch unit {
		case "s":
			total += time.Duration(num) * time.Second
		case "m":
			total += time.Duration(num) * time.Minute
		case "h":
			total += time.Duration(num) * time.Hour
		case "d":
			total += time.Duration(num) * 24 * time.Hour
		case "w":
			total += time.Duration(num) * 7 * 24 * time.Hour
		}
	}
	return total, nil
}
