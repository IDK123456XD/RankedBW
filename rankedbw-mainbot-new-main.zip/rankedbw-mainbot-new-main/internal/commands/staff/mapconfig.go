package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type MapConfig struct{}

func NewMapConfig() *MapConfig { return &MapConfig{} }
func (c *MapConfig) Name() string {
	return "mapconfig"
}

func (c *MapConfig) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:                     c.Name(),
		Description:              "Manage queue maps (staff only).",
		DefaultMemberPermissions: &perm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Add or update a map.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "name",
						Description: "Map name.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionInteger,
						Name:        "height_limit",
						Description: "Height limit for the map.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove a map.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "name",
						Description: "Map name to remove.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List configured maps.",
			},
		},
	}
}

func (c *MapConfig) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if i == nil || len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	sub := i.ApplicationCommandData().Options[0]
	switch sub.Name {
	case "add":
		c.handleAdd(sess, i, sub)
	case "remove":
		c.handleRemove(sess, i, sub)
	case "list":
		c.handleList(sess, i)
	}
}

func (c *MapConfig) handleAdd(sess *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	var nameOpt, heightOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, o := range opt.Options {
		switch o.Name {
		case "name":
			nameOpt = o
		case "height_limit":
			heightOpt = o
		}
	}
	if nameOpt == nil || heightOpt == nil {
		shared.RespondEphemeral(sess, i, "Provide both name and height_limit.")
		return
	}
	name := strings.TrimSpace(nameOpt.StringValue())
	height := int(heightOpt.IntValue())
	if name == "" || height <= 0 {
		shared.RespondEphemeral(sess, i, "Name is required and height_limit must be positive.")
		return
	}

	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.UpsertMap(ctx, name, height); err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to save map: %v", err))
		return
	}
	msg := fmt.Sprintf("Saved map **%s** with height limit **%d**.", name, height)
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}

func (c *MapConfig) handleRemove(sess *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	name := strings.TrimSpace(opt.Options[0].StringValue())
	if name == "" {
		shared.RespondEphemeral(sess, i, "Provide a map name to remove.")
		return
	}
	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.DeleteMap(ctx, name); err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to delete map: %v", err))
		return
	}
	msg := fmt.Sprintf("Deleted map **%s** (if it existed).", name)
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}

func (c *MapConfig) handleList(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	list, err := storage.ListMaps(ctx)
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to load maps: %v", err))
		return
	}
	if len(list) == 0 {
		msg := "No maps configured."
		_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
		return
	}
	var lines []string
	for _, m := range list {
		lines = append(lines, fmt.Sprintf("• **%s** — height %d", strings.TrimSpace(m.Name), m.Height))
	}
	embed := &discordgo.MessageEmbed{
		Title:       "Configured Maps",
		Description: strings.Join(lines, "\n"),
		Color:       shared.DefaultEmbedColor,
	}
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{embed},
	})
}
