package staff

import (
	"bytes"
	"context"
	"fmt"
	"log"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/rolecommands"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Audit struct{}

func NewAudit() *Audit { return &Audit{} }
func (c *Audit) Name() string {
	return "audit"
}

func (c *Audit) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:                     c.Name(),
		Description:              "Audit members for registration, rank, and ELO nickname mismatches (admin).",
		DefaultMemberPermissions: &perm,
	}
}

func (c *Audit) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasAdminPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to run `/audit`.")
		return
	}
	if i == nil || i.GuildID == "" {
		shared.RespondEphemeral(s, i, "This command can only be used in a server.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	started := time.Now()

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to locate active season: %v", err))
		return
	}

	ranks, err := storage.ListRanks(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load rank configuration: %v", err))
		return
	}

	registerRoleID := strings.TrimSpace(shared.SettingOrEnv("REGISTER_RANK"))

	players, err := storage.AllPlayers(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load players from DB: %v", err))
		return
	}
	eloByPlayerID, err := storage.SeasonEloByPlayerID(ctx, seasonID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load season stats from DB: %v", err))
		return
	}

	playerByUserID := make(map[string]*storage.PlayerRecord, len(players))
	for idx := range players {
		p := &players[idx]
		if strings.TrimSpace(p.UserID) == "" {
			continue
		}
		playerByUserID[p.UserID] = p
	}

	rankRoleIDs := make(map[string]storage.RankRecord, len(ranks))
	for _, r := range ranks {
		if strings.TrimSpace(r.RoleID) == "" {
			continue
		}
		rankRoleIDs[strings.TrimSpace(r.RoleID)] = r
	}

	roleNames := map[string]string{}
	if roles, err := s.GuildRoles(i.GuildID); err == nil {
		roleNames = make(map[string]string, len(roles))
		for _, role := range roles {
			if role != nil && strings.TrimSpace(role.ID) != "" {
				roleNames[role.ID] = role.Name
			}
		}
	} else {
		log.Printf("audit: failed to fetch guild roles: %v", err)
	}

	members, err := rolecommands.FetchAllMembers(s, i.GuildID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch server members: %v", err))
		return
	}

	report := auditReport{
		guildID:                i.GuildID,
		seasonID:               seasonID,
		registerRoleID:         registerRoleID,
		ranks:                  ranks,
		rankRoleIDs:            rankRoleIDs,
		roleNames:              roleNames,
		membersTotal:           len(members),
		registerRoleConfigured: registerRoleID != "",
	}

	eloPrefix := regexp.MustCompile(`^\\[(\\d+)\\]\\s+`)
	for _, member := range members {
		report.scanMember(member, playerByUserID, eloByPlayerID, eloPrefix)
	}

	fileName := fmt.Sprintf("audit-%s-%s.txt", i.GuildID, time.Now().UTC().Format("20060102-150405"))
	content, summary := report.render(time.Since(started))

	file := &discordgo.File{
		Name:        fileName,
		ContentType: "text/plain",
		Reader:      bytes.NewReader([]byte(content)),
	}

	dmSent := false
	if i.Member != nil && i.Member.User != nil && strings.TrimSpace(i.Member.User.ID) != "" {
		if dm, err := s.UserChannelCreate(i.Member.User.ID); err == nil && dm != nil && dm.ID != "" {
			if _, err := s.ChannelMessageSendComplex(dm.ID, &discordgo.MessageSend{
				Content: summary,
				Files:   []*discordgo.File{file},
				AllowedMentions: &discordgo.MessageAllowedMentions{
					Parse: []discordgo.AllowedMentionType{},
				},
			}); err == nil {
				dmSent = true
			} else {
				log.Printf("audit: failed to DM report: %v", err)
			}
		} else if err != nil {
			log.Printf("audit: failed to open DM channel: %v", err)
		}
	}

	if dmSent {
		msg := "Audit complete. I sent you a DM with the report."
		_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
			Content: &msg,
			AllowedMentions: &discordgo.MessageAllowedMentions{
				Parse: []discordgo.AllowedMentionType{},
			},
		})
		return
	}

	msg := "Audit complete, but I could not DM you (privacy settings?). Attaching the report here (ephemeral)."
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content: &msg,
		Files:   []*discordgo.File{file},
		AllowedMentions: &discordgo.MessageAllowedMentions{
			Parse: []discordgo.AllowedMentionType{},
		},
	})
}

type auditReport struct {
	guildID  string
	seasonID string

	registerRoleID         string
	registerRoleConfigured bool

	ranks       []storage.RankRecord
	rankRoleIDs map[string]storage.RankRecord
	roleNames   map[string]string

	membersTotal   int
	membersScanned int
	botsSkipped    int

	rankButNotRegistered []string
	wrongRankRole        []string
	missingRankRole      []string
	multipleRankRoles    []string
	eloNickMismatch      []string
	eloNickNotRegistered []string
	missingSeasonStats   []string
}

func (r *auditReport) scanMember(member *discordgo.Member, playerByUserID map[string]*storage.PlayerRecord, eloByPlayerID map[string]int, eloPrefix *regexp.Regexp) {
	if member == nil || member.User == nil {
		return
	}
	if member.User.Bot {
		r.botsSkipped++
		return
	}
	r.membersScanned++

	userID := strings.TrimSpace(member.User.ID)
	if userID == "" {
		return
	}

	display := member.Nick
	if strings.TrimSpace(display) == "" {
		display = member.User.Username
	}

	currentNickElo, hasNickElo := parseNickElo(display, eloPrefix)

	currentRankRoles := r.memberRankRoles(member)

	player := playerByUserID[userID]
	if player == nil {
		if hasNickElo {
			r.eloNickNotRegistered = append(r.eloNickNotRegistered, fmt.Sprintf("<@%s> | nickElo=%d | name=%q", userID, currentNickElo, display))
		}
		if len(currentRankRoles) > 0 {
			r.rankButNotRegistered = append(r.rankButNotRegistered, fmt.Sprintf("<@%s> | rankRoles=%s | name=%q", userID, strings.Join(currentRankRoles, ", "), display))
		}
		return
	}

	elo, ok := eloByPlayerID[player.ID]
	if !ok {
		r.missingSeasonStats = append(r.missingSeasonStats, fmt.Sprintf("<@%s> | playerId=%s | name=%q", userID, player.ID, display))
		elo = 0
	}

	expected := rankForElo(r.ranks, elo)

	switch {
	case expected == nil:
		// No configured bracket for this ELO.
	case len(currentRankRoles) == 0:
		if expected != nil {
			r.missingRankRole = append(r.missingRankRole, fmt.Sprintf("<@%s> | elo=%d | expected=%s | name=%q", userID, elo, r.rankLabel(expected), display))
		}
	case len(currentRankRoles) > 1:
		r.multipleRankRoles = append(r.multipleRankRoles, fmt.Sprintf("<@%s> | elo=%d | expected=%s | has=%s | name=%q", userID, elo, r.rankLabel(expected), strings.Join(currentRankRoles, ", "), display))
	default:
		if expected != nil {
			hasRoleID := r.extractRankRoleID(member)
			if strings.TrimSpace(hasRoleID) != "" && strings.TrimSpace(expected.RoleID) != "" && hasRoleID != expected.RoleID {
				r.wrongRankRole = append(r.wrongRankRole, fmt.Sprintf("<@%s> | elo=%d | expected=%s | has=%s | name=%q", userID, elo, r.rankLabel(expected), currentRankRoles[0], display))
			}
		}
	}

	if hasNickElo && ok && currentNickElo != elo {
		r.eloNickMismatch = append(r.eloNickMismatch, fmt.Sprintf("<@%s> | nickElo=%d | dbElo=%d | name=%q", userID, currentNickElo, elo, display))
	}
}

func (r *auditReport) memberRankRoles(member *discordgo.Member) []string {
	if member == nil {
		return nil
	}
	var out []string
	for _, rid := range member.Roles {
		rid = strings.TrimSpace(rid)
		if rid == "" {
			continue
		}
		if _, ok := r.rankRoleIDs[rid]; !ok {
			continue
		}
		out = append(out, r.roleName(rid))
	}
	sort.Strings(out)
	return out
}

func (r *auditReport) extractRankRoleID(member *discordgo.Member) string {
	if member == nil {
		return ""
	}
	for _, rid := range member.Roles {
		rid = strings.TrimSpace(rid)
		if rid == "" {
			continue
		}
		if _, ok := r.rankRoleIDs[rid]; ok {
			return rid
		}
	}
	return ""
}

func (r *auditReport) roleName(roleID string) string {
	roleID = strings.TrimSpace(roleID)
	if roleID == "" {
		return ""
	}
	if name := strings.TrimSpace(r.roleNames[roleID]); name != "" {
		return name
	}
	return roleID
}

func (r *auditReport) rankLabel(rank *storage.RankRecord) string {
	if rank == nil {
		return ""
	}
	roleName := r.roleName(rank.RoleID)
	if roleName != "" && strings.TrimSpace(rank.Name) != "" && roleName != strings.TrimSpace(rank.Name) {
		return fmt.Sprintf("%s (%d-%d) -> %s", strings.TrimSpace(rank.Name), rank.Min, rank.Max, roleName)
	}
	if roleName != "" && strings.TrimSpace(rank.Name) == "" {
		return fmt.Sprintf("%s (%d-%d)", roleName, rank.Min, rank.Max)
	}
	return fmt.Sprintf("%s (%d-%d)", strings.TrimSpace(rank.Name), rank.Min, rank.Max)
}

func parseNickElo(name string, re *regexp.Regexp) (int, bool) {
	name = strings.TrimSpace(name)
	if name == "" || re == nil {
		return 0, false
	}
	m := re.FindStringSubmatch(name)
	if len(m) < 2 {
		return 0, false
	}
	n, err := strconv.Atoi(m[1])
	if err != nil {
		return 0, false
	}
	return n, true
}

func rankForElo(ranks []storage.RankRecord, elo int) *storage.RankRecord {
	for idx := range ranks {
		r := &ranks[idx]
		if elo >= r.Min && elo <= r.Max {
			return r
		}
	}
	return nil
}

func (r *auditReport) render(duration time.Duration) (string, string) {
	duration = duration.Round(time.Second)

	var buf strings.Builder
	buf.WriteString(fmt.Sprintf("RBW Audit Report\nGuild: %s\nSeason: %s\nDuration: %s\n\n", r.guildID, r.seasonID, duration))
	buf.WriteString(fmt.Sprintf("Members fetched: %d\nMembers scanned: %d\nBots skipped: %d\n\n", r.membersTotal, r.membersScanned, r.botsSkipped))
	buf.WriteString(fmt.Sprintf("Rank brackets configured: %d\nRegister role configured: %v\n\n", len(r.ranks), r.registerRoleConfigured))

	writeSection := func(title string, lines []string) {
		buf.WriteString(title)
		buf.WriteString(fmt.Sprintf(" (%d)\n", len(lines)))
		if len(lines) == 0 {
			buf.WriteString("\n")
			return
		}
		for _, line := range lines {
			buf.WriteString("- ")
			buf.WriteString(line)
			buf.WriteString("\n")
		}
		buf.WriteString("\n")
	}

	writeSection("Rank role but NOT registered", r.rankButNotRegistered)
	writeSection("Registered but WRONG rank role", r.wrongRankRole)
	writeSection("Registered but MISSING rank role", r.missingRankRole)
	writeSection("Registered with MULTIPLE rank roles", r.multipleRankRoles)
	writeSection("ELO nickname mismatch (registered)", r.eloNickMismatch)
	writeSection("ELO nickname present but NOT registered", r.eloNickNotRegistered)
	writeSection("Registered but missing active-season stats row", r.missingSeasonStats)

	summary := fmt.Sprintf(
		"Audit complete in %s.\nRank-not-registered: %d\nWrong-rank: %d\nMissing-rank: %d\nMulti-rank: %d\nELO-nick mismatch: %d\nELO-nick but not registered: %d\nMissing season stats: %d\n",
		duration,
		len(r.rankButNotRegistered),
		len(r.wrongRankRole),
		len(r.missingRankRole),
		len(r.multipleRankRoles),
		len(r.eloNickMismatch),
		len(r.eloNickNotRegistered),
		len(r.missingSeasonStats),
	)

	return buf.String(), summary
}
