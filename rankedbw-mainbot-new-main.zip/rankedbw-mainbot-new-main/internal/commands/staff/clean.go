package staff

import (
	"fmt"
	"strings"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/discordutil"

	"github.com/bwmarrin/discordgo"
)

type Clean struct{}

func NewClean() *Clean        { return &Clean{} }
func (c *Clean) Name() string { return "clean" }
func (c *Clean) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Delete voice channels with \"Game\" in the name under a category.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Name:         "category",
				Description:  "Category to clean.",
				Type:         discordgo.ApplicationCommandOptionChannel,
				Required:     true,
				ChannelTypes: []discordgo.ChannelType{discordgo.ChannelTypeGuildCategory},
			},
		},
		DefaultMemberPermissions: &perm,
	}
}

func (c *Clean) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if i.GuildID == "" {
		shared.RespondEphemeral(s, i, "This command can only be used in a guild.")
		return
	}

	opt := i.ApplicationCommandData().Options[0]
	cat := opt.ChannelValue(s)
	if cat == nil || cat.Type != discordgo.ChannelTypeGuildCategory {
		shared.RespondEphemeral(s, i, "Please select a valid category.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	channels, err := s.GuildChannels(i.GuildID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load channels: %v", err))
		return
	}

	var removed, skipped []string
	waiting := shared.WaitingRoomID()
	for _, ch := range channels {
		if ch == nil || ch.Type != discordgo.ChannelTypeGuildVoice {
			continue
		}
		if ch.ParentID != cat.ID {
			continue
		}
		if !strings.Contains(strings.ToLower(ch.Name), "game") {
			continue
		}

		task := discordutil.DeleteTask{
			ChannelID:     ch.ID,
			GuildID:       i.GuildID,
			MoveMembersTo: waiting,
			Hide:          true,
			Reason:        "clean command",
		}
		if discordutil.EnqueueDelete(task) {
			removed = append(removed, fmt.Sprintf("`%s` (queued)", ch.Name))
			continue
		}
		if _, err := s.ChannelDelete(ch.ID); err != nil {
			skipped = append(skipped, fmt.Sprintf("<#%s>: %v", ch.ID, err))
			continue
		}
		removed = append(removed, fmt.Sprintf("`%s`", ch.Name))
	}

	var msg strings.Builder
	msg.WriteString(fmt.Sprintf("Removed %d voice channel(s) in <#%s> with \"Game\" in the name.", len(removed), cat.ID))
	if len(skipped) > 0 {
		msg.WriteString("\nFailed to remove:")
		for _, entry := range skipped {
			msg.WriteString("\n- ")
			msg.WriteString(entry)
		}
	}

	content := msg.String()
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}
