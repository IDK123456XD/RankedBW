package staff

import (
	"context"
	"log"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

func refreshNicknamesFromScore(ctx context.Context, sess *discordgo.Session, guildID string, updates []storage.ScoreUpdate, source string) {
	if sess == nil || guildID == "" || len(updates) == 0 {
		return
	}
	for _, upd := range updates {
		if upd.SkipStats {
			continue
		}
		player, err := storage.GetPlayerByID(ctx, upd.PlayerID)
		if err != nil {
			log.Printf("%s: failed to load player %s: %v", source, upd.PlayerID, err)
			continue
		}
		if player == nil {
			continue
		}
		stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, upd.SeasonID)
		if err != nil {
			log.Printf("%s: failed to load stats for %s: %v", source, player.ID, err)
			continue
		}
		if stats == nil {
			continue
		}
		shared.ApplyNickname(sess, guildID, player, stats, source)
		_ = shared.ApplyRankRole(sess, guildID, player.UserID, stats.Elo, source)
	}
}

func refreshNicknamesFromUnscore(ctx context.Context, sess *discordgo.Session, guildID string, updates []storage.UnscoreUpdate, source string) {
	if sess == nil || guildID == "" || len(updates) == 0 {
		return
	}
	for _, upd := range updates {
		if upd.SkipStats {
			continue
		}
		player, err := storage.GetPlayerByID(ctx, upd.PlayerID)
		if err != nil {
			log.Printf("%s: failed to load player %s: %v", source, upd.PlayerID, err)
			continue
		}
		if player == nil {
			continue
		}
		stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, upd.SeasonID)
		if err != nil {
			log.Printf("%s: failed to load stats for %s: %v", source, player.ID, err)
			continue
		}
		if stats == nil {
			continue
		}
		shared.ApplyNickname(sess, guildID, player, stats, source)
		_ = shared.ApplyRankRole(sess, guildID, player.UserID, stats.Elo, source)
	}
}
