package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type ResetStats struct{}

func NewResetStats() *ResetStats   { return &ResetStats{} }
func (c *ResetStats) Name() string { return "resetstats" }
func (c *ResetStats) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Reset a player's stats.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "player",
				Description: "Player to reset.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for the reset.",
			},
		},
	}
}

func (c *ResetStats) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to reset player stats.")
		return
	}

	target := i.ApplicationCommandData().Options[0].UserValue(s)
	reason := ""
	if len(i.ApplicationCommandData().Options) > 1 {
		reason = strings.TrimSpace(i.ApplicationCommandData().Options[1].StringValue())
	}

	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "That player is not registered.")
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to find active season: %v", err))
		return
	}
	if err := storage.EnsurePlayerSeasonStats(ctx, player.ID, seasonID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to prepare stats: %v", err))
		return
	}
	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil || stats == nil {
		shared.EditError(s, i, "Unable to load stats for that player.")
		return
	}

	if err := storage.ResetPlayerSeasonStats(ctx, stats.ID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to reset stats: %v", err))
		return
	}

	stats.Elo = 0
	shared.ApplyNickname(s, i.GuildID, player, stats, "resetstats")

	logChannel, _ := storage.GetLogChannelID(ctx)
	if logChannel != "" {
		desc := fmt.Sprintf("<@%s> reset <@%s>'s stats. Reason: `%s`", i.Member.User.ID, target.ID, reason)
		embed := &discordgo.MessageEmbed{
			Title:       "Stats Reset",
			Description: desc,
			Color:       0x9B59B6,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
	}

	content := fmt.Sprintf("%s's stats have been reset.", target.Mention())
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}
