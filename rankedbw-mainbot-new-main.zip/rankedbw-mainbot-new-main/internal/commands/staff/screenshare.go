package staff

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"math/rand"
	"os"
	"strings"
	"sync"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"
	"rbw-bot/internal/transcripts"

	"github.com/bwmarrin/discordgo"
)

const (
	ssFreezeButtonPrefix = "ss_freeze:"
	ssCloseButtonPrefix  = "ss_close:"
)

type ssTicket struct {
	TargetID    string
	RequesterID string
	MessageID   string
	LogChannel  string
	Reason      string
	TargetName  string
	ProofURL    string
	RequestedAt time.Time
	TakenBy     string
	timer       *time.Timer
}

// Screenshare handles /ss and the Freeze/Close buttons.
type Screenshare struct {
	mu      sync.Mutex
	tickets map[string]*ssTicket
	active  map[string]string // requesterID -> channelID
	rng     *rand.Rand
	session *discordgo.Session
	sessMu  sync.RWMutex
	booted  bool
}

func NewScreenshare() *Screenshare {
	s := &Screenshare{
		tickets: make(map[string]*ssTicket),
		active:  make(map[string]string),
		rng:     rand.New(rand.NewSource(time.Now().UnixNano())),
	}
	go s.ssWatcherLoop()
	return s
}

func (s *Screenshare) Name() string { return "ss" }

func (s *Screenshare) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        s.Name(),
		Description: "Create a screenshare request ticket.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "user",
				Description: "User being screenshared.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for the screenshare.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionAttachment,
				Name:        "image",
				Description: "Evidence/screenshot to attach.",
				Required:    true,
			},
		},
	}
}

// Handle creates the ticket channel and posts the request message with buttons.
func (s *Screenshare) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	s.SetSession(sess)
	if i.Member == nil || i.Member.User == nil || i.GuildID == "" {
		shared.RespondEphemeral(sess, i, "This command must be used inside a guild.")
		return
	}
	isStaff := hasStaffPermission(i)

	var userOpt, reasonOpt, imageOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "user":
			userOpt = opt
		case "reason":
			reasonOpt = opt
		case "image":
			imageOpt = opt
		}
	}
	if userOpt == nil || reasonOpt == nil {
		shared.RespondEphemeral(sess, i, "User, reason, and a screenshot are required.")
		return
	}

	targetUser := userOpt.UserValue(sess)
	if targetUser == nil {
		shared.RespondEphemeral(sess, i, "Unable to resolve the selected user.")
		return
	}
	reason := strings.TrimSpace(reasonOpt.StringValue())
	if reason == "" {
		shared.RespondEphemeral(sess, i, "Reason cannot be empty.")
		return
	}
	attachment := resolveAttachment(i, attachmentID(imageOpt))
	if attachment == nil {
		shared.RespondEphemeral(sess, i, "Attach a screenshot to continue.")
		return
	}

	categoryID := strings.TrimSpace(shared.SettingOrEnv("SCREEN_SHARE_CATEGORY"))
	screensharerRoleID := strings.TrimSpace(shared.SettingOrEnv("SCREENSHARER_ROLE_ID"))
	frozenRoleID := strings.TrimSpace(shared.SettingOrEnv("FROZEN_ROLE_ID"))
	logChannelID := strings.TrimSpace(shared.SettingOrEnv("SCREENSHARE_LOGS_CHANNEL"))
	switch {
	case categoryID == "":
		shared.RespondEphemeral(sess, i, "screen_share_category is not configured. Set it with /settings setchannel.")
		return
	case screensharerRoleID == "":
		shared.RespondEphemeral(sess, i, "screensharer_role_id is not configured. Set it with /settings addrole.")
		return
	case frozenRoleID == "":
		shared.RespondEphemeral(sess, i, "frozen_role_id is not configured. Set it with /settings addrole.")
		return
	}

	if !isStaff && s.hasActiveTicket(i.Member.User.ID) {
		shared.RespondEphemeral(sess, i, "You already have an active screenshare ticket. Please close it before opening another.")
		return
	}

	name := s.channelName(targetUser.Username)
	topic := fmt.Sprintf("Screenshare for %s requested by %s | targetID:%s requesterID:%s", formatMention(targetUser.ID), formatMention(i.Member.User.ID), targetUser.ID, i.Member.User.ID)
	var allowPerms int64 = discordgo.PermissionViewChannel | discordgo.PermissionSendMessages | discordgo.PermissionReadMessageHistory | discordgo.PermissionAttachFiles
	channel, err := sess.GuildChannelCreateComplex(i.GuildID, discordgo.GuildChannelCreateData{
		Name:     name,
		Type:     discordgo.ChannelTypeGuildText,
		ParentID: categoryID,
		Topic:    topic,
		PermissionOverwrites: []*discordgo.PermissionOverwrite{
			{
				ID:    i.GuildID, // @everyone
				Type:  discordgo.PermissionOverwriteTypeRole,
				Deny:  discordgo.PermissionViewChannel,
				Allow: 0,
			},
			{
				ID:    screensharerRoleID,
				Type:  discordgo.PermissionOverwriteTypeRole,
				Allow: allowPerms,
			},
			{
				ID:    targetUser.ID,
				Type:  discordgo.PermissionOverwriteTypeMember,
				Allow: allowPerms,
			},
			{
				ID:    i.Member.User.ID,
				Type:  discordgo.PermissionOverwriteTypeMember,
				Allow: allowPerms,
			},
		},
	})
	if err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to create ticket: %v", err))
		return
	}

	content := fmt.Sprintf("<@%s>, you have been screenshare requested by <@%s> with the reason: %s\nA <@&%s> will guide you through this process. If one doesn't show up within 10 minutes then this channel will automatically close and you will be free to go.\nImage submitted:", targetUser.ID, i.Member.User.ID, reason, screensharerRoleID)
	msg := &discordgo.MessageSend{
		Content: content,
		AllowedMentions: &discordgo.MessageAllowedMentions{
			Users: uniqueStringSlice([]string{targetUser.ID, i.Member.User.ID}),
			Roles: []string{screensharerRoleID},
		},
		Components: []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					plainButton{CustomID: ssFreezeButtonPrefix + targetUser.ID + ":" + i.Member.User.ID, Label: "Freeze", Style: discordgo.PrimaryButton},
					plainButton{CustomID: ssCloseButtonPrefix + targetUser.ID + ":" + i.Member.User.ID, Label: "Close", Style: discordgo.DangerButton},
				},
			},
		},
	}
	if attachment != nil {
		msg.Embeds = []*discordgo.MessageEmbed{
			{
				Title: "Submitted image",
				Image: &discordgo.MessageEmbedImage{URL: attachment.URL},
			},
		}
	}

	sent, err := sess.ChannelMessageSendComplex(channel.ID, msg)
	if err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Ticket created, but failed to send message: %v", err))
		return
	}

	requestedAt := time.Now().UTC()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.CreateScreenshareRecord(ctx, i.Member.User.ID, targetUser.ID, channel.ID, requestedAt, attachment.URL); err != nil {
		fmt.Printf("ss: failed to record request: %v\n", err)
	}

	shared.RespondEphemeral(sess, i, fmt.Sprintf("Screenshare ticket created: <#%s>.", channel.ID))
	s.startExpiryTimer(sess, channel.ID, &ssTicket{
		TargetID:    targetUser.ID,
		RequesterID: i.Member.User.ID,
		MessageID:   sent.ID,
		LogChannel:  logChannelID,
		Reason:      reason,
		TargetName:  targetUser.Username,
		ProofURL:    attachment.URL,
		RequestedAt: requestedAt,
	})
	s.logScreenshareRequest(sess, "OPEN", reason, "", i.Member.User.ID, targetUser.ID, targetUser.Username, channel.ID, "")
	s.sendScreenshareInstructions(sess, i.GuildID, channel.ID, targetUser)
}

// HandleComponent processes Freeze and Close button clicks.
func (s *Screenshare) HandleComponent(sess *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if i.Type != discordgo.InteractionMessageComponent {
		return false
	}
	s.SetSession(sess)
	data := i.MessageComponentData()
	switch {
	case strings.HasPrefix(data.CustomID, ssFreezeButtonPrefix):
		s.handleFreezeButton(sess, i, data.CustomID)
		return true
	case strings.HasPrefix(data.CustomID, ssCloseButtonPrefix):
		s.handleCloseButton(sess, i, data.CustomID)
		return true
	default:
		return false
	}
}

// FreezeCmd exposes /freeze to assign the Frozen role.
type FreezeCmd struct{}

func NewFreezeCmd() *FreezeCmd    { return &FreezeCmd{} }
func (c *FreezeCmd) Name() string { return "freeze" }
func (c *FreezeCmd) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Assign the configured Frozen role to a user.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "user",
				Description: "User to freeze.",
				Required:    true,
			},
		},
	}
}

func (c *FreezeCmd) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasScreensharerPermission(i) {
		shared.RespondEphemeral(sess, i, "You do not have the @Screensharer role.")
		return
	}
	if i.Member == nil || i.Member.User == nil || i.GuildID == "" {
		shared.RespondEphemeral(sess, i, "This command must be used inside a guild.")
		return
	}
	if len(i.ApplicationCommandData().Options) == 0 {
		shared.RespondEphemeral(sess, i, "Select a user to freeze.")
		return
	}
	target := i.ApplicationCommandData().Options[0].UserValue(sess)
	if target == nil {
		shared.RespondEphemeral(sess, i, "Unable to resolve the selected user.")
		return
	}
	frozenRole := strings.TrimSpace(shared.SettingOrEnv("FROZEN_ROLE_ID"))
	if frozenRole == "" {
		shared.RespondEphemeral(sess, i, "frozen_role_id is not configured. Set it with /settings addrole.")
		return
	}

	if err := sess.GuildMemberRoleAdd(i.GuildID, target.ID, frozenRole); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to assign Frozen role: %v", err))
		return
	}
	shared.RespondEphemeral(sess, i, fmt.Sprintf("You have frozen <@%s>.", target.ID))
}

// UnfreezeCmd exposes /unfreeze to remove the Frozen role.
type UnfreezeCmd struct{}

func NewUnfreezeCmd() *UnfreezeCmd  { return &UnfreezeCmd{} }
func (c *UnfreezeCmd) Name() string { return "unfreeze" }
func (c *UnfreezeCmd) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Remove the configured Frozen role from a user.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "user",
				Description: "User to unfreeze.",
				Required:    true,
			},
		},
	}
}

func (c *UnfreezeCmd) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasScreensharerPermission(i) {
		shared.RespondEphemeral(sess, i, "You do not have the @Screensharer role.")
		return
	}
	if i.Member == nil || i.Member.User == nil || i.GuildID == "" {
		shared.RespondEphemeral(sess, i, "This command must be used inside a guild.")
		return
	}
	if len(i.ApplicationCommandData().Options) == 0 {
		shared.RespondEphemeral(sess, i, "Select a user to unfreeze.")
		return
	}
	target := i.ApplicationCommandData().Options[0].UserValue(sess)
	if target == nil {
		shared.RespondEphemeral(sess, i, "Unable to resolve the selected user.")
		return
	}
	frozenRole := strings.TrimSpace(shared.SettingOrEnv("FROZEN_ROLE_ID"))
	if frozenRole == "" {
		shared.RespondEphemeral(sess, i, "frozen_role_id is not configured. Set it with /settings addrole.")
		return
	}

	if err := sess.GuildMemberRoleRemove(i.GuildID, target.ID, frozenRole); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to remove Frozen role: %v", err))
		return
	}
	shared.RespondEphemeral(sess, i, fmt.Sprintf("You have unfrozen <@%s>.", target.ID))
}

// SSCloseCmd closes a screenshare channel with a reason.
type SSCloseCmd struct {
	manager *Screenshare
}

func NewSSCloseCmd(manager *Screenshare) *SSCloseCmd { return &SSCloseCmd{manager: manager} }
func (c *SSCloseCmd) Name() string                   { return "ssclose" }
func (c *SSCloseCmd) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Close a screenshare ticket with a reason.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for closing.",
				Required:    false,
			},
		},
	}
}

func (c *SSCloseCmd) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if !canManageScreenshare(i) {
		shared.RespondEphemeral(sess, i, "You do not have permission to close screenshare tickets.")
		return
	}
	if i.GuildID == "" {
		shared.RespondEphemeral(sess, i, "This command must be used inside a guild.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	isTicket, err := storage.ScreenshareChannelExists(ctx, i.ChannelID)
	cancel()
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to validate channel: %v", err))
		return
	}
	if !isTicket {
		shared.RespondEphemeral(sess, i, "This channel is not a screenshare ticket.")
		return
	}
	reason := "No reason provided."
	if len(i.ApplicationCommandData().Options) > 0 {
		reasonVal := strings.TrimSpace(i.ApplicationCommandData().Options[0].StringValue())
		if reasonVal != "" {
			reason = reasonVal
		}
	}

	targetID, requesterID := c.manager.idsForChannel(sess, i.ChannelID)
	logChannel := strings.TrimSpace(shared.SettingOrEnv("SCREENSHARE_LOGS_CHANNEL"))

	shared.RespondEphemeral(sess, i, "Closing screenshare ticket.")
	c.manager.finishClose(sess, i.ChannelID, reason, i.Member.User.ID, targetID, requesterID, logChannel)
}

// --- Internal helpers ---

func (s *Screenshare) handleFreezeButton(sess *discordgo.Session, i *discordgo.InteractionCreate, cid string) {
	if !hasScreensharerPermission(i) {
		shared.RespondEphemeral(sess, i, "You do not have the @Screensharer role.")
		return
	}
	targetID, requesterID := parseIDs(cid)
	if targetID == "" {
		targetID, requesterID = s.idsForChannel(sess, i.ChannelID)
	}
	if targetID == "" {
		shared.RespondEphemeral(sess, i, "Could not determine which user to freeze.")
		return
	}
	frozenRole := strings.TrimSpace(shared.SettingOrEnv("FROZEN_ROLE_ID"))
	if frozenRole == "" {
		shared.RespondEphemeral(sess, i, "frozen_role_id is not configured. Set it with /settings addrole.")
		return
	}
	if err := sess.GuildMemberRoleAdd(i.GuildID, targetID, frozenRole); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to assign Frozen role: %v", err))
		return
	}
	s.stopTimer(i.ChannelID)
	shared.RespondEphemeral(sess, i, fmt.Sprintf("You have frozen <@%s>.", targetID))
	if ticket := s.ticket(i.ChannelID); ticket != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		if err := storage.MarkScreenshareTaken(ctx, ticket.RequesterID, ticket.TargetID, ticket.RequestedAt, i.Member.User.ID); err != nil {
			fmt.Printf("ss: failed to mark request taken for channel %s: %v\n", i.ChannelID, err)
		}
		cancel()
		s.updateTicket(i.ChannelID, func(t *ssTicket) {
			t.TakenBy = i.Member.User.ID
		})
	}
	// Keep requester info for logging.
	if requesterID != "" {
		s.ensureTicket(i.ChannelID, targetID, requesterID, strings.TrimSpace(shared.SettingOrEnv("SCREENSHARE_LOGS_CHANNEL")))
	}
}

func (s *Screenshare) handleCloseButton(sess *discordgo.Session, i *discordgo.InteractionCreate, cid string) {
	if !canManageScreenshare(i) {
		shared.RespondEphemeral(sess, i, "You do not have permission to close this ticket.")
		return
	}
	targetID, requesterID := parseIDs(cid)
	if targetID == "" {
		targetID, requesterID = s.idsForChannel(sess, i.ChannelID)
	}
	logChannel := strings.TrimSpace(shared.SettingOrEnv("SCREENSHARE_LOGS_CHANNEL"))
	shared.RespondEphemeral(sess, i, "Closing screenshare ticket.")
	s.finishClose(sess, i.ChannelID, "Closed via button", i.Member.User.ID, targetID, requesterID, logChannel)
}

func (s *Screenshare) startExpiryTimer(sess *discordgo.Session, channelID string, ticket *ssTicket) {
	if ticket == nil {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if existing, ok := s.tickets[channelID]; ok && existing.timer != nil {
		existing.timer.Stop()
	}
	tCopy := *ticket
	tCopy.timer = time.AfterFunc(10*time.Minute, func() {
		s.expireTicket(sess, channelID)
	})
	s.tickets[channelID] = &tCopy
	if ticket.RequesterID != "" {
		s.active[ticket.RequesterID] = channelID
	}
}

func (s *Screenshare) stopTimer(channelID string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if t, ok := s.tickets[channelID]; ok && t != nil && t.timer != nil {
		t.timer.Stop()
		t.timer = nil
	}
}

func (s *Screenshare) expireTicket(sess *discordgo.Session, channelID string) {
	ticket := s.ticket(channelID)
	targetID, requesterID := s.idsForChannel(sess, channelID)
	guildID := ""
	if ch, err := sess.Channel(channelID); err == nil && ch != nil {
		guildID = ch.GuildID
	}
	var proofURL string
	if ticket != nil {
		proofURL = ticket.ProofURL
	}
	target := targetID
	requester := requesterID
	takenBy := ""
	if ticket != nil {
		if ticket.TargetID != "" {
			target = ticket.TargetID
		}
		if ticket.RequesterID != "" {
			requester = ticket.RequesterID
		}
		takenBy = ticket.TakenBy
	}
	transcriptLink, txErr := s.captureAndSendSSTranscript(sess, guildID, channelID, proofURL, target, requester, takenBy)
	if txErr != nil {
		fmt.Printf("ss: failed to capture transcript for channel %s: %v\n", channelID, txErr)
	}
	content := "No Screensharer responded within 10 minutes. Closing this channel."
	_, _ = sess.ChannelMessageSend(channelID, content)
	if ticket != nil {
		s.logScreenshareRequest(sess, "EXPIRED", ticket.Reason, "No Screensharer responded within 10 minutes.", ticket.RequesterID, ticket.TargetID, ticket.TargetName, channelID, transcriptLink)
	}
	{
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		if err := storage.MarkScreenshareFinishedByChannel(ctx, channelID); err != nil {
			fmt.Printf("ss: failed to mark request finished for channel %s: %v\n", channelID, err)
		}
		cancel()
	}
	s.maybeUnfreeze(sess, guildID, target)
	_, _ = sess.ChannelDelete(channelID)
	s.removeTicket(channelID)
}

func (s *Screenshare) finishClose(sess *discordgo.Session, channelID, reason, closedBy, targetID, requesterID, logChannel string) {
	s.stopTimer(channelID)
	if targetID == "" || requesterID == "" {
		targetID, requesterID = s.idsForChannel(sess, channelID)
	}
	guildID := ""
	if ch, err := sess.Channel(channelID); err == nil && ch != nil {
		guildID = ch.GuildID
	}
	var proofURL, target, requester, takenBy string
	if ticket := s.ticket(channelID); ticket != nil {
		proofURL = ticket.ProofURL
		if ticket.TargetID != "" {
			target = ticket.TargetID
		}
		if ticket.RequesterID != "" {
			requester = ticket.RequesterID
		}
		takenBy = ticket.TakenBy
	}
	if target == "" {
		target = targetID
	}
	if requester == "" {
		requester = requesterID
	}
	transcriptLink, txErr := s.captureAndSendSSTranscript(sess, guildID, channelID, proofURL, target, requester, takenBy)
	if txErr != nil {
		fmt.Printf("ss: failed to capture transcript for channel %s: %v\n", channelID, txErr)
	}
	if logChannel == "" {
		logChannel = strings.TrimSpace(shared.SettingOrEnv("SCREENSHARE_LOGS_CHANNEL"))
	}
	if ticket := s.ticket(channelID); ticket != nil && strings.TrimSpace(ticket.LogChannel) != "" {
		logChannel = strings.TrimSpace(ticket.LogChannel)
	}
	s.maybeUnfreeze(sess, guildID, target)
	if ticket := s.ticket(channelID); ticket != nil {
		note := fmt.Sprintf("Closed by %s: %s", formatMention(closedBy), reason)
		s.logScreenshareRequest(sess, "CLOSED", ticket.Reason, note, ticket.RequesterID, ticket.TargetID, ticket.TargetName, channelID, transcriptLink)
	}
	{
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		if err := storage.MarkScreenshareFinishedByChannel(ctx, channelID); err != nil {
			fmt.Printf("ss: failed to mark request finished for channel %s: %v\n", channelID, err)
		}
		cancel()
	}
	_, _ = sess.ChannelDelete(channelID)
	s.removeTicket(channelID)
}

func (s *Screenshare) maybeUnfreeze(sess *discordgo.Session, guildID string, targetID string) {
	if sess == nil || guildID == "" || strings.TrimSpace(targetID) == "" {
		return
	}
	frozenRole := strings.TrimSpace(shared.SettingOrEnv("FROZEN_ROLE_ID"))
	if frozenRole == "" {
		return
	}
	_ = sess.GuildMemberRoleRemove(guildID, targetID, frozenRole)
}

func (s *Screenshare) removeTicket(channelID string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if t, ok := s.tickets[channelID]; ok && t != nil {
		if t.RequesterID != "" {
			delete(s.active, t.RequesterID)
		}
	}
	delete(s.tickets, channelID)
}

func (s *Screenshare) ensureTicket(channelID, targetID, requesterID, logChannel string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.tickets[channelID]; ok {
		return
	}
	s.tickets[channelID] = &ssTicket{
		TargetID:    targetID,
		RequesterID: requesterID,
		LogChannel:  logChannel,
	}
	if requesterID != "" {
		s.active[requesterID] = channelID
	}
}

func (s *Screenshare) ticket(channelID string) *ssTicket {
	s.mu.Lock()
	defer s.mu.Unlock()
	if t, ok := s.tickets[channelID]; ok && t != nil {
		copy := *t
		return &copy
	}
	return nil
}

func (s *Screenshare) idsForChannel(sess *discordgo.Session, channelID string) (targetID, requesterID string) {
	s.mu.Lock()
	if t, ok := s.tickets[channelID]; ok && t != nil {
		targetID = t.TargetID
		requesterID = t.RequesterID
	}
	s.mu.Unlock()
	if targetID != "" || requesterID != "" {
		return
	}
	ch, err := sess.Channel(channelID)
	if err != nil || ch == nil {
		return
	}
	targetID, requesterID = parseTopic(ch.Topic)
	return
}

func (s *Screenshare) hasActiveTicket(requesterID string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	_, ok := s.active[requesterID]
	return ok
}

func (s *Screenshare) channelName(base string) string {
	base = strings.ToLower(strings.TrimSpace(base))
	var b strings.Builder
	for _, r := range base {
		switch {
		case r >= 'a' && r <= 'z':
			b.WriteRune(r)
		case r >= '0' && r <= '9':
			b.WriteRune(r)
		case r == ' ' || r == '-' || r == '_':
			b.WriteRune('-')
		}
		if b.Len() >= 20 {
			break
		}
	}
	name := strings.Trim(b.String(), "-")
	if name == "" {
		name = "player"
	}
	return fmt.Sprintf("ss-%s-%s", name, s.randSuffix())
}

func (s *Screenshare) randSuffix() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return fmt.Sprintf("%04d", s.rng.Intn(10000))
}

func parseIDs(cid string) (targetID, requesterID string) {
	parts := strings.Split(strings.TrimSpace(cid), ":")
	if len(parts) >= 2 {
		targetID = strings.TrimSpace(parts[1])
	}
	if len(parts) >= 3 {
		requesterID = strings.TrimSpace(parts[2])
	}
	return
}

func parseTopic(topic string) (targetID, requesterID string) {
	if topic == "" {
		return
	}
	parts := strings.Fields(topic)
	for _, p := range parts {
		if strings.HasPrefix(p, "targetID:") {
			targetID = strings.TrimPrefix(p, "targetID:")
		}
		if strings.HasPrefix(p, "requesterID:") {
			requesterID = strings.TrimPrefix(p, "requesterID:")
		}
	}
	return
}

func (s *Screenshare) sendScreenshareInstructions(sess *discordgo.Session, guildID, channelID string, user *discordgo.User) {
	if sess == nil || user == nil || guildID == "" || channelID == "" {
		return
	}
	dm, err := sess.UserChannelCreate(user.ID)
	if err != nil || dm == nil {
		return
	}
	link := fmt.Sprintf("https://discord.com/channels/%s/%s", guildID, channelID)
	content := fmt.Sprintf("Download AnyDesk here: https://anydesk.com/en.\nRun AnyDesk.\nCopy the 9 digit code at the top of your screen and put it in your new ticket <#%s> (%s)", channelID, link)
	_, _ = sess.ChannelMessageSend(dm.ID, content)
}

func (s *Screenshare) logScreenshareRequest(sess *discordgo.Session, status, reason, note, requesterID, targetID, targetName, ticketChannel, transcriptLink string) {
	if sess == nil || requesterID == "" || targetID == "" || ticketChannel == "" {
		return
	}
	logChannel := strings.TrimSpace(shared.SettingOrEnv("SCREENSHARE_LOGS_CHANNEL"))
	if logChannel == "" {
		return
	}
	if targetName == "" {
		targetName = "player"
	}
	if reason == "" {
		reason = "No reason provided."
	}
	description := fmt.Sprintf("User <@%s> has requested a screenshare for <@%s> (%s).", requesterID, targetID, targetName)
	fields := []*discordgo.MessageEmbedField{
		{Name: "Reason", Value: reason, Inline: false},
		{Name: "Status", Value: status, Inline: true},
		{Name: "Ticket", Value: fmt.Sprintf("<#%s>", ticketChannel), Inline: true},
	}
	if note != "" {
		fields = append(fields, &discordgo.MessageEmbedField{Name: "Note", Value: note, Inline: false})
	}
	if transcriptLink != "" {
		fields = append(fields, &discordgo.MessageEmbedField{Name: "Transcript", Value: transcriptLink, Inline: false})
	}
	embed := &discordgo.MessageEmbed{
		Title:       "Screenshare Request",
		Description: description,
		Color:       0x004CFF,
		Fields:      fields,
	}
	_, _ = sess.ChannelMessageSendEmbed(logChannel, embed)
}

func (s *Screenshare) captureAndSendSSTranscript(sess *discordgo.Session, guildID, channelID, proofURL, targetID, requesterID, takenBy string) (string, error) {
	text, err := captureChannelTranscript(sess, channelID)
	if err != nil {
		return "", err
	}
	if strings.TrimSpace(text) == "" {
		return "", nil
	}
	return persistSSTranscript(sess, guildID, channelID, text, proofURL, targetID, requesterID, takenBy)
}

func persistSSTranscript(sess *discordgo.Session, guildID, channelID, text, proofURL, targetID, requesterID, takenBy string) (string, error) {
	if sess == nil {
		return "", errors.New("session is nil")
	}
	transcriptChannel := strings.TrimSpace(shared.SettingOrEnv("SS_TRANSCRIPT"))
	if transcriptChannel == "" {
		return "", nil
	}
	htmlPath, err := transcripts.Write("ss", channelID, text)
	if err != nil {
		return "", err
	}
	defer func() {
		if htmlPath != "" {
			_ = os.Remove(htmlPath)
		}
	}()
	data, err := os.ReadFile(htmlPath)
	if err != nil {
		return "", err
	}
	file := &discordgo.File{
		Name:        fmt.Sprintf("screenshare_%s_transcript.html", channelID),
		ContentType: "text/html",
		Reader:      bytes.NewReader(data),
	}
	targetMention := mentionOrUnknown(targetID)
	requesterMention := mentionOrUnknown(requesterID)
	takenMention := mentionOrUnknown(takenBy)
	msgSend := &discordgo.MessageSend{
		Content: fmt.Sprintf("Screenshare transcript for %s by %s taken by %s.", targetMention, requesterMention, takenMention),
		Files:   []*discordgo.File{file},
	}
	if trimmed := strings.TrimSpace(proofURL); trimmed != "" {
		msgSend.Embeds = []*discordgo.MessageEmbed{
			{
				Title: "Submitted image",
				Image: &discordgo.MessageEmbedImage{URL: trimmed},
			},
		}
	}
	msg, err := sess.ChannelMessageSendComplex(transcriptChannel, msgSend)
	if err != nil {
		return "", err
	}
	if guildID == "" {
		return "", nil
	}
	return fmt.Sprintf("https://discord.com/channels/%s/%s/%s", guildID, transcriptChannel, msg.ID), nil
}

func (s *Screenshare) ssWatcherLoop() {
	ticker := time.NewTicker(2 * time.Minute)
	defer ticker.Stop()
	for range ticker.C {
		fmt.Println("Running ss watcher now")
		s.checkPendingRequests()
	}
}

func (s *Screenshare) checkPendingRequests() {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	requests, err := storage.GetPendingScreenshareRequestsBefore(ctx, time.Now().Add(-10*time.Minute))
	if err != nil {
		fmt.Printf("ss watcher: failed to load requests: %v\n", err)
		return
	}
	sess := s.getSession()
	if sess == nil {
		return
	}
	for _, rec := range requests {
		channel := strings.TrimSpace(rec.ChannelID)
		if channel == "" {
			channel = s.channelForRequester(rec.RequesterID)
		}
		if channel != "" {
			s.expireTicket(sess, channel)
		}
	}
}

func (s *Screenshare) channelForRequester(requesterID string) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.active[requesterID]
}

func (s *Screenshare) updateTicket(channelID string, update func(*ssTicket)) {
	if channelID == "" || update == nil {
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if t, ok := s.tickets[channelID]; ok && t != nil {
		update(t)
	}
}

func hasScreensharerPermission(i *discordgo.InteractionCreate) bool {
	if hasAdminPermission(i) {
		return true
	}
	roleID := strings.TrimSpace(shared.SettingOrEnv("SCREENSHARER_ROLE_ID"))
	if roleID == "" {
		return false
	}
	return memberHasRole(i.Member, roleID)
}

func hasSSManagerPermission(i *discordgo.InteractionCreate) bool {
	if hasAdminPermission(i) {
		return true
	}
	roleID := strings.TrimSpace(shared.SettingOrEnv("SS_MANAGER_ROLE_ID"))
	if roleID == "" {
		return false
	}
	return memberHasRole(i.Member, roleID)
}

func canManageScreenshare(i *discordgo.InteractionCreate) bool {
	if hasAdminPermission(i) || hasStaffPermission(i) {
		return true
	}
	return hasScreensharerPermission(i)
}

func uniqueStringSlice(items []string) []string {
	out := make([]string, 0, len(items))
	seen := make(map[string]struct{})
	for _, v := range items {
		v = strings.TrimSpace(v)
		if v == "" {
			continue
		}
		if _, ok := seen[v]; ok {
			continue
		}
		seen[v] = struct{}{}
		out = append(out, v)
	}
	return out
}

func mentionOrUnknown(id string) string {
	if mention := formatMention(id); mention != "" {
		return mention
	}
	return "unknown"
}

func (s *Screenshare) setSession(sess *discordgo.Session) {
	if sess == nil {
		return
	}
	s.sessMu.Lock()
	defer s.sessMu.Unlock()
	s.session = sess
	if !s.booted {
		s.booted = true
		go s.checkPendingRequests()
	}
}

// SetSession allows startup hooks to attach the session.
func (s *Screenshare) SetSession(sess *discordgo.Session) {
	s.setSession(sess)
}

func (s *Screenshare) getSession() *discordgo.Session {
	s.sessMu.RLock()
	defer s.sessMu.RUnlock()
	return s.session
}
