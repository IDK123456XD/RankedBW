package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type RankConfig struct{}

func NewRankConfig() *RankConfig { return &RankConfig{} }
func (c *RankConfig) Name() string {
	return "rankconfig"
}

func (c *RankConfig) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:                     c.Name(),
		Description:              "Manage rank brackets (staff only).",
		DefaultMemberPermissions: &perm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "set",
				Description: "Create or update a rank bracket.",
				Options: []*discordgo.ApplicationCommandOption{
					{Name: "name", Type: discordgo.ApplicationCommandOptionString, Description: "Rank name", Required: true},
					{Name: "min", Type: discordgo.ApplicationCommandOptionInteger, Description: "Min elo (inclusive)", Required: true},
					{Name: "max", Type: discordgo.ApplicationCommandOptionInteger, Description: "Max elo (inclusive)", Required: true},
					{Name: "gain", Type: discordgo.ApplicationCommandOptionInteger, Description: "Win gain", Required: true},
					{Name: "loss", Type: discordgo.ApplicationCommandOptionInteger, Description: "Loss amount", Required: true},
					{Name: "mvp", Type: discordgo.ApplicationCommandOptionInteger, Description: "MVP bonus", Required: true},
					{Name: "role", Type: discordgo.ApplicationCommandOptionRole, Description: "Discord role for this rank", Required: true},
					{Name: "emoji_id", Type: discordgo.ApplicationCommandOptionString, Description: "Custom emoji ID (optional)", Required: false},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "delete",
				Description: "Delete a rank bracket by name.",
				Options: []*discordgo.ApplicationCommandOption{
					{Name: "name", Type: discordgo.ApplicationCommandOptionString, Description: "Rank name", Required: true},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List all configured ranks.",
			},
		},
	}
}

func (c *RankConfig) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if i == nil || len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	sub := i.ApplicationCommandData().Options[0]
	switch sub.Name {
	case "set":
		c.handleSet(sess, i, sub)
	case "delete":
		c.handleDelete(sess, i, sub)
	case "list":
		c.handleList(sess, i)
	}
}

func (c *RankConfig) handleSet(sess *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	args := map[string]*discordgo.ApplicationCommandInteractionDataOption{}
	for _, o := range opt.Options {
		args[o.Name] = o
	}
	required := []string{"name", "min", "max", "gain", "loss", "mvp", "role"}
	for _, key := range required {
		if args[key] == nil {
			shared.RespondEphemeral(sess, i, fmt.Sprintf("Missing required option: %s", key))
			return
		}
	}

	name := strings.TrimSpace(args["name"].StringValue())
	min := int(args["min"].IntValue())
	max := int(args["max"].IntValue())
	gain := int(args["gain"].IntValue())
	loss := int(args["loss"].IntValue())
	mvp := int(args["mvp"].IntValue())
	roleID := ""
	if role := args["role"].RoleValue(sess, i.GuildID); role != nil {
		roleID = strings.TrimSpace(role.ID)
	}
	emojiID := ""
	if opt := args["emoji_id"]; opt != nil {
		emojiID = strings.TrimSpace(opt.StringValue())
	}

	if name == "" || roleID == "" {
		shared.RespondEphemeral(sess, i, "Provide a rank name and role.")
		return
	}
	if min < 0 || max < 0 || max < min {
		shared.RespondEphemeral(sess, i, "Min/max elo must be non-negative and max must be >= min.")
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	err := storage.UpsertRank(ctx, storage.RankRecord{
		Name:    name,
		Min:     min,
		Max:     max,
		Gain:    gain,
		Loss:    loss,
		MVP:     mvp,
		RoleID:  roleID,
		EmojiID: emojiID,
	})
	if err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to save rank: %v", err))
		return
	}

	msg := fmt.Sprintf("Saved rank **%s**: %d-%d Elo | +%d / -%d | MVP %d | Role <@&%s>", name, min, max, gain, loss, mvp, roleID)
	if emojiID != "" {
		msg += fmt.Sprintf(" | Emoji ID `%s`", emojiID)
	}
	shared.RespondEphemeral(sess, i, msg)
}

func (c *RankConfig) handleDelete(sess *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	name := strings.TrimSpace(opt.Options[0].StringValue())
	if name == "" {
		shared.RespondEphemeral(sess, i, "Provide a rank name to delete.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.DeleteRank(ctx, name); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to delete rank: %v", err))
		return
	}
	shared.RespondEphemeral(sess, i, fmt.Sprintf("Deleted rank **%s** (if it existed).", name))
}

func (c *RankConfig) handleList(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	ranks, err := storage.ListRanks(ctx)
	if err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to load ranks: %v", err))
		return
	}
	if len(ranks) == 0 {
		shared.RespondEphemeral(sess, i, "No ranks configured.")
		return
	}
	var sb strings.Builder
	for _, r := range ranks {
		line := fmt.Sprintf("**%s**: %d-%d | +%d / -%d | MVP %d | <@&%s>", r.Name, r.Min, r.Max, r.Gain, r.Loss, r.MVP, r.RoleID)
		if strings.TrimSpace(r.EmojiID) != "" {
			line += fmt.Sprintf(" | Emoji `%s`", strings.TrimSpace(r.EmojiID))
		}
		sb.WriteString(line + "\n")
	}
	embed := &discordgo.MessageEmbed{
		Title:       "Configured Ranks",
		Description: sb.String(),
		Color:       shared.DefaultEmbedColor,
	}
	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Embeds: []*discordgo.MessageEmbed{embed}},
	})
}
