package staff

import (
	"fmt"
	"strings"

	"rbw-bot/internal/commands/shared"

	"github.com/bwmarrin/discordgo"
)

type ScreenshareManage struct{}

func NewScreenshareManage() *ScreenshareManage { return &ScreenshareManage{} }
func (c *ScreenshareManage) Name() string      { return "screenshare" }

func (c *ScreenshareManage) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Manage Screensharer roles.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Assign the Screensharer role to a user.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "User to add as Screensharer.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove the Screensharer role from a user.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "User to remove from Screensharer.",
						Required:    true,
					},
				},
			},
		},
	}
}

func (c *ScreenshareManage) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if i.Member == nil || i.Member.User == nil || i.GuildID == "" {
		shared.RespondEphemeral(sess, i, "This command must be used inside a guild.")
		return
	}
	if !hasSSManagerPermission(i) {
		shared.RespondEphemeral(sess, i, "You do not have permission to manage Screensharers.")
		return
	}
	data := i.ApplicationCommandData()
	if len(data.Options) == 0 {
		shared.RespondEphemeral(sess, i, "Select a subcommand.")
		return
	}
	sub := data.Options[0]
	if len(sub.Options) == 0 {
		shared.RespondEphemeral(sess, i, "Select a user.")
		return
	}
	target := sub.Options[0].UserValue(sess)
	if target == nil {
		shared.RespondEphemeral(sess, i, "Unable to resolve the selected user.")
		return
	}
	roleID := strings.TrimSpace(shared.SettingOrEnv("SCREENSHARER_ROLE_ID"))
	if roleID == "" {
		shared.RespondEphemeral(sess, i, "screensharer_role_id is not configured. Set it with /settings addrole.")
		return
	}
	switch sub.Name {
	case "add":
		if err := sess.GuildMemberRoleAdd(i.GuildID, target.ID, roleID); err != nil {
			shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to assign Screensharer role: %v", err))
			return
		}
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Added Screensharer role to <@%s>.", target.ID))
	case "remove":
		if err := sess.GuildMemberRoleRemove(i.GuildID, target.ID, roleID); err != nil {
			shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to remove Screensharer role: %v", err))
			return
		}
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Removed Screensharer role from <@%s>.", target.ID))
	default:
		shared.RespondEphemeral(sess, i, "Unknown subcommand.")
	}
}
