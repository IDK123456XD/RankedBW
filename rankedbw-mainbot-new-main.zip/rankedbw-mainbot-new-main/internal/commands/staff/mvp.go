package staff

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/ranks"
	"rbw-bot/internal/scoring"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type MVP struct{}

func NewMVP() *MVP          { return &MVP{} }
func (m *MVP) Name() string { return "mvp" }

func (m *MVP) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        m.Name(),
		Description: "Award an MVP to a player in a scored game.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "gameid",
				Description: "Game ID (e.g. 1).",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "player",
				Description: "Player to mark as MVP.",
				Required:    true,
			},
		},
	}
}

func (m *MVP) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to award MVPs.")
		return
	}

	var gameOpt, playerOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "gameid":
			gameOpt = opt
		case "player":
			playerOpt = opt
		}
	}

	if gameOpt == nil || playerOpt == nil {
		shared.RespondEphemeral(s, i, "Both `gameid` and `player` are required.")
		return
	}

	gameID := strings.TrimSpace(gameOpt.StringValue())
	targetUser := playerOpt.UserValue(s)
	if targetUser == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the selected player.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	playerRecord, err := storage.GetPlayerByUserID(ctx, targetUser.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player profile: %v", err))
		return
	}
	if playerRecord == nil {
		shared.EditError(s, i, "That player is not registered.")
		return
	}

	logChannelID, err := storage.GetLogChannelID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load log channel: %v", err))
		return
	}

	game, players, _, err := storage.GetGameWithPlayersActiveSeason(ctx, gameID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load game: %v", err))
		return
	}
	if game == nil {
		shared.EditError(s, i, fmt.Sprintf("Game `%s` not found.", gameID))
		return
	}
	status := strings.ToUpper(strings.TrimSpace(game.Status))
	switch status {
	case "FINISHED", "SCORED":
		// proceed
	case "CANCELLED", "VOIDED":
		shared.EditError(s, i, fmt.Sprintf("Game `%s` was cancelled; MVP cannot be assigned.", gameID))
		return
	case "PENDING", "LIVE":
		shared.EditError(s, i, fmt.Sprintf("You need to score game `%s` before you can award an MVP.", gameID))
		return
	default:
		shared.EditError(s, i, fmt.Sprintf("Game `%s` is in status `%s` and cannot receive an MVP.", gameID, strings.ToLower(status)))
		return
	}

	var gp *storage.GamePlayerRecord
	for idx := range players {
		record := &players[idx]
		if record.DiscordID == targetUser.ID || record.PlayerID == playerRecord.ID {
			gp = record
			break
		}
	}
	if gp == nil {
		msg := fmt.Sprintf("%s did not participate in game `%s`.", targetUser.Mention(), gameID)
		shared.EditError(s, i, msg)
		return
	}
	if gp.MVP {
		shared.EditError(s, i, "That player is already marked as MVP for this game.")
		return
	}

	seasonID, err := scoring.SeasonIDForGame(ctx, game)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Could not determine season for this game: %v", err))
		return
	}

	stats, err := storage.GetPlayerSeasonStats(ctx, playerRecord.ID, seasonID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player stats: %v", err))
		return
	}
	if stats == nil {
		shared.EditError(s, i, "This player has no stats for the current season.")
		return
	}

	mvpBonus, ok := ranks.MVPBonusForElo(gp.PreElo)
	if !ok || mvpBonus == 0 {
		shared.EditError(s, i, "Could not determine MVP bonus for that player.")
		return
	}

	newElo := stats.Elo + mvpBonus
	if err := storage.MarkGamePlayerMVP(ctx, gp.ID, newElo); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to mark MVP: %v", err))
		return
	}

	reason := fmt.Sprintf("MVP Added %s", gameID)
	if _, _, err := storage.UpdatePlayerElo(ctx, stats.ID, playerRecord.ID, stats.SeasonID, newElo, "MVP", reason); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update Elo: %v", err))
		return
	}

	if err := storage.IncrementPlayerMVP(ctx, stats.ID, playerRecord.ID, stats.SeasonID, gp.PreElo); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update MVP stats: %v", err))
		return
	}

	stats.Elo = newElo
	refreshNicknamesFromScore(ctx, s, i.GuildID, []storage.ScoreUpdate{
		{PlayerID: playerRecord.ID, SeasonID: stats.SeasonID},
	}, "mvp")

	msg := fmt.Sprintf("%s has been awarded MVP for game `%s` and gained **+%d** Elo.", targetUser.Mention(), gameID, mvpBonus)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})

	m.logResult(s, logChannelID, i.Member.User.ID, targetUser.ID, gameID, mvpBonus)
}

func (m *MVP) logResult(s *discordgo.Session, channelID, moderatorID, playerID, gameID string, bonus int) {
	if channelID == "" {
		return
	}
	embed := &discordgo.MessageEmbed{
		Title: "MVP Awarded",
		Fields: []*discordgo.MessageEmbedField{
			{Name: "Player", Value: fmt.Sprintf("<@%s>", playerID), Inline: true},
			{Name: "Moderator", Value: fmt.Sprintf("<@%s>", moderatorID), Inline: true},
			{Name: "Game", Value: gameID, Inline: true},
			{Name: "Bonus", Value: fmt.Sprintf("+%d Elo", bonus), Inline: true},
		},
		Color:     0xFFD700,
		Timestamp: time.Now().Format(time.RFC3339),
	}

	if _, err := s.ChannelMessageSendEmbed(channelID, embed); err != nil {
		log.Printf("mvp: failed to send log embed: %v", err)
	}
}
