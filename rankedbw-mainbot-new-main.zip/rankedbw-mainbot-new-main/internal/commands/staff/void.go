package staff

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/leveling"
	"rbw-bot/internal/scoring"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Void struct {
	polls  map[string]*votePoll
	pollMu sync.Mutex
}

type votePoll struct {
	GameID       string
	ThreadID     string
	MessageID    string
	Participants map[string]struct{}
	Yes          map[string]struct{}
	No           map[string]struct{}
	ExpiresAt    time.Time
}

const (
	voteYesPrefix         = "voidvote:yes:"
	voteNoPrefix          = "voidvote:no:"
	staffVoidButtonPrefix = "void_staff_btn:"
)

func NewVoid() *Void {
	return &Void{
		polls: make(map[string]*votePoll),
	}
}

func (v *Void) Name() string { return "void" }

func (v *Void) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        v.Name(),
		Description: "Void a game via staff action or player vote.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "staff",
				Description: "Staff: void a game and undo stats if already scored.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "gameid",
						Description: "Game ID to void.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "reason",
						Description: "Reason for voiding.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "vote",
				Description: "Start a player vote to void the current game thread.",
			},
		},
	}
}

func (v *Void) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if len(i.ApplicationCommandData().Options) == 0 || i.ApplicationCommandData().Options[0].Name == "vote" {
		v.handlePlayerVote(sess, i)
		return
	}

	sub := i.ApplicationCommandData().Options[0]
	switch sub.Name {
	case "staff":
		v.handleStaffVoid(sess, i, sub)
	default:
		v.handlePlayerVote(sess, i)
	}
}

// --- Staff flow ---
func (v *Void) handleStaffVoid(sess *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(sess, i, "Only staff can use the staff void. Use `/void vote` inside a game thread to request a player vote.")
		return
	}

	var gameOpt, reasonOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, sub := range opt.Options {
		switch sub.Name {
		case "gameid":
			gameOpt = sub
		case "reason":
			reasonOpt = sub
		}
	}
	if gameOpt == nil || reasonOpt == nil {
		shared.RespondEphemeral(sess, i, "Provide both `gameid` and `reason`.")
		return
	}
	gameID := strings.TrimSpace(gameOpt.StringValue())
	reason := strings.TrimSpace(reasonOpt.StringValue())
	if gameID == "" || reason == "" {
		shared.RespondEphemeral(sess, i, "Provide both `gameid` and `reason`.")
		return
	}

	v.performStaffVoid(sess, i, gameID, reason, voidSourceStaff)
}

func (v *Void) handleStaffVoidButton(sess *discordgo.Session, i *discordgo.InteractionCreate, gameID string) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(sess, i, "Only staff can void games.")
		return
	}
	gameID = strings.TrimSpace(gameID)
	if gameID == "" {
		shared.RespondEphemeral(sess, i, "Missing game ID for void.")
		return
	}
	userID := interactionUserID(i)
	if userID == "" {
		shared.RespondEphemeral(sess, i, "Unable to identify you for this action.")
		return
	}
	reason := fmt.Sprintf("Voided by %s", userID)
	if ok := v.performStaffVoid(sess, i, gameID, reason, voidSourceButton); ok {
		v.disableInteractionMessage(sess, i)
	}
}

func (v *Void) disableInteractionMessage(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if sess == nil || i == nil || i.Message == nil {
		return
	}
	_, _ = sess.ChannelMessageEditComplex(&discordgo.MessageEdit{
		ID:         i.Message.ID,
		Channel:    i.ChannelID,
		Components: disableComponents(i.Message.Components),
	})
}

func (v *Void) performStaffVoid(sess *discordgo.Session, i *discordgo.InteractionCreate, gameID, reason string, source voidSource) bool {
	if sess == nil || i == nil {
		return false
	}
	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	logChannelID, err := storage.GetLogChannelID(ctx)
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to load log channel: %v", err))
		return false
	}

	game, players, _, err := storage.GetGameWithPlayersActiveSeason(ctx, gameID)
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to load game: %v", err))
		return false
	}
	if game == nil {
		shared.EditError(sess, i, fmt.Sprintf("Game `%s` was not found.", gameID))
		return false
	}
	status := strings.ToUpper(strings.TrimSpace(game.Status))
	if status == "CANCELLED" || status == "VOIDED" {
		shared.EditError(sess, i, fmt.Sprintf("Game `%s` has already been voided.", gameID))
		return false
	}

	var updates []storage.UnscoreUpdate
	var adjustedMentions []string
	reversed := 0
	wasScored := status == "FINISHED" || status == "SCORED"
	if wasScored {
		seasonID, err := scoring.SeasonIDForGame(ctx, game)
		if err != nil {
			shared.EditError(sess, i, fmt.Sprintf("Failed to determine season: %v", err))
			return false
		}
		for _, player := range players {
			label := scoring.MentionFromDiscordID(player.DiscordID)
			if label == "" {
				label = fmt.Sprintf("`%s`", player.PlayerID)
			}
			stats, err := storage.GetPlayerSeasonStats(ctx, player.PlayerID, seasonID)
			if err != nil {
				shared.EditError(sess, i, fmt.Sprintf("Failed to load stats for %s: %v", label, err))
				return false
			}
			if stats == nil {
				shared.EditError(sess, i, fmt.Sprintf("%s has no stats for this season.", label))
				return false
			}
			skipStats := stats.LastReset.Valid && game.CreatedAt.Before(stats.LastReset.Time)
			if skipStats {
				reasonSuffix := fmt.Sprintf("Game Voided %s", game.GameID)
				if strings.TrimSpace(reason) != "" {
					reasonSuffix = fmt.Sprintf("%s - %s", reasonSuffix, reason)
				}
				updates = append(updates, storage.UnscoreUpdate{
					GamePlayerID: player.ID,
					PlayerID:     player.PlayerID,
					StatsID:      stats.ID,
					SeasonID:     stats.SeasonID,
					Win:          player.Win,
					MVP:          player.MVP,
					XPDelta:      0,
					Streak:       stats.Streak,
					NewElo:       stats.Elo,
					ExtraReason:  reasonSuffix,
					SkipStats:    true,
				})
				continue
			}
			if stats.GamesPlayed <= 0 {
				shared.EditError(sess, i, fmt.Sprintf("Cannot void because %s has no recorded games.", label))
				return false
			}
			if player.Win && stats.Wins <= 0 {
				shared.EditError(sess, i, fmt.Sprintf("Cannot void because wins for %s would become negative.", label))
				return false
			}
			if !player.Win && stats.Losses <= 0 {
				shared.EditError(sess, i, fmt.Sprintf("Cannot void because losses for %s would become negative.", label))
				return false
			}
			if player.MVP && stats.MVPs <= 0 {
				shared.EditError(sess, i, fmt.Sprintf("Cannot void because MVPs for %s would become negative.", label))
				return false
			}

			newElo := stats.Elo - player.EloDiff
			if newElo < 0 {
				newElo = 0
			}
			xpToRemove := leveling.GameXPReward(player.PreElo, player.Win, player.MVP)
			newStreak := scoring.StreakAfterRevert(stats.Streak, player.Win)

			reasonSuffix := fmt.Sprintf("Game Voided %s", game.GameID)
			if strings.TrimSpace(reason) != "" {
				reasonSuffix = fmt.Sprintf("%s - %s", reasonSuffix, reason)
			}

			updates = append(updates, storage.UnscoreUpdate{
				GamePlayerID: player.ID,
				PlayerID:     player.PlayerID,
				StatsID:      stats.ID,
				SeasonID:     stats.SeasonID,
				Win:          player.Win,
				MVP:          player.MVP,
				XPDelta:      xpToRemove,
				Streak:       newStreak,
				NewElo:       newElo,
				ExtraReason:  reasonSuffix,
			})
			if mention := scoring.MentionFromDiscordID(player.DiscordID); mention != "" {
				adjustedMentions = append(adjustedMentions, mention)
			}
			reversed++
		}
	}

	if err := storage.VoidGame(ctx, game.ID, reason, updates); err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to void game: %v", err))
		return false
	}

	if len(updates) > 0 {
		refreshNicknamesFromUnscore(ctx, sess, i.GuildID, updates, "void")
	}

	actions, warnings := shared.CleanupGameResources(sess, i.GuildID, game)

	var response strings.Builder
	response.WriteString(fmt.Sprintf("Game `%s` has been voided.", game.GameID))
	if reversed > 0 {
		response.WriteString(fmt.Sprintf(" Reversed stats for %d players.", reversed))
	} else {
		response.WriteString(" No stat changes required.")
	}
	if len(actions) > 0 {
		response.WriteString("\nChannels closed:")
		for _, entry := range actions {
			response.WriteString("\n- " + entry)
		}
	}
	if len(warnings) > 0 {
		response.WriteString("\nWarnings:")
		for _, entry := range warnings {
			response.WriteString("\n- " + entry)
		}
	}

	out := response.String()
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &out})

	v.logVoidResult(sess, logChannelID, i, game.GameID, reason, adjustedMentions, reversed, wasScored)
	v.postVoidAnnouncement(sess, game.GameID, players, reason, source)
	return true
}

func (v *Void) logVoidResult(sess *discordgo.Session, channelID string, i *discordgo.InteractionCreate, gameID, reason string, players []string, reversed int, wasScored bool) {
	if channelID == "" {
		return
	}
	moderator := "Unknown"
	if i.Member != nil && i.Member.User != nil {
		moderator = fmt.Sprintf("<@%s>", i.Member.User.ID)
	} else if i.User != nil {
		moderator = fmt.Sprintf("<@%s>", i.User.ID)
	}

	description := fmt.Sprintf("**Moderator:** %s\n**Reason:** %s\n**Stats Reversed:** %t", moderator, reason, wasScored)
	if reversed > 0 {
		description += fmt.Sprintf("\n**Players Adjusted (%d):** %s", reversed, scoring.FormatList(players))
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Game %s Voided", gameID),
		Description: description,
		Color:       0xe74c3c,
		Timestamp:   time.Now().Format(time.RFC3339),
	}

	if _, err := sess.ChannelMessageSendEmbed(channelID, embed); err != nil {
		fmt.Printf("void: failed to send log embed: %v\n", err)
	}
}

// --- Player vote flow ---

// HandleComponent processes vote button clicks.
func (v *Void) HandleComponent(sess *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if i == nil || i.MessageComponentData().CustomID == "" {
		return false
	}
	custom := i.MessageComponentData().CustomID
	switch {
	case strings.HasPrefix(custom, staffVoidButtonPrefix):
		v.handleStaffVoidButton(sess, i, strings.TrimPrefix(custom, staffVoidButtonPrefix))
		return true

	case strings.HasPrefix(custom, voteYesPrefix), strings.HasPrefix(custom, voteNoPrefix):
		if i.Message == nil {
			return false
		}
		threadID := strings.TrimPrefix(strings.TrimPrefix(custom, voteYesPrefix), voteNoPrefix)
		userID := interactionUserID(i)
		if userID == "" {
			return true
		}

		poll := v.getPoll(threadID)
		if poll == nil {
			shared.RespondEphemeral(sess, i, "This void vote has expired or is no longer active.")
			return true
		}
		if time.Now().After(poll.ExpiresAt) {
			v.removePoll(threadID)
			shared.RespondEphemeral(sess, i, "This void vote has expired.")
			return true
		}

		if _, ok := poll.Participants[userID]; !ok {
			shared.RespondEphemeral(sess, i, "Only players in this game can vote to void it.")
			return true
		}

		v.recordVote(threadID, userID, strings.HasPrefix(custom, voteYesPrefix))

		poll = v.getPoll(threadID)
		yesCount := len(poll.Yes)
		total := len(poll.Participants)
		approved := yesCount*2 > total // strictly more than 50%

		embed := v.buildPollEmbed(poll, total, approved, false)
		components := voteButtons(poll.ThreadID, false)
		if approved {
			components = voteButtons(poll.ThreadID, true)
		}

		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseUpdateMessage,
			Data: &discordgo.InteractionResponseData{
				Embeds:     []*discordgo.MessageEmbed{embed},
				Components: components,
			},
		})

		if approved {
			go v.performPlayerVoid(sess, i, poll)
		}
		return true

	default:
		return false
	}
}

func (v *Void) handlePlayerVote(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	userID := interactionUserID(i)
	if userID == "" {
		shared.RespondEphemeral(sess, i, "Unable to identify you for voting.")
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	gameRec, players, err := storage.GetGameWithPlayersByThread(ctx, i.ChannelID)
	if err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to load game for this thread: %v", err))
		return
	}
	if gameRec == nil {
		shared.RespondEphemeral(sess, i, "This thread is not linked to an active game.")
		return
	}
	if isVoidedStatus(gameRec.Status) {
		shared.RespondEphemeral(sess, i, "This game is already voided or cancelled.")
		return
	}
	if isScoredStatus(gameRec.Status) {
		shared.RespondEphemeral(sess, i, "This game is already finished. Please ask staff to void it.")
		return
	}

	participants := make(map[string]struct{})
	for _, p := range players {
		if id := strings.TrimSpace(p.DiscordID); id != "" {
			participants[id] = struct{}{}
		}
	}
	if len(participants) == 0 {
		shared.RespondEphemeral(sess, i, "Cannot start a vote because no player Discord IDs were found for this game.")
		return
	}
	if _, ok := participants[userID]; !ok {
		shared.RespondEphemeral(sess, i, "Only players in this game can start a void vote.")
		return
	}

	if existing := v.getPoll(i.ChannelID); existing != nil && time.Now().Before(existing.ExpiresAt) {
		shared.RespondEphemeral(sess, i, "A void vote is already active in this thread.")
		return
	}

	poll := &votePoll{
		GameID:       gameRec.GameID,
		ThreadID:     i.ChannelID,
		Participants: participants,
		Yes:          make(map[string]struct{}),
		No:           make(map[string]struct{}),
		ExpiresAt:    time.Now().Add(10 * time.Minute),
	}
	// Record starter's vote as yes.
	poll.Yes[userID] = struct{}{}
	v.setPoll(i.ChannelID, poll)

	embed := v.buildPollEmbed(poll, len(participants), false, false)
	components := voteButtons(poll.ThreadID, false)

	// Send initial message and capture ID.
	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})
	msg, err := sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds:     &[]*discordgo.MessageEmbed{embed},
		Components: &components,
	})
	if err != nil {
		v.removePoll(i.ChannelID)
		shared.EditError(sess, i, fmt.Sprintf("Failed to start vote: %v", err))
		return
	}
	poll.MessageID = msg.ID
	v.setPoll(i.ChannelID, poll)

	// Expire vote after window.
	go func(threadID string, messageID string) {
		<-time.After(10 * time.Minute)
		v.expirePoll(sess, threadID, messageID)
	}(i.ChannelID, poll.MessageID)
}

func (v *Void) performPlayerVoid(sess *discordgo.Session, i *discordgo.InteractionCreate, poll *votePoll) {
	if poll == nil {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	gameRec, players, err := storage.GetGameWithPlayersByThread(ctx, poll.ThreadID)
	if err != nil || gameRec == nil {
		v.finishPollMessage(sess, poll, "Unable to load game for this thread. Please contact staff.")
		return
	}
	// Avoid double void.
	if isVoidedStatus(gameRec.Status) {
		v.finishPollMessage(sess, poll, "Game was already voided or cancelled.")
		return
	}
	if isScoredStatus(gameRec.Status) {
		v.finishPollMessage(sess, poll, "Game is already finished/scored. Staff action is required for any void.")
		return
	}

	reason := fmt.Sprintf("Player vote in thread %s", poll.ThreadID)
	if err := storage.VoidGame(ctx, gameRec.ID, reason, nil); err != nil {
		v.finishPollMessage(sess, poll, fmt.Sprintf("Void failed: %v", err))
		return
	}

	actions, warnings := shared.CleanupGameResources(sess, i.GuildID, gameRec)

	v.removePoll(poll.ThreadID)

	result := v.buildPollEmbed(poll, len(poll.Participants), true, true)
	if len(actions) > 0 || len(warnings) > 0 {
		var sb strings.Builder
		if len(actions) > 0 {
			sb.WriteString("Cleanup:\n")
			for _, a := range actions {
				sb.WriteString("- " + a + "\n")
			}
		}
		if len(warnings) > 0 {
			sb.WriteString("Warnings:\n")
			for _, w := range warnings {
				sb.WriteString("- " + w + "\n")
			}
		}
		result.Description += "\n" + sb.String()
	}

	_, _ = sess.ChannelMessageEditComplex(&discordgo.MessageEdit{
		ID:         poll.MessageID,
		Channel:    poll.ThreadID,
		Embeds:     []*discordgo.MessageEmbed{result},
		Components: voteButtons(poll.ThreadID, true),
	})
	v.postVoidAnnouncement(sess, gameRec.GameID, players, "", voidSourceVote)
}

type voidSource int

const (
	voidSourceStaff voidSource = iota
	voidSourceVote
	voidSourceButton
)

func (v *Void) postVoidAnnouncement(sess *discordgo.Session, gameID string, players []storage.GamePlayerRecord, reason string, source voidSource) {
	if sess == nil || strings.TrimSpace(gameID) == "" {
		return
	}
	channelID := strings.TrimSpace(shared.SettingOrEnv("game_resultls_channel"))
	if channelID == "" {
		return
	}
	userSet := make(map[string]struct{})
	for _, p := range players {
		id := strings.TrimSpace(p.DiscordID)
		if id == "" {
			continue
		}
		userSet[id] = struct{}{}
	}
	userIDs := make([]string, 0, len(userSet))
	mentions := make([]string, 0, len(userSet))
	for id := range userSet {
		userIDs = append(userIDs, id)
		mentions = append(mentions, fmt.Sprintf("<@%s>", id))
	}
	content := strings.Join(mentions, " ")
	if strings.TrimSpace(content) != "" {
		content += " "
	}
	content += fmt.Sprintf("Game `%s` was voided.", gameID)
	switch source {
	case voidSourceVote:
		content += " (voided by player vote)"
	case voidSourceStaff:
		if strings.TrimSpace(reason) != "" {
			content += " Reason: " + reason
		}
	case voidSourceButton:
		// No reason for scoring void button.
	}
	msg := &discordgo.MessageSend{
		Content: content,
		AllowedMentions: &discordgo.MessageAllowedMentions{
			Users: userIDs,
		},
	}
	_, _ = sess.ChannelMessageSendComplex(channelID, msg)
}

func (v *Void) finishPollMessage(sess *discordgo.Session, poll *votePoll, note string) {
	if poll == nil || sess == nil {
		return
	}
	v.removePoll(poll.ThreadID)
	embed := v.buildPollEmbed(poll, len(poll.Participants), false, true)
	if note != "" {
		embed.Description += "\n" + note
	}
	_, _ = sess.ChannelMessageEditComplex(&discordgo.MessageEdit{
		ID:         poll.MessageID,
		Channel:    poll.ThreadID,
		Embeds:     []*discordgo.MessageEmbed{embed},
		Components: voteButtons(poll.ThreadID, true),
	})
}

func (v *Void) buildPollEmbed(poll *votePoll, total int, approved bool, finalized bool) *discordgo.MessageEmbed {
	yes := len(poll.Yes)
	no := len(poll.No)
	status := "Active"
	if approved && finalized {
		status = "Approved — game voided"
	} else if approved {
		status = "Voiding in progress (majority reached)"
	} else if time.Now().After(poll.ExpiresAt) {
		status = "Expired"
	}
	desc := fmt.Sprintf("More than 50%% of players must vote to void. Only players in the game can vote.\n\nVotes: **%d/%d** yes, **%d** no.\nStatus: **%s**", yes, total, no, status)
	if approved {
		desc += "\nIf successful, the game will be voided and its thread/VCs will be closed."
	}
	return &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Void Vote for Game %s", poll.GameID),
		Description: desc,
		Color:       0xED4245,
		Timestamp:   time.Now().Format(time.RFC3339),
	}
}

func voteButtons(threadID string, disabled bool) []discordgo.MessageComponent {
	return []discordgo.MessageComponent{
		discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{
				plainButton{
					Label:    "Void Game",
					Style:    discordgo.DangerButton,
					CustomID: voteYesPrefix + threadID,
					Disabled: disabled,
				},
				plainButton{
					Label:    "Keep Game",
					Style:    discordgo.SecondaryButton,
					CustomID: voteNoPrefix + threadID,
					Disabled: disabled,
				},
			},
		},
	}
}

func (v *Void) recordVote(threadID, userID string, yes bool) {
	v.pollMu.Lock()
	defer v.pollMu.Unlock()
	poll, ok := v.polls[threadID]
	if !ok {
		return
	}
	delete(poll.Yes, userID)
	delete(poll.No, userID)
	if yes {
		poll.Yes[userID] = struct{}{}
	} else {
		poll.No[userID] = struct{}{}
	}
}

func (v *Void) getPoll(threadID string) *votePoll {
	v.pollMu.Lock()
	defer v.pollMu.Unlock()
	if poll, ok := v.polls[threadID]; ok {
		// shallow copy pointer is fine; internal maps guarded by same mutex usage.
		return poll
	}
	return nil
}

func (v *Void) setPoll(threadID string, poll *votePoll) {
	v.pollMu.Lock()
	defer v.pollMu.Unlock()
	if poll == nil {
		delete(v.polls, threadID)
		return
	}
	v.polls[threadID] = poll
}

func (v *Void) removePoll(threadID string) *votePoll {
	v.pollMu.Lock()
	defer v.pollMu.Unlock()
	p := v.polls[threadID]
	delete(v.polls, threadID)
	return p
}

func (v *Void) expirePoll(sess *discordgo.Session, threadID, messageID string) {
	poll := v.removePoll(threadID)
	if poll == nil || sess == nil || messageID == "" {
		return
	}
	embed := v.buildPollEmbed(poll, len(poll.Participants), false, true)
	embed.Description += "\nVote expired with no action taken."
	_, _ = sess.ChannelMessageEditComplex(&discordgo.MessageEdit{
		ID:         messageID,
		Channel:    threadID,
		Embeds:     []*discordgo.MessageEmbed{embed},
		Components: voteButtons(threadID, true),
	})
}

func interactionUserID(i *discordgo.InteractionCreate) string {
	if i == nil {
		return ""
	}
	if i.Member != nil && i.Member.User != nil {
		return strings.TrimSpace(i.Member.User.ID)
	}
	if i.User != nil {
		return strings.TrimSpace(i.User.ID)
	}
	return ""
}

func isVoidedStatus(status string) bool {
	switch strings.ToUpper(strings.TrimSpace(status)) {
	case "VOIDED", "CANCELLED":
		return true
	default:
		return false
	}
}

func isScoredStatus(status string) bool {
	switch strings.ToUpper(strings.TrimSpace(status)) {
	case "FINISHED", "SCORED":
		return true
	default:
		return false
	}
}

// plainButton mirrors discordgo.Button but omits the emoji field entirely to avoid sending empty emoji payloads.
type plainButton struct {
	Label    string                `json:"label,omitempty"`
	Style    discordgo.ButtonStyle `json:"style"`
	Disabled bool                  `json:"disabled,omitempty"`
	CustomID string                `json:"custom_id,omitempty"`
}

func (plainButton) Type() discordgo.ComponentType {
	return discordgo.ButtonComponent
}

func (b plainButton) MarshalJSON() ([]byte, error) {
	// match discordgo.Button marshal behavior minus emoji/url fields
	type btn plainButton
	if b.Style == 0 {
		b.Style = discordgo.PrimaryButton
	}
	return discordgo.Marshal(struct {
		btn
		Type discordgo.ComponentType `json:"type"`
	}{
		btn:  btn(b),
		Type: b.Type(),
	})
}
