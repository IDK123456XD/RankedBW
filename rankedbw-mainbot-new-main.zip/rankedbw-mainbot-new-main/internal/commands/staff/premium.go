package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/rolecommands"

	"github.com/bwmarrin/discordgo"
)

var premiumConfig = rolecommands.Config{
	Name:               "Premium",
	RoleEnv:            "PREMIUM_ROLE_ID",
	ManagerRoleEnv:     "PREMIUM_MANAGER_ROLE_ID",
	AnnounceChannelEnv: "PREMIUM_ANNOUNCEMENTS_CHANNEL_ID",
	LogChannelEnv:      "PREMIUM_LOG_CHANNEL_ID",
}

type Premium struct{}

func NewPremium() *Premium      { return &Premium{} }
func (p *Premium) Name() string { return "premium" }

func (p *Premium) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        p.Name(),
		Description: "Manage Premium players.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "add",
				Description: "Add a player to Premium.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "member",
						Description: "Discord user to add.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "reason",
						Description: "Reason for adding.",
					},
					{
						Type:        discordgo.ApplicationCommandOptionBoolean,
						Name:        "announce",
						Description: "Whether to announce in the Premium channel.",
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "remove",
				Description: "Remove a player from Premium.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "member",
						Description: "Discord user to remove.",
						Required:    true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "reason",
						Description: "Reason for removal.",
					},
					{
						Type:        discordgo.ApplicationCommandOptionBoolean,
						Name:        "announce",
						Description: "Whether to announce the removal.",
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List current Premium members.",
			},
		},
		// Runtime permission checks ensure only managers/owners/admins can act.
		DefaultMemberPermissions: nil,
	}
}

func (p *Premium) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	switch i.ApplicationCommandData().Options[0].Name {
	case "add":
		p.handleAdd(s, i)
	case "remove":
		p.handleRemove(s, i)
	case "list":
		p.handleList(s, i)
	}
}

func (p *Premium) handleAdd(s *discordgo.Session, i *discordgo.InteractionCreate) {
	opts := optionMap(i.ApplicationCommandData().Options[0].Options)
	target := opts["member"].UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	if !premiumConfig.IsManagerOrOwner(i.Member) && (i.Member == nil || i.Member.Permissions&discordgo.PermissionAdministrator == 0) {
		shared.RespondEphemeral(s, i, "Only Premium managers/owners or admins can manage Premium membership.")
		return
	}
	reason := ""
	if opt, ok := opts["reason"]; ok {
		reason = strings.TrimSpace(opt.StringValue())
	}
	announce := false
	if opt, ok := opts["announce"]; ok {
		announce = opt.BoolValue()
	}

	roleID, err := premiumConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "That user is not in this guild.")
		return
	}
	for _, id := range member.Roles {
		if id == roleID {
			shared.EditError(s, i, "That user is already in Premium.")
			return
		}
	}
	if err := s.GuildMemberRoleAdd(i.GuildID, target.ID, roleID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to assign role: %v", err))
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	mcName := rolecommands.PlayerMinecraftName(ctx, target.ID)

	if announce {
		actorID := ""
		if i.Member != nil && i.Member.User != nil {
			actorID = i.Member.User.ID
		} else if i.User != nil {
			actorID = i.User.ID
		}
		premiumConfig.AnnounceAction(s, true, actorID, target.ID, mcName, reason)
	}
	actorID := ""
	if i.Member != nil && i.Member.User != nil {
		actorID = i.Member.User.ID
	} else if i.User != nil {
		actorID = i.User.ID
	}
	premiumConfig.LogAction(s, true, actorID, target.ID, reason)
	updatedRoles := append(append([]string{}, member.Roles...), roleID)
	updateRoleListCacheFromMember(i.GuildID, roleListKindPremium, member, updatedRoles, mcName)

	message := fmt.Sprintf("%s has been added to Premium.", target.Mention())
	if reason != "" {
		message += " Reason: " + reason
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (p *Premium) handleRemove(s *discordgo.Session, i *discordgo.InteractionCreate) {
	opts := optionMap(i.ApplicationCommandData().Options[0].Options)
	target := opts["member"].UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	if !premiumConfig.IsManagerOrOwner(i.Member) && (i.Member == nil || i.Member.Permissions&discordgo.PermissionAdministrator == 0) {
		shared.RespondEphemeral(s, i, "Only Premium managers/owners or admins can manage Premium membership.")
		return
	}
	reason := ""
	if opt, ok := opts["reason"]; ok {
		reason = strings.TrimSpace(opt.StringValue())
	}
	announce := false
	if opt, ok := opts["announce"]; ok {
		announce = opt.BoolValue()
	}

	roleID, err := premiumConfig.RoleID()
	if err != nil {
		shared.RespondEphemeral(s, i, err.Error())
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	member, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.EditError(s, i, "That user is not in this guild.")
		return
	}
	hasRole := false
	for _, id := range member.Roles {
		if id == roleID {
			hasRole = true
			break
		}
	}
	if !hasRole {
		shared.EditError(s, i, "That user is not in Premium.")
		return
	}

	if err := s.GuildMemberRoleRemove(i.GuildID, target.ID, roleID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to remove role: %v", err))
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	mcName := rolecommands.PlayerMinecraftName(ctx, target.ID)

	actorID := ""
	if i.Member != nil && i.Member.User != nil {
		actorID = i.Member.User.ID
	} else if i.User != nil {
		actorID = i.User.ID
	}
	if announce {
		premiumConfig.AnnounceAction(s, false, actorID, target.ID, mcName, reason)
	}
	premiumConfig.LogAction(s, false, actorID, target.ID, reason)
	var updatedRoles []string
	for _, r := range member.Roles {
		if strings.TrimSpace(r) != strings.TrimSpace(roleID) {
			updatedRoles = append(updatedRoles, r)
		}
	}
	updateRoleListCacheFromMember(i.GuildID, roleListKindPremium, member, updatedRoles, mcName)

	message := fmt.Sprintf("%s has been removed from Premium.", target.Mention())
	if reason != "" {
		message += " Reason: " + reason
	}
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (p *Premium) handleList(s *discordgo.Session, i *discordgo.InteractionCreate) {
	sendRoleList(s, i, roleListKindPremium)
}
