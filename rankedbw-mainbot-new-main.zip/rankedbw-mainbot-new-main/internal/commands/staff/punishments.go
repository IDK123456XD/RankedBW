package staff

import (
	"context"
	"fmt"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Punishments struct{}

func NewPunishments() *Punishments  { return &Punishments{} }
func (c *Punishments) Name() string { return "punishments" }
func (c *Punishments) Build() *discordgo.ApplicationCommand {
	min := float64(1)
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "List all punishments for a player.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "player",
				Description: "Player to inspect.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionInteger,
				Name:        "limit",
				Description: "How many entries to show (max 25).",
				MinValue:    &min,
				MaxValue:    25,
			},
		},
	}
}

func (c *Punishments) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to view punishment history.")
		return
	}

	opts := optionMap(i.ApplicationCommandData().Options)
	target := opts["player"].UserValue(s)
	limit := 10
	if lOpt, ok := opts["limit"]; ok {
		limit = int(lOpt.IntValue())
	}
	if limit < 1 {
		limit = 1
	}
	if limit > 25 {
		limit = 25
	}
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "That player is not registered.")
		return
	}

	entries, err := storage.ListPunishmentsByPlayer(ctx, player.ID, limit)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch punishments: %v", err))
		return
	}
	if len(entries) == 0 {
		shared.EditError(s, i, "No punishments found for this player.")
		return
	}

	fields := make([]*discordgo.MessageEmbedField, 0, len(entries))
	for _, entry := range entries {
		var expiresAt time.Time
		hasExpiry := entry.ExpiresAt.Valid
		if hasExpiry {
			expiresAt = entry.ExpiresAt.Time
		}
		status := "Active"
		if entry.Expired || (hasExpiry && expiresAt.Before(time.Now())) {
			status = "Expired"
		}
		value := fmt.Sprintf("Reason: `%s`\nStaff: <@%s>\nStatus: %s", entry.Reason, entry.StaffID, status)
		if hasExpiry {
			unix := expiresAt.Unix()
			value += fmt.Sprintf("\nExpires: <t:%d:F> (<t:%d:R>)", unix, unix)
		}
		fields = append(fields, &discordgo.MessageEmbedField{
			Name:  fmt.Sprintf("%s — %s", entry.Type, entry.CreatedAt.Format("Jan 2 2006")),
			Value: value,
		})
		if len(fields) == 25 {
			break
		}
	}

	embed := &discordgo.MessageEmbed{
		Title:  fmt.Sprintf("Punishments for %s", player.MinecraftName),
		Color:  0xE74C3C,
		Fields: fields,
	}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{embed},
	})
}
