package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

// ClaimEloConfig manages claim-elo role rules.
type ClaimEloConfig struct{}

func NewClaimEloConfig() *ClaimEloConfig { return &ClaimEloConfig{} }
func (c *ClaimEloConfig) Name() string   { return "claimeloconfig" }

func (c *ClaimEloConfig) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:                     c.Name(),
		Description:              "Manage claim-elo rules (staff only).",
		DefaultMemberPermissions: &perm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "set",
				Description: "Create or update a claim rule for a role.",
				Options: []*discordgo.ApplicationCommandOption{
					{Name: "role", Type: discordgo.ApplicationCommandOptionRole, Description: "Role allowed to claim", Required: true},
					{Name: "amount", Type: discordgo.ApplicationCommandOptionInteger, Description: "ELO to set for the user", Required: true},
					{Name: "max_claims", Type: discordgo.ApplicationCommandOptionInteger, Description: "How many times this role can claim per season", Required: true},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "delete",
				Description: "Delete a claim rule for a role.",
				Options: []*discordgo.ApplicationCommandOption{
					{Name: "role", Type: discordgo.ApplicationCommandOptionRole, Description: "Role to remove", Required: true},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "list",
				Description: "List all claim rules.",
			},
		},
	}
}

func (c *ClaimEloConfig) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if i == nil || len(i.ApplicationCommandData().Options) == 0 {
		return
	}
	sub := i.ApplicationCommandData().Options[0]
	switch sub.Name {
	case "set":
		c.handleSet(sess, i, sub)
	case "delete":
		c.handleDelete(sess, i, sub)
	case "list":
		c.handleList(sess, i)
	}
}

func (c *ClaimEloConfig) handleSet(sess *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	var roleOpt *discordgo.ApplicationCommandInteractionDataOption
	var amountOpt *discordgo.ApplicationCommandInteractionDataOption
	var maxOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, o := range opt.Options {
		switch o.Name {
		case "role":
			roleOpt = o
		case "amount":
			amountOpt = o
		case "max_claims":
			maxOpt = o
		}
	}
	if roleOpt == nil || amountOpt == nil || maxOpt == nil {
		shared.RespondEphemeral(sess, i, "Provide role, amount, and max_claims.")
		return
	}

	role := roleOpt.RoleValue(sess, i.GuildID)
	if role == nil || strings.TrimSpace(role.ID) == "" {
		shared.RespondEphemeral(sess, i, "Invalid role.")
		return
	}
	amount := int(amountOpt.IntValue())
	maxClaims := int(maxOpt.IntValue())
	if amount <= 0 {
		shared.RespondEphemeral(sess, i, "Amount must be positive.")
		return
	}
	if maxClaims <= 0 {
		shared.RespondEphemeral(sess, i, "max_claims must be at least 1.")
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.UpsertClaimEloRule(ctx, role.ID, amount, maxClaims); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to save rule: %v", err))
		return
	}
	shared.RespondEphemeral(sess, i, fmt.Sprintf("Saved claim rule: <@&%s> -> set Elo to %d (max %d claim(s) per season).", role.ID, amount, maxClaims))
}

func (c *ClaimEloConfig) handleDelete(sess *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	roleOpt := opt.Options[0].RoleValue(sess, i.GuildID)
	if roleOpt == nil || strings.TrimSpace(roleOpt.ID) == "" {
		shared.RespondEphemeral(sess, i, "Invalid role.")
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := storage.DeleteClaimEloRule(ctx, roleOpt.ID); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to delete rule: %v", err))
		return
	}
	shared.RespondEphemeral(sess, i, fmt.Sprintf("Deleted claim rule for <@&%s> (if it existed).", roleOpt.ID))
}

func (c *ClaimEloConfig) handleList(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	rules, err := storage.ListClaimEloRules(ctx)
	if err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to load rules: %v", err))
		return
	}
	if len(rules) == 0 {
		shared.RespondEphemeral(sess, i, "No claim rules configured.")
		return
	}
	var lines []string
	for _, r := range rules {
		max := r.MaxClaims
		if max <= 0 {
			max = 1
		}
		lines = append(lines, fmt.Sprintf("<@&%s>: set Elo to %d | max %d claim(s)/season", strings.TrimSpace(r.RoleID), r.Amount, max))
	}
	embed := &discordgo.MessageEmbed{
		Title:       "Claim Elo Rules",
		Description: strings.Join(lines, "\n"),
		Color:       shared.DefaultEmbedColor,
	}
	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}
