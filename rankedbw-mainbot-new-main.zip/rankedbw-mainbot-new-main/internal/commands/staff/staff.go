package staff

import (
	"fmt"
	"os"
	"strings"

	"rbw-bot/internal/commands/shared"

	"github.com/bwmarrin/discordgo"
)

type staffRole struct {
	Name string
	Env  string
}

var (
	staffHierarchy = []staffRole{
		{Name: "helper", Env: "STAFF_HELPER_ROLE_ID"},
		{Name: "moderator", Env: "STAFF_MODERATOR_ROLE_ID"},
		{Name: "seniormoderator", Env: "STAFF_SENIOR_MODERATOR_ROLE_ID"},
		{Name: "administrator", Env: "STAFF_ADMINISTRATOR_ROLE_ID"},
		{Name: "owner", Env: "STAFF_OWNER_ROLE_ID"},
	}
	baseStaffRoleEnv      = "STAFF_ROLE_ID"
	staffAnnouncementsEnv = "STAFF_ANNOUNCEMENTS_CHANNEL_ID"
)

type Staff struct{}

func NewStaff() *Staff        { return &Staff{} }
func (c *Staff) Name() string { return "staff" }
func (c *Staff) Build() *discordgo.ApplicationCommand {
	choices := make([]*discordgo.ApplicationCommandOptionChoice, 0, len(staffHierarchy))
	for _, role := range staffHierarchy {
		choices = append(choices, &discordgo.ApplicationCommandOptionChoice{Name: strings.Title(role.Name), Value: role.Name})
	}
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Staff role system command.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "user",
				Description: "Discord user to modify.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "role",
				Description: "Role to add/remove.",
				Choices:     choices,
				Required:    true,
			},
		},
		DefaultMemberPermissions: &perm,
	}
}

func (c *Staff) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	target := i.ApplicationCommandData().Options[0].UserValue(s)
	roleName := strings.ToLower(i.ApplicationCommandData().Options[1].StringValue())

	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}

	entry := findStaffRole(roleName)
	if entry == nil {
		shared.RespondEphemeral(s, i, "Unknown staff role.")
		return
	}
	roleID := strings.TrimSpace(os.Getenv(entry.Env))
	if roleID == "" {
		shared.RespondEphemeral(s, i, fmt.Sprintf("Missing env %s", entry.Env))
		return
	}

	issuerHighest := highestStaffIndex(i.Member.Roles)
	targetMember, err := s.GuildMember(i.GuildID, target.ID)
	if err != nil {
		shared.RespondEphemeral(s, i, "That user is not in the guild.")
		return
	}
	targetHighest := highestStaffIndex(targetMember.Roles)
	roleIndex := roleIndex(roleName)

	if issuerHighest <= roleIndex {
		shared.RespondEphemeral(s, i, "You cannot manage a role equal to or higher than your own.")
		return
	}
	if issuerHighest <= targetHighest {
		shared.RespondEphemeral(s, i, "You cannot modify someone with an equal or higher staff role.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	currentlyHas := hasRole(targetMember, roleID)
	baseID := strings.TrimSpace(os.Getenv(baseStaffRoleEnv))

	if currentlyHas {
		_ = s.GuildMemberRoleRemove(i.GuildID, target.ID, roleID)
		if baseID != "" && highestStaffIndexAfterRemoval(targetMember.Roles, roleID) == -1 {
			_ = s.GuildMemberRoleRemove(i.GuildID, target.ID, baseID)
		}
		sendStaffAnnouncement(s, fmt.Sprintf("%s removed %s from **%s**.", i.Member.User.Mention(), target.Mention(), strings.Title(roleName)))
		msg := fmt.Sprintf("Removed %s from **%s**.", target.Mention(), strings.Title(roleName))
		_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
		return
	}

	// Remove other staff roles
	for _, role := range staffHierarchy {
		roleVal := strings.TrimSpace(os.Getenv(role.Env))
		if roleVal != "" && hasRole(targetMember, roleVal) {
			_ = s.GuildMemberRoleRemove(i.GuildID, target.ID, roleVal)
		}
	}
	if baseID != "" {
		_ = s.GuildMemberRoleAdd(i.GuildID, target.ID, baseID)
	}
	if err := s.GuildMemberRoleAdd(i.GuildID, target.ID, roleID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update roles: %v", err))
		return
	}

	sendStaffAnnouncement(s, fmt.Sprintf("%s set %s to **%s**.", i.Member.User.Mention(), target.Mention(), strings.Title(roleName)))
	msg := fmt.Sprintf("%s is now **%s**.", target.Mention(), strings.Title(roleName))
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}

func findStaffRole(name string) *staffRole {
	for _, role := range staffHierarchy {
		if role.Name == name {
			return &role
		}
	}
	return nil
}

func roleIndex(name string) int {
	for idx, role := range staffHierarchy {
		if role.Name == name {
			return idx
		}
	}
	return -1
}

func highestStaffIndex(roleIDs []string) int {
	index := -1
	for _, role := range roleIDs {
		for idx, entry := range staffHierarchy {
			if strings.TrimSpace(os.Getenv(entry.Env)) == role {
				if idx > index {
					index = idx
				}
			}
		}
	}
	return index
}

func highestStaffIndexAfterRemoval(roleIDs []string, removed string) int {
	var filtered []string
	for _, id := range roleIDs {
		if id != removed {
			filtered = append(filtered, id)
		}
	}
	return highestStaffIndex(filtered)
}

func hasRole(member *discordgo.Member, roleID string) bool {
	for _, r := range member.Roles {
		if r == roleID {
			return true
		}
	}
	return false
}

func sendStaffAnnouncement(s *discordgo.Session, content string) {
	channelID := strings.TrimSpace(os.Getenv(staffAnnouncementsEnv))
	if channelID == "" {
		return
	}
	_, _ = s.ChannelMessageSend(channelID, content)
}
