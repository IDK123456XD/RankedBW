package staff

import (
	"strings"

	"rbw-bot/internal/commands/shared"

	"github.com/bwmarrin/discordgo"
)

// Undo is an alias for /void staff.
type Undo struct{}

func NewUndo() *Undo { return &Undo{} }
func (c *Undo) Name() string {
	return "undo"
}

func (c *Undo) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Alias for /void staff.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "gameid",
				Description: "Game ID to void.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for voiding.",
				Required:    true,
			},
		},
	}
}

func (c *Undo) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(sess, i, "Only staff can use /undo.")
		return
	}

	var gameID, reason string
	for _, opt := range i.ApplicationCommandData().Options {
		switch strings.ToLower(strings.TrimSpace(opt.Name)) {
		case "gameid":
			gameID = strings.TrimSpace(opt.StringValue())
		case "reason":
			reason = strings.TrimSpace(opt.StringValue())
		}
	}
	if gameID == "" || reason == "" {
		shared.RespondEphemeral(sess, i, "Provide both `gameid` and `reason`.")
		return
	}

	NewVoid().performStaffVoid(sess, i, gameID, reason, voidSourceStaff)
}
