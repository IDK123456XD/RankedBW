package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type SSLeaderboard struct{}

func NewSSLeaderboard() *SSLeaderboard { return &SSLeaderboard{} }
func (c *SSLeaderboard) Name() string  { return "ssleaderboard" }

func (c *SSLeaderboard) Build() *discordgo.ApplicationCommand {
	min := float64(1)
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "View the screenshare leaderboard for a season.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "season",
				Description: "Season name (defaults to active season).",
			},
			{
				Type:        discordgo.ApplicationCommandOptionInteger,
				Name:        "page",
				Description: "Page number (10 per page).",
				MinValue:    &min,
			},
		},
	}
}

func (c *SSLeaderboard) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !canManageScreenshare(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to use this command.")
		return
	}

	seasonName := ""
	page := int64(1)
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "season":
			seasonName = strings.TrimSpace(opt.StringValue())
		case "page":
			page = opt.IntValue()
		}
	}
	if page < 1 {
		page = 1
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var season *storage.SeasonRecord
	var err error
	if seasonName == "" {
		season, err = storage.ActiveSeason(ctx)
	} else {
		season, err = storage.SeasonByName(ctx, seasonName)
	}
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load season: %v", err))
		return
	}
	if season == nil || strings.TrimSpace(season.Name) == "" {
		shared.EditError(s, i, "Season not found.")
		return
	}

	offset := int((page - 1) * 10)
	rows, err := storage.ScreenshareLeaderboard(ctx, season.Name, 10, offset)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load screenshare leaderboard: %v", err))
		return
	}
	unclaimed, err := storage.ScreenshareUnclaimedCount(ctx, season.Name)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to count unclaimed screenshares: %v", err))
		return
	}
	if len(rows) == 0 && unclaimed == 0 {
		shared.EditError(s, i, fmt.Sprintf("No screenshares recorded for **%s** yet.", season.Name))
		return
	}

	total, err := storage.ScreenshareLeaderboardTotal(ctx, season.Name)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to count screenshare leaderboard: %v", err))
		return
	}
	totalPages := (total + 9) / 10
	if totalPages < 1 {
		totalPages = 1
	}

	lines := make([]string, 0, len(rows))
	for idx, row := range rows {
		pos := offset + idx + 1
		label := "<unknown>"
		if strings.TrimSpace(row.TakenBy) != "" {
			label = fmt.Sprintf("<@%s>", strings.TrimSpace(row.TakenBy))
		}
		lines = append(lines, fmt.Sprintf("`#%d` %s - **%d**", pos, label, row.TakenCount))
	}
	if unclaimed > 0 {
		lines = append(lines, fmt.Sprintf("`#-` Unclaimed - **%d**", unclaimed))
	}

	description := fmt.Sprintf("**Season:** %s (Page %d)\n**Unclaimed:** %d\n%s", season.Name, page, unclaimed, strings.Join(lines, "\n"))
	embed := &discordgo.MessageEmbed{
		Title:       "Screenshare Leaderboard",
		Description: description,
		Color:       0x004CFF,
		Footer: &discordgo.MessageEmbedFooter{
			Text: fmt.Sprintf("Page %d/%d", page, totalPages),
		},
	}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{embed},
	})
}
