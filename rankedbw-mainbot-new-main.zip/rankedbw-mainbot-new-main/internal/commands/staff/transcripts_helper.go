package staff

import (
	"errors"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/transcripts"

	"github.com/bwmarrin/discordgo"
)

func captureChannelTranscript(sess *discordgo.Session, channelID string) (string, error) {
	if sess == nil {
		return "", errors.New("session is nil")
	}
	channelID = strings.TrimSpace(channelID)
	if channelID == "" {
		return "", errors.New("channel ID is empty")
	}

	const batchSize = 100
	var all []*discordgo.Message
	before := ""
	for {
		msgs, err := sess.ChannelMessages(channelID, batchSize, before, "", "")
		if err != nil {
			return "", err
		}
		if len(msgs) == 0 {
			break
		}
		all = append(all, msgs...)
		if len(msgs) < batchSize {
			break
		}
		before = msgs[len(msgs)-1].ID
	}

	if len(all) == 0 {
		return "", nil
	}
	for i, j := 0, len(all)-1; i < j; i, j = i+1, j-1 {
		all[i], all[j] = all[j], all[i]
	}

	entries := make([]transcripts.TranscriptEntry, 0, len(all))
	for _, msg := range all {
		ts := msg.Timestamp
		if ts.IsZero() {
			ts = time.Now()
		}
		author := "Unknown"
		if msg.Member != nil && strings.TrimSpace(msg.Member.Nick) != "" {
			author = msg.Member.Nick
		} else if msg.Author != nil && strings.TrimSpace(msg.Author.Username) != "" {
			author = msg.Author.Username
		}
		content := strings.TrimSpace(msg.Content)
		if content == "" {
			content = "<no text>"
		}
		entry := transcripts.TranscriptEntry{
			Timestamp: ts.UTC(),
			Author:    author,
			Content:   content,
		}
		if msg.Author != nil {
			entry.AuthorID = strings.TrimSpace(msg.Author.ID)
		}
		for _, att := range msg.Attachments {
			if url := strings.TrimSpace(att.URL); url != "" {
				entry.Attachments = append(entry.Attachments, url)
			}
		}
		for _, embed := range msg.Embeds {
			if embed == nil {
				continue
			}
			e := transcripts.TranscriptEmbed{}
			if embed.Title != "" {
				e.Title = embed.Title
			}
			if embed.Description != "" {
				e.Description = embed.Description
			}
			if e.Title != "" || e.Description != "" {
				entry.Embeds = append(entry.Embeds, e)
			}
		}
		entries = append(entries, entry)
	}

	return formatScreenshareTranscriptEntries(entries), nil
}

func formatScreenshareTranscriptEntries(entries []transcripts.TranscriptEntry) string {
	var builder strings.Builder
	for idx, entry := range entries {
		builder.WriteString(fmt.Sprintf("[%s] ", entry.Timestamp.Format(time.RFC3339)))
		if entry.AuthorID != "" {
			builder.WriteString(fmt.Sprintf("%s (%s): ", entry.Author, entry.AuthorID))
		} else {
			builder.WriteString(fmt.Sprintf("%s: ", entry.Author))
		}
		builder.WriteString(entry.Content)
		builder.WriteString("\n")

		for _, att := range entry.Attachments {
			builder.WriteString("  Attachment: ")
			builder.WriteString(att)
			builder.WriteString("\n")
		}
		for _, embed := range entry.Embeds {
			if embed.Title != "" {
				builder.WriteString("  Embed title: ")
				builder.WriteString(embed.Title)
				builder.WriteString("\n")
			}
			if embed.Description != "" {
				builder.WriteString("  Embed desc: ")
				builder.WriteString(embed.Description)
				builder.WriteString("\n")
			}
		}
		if idx < len(entries)-1 {
			builder.WriteString("\n")
		}
	}
	return builder.String()
}
