package staff

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/assets"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type StrikeRemove struct{}

func NewStrikeRemove() *StrikeRemove { return &StrikeRemove{} }
func (c *StrikeRemove) Name() string { return "strikeremove" }
func (c *StrikeRemove) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Remove the most recent strike from a player.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "player",
				Description: "Player to adjust.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Reason for removing the strike.",
				Required:    true,
			},
		},
	}
}

func (c *StrikeRemove) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to remove strikes.")
		return
	}

	opts := optionMap(i.ApplicationCommandData().Options)
	targetOpt := opts["player"]
	reasonOpt := opts["reason"]
	if targetOpt == nil || reasonOpt == nil {
		shared.RespondEphemeral(s, i, "Player and reason are required.")
		return
	}
	target := targetOpt.UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve that user.")
		return
	}
	reason := strings.TrimSpace(reasonOpt.StringValue())
	if reason == "" {
		shared.RespondEphemeral(s, i, "Please provide a reason for removing the strike.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "That player is not registered.")
		return
	}

	seasonID, err := storage.ActiveSeasonID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to find active season: %v", err))
		return
	}
	if err := storage.EnsurePlayerSeasonStats(ctx, player.ID, seasonID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to prepare stats: %v", err))
		return
	}
	stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, seasonID)
	if err != nil || stats == nil {
		shared.EditError(s, i, "Player has no stats for the active season.")
		return
	}

	strike, err := storage.LatestActiveStrike(ctx, player.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to locate strikes: %v", err))
		return
	}
	if strike == nil {
		shared.EditError(s, i, "This player has no active strikes.")
		return
	}

	if err := storage.MarkPunishmentExpired(ctx, strike.ID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to mark strike as removed: %v", err))
		return
	}
	if _, err := storage.CreateStrikeRemoval(ctx, player.ID, i.Member.User.ID, reason); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to record strike removal: %v", err))
		return
	}

	newElo := stats.Elo + strikeEloPenalty
	prev, updated, err := storage.UpdatePlayerElo(ctx, stats.ID, player.ID, seasonID, newElo, "StrikeRemove", reason)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update ELO: %v", err))
		return
	}

	stats.Elo = updated
	display := shared.BuildDisplayName(player, stats)
	if err := s.GuildMemberNickname(i.GuildID, player.UserID, display); err != nil {
		log.Printf("strikeremove: failed to update nickname for %s: %v", player.UserID, err)
	}

	season, _ := storage.ActiveSeason(ctx)
	count := 0
	if season != nil {
		if c, err := storage.ActiveStrikeCountForSeason(ctx, player.ID, season); err == nil {
			count = c
		}
	} else if c, err := storage.ActiveStrikeCount(ctx, player.ID); err == nil {
		count = c
	}
	notifyStrikeRemoval(ctx, s, i.GuildID, target.ID, i.Member.User.ID, reason, updated-prev, updated, count)
	adjustRankedBanForStrikeRemoval(ctx, s, i.GuildID, target.ID, i.Member.User.ID, reason, player.ID, count)

	content := fmt.Sprintf("Removed %s's most recent strike. ELO: %d ➜ %d.", target.Mention(), prev, updated)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &content})
}

func notifyStrikeRemoval(ctx context.Context, s *discordgo.Session, guildID, userID, staffID, reason string, eloDelta, newElo, totalStrikes int) {
	punishChannel, _ := storage.GetPunishmentsChannelID(ctx)
	logChannel, _ := storage.GetStaffPunishmentLogChannelID(ctx)

	if punishChannel != "" {
		desc := fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n**ELO Restored:** +%d\n\nYour most recent strike has been removed.", userID, reason, eloDelta*-1)
		if eloDelta < 0 {
			desc = fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n**ELO Restored:** +%d\n\nYour most recent strike has been removed.", userID, reason, -eloDelta)
		}
		embed := &discordgo.MessageEmbed{
			Title:       "Strike Removed",
			Description: desc,
			Color:       0x40FF56,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
				Files:   files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
				Content: fmt.Sprintf("<@%s>", userID),
				Embeds:  []*discordgo.MessageEmbed{embed},
			})
		}
	}

	if logChannel != "" {
		desc := fmt.Sprintf("<@%s> removed a strike from <@%s>.\nReason: `%s`\nELO now: %d\nActive strikes: %d", staffID, userID, reason, newElo, totalStrikes)
		embed := &discordgo.MessageEmbed{
			Title:       "Strike Removal Logged",
			Description: desc,
			Color:       0x40FF56,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		if thumb, files, cleanup := assets.ThumbnailAttachment("rankedunban.png"); thumb != nil {
			embed.Thumbnail = thumb
			_, _ = s.ChannelMessageSendComplex(logChannel, &discordgo.MessageSend{
				Embeds: []*discordgo.MessageEmbed{embed},
				Files:  files,
			})
			cleanup()
		} else {
			_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
		}
	}
}

func adjustRankedBanForStrikeRemoval(ctx context.Context, s *discordgo.Session, guildID, userID, staffID, reason, playerID string, strikesAfter int) {
	if ctx == nil || s == nil || strings.TrimSpace(playerID) == "" {
		return
	}
	oldStrikes := strikesAfter + 1
	if oldStrikes < 2 {
		return
	}
	durations := autoRankedBanDurations()
	oldDuration, ok := durations[oldStrikes]
	if !ok || oldDuration <= 0 {
		return
	}
	newDuration := time.Duration(0)
	if strikesAfter >= 2 {
		var okNew bool
		newDuration, okNew = durations[strikesAfter]
		if !okNew {
			return
		}
	}
	reduction := oldDuration - newDuration
	if reduction <= 0 {
		return
	}

	active, err := storage.ActiveRankedBanForPlayer(ctx, playerID)
	if err != nil || active == nil || !active.ExpiresAt.Valid {
		return
	}
	oldExpiry := active.ExpiresAt.Time
	newExpiry := oldExpiry.Add(-reduction)
	now := time.Now()

	expiredEarly := !newExpiry.After(now)
	if expiredEarly {
		if err := storage.MarkPunishmentExpired(ctx, active.ID); err != nil {
			log.Printf("strikeremove: failed to expire ranked ban %s: %v", active.ID, err)
			return
		}
		roleID := strings.TrimSpace(shared.SettingOrEnv("RANKED_BAN_ROLE_ID"))
		if roleID != "" {
			if err := s.GuildMemberRoleRemove(guildID, userID, roleID); err != nil {
				log.Printf("strikeremove: failed to remove ranked ban role for %s: %v", userID, err)
			}
		}
	} else if err := storage.UpdatePunishmentExpiry(ctx, active.ID, newExpiry); err != nil {
		log.Printf("strikeremove: failed to update ranked ban expiry for %s: %v", active.ID, err)
		return
	}

	notifyRankedBanReduction(ctx, s, userID, staffID, reason, oldExpiry, newExpiry, reduction, expiredEarly)
}

func notifyRankedBanReduction(ctx context.Context, s *discordgo.Session, userID, staffID, reason string, oldExpiry, newExpiry time.Time, reduction time.Duration, expiredEarly bool) {
	punishChannel, _ := storage.GetPunishmentsChannelID(ctx)
	logChannel, _ := storage.GetStaffPunishmentLogChannelID(ctx)
	adjustment := formatDurationLabel(reduction)

	if punishChannel != "" {
		desc := fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n**Adjustment:** -%s\n**New Expiry:** <t:%d:F> (<t:%d:R>)", userID, reason, adjustment, newExpiry.Unix(), newExpiry.Unix())
		title := "Ranked Ban Reduced"
		if expiredEarly {
			title = "Ranked Ban Removed"
			desc = fmt.Sprintf("**User:** <@%s>\n**Reason:** %s\n**Adjustment:** -%s\n\nYour ranked ban has been lifted early.", userID, reason, adjustment)
		}
		embed := &discordgo.MessageEmbed{
			Title:       title,
			Description: desc,
			Color:       0x40FF56,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		_, _ = s.ChannelMessageSendComplex(punishChannel, &discordgo.MessageSend{
			Content: fmt.Sprintf("<@%s>", userID),
			Embeds:  []*discordgo.MessageEmbed{embed},
		})
	}

	if logChannel != "" {
		desc := fmt.Sprintf("<@%s> reduced ranked ban time for <@%s> by %s.\nReason: `%s`\nOld expiry: <t:%d:F>\nNew expiry: <t:%d:F>", staffID, userID, adjustment, reason, oldExpiry.Unix(), newExpiry.Unix())
		title := "Ranked Ban Reduced"
		if expiredEarly {
			title = "Ranked Ban Removed"
			desc = fmt.Sprintf("<@%s> reduced ranked ban time for <@%s> by %s.\nReason: `%s`\nOld expiry: <t:%d:F>\nNew expiry: expired", staffID, userID, adjustment, reason, oldExpiry.Unix())
		}
		embed := &discordgo.MessageEmbed{
			Title:       title,
			Description: desc,
			Color:       0x40FF56,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		_, _ = s.ChannelMessageSendEmbed(logChannel, embed)
	}
}
