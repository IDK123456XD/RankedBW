package staff

import (
	"context"
	"fmt"
	"os"
	"sort"
	"strings"
	"sync"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/rolecommands"

	"github.com/bwmarrin/discordgo"
)

const (
	roleListNavPrefix = "rolelist_nav:"

	roleListKindPugs    = "pugs"
	roleListKindPups    = "pups"
	roleListKindPremium = "premium"
	roleListKindPit     = "pit"

	roleListItemsPerPage = 20
)

type roleListRoleIDs struct {
	Base    string
	Manager string
	Owner   string
	Trial   string
	Spec    string
}

type roleListSpec struct {
	Kind        string
	DisplayName string
	IDs         roleListRoleIDs
	Sections    []string
}

type roleListItem struct {
	UserID   string
	Display  string
	SortKey  string
	Recorded time.Time
}

type roleListCacheEntry struct {
	mu        sync.RWMutex
	guildID   string
	kind      string
	loaded    bool
	loadedAt  time.Time
	updatedAt time.Time
	sections  map[string]map[string]roleListItem
	embeds    []*discordgo.MessageEmbed
}

type roleListCacheStore struct {
	mu      sync.RWMutex
	entries map[string]*roleListCacheEntry
}

var roleListCache = &roleListCacheStore{entries: make(map[string]*roleListCacheEntry)}

func roleListCacheKey(guildID, kind string) string {
	return strings.TrimSpace(guildID) + ":" + strings.TrimSpace(kind)
}

func (c *roleListCacheStore) get(guildID, kind string) *roleListCacheEntry {
	key := roleListCacheKey(guildID, kind)
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.entries[key]
}

func (c *roleListCacheStore) getOrCreate(guildID, kind string) *roleListCacheEntry {
	key := roleListCacheKey(guildID, kind)
	c.mu.Lock()
	defer c.mu.Unlock()
	if existing := c.entries[key]; existing != nil {
		return existing
	}
	entry := &roleListCacheEntry{
		guildID:  strings.TrimSpace(guildID),
		kind:     strings.TrimSpace(kind),
		sections: make(map[string]map[string]roleListItem),
	}
	c.entries[key] = entry
	return entry
}

func roleListSpecForKind(kind string) (roleListSpec, error) {
	kind = strings.TrimSpace(kind)
	switch kind {
	case roleListKindPugs:
		roleID, err := pugsConfig.RoleID()
		if err != nil {
			return roleListSpec{}, err
		}
		return roleListSpec{
			Kind:        kind,
			DisplayName: strings.TrimSpace(pugsConfig.Name),
			IDs: roleListRoleIDs{
				Base:    strings.TrimSpace(roleID),
				Manager: strings.TrimSpace(pugsConfig.ManagerRoleID()),
				Owner:   strings.TrimSpace(pugsConfig.OwnerRoleID()),
				Trial:   strings.TrimSpace(os.Getenv("PUGS_TRIAL_ROLE_ID")),
				Spec:    strings.TrimSpace(os.Getenv("PUGS_SPEC_ROLE_ID")),
			},
			Sections: []string{"Owners", "Managers", "Members", "Trial", "Spec"},
		}, nil

	case roleListKindPups:
		roleID, err := pupsConfig.RoleID()
		if err != nil {
			return roleListSpec{}, err
		}
		return roleListSpec{
			Kind:        kind,
			DisplayName: strings.TrimSpace(pupsConfig.Name),
			IDs: roleListRoleIDs{
				Base:    strings.TrimSpace(roleID),
				Manager: strings.TrimSpace(pupsConfig.ManagerRoleID()),
				Owner:   strings.TrimSpace(pupsConfig.OwnerRoleID()),
				Trial:   strings.TrimSpace(os.Getenv("PUPS_TRIAL_ROLE_ID")),
			},
			Sections: []string{"Owners", "Managers", "Members", "Trial"},
		}, nil

	case roleListKindPremium:
		roleID, err := premiumConfig.RoleID()
		if err != nil {
			return roleListSpec{}, err
		}
		return roleListSpec{
			Kind:        kind,
			DisplayName: strings.TrimSpace(premiumConfig.Name),
			IDs: roleListRoleIDs{
				Base:    strings.TrimSpace(roleID),
				Manager: strings.TrimSpace(premiumConfig.ManagerRoleID()),
			},
			Sections: []string{"Managers", "Members"},
		}, nil

	case roleListKindPit:
		roleID, err := pitConfig.RoleID()
		if err != nil {
			return roleListSpec{}, err
		}
		return roleListSpec{
			Kind:        kind,
			DisplayName: strings.TrimSpace(pitConfig.Name),
			IDs: roleListRoleIDs{
				Base:    strings.TrimSpace(roleID),
				Manager: strings.TrimSpace(pitConfig.ManagerRoleID()),
				Owner:   strings.TrimSpace(pitConfig.OwnerRoleID()),
			},
			Sections: []string{"Owners", "Managers", "Members"},
		}, nil

	default:
		return roleListSpec{}, fmt.Errorf("unknown list kind: %s", kind)
	}
}

func roleListSectionForRoles(kind string, roles []string, ids roleListRoleIDs) string {
	has := func(roleID string) bool {
		roleID = strings.TrimSpace(roleID)
		if roleID == "" {
			return false
		}
		for _, r := range roles {
			if strings.TrimSpace(r) == roleID {
				return true
			}
		}
		return false
	}

	switch strings.TrimSpace(kind) {
	case roleListKindPugs:
		if ids.Owner != "" && has(ids.Owner) {
			return "Owners"
		}
		if ids.Manager != "" && has(ids.Manager) {
			return "Managers"
		}
		if ids.Trial != "" && has(ids.Trial) {
			return "Trial"
		}
		if ids.Spec != "" && has(ids.Spec) {
			return "Spec"
		}
		if has(ids.Base) {
			return "Members"
		}
		return ""

	case roleListKindPups:
		if ids.Owner != "" && has(ids.Owner) {
			return "Owners"
		}
		if ids.Manager != "" && has(ids.Manager) {
			return "Managers"
		}
		if ids.Trial != "" && has(ids.Trial) {
			return "Trial"
		}
		if has(ids.Base) {
			return "Members"
		}
		return ""

	case roleListKindPremium:
		if ids.Manager != "" && has(ids.Manager) {
			return "Managers"
		}
		if has(ids.Base) {
			return "Members"
		}
		return ""

	case roleListKindPit:
		if ids.Owner != "" && has(ids.Owner) {
			return "Owners"
		}
		if ids.Manager != "" && has(ids.Manager) {
			return "Managers"
		}
		if has(ids.Base) {
			return "Members"
		}
		return ""

	default:
		return ""
	}
}

func formatRoleListMember(ctx context.Context, member *discordgo.Member, minecraftName string) (display string, sortKey string) {
	if member == nil || member.User == nil {
		return "", ""
	}
	userID := strings.TrimSpace(member.User.ID)
	if userID == "" {
		return "", ""
	}
	mention := member.Mention()

	name := strings.TrimSpace(minecraftName)
	if name == "" && ctx != nil {
		name = rolecommands.PlayerMinecraftName(ctx, userID)
	}
	if name != "" {
		return fmt.Sprintf("%s | `%s`", mention, name), strings.ToLower(name)
	}
	if nick := strings.TrimSpace(member.Nick); nick != "" {
		return fmt.Sprintf("%s | `%s`", mention, nick), strings.ToLower(nick)
	}
	return mention, strings.ToLower(userID)
}

func ensureRoleListCacheBuilt(ctx context.Context, sess *discordgo.Session, guildID, kind string) (*roleListCacheEntry, error) {
	if sess == nil {
		return nil, fmt.Errorf("session is nil")
	}
	guildID = strings.TrimSpace(guildID)
	if guildID == "" {
		return nil, fmt.Errorf("missing guild ID")
	}

	spec, err := roleListSpecForKind(kind)
	if err != nil {
		return nil, err
	}

	entry := roleListCache.getOrCreate(guildID, kind)

	entry.mu.RLock()
	loaded := entry.loaded
	entry.mu.RUnlock()
	if loaded {
		return entry, nil
	}

	entry.mu.Lock()
	defer entry.mu.Unlock()
	if entry.loaded {
		return entry, nil
	}

	members, err := rolecommands.FetchAllMembers(sess, guildID)
	if err != nil {
		return nil, err
	}

	for _, section := range spec.Sections {
		entry.sections[section] = make(map[string]roleListItem)
	}

	lookupCtx := ctx
	if lookupCtx == nil {
		lookupCtx = context.Background()
	}
	lookupCtx, cancel := context.WithTimeout(lookupCtx, 20*time.Second)
	defer cancel()

	now := time.Now()
	for _, member := range members {
		if member == nil || member.User == nil {
			continue
		}
		section := roleListSectionForRoles(spec.Kind, member.Roles, spec.IDs)
		if section == "" {
			continue
		}
		display, sortKey := formatRoleListMember(lookupCtx, member, "")
		if display == "" {
			continue
		}
		userID := strings.TrimSpace(member.User.ID)
		entry.sections[section][userID] = roleListItem{
			UserID:   userID,
			Display:  display,
			SortKey:  sortKey,
			Recorded: now,
		}
	}

	entry.loaded = true
	entry.loadedAt = now
	entry.updatedAt = now
	entry.embeds = buildRoleListEmbeds(spec, entry.sections)

	return entry, nil
}

func (e *roleListCacheEntry) embedsForDisplay() ([]*discordgo.MessageEmbed, error) {
	e.mu.Lock()
	defer e.mu.Unlock()
	if !e.loaded {
		return nil, nil
	}
	if e.embeds != nil {
		return e.embeds, nil
	}
	spec, err := roleListSpecForKind(e.kind)
	if err != nil {
		return nil, err
	}
	e.embeds = buildRoleListEmbeds(spec, e.sections)
	return e.embeds, nil
}

func buildRoleListEmbeds(spec roleListSpec, sections map[string]map[string]roleListItem) []*discordgo.MessageEmbed {
	if len(spec.Sections) == 0 {
		return nil
	}

	var embeds []*discordgo.MessageEmbed

	for _, section := range spec.Sections {
		itemsMap := sections[section]
		if len(itemsMap) == 0 {
			continue
		}
		items := make([]roleListItem, 0, len(itemsMap))
		for _, item := range itemsMap {
			items = append(items, item)
		}
		sort.Slice(items, func(i, j int) bool {
			if items[i].SortKey == items[j].SortKey {
				return items[i].UserID < items[j].UserID
			}
			return items[i].SortKey < items[j].SortKey
		})

		total := len(items)
		for start := 0; start < total; start += roleListItemsPerPage {
			end := start + roleListItemsPerPage
			if end > total {
				end = total
			}
			lines := make([]string, 0, end-start)
			for _, item := range items[start:end] {
				if strings.TrimSpace(item.Display) == "" {
					continue
				}
				lines = append(lines, strings.TrimSpace(item.Display))
			}
			desc := strings.Join(lines, "\n")
			if total > roleListItemsPerPage {
				desc = fmt.Sprintf("Showing %d-%d of %d\n\n%s", start+1, end, total, desc)
			}

			title := strings.TrimSpace(spec.DisplayName)
			if title == "" {
				title = strings.ToUpper(spec.Kind)
			}
			title = fmt.Sprintf("%s %s (%d)", title, section, total)

			embeds = append(embeds, &discordgo.MessageEmbed{
				Title:       title,
				Description: desc,
				Color:       shared.DefaultEmbedColor,
			})
		}
	}

	totalPages := len(embeds)
	for idx := range embeds {
		if embeds[idx] == nil {
			continue
		}
		embeds[idx].Footer = &discordgo.MessageEmbedFooter{
			Text: fmt.Sprintf("Page %d/%d", idx+1, totalPages),
		}
	}

	return embeds
}

func roleListNavComponents(kind string, page, totalPages int, requester string) []discordgo.MessageComponent {
	if totalPages < 1 {
		totalPages = 1
	}
	if page < 1 {
		page = 1
	}
	if page > totalPages {
		page = totalPages
	}
	prev := plainButton{
		Label:    "< Prev",
		Style:    discordgo.SecondaryButton,
		CustomID: fmt.Sprintf("%s%s:%d:%s:prev", roleListNavPrefix, strings.TrimSpace(kind), page, strings.TrimSpace(requester)),
		Disabled: page <= 1,
	}
	next := plainButton{
		Label:    "Next >",
		Style:    discordgo.SecondaryButton,
		CustomID: fmt.Sprintf("%s%s:%d:%s:next", roleListNavPrefix, strings.TrimSpace(kind), page, strings.TrimSpace(requester)),
		Disabled: page >= totalPages,
	}
	return []discordgo.MessageComponent{
		discordgo.ActionsRow{Components: []discordgo.MessageComponent{prev, next}},
	}
}

func sendRoleList(s *discordgo.Session, i *discordgo.InteractionCreate, kind string) {
	if s == nil || i == nil {
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	entry, err := ensureRoleListCacheBuilt(ctx, s, i.GuildID, kind)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load list: %v", err))
		return
	}
	embeds, err := entry.embedsForDisplay()
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to build list: %v", err))
		return
	}
	if len(embeds) == 0 {
		shared.EditError(s, i, "No members found.")
		return
	}

	requester := interactionUserID(i)
	page := 1
	components := roleListNavComponents(kind, page, len(embeds), requester)
	allowed := &discordgo.MessageAllowedMentions{Parse: []discordgo.AllowedMentionType{}}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds:          &[]*discordgo.MessageEmbed{embeds[0]},
		Components:      &components,
		AllowedMentions: allowed,
	})
}

func updateRoleListCacheFromMember(guildID, kind string, member *discordgo.Member, updatedRoles []string, minecraftName string) {
	entry := roleListCache.get(guildID, kind)
	if entry == nil {
		return
	}

	entry.mu.Lock()
	defer entry.mu.Unlock()
	if !entry.loaded {
		return
	}

	spec, err := roleListSpecForKind(kind)
	if err != nil {
		return
	}
	for _, section := range spec.Sections {
		if entry.sections[section] == nil {
			entry.sections[section] = make(map[string]roleListItem)
		}
	}

	userID := ""
	if member != nil && member.User != nil {
		userID = strings.TrimSpace(member.User.ID)
	}
	if userID == "" {
		return
	}

	for _, section := range spec.Sections {
		delete(entry.sections[section], userID)
	}

	targetSection := roleListSectionForRoles(spec.Kind, updatedRoles, spec.IDs)
	if targetSection != "" {
		lookupCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		display, sortKey := formatRoleListMember(lookupCtx, member, minecraftName)
		if display != "" {
			entry.sections[targetSection][userID] = roleListItem{
				UserID:   userID,
				Display:  display,
				SortKey:  sortKey,
				Recorded: time.Now(),
			}
		}
	}

	entry.updatedAt = time.Now()
	entry.embeds = nil
}
