package staff

import (
	"fmt"
	"strings"

	"rbw-bot/internal/commands/shared"

	"github.com/bwmarrin/discordgo"
)

type Embed struct{}

func NewEmbed() *Embed        { return &Embed{} }
func (e *Embed) Name() string { return "embed" }

func (e *Embed) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        e.Name(),
		Description: "Send a custom embed to the current channel.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "description",
				Description: "Body text for the embed (supports \\n for newlines).",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "title",
				Description: "Optional embed title.",
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "image",
				Description: "Optional image URL.",
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "link",
				Description: "Optional URL to link the title to.",
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "color",
				Description: "Hex color like #7289DA. Defaults to Discord blurple.",
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "thumbnail",
				Description: "Optional thumbnail URL.",
			},
			{
				Type:        discordgo.ApplicationCommandOptionBoolean,
				Name:        "footer",
				Description: "Toggle the default Ranked Bedwars footer.",
			},
		},
		DefaultMemberPermissions: &[]int64{int64(discordgo.PermissionAdministrator)}[0],
	}
}

func (e *Embed) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	opts := map[string]*discordgo.ApplicationCommandInteractionDataOption{}
	for _, opt := range i.ApplicationCommandData().Options {
		opts[opt.Name] = opt
	}

	desc := stringOption(opts, "description")
	if desc == "" {
		shared.RespondEphemeral(s, i, "Description is required.")
		return
	}
	desc = strings.ReplaceAll(desc, `\n`, "\n")

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	embed := &discordgo.MessageEmbed{
		Description: desc,
		Color:       parseColor(stringOption(opts, "color")),
	}

	if title := stringOption(opts, "title"); title != "" {
		embed.Title = title
	}
	if link := stringOption(opts, "link"); link != "" {
		embed.URL = link
	}
	if image := stringOption(opts, "image"); image != "" {
		embed.Image = &discordgo.MessageEmbedImage{URL: image}
	}
	if thumb := stringOption(opts, "thumbnail"); thumb != "" {
		embed.Thumbnail = &discordgo.MessageEmbedThumbnail{URL: thumb}
	}
	if footerOpt, ok := opts["footer"]; ok && footerOpt.BoolValue() {
		embed.Footer = &discordgo.MessageEmbedFooter{Text: "Ranked Bedwars"}
	}

	if _, err := s.ChannelMessageSendComplex(i.ChannelID, &discordgo.MessageSend{
		Embeds: []*discordgo.MessageEmbed{embed},
	}); err != nil {
		msg := fmt.Sprintf("Failed to send embed: %v", err)
		shared.EditError(s, i, msg)
		return
	}

	success := "Embed sent."
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &success})
}

func stringOption(opts map[string]*discordgo.ApplicationCommandInteractionDataOption, name string) string {
	if opt, ok := opts[name]; ok && opt.Value != nil {
		return strings.TrimSpace(opt.StringValue())
	}
	return ""
}

func parseColor(input string) int {
	if input == "" {
		return 0x7289DA
	}
	input = strings.TrimSpace(strings.TrimPrefix(input, "#"))
	if len(input) != 6 {
		return 0x7289DA
	}
	var val int
	if _, err := fmt.Sscanf(input, "%06x", &val); err != nil {
		return 0x7289DA
	}
	return val
}
