package staff

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"sort"
	"strings"
	"sync"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/images"
	"rbw-bot/internal/scoring"
	"rbw-bot/internal/storage"
	"rbw-bot/internal/transcripts"

	"github.com/bwmarrin/discordgo"
)

const (
	submitButtonPrefix  = "score_submit_btn:"
	mvpSelectPrefix     = "score_mvp:"
	winButtonPrefix     = "score_win:"
	confirmButtonPrefix = "score_confirm:"
	modalPrefix         = "score_modal:"
)

type Score struct {
	scoringChannelID    string
	transcriptChannelID string
	mvpSelections       sync.Map // messageID -> []string (discord user IDs)
	winSelections       sync.Map // messageID -> int (winning team)
	submitting          sync.Map // gameID -> struct{}
}

func (s *Score) tryLockSubmission(gameID string) bool {
	if s == nil {
		return false
	}
	gameID = strings.TrimSpace(gameID)
	if gameID == "" {
		return false
	}
	_, loaded := s.submitting.LoadOrStore(gameID, struct{}{})
	return !loaded
}

func (s *Score) unlockSubmission(gameID string) {
	if s == nil {
		return
	}
	gameID = strings.TrimSpace(gameID)
	if gameID == "" {
		return
	}
	s.submitting.Delete(gameID)
}

func NewScore() *Score {
	return &Score{
		scoringChannelID:    shared.SettingOrEnv("SCORING_CHANNEL_ID"),
		transcriptChannelID: shared.SettingOrEnv("TRANSCRIPT_CHANNEL_ID"),
	}
}

func (s *Score) Name() string { return "submit" }

func (s *Score) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        s.Name(),
		Description: "Submit proof for the game tied to this thread.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionAttachment,
				Name:        "proof",
				Description: "Screenshot proof (required).",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "notes",
				Description: "Optional notes for staff.",
				Required:    false,
			},
		},
	}
}

func (s *Score) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if i.Member == nil || i.Member.User == nil {
		shared.RespondEphemeral(sess, i, "Only guild members may use this command.")
		return
	}

	var notesOpt, proofOpt *discordgo.ApplicationCommandInteractionDataOption
	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "notes":
			notesOpt = opt
		case "proof":
			proofOpt = opt
		}
	}
	if proofOpt == nil {
		shared.RespondEphemeral(sess, i, "Attach proof to submit this game.")
		return
	}

	proofID := attachmentID(proofOpt)
	proof := resolveAttachment(i, proofID)
	if proof == nil || strings.TrimSpace(proof.URL) == "" {
		shared.RespondEphemeral(sess, i, "Attach a screenshot as proof.")
		return
	}

	var notes string
	if notesOpt != nil {
		notes = strings.TrimSpace(notesOpt.StringValue())
	}

	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	if s.scoringChannelID == "" {
		shared.EditError(sess, i, "Scoring channel is not configured.")
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	threadID := strings.TrimSpace(i.ChannelID)
	if threadID == "" {
		shared.EditError(sess, i, "This command must be used inside the game thread.")
		return
	}

	game, players, err := storage.GetGameWithPlayersByThread(ctx, threadID)
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to find game for this thread: %v", err))
		return
	}
	if game == nil {
		shared.EditError(sess, i, "Could not find a game linked to this thread. Run this inside the game thread.")
		return
	}
	gameID := game.GameID
	if !s.tryLockSubmission(gameID) {
		shared.EditError(sess, i, "Another submission for this game is already in progress.")
		return
	}
	defer s.unlockSubmission(gameID)

	allowed := hasStaffPermission(i)
	if !allowed {
		requester := strings.TrimSpace(i.Member.User.ID)
		for _, p := range players {
			if strings.TrimSpace(p.DiscordID) == requester {
				allowed = true
				break
			}
		}
	}
	if !allowed {
		shared.EditError(sess, i, "Only participants in this game (or staff) can submit proof.")
		return
	}

	threadIDToClean := strings.TrimSpace(game.ThreadID.String)
	if threadIDToClean == "" {
		threadIDToClean = strings.TrimSpace(i.ChannelID)
	}
	seasonID := ""
	if game.SeasonID.Valid {
		seasonID = strings.TrimSpace(game.SeasonID.String)
	}
	if threadIDToClean != "" {
		if _, err := s.captureAndDeleteThread(ctx, sess, i.GuildID, seasonID, game.GameID, game.ID, threadIDToClean); err != nil {
			fmt.Printf("score: failed to capture transcript for thread %s: %v\n", threadIDToClean, err)
		}
	}

	if err := s.createScoringCard(ctx, sess, i.GuildID, i.Member.User.ID, game.GameID, proof.URL, notes, "slash", false); err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to submit score: %v", err))
		return
	}

	msg := fmt.Sprintf("Submitted game `%s` to staff with your proof.", game.GameID)
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}

// HandleComponent manages submit buttons, MVP dropdowns, and win buttons.
func (s *Score) HandleComponent(sess *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if i == nil || i.MessageComponentData().CustomID == "" {
		return false
	}
	cid := i.MessageComponentData().CustomID

	switch {
	case strings.HasPrefix(cid, submitButtonPrefix):
		// Buttons can't collect attachments; direct users to the slash command that supports file uploads.
		shared.RespondEphemeral(sess, i, "Use `/submit` in this thread and attach your screenshot. The button cannot accept image uploads.")
		return true

	case strings.HasPrefix(cid, mvpSelectPrefix):
		if !hasStaffPermission(i) {
			shared.RespondEphemeral(sess, i, "You do not have permission to score games.")
			return true
		}
		gameID := strings.TrimPrefix(cid, mvpSelectPrefix)
		if gameID == "" {
			return false
		}
		values := i.MessageComponentData().Values
		s.mvpSelections.Store(i.Message.ID, values)
		content := fmt.Sprintf("Selected %d MVP candidate(s) for game %s.", len(values), gameID)
		_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Flags:   64,
				Content: content,
			},
		})
		return true

	case strings.HasPrefix(cid, winButtonPrefix):
		if !hasStaffPermission(i) {
			shared.RespondEphemeral(sess, i, "You do not have permission to score games.")
			return true
		}
		parts := strings.Split(strings.TrimPrefix(cid, winButtonPrefix), ":")
		if len(parts) != 2 {
			return false
		}
		gameID := strings.TrimSpace(parts[0])
		teamRaw := strings.TrimSpace(parts[1])
		if gameID == "" || (teamRaw != "1" && teamRaw != "2") {
			return false
		}
		team := 1
		if teamRaw == "2" {
			team = 2
		}
		s.handleWinSelection(sess, i, gameID, team)
		return true

	case strings.HasPrefix(cid, confirmButtonPrefix):
		if !hasStaffPermission(i) {
			shared.RespondEphemeral(sess, i, "You do not have permission to score games.")
			return true
		}
		payload := strings.TrimSpace(strings.TrimPrefix(cid, confirmButtonPrefix))
		if payload == "" {
			return false
		}
		parts := strings.Split(payload, ":")
		gameID := strings.TrimSpace(parts[0])
		if gameID == "" {
			return false
		}
		allowRescore := len(parts) > 1 && strings.EqualFold(strings.TrimSpace(parts[1]), "force")
		s.handleConfirmSelection(sess, i, gameID, allowRescore)
		return true
	}

	return false
}

func (s *Score) HandleModal(sess *discordgo.Session, i *discordgo.InteractionCreate) bool {
	if i == nil || i.ModalSubmitData().CustomID == "" {
		return false
	}
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(sess, i, "You do not have permission to score games.")
		return true
	}
	cid := i.ModalSubmitData().CustomID
	if !strings.HasPrefix(cid, modalPrefix) {
		return false
	}
	gameID := strings.TrimPrefix(cid, modalPrefix)
	if gameID == "" {
		return false
	}
	var proofURL, notes string
	for _, comp := range i.ModalSubmitData().Components {
		if row, ok := comp.(*discordgo.ActionsRow); ok {
			for _, c := range row.Components {
				if input, ok := c.(*discordgo.TextInput); ok {
					switch input.CustomID {
					case "proof_url":
						proofURL = strings.TrimSpace(input.Value)
					case "notes":
						notes = strings.TrimSpace(input.Value)
					}
				}
			}
		}
	}
	if proofURL == "" {
		shared.RespondEphemeral(sess, i, "Please provide a screenshot URL.")
		return true
	}
	if s.scoringChannelID == "" {
		shared.RespondEphemeral(sess, i, "Scoring channel is not configured.")
		return true
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	if err := s.createScoringCard(ctx, sess, i.GuildID, i.Member.User.ID, gameID, proofURL, notes, "button", false); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to submit score: %v", err))
		return true
	}
	msg := fmt.Sprintf("Submitted game `%s` to staff with your proof.", gameID)
	shared.RespondEphemeral(sess, i, msg)
	return true
}

func (s *Score) logScoreResult(sess *discordgo.Session, channelID string, i *discordgo.InteractionCreate, result *scoring.ScoreResult) {
	resultsChannelID := shared.SettingOrEnv("game_resultls_channel")

	initiator := "Unknown"
	if i.Member != nil && i.Member.User != nil {
		initiator = fmt.Sprintf("<@%s>", i.Member.User.ID)
	} else if i.User != nil {
		initiator = fmt.Sprintf("<@%s>", i.User.ID)
	}
	proofSubmitter := initiator
	if result.Game != nil && result.Game.ProofBy.Valid {
		if trimmed := strings.TrimSpace(result.Game.ProofBy.String); trimmed != "" {
			proofSubmitter = fmt.Sprintf("<@%s>", trimmed)
		}
	}

	transcriptLink := ""
	// if result != nil && result.Game != nil && result.Game.ThreadSave.Valid {
	// 	transcriptLink = strings.TrimSpace(result.Game.ThreadSave.String)
	// }

	if channelID != "" {
		description := fmt.Sprintf("**Winning Team:** Team %d\n**Winners:** %s\n**Losers:** %s\n**MVPs:** %s",
			result.WinningTeam,
			scoring.FormatList(result.WinnerMentions),
			scoring.FormatList(result.LoserMentions),
			scoring.FormatList(result.MVPMentions),
		)
		if strings.TrimSpace(result.Reason) != "" {
			description += fmt.Sprintf("\n**Reason:** %s", result.Reason)
		}

		embed := &discordgo.MessageEmbed{
			Title:       fmt.Sprintf("Game %s Scored", result.Game.GameID),
			Description: description,
			Color:       0x2ecc71,
			Fields: []*discordgo.MessageEmbedField{
				{Name: "Proof Submitted By", Value: proofSubmitter, Inline: true},
			},
			Timestamp: time.Now().Format(time.RFC3339),
		}
		if result.Game != nil && result.Game.ProofURL.Valid {
			if url := strings.TrimSpace(result.Game.ProofURL.String); url != "" {
				embed.Image = &discordgo.MessageEmbedImage{URL: url}
			}
		}

		msg := &discordgo.MessageSend{
			Embeds: []*discordgo.MessageEmbed{embed},
		}

		if transcriptLink != "" {
			embed.Fields = append(embed.Fields, &discordgo.MessageEmbedField{
				Name:  "Transcript Link",
				Value: fmt.Sprintf("[View transcript](%s)", transcriptLink),
			})
		}

		if _, err := sess.ChannelMessageSendComplex(channelID, msg); err != nil {
			fmt.Printf("score: failed to send log embed: %v\n", err)
		}
	}

	sentCard := s.trySendScorecard(sess, resultsChannelID, initiator, result)
	if !sentCard && resultsChannelID != "" && len(result.ScoreLines) > 0 {
		lines := formatScoreLines(result.ScoreLines)
		content := fmt.Sprintf("Game `%s` scored:\n%s", result.Game.GameID, strings.Join(lines, "\n"))
		if _, err := sess.ChannelMessageSend(resultsChannelID, content); err != nil {
			fmt.Printf("score: failed to send results message: %v\n", err)
		}
	}
}

func formatScoreLines(lines []scoring.ScoreLine) []string {
	var winners, losers []scoring.ScoreLine
	for _, line := range lines {
		if line.Win {
			winners = append(winners, line)
		} else {
			losers = append(losers, line)
		}
	}
	var ordered []scoring.ScoreLine
	ordered = append(ordered, winners...)
	ordered = append(ordered, losers...)

	out := make([]string, 0, len(ordered))
	for _, line := range ordered {
		label := "<unknown>"
		if strings.TrimSpace(line.DiscordID) != "" {
			label = fmt.Sprintf("<@%s>", strings.TrimSpace(line.DiscordID))
		}
		out = append(out, fmt.Sprintf("%s %d->%d (%+d)", label, line.PreElo, line.PostElo, line.EloDiff))
	}
	return out
}

func (s *Score) trySendScorecard(sess *discordgo.Session, channelID, scoredBy string, result *scoring.ScoreResult) bool {
	if sess == nil || result == nil || result.Game == nil {
		return false
	}
	channelID = strings.TrimSpace(channelID)
	if channelID == "" {
		return false
	}

	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()

	game, players, seasonID, err := storage.GetGameWithPlayersActiveSeason(ctx, result.Game.GameID)
	if err != nil {
		log.Printf("score: failed to reload game %s for scorecard: %v\n", result.Game.GameID, err)
		return false
	}
	if game == nil || len(players) == 0 {
		return false
	}

	seasonName := ""
	if season, err := storage.ActiveSeason(ctx); err == nil && season != nil {
		if seasonID == "" || season.ID == seasonID {
			seasonName = season.Name
		}
	}
	if game.ThreadSave.Valid {
		_ = strings.TrimSpace(game.ThreadSave.String)
	}

	var cardPlayers []images.ScorecardPlayer
	for _, p := range players {
		name := strings.TrimSpace(p.MinecraftName)
		if name == "" {
			name = strings.TrimSpace(formatMention(p.DiscordID))
		}
		if name == "" && strings.TrimSpace(p.DiscordID) != "" {
			name = p.DiscordID
		}
		if name == "" {
			name = "Player"
		}

		pre := p.PreElo
		post := p.PostElo
		diff := p.EloDiff

		// Render strictly from the game record to avoid pollution from later games.
		if post == 0 && diff != 0 {
			post = pre + diff
		}
		if diff == 0 && post != 0 {
			diff = post - pre
		}
		if post == 0 {
			post = pre + diff
		}
		// For the scorecard view, anchor pre-Elo to the final Elo minus the change to avoid drift from later games.
		pre = post - diff
		if pre < 0 {
			pre = 0
		}

		cardPlayers = append(cardPlayers, images.ScorecardPlayer{
			Name:      name,
			DiscordID: strings.TrimSpace(p.DiscordID),
			UUID:      strings.TrimSpace(p.UUID),
			HeadSkin:  strings.TrimSpace(p.HeadSkin),
			PreElo:    pre,
			PostElo:   post,
			EloDiff:   diff,
			Win:       p.Win,
			MVP:       p.MVP,
			Team:      p.DiscordTeam,
		})
	}

	card := images.ScorecardData{
		GameID:     game.GameID,
		MapName:    strings.TrimSpace(game.MapName.String),
		SeasonName: strings.TrimSpace(seasonName),
		ScoredBy:   strings.TrimSpace(scoredBy),
		Players:    cardPlayers,
	}

	img, err := images.Scorecard(card)
	if err != nil {
		log.Printf("score: failed to generate scorecard for game %s: %v\n", game.GameID, err)
		return false
	}

	mentions := make([]string, 0, len(cardPlayers))
	for _, p := range cardPlayers {
		if mention := formatMention(p.DiscordID); mention != "" {
			mentions = append(mentions, mention)
		}
	}
	content := fmt.Sprintf("Game `%s` scored.", game.GameID)
	if len(mentions) > 0 {
		content = strings.Join(mentions, " ")
	}

	file := &discordgo.File{
		Name:        fmt.Sprintf("game_%s_scorecard.png", game.GameID),
		ContentType: "image/png",
		Reader:      bytes.NewReader(img),
	}
	msg := &discordgo.MessageSend{
		Content: content,
		Files:   []*discordgo.File{file},
	}

	for attempt := 1; attempt <= 3; attempt++ {
		if _, err := sess.ChannelMessageSendComplex(channelID, msg); err != nil {
			log.Printf("score: failed to send scorecard for game %s (attempt %d): %v\n", game.GameID, attempt, err)
			time.Sleep(time.Duration(attempt) * 500 * time.Millisecond)
			continue
		}
		return true
	}

	return true
}

func hasAdminPermission(i *discordgo.InteractionCreate) bool {
	if i == nil || i.Member == nil {
		return false
	}
	return i.Member.Permissions&discordgo.PermissionAdministrator != 0
}

func hasStaffPermission(i *discordgo.InteractionCreate) bool {
	if hasAdminPermission(i) {
		return true
	}
	if i == nil || i.Member == nil {
		return false
	}
	staffRole := strings.TrimSpace(shared.SettingOrEnv("staff"))
	if staffRole == "" {
		return false
	}
	for _, role := range i.Member.Roles {
		if strings.TrimSpace(role) == staffRole {
			return true
		}
	}
	return false
}

func (s *Score) respondScoreError(sess *discordgo.Session, i *discordgo.InteractionCreate, err error) {
	switch {
	case errors.Is(err, scoring.ErrParticipantCheck):
		shared.EditError(sess, i, "Only participants in this game can submit this score.")
	case errors.Is(err, scoring.ErrAlreadyScored):
		shared.EditError(sess, i, "This game has already been scored.")
	case errors.Is(err, scoring.ErrGameVoided):
		shared.EditError(sess, i, "This game has been voided and cannot be scored.")
	case errors.Is(err, scoring.ErrNoGamePlayers):
		shared.EditError(sess, i, "No players are recorded for that game.")
	case errors.Is(err, scoring.ErrGameNotFound):
		shared.EditError(sess, i, "Game not found.")
	case errors.Is(err, scoring.ErrMissingMVP):
		shared.EditError(sess, i, "Select at least one MVP or proceed without MVPs if allowed.")
	default:
		shared.EditError(sess, i, fmt.Sprintf("Failed to score game: %v", err))
	}
}

// StaffScore is a staff-only slash command to score a game directly (without proof upload).
type StaffScore struct{}

func NewStaffScore() *StaffScore { return &StaffScore{} }

func (c *StaffScore) Name() string { return "score" }

func (c *StaffScore) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:                     c.Name(),
		Description:              "Score a game (staff only).",
		DefaultMemberPermissions: &perm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "gameid",
				Description: "The game to score.",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionInteger,
				Name:        "winner",
				Description: "Winning team number.",
				Required:    true,
				Choices: []*discordgo.ApplicationCommandOptionChoice{
					{Name: "Team 1", Value: 1},
					{Name: "Team 2", Value: 2},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "mvp1",
				Description: "MVP #1 (optional).",
				Required:    false,
			},
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "mvp2",
				Description: "MVP #2 (optional).",
			},
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "mvp3",
				Description: "MVP #3 (optional).",
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "reason",
				Description: "Optional reason to include in logs.",
			},
		},
	}
}

func (c *StaffScore) Handle(sess *discordgo.Session, i *discordgo.InteractionCreate) {
	if i == nil || i.Member == nil || i.Member.User == nil {
		shared.RespondEphemeral(sess, i, "Only guild members may use this command.")
		return
	}

	var (
		gameID      string
		winningTeam int
		reason      string
		mvpIDs      []string
	)

	for _, opt := range i.ApplicationCommandData().Options {
		switch opt.Name {
		case "gameid":
			gameID = strings.TrimSpace(opt.StringValue())
		case "winner":
			winningTeam = int(opt.IntValue())
		case "reason":
			reason = strings.TrimSpace(opt.StringValue())
		case "mvp1", "mvp2", "mvp3":
			if user := opt.UserValue(sess); user != nil {
				mvpIDs = append(mvpIDs, user.ID)
			}
		}
	}

	if gameID == "" {
		shared.RespondEphemeral(sess, i, "Provide a valid game ID.")
		return
	}
	if winningTeam != 1 && winningTeam != 2 {
		shared.RespondEphemeral(sess, i, "Pick the winning team (1 or 2).")
		return
	}

	_ = sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	game, players, _, err := storage.GetGameWithPlayersActiveSeason(ctx, gameID)
	if err != nil {
		shared.EditError(sess, i, fmt.Sprintf("Failed to load game: %v", err))
		return
	}
	if game == nil || len(players) == 0 {
		shared.EditError(sess, i, "Game not found or has no players.")
		return
	}
	status := strings.ToUpper(strings.TrimSpace(game.Status))
	isVoided := status == "VOIDED"
	isCancelled := status == "CANCELLED"
	if status == "FINISHED" || status == "SCORED" {
		shared.EditError(sess, i, "This game has already been scored.")
		return
	}
	if isCancelled {
		shared.EditError(sess, i, "This game was cancelled and cannot be scored.")
		return
	}

	actions, warnings := shared.CleanupGameVoiceChannels(sess, i.GuildID, game, players)

	reasonText := fmt.Sprintf("Scored via /score by <@%s>", i.Member.User.ID)
	if isVoided {
		reasonText = fmt.Sprintf("%s (void override)", reasonText)
	}
	if reason != "" {
		reasonText = fmt.Sprintf("%s: %s", reasonText, reason)
	}

	result, err := scoring.ScoreGame(ctx, scoring.ScoreRequest{
		GameID:             gameID,
		WinningTeam:        winningTeam,
		Reason:             reasonText,
		MVPDiscordIDs:      mvpIDs,
		RequireParticipant: "",
		AllowRescore:       isVoided,
		AllowNoMVP:         true,
	})
	if err != nil {
		(&Score{}).respondScoreError(sess, i, err)
		return
	}

	refreshNicknamesFromScore(ctx, sess, i.GuildID, result.PlayerUpdates, "score")

	logChannelID, _ := storage.GetLogChannelID(ctx)
	(&Score{}).logScoreResult(sess, logChannelID, i, result)

	msgBuilder := strings.Builder{}
	msgBuilder.WriteString(fmt.Sprintf("Game `%s` scored. Team %d wins. MVPs: %s", gameID, winningTeam, scoring.FormatList(result.MVPMentions)))
	if len(actions) > 0 {
		msgBuilder.WriteString("\nVoice cleanup:")
		for _, a := range actions {
			msgBuilder.WriteString("\n- " + a)
		}
	}
	if isVoided {
		msgBuilder.WriteString("\nNote: game was previously voided; this rescore overwrote that state.")
	}
	if len(warnings) > 0 {
		msgBuilder.WriteString("\nWarnings:")
		for _, w := range warnings {
			msgBuilder.WriteString("\n- " + w)
		}
	}

	msg := msgBuilder.String()
	_, _ = sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
}

func (s *Score) createScoringCard(ctx context.Context, sess *discordgo.Session, guildID, submitterID, gameID, proofURL, notes, source string, allowScored bool) error {
	if sess == nil {
		return errors.New("session is nil")
	}
	game, players, _, err := storage.GetGameWithPlayersActiveSeason(ctx, gameID)
	if err != nil {
		return err
	}
	if game == nil {
		return errors.New("game not found")
	}
	status := strings.ToUpper(strings.TrimSpace(game.Status))
	isCancelled := status == "CANCELLED"
	isVoided := status == "VOIDED"
	if (status == "FINISHED" || status == "SCORED") && !allowScored {
		return errors.New("game already scored")
	}
	if isCancelled {
		return errors.New("game was cancelled")
	}
	if isVoided && !allowScored {
		return errors.New("game was voided")
	}
	if len(players) == 0 {
		return errors.New("no players recorded for this game")
	}

	transcriptLink := ""
	if game.ThreadSave.Valid {
		transcriptLink = strings.TrimSpace(game.ThreadSave.String)
	}

	storedProofURL := ""
	if game.ProofURL.Valid {
		storedProofURL = strings.TrimSpace(game.ProofURL.String)
	}
	effectiveProofURL := strings.TrimSpace(proofURL)
	if effectiveProofURL == "" {
		effectiveProofURL = storedProofURL
	}

	if strings.TrimSpace(proofURL) != "" && strings.ToLower(strings.TrimSpace(source)) != "refresh" {
		_ = storage.UpdateGameProof(ctx, game.ID, proofURL, submitterID)
	}

	var warnings []string
	if strings.ToLower(strings.TrimSpace(source)) != "refresh" {
		_, warnings = shared.CleanupGameVoiceChannels(sess, guildID, game, players)
	}

	team1, team2 := splitGamePlayers(players)
	names := s.playerNameMap(ctx, players)

	team1Mentions := formatTeamMentions(team1)
	team2Mentions := formatTeamMentions(team2)

	threadSource := formatSource(transcriptLink, game.ThreadID.String)
	action := "submitted proof"
	if strings.ToLower(strings.TrimSpace(source)) == "refresh" {
		action = "refreshed the scoring card"
	}
	content := fmt.Sprintf("<@%s> %s for game %s from %s.\nTeam 1: %s\nTeam 2: %s", submitterID, action, game.GameID, threadSource, team1Mentions, team2Mentions)
	content += fmt.Sprintf("\nType `/refresh %s` to resend this card if needed.", game.GameID)
	desc := fmt.Sprintf("Staff: select the winning team via the buttons below and (optionally) choose MVPs using the dropdown.\nProof: %s", effectiveProofURL)
	if isCancelled {
		desc = fmt.Sprintf("Status: **%s** (controls disabled)\nProof: %s", status, effectiveProofURL)
		if game.Reason.Valid && strings.TrimSpace(game.Reason.String) != "" {
			desc += fmt.Sprintf("\nReason: %s", strings.TrimSpace(game.Reason.String))
		}
	} else if isVoided {
		statusLine := fmt.Sprintf("Status: **%s**", status)
		if allowScored {
			statusLine += " - rescore will overwrite the void."
		} else {
			statusLine += " (controls disabled)"
		}
		desc = fmt.Sprintf("%s\nProof: %s", statusLine, effectiveProofURL)
		if game.Reason.Valid && strings.TrimSpace(game.Reason.String) != "" {
			desc += fmt.Sprintf("\nReason: %s", strings.TrimSpace(game.Reason.String))
		}
	}
	if notes != "" {
		desc += fmt.Sprintf("\nNotes: %s", notes)
	}
	if len(warnings) > 0 {
		desc += "\n\nWarnings:"
		for _, w := range warnings {
			desc += "\n- " + w
		}
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Game %s", game.GameID),
		Description: desc,
		Color:       0xf1c40f,
		Fields: []*discordgo.MessageEmbedField{
			{Name: "Team 1", Value: formatGameNames(team1, names), Inline: false},
			{Name: "Team 2", Value: formatGameNames(team2, names), Inline: false},
		},
	}
	if effectiveProofURL != "" {
		embed.Image = &discordgo.MessageEmbedImage{URL: effectiveProofURL}
	}

	mvpOptions := buildMVPOptions(team1, team2, names)
	maxMVP := len(mvpOptions)
	if maxMVP < 1 {
		maxMVP = 1
	}
	if maxMVP > 25 {
		maxMVP = 25
	}
	mvpSelect := discordgo.SelectMenu{
		CustomID:    mvpSelectPrefix + game.GameID,
		Placeholder: "Select MVPs (optional)",
		MinValues:   intPtr(0),
		MaxValues:   maxMVP,
		Options:     mvpOptions,
	}

	buttons := discordgo.ActionsRow{
		Components: []discordgo.MessageComponent{
			discordgo.Button{
				Label:    "Team 1 wins",
				Style:    discordgo.PrimaryButton,
				CustomID: winButtonPrefix + game.GameID + ":1",
				Emoji:    discordgo.ComponentEmoji{Name: "\u2705"},
			},
			discordgo.Button{
				Label:    "Team 2 wins",
				Style:    discordgo.PrimaryButton,
				CustomID: winButtonPrefix + game.GameID + ":2",
				Emoji:    discordgo.ComponentEmoji{Name: "\u2705"},
			},
		},
	}

	selectRow := discordgo.ActionsRow{Components: []discordgo.MessageComponent{mvpSelect}}
	confirmID := confirmButtonPrefix + game.GameID
	if allowScored {
		confirmID = confirmButtonPrefix + game.GameID + ":force"
	}
	confirmRow := discordgo.ActionsRow{
		Components: []discordgo.MessageComponent{
			discordgo.Button{
				Label:    "Confirm",
				Style:    discordgo.SuccessButton,
				CustomID: confirmID,
				Emoji:    discordgo.ComponentEmoji{Name: "\u2705"},
			},
			discordgo.Button{
				Label:    "Void",
				Style:    discordgo.DangerButton,
				CustomID: staffVoidButtonPrefix + game.GameID,
				Emoji:    discordgo.ComponentEmoji{Name: "\u274C"},
			},
		},
	}
	components := []discordgo.MessageComponent{buttons, selectRow, confirmRow}
	if isCancelled || (isVoided && !allowScored) {
		components = disableComponents(components)
	}
	_, err = sess.ChannelMessageSendComplex(s.scoringChannelID, &discordgo.MessageSend{
		Content:    content,
		Embeds:     []*discordgo.MessageEmbed{embed},
		Components: components,
	})
	return err
}

func (s *Score) captureAndDeleteThread(ctx context.Context, sess *discordgo.Session, guildID, season, gameID, recordID, threadID string) (string, error) {
	if sess == nil {
		return "", errors.New("session is nil")
	}
	gameID = strings.TrimSpace(gameID)
	threadID = strings.TrimSpace(threadID)
	guildID = strings.TrimSpace(guildID)
	if gameID == "" || threadID == "" {
		return "", nil
	}

	var transcriptLink string
	var firstErr error

	text, err := s.captureThreadTranscript(sess, threadID)
	if err != nil {
		fmt.Printf("score: failed to capture transcript for thread %s: %v\n", threadID, err)
		firstErr = err
	} else if strings.TrimSpace(text) != "" {
		if link, err := s.persistTranscript(ctx, sess, guildID, recordID, season, gameID, text); err != nil {
			fmt.Printf("score: failed to persist transcript for game %s: %v\n", gameID, err)
			if firstErr == nil {
				firstErr = err
			}
		} else {
			transcriptLink = link
		}
	}

	if _, err := sess.ChannelDelete(threadID); err != nil {
		fmt.Printf("score: failed to delete thread %s: %v\n", threadID, err)
		if firstErr == nil {
			firstErr = err
		}
	}
	return transcriptLink, firstErr
}

func (s *Score) persistTranscript(ctx context.Context, sess *discordgo.Session, guildID, recordID, season, gameID, text string) (string, error) {
	if sess == nil {
		return "", errors.New("session is nil")
	}
	gameID = strings.TrimSpace(gameID)
	if gameID == "" {
		return "", errors.New("game ID is required")
	}
	body := strings.TrimSpace(text)
	if body == "" {
		return "", nil
	}
	htmlPath, err := transcripts.Write(season, gameID, text)
	if err != nil {
		return "", err
	}
	defer func() {
		if htmlPath != "" {
			if err := os.Remove(htmlPath); err != nil && !errors.Is(err, os.ErrNotExist) {
				fmt.Printf("score: failed to remove transcript file %s: %v\n", htmlPath, err)
			}
		}
	}()

	channelID := strings.TrimSpace(s.transcriptChannelID)
	if channelID == "" {
		return "", nil
	}

	files := []*discordgo.File{}
	if htmlPath != "" {
		if data, err := os.ReadFile(htmlPath); err == nil {
			files = append(files, &discordgo.File{
				Name:        fmt.Sprintf("game_%s_transcript.html", gameID),
				ContentType: "text/html",
				Reader:      bytes.NewReader(data),
			})
		}
	}
	msg, err := sess.ChannelMessageSendComplex(channelID, &discordgo.MessageSend{
		Content: fmt.Sprintf("Transcript for game %s", gameID),
		Files:   files,
	})
	if err != nil {
		return "", err
	}
	if guildID == "" {
		return "", nil
	}
	link := fmt.Sprintf("https://discord.com/channels/%s/%s/%s", guildID, channelID, msg.ID)
	if link == "" || recordID == "" {
		return link, nil
	}
	if err := storage.UpdateGameTranscriptLink(ctx, recordID, link); err != nil {
		return link, err
	}
	return link, nil
}

func (s *Score) captureThreadTranscript(sess *discordgo.Session, threadID string) (string, error) {
	if sess == nil {
		return "", errors.New("session is nil")
	}
	threadID = strings.TrimSpace(threadID)
	if threadID == "" {
		return "", errors.New("thread ID is empty")
	}

	const batchSize = 100
	var all []*discordgo.Message
	before := ""
	for {
		msgs, err := sess.ChannelMessages(threadID, batchSize, before, "", "")
		if err != nil {
			return "", err
		}
		if len(msgs) == 0 {
			break
		}
		all = append(all, msgs...)
		if len(msgs) < batchSize {
			break
		}
		before = msgs[len(msgs)-1].ID
	}

	if len(all) == 0 {
		return "", nil
	}
	for i, j := 0, len(all)-1; i < j; i, j = i+1, j-1 {
		all[i], all[j] = all[j], all[i]
	}

	entries := make([]transcripts.TranscriptEntry, 0, len(all))
	for _, msg := range all {
		ts := msg.Timestamp
		if ts.IsZero() {
			ts = time.Now()
		}
		author := "Unknown"
		if msg.Member != nil && strings.TrimSpace(msg.Member.Nick) != "" {
			author = msg.Member.Nick
		} else if msg.Author != nil && strings.TrimSpace(msg.Author.Username) != "" {
			author = msg.Author.Username
		}
		content := strings.TrimSpace(msg.Content)
		if content == "" {
			content = "<no text>"
		}
		entry := transcripts.TranscriptEntry{
			Timestamp: ts.UTC(),
			Author:    author,
			Content:   content,
		}
		if msg.Author != nil {
			entry.AuthorID = strings.TrimSpace(msg.Author.ID)
		}
		for _, att := range msg.Attachments {
			if url := strings.TrimSpace(att.URL); url != "" {
				entry.Attachments = append(entry.Attachments, url)
			}
		}
		for _, embed := range msg.Embeds {
			if embed == nil {
				continue
			}
			e := transcripts.TranscriptEmbed{}
			if embed.Title != "" {
				e.Title = embed.Title
			}
			if embed.Description != "" {
				e.Description = embed.Description
			}
			if e.Title != "" || e.Description != "" {
				entry.Embeds = append(entry.Embeds, e)
			}
		}
		entries = append(entries, entry)
	}
	return formatTranscriptEntries(entries), nil
}

func formatTranscriptEntries(entries []transcripts.TranscriptEntry) string {
	var builder strings.Builder
	for idx, entry := range entries {
		builder.WriteString(fmt.Sprintf("[%s] ", entry.Timestamp.Format(time.RFC3339)))
		if entry.AuthorID != "" {
			builder.WriteString(fmt.Sprintf("%s (%s): ", entry.Author, entry.AuthorID))
		} else {
			builder.WriteString(fmt.Sprintf("%s: ", entry.Author))
		}
		builder.WriteString(entry.Content)
		builder.WriteString("\n")

		for _, att := range entry.Attachments {
			builder.WriteString("  Attachment: ")
			builder.WriteString(att)
			builder.WriteString("\n")
		}
		for _, embed := range entry.Embeds {
			if embed.Title != "" {
				builder.WriteString("  Embed title: ")
				builder.WriteString(embed.Title)
				builder.WriteString("\n")
			}
			if embed.Description != "" {
				builder.WriteString("  Embed desc: ")
				builder.WriteString(embed.Description)
				builder.WriteString("\n")
			}
		}
		if idx < len(entries)-1 {
			builder.WriteString("\n")
		}
	}
	return builder.String()
}

func (s *Score) handleWinSelection(sess *discordgo.Session, i *discordgo.InteractionCreate, gameID string, winningTeam int) {
	if sess == nil || i == nil {
		return
	}
	if i.Member == nil || i.Member.User == nil {
		shared.RespondEphemeral(sess, i, "Only guild members may use this control.")
		return
	}

	s.winSelections.Store(i.Message.ID, winningTeam)
	shared.RespondEphemeral(sess, i, fmt.Sprintf("Selected Team %d as winner. Press ✅ Confirm to score.", winningTeam))
}

func (s *Score) handleConfirmSelection(sess *discordgo.Session, i *discordgo.InteractionCreate, gameID string, allowRescore bool) {
	if sess == nil || i == nil {
		return
	}
	if i.Member == nil || i.Member.User == nil {
		shared.RespondEphemeral(sess, i, "Only guild members may use this control.")
		return
	}

	rawTeam, ok := s.winSelections.Load(i.Message.ID)
	if !ok {
		shared.RespondEphemeral(sess, i, "Select a winning team first using the team buttons.")
		return
	}
	winningTeam, _ := rawTeam.(int)

	mvpRaw, _ := s.mvpSelections.Load(i.Message.ID)
	mvpIDs, _ := mvpRaw.([]string)

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	if err := sess.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredMessageUpdate,
	}); err != nil {
		shared.RespondEphemeral(sess, i, fmt.Sprintf("Failed to acknowledge interaction: %v", err))
		return
	}

	result, err := scoring.ScoreGame(ctx, scoring.ScoreRequest{
		GameID:             gameID,
		WinningTeam:        winningTeam,
		Reason:             fmt.Sprintf("Scored via staff card by <@%s>", i.Member.User.ID),
		MVPDiscordIDs:      mvpIDs,
		RequireParticipant: "",
		AllowRescore:       allowRescore,
		AllowNoMVP:         true,
	})
	if err != nil {
		_, _ = sess.FollowupMessageCreate(i.Interaction, true, &discordgo.WebhookParams{
			Content: fmt.Sprintf("Failed to score: %v", err),
			Flags:   64,
		})
		return
	}

	refreshNicknamesFromScore(ctx, sess, i.GuildID, result.PlayerUpdates, "score")

	logChannelID, _ := storage.GetLogChannelID(ctx)
	s.logScoreResult(sess, logChannelID, i, result)

	// Disable components and show result.
	var components []discordgo.MessageComponent
	if i.Message != nil {
		components = disableComponents(i.Message.Components)
	}

	by := "unknown"
	if i != nil && i.Member != nil && i.Member.User != nil {
		by = fmt.Sprintf("<@%s>", i.Member.User.ID)
	}
	summary := fmt.Sprintf("Team %d wins. MVPs: %s\nScored by %s", winningTeam, scoring.FormatList(result.MVPMentions), by)
	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Game %s Scored", gameID),
		Description: summary,
		Color:       0x2ecc71,
	}

	content := i.Message.Content
	embeds := []*discordgo.MessageEmbed{embed}
	if _, err := sess.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Content:    &content,
		Embeds:     &embeds,
		Components: &components,
	}); err != nil {
		log.Printf("score: failed to edit scoring message: %v", err)
	}

	s.winSelections.Delete(i.Message.ID)
	s.mvpSelections.Delete(i.Message.ID)
}

func formatSource(transcriptLink, threadID string) string {
	if link := strings.TrimSpace(transcriptLink); link != "" {
		return fmt.Sprintf("[Transcript message](%s)", link)
	}
	threadID = strings.TrimSpace(threadID)
	if threadID == "" {
		return "unknown"
	}
	return fmt.Sprintf("<#%s>", threadID)
}

func userTag(user *discordgo.User) string {
	if user == nil {
		return ""
	}
	tag := strings.TrimSpace(user.Username)
	if user.Discriminator != "0" && strings.TrimSpace(user.Discriminator) != "" {
		tag = fmt.Sprintf("%s#%s", tag, strings.TrimSpace(user.Discriminator))
	}
	return tag
}

func seasonIDFromScoreResult(result *scoring.ScoreResult) string {
	if result == nil || result.Game == nil {
		return ""
	}
	if result.Game.SeasonID.Valid {
		if trimmed := strings.TrimSpace(result.Game.SeasonID.String); trimmed != "" {
			return trimmed
		}
	}
	if len(result.PlayerUpdates) > 0 {
		return strings.TrimSpace(result.PlayerUpdates[0].SeasonID)
	}
	return ""
}

func splitGamePlayers(players []storage.GamePlayerRecord) (team1, team2 []storage.GamePlayerRecord) {
	for _, p := range players {
		if p.DiscordTeam == 1 {
			team1 = append(team1, p)
		} else if p.DiscordTeam == 2 {
			team2 = append(team2, p)
		}
	}
	return
}

func (s *Score) playerNameMap(ctx context.Context, players []storage.GamePlayerRecord) map[string]string {
	var ids []string
	for _, p := range players {
		if strings.TrimSpace(p.PlayerID) != "" {
			ids = append(ids, p.PlayerID)
		}
	}
	names, err := storage.PlayerNameMap(ctx, ids)
	if err != nil {
		fmt.Printf("score: failed to load player names: %v\n", err)
		return map[string]string{}
	}
	return names
}

func formatGameNames(players []storage.GamePlayerRecord, nameMap map[string]string) string {
	if len(players) == 0 {
		return "None"
	}
	names := make([]string, 0, len(players))
	for _, p := range players {
		name := strings.TrimSpace(nameMap[p.PlayerID])
		if name == "" {
			name = formatMention(p.DiscordID)
		}
		if name == "" {
			name = p.DiscordID
		}
		names = append(names, name)
	}
	sort.Strings(names)
	return strings.Join(names, ", ")
}

func formatTeamMentions(players []storage.GamePlayerRecord) string {
	if len(players) == 0 {
		return "None"
	}
	parts := make([]string, 0, len(players))
	for _, p := range players {
		if mention := formatMention(p.DiscordID); mention != "" {
			parts = append(parts, mention)
			continue
		}
		if trimmed := strings.TrimSpace(p.PlayerID); trimmed != "" {
			parts = append(parts, trimmed)
			continue
		}
		parts = append(parts, "unknown")
	}
	return strings.Join(parts, ", ")
}

func buildMVPOptions(team1, team2 []storage.GamePlayerRecord, nameMap map[string]string) []discordgo.SelectMenuOption {
	var opts []discordgo.SelectMenuOption
	add := func(p storage.GamePlayerRecord) {
		label := strings.TrimSpace(nameMap[p.PlayerID])
		if label == "" {
			label = fmt.Sprintf("Player %s", p.DiscordID)
		}
		opt := discordgo.SelectMenuOption{
			Label:       fmt.Sprintf("%s (Team %d)", label, p.DiscordTeam),
			Value:       p.DiscordID,
			Description: fmt.Sprintf("Team %d", p.DiscordTeam),
			Emoji:       discordgo.ComponentEmoji{Name: "\u2705"},
		}
		opts = append(opts, opt)
	}
	for _, p := range team1 {
		add(p)
	}
	for _, p := range team2 {
		add(p)
	}
	return opts
}

func disableComponents(rows []discordgo.MessageComponent) []discordgo.MessageComponent {
	var out []discordgo.MessageComponent
	for _, row := range rows {
		ar, ok := row.(discordgo.ActionsRow)
		if !ok {
			if arp, okp := row.(*discordgo.ActionsRow); okp {
				ar = *arp
			} else {
				continue
			}
		}
		var comps []discordgo.MessageComponent
		for _, c := range ar.Components {
			switch v := c.(type) {
			case *discordgo.Button:
				cp := *v
				cp.Disabled = true
				comps = append(comps, &cp)
			case *discordgo.SelectMenu:
				cp := *v
				cp.Disabled = true
				comps = append(comps, &cp)
			default:
				comps = append(comps, c)
			}
		}
		out = append(out, discordgo.ActionsRow{Components: comps})
	}
	return out
}

func formatMention(id string) string {
	id = strings.TrimSpace(id)
	if id == "" {
		return ""
	}
	return fmt.Sprintf("<@%s>", id)
}

func attachmentID(opt *discordgo.ApplicationCommandInteractionDataOption) string {
	if opt == nil || opt.Value == nil {
		return ""
	}
	if v, ok := opt.Value.(string); ok {
		return v
	}
	return fmt.Sprintf("%v", opt.Value)
}

func resolveAttachment(i *discordgo.InteractionCreate, id string) *discordgo.MessageAttachment {
	if i == nil || id == "" {
		return nil
	}
	data := i.ApplicationCommandData()
	if data.Resolved == nil {
		return nil
	}
	if att, ok := data.Resolved.Attachments[id]; ok {
		return att
	}
	return nil
}

func intPtr(v int) *int {
	return &v
}
