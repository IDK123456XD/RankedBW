package staff

import (
	"context"
	"fmt"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Infocard struct{}

func NewInfocard() *Infocard     { return &Infocard{} }
func (c *Infocard) Name() string { return "infocard" }

func (c *Infocard) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:                     c.Name(),
		Description:              "Manage player info cards (staff only).",
		DefaultMemberPermissions: &perm,
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "grant",
				Description: "Grant an info card to a player.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "Player to grant the card to.",
						Required:    true,
					},
					{
						Type:         discordgo.ApplicationCommandOptionString,
						Name:         "card",
						Description:  "Card name or ID.",
						Required:     true,
						Autocomplete: true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "revoke",
				Description: "Revoke an info card from a player.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionUser,
						Name:        "user",
						Description: "Player to revoke the card from.",
						Required:    true,
					},
					{
						Type:         discordgo.ApplicationCommandOptionString,
						Name:         "card",
						Description:  "Card name or ID.",
						Required:     true,
						Autocomplete: true,
					},
				},
			},
		},
	}
}

func (c *Infocard) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !hasStaffPermission(i) {
		shared.RespondEphemeral(s, i, "You do not have permission to manage info cards.")
		return
	}
	data := i.ApplicationCommandData()
	if len(data.Options) == 0 {
		shared.RespondEphemeral(s, i, "Please choose a subcommand.")
		return
	}

	switch data.Options[0].Name {
	case "grant":
		c.handleGrant(s, i, data.Options[0])
	case "revoke":
		c.handleRevoke(s, i, data.Options[0])
	default:
		shared.RespondEphemeral(s, i, "Unknown infocard subcommand.")
	}
}

func (c *Infocard) HandleAutocomplete(s *discordgo.Session, i *discordgo.InteractionCreate) {
	focused := findFocusedOption(i.ApplicationCommandData().Options)
	if focused == nil || focused.Name != "card" {
		respondAutocomplete(s, i, nil)
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	cards, err := storage.SearchInfocards(ctx, focused.StringValue(), 25)
	if err != nil {
		respondAutocomplete(s, i, nil)
		return
	}

	choices := make([]*discordgo.ApplicationCommandOptionChoice, 0, len(cards))
	for _, card := range cards {
		name := card.Name
		if name == "" {
			name = card.ID
		}
		if len(name) > 100 {
			name = name[:100]
		}
		choices = append(choices, &discordgo.ApplicationCommandOptionChoice{
			Name:  name,
			Value: card.ID,
		})
	}
	respondAutocomplete(s, i, choices)
}

func (c *Infocard) handleGrant(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	opts := mapOptions(opt.Options)
	userOpt, ok := opts["user"]
	if !ok {
		shared.RespondEphemeral(s, i, "Please select a user.")
		return
	}
	cardOpt, ok := opts["card"]
	if !ok {
		shared.RespondEphemeral(s, i, "Please select a card.")
		return
	}
	target := userOpt.UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the selected user.")
		return
	}
	cardValue := strings.TrimSpace(cardOpt.StringValue())
	if cardValue == "" {
		shared.RespondEphemeral(s, i, "Please provide a card name or ID.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := storage.EnsurePlayerInfocardsTable(ctx); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to initialize locker table: %v", err))
		return
	}

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player profile: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "That user is not registered.")
		return
	}

	card, err := storage.ResolveInfocard(ctx, cardValue)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to resolve card: %v", err))
		return
	}
	if card == nil {
		shared.EditError(s, i, "That card was not found.")
		return
	}

	staffID := ""
	if i.Member != nil && i.Member.User != nil {
		staffID = i.Member.User.ID
	}
	if err := storage.GrantPlayerInfocard(ctx, player.ID, card.ID, staffID); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to grant card: %v", err))
		return
	}

	msg := fmt.Sprintf("Granted **%s** to %s.", card.Name, target.Mention())
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
	logInfocardChange(ctx, s, "Infocard Granted", 0x57F287, staffID, target.ID, card.Name, card.ID, "")
}

func (c *Infocard) handleRevoke(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	opts := mapOptions(opt.Options)
	userOpt, ok := opts["user"]
	if !ok {
		shared.RespondEphemeral(s, i, "Please select a user.")
		return
	}
	cardOpt, ok := opts["card"]
	if !ok {
		shared.RespondEphemeral(s, i, "Please select a card.")
		return
	}
	target := userOpt.UserValue(s)
	if target == nil {
		shared.RespondEphemeral(s, i, "Unable to resolve the selected user.")
		return
	}
	cardValue := strings.TrimSpace(cardOpt.StringValue())
	if cardValue == "" {
		shared.RespondEphemeral(s, i, "Please provide a card name or ID.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := storage.EnsurePlayerInfocardsTable(ctx); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to initialize locker table: %v", err))
		return
	}

	player, err := storage.GetPlayerByUserID(ctx, target.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load player profile: %v", err))
		return
	}
	if player == nil {
		shared.EditError(s, i, "That user is not registered.")
		return
	}

	card, err := storage.ResolveInfocard(ctx, cardValue)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to resolve card: %v", err))
		return
	}
	if card == nil {
		shared.EditError(s, i, "That card was not found.")
		return
	}

	staffID := ""
	if i.Member != nil && i.Member.User != nil {
		staffID = i.Member.User.ID
	}

	defaultID, err := storage.DefaultInfocardID(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load default card: %v", err))
		return
	}
	if card.ID == defaultID || strings.EqualFold(card.Name, "dark") || strings.EqualFold(card.Name, "light") {
		shared.EditError(s, i, "You cannot revoke the default light/dark cards.")
		return
	}

	removed, err := storage.RevokePlayerInfocard(ctx, player.ID, card.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to revoke card: %v", err))
		return
	}
	if !removed {
		msg := fmt.Sprintf("%s does not own **%s**.", target.Mention(), card.Name)
		_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
		return
	}

	selectedID := strings.TrimSpace(player.SelectedInfocardID.String)
	if player.SelectedInfocardID.Valid && selectedID == card.ID {
		if err := storage.GrantPlayerInfocard(ctx, player.ID, defaultID, ""); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to restore default card: %v", err))
			return
		}
		if err := storage.SetPlayerSelectedInfocard(ctx, player.ID, defaultID); err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to equip default card: %v", err))
			return
		}
		msg := fmt.Sprintf("Revoked **%s** from %s and equipped the default card.", card.Name, target.Mention())
		_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
		logInfocardChange(ctx, s, "Infocard Revoked", 0xED4245, staffID, target.ID, card.Name, card.ID, "Default card equipped")
		return
	}

	msg := fmt.Sprintf("Revoked **%s** from %s.", card.Name, target.Mention())
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
	logInfocardChange(ctx, s, "Infocard Revoked", 0xED4245, staffID, target.ID, card.Name, card.ID, "")
}

func respondAutocomplete(s *discordgo.Session, i *discordgo.InteractionCreate, choices []*discordgo.ApplicationCommandOptionChoice) {
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionApplicationCommandAutocompleteResult,
		Data: &discordgo.InteractionResponseData{Choices: choices},
	})
}

func findFocusedOption(options []*discordgo.ApplicationCommandInteractionDataOption) *discordgo.ApplicationCommandInteractionDataOption {
	for _, opt := range options {
		if opt.Focused {
			return opt
		}
		if opt.Type == discordgo.ApplicationCommandOptionSubCommand || opt.Type == discordgo.ApplicationCommandOptionSubCommandGroup {
			if nested := findFocusedOption(opt.Options); nested != nil {
				return nested
			}
		}
	}
	return nil
}

func mapOptions(opts []*discordgo.ApplicationCommandInteractionDataOption) map[string]*discordgo.ApplicationCommandInteractionDataOption {
	m := make(map[string]*discordgo.ApplicationCommandInteractionDataOption, len(opts))
	for _, opt := range opts {
		m[opt.Name] = opt
	}
	return m
}

func logInfocardChange(ctx context.Context, s *discordgo.Session, title string, color int, staffID, targetID, cardName, cardID, note string) {
	if ctx == nil || s == nil {
		return
	}
	channelID, err := storage.GetLogChannelID(ctx)
	if err != nil || strings.TrimSpace(channelID) == "" {
		return
	}
	lines := []string{
		fmt.Sprintf("**Staff:** %s", mentionOrID(staffID)),
		fmt.Sprintf("**Player:** %s", mentionOrID(targetID)),
		fmt.Sprintf("**Card:** %s", strings.TrimSpace(cardName)),
	}
	if strings.TrimSpace(cardID) != "" {
		lines = append(lines, fmt.Sprintf("**Card ID:** `%s`", strings.TrimSpace(cardID)))
	}
	if strings.TrimSpace(note) != "" {
		lines = append(lines, fmt.Sprintf("**Note:** %s", strings.TrimSpace(note)))
	}
	embed := &discordgo.MessageEmbed{
		Title:       strings.TrimSpace(title),
		Description: strings.Join(lines, "\n"),
		Color:       color,
		Timestamp:   time.Now().UTC().Format(time.RFC3339),
		Footer:      &discordgo.MessageEmbedFooter{Text: "Ranked Bedwars"},
	}
	_, _ = s.ChannelMessageSendEmbed(channelID, embed)
}

func mentionOrID(id string) string {
	id = strings.TrimSpace(id)
	if id == "" {
		return "unknown"
	}
	return fmt.Sprintf("<@%s>", id)
}
