package embeds

import (
	"log"
	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Rules struct{}

func NewRules() *Rules        { return &Rules{} }
func (r *Rules) Name() string { return "rules" }

func (r *Rules) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        r.Name(),
		Description: "Display the current season ruleset.",
	}
}

func (r *Rules) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	// Defer to avoid timeouts
	if err := s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	}); err != nil {
		log.Printf("/rules defer error: %v", err)
		return
	}

	content, err := storage.LoadRuleset()
	if err != nil || content == "" {
		msg := "No ruleset has been uploaded yet. Use `/settings ruleset`."
		_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &msg})
		return
	}

	emb := &discordgo.MessageEmbed{
		Title:       "Season Rules",
		Description: content,
		Thumbnail:   &discordgo.MessageEmbedThumbnail{URL: shared.BotAvatarURL(s)},
		Color:       0x004CFF,
	}
	embeds := []*discordgo.MessageEmbed{emb}
	_, err = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &embeds,
	})
	if err != nil {
		log.Printf("/rules edit error: %v", err)
	}
}
