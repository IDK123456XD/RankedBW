package howtoregister

import (
	"fmt"

	"github.com/bwmarrin/discordgo"
)

type HowToRegister struct{}

func New() *HowToRegister             { return &HowToRegister{} }
func (c *HowToRegister) Name() string { return "howtoregister" }

func (c *HowToRegister) Build() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Show the 'How To Register' embed.",
	}
}

func (c *HowToRegister) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	registerChannelID := "1437267495156191314"
	registerChannelMention := fmt.Sprintf("<#%s>", registerChannelID)

	desc := "**Link your current Discord Username to your Hypixel Account**\n\n" +
		fmt.Sprintf("Run `/register (Username)` in %s\n", registerChannelMention) +
		"*Changes might take up to a few minutes to take effect.*"

	embed := &discordgo.MessageEmbed{
		Title:       "Wondering how to get registered?",
		Description: desc,
		Image: &discordgo.MessageEmbedImage{
			URL: "https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExbDM5eGNlajdzNzh5N2ttNzkxNGhmM3B1ajl0dTZkMzc3bDFnamJxYiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/vzOPo3G826KvydyuwS/giphy.gif",
		},
		Color:  0x004CFF,
		Footer: &discordgo.MessageEmbedFooter{Text: "Ranked Bedwars"},
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
			Flags:  64,
		},
	})
}
