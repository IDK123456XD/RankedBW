package types

import "github.com/bwmarrin/discordgo"

// Slash represents a slash command definition + handler.
type Slash interface {
	Build() *discordgo.ApplicationCommand
	Handle(s *discordgo.Session, i *discordgo.InteractionCreate)
	Name() string
}

// ComponentHandler handles interactive component callbacks (e.g., select menus).
type ComponentHandler interface {
	HandleComponent(s *discordgo.Session, i *discordgo.InteractionCreate) bool
}

// ModalHandler processes modal submit interactions.
type ModalHandler interface {
	HandleModal(s *discordgo.Session, i *discordgo.InteractionCreate) bool
}

// Autocomplete allows a slash command to respond to autocomplete interactions.
type Autocomplete interface {
	HandleAutocomplete(s *discordgo.Session, i *discordgo.InteractionCreate)
}

// SessionAware allows a command or handler to receive the bot session on startup.
type SessionAware interface {
	SetSession(s *discordgo.Session)
}
