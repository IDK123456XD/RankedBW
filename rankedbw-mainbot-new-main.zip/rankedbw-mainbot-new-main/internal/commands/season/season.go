package season

import (
	"context"
	"fmt"
	"log"
	"strings"
	"time"

	"rbw-bot/internal/commands/shared"
	"rbw-bot/internal/storage"

	"github.com/bwmarrin/discordgo"
)

type Command struct{}

func NewSeason() *Command       { return &Command{} }
func (c *Command) Name() string { return "season" }

func (c *Command) Build() *discordgo.ApplicationCommand {
	perm := int64(discordgo.PermissionAdministrator)
	return &discordgo.ApplicationCommand{
		Name:        c.Name(),
		Description: "Manage Ranked Bedwars seasons.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "editname",
				Description: "Rename a season.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:         discordgo.ApplicationCommandOptionString,
						Name:         "season",
						Description:  "Existing season name.",
						Required:     true,
						Autocomplete: true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "new_name",
						Description: "New name for the season.",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "info",
				Description: "Get information about a season.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:         discordgo.ApplicationCommandOptionString,
						Name:         "season",
						Description:  "Season name (defaults to current season).",
						Autocomplete: true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "end",
				Description: "End the current active season.",
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "setmaxgames",
				Description: "Set the max scored games for the active season.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionInteger,
						Name:        "max_games",
						Description: "Max scored games (0 to clear).",
						Required:    true,
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "archive",
				Description: "Toggle archive status of a season.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:         discordgo.ApplicationCommandOptionString,
						Name:         "season",
						Description:  "Season name to toggle (defaults to active).",
						Autocomplete: true,
					},
					{
						Type:        discordgo.ApplicationCommandOptionBoolean,
						Name:        "archived",
						Description: "Whether the season should be archived (defaults to toggle).",
					},
				},
			},
			{
				Type:        discordgo.ApplicationCommandOptionSubCommand,
				Name:        "start",
				Description: "Start a new season.",
				Options: []*discordgo.ApplicationCommandOption{
					{
						Type:        discordgo.ApplicationCommandOptionString,
						Name:        "name",
						Description: "Name of the new season.",
						Required:    true,
					},
				},
			},
		},
		DefaultMemberPermissions: &perm,
	}
}

func (c *Command) Handle(s *discordgo.Session, i *discordgo.InteractionCreate) {
	data := i.ApplicationCommandData()
	if len(data.Options) == 0 {
		shared.RespondEphemeral(s, i, "Please choose a subcommand.")
		return
	}
	switch data.Options[0].Name {
	case "editname":
		c.handleEditName(s, i, data.Options[0])
	case "info":
		c.handleInfo(s, i, data.Options[0])
	case "end":
		c.handleEnd(s, i)
	case "setmaxgames":
		c.handleSetMaxGames(s, i, data.Options[0])
	case "archive":
		c.handleArchive(s, i, data.Options[0])
	case "start":
		c.handleStart(s, i, data.Options[0])
	default:
		shared.RespondEphemeral(s, i, "That season command is not implemented yet.")
	}
}

func (c *Command) handleEditName(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	opts := mapOptions(opt.Options)
	seasonOpt, ok := opts["season"]
	if !ok {
		shared.RespondEphemeral(s, i, "Please select a season to rename.")
		return
	}
	newNameOpt, ok := opts["new_name"]
	if !ok {
		shared.RespondEphemeral(s, i, "Please provide the new name.")
		return
	}

	oldName := strings.TrimSpace(seasonOpt.StringValue())
	newName := strings.TrimSpace(newNameOpt.StringValue())
	if oldName == "" || newName == "" {
		shared.RespondEphemeral(s, i, "Both season names must be provided.")
		return
	}
	if strings.EqualFold(oldName, newName) {
		shared.RespondEphemeral(s, i, "The new name must be different from the current name.")
		return
	}
	if len(newName) > 100 {
		shared.RespondEphemeral(s, i, "Season names must be 100 characters or fewer.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	season, err := storage.SeasonByName(ctx, oldName)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to load season: %v", err))
		return
	}
	if season == nil {
		shared.EditError(s, i, fmt.Sprintf("Season \"%s\" was not found.", oldName))
		return
	}

	existing, err := storage.SeasonByName(ctx, newName)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to validate new name: %v", err))
		return
	}
	if existing != nil {
		shared.EditError(s, i, fmt.Sprintf("A season named \"%s\" already exists.", newName))
		return
	}

	if err := storage.UpdateSeasonName(ctx, season.ID, newName); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to rename season: %v", err))
		return
	}

	response := fmt.Sprintf("Season \"%s\" has been renamed to \"%s\".", season.Name, newName)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &response})
}

func (c *Command) HandleAutocomplete(s *discordgo.Session, i *discordgo.InteractionCreate) {
	focused := findFocusedOption(i.ApplicationCommandData().Options)
	if focused == nil || focused.Name != "season" {
		respondAutocomplete(s, i, nil)
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	seasons, err := storage.SearchSeasons(ctx, focused.StringValue(), 25)
	if err != nil {
		log.Printf("season autocomplete failed: %v", err)
		respondAutocomplete(s, i, nil)
		return
	}

	choices := make([]*discordgo.ApplicationCommandOptionChoice, 0, len(seasons))
	for _, season := range seasons {
		name := season.Name
		if len(name) > 100 {
			name = name[:100]
		}
		choices = append(choices, &discordgo.ApplicationCommandOptionChoice{
			Name:  name,
			Value: season.Name,
		})
	}
	respondAutocomplete(s, i, choices)
}

func (c *Command) handleInfo(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	var seasonName string
	if len(opt.Options) > 0 {
		seasonName = strings.TrimSpace(opt.Options[0].StringValue())
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var (
		season *storage.SeasonRecord
		err    error
	)

	if seasonName == "" {
		season, err = storage.ActiveSeason(ctx)
		if err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to load active season: %v", err))
			return
		}
		if season == nil {
			shared.EditError(s, i, "There is no active season currently.")
			return
		}
	} else {
		season, err = storage.SeasonByName(ctx, seasonName)
		if err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to load season: %v", err))
			return
		}
		if season == nil {
			shared.EditError(s, i, fmt.Sprintf("Season \"%s\" was not found.", seasonName))
			return
		}
	}

	gameCount, err := storage.SeasonGameCount(ctx, season.ID)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to count games: %v", err))
		return
	}

	topPlayers, err := storage.TopPlayersForSeason(ctx, season.ID, 3)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch top players: %v", err))
		return
	}

	status := "Ended"
	if season.Active {
		status = "Active"
	}

	startUnix := season.StartDate.UTC().Unix()
	description := fmt.Sprintf("**Season Name:** %s\n**Status:** %s\n**Start Date:** <t:%d:F>\n", season.Name, status, startUnix)
	if season.EndDate.Valid {
		description += fmt.Sprintf("**End Date:** <t:%d:F>\n", season.EndDate.Time.UTC().Unix())
	}
	if season.MaxGames.Valid {
		description += fmt.Sprintf("**Max Scored Games:** %d\n", season.MaxGames.Int32)
	}
	description += fmt.Sprintf("**Games Played:** %d\n", gameCount)
	if season.Archived {
		description += "**This season is archived.**\n"
	}

	description += "\n**Top Players:**\n"
	if len(topPlayers) == 0 {
		description += "No top players yet."
	} else {
		lines := make([]string, 0, len(topPlayers))
		for _, entry := range topPlayers {
			lines = append(lines, fmt.Sprintf("%d. %s (%d ELO)", entry.Position, entry.MinecraftName, entry.FinalElo))
		}
		description += strings.Join(lines, "\n")
	}

	embed := &discordgo.MessageEmbed{
		Title:       "Season Information",
		Description: description,
		Color:       0x5865F2,
		Footer:      &discordgo.MessageEmbedFooter{Text: "Ranked Bedwars"},
	}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{embed},
	})
}

func (c *Command) handleEnd(s *discordgo.Session, i *discordgo.InteractionCreate) {
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()

	season, err := storage.ActiveSeason(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch active season: %v", err))
		return
	}
	if season == nil {
		shared.EditError(s, i, "There is no active season to end.")
		return
	}

	leaders, err := storage.SeasonLeaders(ctx, season.ID, 3)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to gather top players: %v", err))
		return
	}
	if err := storage.ReplaceSeasonTopPlayers(ctx, season.ID, leaders); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to record top players: %v", err))
		return
	}

	if err := storage.EndSeason(ctx, season.ID, time.Now().UTC()); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to end the season: %v", err))
		return
	}

	topPlayersDesc := "No top players recorded."
	if len(leaders) > 0 {
		lines := make([]string, 0, len(leaders))
		for _, leader := range leaders {
			lines = append(lines, fmt.Sprintf("%d. %s (%d ELO)", leader.Position, leader.MinecraftName, leader.FinalElo))
		}
		topPlayersDesc = strings.Join(lines, "\n")
	}

	description := fmt.Sprintf("Season **%s** has been ended.\n\n**Top Players:**\n%s\n\nA new season can now be started.", season.Name, topPlayersDesc)
	embed := &discordgo.MessageEmbed{
		Title:       "Season Ended",
		Description: description,
		Color:       0xED4245,
		Timestamp:   time.Now().Format(time.RFC3339),
		Footer:      &discordgo.MessageEmbedFooter{Text: "Ranked Bedwars"},
	}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{embed},
	})
}

func (c *Command) handleSetMaxGames(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	opts := mapOptions(opt.Options)
	valOpt, ok := opts["max_games"]
	if !ok {
		shared.RespondEphemeral(s, i, "Please provide the max games amount.")
		return
	}

	value := valOpt.IntValue()
	if value < -1 {
		shared.RespondEphemeral(s, i, "Please provide a valid number (0 or greater).")
		return
	}
	if value > 10000 {
		shared.RespondEphemeral(s, i, "Max games must be 10,000 or fewer.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	season, err := storage.ActiveSeason(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch active season: %v", err))
		return
	}
	if season == nil {
		shared.EditError(s, i, "There is no active season.")
		return
	}

	var ptr *int
	var message string
	if value <= 0 {
		message = fmt.Sprintf("Cleared the max scored games limit for **%s**.", season.Name)
	} else {
		v := int(value)
		ptr = &v
		message = fmt.Sprintf("Set the max scored games for **%s** to **%d**.", season.Name, v)
	}

	if err := storage.UpdateSeasonMaxGames(ctx, season.ID, ptr); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update max games: %v", err))
		return
	}

	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (c *Command) handleArchive(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	opts := mapOptions(opt.Options)
	var (
		seasonName string
		explicit   *bool
	)
	if seasonOpt, ok := opts["season"]; ok {
		seasonName = strings.TrimSpace(seasonOpt.StringValue())
	}
	if archOpt, ok := opts["archived"]; ok {
		val := archOpt.BoolValue()
		explicit = &val
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	var (
		season *storage.SeasonRecord
		err    error
	)

	if seasonName == "" {
		season, err = storage.ActiveSeason(ctx)
		if err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to fetch active season: %v", err))
			return
		}
		if season == nil {
			shared.EditError(s, i, "Please provide a season name; there is no active season.")
			return
		}
	} else {
		season, err = storage.SeasonByName(ctx, seasonName)
		if err != nil {
			shared.EditError(s, i, fmt.Sprintf("Failed to load season: %v", err))
			return
		}
		if season == nil {
			shared.EditError(s, i, fmt.Sprintf("Season \"%s\" was not found.", seasonName))
			return
		}
	}

	targetArchived := !season.Archived
	if explicit != nil {
		targetArchived = *explicit
	}

	if err := storage.SetSeasonArchived(ctx, season.ID, targetArchived); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to update season: %v", err))
		return
	}

	state := "unarchived"
	if targetArchived {
		state = "archived"
	}
	message := fmt.Sprintf("Season **%s** is now %s.", season.Name, state)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func (c *Command) handleStart(s *discordgo.Session, i *discordgo.InteractionCreate, opt *discordgo.ApplicationCommandInteractionDataOption) {
	opts := mapOptions(opt.Options)
	nameOpt, ok := opts["name"]
	if !ok {
		shared.RespondEphemeral(s, i, "Please provide a season name.")
		return
	}
	name := strings.TrimSpace(nameOpt.StringValue())
	if name == "" {
		shared.RespondEphemeral(s, i, "Season name cannot be empty.")
		return
	}
	if len(name) > 100 {
		shared.RespondEphemeral(s, i, "Season name must be 100 characters or fewer.")
		return
	}

	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Flags: 64},
	})

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	if current, err := storage.ActiveSeason(ctx); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to check active season: %v", err))
		return
	} else if current != nil {
		shared.EditError(s, i, fmt.Sprintf("Season \"%s\" is currently active. End it before starting a new one.", current.Name))
		return
	}

	if existing, err := storage.SeasonByName(ctx, name); err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to validate season name: %v", err))
		return
	} else if existing != nil {
		shared.EditError(s, i, fmt.Sprintf("A season named \"%s\" already exists.", existing.Name))
		return
	}

	season, err := storage.CreateSeason(ctx, name)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to create season: %v", err))
		return
	}

	playerIDs, err := storage.AllPlayerIDs(ctx)
	if err != nil {
		shared.EditError(s, i, fmt.Sprintf("Failed to fetch players: %v", err))
		return
	}

	created := 0
	for _, playerID := range playerIDs {
		if err := storage.EnsurePlayerSeasonStats(ctx, playerID, season.ID); err != nil {
			log.Printf("season start: failed to create stats for %s: %v", playerID, err)
			continue
		}
		created++
	}

	// Reset nicknames to reflect fresh 0 Elo.
	updatedNicks := 0
	if s != nil && strings.TrimSpace(i.GuildID) != "" {
		for _, playerID := range playerIDs {
			player, err := storage.GetPlayerByID(ctx, playerID)
			if err != nil || player == nil {
				continue
			}
			stats, err := storage.GetPlayerSeasonStats(ctx, player.ID, season.ID)
			if err != nil || stats == nil {
				continue
			}
			shared.ApplyNickname(s, i.GuildID, player, stats, "season start")
			updatedNicks++
		}
	}

	message := fmt.Sprintf("Season **%s** has been started. Initialized stats for %d player(s). Updated %d nickname(s).", season.Name, created, updatedNicks)
	_, _ = s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{Content: &message})
}

func respondAutocomplete(s *discordgo.Session, i *discordgo.InteractionCreate, choices []*discordgo.ApplicationCommandOptionChoice) {
	_ = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionApplicationCommandAutocompleteResult,
		Data: &discordgo.InteractionResponseData{Choices: choices},
	})
}

func findFocusedOption(options []*discordgo.ApplicationCommandInteractionDataOption) *discordgo.ApplicationCommandInteractionDataOption {
	for _, opt := range options {
		if opt.Focused {
			return opt
		}
		if opt.Type == discordgo.ApplicationCommandOptionSubCommand || opt.Type == discordgo.ApplicationCommandOptionSubCommandGroup {
			if nested := findFocusedOption(opt.Options); nested != nil {
				return nested
			}
		}
	}
	return nil
}

func mapOptions(opts []*discordgo.ApplicationCommandInteractionDataOption) map[string]*discordgo.ApplicationCommandInteractionDataOption {
	m := make(map[string]*discordgo.ApplicationCommandInteractionDataOption, len(opts))
	for _, opt := range opts {
		m[opt.Name] = opt
	}
	return m
}
