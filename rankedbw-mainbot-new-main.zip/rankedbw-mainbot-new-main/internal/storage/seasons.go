package storage

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"
)

// SeasonRecord mirrors the Season table, allowing commands to pull metadata.
type SeasonRecord struct {
	ID        string
	Name      string
	StartDate time.Time
	EndDate   sql.NullTime
	Ruleset   string
	Archived  bool
	Active    bool
	CreatedAt time.Time
	UpdatedAt time.Time
	MaxGames  sql.NullInt32
}

// SeasonByName fetches a single season by case-insensitive name.
func SeasonByName(ctx context.Context, name string) (*SeasonRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var rec SeasonRecord
	err = conn.QueryRowContext(ctx, `
		SELECT id,name,"startDate","endDate",ruleset,archived,active,"createdAt","updatedAt","maxGames"
		  FROM "Season"
		 WHERE lower(name) = lower($1)
		 LIMIT 1
	`, strings.TrimSpace(name)).Scan(
		&rec.ID,
		&rec.Name,
		&rec.StartDate,
		&rec.EndDate,
		&rec.Ruleset,
		&rec.Archived,
		&rec.Active,
		&rec.CreatedAt,
		&rec.UpdatedAt,
		&rec.MaxGames,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &rec, nil
}

// SeasonByID fetches a single season by ID.
func SeasonByID(ctx context.Context, id string) (*SeasonRecord, error) {
	id = strings.TrimSpace(id)
	if id == "" {
		return nil, errors.New("season id is required")
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var rec SeasonRecord
	err = conn.QueryRowContext(ctx, `
		SELECT id,name,"startDate","endDate",ruleset,archived,active,"createdAt","updatedAt","maxGames"
		  FROM "Season"
		 WHERE id = $1
		 LIMIT 1
	`, id).Scan(
		&rec.ID,
		&rec.Name,
		&rec.StartDate,
		&rec.EndDate,
		&rec.Ruleset,
		&rec.Archived,
		&rec.Active,
		&rec.CreatedAt,
		&rec.UpdatedAt,
		&rec.MaxGames,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &rec, nil
}

// ActiveSeason returns the currently active season or nil if not found.
func ActiveSeason(ctx context.Context) (*SeasonRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var rec SeasonRecord
	err = conn.QueryRowContext(ctx, `
		SELECT id,name,"startDate","endDate",ruleset,archived,active,"createdAt","updatedAt","maxGames"
		  FROM "Season"
		 WHERE active = true
		 ORDER BY "startDate" DESC
		 LIMIT 1
	`).Scan(
		&rec.ID,
		&rec.Name,
		&rec.StartDate,
		&rec.EndDate,
		&rec.Ruleset,
		&rec.Archived,
		&rec.Active,
		&rec.CreatedAt,
		&rec.UpdatedAt,
		&rec.MaxGames,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &rec, nil
}

// SearchSeasons returns up to limit seasons containing the term (case-insensitive).
func SearchSeasons(ctx context.Context, term string, limit int) ([]SeasonRecord, error) {
	if limit <= 0 {
		limit = 25
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	like := "%"
	if trimmed := strings.TrimSpace(term); trimmed != "" {
		like = "%" + strings.ToLower(trimmed) + "%"
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id,name,"startDate","endDate",ruleset,archived,active,"createdAt","updatedAt","maxGames"
		  FROM "Season"
		 WHERE lower(name) LIKE $1
		 ORDER BY "createdAt" DESC
		 LIMIT $2
	`, like, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []SeasonRecord
	for rows.Next() {
		var rec SeasonRecord
		if err := rows.Scan(
			&rec.ID,
			&rec.Name,
			&rec.StartDate,
			&rec.EndDate,
			&rec.Ruleset,
			&rec.Archived,
			&rec.Active,
			&rec.CreatedAt,
			&rec.UpdatedAt,
			&rec.MaxGames,
		); err != nil {
			return nil, err
		}
		list = append(list, rec)
	}
	return list, rows.Err()
}

// UpdateSeasonName renames a season by ID.
func UpdateSeasonName(ctx context.Context, seasonID, newName string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	newName = strings.TrimSpace(newName)
	if newName == "" {
		return errors.New("season name cannot be empty")
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Season"
		   SET name = $2,
		       "updatedAt" = now()
		 WHERE id = $1
	`, seasonID, newName)
	return err
}

// SeasonGameCount returns the number of scored games for the specified season.
func SeasonGameCount(ctx context.Context, seasonID string) (int, error) {
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var count int
	err = conn.QueryRowContext(ctx, `
		SELECT COUNT(1)
		  FROM "Game"
		 WHERE "seasonId" = $1
		   AND upper(status::text) IN ('FINISHED','SCORED')
	`, seasonID).Scan(&count)
	return count, err
}

type SeasonTopPlayer struct {
	Position      int
	FinalElo      int
	PlayerID      string
	MinecraftName string
}

// TopPlayersForSeason returns ordered top player entries for the season.
func TopPlayersForSeason(ctx context.Context, seasonID string, limit int) ([]SeasonTopPlayer, error) {
	if limit <= 0 {
		limit = 3
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT stp."position",
		       stp."finalElo",
		       p.id,
		       p."minecraftName"
		  FROM "SeasonTopPlayer" stp
		  JOIN "Player" p ON p.id = stp."playerId"
		 WHERE stp."seasonId" = $1
		 ORDER BY stp."position" ASC
		 LIMIT $2
	`, seasonID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []SeasonTopPlayer
	for rows.Next() {
		var entry SeasonTopPlayer
		if err := rows.Scan(&entry.Position, &entry.FinalElo, &entry.PlayerID, &entry.MinecraftName); err != nil {
			return nil, err
		}
		list = append(list, entry)
	}
	return list, rows.Err()
}

// SeasonLeaders returns leaderboard rows ordered by elo for the season.
func SeasonLeaders(ctx context.Context, seasonID string, limit int) ([]SeasonTopPlayer, error) {
	if limit <= 0 {
		limit = 3
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT ps."playerId",
		       ps.elo,
		       p."minecraftName"
		  FROM "PlayerStatistics" ps
		  JOIN "Player" p ON p.id = ps."playerId"
		 WHERE ps."seasonId" = $1
		 ORDER BY ps.elo DESC, ps."gamesPlayed" DESC
		 LIMIT $2
	`, seasonID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var leaders []SeasonTopPlayer
	position := 1
	for rows.Next() {
		var leader SeasonTopPlayer
		leader.Position = position
		position++
		if err := rows.Scan(&leader.PlayerID, &leader.FinalElo, &leader.MinecraftName); err != nil {
			return nil, err
		}
		leaders = append(leaders, leader)
	}
	return leaders, rows.Err()
}

// ReplaceSeasonTopPlayers overwrites the stored top player rows for a season.
func ReplaceSeasonTopPlayers(ctx context.Context, seasonID string, leaders []SeasonTopPlayer) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	if _, err = tx.ExecContext(ctx, `DELETE FROM "SeasonTopPlayer" WHERE "seasonId"=$1`, seasonID); err != nil {
		return err
	}

	for _, leader := range leaders {
		if strings.TrimSpace(leader.PlayerID) == "" {
			continue
		}
		id, idErr := randomHexID()
		if idErr != nil {
			return idErr
		}
		if _, err = tx.ExecContext(ctx, `
			INSERT INTO "SeasonTopPlayer"
				(id,"playerId","finalElo","position","seasonId")
			VALUES ($1,$2,$3,$4,$5)
		`, id, leader.PlayerID, leader.FinalElo, leader.Position, seasonID); err != nil {
			return err
		}
	}

	return tx.Commit()
}

// EndSeason marks a season inactive and sets the end timestamp.
func EndSeason(ctx context.Context, seasonID string, endedAt time.Time) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Season"
		   SET active = false,
		       "endDate" = $2,
		       "updatedAt" = now()
		 WHERE id = $1
	`, seasonID, endedAt.UTC())
	return err
}

// UpdateSeasonMaxGames sets or clears the max scored games for a season.
func UpdateSeasonMaxGames(ctx context.Context, seasonID string, maxGames *int) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	var value interface{}
	if maxGames == nil {
		value = nil
	} else {
		value = *maxGames
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Season"
		   SET "maxGames" = $2,
		       "updatedAt" = now()
		 WHERE id = $1
	`, seasonID, value)
	return err
}

// SetSeasonArchived toggles the archived flag for a season.
func SetSeasonArchived(ctx context.Context, seasonID string, archived bool) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Season"
		   SET archived = $2,
		       "updatedAt" = now()
		 WHERE id = $1
	`, seasonID, archived)
	return err
}

// CreateSeason inserts and returns a new active season with the provided name.
func CreateSeason(ctx context.Context, name string) (*SeasonRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	name = strings.TrimSpace(name)
	if name == "" {
		return nil, errors.New("season name cannot be empty")
	}
	id, err := randomHexID()
	if err != nil {
		return nil, err
	}
	now := time.Now().UTC()
	if _, err := conn.ExecContext(ctx, `
		INSERT INTO "Season"
			(id,name,"startDate","active","archived","createdAt","updatedAt")
		VALUES ($1,$2,$3,true,false,$3,$3)
	`, id, name, now); err != nil {
		return nil, err
	}
	return &SeasonRecord{
		ID:        id,
		Name:      name,
		StartDate: now,
		Archived:  false,
		Active:    true,
		CreatedAt: now,
		UpdatedAt: now,
		Ruleset:   "",
	}, nil
}

// SeasonRankPosition returns the leaderboard position (1-based) for a player by Elo.
// Ties are ordered by greater-than comparison only, matching the legacy behavior.
func SeasonRankPosition(ctx context.Context, seasonID, playerID string, elo int) (int, error) {
	seasonID = strings.TrimSpace(seasonID)
	if seasonID == "" {
		return 0, nil
	}
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var pos int
	err = conn.QueryRowContext(ctx, `
		SELECT 1 + COUNT(1)
		  FROM "PlayerStatistics"
		 WHERE "seasonId" = $1
		   AND elo > $2
	`, seasonID, elo).Scan(&pos)
	return pos, err
}
