package storage

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"
)

type ScoreUpdate struct {
	GamePlayerID string
	PlayerID     string
	StatsID      string
	SeasonID     string
	Win          bool
	MVP          bool
	NewElo       int
	EloDiff      int
	XPDelta      int
	Streak       int
	EloReason    string
	ExtraReason  string
	SkipStats    bool
}

type UnscoreUpdate struct {
	GamePlayerID string
	PlayerID     string
	StatsID      string
	SeasonID     string
	Win          bool
	MVP          bool
	XPDelta      int
	Streak       int
	NewElo       int
	ExtraReason  string
	SkipStats    bool
}

func ApplyGameScore(ctx context.Context, gameID string, reason string, updates []ScoreUpdate) (err error) {
	if len(updates) == 0 {
		return errors.New("no player updates provided")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	var reasonValue interface{}
	if trimmed := strings.TrimSpace(reason); trimmed != "" {
		reasonValue = trimmed
	} else {
		reasonValue = nil
	}
	if _, err = tx.ExecContext(ctx, `
		UPDATE "Game"
		   SET status='SCORED',
		       reason=$2,
		       "updatedAt"=now()
		 WHERE id=$1
	`, gameID, reasonValue); err != nil {
		return err
	}

	for _, update := range updates {
		if err = applyScoreForPlayer(ctx, tx, update); err != nil {
			return err
		}
	}

	return tx.Commit()
}

func applyScoreForPlayer(ctx context.Context, tx *sql.Tx, update ScoreUpdate) error {
	if _, err := tx.ExecContext(ctx, `
		UPDATE "GamePlayer"
		   SET win=$2,
		       mvp=$3,
		       "postElo"=$4,
		       "eloDiff"=$5
		 WHERE id=$1
	`, update.GamePlayerID, update.Win, update.MVP, update.NewElo, update.EloDiff); err != nil {
		return err
	}
	if update.SkipStats {
		return nil
	}

	winInc := boolToInt(update.Win)
	lossInc := boolToInt(!update.Win)
	mvpInc := boolToInt(update.MVP)
	if _, err := tx.ExecContext(ctx, `
		UPDATE "PlayerStatistics"
		   SET "elo"=$2,
		       "peakElo"=GREATEST("peakElo",$2),
		       "wins"="wins"+$3,
		       "losses"="losses"+$4,
		       "mvps"="mvps"+$5,
		       "gamesPlayed"="gamesPlayed"+1,
		       "streak"=$6,
		       "updatedAt"=now()
		 WHERE id=$1
	`, update.StatsID, update.NewElo, winInc, lossInc, mvpInc, update.Streak); err != nil {
		return err
	}

	if _, err := tx.ExecContext(ctx, `
		UPDATE "Player"
		   SET "totalXp"=GREATEST(0,"totalXp"+$2),
		       "updatedAt"=now()
		 WHERE id=$1
	`, update.PlayerID, update.XPDelta); err != nil {
		return err
	}

	return insertEloHistoryTx(ctx, tx, update.PlayerID, update.SeasonID, update.NewElo, update.EloReason, update.ExtraReason)
}

func RevertGameScore(ctx context.Context, gameID string, updates []UnscoreUpdate) (err error) {
	if len(updates) == 0 {
		return errors.New("no player updates provided")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	if _, err = tx.ExecContext(ctx, `
		UPDATE "Game"
		   SET status='PENDING',
		       reason=NULL,
		       "updatedAt"=now()
		 WHERE id=$1
	`, gameID); err != nil {
		return err
	}

	for _, update := range updates {
		if err = revertScoreForPlayer(ctx, tx, update); err != nil {
			return err
		}
	}

	return tx.Commit()
}

func revertScoreForPlayer(ctx context.Context, tx *sql.Tx, update UnscoreUpdate) error {
	if _, err := tx.ExecContext(ctx, `
		UPDATE "GamePlayer"
		   SET win=false,
		       mvp=false
		 WHERE id=$1
	`, update.GamePlayerID); err != nil {
		return err
	}
	if update.SkipStats {
		return nil
	}

	winDec := boolToInt(update.Win)
	lossDec := boolToInt(!update.Win)
	mvpDec := boolToInt(update.MVP)
	if _, err := tx.ExecContext(ctx, `
		UPDATE "PlayerStatistics"
		   SET "elo"=$2,
		       "wins"=GREATEST(0,"wins"-$3),
		       "losses"=GREATEST(0,"losses"-$4),
		       "mvps"=GREATEST(0,"mvps"-$5),
		       "gamesPlayed"=GREATEST(0,"gamesPlayed"-1),
		       "streak"=$6,
		       "updatedAt"=now()
		 WHERE id=$1
	`, update.StatsID, update.NewElo, winDec, lossDec, mvpDec, update.Streak); err != nil {
		return err
	}

	if _, err := tx.ExecContext(ctx, `
		UPDATE "Player"
		   SET "totalXp"=GREATEST(0,"totalXp"-$2),
		       "updatedAt"=now()
		 WHERE id=$1
	`, update.PlayerID, update.XPDelta); err != nil {
		return err
	}

	return insertEloHistoryTx(ctx, tx, update.PlayerID, update.SeasonID, update.NewElo, "ManualAdjustment", update.ExtraReason)
}

func insertEloHistoryTx(ctx context.Context, tx *sql.Tx, playerID, seasonID string, newElo int, reason, extra string) error {
	historyID, err := randomHexID()
	if err != nil {
		return err
	}
	now := time.Now().UTC()
	var extraReason interface{}
	if trimmed := strings.TrimSpace(extra); trimmed != "" {
		extraReason = trimmed
	} else {
		extraReason = nil
	}
	_, err = tx.ExecContext(ctx, `
		INSERT INTO "EloHistory"
			("id","userId","seasonId","elo","reason","extraReason","createdAt","updatedAt")
		VALUES ($1,$2,$3,$4,$5::"EloHistoryReason",$6,$7,$7)
	`, historyID, playerID, seasonID, newElo, reason, extraReason, now)
	return err
}

func boolToInt(v bool) int {
	if v {
		return 1
	}
	return 0
}

func VoidGame(ctx context.Context, gameID string, reason string, updates []UnscoreUpdate) (err error) {
	conn, err := getDB()
	if err != nil {
		return err
	}
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	var reasonValue interface{}
	if trimmed := strings.TrimSpace(reason); trimmed != "" {
		reasonValue = trimmed
	} else {
		reasonValue = nil
	}
	if _, err = tx.ExecContext(ctx, `
		UPDATE "Game"
		   SET status='VOIDED',
		       reason=$2,
		       "updatedAt"=now()
		 WHERE id=$1
	`, gameID, reasonValue); err != nil {
		return err
	}

	for _, update := range updates {
		if err = revertScoreForPlayer(ctx, tx, update); err != nil {
			return err
		}
	}

	return tx.Commit()
}
