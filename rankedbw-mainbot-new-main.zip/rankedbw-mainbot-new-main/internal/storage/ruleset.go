package storage

import (
	"context"
	"database/sql"
	"errors"
	"io"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib"
)

const maxRulesetBytes = 64 * 1024 // 64 KiB guard

var (
	db      *sql.DB
	once    sync.Once
	initErr error
)

func getDB() (*sql.DB, error) {
	once.Do(func() {
		dsn := os.Getenv("DATABASE_URL")
		if dsn == "" {
			initErr = errors.New("DATABASE_URL is not set")
			return
		}
		var err error
		db, err = sql.Open("pgx", dsn)
		if err != nil {
			initErr = err
			return
		}
		// You can tune these if you want
		db.SetMaxOpenConns(5)
		db.SetMaxIdleConns(5)
		db.SetConnMaxLifetime(30 * time.Minute)

		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err = db.PingContext(ctx); err != nil {
			initErr = err
		}
	})
	return db, initErr
}

// SaveRulesetFromURL downloads a .txt and stores its content in "Settings".ruleset
func SaveRulesetFromURL(ctx context.Context, url string) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return errors.New("ruleset download failed: non-200")
	}

	limited := io.LimitedReader{R: resp.Body, N: maxRulesetBytes + 1}
	data, err := io.ReadAll(&limited)
	if err != nil {
		return err
	}
	if int64(len(data)) > maxRulesetBytes {
		return errors.New("ruleset too large (>64 KiB)")
	}

	content := strings.ReplaceAll(string(data), "\r\n", "\n")
	return SaveRulesetText(ctx, content)
}

// SaveRulesetText writes plain text to the single row in "Settings".ruleset
func SaveRulesetText(ctx context.Context, content string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	// If there truly is only one row, a WHERE is unnecessary.
	// Quoted identifier preserves the capitalized table name.
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET ruleset = $1`, content)
	return err
}

// LoadRuleset reads the current ruleset text from "Settings".ruleset
func LoadRuleset() (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var rs sql.NullString
	err = conn.QueryRow(`SELECT ruleset FROM "Settings" LIMIT 1`).Scan(&rs)
	if err != nil {
		return "", err
	}
	if !rs.Valid {
		return "", nil
	}
	// Ensure \n line endings for Discord
	return strings.ReplaceAll(rs.String, "\r\n", "\n"), nil
}

// SetClaimElo updates the single-row boolean flag in "Settings".claimelo
func SetClaimElo(ctx context.Context, enabled bool) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "claimEloEnabled" = $1`, enabled)
	return err
}

func GetClaimEloEnabled(ctx context.Context) (bool, error) {
	conn, err := getDB()
	if err != nil {
		return false, err
	}
	var enabled sql.NullBool
	if err := conn.QueryRowContext(ctx, `SELECT "claimEloEnabled" FROM "Settings" LIMIT 1`).Scan(&enabled); err != nil {
		return false, err
	}
	if !enabled.Valid {
		return false, nil
	}
	return enabled.Bool, nil
}

// SetGameStyle updates the single-row gameStyle value in "Settings".
func SetGameStyle(ctx context.Context, style string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	// Expect only "2v2" or "4v4"
	switch style {
	case "2v2", "4v4":
	default:
		return errors.New("invalid game style")
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "gameStyle" = $1`, style)
	return err
}

func GetGameStyle(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var style sql.NullString
	if err := conn.QueryRowContext(ctx, `SELECT "gameStyle" FROM "Settings" LIMIT 1`).Scan(&style); err != nil {
		return "", err
	}
	if !style.Valid {
		return "", nil
	}
	return strings.TrimSpace(style.String), nil
}

// SetHypixelAPIKey updates the single-row API key in "Settings".hypixelApiKey
func SetHypixelAPIKey(ctx context.Context, key string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "hypixelAPIKey" = $1`, key)
	return err
}

// SetPartyEnabled updates the single-row partyEnabled flag in "Settings".
func SetPartyEnabled(ctx context.Context, enabled bool) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "partyEnabled" = $1`, enabled)
	return err
}

// SetPartySize updates "Settings".partySize (allowed: 1..4)
func SetPartySize(ctx context.Context, size int64) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	if size < 1 || size > 4 {
		return errors.New("invalid party size")
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "partySize" = $1`, size)
	return err
}

// SetPickingType updates "Settings".pickingType (allowed: 1, 2)
func SetPickingType(ctx context.Context, pick string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	switch strings.ToLower(pick) {
	case "1", "2":
		// ok
	default:
		return errors.New("invalid picking type")
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "pickingType" = $1`, strings.ToLower(pick))
	return err
}

func GetHypixelAPIKey(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var key sql.NullString
	if err := conn.QueryRowContext(ctx, `SELECT "hypixelAPIKey" FROM "Settings" LIMIT 1`).Scan(&key); err != nil {
		return "", err
	}
	if !key.Valid || strings.TrimSpace(key.String) == "" {
		return "", errors.New("hypixel api key is not set")
	}
	return strings.TrimSpace(key.String), nil
}

func SetLogChannelID(ctx context.Context, channelID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	var value interface{}
	if strings.TrimSpace(channelID) == "" {
		value = nil
	} else {
		value = channelID
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "logChannelId" = $1`, value)
	return err
}

func GetLogChannelID(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var channel sql.NullString
	if err := conn.QueryRowContext(ctx, `SELECT "logChannelId" FROM "Settings" LIMIT 1`).Scan(&channel); err != nil {
		return "", err
	}
	if !channel.Valid {
		return "", nil
	}
	return strings.TrimSpace(channel.String), nil
}

// Queue log channel (for queue events)
func SetQueueLogChannelID(ctx context.Context, channelID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	var value interface{}
	if strings.TrimSpace(channelID) == "" {
		value = nil
	} else {
		value = channelID
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "queueLogChannelId" = $1`, value)
	return err
}

func GetQueueLogChannelID(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var channel sql.NullString
	if err := conn.QueryRowContext(ctx, `SELECT "queueLogChannelId" FROM "Settings" LIMIT 1`).Scan(&channel); err != nil {
		return "", err
	}
	if !channel.Valid {
		return "", nil
	}
	return strings.TrimSpace(channel.String), nil
}

func SetPunishmentsChannelID(ctx context.Context, channelID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	var value interface{}
	if strings.TrimSpace(channelID) == "" {
		value = nil
	} else {
		value = channelID
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "punishmentsChannelId" = $1`, value)
	return err
}

func GetPunishmentsChannelID(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var channel sql.NullString
	if err := conn.QueryRowContext(ctx, `SELECT "punishmentsChannelId" FROM "Settings" LIMIT 1`).Scan(&channel); err != nil {
		return "", err
	}
	if !channel.Valid {
		return "", nil
	}
	return strings.TrimSpace(channel.String), nil
}

// GetStaffPunishmentLogChannelID returns the staff-facing punishment log channel.
// Reads from settings (staff_punishment_logs) and falls back to env STAFF_PUNISHMENT_LOGS.
func GetStaffPunishmentLogChannelID(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var channel sql.NullString
	if err := conn.QueryRowContext(ctx, `SELECT "staff_punishment_logs" FROM "Settings" LIMIT 1`).Scan(&channel); err != nil && !errors.Is(err, sql.ErrNoRows) {
		return "", err
	}
	if channel.Valid && strings.TrimSpace(channel.String) != "" {
		return strings.TrimSpace(channel.String), nil
	}
	return strings.TrimSpace(os.Getenv("STAFF_PUNISHMENT_LOGS")), nil
}

func SetSupportChannelID(ctx context.Context, channelID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	var value interface{}
	if strings.TrimSpace(channelID) == "" {
		value = nil
	} else {
		value = channelID
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "supportChannelId" = $1`, value)
	return err
}

func GetSupportChannelID(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var channel sql.NullString
	if err := conn.QueryRowContext(ctx, `SELECT "supportChannelId" FROM "Settings" LIMIT 1`).Scan(&channel); err != nil {
		return "", err
	}
	if !channel.Valid {
		return "", nil
	}
	return strings.TrimSpace(channel.String), nil
}

func SetAlertsChannelID(ctx context.Context, channelID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	var value interface{}
	if strings.TrimSpace(channelID) == "" {
		value = nil
	} else {
		value = channelID
	}
	_, err = conn.ExecContext(ctx, `UPDATE "Settings" SET "alerts" = $1`, value)
	return err
}

func GetAlertsChannelID(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var channel sql.NullString
	if err := conn.QueryRowContext(ctx, `SELECT "alerts" FROM "Settings" LIMIT 1`).Scan(&channel); err != nil {
		return "", err
	}
	if !channel.Valid {
		return "", nil
	}
	return strings.TrimSpace(channel.String), nil
}

func GetPartySettings(ctx context.Context) (enabled bool, size int, err error) {
	conn, err := getDB()
	if err != nil {
		return false, 0, err
	}
	var (
		enabledVal sql.NullBool
		sizeVal    sql.NullInt64
	)
	if err := conn.QueryRowContext(ctx, `SELECT "partyEnabled","partySize" FROM "Settings" LIMIT 1`).Scan(&enabledVal, &sizeVal); err != nil {
		return false, 0, err
	}
	return enabledVal.Bool, int(sizeVal.Int64), nil
}
