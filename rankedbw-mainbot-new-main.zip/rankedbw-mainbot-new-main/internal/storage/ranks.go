package storage

import (
	"context"
	"database/sql"
	"strings"
)

// RankRecord represents a rank bracket stored in the database.
// Expected table (example):
// CREATE TABLE "Rank" (
//
//	name TEXT PRIMARY KEY,
//	min INTEGER NOT NULL,
//	max INTEGER NOT NULL,
//	gain INTEGER NOT NULL,
//	loss INTEGER NOT NULL,
//	mvp INTEGER NOT NULL,
//	role_id TEXT NOT NULL
//	emoji_id TEXT NULL
//
// );
type RankRecord struct {
	Name    string
	Min     int
	Max     int
	Gain    int
	Loss    int
	MVP     int
	RoleID  string
	EmojiID string
}

// ListRanks returns all rank records ordered by minimum elo.
func ListRanks(ctx context.Context) ([]RankRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT name, min, max, gain, loss, mvp, role_id, COALESCE(emoji_id,'')
		  FROM "Rank"
		 ORDER BY min ASC
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var ranks []RankRecord
	for rows.Next() {
		var r RankRecord
		if err := rows.Scan(&r.Name, &r.Min, &r.Max, &r.Gain, &r.Loss, &r.MVP, &r.RoleID, &r.EmojiID); err != nil {
			return nil, err
		}
		r.RoleID = strings.TrimSpace(r.RoleID)
		r.EmojiID = strings.TrimSpace(r.EmojiID)
		ranks = append(ranks, r)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return ranks, nil
}

// RankForElo returns the first rank that contains the provided elo, or nil if none match.
func RankForElo(ctx context.Context, elo int) (*RankRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var r RankRecord
	err = conn.QueryRowContext(ctx, `
		SELECT name, min, max, gain, loss, mvp, role_id, COALESCE(emoji_id,'')
		  FROM "Rank"
		 WHERE $1 BETWEEN min AND max
		 ORDER BY min ASC
		 LIMIT 1
	`, elo).Scan(&r.Name, &r.Min, &r.Max, &r.Gain, &r.Loss, &r.MVP, &r.RoleID, &r.EmojiID)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	r.RoleID = strings.TrimSpace(r.RoleID)
	r.EmojiID = strings.TrimSpace(r.EmojiID)
	return &r, nil
}

// UpsertRank creates or updates a rank record keyed by name.
func UpsertRank(ctx context.Context, rank RankRecord) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "Rank" (name, min, max, gain, loss, mvp, role_id, emoji_id)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
		ON CONFLICT (name)
		DO UPDATE SET min=EXCLUDED.min,
		              max=EXCLUDED.max,
		              gain=EXCLUDED.gain,
		              loss=EXCLUDED.loss,
		              mvp=EXCLUDED.mvp,
		              role_id=EXCLUDED.role_id,
		              emoji_id=EXCLUDED.emoji_id
	`, rank.Name, rank.Min, rank.Max, rank.Gain, rank.Loss, rank.MVP, strings.TrimSpace(rank.RoleID), strings.TrimSpace(rank.EmojiID))
	return err
}

// DeleteRank removes a rank row by name.
func DeleteRank(ctx context.Context, name string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `DELETE FROM "Rank" WHERE name=$1`, name)
	return err
}
