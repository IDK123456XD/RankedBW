package storage

import (
	"context"
	"database/sql"
	"errors"
	"strconv"
	"strings"
)

// GameCreatePlayer describes an entry in the GamePlayer table.
type GameCreatePlayer struct {
	PlayerID    string
	DiscordID   string
	DiscordTeam int
	PreElo      int
}

// GameCreateInput carries the data required to create a pending game.
type GameCreateInput struct {
	GameCode          string
	Team1VoiceID      string
	Team2VoiceID      string
	QueueThreadID     string
	SeasonID          string
	GameStyle         string
	MapName           string
	PlayerAssignments []GameCreatePlayer
}

// GenerateGameCode returns the next sequential numeric identifier for the provided season.
// Game IDs start at 1 for each season and increment by 1 based on the current maximum,
// including any active picking sessions that have reserved a game code.
func GenerateGameCode(ctx context.Context, seasonID string) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}

	seasonID = strings.TrimSpace(seasonID)
	var query string
	var args []interface{}
	if seasonID == "" {
		query = `
			SELECT COALESCE(MAX(CAST("gameId" AS BIGINT)),0)
			  FROM "Game"
			 WHERE COALESCE("seasonId",'') = ''
			   AND "gameId" ~ '^[0-9]+$'
		`
	} else {
		query = `
			SELECT COALESCE(MAX(CAST("gameId" AS BIGINT)),0)
			  FROM "Game"
			 WHERE "seasonId" = $1
			   AND "gameId" ~ '^[0-9]+$'
		`
		args = append(args, seasonID)
	}

	var current sql.NullInt64
	if err := conn.QueryRowContext(ctx, query, args...).Scan(&current); err != nil {
		return "", err
	}

	maxVal := int64(0)
	if current.Valid && current.Int64 > 0 {
		maxVal = current.Int64
	}

	if exists, err := pickingTableExists(ctx, conn, "PickingSession"); err == nil && exists {
		var pickQuery string
		var pickArgs []interface{}
		if seasonID == "" {
			pickQuery = `
				SELECT COALESCE(MAX(CAST("gameCode" AS BIGINT)),0)
				  FROM "PickingSession"
				 WHERE COALESCE("seasonId",'') = ''
				   AND "gameCode" ~ '^[0-9]+$'
			`
		} else {
			pickQuery = `
				SELECT COALESCE(MAX(CAST("gameCode" AS BIGINT)),0)
				  FROM "PickingSession"
				 WHERE "seasonId" = $1
				   AND "gameCode" ~ '^[0-9]+$'
			`
			pickArgs = append(pickArgs, seasonID)
		}
		var reserved sql.NullInt64
		if err := conn.QueryRowContext(ctx, pickQuery, pickArgs...).Scan(&reserved); err != nil {
			return "", err
		}
		if reserved.Valid && reserved.Int64 > maxVal {
			maxVal = reserved.Int64
		}
	}

	next := maxVal + 1

	for isBlacklistedGameCode(next) {
		next++
	}

	return strconv.FormatInt(next, 10), nil
}

/*
due to discord blocking certain phrases in our case numbers for server discovery we need to skip
these numbers because otherwise channel creation fails and so does the queue itself
*/
func isBlacklistedGameCode(code int64) bool {
	s := strconv.FormatInt(code, 10)

	blacklist := []string{
		"69",
		"420",
		"666",
		"1312",
		"1488",
	}

	for _, bad := range blacklist {
		if strings.Contains(s, bad) {
			return true
		}
	}

	return false
}

// CreateGameWithPlayers inserts a pending game and its participants.
func CreateGameWithPlayers(ctx context.Context, input GameCreateInput) (string, error) {
	if len(input.PlayerAssignments) == 0 {
		return "", errors.New("no players provided for game creation")
	}
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return "", err
	}
	rollback := true
	defer func() {
		if rollback {
			_ = tx.Rollback()
		}
	}()

	gameID, err := randomHexID()
	if err != nil {
		return "", err
	}

	var season interface{}
	if strings.TrimSpace(input.SeasonID) != "" {
		season = input.SeasonID
	} else {
		season = nil
	}

	if _, err := tx.ExecContext(ctx, `
		INSERT INTO "Game"
			(id,"gameId","team1Voice","team2Voice","queueThreadChannelId","mapPlaying","gameStyle","seasonId","status","createdAt","updatedAt")
		VALUES
			($1,$2,$3,$4,$5,$6,$7,$8,'PENDING',now(),now())
	`, gameID, input.GameCode, input.Team1VoiceID, input.Team2VoiceID, input.QueueThreadID, input.MapName, input.GameStyle, season); err != nil {
		return "", err
	}

	for _, p := range input.PlayerAssignments {
		playerID := strings.TrimSpace(p.PlayerID)
		if playerID == "" {
			return "", errors.New("player id cannot be empty")
		}
		rowID, err := randomHexID()
		if err != nil {
			return "", err
		}
		if _, err := tx.ExecContext(ctx, `
			INSERT INTO "GamePlayer" (id,"userId","preElo","discordTeam","gameId")
			VALUES ($1,$2,$3,$4,$5)
		`, rowID, playerID, p.PreElo, p.DiscordTeam, gameID); err != nil {
			return "", err
		}
	}

	if err := tx.Commit(); err != nil {
		return "", err
	}
	rollback = false
	return gameID, nil
}
