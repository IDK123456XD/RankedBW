package storage

import (
	"context"
	"database/sql"
	"errors"
	"strings"
)

// LatestPendingGameCodeForPlayer returns the most recent unscored game code ("gameId")
// for the player in the given season. If none is found, "" is returned.
func LatestPendingGameCodeForPlayer(ctx context.Context, playerID, seasonID string) (string, error) {
	playerID = strings.TrimSpace(playerID)
	if playerID == "" {
		return "", errors.New("player id is required")
	}
	seasonID = strings.TrimSpace(seasonID)

	conn, err := getDB()
	if err != nil {
		return "", err
	}

	var code sql.NullString
	query := `
		SELECT g."gameId"
		  FROM "GamePlayer" gp
		  JOIN "Game" g ON g.id = gp."gameId"
		 WHERE gp."userId"=$1
		   AND upper(g.status::text) IN ('PENDING','LIVE')
		   AND ($2='' OR g."seasonId"=$2)
		 ORDER BY g."createdAt" DESC
		 LIMIT 1
	`
	if err := conn.QueryRowContext(ctx, query, playerID, seasonID).Scan(&code); errors.Is(err, sql.ErrNoRows) {
		return "", nil
	} else if err != nil {
		return "", err
	}
	return strings.TrimSpace(code.String), nil
}
