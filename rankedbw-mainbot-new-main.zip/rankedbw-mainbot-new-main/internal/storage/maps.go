package storage

import (
	"context"
	"errors"
	"math/rand"
	"strings"
	"time"
)

type MapRecord struct {
	Name   string
	Height int
}

// UpsertMap creates or updates a map record.
func UpsertMap(ctx context.Context, name string, height int) error {
	name = strings.TrimSpace(name)
	if name == "" || height <= 0 {
		return errors.New("name required and height must be positive")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO maps (map_name, height_limit)
		     VALUES ($1,$2)
		ON CONFLICT (map_name)
		  DO UPDATE SET height_limit=$2
	`, name, height)
	return err
}

// DeleteMap removes a map record by name.
func DeleteMap(ctx context.Context, name string) error {
	name = strings.TrimSpace(name)
	if name == "" {
		return errors.New("name is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `DELETE FROM maps WHERE map_name=$1`, name)
	return err
}

// ListMaps returns all maps from the maps table.
func ListMaps(ctx context.Context) ([]MapRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT map_name, height_limit
		  FROM maps
		 ORDER BY map_name
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []MapRecord
	for rows.Next() {
		var rec MapRecord
		if err := rows.Scan(&rec.Name, &rec.Height); err != nil {
			return nil, err
		}
		rec.Name = strings.TrimSpace(rec.Name)
		list = append(list, rec)
	}
	return list, rows.Err()
}

// RandomMap returns a random map from the table.
func RandomMap(ctx context.Context) (MapRecord, error) {
	list, err := ListMaps(ctx)
	if err != nil {
		return MapRecord{}, err
	}
	if len(list) == 0 {
		return MapRecord{}, errors.New("no maps configured")
	}
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	return list[r.Intn(len(list))], nil
}
