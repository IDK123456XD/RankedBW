package storage

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"
)

type PlayerRecord struct {
	ID                 string
	UserID             string
	MinecraftName      string
	UUID               string
	TotalXP            int
	Nickname           sql.NullString
	EloPrefix          bool
	FullBodySkin       sql.NullString
	HeadSkin           sql.NullString
	SelectedInfocardID sql.NullString
	CreatedAt          time.Time
}

type PlayerSeasonStats struct {
	ID          string
	PlayerID    string
	SeasonID    string
	Elo         int
	Wins        int
	Losses      int
	GamesPlayed int
	MVPs        int
	Streak      int
	PeakElo     int
	LastReset   sql.NullTime
	ResetCount  int
	ClaimedElo  bool
}

type EloHistoryEntry struct {
	Elo         int
	Reason      string
	ExtraReason sql.NullString
	CreatedAt   time.Time
	SeasonID    sql.NullString
	SeasonName  sql.NullString
}

// PlayerNameMap maps player IDs to their Minecraft names.
func PlayerNameMap(ctx context.Context, ids []string) (map[string]string, error) {
	result := make(map[string]string, len(ids))
	if len(ids) == 0 {
		return result, nil
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id,"minecraftName"
		  FROM "Player"
		 WHERE id = ANY($1)
	`, pq.Array(ids))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var id, name string
		if err := rows.Scan(&id, &name); err != nil {
			return nil, err
		}
		result[id] = name
	}
	return result, rows.Err()
}

func EloHistoryForPlayer(ctx context.Context, playerID string, limit int) ([]EloHistoryEntry, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	if limit <= 0 {
		limit = 10
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT h.elo,h."reason",h."extraReason",h."createdAt",h."seasonId",s.name
		  FROM "EloHistory" h
		  LEFT JOIN "Season" s ON s.id = h."seasonId"
		 WHERE h."userId" = $1
		 ORDER BY h."createdAt" DESC
		 LIMIT $2
	`, playerID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var entries []EloHistoryEntry
	for rows.Next() {
		var entry EloHistoryEntry
		if err := rows.Scan(&entry.Elo, &entry.Reason, &entry.ExtraReason, &entry.CreatedAt, &entry.SeasonID, &entry.SeasonName); err != nil {
			return nil, err
		}
		entries = append(entries, entry)
	}
	return entries, rows.Err()
}

func EloHistoryForPlayerSeason(ctx context.Context, playerID, seasonID string, limit int) ([]EloHistoryEntry, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	if limit <= 0 {
		limit = 10
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT h.elo,h."reason",h."extraReason",h."createdAt",h."seasonId",s.name
		  FROM "EloHistory" h
		  LEFT JOIN "Season" s ON s.id = h."seasonId"
		 WHERE h."userId" = $1
		   AND h."seasonId" = $2
		 ORDER BY h."createdAt" DESC
		 LIMIT $3
	`, playerID, strings.TrimSpace(seasonID), limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var entries []EloHistoryEntry
	for rows.Next() {
		var entry EloHistoryEntry
		if err := rows.Scan(&entry.Elo, &entry.Reason, &entry.ExtraReason, &entry.CreatedAt, &entry.SeasonID, &entry.SeasonName); err != nil {
			return nil, err
		}
		entries = append(entries, entry)
	}
	return entries, rows.Err()
}

type LeaderboardRow struct {
	PlayerID      string
	MinecraftName string
	Value         int
}

func GetPlayerByUserID(ctx context.Context, userID string) (*PlayerRecord, error) {
	return fetchPlayer(ctx, `"userId"=$1`, userID)
}

func GetPlayerByID(ctx context.Context, id string) (*PlayerRecord, error) {
	return fetchPlayer(ctx, `id=$1`, id)
}

func GetPlayerByMinecraftName(ctx context.Context, ign string) (*PlayerRecord, error) {
	return fetchPlayer(ctx, `lower("minecraftName")=lower($1)`, ign)
}

func GetPlayerByUUID(ctx context.Context, uuid string) (*PlayerRecord, error) {
	return fetchPlayer(ctx, `lower("uuid")=lower($1)`, uuid)
}

func fetchPlayer(ctx context.Context, where string, args ...any) (*PlayerRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var rec PlayerRecord
	query := `SELECT id,"userId","minecraftName","uuid","totalXp",nickname,"eloPrefix","fullBodySkin","headSkin","selectedInfocardId","createdAt" FROM "Player" WHERE ` + where + ` LIMIT 1`
	err = conn.QueryRowContext(ctx, query, args...).Scan(&rec.ID, &rec.UserID, &rec.MinecraftName, &rec.UUID, &rec.TotalXP, &rec.Nickname, &rec.EloPrefix, &rec.FullBodySkin, &rec.HeadSkin, &rec.SelectedInfocardID, &rec.CreatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &rec, nil
}

func DumpPlayerJSON(ctx context.Context, userID string) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var raw sql.NullString
	err = conn.QueryRowContext(ctx, `
		SELECT row_to_json(p)::text
		  FROM (SELECT * FROM "Player" WHERE "userId"=$1) p
	`, userID).Scan(&raw)
	if errors.Is(err, sql.ErrNoRows) || !raw.Valid {
		return "", nil
	}
	return raw.String, err
}

func CreatePlayer(ctx context.Context, userID, ign, uuid, fullSkin, headSkin, infocardID string) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	if err := ensureUser(ctx, conn, userID); err != nil {
		return "", err
	}
	id, err := generatePlayerID(ctx, conn)
	if err != nil {
		return "", err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "Player"
			("id","userId","minecraftName","uuid","fullBodySkin","headSkin","selectedInfocardId","lastMojangFetch","createdAt","updatedAt")
		VALUES ($1,$2,$3,$4,$5,$6,$7,now(),now(),now())
	`, id, userID, ign, uuid, optionalString(fullSkin), optionalString(headSkin), optionalString(infocardID))
	if err != nil {
		return "", err
	}
	return id, nil
}

func UpdatePlayerProfile(ctx context.Context, playerID, ign, uuid, fullSkin, headSkin, infocardID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Player"
		   SET "minecraftName"=$2,
		       "uuid"=$3,
		       "fullBodySkin"=$4,
		       "headSkin"=$5,
		       "selectedInfocardId"=COALESCE($6,"selectedInfocardId"),
		       "lastMojangFetch"=now(),
		       "updatedAt"=now()
		 WHERE id=$1
	`, playerID, ign, uuid, optionalString(fullSkin), optionalString(headSkin), optionalString(infocardID))
	return err
}

func EnsurePlayerSeasonStats(ctx context.Context, playerID, seasonID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "PlayerStatistics" (id,"playerId","seasonId")
		SELECT gen_random_uuid()::text, $1, $2
		WHERE NOT EXISTS (
			SELECT 1 FROM "PlayerStatistics" WHERE "playerId"=$1 AND "seasonId"=$2
		)
	`, playerID, seasonID)
	return err
}

func PlayerSeasonElo(ctx context.Context, playerID, seasonID string) (int, error) {
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var elo sql.NullInt64
	err = conn.QueryRowContext(ctx, `
		SELECT "elo"
		  FROM "PlayerStatistics"
		 WHERE "playerId"=$1 AND "seasonId"=$2
		 LIMIT 1
	`, playerID, seasonID).Scan(&elo)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, nil
	}
	if err != nil {
		return 0, err
	}
	if !elo.Valid {
		return 0, nil
	}
	return int(elo.Int64), nil
}

func GetPlayerSeasonStats(ctx context.Context, playerID, seasonID string) (*PlayerSeasonStats, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var stats PlayerSeasonStats
	err = conn.QueryRowContext(ctx, `
		SELECT id,"elo","wins","losses","gamesPlayed","mvps","streak","peakElo","lastStatResetAt","statResetCount","claimedELO"
		  FROM "PlayerStatistics"
		 WHERE "playerId"=$1 AND "seasonId"=$2
		 LIMIT 1
	`, playerID, seasonID).Scan(
		&stats.ID,
		&stats.Elo,
		&stats.Wins,
		&stats.Losses,
		&stats.GamesPlayed,
		&stats.MVPs,
		&stats.Streak,
		&stats.PeakElo,
		&stats.LastReset,
		&stats.ResetCount,
		&stats.ClaimedElo,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	stats.PlayerID = playerID
	stats.SeasonID = seasonID
	return &stats, nil
}

func SetPlayerClaimedElo(ctx context.Context, statsID string, claimed bool) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "PlayerStatistics"
		   SET "claimedELO" = $2
		 WHERE id = $1
	`, statsID, claimed)
	return err
}

func UpdatePlayerTotalXP(ctx context.Context, playerID string, totalXP int) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Player"
		   SET "totalXp"=$2,
		       "updatedAt"=now()
		 WHERE id=$1
	`, playerID, totalXP)
	return err
}

var allowedStatColumns = map[string]bool{
	"wins":        true,
	"losses":      true,
	"gamesPlayed": true,
	"mvps":        true,
	"streak":      true,
}

func UpdatePlayerStatsColumn(ctx context.Context, statsID, column string, value int) error {
	if !allowedStatColumns[column] {
		return fmt.Errorf("unsupported stats column %s", column)
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	query := fmt.Sprintf(`UPDATE "PlayerStatistics" SET "%s"=$2 WHERE id=$1`, column)
	_, err = conn.ExecContext(ctx, query, statsID, value)
	return err
}

func UpdatePlayerElo(ctx context.Context, statsID, playerID, seasonID string, newElo int, reason, extraReason string) (int, int, error) {
	conn, err := getDB()
	if err != nil {
		return 0, 0, err
	}
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return 0, 0, err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	var prevElo int
	err = tx.QueryRowContext(ctx, `
		SELECT "elo"
		  FROM "PlayerStatistics"
		 WHERE id=$1
		 FOR UPDATE
	`, statsID).Scan(&prevElo)
	if err != nil {
		return 0, 0, err
	}

	clamped := newElo
	if clamped < 0 {
		clamped = 0
	}

	now := time.Now().UTC()
	if _, err = tx.ExecContext(ctx, `
		UPDATE "PlayerStatistics"
		   SET "elo"=$2,
		       "peakElo"=GREATEST("peakElo",$2)
		 WHERE id=$1
	`, statsID, clamped); err != nil {
		return 0, 0, err
	}

	historyID, err := randomHexID()
	if err != nil {
		return 0, 0, err
	}

	if _, err = tx.ExecContext(ctx, `
		INSERT INTO "EloHistory"
			("id","userId","seasonId","elo","reason","extraReason","createdAt","updatedAt")
		VALUES ($1,$2,$3,$4,$5::"EloHistoryReason",$6,$7,$8)
	`, historyID, playerID, seasonID, clamped, reason, extraReason, now, now); err != nil {
		return 0, 0, err
	}

	if err = tx.Commit(); err != nil {
		return 0, 0, err
	}
	return prevElo, clamped, nil
}

func DecrementLossAndGames(ctx context.Context, statsID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "PlayerStatistics"
		   SET "losses" = GREATEST(0,"losses"-1),
		       "gamesPlayed" = GREATEST(0,"gamesPlayed"-1),
		       "updatedAt"=now()
		 WHERE id=$1
	`, statsID)
	return err
}

func IncrementPlayerMVP(ctx context.Context, statsID, playerID, seasonID string, preElo int) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	tx, err := conn.Begin()
	if err != nil {
		return err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	if _, err = tx.ExecContext(ctx, `
		UPDATE "PlayerStatistics"
		   SET "mvps" = "mvps" + 1,
		       "updatedAt" = now()
		 WHERE id=$1
	`, statsID); err != nil {
		return err
	}

	xpBonus := 5 * preElo
	if _, err = tx.ExecContext(ctx, `
		UPDATE "Player"
		   SET "totalXp" = "totalXp" + $2,
		       "updatedAt" = now()
		 WHERE id=$1
	`, playerID, xpBonus); err != nil {
		return err
	}

	return tx.Commit()
}

func DefaultInfocardID(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	if _, err := EnsureInfocardCatalog(ctx); err != nil {
		return "", err
	}

	defaultName := infocardDefaultName()
	var id string
	if defaultName != "" {
		if err := conn.QueryRowContext(ctx, `SELECT id FROM "Infocard" WHERE lower(name)=lower($1) LIMIT 1`, defaultName).Scan(&id); err == nil {
			return id, nil
		} else if !errors.Is(err, sql.ErrNoRows) {
			return "", err
		}
	}

	if err := conn.QueryRowContext(ctx, `SELECT id FROM "Infocard" WHERE lower(name)='light' LIMIT 1`).Scan(&id); err == nil {
		return id, nil
	} else if !errors.Is(err, sql.ErrNoRows) {
		return "", err
	}

	if err := conn.QueryRowContext(ctx, `SELECT id FROM "Infocard" LIMIT 1`).Scan(&id); err == nil {
		return id, nil
	} else if !errors.Is(err, sql.ErrNoRows) {
		return "", err
	}

	newID, err := randomHexID()
	if err != nil {
		return "", err
	}
	image := "light.png"
	if _, err := conn.ExecContext(ctx, `
		INSERT INTO "Infocard" (id,name,image,color)
		VALUES ($1,'light',$2,'light')
	`, newID, image); err != nil {
		return "", err
	}
	return newID, nil
}

// PlayerInfocard returns the image filename and color for the player's selected infocard.
func PlayerInfocard(ctx context.Context, playerID string) (string, string, error) {
	conn, err := getDB()
	if err != nil {
		return "", "", err
	}
	var img sql.NullString
	var color sql.NullString
	err = conn.QueryRowContext(ctx, `
		SELECT i.image, i.color
		  FROM "Infocard" i
		  JOIN "Player" p ON p."selectedInfocardId" = i.id
		 WHERE p.id = $1
		 LIMIT 1
	`, playerID).Scan(&img, &color)
	if errors.Is(err, sql.ErrNoRows) {
		return "", "", nil
	}
	if err != nil {
		return "", "", err
	}
	return strings.TrimSpace(img.String), strings.TrimSpace(color.String), nil
}

func ActiveSeasonID(ctx context.Context) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	var id string
	if err := conn.QueryRowContext(ctx, `SELECT id FROM "Season" WHERE active = true LIMIT 1`).Scan(&id); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return "", errors.New("no active season found")
		}
		return "", err
	}
	return id, nil
}

func optionalString(val string) any {
	if strings.TrimSpace(val) == "" {
		return nil
	}
	return val
}

func generatePlayerID(ctx context.Context, conn *sql.DB) (string, error) {
	for attempts := 0; attempts < 5; attempts++ {
		id, err := randomHexID()
		if err != nil {
			return "", err
		}
		var exists bool
		if err := conn.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM "Player" WHERE id=$1)`, id).Scan(&exists); err != nil {
			return "", err
		}
		if !exists {
			return id, nil
		}
	}
	return "", errors.New("failed to generate unique player id")
}

func randomHexID() (string, error) {
	buf := make([]byte, 12)
	if _, err := rand.Read(buf); err != nil {
		return "", err
	}
	return hex.EncodeToString(buf), nil
}

func ensureUser(ctx context.Context, conn *sql.DB, userID string) error {
	var exists bool
	if err := conn.QueryRowContext(ctx, `SELECT EXISTS(SELECT 1 FROM "User" WHERE id=$1)`, userID).Scan(&exists); err != nil {
		return err
	}
	if exists {
		return nil
	}
	email := userID + "@rankedbedwars.local"
	now := time.Now().UTC()
	_, err := conn.ExecContext(ctx, `
		INSERT INTO "User"
			(id,email,"discordId","createdAt","updatedAt")
		VALUES ($1,$2,$3,$4,$4)
	`, userID, email, userID, now)
	return err
}

// SetPlayerEloPrefix updates the boolean eloPrefix flag for the player.
func SetPlayerEloPrefix(ctx context.Context, playerID string, enabled bool) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Player"
		   SET "eloPrefix"=$2,
		       "updatedAt"=now()
		 WHERE id=$1
	`, playerID, enabled)
	return err
}

// SetPlayerNickname updates the stored nickname (empty string clears it).
func SetPlayerNickname(ctx context.Context, playerID, nickname string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	var value any
	if strings.TrimSpace(nickname) == "" {
		value = nil
	} else {
		value = nickname
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Player"
		   SET nickname = $2,
		       "updatedAt" = now()
		 WHERE id = $1
	`, playerID, value)
	return err
}

// ResetPlayerSeasonStats zeros out season statistics and increments the reset counter.
func ResetPlayerSeasonStats(ctx context.Context, statsID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "PlayerStatistics"
		   SET "claimedELO" = false,
		       "elo" = 0,
		       "wins" = 0,
		       "losses" = 0,
		       "gamesPlayed" = 0,
		       "mvps" = 0,
		       "streak" = 0,
		       "position" = 0,
		       "peakElo" = 0,
		       "statResetCount" = "statResetCount" + 1,
		       "lastStatResetAt" = now(),
		       "updatedAt" = now()
		 WHERE id = $1
	`, statsID)
	return err
}

// SeasonLeaderboard returns the top players ordered by the specified metric column.
func SeasonLeaderboard(ctx context.Context, seasonID, column string, limit, offset int, descending bool) ([]LeaderboardRow, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	if limit <= 0 {
		limit = 10
	}
	if limit > 50 {
		limit = 50
	}
	order := "DESC"
	if !descending {
		order = "ASC"
	}
	query := fmt.Sprintf(`
		SELECT ps."playerId", p."minecraftName", %s AS value
		  FROM "PlayerStatistics" ps
		  JOIN "Player" p ON p.id = ps."playerId"
		 WHERE ps."seasonId" = $1
		 ORDER BY %s %s, p."minecraftName" ASC
		 LIMIT $2 OFFSET $3
	`, column, column, order)

	rows, err := conn.QueryContext(ctx, query, seasonID, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []LeaderboardRow
	for rows.Next() {
		var row LeaderboardRow
		if err := rows.Scan(&row.PlayerID, &row.MinecraftName, &row.Value); err != nil {
			return nil, err
		}
		list = append(list, row)
	}
	return list, rows.Err()
}

// SeasonLeaderboardTotal returns the total number of player stats rows for a season.
func SeasonLeaderboardTotal(ctx context.Context, seasonID string) (int, error) {
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var count int
	if err := conn.QueryRowContext(ctx, `SELECT COUNT(1) FROM "PlayerStatistics" WHERE "seasonId" = $1`, seasonID).Scan(&count); err != nil {
		return 0, err
	}
	return count, nil
}

func DeletePlayerByUserID(ctx context.Context, userID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `DELETE FROM "Player" WHERE "userId"=$1`, userID)
	return err
}

func GetPartyIgnoreList(ctx context.Context, userID string) ([]string, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var entries []string
	if err := conn.QueryRowContext(ctx, `SELECT "partyIgnoreList" FROM "Player" WHERE "userId"=$1`, userID).Scan(pq.Array(&entries)); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, err
	}
	return entries, nil
}

func SetPartyIgnoreList(ctx context.Context, userID string, entries []string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Player"
		   SET "partyIgnoreList"=$2
		 WHERE "userId"=$1
	`, userID, pq.Array(entries))
	return err
}

// AllPlayerIDs returns every player ID in the Player table.
func AllPlayerIDs(ctx context.Context) ([]string, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `SELECT id FROM "Player"`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var ids []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}
