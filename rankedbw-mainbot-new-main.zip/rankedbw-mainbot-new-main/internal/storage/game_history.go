package storage

import (
	"context"
	"database/sql"
	"strings"
	"time"
)

type PlayerGameHistoryEntry struct {
	GameCode   string
	Status     string
	LossVoided bool
	CreatedAt  time.Time
	UpdatedAt  time.Time

	SeasonID   sql.NullString
	SeasonName sql.NullString

	Win     bool
	MVP     bool
	PreElo  int
	PostElo int
	EloDiff int
}

func GameHistoryForPlayerSeason(ctx context.Context, playerID, seasonID string, limit int) ([]PlayerGameHistoryEntry, error) {
	playerID = strings.TrimSpace(playerID)
	seasonID = strings.TrimSpace(seasonID)
	if playerID == "" || seasonID == "" {
		return nil, nil
	}
	if limit <= 0 {
		limit = 10
	}
	if limit > 25 {
		limit = 25
	}

	conn, err := getDB()
	if err != nil {
		return nil, err
	}

	rows, err := conn.QueryContext(ctx, `
		SELECT g."gameId",
		       g.status,
		       g."lossVoided",
		       g."createdAt",
		       g."updatedAt",
		       gp.win,
		       gp.mvp,
		       COALESCE(gp."preElo",0),
		       COALESCE(gp."postElo",0),
		       COALESCE(gp."eloDiff",0)
		  FROM "GamePlayer" gp
		  JOIN "Game" g ON g.id = gp."gameId"
		 WHERE gp."userId" = $1
		   AND g."seasonId" = $2
		 ORDER BY g."updatedAt" DESC, g."createdAt" DESC
		 LIMIT $3
	`, playerID, seasonID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []PlayerGameHistoryEntry
	for rows.Next() {
		var entry PlayerGameHistoryEntry
		if err := rows.Scan(
			&entry.GameCode,
			&entry.Status,
			&entry.LossVoided,
			&entry.CreatedAt,
			&entry.UpdatedAt,
			&entry.Win,
			&entry.MVP,
			&entry.PreElo,
			&entry.PostElo,
			&entry.EloDiff,
		); err != nil {
			return nil, err
		}
		list = append(list, entry)
	}
	return list, rows.Err()
}

func GameHistoryForPlayer(ctx context.Context, playerID string, limit int) ([]PlayerGameHistoryEntry, error) {
	playerID = strings.TrimSpace(playerID)
	if playerID == "" {
		return nil, nil
	}
	if limit <= 0 {
		limit = 10
	}
	if limit > 25 {
		limit = 25
	}

	conn, err := getDB()
	if err != nil {
		return nil, err
	}

	rows, err := conn.QueryContext(ctx, `
		SELECT g."gameId",
		       g.status,
		       g."lossVoided",
		       g."createdAt",
		       g."updatedAt",
		       g."seasonId",
		       s.name,
		       gp.win,
		       gp.mvp,
		       COALESCE(gp."preElo",0),
		       COALESCE(gp."postElo",0),
		       COALESCE(gp."eloDiff",0)
		  FROM "GamePlayer" gp
		  JOIN "Game" g ON g.id = gp."gameId"
		  LEFT JOIN "Season" s ON s.id = g."seasonId"
		 WHERE gp."userId" = $1
		 ORDER BY g."updatedAt" DESC, g."createdAt" DESC
		 LIMIT $2
	`, playerID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []PlayerGameHistoryEntry
	for rows.Next() {
		var entry PlayerGameHistoryEntry
		if err := rows.Scan(
			&entry.GameCode,
			&entry.Status,
			&entry.LossVoided,
			&entry.CreatedAt,
			&entry.UpdatedAt,
			&entry.SeasonID,
			&entry.SeasonName,
			&entry.Win,
			&entry.MVP,
			&entry.PreElo,
			&entry.PostElo,
			&entry.EloDiff,
		); err != nil {
			return nil, err
		}
		list = append(list, entry)
	}
	return list, rows.Err()
}
