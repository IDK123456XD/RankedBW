package storage

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"
)

// CreateScreenshareRecord inserts a new screenshare ticket row for tracking.
func CreateScreenshareRecord(ctx context.Context, requesterID, frozenID, channelID string, createdAt time.Time, proofURL string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	seasonName := ""
	if season, err := ActiveSeason(ctx); err == nil && season != nil {
		seasonName = strings.TrimSpace(season.Name)
	}
	var seasonValue interface{}
	if seasonName != "" {
		seasonValue = seasonName
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO screenshare (requester_id, frozen_id, channel_id, created_at, status, taken_by, proof, season)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
	`, strings.TrimSpace(requesterID), strings.TrimSpace(frozenID), strings.TrimSpace(channelID), createdAt, "UNCLAIMED", nil, strings.TrimSpace(proofURL), seasonValue)
	return err
}

// MarkScreenshareTaken marks an existing formatted row as taken by the provided user.
func MarkScreenshareTaken(ctx context.Context, requesterID, frozenID string, createdAt time.Time, takenBy string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if requesterID == "" || frozenID == "" || createdAt.IsZero() {
		return nil
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE screenshare
		   SET status = $4,
		       taken_by = $5
		 WHERE requester_id = $1
		   AND frozen_id = $2
		   AND created_at = $3
	`, strings.TrimSpace(requesterID), strings.TrimSpace(frozenID), createdAt, "TAKEN", strings.TrimSpace(takenBy))
	return err
}

// MarkScreenshareFinishedByChannel marks an existing row as finished by channel id.
func MarkScreenshareFinishedByChannel(ctx context.Context, channelID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	channelID = strings.TrimSpace(channelID)
	if channelID == "" {
		return nil
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE screenshare
		   SET status = $2
		 WHERE channel_id = $1
	`, channelID, "FINISHED")
	return err
}

// ScreenshareRequest represents a pending /ss row that may need expiration.
type ScreenshareRequest struct {
	RequesterID string
	FrozenID    string
	ChannelID   string
	CreatedAt   time.Time
}

// GetPendingScreenshareRequestsBefore returns all requests still marked as unclaimed before the cutoff time.
func GetPendingScreenshareRequestsBefore(ctx context.Context, cutoff time.Time) ([]ScreenshareRequest, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT requester_id, frozen_id, channel_id, created_at
		FROM screenshare
		WHERE status = 'UNCLAIMED' AND created_at <= $1
	`, cutoff)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []ScreenshareRequest{}
	for rows.Next() {
		var rec ScreenshareRequest
		var channelID sql.NullString
		var createdAtRaw interface{}
		if err := rows.Scan(&rec.RequesterID, &rec.FrozenID, &channelID, &createdAtRaw); err != nil {
			return nil, err
		}
		if channelID.Valid {
			rec.ChannelID = strings.TrimSpace(channelID.String)
		}
		if createdAt, err := parseTimeValue(createdAtRaw); err == nil {
			rec.CreatedAt = createdAt
		}
		out = append(out, rec)
	}
	return out, rows.Err()
}

// ScreenshareLeaderboardRow represents a leaderboard entry by staff member.
type ScreenshareLeaderboardRow struct {
	TakenBy    string
	TakenCount int
}

// ScreenshareLeaderboard returns the screenshare leaderboard for the provided season name.
func ScreenshareLeaderboard(ctx context.Context, season string, limit, offset int) ([]ScreenshareLeaderboardRow, error) {
	season = strings.TrimSpace(season)
	if season == "" {
		return nil, errors.New("season is required")
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT taken_by, COUNT(1)
		FROM screenshare
		WHERE status IN ('TAKEN', 'FINISHED')
		  AND season = $1
		  AND taken_by IS NOT NULL
		  AND taken_by <> ''
		GROUP BY taken_by
		ORDER BY COUNT(1) DESC, taken_by ASC
		LIMIT $2 OFFSET $3
	`, season, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []ScreenshareLeaderboardRow{}
	for rows.Next() {
		var row ScreenshareLeaderboardRow
		if err := rows.Scan(&row.TakenBy, &row.TakenCount); err != nil {
			return nil, err
		}
		out = append(out, row)
	}
	return out, rows.Err()
}

// ScreenshareLeaderboardTotal returns the total number of leaderboard rows for a season.
func ScreenshareLeaderboardTotal(ctx context.Context, season string) (int, error) {
	season = strings.TrimSpace(season)
	if season == "" {
		return 0, errors.New("season is required")
	}
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var count int
	if err := conn.QueryRowContext(ctx, `
		SELECT COUNT(DISTINCT taken_by)
		FROM screenshare
		WHERE status IN ('TAKEN', 'FINISHED')
		  AND season = $1
		  AND taken_by IS NOT NULL
		  AND taken_by <> ''
	`, season).Scan(&count); err != nil {
		return 0, err
	}
	return count, nil
}

// ScreenshareUnclaimedCount returns the number of unclaimed screenshares for a season.
func ScreenshareUnclaimedCount(ctx context.Context, season string) (int, error) {
	season = strings.TrimSpace(season)
	if season == "" {
		return 0, errors.New("season is required")
	}
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var count int
	if err := conn.QueryRowContext(ctx, `
		SELECT COUNT(1)
		FROM screenshare
		WHERE season = $1
		  AND (
		    status = 'UNCLAIMED'
		    OR (status = 'FINISHED' AND (taken_by IS NULL OR taken_by = ''))
		  )
	`, season).Scan(&count); err != nil {
		return 0, err
	}
	return count, nil
}

// ScreenshareChannelExists returns true if the channel_id exists in the screenshare table.
func ScreenshareChannelExists(ctx context.Context, channelID string) (bool, error) {
	channelID = strings.TrimSpace(channelID)
	if channelID == "" {
		return false, errors.New("channel id is required")
	}
	conn, err := getDB()
	if err != nil {
		return false, err
	}
	var exists bool
	if err := conn.QueryRowContext(ctx, `
		SELECT EXISTS (
			SELECT 1
			FROM screenshare
			WHERE channel_id = $1
		)
	`, channelID).Scan(&exists); err != nil {
		return false, err
	}
	return exists, nil
}

func parseTimeValue(value interface{}) (time.Time, error) {
	switch v := value.(type) {
	case time.Time:
		return v, nil
	case string:
		return parseTimeString(v)
	case []byte:
		return parseTimeString(string(v))
	case nil:
		return time.Time{}, errors.New("created_at is nil")
	default:
		return time.Time{}, fmt.Errorf("unsupported created_at type %T", value)
	}
}

func parseTimeString(value string) (time.Time, error) {
	trimmed := strings.TrimSpace(value)
	if trimmed == "" {
		return time.Time{}, errors.New("created_at is empty")
	}
	layouts := []string{
		time.RFC3339Nano,
		time.RFC3339,
		"2006-01-02 15:04:05",
		"2006-01-02 15:04:05Z07",
		"2006-01-02 15:04:05-07:00",
		"2006-01-02 15:04:05.999999",
		"2006-01-02 15:04:05.999999Z07",
		"2006-01-02 15:04:05.999999-07:00",
	}
	for _, layout := range layouts {
		if t, err := time.Parse(layout, trimmed); err == nil {
			return t, nil
		}
	}
	return time.Time{}, fmt.Errorf("unrecognized created_at format: %q", trimmed)
}
