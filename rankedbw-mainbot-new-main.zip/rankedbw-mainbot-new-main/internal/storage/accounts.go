package storage

import (
	"context"
	"time"
)

// UpsertAccountRegistration links a Discord user to a Minecraft account in "Accounts".
func UpsertAccountRegistration(ctx context.Context, userID, ign, uuid string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}

	now := time.Now().UTC() // <-- define `now` before using it

	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() { _ = tx.Rollback() }() // ensure rollback if commit fails

	// Try UPDATE first
	res, err := tx.ExecContext(ctx, `
		UPDATE "Player"
		   SET "minecraftName"=$2,
		       "uuid"=$3,
		       "lastMojangFetch"=$4,
		       "updatedAt"=$4
		 WHERE "userId"=$1
	`, userID, ign, uuid, now)
	if err != nil {
		return err
	}

	rows, _ := res.RowsAffected()
	if rows == 0 {
		// Insert new record if none updated
		_, err = tx.ExecContext(ctx, `
			INSERT INTO "Player"
				("userId","minecraftName","uuid","lastMojangFetch","createdAt","updatedAt")
			VALUES ($1,$2,$3,$4,$4,$4)
		`, userID, ign, uuid, now)
		if err != nil {
			return err
		}
	}

	return tx.Commit()
}
