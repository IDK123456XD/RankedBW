package storage

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"
)

// EnsureVoiceChannelsTable creates the voicechannels table if it does not exist.
func EnsureVoiceChannelsTable(ctx context.Context) error {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		CREATE TABLE IF NOT EXISTS voicechannels (
			channel_id TEXT PRIMARY KEY,
			channel_name TEXT NOT NULL,
			created_at TIMESTAMPTZ NOT NULL,
			last_joined TIMESTAMPTZ
		)
	`)
	return err
}

// UpsertVoiceChannel inserts or updates a voicechannel row by channel_id.
func UpsertVoiceChannel(ctx context.Context, channelID, channelName string, createdAt time.Time, lastJoined *time.Time) error {
	if ctx == nil {
		ctx = context.Background()
	}
	channelID = strings.TrimSpace(channelID)
	channelName = strings.TrimSpace(channelName)
	if channelID == "" || channelName == "" {
		return errors.New("channel id and name are required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	var lastJoinedVal sql.NullTime
	if lastJoined != nil {
		lastJoinedVal = sql.NullTime{Time: lastJoined.UTC(), Valid: true}
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO voicechannels (channel_id, channel_name, created_at, last_joined)
		VALUES ($1, $2, $3, $4)
		ON CONFLICT (channel_id) DO UPDATE
		   SET channel_name = EXCLUDED.channel_name,
		       created_at = LEAST(voicechannels.created_at, EXCLUDED.created_at),
		       last_joined = COALESCE(EXCLUDED.last_joined, voicechannels.last_joined)
	`, channelID, channelName, createdAt.UTC(), lastJoinedVal)
	return err
}

// GetVoiceChannelLastJoined returns the last_joined timestamp for a channel.
func GetVoiceChannelLastJoined(ctx context.Context, channelID string) (*time.Time, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	channelID = strings.TrimSpace(channelID)
	if channelID == "" {
		return nil, errors.New("channel id is required")
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var last sql.NullTime
	if err := conn.QueryRowContext(ctx, `
		SELECT last_joined
		FROM voicechannels
		WHERE channel_id = $1
	`, channelID).Scan(&last); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, err
	}
	if !last.Valid {
		return nil, nil
	}
	t := last.Time.UTC()
	return &t, nil
}

// DeleteVoiceChannel removes a channel row by id.
func DeleteVoiceChannel(ctx context.Context, channelID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	channelID = strings.TrimSpace(channelID)
	if channelID == "" {
		return errors.New("channel id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		DELETE FROM voicechannels
		WHERE channel_id = $1
	`, channelID)
	return err
}

// ListVoiceChannelIDs returns all stored channel IDs.
func ListVoiceChannelIDs(ctx context.Context) ([]string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `SELECT channel_id FROM voicechannels`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		id = strings.TrimSpace(id)
		if id != "" {
			ids = append(ids, id)
		}
	}
	return ids, rows.Err()
}
