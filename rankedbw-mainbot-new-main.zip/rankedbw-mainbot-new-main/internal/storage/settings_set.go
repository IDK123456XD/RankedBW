package storage

import (
	"context"
	"fmt"
)

// SetSettingsColumn updates a single column in the single-row Settings table.
// The column name must be validated by the caller to prevent SQL injection.
func SetSettingsColumn(ctx context.Context, column string, value *string) error {
	if column == "" {
		return fmt.Errorf("column name required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	query := fmt.Sprintf(`UPDATE "Settings" SET "%s" = $1`, column)
	var arg interface{}
	if value != nil && *value != "" {
		arg = *value
	} else {
		arg = nil
	}
	_, err = conn.ExecContext(ctx, query, arg)
	return err
}
