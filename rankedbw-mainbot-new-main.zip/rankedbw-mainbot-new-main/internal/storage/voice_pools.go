package storage

import "context"

type VoicePoolConfig struct {
	CategoryID string
	BaseCount  int
}

func ListVoicePools(ctx context.Context) ([]VoicePoolConfig, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT "categoryId","baseCount"
		  FROM "VoicePools"
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var pools []VoicePoolConfig
	for rows.Next() {
		var cfg VoicePoolConfig
		if err := rows.Scan(&cfg.CategoryID, &cfg.BaseCount); err != nil {
			return nil, err
		}
		pools = append(pools, cfg)
	}
	return pools, rows.Err()
}

func UpsertVoicePool(ctx context.Context, cfg VoicePoolConfig) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "VoicePools" ("categoryId","baseCount")
		VALUES ($1,$2)
		ON CONFLICT ("categoryId")
		DO UPDATE SET "baseCount"=EXCLUDED."baseCount"
	`, cfg.CategoryID, cfg.BaseCount)
	return err
}

func DeleteVoicePool(ctx context.Context, categoryID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		DELETE FROM "VoicePools"
		 WHERE "categoryId"=$1
	`, categoryID)
	return err
}
