package storage

import (
	"context"
	"database/sql"
	"errors"
)

type QueueConfig struct {
	ChannelID string
	MinElo    int
	MaxElo    int
	Setup     string
}

func ListQueueConfigs(ctx context.Context) ([]QueueConfig, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	if err := ensureQueueConfigSetupColumn(ctx, conn); err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT "channelId","minElo","maxElo",COALESCE("setup",'')
		  FROM "QueueConfig"
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var configs []QueueConfig
	for rows.Next() {
		var cfg QueueConfig
		if err := rows.Scan(&cfg.ChannelID, &cfg.MinElo, &cfg.MaxElo, &cfg.Setup); err != nil {
			return nil, err
		}
		configs = append(configs, cfg)
	}
	return configs, rows.Err()
}

func UpsertQueueConfig(ctx context.Context, cfg QueueConfig) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	if err := ensureQueueConfigSetupColumn(ctx, conn); err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "QueueConfig" ("channelId","minElo","maxElo","setup")
		VALUES ($1,$2,$3,$4)
		ON CONFLICT ("channelId")
		DO UPDATE SET "minElo"=EXCLUDED."minElo","maxElo"=EXCLUDED."maxElo","setup"=EXCLUDED."setup"
	`, cfg.ChannelID, cfg.MinElo, cfg.MaxElo, cfg.Setup)
	return err
}

func DeleteQueueConfig(ctx context.Context, channelID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		DELETE FROM "QueueConfig"
		 WHERE "channelId"=$1
	`, channelID)
	return err
}

func ensureQueueConfigSetupColumn(ctx context.Context, conn *sql.DB) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if conn == nil {
		return errors.New("db connection is nil")
	}
	_, err := conn.ExecContext(ctx, `
		ALTER TABLE "QueueConfig"
		ADD COLUMN IF NOT EXISTS "setup" TEXT
	`)
	return err
}
