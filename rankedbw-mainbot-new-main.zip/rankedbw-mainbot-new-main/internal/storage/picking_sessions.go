package storage

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgconn"
)

// PickingSession tracks an active picking phase for a queued match.
type PickingSession struct {
	ID               string
	QueueChannelID   string
	PickingChannelID string
	ThreadID         string
	MessageID        string
	GameCode         string
	SeasonID         string
	Captain1ID       string
	Captain2ID       string
	PickIndex        int
	CreatedAt        time.Time
	ExpiresAt        time.Time
}

// PickingSessionPlayer tracks a player's assignment within a picking session.
type PickingSessionPlayer struct {
	SessionID string
	UserID    string
	PlayerID  string
	Elo       int
	Team      int
	PickedAt  sql.NullTime
}

var (
	ErrPickingSessionChanged    = errors.New("picking session state changed")
	ErrPickingPlayerUnavailable = errors.New("picking player unavailable")
)

// EnsurePickingSessionsTable creates the picking session tables if they do not exist.
func EnsurePickingSessionsTable(ctx context.Context) error {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	if err := ensurePickingTable(ctx, conn, "PickingSession", `
		CREATE TABLE IF NOT EXISTS "PickingSession" (
			id TEXT PRIMARY KEY,
			"queueChannelId" TEXT NOT NULL,
			"pickingChannelId" TEXT NOT NULL,
			"threadId" TEXT,
			"messageId" TEXT,
			"gameCode" TEXT NOT NULL,
			"seasonId" TEXT NOT NULL,
			"captain1Id" TEXT NOT NULL,
			"captain2Id" TEXT NOT NULL,
			"pickIndex" INT NOT NULL DEFAULT 0,
			"createdAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
			"expiresAt" TIMESTAMPTZ NOT NULL
		)
	`); err != nil {
		return err
	}
	if err := ensurePickingSessionColumns(ctx, conn); err != nil {
		return err
	}
	return ensurePickingTable(ctx, conn, "PickingSessionPlayer", `
		CREATE TABLE IF NOT EXISTS "PickingSessionPlayer" (
			"sessionId" TEXT NOT NULL REFERENCES "PickingSession"(id) ON DELETE CASCADE,
			"userId" TEXT NOT NULL,
			"playerId" TEXT NOT NULL,
			"elo" INT NOT NULL,
			"team" INT NOT NULL DEFAULT 0,
			"pickedAt" TIMESTAMPTZ,
			PRIMARY KEY ("sessionId","userId")
		)
	`)
}

// CreatePickingSession inserts a picking session and its players.
func CreatePickingSession(ctx context.Context, session PickingSession, players []PickingSessionPlayer) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if strings.TrimSpace(session.ID) == "" {
		return errors.New("session id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	_, err = tx.ExecContext(ctx, `
		INSERT INTO "PickingSession"
			(id,"queueChannelId","pickingChannelId","threadId","messageId","gameCode","seasonId","captain1Id","captain2Id","pickIndex","createdAt","expiresAt")
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
	`, session.ID, session.QueueChannelID, session.PickingChannelID, nullableString(session.ThreadID), nullableString(session.MessageID), session.GameCode, session.SeasonID, session.Captain1ID, session.Captain2ID, session.PickIndex, session.CreatedAt, session.ExpiresAt)
	if err != nil {
		return err
	}

	for _, p := range players {
		_, err = tx.ExecContext(ctx, `
			INSERT INTO "PickingSessionPlayer"
				("sessionId","userId","playerId","elo","team","pickedAt")
			VALUES ($1,$2,$3,$4,$5,$6)
		`, session.ID, p.UserID, p.PlayerID, p.Elo, p.Team, nullableTime(p.PickedAt))
		if err != nil {
			return err
		}
	}
	return tx.Commit()
}

// GetPickingSession returns a picking session by ID.
func GetPickingSession(ctx context.Context, sessionID string) (*PickingSession, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	sessionID = strings.TrimSpace(sessionID)
	if sessionID == "" {
		return nil, nil
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var session PickingSession
	var threadID sql.NullString
	var messageID sql.NullString
	err = conn.QueryRowContext(ctx, `
		SELECT id,"queueChannelId","pickingChannelId","threadId","messageId","gameCode","seasonId","captain1Id","captain2Id","pickIndex","createdAt","expiresAt"
		  FROM "PickingSession"
		 WHERE id = $1
		 LIMIT 1
	`, sessionID).Scan(
		&session.ID,
		&session.QueueChannelID,
		&session.PickingChannelID,
		&threadID,
		&messageID,
		&session.GameCode,
		&session.SeasonID,
		&session.Captain1ID,
		&session.Captain2ID,
		&session.PickIndex,
		&session.CreatedAt,
		&session.ExpiresAt,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if threadID.Valid {
		session.ThreadID = strings.TrimSpace(threadID.String)
	}
	if messageID.Valid {
		session.MessageID = strings.TrimSpace(messageID.String)
	}
	return &session, nil
}

// GetPickingSessionByChannel returns a session by picking channel ID.
func GetPickingSessionByChannel(ctx context.Context, channelID string) (*PickingSession, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	channelID = strings.TrimSpace(channelID)
	if channelID == "" {
		return nil, nil
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var session PickingSession
	var threadID sql.NullString
	var messageID sql.NullString
	err = conn.QueryRowContext(ctx, `
		SELECT id,"queueChannelId","pickingChannelId","threadId","messageId","gameCode","seasonId","captain1Id","captain2Id","pickIndex","createdAt","expiresAt"
		  FROM "PickingSession"
		 WHERE "pickingChannelId" = $1
		 LIMIT 1
	`, channelID).Scan(
		&session.ID,
		&session.QueueChannelID,
		&session.PickingChannelID,
		&threadID,
		&messageID,
		&session.GameCode,
		&session.SeasonID,
		&session.Captain1ID,
		&session.Captain2ID,
		&session.PickIndex,
		&session.CreatedAt,
		&session.ExpiresAt,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if threadID.Valid {
		session.ThreadID = strings.TrimSpace(threadID.String)
	}
	if messageID.Valid {
		session.MessageID = strings.TrimSpace(messageID.String)
	}
	return &session, nil
}

// ListActivePickingSessions returns all sessions that have not expired.
func ListActivePickingSessions(ctx context.Context) ([]PickingSession, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id,"queueChannelId","pickingChannelId","threadId","messageId","gameCode","seasonId","captain1Id","captain2Id","pickIndex","createdAt","expiresAt"
		  FROM "PickingSession"
		 WHERE "expiresAt" > now()
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var sessions []PickingSession
	for rows.Next() {
		var session PickingSession
		var threadID sql.NullString
		var messageID sql.NullString
		if err := rows.Scan(
			&session.ID,
			&session.QueueChannelID,
			&session.PickingChannelID,
			&threadID,
			&messageID,
			&session.GameCode,
			&session.SeasonID,
			&session.Captain1ID,
			&session.Captain2ID,
			&session.PickIndex,
			&session.CreatedAt,
			&session.ExpiresAt,
		); err != nil {
			return nil, err
		}
		if threadID.Valid {
			session.ThreadID = strings.TrimSpace(threadID.String)
		}
		if messageID.Valid {
			session.MessageID = strings.TrimSpace(messageID.String)
		}
		sessions = append(sessions, session)
	}
	return sessions, rows.Err()
}

// ListExpiredPickingSessions returns sessions whose expiry has elapsed.
func ListExpiredPickingSessions(ctx context.Context, now time.Time) ([]PickingSession, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if now.IsZero() {
		now = time.Now().UTC()
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id,"queueChannelId","pickingChannelId","threadId","messageId","gameCode","seasonId","captain1Id","captain2Id","pickIndex","createdAt","expiresAt"
		  FROM "PickingSession"
		 WHERE "expiresAt" <= $1
	`, now)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var sessions []PickingSession
	for rows.Next() {
		var session PickingSession
		var threadID sql.NullString
		var messageID sql.NullString
		if err := rows.Scan(
			&session.ID,
			&session.QueueChannelID,
			&session.PickingChannelID,
			&threadID,
			&messageID,
			&session.GameCode,
			&session.SeasonID,
			&session.Captain1ID,
			&session.Captain2ID,
			&session.PickIndex,
			&session.CreatedAt,
			&session.ExpiresAt,
		); err != nil {
			return nil, err
		}
		if threadID.Valid {
			session.ThreadID = strings.TrimSpace(threadID.String)
		}
		if messageID.Valid {
			session.MessageID = strings.TrimSpace(messageID.String)
		}
		sessions = append(sessions, session)
	}
	return sessions, rows.Err()
}

// ListPickingSessionPlayers loads all players for a picking session.
func ListPickingSessionPlayers(ctx context.Context, sessionID string) ([]PickingSessionPlayer, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	sessionID = strings.TrimSpace(sessionID)
	if sessionID == "" {
		return nil, errors.New("session id is required")
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT "sessionId","userId","playerId","elo","team","pickedAt"
		  FROM "PickingSessionPlayer"
		 WHERE "sessionId" = $1
	`, sessionID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var players []PickingSessionPlayer
	for rows.Next() {
		var p PickingSessionPlayer
		if err := rows.Scan(&p.SessionID, &p.UserID, &p.PlayerID, &p.Elo, &p.Team, &p.PickedAt); err != nil {
			return nil, err
		}
		players = append(players, p)
	}
	return players, rows.Err()
}

// UpdatePickingSessionPickIndex updates the pick index for a session.
func UpdatePickingSessionPickIndex(ctx context.Context, sessionID string, pickIndex int) error {
	if ctx == nil {
		ctx = context.Background()
	}
	sessionID = strings.TrimSpace(sessionID)
	if sessionID == "" {
		return errors.New("session id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "PickingSession"
		   SET "pickIndex" = $2
		 WHERE id = $1
	`, sessionID, pickIndex)
	return err
}

// UpdatePickingSessionMessageID updates the prompt message id for a session.
func UpdatePickingSessionMessageID(ctx context.Context, sessionID, messageID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	sessionID = strings.TrimSpace(sessionID)
	if sessionID == "" {
		return errors.New("session id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "PickingSession"
		   SET "messageId" = $2
		 WHERE id = $1
	`, sessionID, nullableString(messageID))
	return err
}

// AssignPickingSessionPlayer sets a player's team assignment in a session.
func AssignPickingSessionPlayer(ctx context.Context, sessionID, userID string, team int) error {
	if ctx == nil {
		ctx = context.Background()
	}
	sessionID = strings.TrimSpace(sessionID)
	userID = strings.TrimSpace(userID)
	if sessionID == "" || userID == "" {
		return errors.New("session id and user id are required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "PickingSessionPlayer"
		   SET "team" = $3,
		       "pickedAt" = now()
		 WHERE "sessionId" = $1
		   AND "userId" = $2
	`, sessionID, userID, team)
	return err
}

// ApplyPickingSelection assigns a player to a team and advances the pick index if unchanged.
func ApplyPickingSelection(ctx context.Context, sessionID, pickedUserID string, expectedPickIndex int, team int) (int, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	sessionID = strings.TrimSpace(sessionID)
	pickedUserID = strings.TrimSpace(pickedUserID)
	if sessionID == "" || pickedUserID == "" {
		return 0, errors.New("session id and user id are required")
	}
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return 0, err
	}
	defer func() {
		if err != nil {
			_ = tx.Rollback()
		}
	}()

	var current int
	if err = tx.QueryRowContext(ctx, `
		SELECT "pickIndex"
		  FROM "PickingSession"
		 WHERE id = $1
		 FOR UPDATE
	`, sessionID).Scan(&current); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return 0, ErrPickingSessionChanged
		}
		return 0, err
	}
	if current != expectedPickIndex {
		return 0, ErrPickingSessionChanged
	}

	res, err := tx.ExecContext(ctx, `
		UPDATE "PickingSessionPlayer"
		   SET "team" = $3,
		       "pickedAt" = now()
		 WHERE "sessionId" = $1
		   AND "userId" = $2
		   AND "team" = 0
	`, sessionID, pickedUserID, team)
	if err != nil {
		return 0, err
	}
	affected, err := res.RowsAffected()
	if err != nil {
		return 0, err
	}
	if affected == 0 {
		return 0, ErrPickingPlayerUnavailable
	}

	next := current + 1
	if _, err = tx.ExecContext(ctx, `
		UPDATE "PickingSession"
		   SET "pickIndex" = $2
		 WHERE id = $1
	`, sessionID, next); err != nil {
		return 0, err
	}
	if err = tx.Commit(); err != nil {
		return 0, err
	}
	return next, nil
}

// DeletePickingSession removes a picking session and its players.
func DeletePickingSession(ctx context.Context, sessionID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	sessionID = strings.TrimSpace(sessionID)
	if sessionID == "" {
		return errors.New("session id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		DELETE FROM "PickingSession"
		 WHERE id = $1
	`, sessionID)
	return err
}

func nullableTime(val sql.NullTime) any {
	if val.Valid {
		return val.Time
	}
	return nil
}

func nullableString(val string) any {
	if strings.TrimSpace(val) == "" {
		return nil
	}
	return strings.TrimSpace(val)
}

func ensurePickingTable(ctx context.Context, conn *sql.DB, tableName, ddl string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if conn == nil {
		return errors.New("db connection is nil")
	}
	if err := execPickingDDL(ctx, conn, tableName, ddl); err != nil {
		return err
	}
	return nil
}

func execPickingDDL(ctx context.Context, conn *sql.DB, tableName, ddl string) error {
	if _, err := conn.ExecContext(ctx, ddl); err == nil {
		return nil
	} else if !isPgTypeDuplicate(err) {
		return err
	}

	exists, err := pickingTableExists(ctx, conn, tableName)
	if err == nil && exists {
		return nil
	}

	if err := dropPickingType(ctx, conn, tableName); err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, ddl)
	return err
}

func pickingTableExists(ctx context.Context, conn *sql.DB, tableName string) (bool, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if conn == nil {
		return false, errors.New("db connection is nil")
	}
	tableName = strings.TrimSpace(tableName)
	if tableName == "" {
		return false, errors.New("table name is required")
	}
	var reg sql.NullString
	ident := fmt.Sprintf(`"%s"`, tableName)
	if err := conn.QueryRowContext(ctx, `SELECT to_regclass($1)`, ident).Scan(&reg); err != nil {
		return false, err
	}
	return reg.Valid && strings.TrimSpace(reg.String) != "", nil
}

func dropPickingType(ctx context.Context, conn *sql.DB, typeName string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if conn == nil {
		return errors.New("db connection is nil")
	}
	typeName = strings.TrimSpace(typeName)
	if typeName == "" {
		return errors.New("type name is required")
	}
	_, err := conn.ExecContext(ctx, fmt.Sprintf(`DROP TYPE IF EXISTS "%s"`, typeName))
	return err
}

func isPgTypeDuplicate(err error) bool {
	var pgErr *pgconn.PgError
	if !errors.As(err, &pgErr) {
		return false
	}
	if pgErr.Code != "23505" {
		return false
	}
	if strings.EqualFold(pgErr.ConstraintName, "pg_type_typname_nsp_index") {
		return true
	}
	if strings.Contains(strings.ToLower(pgErr.Message), "pg_type_typname_nsp_index") {
		return true
	}
	return false
}

func ensurePickingSessionColumns(ctx context.Context, conn *sql.DB) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if conn == nil {
		return errors.New("db connection is nil")
	}
	if _, err := conn.ExecContext(ctx, `ALTER TABLE "PickingSession" ADD COLUMN IF NOT EXISTS "threadId" TEXT`); err != nil {
		return err
	}
	_, err := conn.ExecContext(ctx, `ALTER TABLE "PickingSession" ADD COLUMN IF NOT EXISTS "messageId" TEXT`)
	return err
}
