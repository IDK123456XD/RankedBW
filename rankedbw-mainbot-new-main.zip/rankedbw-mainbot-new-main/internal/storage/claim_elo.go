package storage

import (
	"context"
	"errors"
	"strings"
	"time"
)

// ClaimEloRule defines a Discord role that can claim a starting Elo amount,
// along with the maximum number of times it can be claimed per season.
type ClaimEloRule struct {
	ID        string
	RoleID    string
	Amount    int
	MaxClaims int
	CreatedAt time.Time
}

// ListClaimEloRules returns all configured claim-elo rules ordered by amount descending.
func ListClaimEloRules(ctx context.Context) ([]ClaimEloRule, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id, role_id, amount, max_claims, created_at
		  FROM claim_elo_rule
		 ORDER BY amount DESC, created_at ASC
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var rules []ClaimEloRule
	for rows.Next() {
		var r ClaimEloRule
		if err := rows.Scan(&r.ID, &r.RoleID, &r.Amount, &r.MaxClaims, &r.CreatedAt); err != nil {
			return nil, err
		}
		if r.MaxClaims <= 0 {
			r.MaxClaims = 1
		}
		rules = append(rules, r)
	}
	return rules, rows.Err()
}

// UpsertClaimEloRule inserts or updates a rule keyed by role ID.
func UpsertClaimEloRule(ctx context.Context, roleID string, amount, maxClaims int) error {
	roleID = strings.TrimSpace(roleID)
	if roleID == "" {
		return errors.New("role id is required")
	}
	if amount <= 0 {
		return errors.New("amount must be positive")
	}
	if maxClaims <= 0 {
		maxClaims = 1
	}

	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO claim_elo_rule (role_id, amount, max_claims)
		     VALUES ($1,$2,$3)
		ON CONFLICT (role_id)
		  DO UPDATE SET amount=$2, max_claims=$3
	`, roleID, amount, maxClaims)
	return err
}

// DeleteClaimEloRule removes a claim-elo rule for the given role.
func DeleteClaimEloRule(ctx context.Context, roleID string) error {
	roleID = strings.TrimSpace(roleID)
	if roleID == "" {
		return errors.New("role id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `DELETE FROM claim_elo_rule WHERE role_id=$1`, roleID)
	return err
}

// CountClaimEloUses returns how many times the player has claimed using this role in the season.
func CountClaimEloUses(ctx context.Context, playerID, seasonID, roleID string) (int, error) {
	playerID = strings.TrimSpace(playerID)
	seasonID = strings.TrimSpace(seasonID)
	roleID = strings.TrimSpace(roleID)
	if playerID == "" || seasonID == "" || roleID == "" {
		return 0, errors.New("player, season, and role ids are required")
	}
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var count int
	if err := conn.QueryRowContext(ctx, `
		SELECT COUNT(1)
		  FROM claim_elo_usage
		 WHERE player_id=$1 AND season_id=$2 AND role_id=$3
	`, playerID, seasonID, roleID).Scan(&count); err != nil {
		return 0, err
	}
	return count, nil
}

// RecordClaimEloUse stores a claim usage for auditing and limits.
func RecordClaimEloUse(ctx context.Context, playerID, seasonID, roleID string, amount int) error {
	playerID = strings.TrimSpace(playerID)
	seasonID = strings.TrimSpace(seasonID)
	roleID = strings.TrimSpace(roleID)
	if playerID == "" || seasonID == "" || roleID == "" {
		return errors.New("player, season, and role ids are required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO claim_elo_usage (player_id, season_id, role_id, amount, created_at)
		     VALUES ($1,$2,$3,$4,now())
	`, playerID, seasonID, roleID, amount)
	return err
}
