package storage

import (
	"context"
)

// EnsureAllPlayerSeasonStats ensures every player has a PlayerStatistics row for the season.
// Returns the number of rows inserted.
func EnsureAllPlayerSeasonStats(ctx context.Context, seasonID string) (int, error) {
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	res, err := conn.ExecContext(ctx, `
		INSERT INTO "PlayerStatistics" (id,"playerId","seasonId")
		SELECT gen_random_uuid()::text, p.id, $1
		  FROM "Player" p
		 WHERE NOT EXISTS (
			SELECT 1
			  FROM "PlayerStatistics" ps
			 WHERE ps."playerId" = p.id
			   AND ps."seasonId" = $1
		)
	`, seasonID)
	if err != nil {
		return 0, err
	}
	affected, _ := res.RowsAffected()
	return int(affected), nil
}

// AllPlayers returns lightweight player rows for auditing purposes.
// It intentionally selects only the columns required for nickname + rank audits.
func AllPlayers(ctx context.Context) ([]PlayerRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id,"userId","minecraftName",nickname,"eloPrefix"
		  FROM "Player"
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []PlayerRecord
	for rows.Next() {
		var rec PlayerRecord
		if err := rows.Scan(&rec.ID, &rec.UserID, &rec.MinecraftName, &rec.Nickname, &rec.EloPrefix); err != nil {
			return nil, err
		}
		list = append(list, rec)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return list, nil
}

// SeasonEloByPlayerID returns a map of playerID -> elo for the provided season.
func SeasonEloByPlayerID(ctx context.Context, seasonID string) (map[string]int, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT "playerId","elo"
		  FROM "PlayerStatistics"
		 WHERE "seasonId" = $1
	`, seasonID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	result := make(map[string]int)
	for rows.Next() {
		var playerID string
		var elo int
		if err := rows.Scan(&playerID, &elo); err != nil {
			return nil, err
		}
		result[playerID] = elo
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return result, nil
}
