package storage

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"
)

type GameRecord struct {
	ID         string
	GameID     string
	Status     string
	LossVoided bool
	Reason     sql.NullString
	SeasonID   sql.NullString
	MapName    sql.NullString
	GameStyle  sql.NullString
	CreatedAt  time.Time
	Team1Voice sql.NullString
	Team2Voice sql.NullString
	ThreadID   sql.NullString
	ThreadSave sql.NullString
	ProofURL   sql.NullString
	ProofBy    sql.NullString
}

type GamePlayerRecord struct {
	ID            string
	PlayerID      string
	DiscordID     string
	MinecraftName string
	UUID          string
	HeadSkin      string
	Win           bool
	PreElo        int
	PostElo       int
	MVP           bool
	DiscordTeam   int
	EloDiff       int
}

type PlayerGameSummary struct {
	Game    GameRecord
	Win     bool
	PreElo  int
	PostElo int
	EloDiff int
	MVP     bool
}

func GetGameWithPlayers(ctx context.Context, gameID string) (*GameRecord, []GamePlayerRecord, error) {
	// Prefer a match in the active season; fall back to any season if not found.
	if seasonID, err := ActiveSeasonID(ctx); err == nil && strings.TrimSpace(seasonID) != "" {
		if game, players, err := getGameWithPlayers(ctx, gameID, &seasonID); err != nil {
			return nil, nil, err
		} else if game != nil {
			return game, players, nil
		}
	}
	return getGameWithPlayers(ctx, gameID, nil)
}

// GameProofSubmitted returns true if a game has proof submitted.
func GameProofSubmitted(ctx context.Context, gameID string) (bool, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	gameID = strings.TrimSpace(gameID)
	if gameID == "" {
		return false, nil
	}
	conn, err := getDB()
	if err != nil {
		return false, err
	}
	var submitted bool
	err = conn.QueryRowContext(ctx, `
		SELECT CASE
			WHEN COALESCE("proof_url",'') <> '' OR COALESCE("proof_submitted_by",'') <> '' THEN true
			ELSE false
		END
		  FROM "Game"
		 WHERE "gameId" = $1
		 ORDER BY "createdAt" DESC
		 LIMIT 1
	`, gameID).Scan(&submitted)
	if errors.Is(err, sql.ErrNoRows) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return submitted, nil
}

// GetGameWithPlayersForSeason returns the game and players scoped to the provided season ID.
func GetGameWithPlayersForSeason(ctx context.Context, gameID, seasonID string) (*GameRecord, []GamePlayerRecord, error) {
	seasonID = strings.TrimSpace(seasonID)
	if seasonID == "" {
		return nil, nil, errors.New("season id is required")
	}
	return getGameWithPlayers(ctx, gameID, &seasonID)
}

// GetGameWithPlayersActiveSeason loads the game for the current active season.
// It returns the game, its players, and the season ID used for the lookup.
func GetGameWithPlayersActiveSeason(ctx context.Context, gameID string) (*GameRecord, []GamePlayerRecord, string, error) {
	seasonID, err := ActiveSeasonID(ctx)
	if err != nil {
		return nil, nil, "", err
	}
	game, players, err := GetGameWithPlayersForSeason(ctx, gameID, seasonID)
	if err != nil {
		return nil, nil, "", err
	}
	return game, players, seasonID, nil
}

func getGameWithPlayers(ctx context.Context, gameID string, seasonID *string) (*GameRecord, []GamePlayerRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, nil, err
	}

	var game GameRecord
	var row *sql.Row
	if seasonID != nil {
		row = conn.QueryRowContext(ctx, `
			SELECT id,"gameId","status","lossVoided","reason","seasonId","mapPlaying","gameStyle","createdAt","team1Voice","team2Voice","queueThreadChannelId","proof_url","proof_submitted_by","thread_save"
			  FROM "Game"
			 WHERE "gameId"=$1
			   AND "seasonId"=$2
			 LIMIT 1
		`, gameID, *seasonID)
	} else {
		row = conn.QueryRowContext(ctx, `
			SELECT id,"gameId","status","lossVoided","reason","seasonId","mapPlaying","gameStyle","createdAt","team1Voice","team2Voice","queueThreadChannelId","proof_url","proof_submitted_by","thread_save"
			  FROM "Game"
			 WHERE "gameId"=$1
			 LIMIT 1
		`, gameID)
	}

	if err := row.Scan(&game.ID, &game.GameID, &game.Status, &game.LossVoided, &game.Reason, &game.SeasonID, &game.MapName, &game.GameStyle, &game.CreatedAt, &game.Team1Voice, &game.Team2Voice, &game.ThreadID, &game.ProofURL, &game.ProofBy, &game.ThreadSave); errors.Is(err, sql.ErrNoRows) {
		return nil, nil, nil
	} else if err != nil {
		return nil, nil, err
	}

	rows, err := conn.QueryContext(ctx, `
		SELECT gp.id,
		       gp."userId" AS player_id,
		       COALESCE(p."userId",'') AS discord_id,
		       COALESCE(p."minecraftName",'') AS minecraft_name,
		       COALESCE(p."uuid",'') AS uuid,
		       COALESCE(p."headSkin",'') AS head_skin,
		       gp."win",
		       gp."preElo",
		       gp."postElo",
		       gp."mvp",
		       gp."discordTeam",
		       COALESCE(gp."eloDiff",0)
		  FROM "GamePlayer" gp
		  LEFT JOIN "Player" p ON p.id = gp."userId"
		 WHERE gp."gameId"=$1
	`, game.ID)
	if err != nil {
		return nil, nil, err
	}
	defer rows.Close()

	var players []GamePlayerRecord
	for rows.Next() {
		var (
			gp            GamePlayerRecord
			playerID      string
			discord       sql.NullString
			minecraftName sql.NullString
			uuid          sql.NullString
			headSkin      sql.NullString
		)
		if err := rows.Scan(&gp.ID, &playerID, &discord, &minecraftName, &uuid, &headSkin, &gp.Win, &gp.PreElo, &gp.PostElo, &gp.MVP, &gp.DiscordTeam, &gp.EloDiff); err != nil {
			return nil, nil, err
		}
		gp.PlayerID = strings.TrimSpace(playerID)
		if discord.Valid && strings.TrimSpace(discord.String) != "" {
			gp.DiscordID = strings.TrimSpace(discord.String)
		}
		if minecraftName.Valid {
			gp.MinecraftName = strings.TrimSpace(minecraftName.String)
		}
		if uuid.Valid {
			gp.UUID = strings.TrimSpace(uuid.String)
		}
		if headSkin.Valid {
			gp.HeadSkin = strings.TrimSpace(headSkin.String)
		}
		players = append(players, gp)
	}
	if err := rows.Err(); err != nil {
		return nil, nil, err
	}

	return &game, players, nil
}

// GetGameWithPlayersByThread finds a game and its players by the queue thread channel ID.
// Prefers the active season, falling back to any season if not found.
func GetGameWithPlayersByThread(ctx context.Context, threadID string) (*GameRecord, []GamePlayerRecord, error) {
	threadID = strings.TrimSpace(threadID)
	if threadID == "" {
		return nil, nil, errors.New("thread id is required")
	}

	if seasonID, err := ActiveSeasonID(ctx); err == nil && strings.TrimSpace(seasonID) != "" {
		if game, players, err := getGameWithPlayersByThread(ctx, threadID, &seasonID); err != nil {
			return nil, nil, err
		} else if game != nil {
			return game, players, nil
		}
	}
	return getGameWithPlayersByThread(ctx, threadID, nil)
}

func getGameWithPlayersByThread(ctx context.Context, threadID string, seasonID *string) (*GameRecord, []GamePlayerRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, nil, err
	}

	var game GameRecord
	var row *sql.Row
	if seasonID != nil {
		row = conn.QueryRowContext(ctx, `
			SELECT id,"gameId","status","lossVoided","reason","seasonId","mapPlaying","gameStyle","createdAt","team1Voice","team2Voice","queueThreadChannelId","proof_url","proof_submitted_by","thread_save"
			  FROM "Game"
			 WHERE "queueThreadChannelId"=$1
			   AND "seasonId"=$2
			 LIMIT 1
		`, threadID, *seasonID)
	} else {
		row = conn.QueryRowContext(ctx, `
			SELECT id,"gameId","status","lossVoided","reason","seasonId","mapPlaying","gameStyle","createdAt","team1Voice","team2Voice","queueThreadChannelId","proof_url","proof_submitted_by","thread_save"
			  FROM "Game"
			 WHERE "queueThreadChannelId"=$1
			 LIMIT 1
		`, threadID)
	}

	if err := row.Scan(&game.ID, &game.GameID, &game.Status, &game.LossVoided, &game.Reason, &game.SeasonID, &game.MapName, &game.GameStyle, &game.CreatedAt, &game.Team1Voice, &game.Team2Voice, &game.ThreadID, &game.ProofURL, &game.ProofBy, &game.ThreadSave); errors.Is(err, sql.ErrNoRows) {
		return nil, nil, nil
	} else if err != nil {
		return nil, nil, err
	}

	rows, err := conn.QueryContext(ctx, `
		SELECT gp.id,
		       gp."userId" AS player_id,
		       COALESCE(p."userId",'') AS discord_id,
		       COALESCE(p."minecraftName",'') AS minecraft_name,
		       COALESCE(p."uuid",'') AS uuid,
		       COALESCE(p."headSkin",'') AS head_skin,
		       gp."win",
		       gp."preElo",
		       gp."postElo",
		       gp."mvp",
		       gp."discordTeam",
		       COALESCE(gp."eloDiff",0)
		  FROM "GamePlayer" gp
		  LEFT JOIN "Player" p ON p.id = gp."userId"
		 WHERE gp."gameId"=$1
	`, game.ID)
	if err != nil {
		return nil, nil, err
	}
	defer rows.Close()

	var players []GamePlayerRecord
	for rows.Next() {
		var (
			gp            GamePlayerRecord
			playerID      string
			discord       sql.NullString
			minecraftName sql.NullString
			uuid          sql.NullString
			headSkin      sql.NullString
		)
		if err := rows.Scan(&gp.ID, &playerID, &discord, &minecraftName, &uuid, &headSkin, &gp.Win, &gp.PreElo, &gp.PostElo, &gp.MVP, &gp.DiscordTeam, &gp.EloDiff); err != nil {
			return nil, nil, err
		}
		gp.PlayerID = strings.TrimSpace(playerID)
		if discord.Valid && strings.TrimSpace(discord.String) != "" {
			gp.DiscordID = strings.TrimSpace(discord.String)
		}
		if minecraftName.Valid {
			gp.MinecraftName = strings.TrimSpace(minecraftName.String)
		}
		if uuid.Valid {
			gp.UUID = strings.TrimSpace(uuid.String)
		}
		if headSkin.Valid {
			gp.HeadSkin = strings.TrimSpace(headSkin.String)
		}
		players = append(players, gp)
	}
	if err := rows.Err(); err != nil {
		return nil, nil, err
	}

	return &game, players, nil
}

// GetGameWithPlayersByVoice finds a game and its players by a team voice channel ID.
// Prefers the active season, falling back to any season if not found.
func GetGameWithPlayersByVoice(ctx context.Context, voiceChannelID string) (*GameRecord, []GamePlayerRecord, error) {
	voiceChannelID = strings.TrimSpace(voiceChannelID)
	if voiceChannelID == "" {
		return nil, nil, errors.New("voice channel id is required")
	}

	if seasonID, err := ActiveSeasonID(ctx); err == nil && strings.TrimSpace(seasonID) != "" {
		if game, players, err := getGameWithPlayersByVoice(ctx, voiceChannelID, &seasonID); err != nil {
			return nil, nil, err
		} else if game != nil {
			return game, players, nil
		}
	}
	return getGameWithPlayersByVoice(ctx, voiceChannelID, nil)
}

func getGameWithPlayersByVoice(ctx context.Context, voiceChannelID string, seasonID *string) (*GameRecord, []GamePlayerRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, nil, err
	}

	var game GameRecord
	var row *sql.Row
	if seasonID != nil {
		row = conn.QueryRowContext(ctx, `
			SELECT id,"gameId","status","lossVoided","reason","seasonId","mapPlaying","gameStyle","createdAt","team1Voice","team2Voice","queueThreadChannelId","proof_url","proof_submitted_by","thread_save"
			  FROM "Game"
			 WHERE $1 IN ("team1Voice","team2Voice")
			   AND "seasonId"=$2
			 LIMIT 1
		`, voiceChannelID, *seasonID)
	} else {
		row = conn.QueryRowContext(ctx, `
			SELECT id,"gameId","status","lossVoided","reason","seasonId","mapPlaying","gameStyle","createdAt","team1Voice","team2Voice","queueThreadChannelId","proof_url","proof_submitted_by","thread_save"
			  FROM "Game"
			 WHERE $1 IN ("team1Voice","team2Voice")
			 LIMIT 1
		`, voiceChannelID)
	}

	if err := row.Scan(&game.ID, &game.GameID, &game.Status, &game.LossVoided, &game.Reason, &game.SeasonID, &game.MapName, &game.GameStyle, &game.CreatedAt, &game.Team1Voice, &game.Team2Voice, &game.ThreadID, &game.ProofURL, &game.ProofBy, &game.ThreadSave); errors.Is(err, sql.ErrNoRows) {
		return nil, nil, nil
	} else if err != nil {
		return nil, nil, err
	}

	rows, err := conn.QueryContext(ctx, `
		SELECT gp.id,
		       gp."userId" AS player_id,
		       COALESCE(p."userId",'') AS discord_id,
		       COALESCE(p."minecraftName",'') AS minecraft_name,
		       COALESCE(p."uuid",'') AS uuid,
		       COALESCE(p."headSkin",'') AS head_skin,
		       gp."win",
		       gp."preElo",
		       gp."postElo",
		       gp."mvp",
		       gp."discordTeam",
		       COALESCE(gp."eloDiff",0)
		  FROM "GamePlayer" gp
		  LEFT JOIN "Player" p ON p.id = gp."userId"
		 WHERE gp."gameId"=$1
	`, game.ID)
	if err != nil {
		return nil, nil, err
	}
	defer rows.Close()

	var players []GamePlayerRecord
	for rows.Next() {
		var (
			gp            GamePlayerRecord
			playerID      string
			discord       sql.NullString
			minecraftName sql.NullString
			uuid          sql.NullString
			headSkin      sql.NullString
		)
		if err := rows.Scan(&gp.ID, &playerID, &discord, &minecraftName, &uuid, &headSkin, &gp.Win, &gp.PreElo, &gp.PostElo, &gp.MVP, &gp.DiscordTeam, &gp.EloDiff); err != nil {
			return nil, nil, err
		}
		gp.PlayerID = strings.TrimSpace(playerID)
		if discord.Valid && strings.TrimSpace(discord.String) != "" {
			gp.DiscordID = strings.TrimSpace(discord.String)
		}
		if minecraftName.Valid {
			gp.MinecraftName = strings.TrimSpace(minecraftName.String)
		}
		if uuid.Valid {
			gp.UUID = strings.TrimSpace(uuid.String)
		}
		if headSkin.Valid {
			gp.HeadSkin = strings.TrimSpace(headSkin.String)
		}
		players = append(players, gp)
	}
	if err := rows.Err(); err != nil {
		return nil, nil, err
	}

	return &game, players, nil
}

// UpdateGameProof stores the submitted proof URL and submitter for a game.
func UpdateGameProof(ctx context.Context, gameID, proofURL, submittedBy string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Game"
		   SET proof_url = $2,
		       proof_submitted_by = $3,
		       "updatedAt" = now()
		 WHERE id = $1
	`, gameID, strings.TrimSpace(proofURL), strings.TrimSpace(submittedBy))
	return err
}

// UpdateGameTranscriptLink stores the saved transcript link for a game.
func UpdateGameTranscriptLink(ctx context.Context, gameID, link string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Game"
		   SET thread_save = $2,
		       "updatedAt" = now()
		 WHERE id = $1
	`, gameID, strings.TrimSpace(link))
	return err
}

func MarkGameLossVoided(ctx context.Context, gameID string, reason string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Game"
		   SET "lossVoided" = true,
		       "reason" = $2,
		       "updatedAt" = now()
		 WHERE id = $1
	`, gameID, reason)
	return err
}

// AutoClosePendingGames marks stale pending games as auto-closed for the provided season.
func AutoClosePendingGames(ctx context.Context, seasonID string, cutoff time.Time) ([]GameRecord, error) {
	seasonID = strings.TrimSpace(seasonID)
	if seasonID == "" {
		return nil, errors.New("season id is required")
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		UPDATE "Game"
		   SET status = 'AUTO_CLOSED',
		       "updatedAt" = now()
		 WHERE "seasonId" = $1
		   AND status = 'PENDING'
		   AND "finished" = false
		   AND (proof_submitted_by IS NULL OR proof_submitted_by = '')
		   AND "createdAt" <= $2
		RETURNING id,"gameId","seasonId","createdAt"
	`, seasonID, cutoff)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var games []GameRecord
	for rows.Next() {
		var game GameRecord
		if err := rows.Scan(&game.ID, &game.GameID, &game.SeasonID, &game.CreatedAt); err != nil {
			return nil, err
		}
		games = append(games, game)
	}
	return games, rows.Err()
}

func RecentGamesForPlayer(ctx context.Context, playerID string, limit, offset int) ([]PlayerGameSummary, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	if limit <= 0 {
		limit = 5
	}
	if limit > 25 {
		limit = 25
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT g.id,g."gameId",g.status,g."lossVoided",g.reason,g."seasonId",g."createdAt",
		       gp.win,gp."preElo",gp."postElo",COALESCE(gp."eloDiff",0),gp."mvp"
		  FROM "GamePlayer" gp
		  JOIN "Player" p ON p.id = gp."userId"
		  JOIN "Game" g ON g.id = gp."gameId"
		  JOIN "Season" s ON s.id = g."seasonId" AND s.active = true
		 WHERE p.id = $1
		 ORDER BY g."createdAt" DESC
		 LIMIT $2 OFFSET $3
	`, playerID, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []PlayerGameSummary
	for rows.Next() {
		var summary PlayerGameSummary
		if err := rows.Scan(
			&summary.Game.ID,
			&summary.Game.GameID,
			&summary.Game.Status,
			&summary.Game.LossVoided,
			&summary.Game.Reason,
			&summary.Game.SeasonID,
			&summary.Game.CreatedAt,
			&summary.Win,
			&summary.PreElo,
			&summary.PostElo,
			&summary.EloDiff,
			&summary.MVP,
		); err != nil {
			return nil, err
		}
		list = append(list, summary)
	}
	return list, rows.Err()
}

func RecentGamesForPlayerSeason(ctx context.Context, playerID, seasonID string, limit, offset int) ([]PlayerGameSummary, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	if limit <= 0 {
		limit = 5
	}
	if limit > 25 {
		limit = 25
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT g.id,g."gameId",g.status,g."lossVoided",g.reason,g."seasonId",g."createdAt",
		       gp.win,gp."preElo",gp."postElo",COALESCE(gp."eloDiff",0),gp."mvp"
		  FROM "GamePlayer" gp
		  JOIN "Player" p ON p.id = gp."userId"
		  JOIN "Game" g ON g.id = gp."gameId"
		 WHERE p.id = $1
		   AND g."seasonId" = $2
		 ORDER BY g."createdAt" DESC
		 LIMIT $3 OFFSET $4
	`, playerID, seasonID, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []PlayerGameSummary
	for rows.Next() {
		var summary PlayerGameSummary
		if err := rows.Scan(
			&summary.Game.ID,
			&summary.Game.GameID,
			&summary.Game.Status,
			&summary.Game.LossVoided,
			&summary.Game.Reason,
			&summary.Game.SeasonID,
			&summary.Game.CreatedAt,
			&summary.Win,
			&summary.PreElo,
			&summary.PostElo,
			&summary.EloDiff,
			&summary.MVP,
		); err != nil {
			return nil, err
		}
		list = append(list, summary)
	}
	return list, rows.Err()
}

// CountGamesForPlayerSeason returns the number of games a player has in a season.
func CountGamesForPlayerSeason(ctx context.Context, playerID, seasonID string) (int, error) {
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var count int
	err = conn.QueryRowContext(ctx, `
		SELECT COUNT(1)
		  FROM "GamePlayer" gp
		  JOIN "Game" g ON g.id = gp."gameId"
		 WHERE gp."userId" = $1
		   AND g."seasonId" = $2
	`, playerID, seasonID).Scan(&count)
	return count, err
}

// MarkGamePlayerMVP sets the MVP flag and updates the stored post-game Elo for a participant.
func MarkGamePlayerMVP(ctx context.Context, gamePlayerID string, postElo int) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	res, err := conn.ExecContext(ctx, `
		UPDATE "GamePlayer"
		   SET "mvp" = true,
		       "postElo" = $2
		 WHERE id = $1
	`, gamePlayerID, postElo)
	if err != nil {
		return err
	}
	if rows, err := res.RowsAffected(); err == nil && rows == 0 {
		return sql.ErrNoRows
	} else if err != nil {
		return err
	}
	return nil
}
