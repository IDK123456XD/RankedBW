package storage

import (
	"context"
	"database/sql"
	"errors"
	"os"
	"strings"
)

// InfocardRecord describes a card definition from the Infocard table.
type InfocardRecord struct {
	ID    string
	Name  string
	Image string
	Color string
}

// PlayerInfocardStatus pairs a card definition with an ownership flag.
type PlayerInfocardStatus struct {
	InfocardRecord
	Owned bool
}

const (
	infocardNameLight            = "light"
	infocardNameDark             = "dark"
	infocardNameWinter           = "Winter 2025"
	infocardDefaultFallback      = infocardNameLight
	infocardWinterSeasonFallback = "S1"
)

// EnsureInfocardCatalog ensures the standard cards exist and returns the light card ID.
func EnsureInfocardCatalog(ctx context.Context) (string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return "", err
	}

	defaultID, err := lookupInfocardID(ctx, conn, "default")
	if err != nil {
		return "", err
	}
	lightID, err := lookupInfocardID(ctx, conn, infocardNameLight)
	if err != nil {
		return "", err
	}

	if defaultID != "" {
		if lightID != "" && lightID != defaultID {
			if err := EnsurePlayerInfocardsTable(ctx); err != nil {
				return "", err
			}
			if _, err := conn.ExecContext(ctx, `
				UPDATE "Player"
				   SET "selectedInfocardId" = $2
				 WHERE "selectedInfocardId" = $1
			`, defaultID, lightID); err != nil {
				return "", err
			}
			if _, err := conn.ExecContext(ctx, `
				INSERT INTO "PlayerInfocard" ("playerId","infocardId","grantedBy","grantedAt")
				SELECT "playerId", $2, "grantedBy", "grantedAt"
				  FROM "PlayerInfocard"
				 WHERE "infocardId" = $1
				ON CONFLICT ("playerId","infocardId") DO NOTHING
			`, defaultID, lightID); err != nil {
				return "", err
			}
			if _, err := conn.ExecContext(ctx, `
				DELETE FROM "PlayerInfocard"
				 WHERE "infocardId" = $1
			`, defaultID); err != nil {
				return "", err
			}
			if _, err := conn.ExecContext(ctx, `
				DELETE FROM "Infocard"
				 WHERE id = $1
			`, defaultID); err != nil {
				return "", err
			}
		} else if lightID == "" {
			if _, err := conn.ExecContext(ctx, `
				UPDATE "Infocard"
				   SET name = $2,
				       image = $3,
				       color = $4
				 WHERE id = $1
			`, defaultID, infocardNameLight, "light.png", "light"); err != nil {
				return "", err
			}
			lightID = defaultID
		}
	}

	if lightID == "" {
		var err error
		lightID, err = ensureInfocardByName(ctx, conn, infocardNameLight, "light.png", "light")
		if err != nil {
			return "", err
		}
	} else {
		if err := ensureInfocardUpdate(ctx, conn, lightID, infocardNameLight, "light.png", "light"); err != nil {
			return "", err
		}
	}

	if _, err := ensureInfocardByName(ctx, conn, infocardNameDark, "dark.png", "dark"); err != nil {
		return "", err
	}
	winterID, err := lookupInfocardID(ctx, conn, infocardNameWinter)
	if err != nil {
		return "", err
	}
	christmasID, err := lookupInfocardID(ctx, conn, "christmas")
	if err != nil {
		return "", err
	}
	if christmasID != "" && winterID != "" && christmasID != winterID {
		if err := EnsurePlayerInfocardsTable(ctx); err != nil {
			return "", err
		}
		if _, err := conn.ExecContext(ctx, `
			UPDATE "Player"
			   SET "selectedInfocardId" = $2
			 WHERE "selectedInfocardId" = $1
		`, christmasID, winterID); err != nil {
			return "", err
		}
		if _, err := conn.ExecContext(ctx, `
			INSERT INTO "PlayerInfocard" ("playerId","infocardId","grantedBy","grantedAt")
			SELECT "playerId", $2, "grantedBy", "grantedAt"
			  FROM "PlayerInfocard"
			 WHERE "infocardId" = $1
			ON CONFLICT ("playerId","infocardId") DO NOTHING
		`, christmasID, winterID); err != nil {
			return "", err
		}
		if _, err := conn.ExecContext(ctx, `
			DELETE FROM "PlayerInfocard"
			 WHERE "infocardId" = $1
		`, christmasID); err != nil {
			return "", err
		}
		if _, err := conn.ExecContext(ctx, `
			DELETE FROM "Infocard"
			 WHERE id = $1
		`, christmasID); err != nil {
			return "", err
		}
		christmasID = ""
	}
	if christmasID != "" && winterID == "" {
		if err := ensureInfocardUpdate(ctx, conn, christmasID, infocardNameWinter, "christmas.png", "dark"); err != nil {
			return "", err
		}
		winterID = christmasID
	}
	if winterID == "" {
		if _, err := ensureInfocardByName(ctx, conn, infocardNameWinter, "christmas.png", "dark"); err != nil {
			return "", err
		}
	} else {
		if err := ensureInfocardUpdate(ctx, conn, winterID, infocardNameWinter, "christmas.png", "dark"); err != nil {
			return "", err
		}
	}

	return lightID, nil
}

// ApplyInfocardDefaults grants standard cards to all players and optionally forces the default selection.
func ApplyInfocardDefaults(ctx context.Context) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if _, err := EnsureInfocardCatalog(ctx); err != nil {
		return err
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	if err := EnsurePlayerInfocardsTable(ctx); err != nil {
		return err
	}
	lightID, darkID, winterID, err := standardInfocardIDs(ctx, conn)
	if err != nil {
		return err
	}
	if lightID == "" || darkID == "" || winterID == "" {
		return errors.New("infocard catalog is incomplete")
	}
	if err := grantInfocardToAllPlayers(ctx, conn, lightID); err != nil {
		return err
	}
	if err := grantInfocardToAllPlayers(ctx, conn, darkID); err != nil {
		return err
	}

	seasonID, err := winterSeasonID(ctx)
	if err != nil {
		return err
	}
	if seasonID != "" {
		if err := grantInfocardToSeasonPlayers(ctx, conn, winterID, seasonID); err != nil {
			return err
		}
		if err := revokeInfocardFromNonSeasonPlayers(ctx, conn, winterID, seasonID); err != nil {
			return err
		}
		if err := setSelectedInfocardForNonSeasonPlayersIfMatches(ctx, conn, winterID, lightID, seasonID); err != nil {
			return err
		}
	} else {
		if err := revokeInfocardFromAllPlayers(ctx, conn, winterID); err != nil {
			return err
		}
		if err := setSelectedInfocardForAllIfMatches(ctx, conn, winterID, lightID); err != nil {
			return err
		}
	}

	if infocardForceDefault() {
		if override, ok := infocardDefaultNameOverride(); ok {
			defaultID := lightID
			if resolved, err := lookupInfocardID(ctx, conn, override); err != nil {
				return err
			} else if resolved != "" {
				defaultID = resolved
			}
			if err := setAllPlayersSelectedInfocard(ctx, conn, defaultID); err != nil {
				return err
			}
		} else if seasonID != "" {
			if err := setSelectedInfocardForSeasonPlayers(ctx, conn, winterID, seasonID); err != nil {
				return err
			}
			if err := setSelectedInfocardForNonSeasonPlayers(ctx, conn, lightID, seasonID); err != nil {
				return err
			}
		} else {
			if err := setAllPlayersSelectedInfocard(ctx, conn, lightID); err != nil {
				return err
			}
		}
	}
	return nil
}

// GrantStandardInfocards ensures a player owns the standard cards.
func GrantStandardInfocards(ctx context.Context, playerID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	playerID = strings.TrimSpace(playerID)
	if playerID == "" {
		return errors.New("player id is required")
	}
	if _, err := EnsureInfocardCatalog(ctx); err != nil {
		return err
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	if err := EnsurePlayerInfocardsTable(ctx); err != nil {
		return err
	}
	lightID, darkID, winterID, err := standardInfocardIDs(ctx, conn)
	if err != nil {
		return err
	}
	if lightID == "" || darkID == "" || winterID == "" {
		return errors.New("infocard catalog is incomplete")
	}
	if err := GrantPlayerInfocard(ctx, playerID, lightID, ""); err != nil {
		return err
	}
	if err := GrantPlayerInfocard(ctx, playerID, darkID, ""); err != nil {
		return err
	}
	eligible, err := playerEligibleForWinter(ctx, playerID)
	if err != nil {
		return err
	}
	if eligible {
		if err := GrantPlayerInfocard(ctx, playerID, winterID, ""); err != nil {
			return err
		}
		return nil
	}
	if _, err := conn.ExecContext(ctx, `
		DELETE FROM "PlayerInfocard"
		 WHERE "playerId" = $1
		   AND "infocardId" = $2
	`, playerID, winterID); err != nil {
		return err
	}
	if _, err := conn.ExecContext(ctx, `
		UPDATE "Player"
		   SET "selectedInfocardId" = $2,
		       "updatedAt" = now()
		 WHERE id = $1
		   AND "selectedInfocardId" = $3
	`, playerID, lightID, winterID); err != nil {
		return err
	}
	return nil
}

// EnsurePlayerInfocardsTable creates the ownership table if it does not exist.
func EnsurePlayerInfocardsTable(ctx context.Context) error {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		CREATE TABLE IF NOT EXISTS "PlayerInfocard" (
			"playerId" TEXT NOT NULL REFERENCES "Player"(id) ON DELETE CASCADE,
			"infocardId" TEXT NOT NULL REFERENCES "Infocard"(id) ON DELETE CASCADE,
			"grantedBy" TEXT,
			"grantedAt" TIMESTAMPTZ NOT NULL DEFAULT now(),
			PRIMARY KEY ("playerId","infocardId")
		)
	`)
	return err
}

func standardInfocardIDs(ctx context.Context, conn *sql.DB) (string, string, string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	lightID, err := lookupInfocardID(ctx, conn, infocardNameLight)
	if err != nil {
		return "", "", "", err
	}
	darkID, err := lookupInfocardID(ctx, conn, infocardNameDark)
	if err != nil {
		return "", "", "", err
	}
	winterID, err := lookupInfocardID(ctx, conn, infocardNameWinter)
	if err != nil {
		return "", "", "", err
	}
	return lightID, darkID, winterID, nil
}

func grantInfocardToAllPlayers(ctx context.Context, conn *sql.DB, infocardID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	infocardID = strings.TrimSpace(infocardID)
	if infocardID == "" {
		return errors.New("infocard id is required")
	}
	_, err := conn.ExecContext(ctx, `
		INSERT INTO "PlayerInfocard" ("playerId","infocardId","grantedBy","grantedAt")
		SELECT p.id, $1, NULL, now()
		  FROM "Player" p
		ON CONFLICT ("playerId","infocardId") DO NOTHING
	`, infocardID)
	return err
}

func grantInfocardToSeasonPlayers(ctx context.Context, conn *sql.DB, infocardID, seasonID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	infocardID = strings.TrimSpace(infocardID)
	seasonID = strings.TrimSpace(seasonID)
	if infocardID == "" || seasonID == "" {
		return errors.New("infocard id and season id are required")
	}
	_, err := conn.ExecContext(ctx, `
		INSERT INTO "PlayerInfocard" ("playerId","infocardId","grantedBy","grantedAt")
		SELECT ps."playerId", $1, NULL, now()
		  FROM "PlayerStatistics" ps
		 WHERE ps."seasonId" = $2
		   AND (ps."gamesPlayed" > 0 OR ps."wins" > 0 OR ps."losses" > 0)
		ON CONFLICT ("playerId","infocardId") DO NOTHING
	`, infocardID, seasonID)
	return err
}

func revokeInfocardFromNonSeasonPlayers(ctx context.Context, conn *sql.DB, infocardID, seasonID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	infocardID = strings.TrimSpace(infocardID)
	seasonID = strings.TrimSpace(seasonID)
	if infocardID == "" || seasonID == "" {
		return errors.New("infocard id and season id are required")
	}
	_, err := conn.ExecContext(ctx, `
		DELETE FROM "PlayerInfocard" pi
		 WHERE pi."infocardId" = $1
		   AND NOT EXISTS (
				SELECT 1
				  FROM "PlayerStatistics" ps
				 WHERE ps."playerId" = pi."playerId"
				   AND ps."seasonId" = $2
				   AND (ps."gamesPlayed" > 0 OR ps."wins" > 0 OR ps."losses" > 0)
		   )
	`, infocardID, seasonID)
	return err
}

func revokeInfocardFromAllPlayers(ctx context.Context, conn *sql.DB, infocardID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	infocardID = strings.TrimSpace(infocardID)
	if infocardID == "" {
		return errors.New("infocard id is required")
	}
	_, err := conn.ExecContext(ctx, `
		DELETE FROM "PlayerInfocard"
		 WHERE "infocardId" = $1
	`, infocardID)
	return err
}

func setSelectedInfocardForSeasonPlayers(ctx context.Context, conn *sql.DB, infocardID, seasonID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	infocardID = strings.TrimSpace(infocardID)
	seasonID = strings.TrimSpace(seasonID)
	if infocardID == "" || seasonID == "" {
		return errors.New("infocard id and season id are required")
	}
	_, err := conn.ExecContext(ctx, `
		UPDATE "Player" p
		   SET "selectedInfocardId" = $1,
		       "updatedAt" = now()
		 WHERE p."selectedInfocardId" IS DISTINCT FROM $1
		   AND EXISTS (
				SELECT 1
				  FROM "PlayerStatistics" ps
				 WHERE ps."playerId" = p.id
				   AND ps."seasonId" = $2
				   AND (ps."gamesPlayed" > 0 OR ps."wins" > 0 OR ps."losses" > 0)
		   )
	`, infocardID, seasonID)
	return err
}

func setSelectedInfocardForNonSeasonPlayers(ctx context.Context, conn *sql.DB, infocardID, seasonID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	infocardID = strings.TrimSpace(infocardID)
	seasonID = strings.TrimSpace(seasonID)
	if infocardID == "" || seasonID == "" {
		return errors.New("infocard id and season id are required")
	}
	_, err := conn.ExecContext(ctx, `
		UPDATE "Player" p
		   SET "selectedInfocardId" = $1,
		       "updatedAt" = now()
		 WHERE p."selectedInfocardId" IS DISTINCT FROM $1
		   AND NOT EXISTS (
				SELECT 1
				  FROM "PlayerStatistics" ps
				 WHERE ps."playerId" = p.id
				   AND ps."seasonId" = $2
				   AND (ps."gamesPlayed" > 0 OR ps."wins" > 0 OR ps."losses" > 0)
		   )
	`, infocardID, seasonID)
	return err
}

func setSelectedInfocardForNonSeasonPlayersIfMatches(ctx context.Context, conn *sql.DB, fromID, toID, seasonID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	fromID = strings.TrimSpace(fromID)
	toID = strings.TrimSpace(toID)
	seasonID = strings.TrimSpace(seasonID)
	if fromID == "" || toID == "" || seasonID == "" {
		return errors.New("infocard ids and season id are required")
	}
	_, err := conn.ExecContext(ctx, `
		UPDATE "Player" p
		   SET "selectedInfocardId" = $2,
		       "updatedAt" = now()
		 WHERE p."selectedInfocardId" = $1
		   AND NOT EXISTS (
				SELECT 1
				  FROM "PlayerStatistics" ps
				 WHERE ps."playerId" = p.id
				   AND ps."seasonId" = $3
				   AND (ps."gamesPlayed" > 0 OR ps."wins" > 0 OR ps."losses" > 0)
		   )
	`, fromID, toID, seasonID)
	return err
}

func setSelectedInfocardForAllIfMatches(ctx context.Context, conn *sql.DB, fromID, toID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	fromID = strings.TrimSpace(fromID)
	toID = strings.TrimSpace(toID)
	if fromID == "" || toID == "" {
		return errors.New("infocard ids are required")
	}
	_, err := conn.ExecContext(ctx, `
		UPDATE "Player"
		   SET "selectedInfocardId" = $2,
		       "updatedAt" = now()
		 WHERE "selectedInfocardId" = $1
	`, fromID, toID)
	return err
}

func setAllPlayersSelectedInfocard(ctx context.Context, conn *sql.DB, infocardID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	infocardID = strings.TrimSpace(infocardID)
	if infocardID == "" {
		return errors.New("infocard id is required")
	}
	_, err := conn.ExecContext(ctx, `
		UPDATE "Player"
		   SET "selectedInfocardId" = $1,
		       "updatedAt" = now()
		 WHERE "selectedInfocardId" IS DISTINCT FROM $1
	`, infocardID)
	return err
}

func infocardDefaultNameOverride() (string, bool) {
	name := strings.TrimSpace(os.Getenv("INFOCARD_DEFAULT_NAME"))
	if name == "" {
		return "", false
	}
	return name, true
}

func infocardDefaultName() string {
	if name, ok := infocardDefaultNameOverride(); ok {
		return name
	}
	return infocardDefaultFallback
}

func infocardWinterSeasonName() string {
	name := strings.TrimSpace(os.Getenv("INFOCARD_WINTER_SEASON_NAME"))
	if name == "" {
		name = infocardWinterSeasonFallback
	}
	return name
}

func infocardForceDefault() bool {
	val := strings.TrimSpace(strings.ToLower(os.Getenv("INFOCARD_FORCE_DEFAULT")))
	switch val {
	case "1", "true", "yes", "y", "on":
		return true
	default:
		return false
	}
}

func winterSeasonID(ctx context.Context) (string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	name := infocardWinterSeasonName()
	if name == "" {
		return "", nil
	}
	season, err := SeasonByName(ctx, name)
	if err != nil {
		return "", err
	}
	if season == nil {
		return "", nil
	}
	return strings.TrimSpace(season.ID), nil
}

func lookupInfocardID(ctx context.Context, conn *sql.DB, name string) (string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	name = strings.TrimSpace(name)
	if name == "" {
		return "", nil
	}
	var id string
	err := conn.QueryRowContext(ctx, `
		SELECT id
		  FROM "Infocard"
		 WHERE lower(name) = lower($1)
		 LIMIT 1
	`, name).Scan(&id)
	if errors.Is(err, sql.ErrNoRows) {
		return "", nil
	}
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(id), nil
}

func ensureInfocardByName(ctx context.Context, conn *sql.DB, name, image, color string) (string, error) {
	id, err := lookupInfocardID(ctx, conn, name)
	if err != nil {
		return "", err
	}
	if id != "" {
		if err := ensureInfocardUpdate(ctx, conn, id, name, image, color); err != nil {
			return "", err
		}
		return id, nil
	}
	newID, err := randomHexID()
	if err != nil {
		return "", err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "Infocard" (id,name,image,color)
		VALUES ($1,$2,$3,$4)
	`, newID, name, image, color)
	if err != nil {
		return "", err
	}
	return newID, nil
}

func ensureInfocardUpdate(ctx context.Context, conn *sql.DB, id, name, image, color string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	_, err := conn.ExecContext(ctx, `
		UPDATE "Infocard"
		   SET name = $2,
		       image = $3,
		       color = $4
		 WHERE id = $1
	`, id, name, image, color)
	return err
}

// ListInfocardsForPlayer returns all infocard definitions with ownership status for a player.
func ListInfocardsForPlayer(ctx context.Context, playerID string) ([]PlayerInfocardStatus, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	playerID = strings.TrimSpace(playerID)
	if playerID == "" {
		return nil, errors.New("player id is required")
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT i.id, i.name, i.image, i.color,
		       (pi."playerId" IS NOT NULL) AS owned
		  FROM "Infocard" i
		  LEFT JOIN "PlayerInfocard" pi
		    ON pi."infocardId" = i.id
		   AND pi."playerId" = $1
		 ORDER BY lower(i.name) ASC
	`, playerID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []PlayerInfocardStatus
	for rows.Next() {
		var rec PlayerInfocardStatus
		var img sql.NullString
		var color sql.NullString
		if err := rows.Scan(&rec.ID, &rec.Name, &img, &color, &rec.Owned); err != nil {
			return nil, err
		}
		rec.ID = strings.TrimSpace(rec.ID)
		rec.Name = strings.TrimSpace(rec.Name)
		rec.Image = strings.TrimSpace(img.String)
		rec.Color = strings.TrimSpace(color.String)
		out = append(out, rec)
	}
	return out, rows.Err()
}

// SearchInfocards returns up to limit infocards matching the name filter.
func SearchInfocards(ctx context.Context, query string, limit int) ([]InfocardRecord, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if limit <= 0 {
		limit = 25
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id, name, image, color
		  FROM "Infocard"
		 WHERE lower(name) LIKE '%' || lower($1) || '%'
		 ORDER BY lower(name) ASC
		 LIMIT $2
	`, strings.TrimSpace(query), limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []InfocardRecord
	for rows.Next() {
		var rec InfocardRecord
		var img sql.NullString
		var color sql.NullString
		if err := rows.Scan(&rec.ID, &rec.Name, &img, &color); err != nil {
			return nil, err
		}
		rec.ID = strings.TrimSpace(rec.ID)
		rec.Name = strings.TrimSpace(rec.Name)
		rec.Image = strings.TrimSpace(img.String)
		rec.Color = strings.TrimSpace(color.String)
		out = append(out, rec)
	}
	return out, rows.Err()
}

// InfocardByID finds a card definition by ID.
func InfocardByID(ctx context.Context, id string) (*InfocardRecord, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	id = strings.TrimSpace(id)
	if id == "" {
		return nil, nil
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var rec InfocardRecord
	var img sql.NullString
	var color sql.NullString
	err = conn.QueryRowContext(ctx, `
		SELECT id, name, image, color
		  FROM "Infocard"
		 WHERE id = $1
		 LIMIT 1
	`, id).Scan(&rec.ID, &rec.Name, &img, &color)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	rec.ID = strings.TrimSpace(rec.ID)
	rec.Name = strings.TrimSpace(rec.Name)
	rec.Image = strings.TrimSpace(img.String)
	rec.Color = strings.TrimSpace(color.String)
	return &rec, nil
}

// InfocardByName finds a card definition by case-insensitive name.
func InfocardByName(ctx context.Context, name string) (*InfocardRecord, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	name = strings.TrimSpace(name)
	if name == "" {
		return nil, nil
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var rec InfocardRecord
	var img sql.NullString
	var color sql.NullString
	err = conn.QueryRowContext(ctx, `
		SELECT id, name, image, color
		  FROM "Infocard"
		 WHERE lower(name) = lower($1)
		 LIMIT 1
	`, name).Scan(&rec.ID, &rec.Name, &img, &color)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	rec.ID = strings.TrimSpace(rec.ID)
	rec.Name = strings.TrimSpace(rec.Name)
	rec.Image = strings.TrimSpace(img.String)
	rec.Color = strings.TrimSpace(color.String)
	return &rec, nil
}

// ResolveInfocard tries to resolve a card by ID, then by name.
func ResolveInfocard(ctx context.Context, value string) (*InfocardRecord, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		return nil, nil
	}
	if byID, err := InfocardByID(ctx, value); err != nil || byID != nil {
		return byID, err
	}
	return InfocardByName(ctx, value)
}

// GrantPlayerInfocard records ownership of a card for a player (idempotent).
func GrantPlayerInfocard(ctx context.Context, playerID, infocardID, grantedBy string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	playerID = strings.TrimSpace(playerID)
	infocardID = strings.TrimSpace(infocardID)
	if playerID == "" || infocardID == "" {
		return errors.New("player id and infocard id are required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "PlayerInfocard" ("playerId","infocardId","grantedBy","grantedAt")
		VALUES ($1,$2,$3,now())
		ON CONFLICT ("playerId","infocardId") DO NOTHING
	`, playerID, infocardID, optionalString(grantedBy))
	return err
}

// RevokePlayerInfocard removes ownership of a card from a player.
func RevokePlayerInfocard(ctx context.Context, playerID, infocardID string) (bool, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	playerID = strings.TrimSpace(playerID)
	infocardID = strings.TrimSpace(infocardID)
	if playerID == "" || infocardID == "" {
		return false, errors.New("player id and infocard id are required")
	}
	conn, err := getDB()
	if err != nil {
		return false, err
	}
	res, err := conn.ExecContext(ctx, `
		DELETE FROM "PlayerInfocard"
		 WHERE "playerId" = $1
		   AND "infocardId" = $2
	`, playerID, infocardID)
	if err != nil {
		return false, err
	}
	affected, err := res.RowsAffected()
	if err != nil {
		return false, err
	}
	return affected > 0, nil
}

// PlayerOwnsInfocard returns true if the player owns the specified card.
func PlayerOwnsInfocard(ctx context.Context, playerID, infocardID string) (bool, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	playerID = strings.TrimSpace(playerID)
	infocardID = strings.TrimSpace(infocardID)
	if playerID == "" || infocardID == "" {
		return false, errors.New("player id and infocard id are required")
	}
	conn, err := getDB()
	if err != nil {
		return false, err
	}
	var exists bool
	if err := conn.QueryRowContext(ctx, `
		SELECT EXISTS(
			SELECT 1
			  FROM "PlayerInfocard"
			 WHERE "playerId" = $1
			   AND "infocardId" = $2
		)
	`, playerID, infocardID).Scan(&exists); err != nil {
		return false, err
	}
	return exists, nil
}

// SetPlayerSelectedInfocard updates the active card for a player.
func SetPlayerSelectedInfocard(ctx context.Context, playerID, infocardID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	playerID = strings.TrimSpace(playerID)
	infocardID = strings.TrimSpace(infocardID)
	if playerID == "" || infocardID == "" {
		return errors.New("player id and infocard id are required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Player"
		   SET "selectedInfocardId" = $2,
		       "updatedAt" = now()
		 WHERE id = $1
	`, playerID, infocardID)
	return err
}

// PlayerHasPlayedSeason reports whether a player has recorded games in a season by name.
func PlayerHasPlayedSeason(ctx context.Context, playerID, seasonName string) (bool, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	playerID = strings.TrimSpace(playerID)
	if playerID == "" {
		return false, errors.New("player id is required")
	}
	seasonName = strings.TrimSpace(seasonName)
	if seasonName == "" {
		return false, nil
	}
	season, err := SeasonByName(ctx, seasonName)
	if err != nil {
		return false, err
	}
	if season == nil {
		return false, nil
	}
	conn, err := getDB()
	if err != nil {
		return false, err
	}
	var played bool
	err = conn.QueryRowContext(ctx, `
		SELECT ("gamesPlayed" > 0 OR "wins" > 0 OR "losses" > 0)
		  FROM "PlayerStatistics"
		 WHERE "playerId" = $1
		   AND "seasonId" = $2
		 LIMIT 1
	`, playerID, season.ID).Scan(&played)
	if errors.Is(err, sql.ErrNoRows) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return played, nil
}

// ApplySeasonalInfocardSelection updates the player's selected card based on seasonal eligibility.
func ApplySeasonalInfocardSelection(ctx context.Context, player *PlayerRecord) (string, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	if player == nil {
		return "", errors.New("player is required")
	}
	playerID := strings.TrimSpace(player.ID)
	if playerID == "" {
		return "", errors.New("player id is required")
	}
	if _, err := EnsureInfocardCatalog(ctx); err != nil {
		return "", err
	}
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	lightID, _, winterID, err := standardInfocardIDs(ctx, conn)
	if err != nil {
		return "", err
	}
	if lightID == "" || winterID == "" {
		return "", errors.New("infocard catalog is incomplete")
	}

	selectedID := ""
	if player.SelectedInfocardID.Valid {
		selectedID = strings.TrimSpace(player.SelectedInfocardID.String)
	}

	eligible, err := playerEligibleForWinter(ctx, playerID)
	if err != nil {
		return "", err
	}

	desiredID := selectedID
	if eligible {
		if selectedID == "" {
			desiredID = winterID
		}
	} else {
		if selectedID == "" {
			desiredID = lightID
		}
	}

	if desiredID != "" && desiredID != selectedID {
		if err := SetPlayerSelectedInfocard(ctx, playerID, desiredID); err != nil {
			return "", err
		}
		player.SelectedInfocardID = sql.NullString{String: desiredID, Valid: true}
		selectedID = desiredID
	}

	return selectedID, nil
}

func playerEligibleForWinter(ctx context.Context, playerID string) (bool, error) {
	seasonName := infocardWinterSeasonName()
	if seasonName == "" {
		return false, nil
	}
	return PlayerHasPlayedSeason(ctx, playerID, seasonName)
}
