package storage

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"
)

const (
	PunishmentTypeMute         = "mute"
	PunishmentTypeStrike       = "strike"
	PunishmentTypeStrikeRemove = "strikeRemove"
	PunishmentTypeRankedBan    = "rankedban"
	PunishmentTypeRankedUnban  = "rankedunban"
)

type PunishmentRecord struct {
	ID        string
	PlayerID  string
	UserID    string
	StaffID   string
	Reason    string
	Type      string
	ExpiresAt sql.NullTime
	CreatedAt time.Time
	Expired   bool
}

func CreatePunishment(ctx context.Context, playerID, staffID, reason, punishType string, expiresAt time.Time) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}

	id, err := randomHexID()
	if err != nil {
		return "", err
	}

	_, err = conn.ExecContext(ctx, `
		INSERT INTO "Punishment"
			("id","playerId","type","reason","staff","expiresAt","expired","createdAt")
		VALUES ($1,$2,$3::"PunishmentType",$4,$5,$6,$7,now())
	`, id, playerID, punishType, reason, staffID, expiresAt, false)
	if err != nil {
		return "", err
	}
	return id, nil
}

func CreateStrike(ctx context.Context, playerID, staffID, reason string) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	id, err := randomHexID()
	if err != nil {
		return "", err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "Punishment"
			("id","playerId","type","reason","staff","expired","createdAt")
		VALUES ($1,$2,'strike',$3,$4,false,now())
	`, id, playerID, reason, staffID)
	if err != nil {
		return "", err
	}
	return id, nil
}

func CreateStrikeRemoval(ctx context.Context, playerID, staffID, reason string) (string, error) {
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	id, err := randomHexID()
	if err != nil {
		return "", err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "Punishment"
			("id","playerId","type","reason","staff","expired","createdAt")
		VALUES ($1,$2,'strikeRemove',$3,$4,false,now())
	`, id, playerID, reason, staffID)
	if err != nil {
		return "", err
	}
	return id, nil
}

func FetchExpiredMutePunishments(ctx context.Context) ([]PunishmentRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}

	rows, err := conn.QueryContext(ctx, `
		SELECT p.id,
		       p."playerId",
		       pl."userId",
		       p."staff",
		       p."reason",
		       p."type",
		       p."expiresAt",
		       p."expired"
		  FROM "Punishment" p
		  JOIN "Player" pl ON pl.id = p."playerId"
		 WHERE p."expired" = false
		   AND p."type" = 'mute'
		   AND p."expiresAt" <= now()
		   AND p."expiresAt" IS NOT NULL
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var records []PunishmentRecord
	for rows.Next() {
		var rec PunishmentRecord
		if err := rows.Scan(&rec.ID, &rec.PlayerID, &rec.UserID, &rec.StaffID, &rec.Reason, &rec.Type, &rec.ExpiresAt, &rec.Expired); err != nil {
			return nil, err
		}
		records = append(records, rec)
	}
	return records, rows.Err()
}

func FetchExpiredRankedBans(ctx context.Context) ([]PunishmentRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}

	rows, err := conn.QueryContext(ctx, `
		SELECT p.id,
		       p."playerId",
		       pl."userId",
		       p."staff",
		       p."reason",
		       p."type",
		       p."expiresAt",
		       p."createdAt",
		       p."expired"
		  FROM "Punishment" p
		  JOIN "Player" pl ON pl.id = p."playerId"
		 WHERE p."expired" = false
		   AND p."type" = 'rankedban'
		   AND p."expiresAt" <= now()
		   AND p."expiresAt" IS NOT NULL
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var records []PunishmentRecord
	for rows.Next() {
		var rec PunishmentRecord
		if err := rows.Scan(&rec.ID, &rec.PlayerID, &rec.UserID, &rec.StaffID, &rec.Reason, &rec.Type, &rec.ExpiresAt, &rec.CreatedAt, &rec.Expired); err != nil {
			return nil, err
		}
		records = append(records, rec)
	}
	return records, rows.Err()
}

func FetchActiveRankedBans(ctx context.Context) ([]PunishmentRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}

	rows, err := conn.QueryContext(ctx, `
		SELECT p.id,
		       p."playerId",
		       pl."userId",
		       p."staff",
		       p."reason",
		       p."type",
		       p."expiresAt",
		       p."createdAt",
		       p."expired"
		  FROM "Punishment" p
		  JOIN "Player" pl ON pl.id = p."playerId"
		 WHERE p."expired" = false
		   AND p."type" = 'rankedban'
		   AND (p."expiresAt" IS NULL OR p."expiresAt" > now())
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var records []PunishmentRecord
	for rows.Next() {
		var rec PunishmentRecord
		if err := rows.Scan(&rec.ID, &rec.PlayerID, &rec.UserID, &rec.StaffID, &rec.Reason, &rec.Type, &rec.ExpiresAt, &rec.CreatedAt, &rec.Expired); err != nil {
			return nil, err
		}
		records = append(records, rec)
	}
	return records, rows.Err()
}

func ActiveRankedBanForPlayer(ctx context.Context, playerID string) (*PunishmentRecord, error) {
	if playerID == "" {
		return nil, nil
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var rec PunishmentRecord
	err = conn.QueryRowContext(ctx, `
		SELECT id,"playerId","staff","reason","type","expiresAt","createdAt","expired"
		  FROM "Punishment"
		 WHERE "playerId"=$1
		   AND "type"='rankedban'
		   AND "expired"=false
		   AND ("expiresAt" IS NULL OR "expiresAt" > now())
		 ORDER BY "createdAt" DESC
		 LIMIT 1
	`, playerID).Scan(&rec.ID, &rec.PlayerID, &rec.StaffID, &rec.Reason, &rec.Type, &rec.ExpiresAt, &rec.CreatedAt, &rec.Expired)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &rec, nil
}

func MarkPunishmentExpired(ctx context.Context, id string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Punishment"
		   SET "expired" = true
		 WHERE id = $1
	`, id)
	return err
}

func UpdatePunishmentExpiry(ctx context.Context, id string, expiresAt time.Time) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if strings.TrimSpace(id) == "" {
		return errors.New("punishment id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Punishment"
		   SET "expiresAt" = $2,
		       "updatedAt" = now()
		 WHERE id = $1
	`, id, expiresAt.UTC())
	return err
}

func MarkPunishmentsExpiredByPlayerType(ctx context.Context, playerID, punishType string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Punishment"
		   SET "expired" = true
		 WHERE "playerId" = $1
		   AND "type" = $2
		   AND "expired" = false
	`, playerID, punishType)
	return err
}

func ActiveStrikeCount(ctx context.Context, playerID string) (int, error) {
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var count int
	err = conn.QueryRowContext(ctx, `
		SELECT COUNT(1)
		  FROM "Punishment"
		 WHERE "playerId"=$1
		   AND "type"='strike'
		   AND "expired"=false
	`, playerID).Scan(&count)
	return count, err
}

func ActiveStrikeCountForSeason(ctx context.Context, playerID string, season *SeasonRecord) (int, error) {
	if season == nil || strings.TrimSpace(playerID) == "" {
		return 0, errors.New("player id and season are required")
	}
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	start := season.StartDate.UTC()
	end := time.Now().UTC()
	if season.EndDate.Valid {
		end = season.EndDate.Time.UTC()
	}
	var count int
	err = conn.QueryRowContext(ctx, `
		SELECT COUNT(1)
		  FROM "Punishment"
		 WHERE "playerId"=$1
		   AND "type"='strike'
		   AND "expired"=false
		   AND "createdAt">=$2
		   AND "createdAt"<=$3
	`, playerID, start, end).Scan(&count)
	return count, err
}

func LatestActiveStrike(ctx context.Context, playerID string) (*PunishmentRecord, error) {
	return latestActivePunishment(ctx, playerID, PunishmentTypeStrike)
}

func LatestActiveMute(ctx context.Context, playerID string) (*PunishmentRecord, error) {
	return latestActivePunishment(ctx, playerID, PunishmentTypeMute)
}

func LatestActiveRankedBan(ctx context.Context, playerID string) (*PunishmentRecord, error) {
	return latestActivePunishment(ctx, playerID, PunishmentTypeRankedBan)
}

func latestActivePunishment(ctx context.Context, playerID, punishType string) (*PunishmentRecord, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var rec PunishmentRecord
	err = conn.QueryRowContext(ctx, `
		SELECT id,"playerId","staff","reason","type","expiresAt","createdAt","expired"
		  FROM "Punishment"
		 WHERE "playerId"=$1
		   AND "type"=$2
		   AND "expired"=false
		 ORDER BY "createdAt" DESC
		 LIMIT 1
	`, playerID, punishType).Scan(&rec.ID, &rec.PlayerID, &rec.StaffID, &rec.Reason, &rec.Type, &rec.ExpiresAt, &rec.CreatedAt, &rec.Expired)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &rec, nil
}

func ListPunishmentsByPlayer(ctx context.Context, playerID string, limit int) ([]PunishmentRecord, error) {
	if limit <= 0 {
		limit = 20
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id,"playerId","staff","reason","type","expiresAt","createdAt","expired"
		  FROM "Punishment"
		 WHERE "playerId"=$1
		 ORDER BY "createdAt" DESC
		 LIMIT $2
	`, playerID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []PunishmentRecord
	for rows.Next() {
		var rec PunishmentRecord
		if err := rows.Scan(&rec.ID, &rec.PlayerID, &rec.StaffID, &rec.Reason, &rec.Type, &rec.ExpiresAt, &rec.CreatedAt, &rec.Expired); err != nil {
			return nil, err
		}
		list = append(list, rec)
	}
	return list, rows.Err()
}
