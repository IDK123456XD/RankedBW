package storage

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"
)

// QueueThread tracks a game thread for cleanup and debugging.
type QueueThread struct {
	ThreadID        string
	GameCode        string
	ParentChannelID string
	CreatedAt       time.Time
}

// EnsureQueueThreadsTable creates the queue thread tracker table if it does not exist.
func EnsureQueueThreadsTable(ctx context.Context) error {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	if _, err := conn.ExecContext(ctx, `
		CREATE TABLE IF NOT EXISTS "QueueThread" (
			"threadId" TEXT PRIMARY KEY,
			"gameCode" TEXT,
			"parentChannelId" TEXT,
			"createdAt" TIMESTAMPTZ NOT NULL DEFAULT now()
		)
	`); err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		CREATE INDEX IF NOT EXISTS "QueueThread_createdAt_idx" ON "QueueThread" ("createdAt")
	`)
	return err
}

// UpsertQueueThread inserts or updates a queue thread tracker row.
func UpsertQueueThread(ctx context.Context, threadID, gameCode, parentChannelID string, createdAt time.Time) error {
	if ctx == nil {
		ctx = context.Background()
	}
	threadID = strings.TrimSpace(threadID)
	if threadID == "" {
		return errors.New("thread id is required")
	}
	gameCode = strings.TrimSpace(gameCode)
	parentChannelID = strings.TrimSpace(parentChannelID)
	if createdAt.IsZero() {
		createdAt = time.Now().UTC()
	}

	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "QueueThread" ("threadId","gameCode","parentChannelId","createdAt")
		VALUES ($1,$2,$3,$4)
		ON CONFLICT ("threadId") DO UPDATE
		SET "gameCode" = CASE
				WHEN EXCLUDED."gameCode" <> '' THEN EXCLUDED."gameCode"
				ELSE "QueueThread"."gameCode"
			END,
			"parentChannelId" = CASE
				WHEN EXCLUDED."parentChannelId" <> '' THEN EXCLUDED."parentChannelId"
				ELSE "QueueThread"."parentChannelId"
			END,
			"createdAt" = LEAST("QueueThread"."createdAt", EXCLUDED."createdAt")
	`, threadID, nullableString(gameCode), nullableString(parentChannelID), createdAt)
	return err
}

// GetQueueThread returns a tracked thread by ID.
func GetQueueThread(ctx context.Context, threadID string) (*QueueThread, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	threadID = strings.TrimSpace(threadID)
	if threadID == "" {
		return nil, nil
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	var qt QueueThread
	var game sql.NullString
	var parent sql.NullString
	err = conn.QueryRowContext(ctx, `
		SELECT "threadId","gameCode","parentChannelId","createdAt"
		  FROM "QueueThread"
		 WHERE "threadId" = $1
		 LIMIT 1
	`, threadID).Scan(&qt.ThreadID, &game, &parent, &qt.CreatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if game.Valid {
		qt.GameCode = strings.TrimSpace(game.String)
	}
	if parent.Valid {
		qt.ParentChannelID = strings.TrimSpace(parent.String)
	}
	return &qt, nil
}

// ListQueueThreads returns all tracked threads.
func ListQueueThreads(ctx context.Context) ([]QueueThread, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT "threadId","gameCode","parentChannelId","createdAt"
		  FROM "QueueThread"
		 ORDER BY "createdAt" ASC
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []QueueThread
	for rows.Next() {
		var qt QueueThread
		var game sql.NullString
		var parent sql.NullString
		if err := rows.Scan(&qt.ThreadID, &game, &parent, &qt.CreatedAt); err != nil {
			return nil, err
		}
		if game.Valid {
			qt.GameCode = strings.TrimSpace(game.String)
		}
		if parent.Valid {
			qt.ParentChannelID = strings.TrimSpace(parent.String)
		}
		out = append(out, qt)
	}
	return out, rows.Err()
}

// CountQueueThreads returns the number of tracked threads.
func CountQueueThreads(ctx context.Context) (int, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	conn, err := getDB()
	if err != nil {
		return 0, err
	}
	var count int
	if err := conn.QueryRowContext(ctx, `SELECT COUNT(*) FROM "QueueThread"`).Scan(&count); err != nil {
		return 0, err
	}
	return count, nil
}

// DeleteQueueThread removes a thread tracking row.
func DeleteQueueThread(ctx context.Context, threadID string) error {
	if ctx == nil {
		ctx = context.Background()
	}
	threadID = strings.TrimSpace(threadID)
	if threadID == "" {
		return errors.New("thread id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `DELETE FROM "QueueThread" WHERE "threadId" = $1`, threadID)
	return err
}
