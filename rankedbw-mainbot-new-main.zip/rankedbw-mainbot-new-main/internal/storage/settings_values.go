package storage

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
)

// GetSettingValue returns the value of a column derived from the provided env-style key
// (e.g., WAITING_ROOM_VC_ID -> waitingRoomVcId) from the single-row Settings table.
func GetSettingValue(ctx context.Context, envKey string) (string, error) {
	col := envKeyToColumn(envKey)
	if col == "" {
		return "", fmt.Errorf("unsupported setting key: %s", envKey)
	}
	conn, err := getDB()
	if err != nil {
		return "", err
	}
	query := fmt.Sprintf(`SELECT "%s" FROM "Settings" LIMIT 1`, col)
	var val sql.NullString
	if err := conn.QueryRowContext(ctx, query).Scan(&val); err != nil {
		return "", err
	}
	if !val.Valid {
		return "", nil
	}
	return strings.TrimSpace(val.String), nil
}

func envKeyToColumn(key string) string {
	key = strings.TrimSpace(strings.ToLower(key))
	if key == "" {
		return ""
	}
	switch key {
	// Snake_case columns that should not be camelCased.
	case "register_rank",
		"game_resultls_channel",
		"screen_share_category",
		"screensharer_role_id",
		"ss_manager_role_id",
		"frozen_role_id",
		"screenshare_logs_channel",
		"ss_transcript",
		"transcript_channel_id":
		return key
	}
	parts := strings.Split(key, "_")
	var b strings.Builder
	for idx, p := range parts {
		if p == "" {
			continue
		}
		if idx == 0 {
			b.WriteString(p)
		} else {
			b.WriteString(strings.ToUpper(p[:1]))
			if len(p) > 1 {
				b.WriteString(p[1:])
			}
		}
	}
	return b.String()
}
