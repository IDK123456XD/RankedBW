package storage

import (
	"context"
	"database/sql"
	"errors"
	"strings"
)

type StaffScoringLeaderboardRow struct {
	ScorerID    string
	ScorerCount int
}

func StaffScoringLeaderboard(ctx context.Context, seasonID string, limit, offset int) ([]StaffScoringLeaderboardRow, error) {
	seasonID = strings.TrimSpace(seasonID)
	if seasonID == "" {
		return nil, errors.New("season id is required")
	}
	if limit <= 0 {
		limit = 10
	}
	if offset < 0 {
		offset = 0
	}

	conn, err := getDB()
	if err != nil {
		return nil, err
	}

	rows, err := conn.QueryContext(ctx, `
		SELECT scorer_id, COUNT(1) AS scorer_count
		  FROM (
			SELECT COALESCE(
			         substring(g.reason from '<@!?([0-9]+)>'),
			         substring(g.reason from 'by[[:space:]]+([0-9]+)')
			       ) AS scorer_id
			  FROM "Game" g
			 WHERE g."seasonId" = $1
			   AND upper(g.status::text) IN ('SCORED','FINISHED')
			   AND g.reason IS NOT NULL
		  ) scored
		 WHERE scorer_id IS NOT NULL
		   AND scorer_id <> ''
		 GROUP BY scorer_id
		 ORDER BY scorer_count DESC, scorer_id ASC
		 LIMIT $2 OFFSET $3
	`, seasonID, limit, offset)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []StaffScoringLeaderboardRow
	for rows.Next() {
		var row StaffScoringLeaderboardRow
		var scorerID sql.NullString
		if err := rows.Scan(&scorerID, &row.ScorerCount); err != nil {
			return nil, err
		}
		if scorerID.Valid {
			row.ScorerID = strings.TrimSpace(scorerID.String)
		}
		out = append(out, row)
	}
	return out, rows.Err()
}

func StaffScoringLeaderboardTotal(ctx context.Context, seasonID string) (int, error) {
	seasonID = strings.TrimSpace(seasonID)
	if seasonID == "" {
		return 0, errors.New("season id is required")
	}

	conn, err := getDB()
	if err != nil {
		return 0, err
	}

	var count int
	if err := conn.QueryRowContext(ctx, `
		SELECT COUNT(DISTINCT scorer_id)
		  FROM (
			SELECT COALESCE(
			         substring(g.reason from '<@!?([0-9]+)>'),
			         substring(g.reason from 'by[[:space:]]+([0-9]+)')
			       ) AS scorer_id
			  FROM "Game" g
			 WHERE g."seasonId" = $1
			   AND upper(g.status::text) IN ('SCORED','FINISHED')
			   AND g.reason IS NOT NULL
		  ) scored
		 WHERE scorer_id IS NOT NULL
		   AND scorer_id <> ''
	`, seasonID).Scan(&count); err != nil {
		return 0, err
	}
	return count, nil
}
