package storage

import (
	"context"
	"errors"
	"strings"
	"time"
)

// StatResetRule defines how many stat resets a role can use per season.
// MaxResets <= 0 is treated as unlimited.
type StatResetRule struct {
	ID        string
	RoleID    string
	MaxResets int
	CreatedAt time.Time
}

// ListStatResetRules returns all configured rules ordered by max_resets descending.
func ListStatResetRules(ctx context.Context) ([]StatResetRule, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id, role_id, max_resets, created_at
		  FROM stat_reset_rule
		 ORDER BY max_resets DESC, created_at ASC
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var rules []StatResetRule
	for rows.Next() {
		var r StatResetRule
		if err := rows.Scan(&r.ID, &r.RoleID, &r.MaxResets, &r.CreatedAt); err != nil {
			return nil, err
		}
		rules = append(rules, r)
	}
	return rules, rows.Err()
}

// UpsertStatResetRule inserts or updates a rule keyed by role_id.
func UpsertStatResetRule(ctx context.Context, roleID string, maxResets int) error {
	roleID = strings.TrimSpace(roleID)
	if roleID == "" {
		return errors.New("role id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		INSERT INTO stat_reset_rule (role_id, max_resets)
		     VALUES ($1,$2)
		ON CONFLICT (role_id)
		  DO UPDATE SET max_resets = $2
	`, roleID, maxResets)
	return err
}

// DeleteStatResetRule removes a stat reset rule for the given role.
func DeleteStatResetRule(ctx context.Context, roleID string) error {
	roleID = strings.TrimSpace(roleID)
	if roleID == "" {
		return errors.New("role id is required")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `DELETE FROM stat_reset_rule WHERE role_id = $1`, roleID)
	return err
}
