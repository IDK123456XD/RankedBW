package storage

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"

	"github.com/lib/pq"
)

type Party struct {
	ID         string
	LeaderID   string
	Members    []string
	Invites    []PartyInvite
	AutoWarp   bool
	LastVCJoin sql.NullTime
	CreatedAt  time.Time
}

type PartyInvite struct {
	UserID    string
	InvitedAt time.Time
}

func CreateParty(ctx context.Context, leaderID string) (*Party, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	id, err := randomHexID()
	if err != nil {
		return nil, err
	}
	now := time.Now().UTC()
	_, err = conn.ExecContext(ctx, `
		INSERT INTO "Party"
			(id,leader,members,"autoWarp","createdAt")
		VALUES ($1,$2,$3,true,$4)
	`, id, leaderID, pq.Array([]string{leaderID}), now)
	if err != nil {
		return nil, err
	}
	return &Party{
		ID:        id,
		LeaderID:  leaderID,
		Members:   []string{leaderID},
		Invites:   nil,
		AutoWarp:  true,
		CreatedAt: now,
	}, nil
}

func GetPartyByLeader(ctx context.Context, leaderID string) (*Party, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	return scanParty(conn.QueryRowContext(ctx, `
		SELECT id,leader,members,"autoWarp","lastVcJoin",invites,"createdAt"
		  FROM "Party"
		 WHERE leader=$1
		 LIMIT 1
	`, leaderID))
}

func GetPartyByMember(ctx context.Context, userID string) (*Party, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	return scanParty(conn.QueryRowContext(ctx, `
		SELECT id,leader,members,"autoWarp","lastVcJoin",invites,"createdAt"
		  FROM "Party"
		 WHERE $1 = ANY(members)
		 LIMIT 1
	`, userID))
}

func GetPartyByID(ctx context.Context, partyID string) (*Party, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	return scanParty(conn.QueryRowContext(ctx, `
		SELECT id,leader,members,"autoWarp","lastVcJoin",invites,"createdAt"
		  FROM "Party"
		 WHERE id=$1
		 LIMIT 1
	`, partyID))
}

func ListParties(ctx context.Context) ([]Party, error) {
	conn, err := getDB()
	if err != nil {
		return nil, err
	}
	rows, err := conn.QueryContext(ctx, `
		SELECT id,leader,members,"autoWarp","lastVcJoin",invites,"createdAt"
		  FROM "Party"
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var parties []Party
	for rows.Next() {
		var p Party
		if err := scanPartyRow(rows, &p); err != nil {
			return nil, err
		}
		parties = append(parties, p)
	}
	return parties, rows.Err()
}

func UpdateParty(ctx context.Context, party *Party) error {
	if party == nil {
		return errors.New("party is nil")
	}
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Party"
		   SET leader=$2,
		       members=$3,
		       "autoWarp"=$4,
		       "lastVcJoin"=$5,
		       invites=$6
		 WHERE id=$1
	`, party.ID, party.LeaderID, pq.Array(party.Members), party.AutoWarp, party.LastVCJoin, pq.Array(encodeInvites(party.Invites)))
	return err
}

func DeleteParty(ctx context.Context, partyID string) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `DELETE FROM "Party" WHERE id=$1`, partyID)
	return err
}

func UpdatePartyLastVC(ctx context.Context, partyID string, ts time.Time) error {
	conn, err := getDB()
	if err != nil {
		return err
	}
	_, err = conn.ExecContext(ctx, `
		UPDATE "Party"
		   SET "lastVcJoin"=$2
		 WHERE id=$1
	`, partyID, ts)
	return err
}

func scanParty(row *sql.Row) (*Party, error) {
	var p Party
	if err := scanPartyRow(row, &p); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, err
	}
	return &p, nil
}

func scanPartyRow(scanner interface {
	Scan(dest ...any) error
}, p *Party) error {
	var (
		memberArray []string
		inviteArray []string
	)
	if err := scanner.Scan(&p.ID, &p.LeaderID, pq.Array(&memberArray), &p.AutoWarp, &p.LastVCJoin, pq.Array(&inviteArray), &p.CreatedAt); err != nil {
		return err
	}
	p.Members = memberArray
	p.Invites = decodeInvites(inviteArray)
	return nil
}

func encodeInvites(invites []PartyInvite) []string {
	out := make([]string, 0, len(invites))
	for _, inv := range invites {
		out = append(out, inv.UserID+"|"+fmtTimestamp(inv.InvitedAt))
	}
	return out
}

func decodeInvites(entries []string) []PartyInvite {
	var invites []PartyInvite
	for _, entry := range entries {
		parts := strings.Split(entry, "|")
		if len(parts) != 2 {
			continue
		}
		ts, err := time.Parse(time.RFC3339Nano, parts[1])
		if err != nil {
			continue
		}
		invites = append(invites, PartyInvite{
			UserID:    parts[0],
			InvitedAt: ts,
		})
	}
	return invites
}

func fmtTimestamp(t time.Time) string {
	if t.IsZero() {
		return ""
	}
	return t.UTC().Format(time.RFC3339Nano)
}

// RemovePartyMember removes a user from their current party, if any.
func RemovePartyMember(ctx context.Context, userID string) (bool, error) {
	if ctx == nil {
		ctx = context.Background()
	}
	userID = strings.TrimSpace(userID)
	if userID == "" {
		return false, errors.New("user id is required")
	}
	party, err := GetPartyByMember(ctx, userID)
	if err != nil {
		return false, err
	}
	if party == nil {
		return false, nil
	}
	if party.LeaderID == userID {
		if len(party.Members) <= 1 {
			return true, DeleteParty(ctx, party.ID)
		}
		party.Members = party.Members[1:]
		party.LeaderID = party.Members[0]
	} else {
		idx := indexOfMember(party.Members, userID)
		if idx == -1 {
			return false, nil
		}
		party.Members = append(party.Members[:idx], party.Members[idx+1:]...)
	}
	if err := UpdateParty(ctx, party); err != nil {
		return false, err
	}
	return true, nil
}

func indexOfMember(list []string, value string) int {
	for idx, v := range list {
		if v == value {
			return idx
		}
	}
	return -1
}
