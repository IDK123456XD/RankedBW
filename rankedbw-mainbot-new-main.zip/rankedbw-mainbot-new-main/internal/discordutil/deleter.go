package discordutil

import (
	"log"
	"sync"
	"time"

	"github.com/bwmarrin/discordgo"
)

const defaultDeleteDelay = time.Second

type DeleteTask struct {
	ChannelID     string
	GuildID       string
	Hide          bool
	MoveMembersTo string
	Reason        string
}

type Deleter struct {
	s     *discordgo.Session
	delay time.Duration
	tasks chan DeleteTask
}

func NewDeleter(s *discordgo.Session, delay time.Duration) *Deleter {
	if delay <= 0 {
		delay = defaultDeleteDelay
	}
	d := &Deleter{
		s:     s,
		delay: delay,
		tasks: make(chan DeleteTask, 256),
	}
	go d.run()
	return d
}

func (d *Deleter) Enqueue(task DeleteTask) bool {
	if d == nil || d.s == nil {
		return false
	}
	select {
	case d.tasks <- task:
		return true
	default:
		log.Printf("delete worker backlog full, dropping delete for %s", task.ChannelID)
		return false
	}
}

func (d *Deleter) run() {
	for task := range d.tasks {
		d.handle(task)
		time.Sleep(d.delay)
	}
}

func (d *Deleter) handle(task DeleteTask) {
	if d == nil || d.s == nil || task.ChannelID == "" {
		return
	}
	if task.Hide && task.GuildID != "" {
		d.hideChannel(task.ChannelID, task.GuildID)
	}
	if task.MoveMembersTo != "" && task.GuildID != "" {
		d.moveMembers(task.GuildID, task.ChannelID, task.MoveMembersTo)
	}
	if _, err := d.s.ChannelDelete(task.ChannelID); err != nil && !isDiscordNotFound(err) {
		log.Printf("delete worker: failed to delete channel %s: %v", task.ChannelID, err)
	}
}

func (d *Deleter) hideChannel(channelID, guildID string) {
	const mask = discordgo.PermissionViewChannel | discordgo.PermissionVoiceConnect | discordgo.PermissionVoiceSpeak
	_, err := d.s.ChannelEditComplex(channelID, &discordgo.ChannelEdit{
		PermissionOverwrites: []*discordgo.PermissionOverwrite{
			{
				ID:   guildID,
				Type: discordgo.PermissionOverwriteTypeRole,
				Deny: mask,
			},
		},
	})
	if err != nil && !isDiscordNotFound(err) {
		log.Printf("delete worker: failed to hide channel %s: %v", channelID, err)
	}
}

func (d *Deleter) moveMembers(guildID, sourceChannelID, targetChannelID string) {
	guild, err := d.s.State.Guild(guildID)
	if err != nil || guild == nil {
		guild, err = d.s.Guild(guildID)
		if err != nil || guild == nil {
			log.Printf("delete worker: failed to fetch guild %s: %v", guildID, err)
			return
		}
	}
	for _, vs := range guild.VoiceStates {
		if vs.ChannelID != sourceChannelID {
			continue
		}
		target := targetChannelID
		if moveErr := d.s.GuildMemberMove(guildID, vs.UserID, &target); moveErr != nil {
			log.Printf("delete worker: move %s out of %s failed: %v", vs.UserID, sourceChannelID, moveErr)
		}
	}
}

func isDiscordNotFound(err error) bool {
	if rest, ok := err.(*discordgo.RESTError); ok {
		if rest.Response != nil && rest.Response.StatusCode == 404 {
			return true
		}
		if rest.Message != nil && rest.Message.Code == discordgo.ErrCodeUnknownChannel {
			return true
		}
	}
	return false
}

var (
	defaultDeleter *Deleter
	defaultOnce    sync.Once
)

func InitDefaultDeleter(s *discordgo.Session, delay time.Duration) {
	defaultOnce.Do(func() {
		defaultDeleter = NewDeleter(s, delay)
	})
}

func EnqueueDelete(task DeleteTask) bool {
	if defaultDeleter != nil {
		return defaultDeleter.Enqueue(task)
	}
	return false
}
