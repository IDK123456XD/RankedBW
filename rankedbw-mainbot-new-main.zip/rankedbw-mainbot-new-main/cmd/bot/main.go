package main

import (
	"context"
	"log"

	"github.com/joho/godotenv"

	"rbw-bot/internal/bot"
	"rbw-bot/internal/config"
)

func main() {
	// Load local environment variables from .env if present (no-op if missing).
	if err := godotenv.Load(); err != nil {
		log.Printf("warning: could not load .env file: %v", err)
	}

	cfg := config.FromEnv()
	log.Printf("config: guild_id=%s", cfg.GuildID)

	b, err := bot.New(cfg)
	if err != nil {
		log.Fatal(err)
	}

	if err := b.Start(context.Background()); err != nil {
		log.Fatal(err)
	}
}
