export { prisma } from '@common/database/connectors/prisma';
export type * from '@common/database/generated';

