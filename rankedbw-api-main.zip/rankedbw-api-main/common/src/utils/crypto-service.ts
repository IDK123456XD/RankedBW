import 'server-only';
import { Decimal } from 'decimal.js';
import { prisma } from '@common/database/connectors/prisma';
import axios, { AxiosError } from 'axios';
import { BlockcypherWallet, Coin } from '@common/database/generated';

type TxDirection = 'IN' | 'OUT';

interface BlockCypherHookResponse {
    id: string
    event: string
    address: string
    url: string
    token: string
    created_at: string
    confirmations?: number
}

interface CryptoPrices {
    [key: string]: number; // Coin symbol to USD price
}

// Define Litecoin network parameters
const litecoinNetwork = {
    messagePrefix: '\x19Litecoin Signed Message:\n',
    bech32: 'ltc',
    bip32: {
        public: 0x019da462, // Ltub
        private: 0x019d9cfe, // Ltpv
    },
    pubKeyHash: 0x30,
    scriptHash: 0x32,
    wif: 0xb0,
};

export class CryptoService {
    /**
     * Get current crypto prices from CoinGecko API
     */
    public static async getCryptoPrices(): Promise<CryptoPrices> {
        try {
            const response = await axios.get(
                'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,litecoin,ethereum&vs_currencies=usd',
                { timeout: 5000 }
            );

            return {
                BTC: response.data.bitcoin?.usd || 0,
                LTC: response.data.litecoin?.usd || 0,
                ETH: response.data.ethereum?.usd || 0,
            };
        } catch (error) {
            console.error('Failed to fetch crypto prices:', error);
            // Return fallback prices or throw based on your preference
            return {
                BTC: 0,
                LTC: 0,
                ETH: 0,
            };
        }
    }

    /**
     * Calculate total USD value of user's crypto holdings with 1% spread applied
     * Returns value in cents for compatibility with existing balance system
     */
    public static async getTotalBalanceInCents(userId: string): Promise<number> {
        try {
            // Get all user's crypto balances
            const balances = await prisma.balance.findMany({
                where: { userId },
                select: {
                    coin: true,
                    amount: true
                }
            });

            if (balances.length === 0) return 0;

            // Get reserved amounts to subtract from available balance
            const reservations = await prisma.reservedBalance.findMany({
                where: { userId },
                select: {
                    coin: true,
                    amount: true
                }
            });

            // Get current crypto prices
            const prices = await this.getCryptoPrices();

            // Calculate total value in USD
            let totalValue = new Decimal(0);

            for (const balance of balances) {
                const coinPrice = prices[balance.coin];
                if (coinPrice && coinPrice > 0) {
                    // Calculate reserved amount for this coin
                    const reservedForCoin = reservations
                        .filter(r => r.coin === balance.coin)
                        .reduce((sum: Decimal, r: any) => sum.add(new Decimal(r.amount.toString())), new Decimal(0));

                    // Available balance = total balance - reserved
                    const availableAmount = new Decimal(balance.amount.toString()).sub(reservedForCoin);

                    // Only count positive available amounts
                    if (availableAmount.gt(0)) {
                        const coinValue = availableAmount.mul(coinPrice);
                        totalValue = totalValue.add(coinValue);
                    }
                }
            }

            // Apply 1% spread (discount) - multiply by 0.99
            const valueWithSpread = totalValue.mul(0.99);

            // Convert to cents and return as integer
            const valueInCents = valueWithSpread.mul(100).floor();

            return valueInCents.toNumber();
        } catch (error) {
            console.error('Failed to calculate total balance:', error);
            return 0;
        }
    }

    /**
     * Reserve balance for a bet or withdrawal across multiple cryptocurrencies
     * @param userId - User ID
     * @param amountInCents - Amount to reserve in USD cents
     * @param reason - Reason for reservation (BET, WITHDRAWAL)
     * @param referenceId - Reference ID (bet ID, withdrawal ID, etc.)
     * @param expiresAt - Optional expiration date
     * @returns true if successful, false if insufficient balance
     */
    public static async reserveBalance(
        userId: string,
        amountInCents: number,
        reason: 'BET' | 'WITHDRAWAL',
        referenceId: string,
        expiresAt?: Date
    ): Promise<boolean> {
        try {
            const amountInUsd = new Decimal(amountInCents).div(100);

            // Get current available balance
            const currentBalanceInCents = await this.getTotalBalanceInCents(userId);

            if (currentBalanceInCents < amountInCents) {
                return false; // Insufficient balance
            }

            // Get user's crypto balances and current prices
            const balances = await prisma.balance.findMany({
                where: { userId },
                select: { coin: true, amount: true }
            });

            const reservations = await prisma.reservedBalance.findMany({
                where: { userId },
                select: { coin: true, amount: true }
            });

            const prices = await this.getCryptoPrices();

            // Calculate available balances for each coin
            const availableBalances: { coin: Coin, available: Decimal, usdValue: Decimal }[] = [];

            for (const balance of balances) {
                const coinPrice = prices[balance.coin];
                if (coinPrice && coinPrice > 0) {
                    const reservedForCoin = reservations
                        .filter(r => r.coin === balance.coin)
                        .reduce((sum: Decimal, r: any) => sum.add(new Decimal(r.amount.toString())), new Decimal(0));

                    const available = new Decimal(balance.amount.toString()).sub(reservedForCoin);

                    if (available.gt(0)) {
                        availableBalances.push({
                            coin: balance.coin,
                            available,
                            usdValue: available.mul(coinPrice)
                        });
                    }
                }
            }

            // Sort by USD value descending to use largest balances first
            availableBalances.sort((a, b) => b.usdValue.cmp(a.usdValue));

            // Reserve across multiple coins proportionally
            const reservationsToCreate: { coin: Coin, amount: Decimal }[] = [];
            let remainingToReserve = amountInUsd;

            for (const coinBalance of availableBalances) {
                if (remainingToReserve.lte(0)) break;

                const coinPrice = prices[coinBalance.coin];
                const maxFromThisCoin = coinBalance.usdValue;
                const toReserveFromThisCoin = Decimal.min(remainingToReserve, maxFromThisCoin);

                if (toReserveFromThisCoin.gt(0)) {
                    const coinAmountToReserve = toReserveFromThisCoin.div(coinPrice);

                    reservationsToCreate.push({
                        coin: coinBalance.coin,
                        amount: coinAmountToReserve
                    });

                    remainingToReserve = remainingToReserve.sub(toReserveFromThisCoin);
                }
            }

            // Create reservations in database
            await prisma.reservedBalance.createMany({
                data: reservationsToCreate.map(reservation => ({
                    userId,
                    coin: reservation.coin,
                    amount: reservation.amount.toString(),
                    reason: reason as 'BET' | 'WITHDRAWAL',
                    referenceId,
                    expiresAt
                }))
            });

            return true;
        } catch (error) {
            console.error('Failed to reserve balance:', error);
            return false;
        }
    }

    /**
     * Release a reservation (e.g., when a bet is cancelled)
     */
    public static async releaseReservation(referenceId: string): Promise<boolean> {
        try {
            await prisma.reservedBalance.deleteMany({
                where: { referenceId }
            });
            return true;
        } catch (error) {
            console.error('Failed to release reservation:', error);
            return false;
        }
    }

    /**
     * Confirm a reservation and actually deduct the balance (e.g., when a bet loses)
     */
    public static async confirmReservation(referenceId: string): Promise<boolean> {
        try {
            return await prisma.$transaction(async (tx) => {
                // Get all reservations for this reference
                const reservations = await tx.reservedBalance.findMany({
                    where: { referenceId }
                });

                if (reservations.length === 0) {
                    return false; // No reservations found
                }

                // Deduct from actual balances
                for (const reservation of reservations) {
                    await tx.balance.update({
                        where: {
                            userId_coin: {
                                userId: reservation.userId,
                                coin: reservation.coin
                            }
                        },
                        data: {
                            amount: { decrement: reservation.amount.toString() }
                        }
                    });
                }

                // Remove reservations
                await tx.reservedBalance.deleteMany({
                    where: { referenceId }
                });

                return true;
            });
        } catch (error) {
            console.error('Failed to confirm reservation:', error);
            return false;
        }
    }

    /**
     * Get user's balance for a specific coin
     */
    public static async getBalance(userId: string, coin: Coin): Promise<Decimal> {
        const balance = await prisma.balance.findUnique({
            where: {
                userId_coin: { userId, coin }
            }
        });

        return balance ? new Decimal(balance.amount.toString()) : new Decimal(0);
    }

    /**
     * Credit user's balance (used for deposits)
     */
    public static async creditBalance(
        userId: string,
        coin: Coin,
        amount: Decimal,
        txId?: string
    ): Promise<void> {
        await prisma.$transaction(async (tx) => {
            // Upsert balance
            await tx.balance.upsert({
                where: {
                    userId_coin: { userId, coin }
                },
                update: {
                    amount: { increment: amount.toString() }
                },
                create: {
                    userId,
                    coin,
                    amount: amount.toString()
                }
            });

            // Record transaction if txId provided
            if (txId) {
                await tx.onChainTx.upsert({
                    where: { txId },
                    update: {
                        confirmed: true
                    },
                    create: {
                        txId,
                        userId,
                        coin,
                        amount: amount.toString(),
                        direction: 'IN',
                        confirmed: true
                    }
                });
            }
        });
    }

    /**
     * Debit user's balance (used for withdrawals and bets)
     */
    public static async debitBalance(
        userId: string,
        coin: Coin,
        amount: Decimal,
        txId?: string
    ): Promise<boolean> {
        try {
            await prisma.$transaction(async (tx) => {
                // Check current balance
                const currentBalance = await tx.balance.findUnique({
                    where: { userId_coin: { userId, coin } }
                });

                const balance = currentBalance
                    ? new Decimal(currentBalance.amount.toString())
                    : new Decimal(0);

                if (balance.lt(amount)) {
                    throw new Error('Insufficient balance');
                }

                // Debit balance
                await tx.balance.update({
                    where: { userId_coin: { userId, coin } },
                    data: {
                        amount: { decrement: amount.toString() }
                    }
                });

                // Record transaction if txId provided
                if (txId) {
                    await tx.onChainTx.create({
                        data: {
                            txId,
                            userId,
                            coin,
                            amount: amount.toString(),
                            direction: 'OUT',
                            confirmed: true
                        }
                    });
                }
            });

            return true;
        } catch (error) {
            console.error('Failed to debit balance:', error);
            return false;
        }
    }

    /**
     * Transfer balance between users (for bet settlements)
     */
    public static async transferBalance(
        fromUserId: string,
        toUserId: string,
        coin: Coin,
        amount: Decimal
    ): Promise<boolean> {
        try {
            await prisma.$transaction(async (tx) => {
                // Check sender's balance
                const senderBalance = await tx.balance.findUnique({
                    where: { userId_coin: { userId: fromUserId, coin } }
                });

                const balance = senderBalance
                    ? new Decimal(senderBalance.amount.toString())
                    : new Decimal(0);

                if (balance.lt(amount)) {
                    throw new Error('Insufficient balance');
                }

                // Debit sender
                await tx.balance.update({
                    where: { userId_coin: { userId: fromUserId, coin } },
                    data: {
                        amount: { decrement: amount.toString() }
                    }
                });

                // Credit receiver
                await tx.balance.upsert({
                    where: { userId_coin: { userId: toUserId, coin } },
                    update: {
                        amount: { increment: amount.toString() }
                    },
                    create: {
                        userId: toUserId,
                        coin,
                        amount: amount.toString()
                    }
                });
            });

            return true;
        } catch (error) {
            console.error('Failed to transfer balance:', error);
            return false;
        }
    }

    /**
     * Process incoming deposit
     */
    public static async processDeposit(
        txId: string,
        address: string,
        coin: Coin,
        amount: Decimal,
        confirmations: number,
        blockHeight?: number
    ): Promise<boolean> {
        try {
            // Check if transaction already processed
            const existingTx = await prisma.onChainTx.findUnique({
                where: { txId }
            });

            if (existingTx) {
                // Update confirmation status if needed
                if (existingTx.confirmed !== (confirmations >= this.getRequiredConfirmations(coin))) {
                    await prisma.onChainTx.update({
                        where: { txId },
                        data: {
                            confirmed: confirmations >= this.getRequiredConfirmations(coin),
                            blockHeight
                        }
                    });
                }
                return true;
            }

            // Find address owner
            const depositAddress = await prisma.depositAddress.findUnique({
                where: { address }
            });

            if (!depositAddress) {
                console.warn(`Unknown deposit address: ${address}`);
                return false;
            }

            const confirmed = confirmations >= this.getRequiredConfirmations(coin);

            // Record transaction
            await prisma.onChainTx.create({
                data: {
                    txId,
                    userId: depositAddress.userId,
                    coin,
                    amount: amount.toString(),
                    direction: 'IN',
                    confirmed,
                    blockHeight,
                    address
                }
            });

            // Credit balance if confirmed
            if (confirmed) {
                await this.creditBalance(depositAddress.userId, coin, amount);
            }

            return true;
        } catch (error) {
            console.error('Failed to process deposit:', error);
            return false;
        }
    }

    /**
     * Create withdrawal request
     */
    public static async createWithdrawalRequest(
        userId: string,
        coin: Coin,
        amount: Decimal,
        toAddress: string
    ): Promise<string | null> {
        try {
            // Check balance
            const canDebit = await this.debitBalance(userId, coin, amount);
            if (!canDebit) {
                return null;
            }

            // Create withdrawal request
            const withdrawal = await prisma.withdrawalRequest.create({
                data: {
                    userId,
                    coin,
                    amount: amount.toString(),
                    toAddress,
                    status: 'PENDING'
                }
            });

            return withdrawal.id;
        } catch (error) {
            console.error('Failed to create withdrawal request:', error);
            return null;
        }
    }

    /**
     * Get pending withdrawal requests
     */
    public static async getPendingWithdrawals(coin?: Coin): Promise<Array<{
        id: string;
        userId: string;
        coin: Coin;
        amount: Decimal;
        toAddress: string;
        createdAt: Date;
    }>> {
        const withdrawals = await prisma.withdrawalRequest.findMany({
            where: {
                status: 'PENDING',
                ...(coin ? { coin } : {})
            },
            orderBy: { createdAt: 'asc' }
        });

        return withdrawals.map(w => ({
            id: w.id,
            userId: w.userId,
            coin: w.coin as Coin,
            amount: new Decimal(w.amount.toString()),
            toAddress: w.toAddress,
            createdAt: w.createdAt
        }));
    }

    /**
     * Mark withdrawal as completed
     */
    public static async completeWithdrawal(withdrawalId: string, txId: string): Promise<void> {
        await prisma.withdrawalRequest.update({
            where: { id: withdrawalId },
            data: {
                status: 'COMPLETED',
                txId,
                processedAt: new Date()
            }
        });
    }

    /**
     * Mark withdrawal as failed
     */
    public static async failWithdrawal(withdrawalId: string, reason: string): Promise<void> {
        const withdrawal = await prisma.withdrawalRequest.findUnique({
            where: { id: withdrawalId }
        });

        if (!withdrawal) return;

        await prisma.$transaction(async (tx) => {
            // Refund the amount
            await tx.balance.upsert({
                where: { userId_coin: { userId: withdrawal.userId, coin: withdrawal.coin } },
                update: {
                    amount: { increment: withdrawal.amount.toString() }
                },
                create: {
                    userId: withdrawal.userId,
                    coin: withdrawal.coin,
                    amount: withdrawal.amount.toString()
                }
            });

            // Mark as failed
            await tx.withdrawalRequest.update({
                where: { id: withdrawalId },
                data: {
                    status: 'FAILED',
                    failureReason: reason,
                    processedAt: new Date()
                }
            });
        });
    }

    /**
     * Get transaction history for a user
     */
    public static async getTransactionHistory(
        userId: string,
        coin?: Coin,
        limit: number = 50
    ): Promise<Array<{
        txId: string;
        coin: Coin;
        amount: Decimal;
        direction: TxDirection;
        confirmed: boolean;
        seenAt: Date;
        blockHeight?: number;
    }>> {
        const transactions = await prisma.onChainTx.findMany({
            where: {
                userId,
                ...(coin ? { coin } : {})
            },
            orderBy: { seenAt: 'desc' },
            take: limit
        });

        return transactions.map(tx => ({
            txId: tx.txId,
            coin: tx.coin as Coin,
            amount: new Decimal(tx.amount.toString()),
            direction: tx.direction as TxDirection,
            confirmed: tx.confirmed,
            seenAt: tx.seenAt,
            blockHeight: tx.blockHeight || undefined
        }));
    }

    // ========== ADDRESS GENERATION METHODS ==========

    /**
     * Generate deposit address - server-only with dynamic imports
     */
    public static async generateDepositAddress(userId: string, coin: Coin): Promise<string> {
        if (coin === 'ETH') {
            return this.generateEthereumAddress(userId, coin);
        } else {
            return this.generateBitcoinAddress(userId, coin);
        }
    }

    /**
     * Get existing valid deposit address
     */
    public static async getExistingDepositAddress(userId: string, coin: Coin): Promise<string | null> {
        const now = new Date();

        const depositAddress = await prisma.depositAddress.findFirst({
            where: {
                userId,
                coin,
                expiresAt: { gt: now }
            },
            orderBy: { createdAt: 'desc' }
        });

        return depositAddress?.address || null;
    }

    /**
     * Get or create deposit address
     */
    public static async getOrCreateDepositAddress(userId: string, coin: Coin): Promise<string> {
        // Try to get existing address first
        const existingAddress = await this.getExistingDepositAddress(userId, coin);
        if (existingAddress) return existingAddress;

        // Generate new address
        return this.generateDepositAddress(userId, coin);
    }

    // ========== PRIVATE HELPER METHODS ==========

    private static async generateEthereumAddress(userId: string, coin: Coin): Promise<string> {
        const { HDNodeWallet } = await import('ethers');

        const xpub = process.env.ETH_XPUB;
        if (!xpub) {
            throw new Error('ETH_XPUB not configured');
        }

        // Get next derivation index
        const lastAddressResult = await prisma.depositAddress.aggregate({
            _max: { index: true },
            where: { coin }
        });
        const nextIndex = (lastAddressResult._max.index ?? -1) + 1;

        // Generate address
        const hdNode = HDNodeWallet.fromExtendedKey(xpub);
        const derivedNode = hdNode.derivePath(`0/${nextIndex}`);
        const address = derivedNode.address;

        // Set expiration to 7 days from now
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7);

        const alchemy = await this.ensureAlchemyWebhook([address]);

        // Save to database
        await prisma.depositAddress.create({
            data: {
                userId,
                coin,
                address,
                index: nextIndex,
                expiresAt,
                walletName: alchemy.walletName
            }
        });

        return address;
    }

    private static async ensureAlchemyWebhook(addAddresses?: string[]) {
        const token = process.env.ALCHEMY_TOKEN;
        const urlBase = 'https://dashboard.alchemy.com/api';
        if (!token || !process.env.ALCHEMY_WEBHOOK_URL) {
            throw new Error('Please set ALCHEMY_TOKEN and ALCHEMY_WEBHOOK_URL');
        }

        // 1) Look for an existing Alchemy webhook record
        let wh = await prisma.blockcypherWallet.findFirst({
            where: { coin: Coin.ETH }
        });

        const depositAddresses = await prisma.depositAddress.findMany({
            where: { coin: Coin.ETH }
        });
        const walletAddresses = depositAddresses.map(d => d.address);
        const withAddedAddresses = addAddresses ? [...walletAddresses, ...addAddresses] : walletAddresses;

        // 2a) If none exists, create it
        if (!wh) {
            const payload: any = {
                network: 'ETH_MAINNET',
                webhook_type: 'ADDRESS_ACTIVITY',
                webhook_url: process.env.ALCHEMY_WEBHOOK_URL,
            };
            if (withAddedAddresses?.length) {
                payload.addresses = withAddedAddresses;
            }

            const resp = await axios.post(
                `${urlBase}/create-webhook`,
                payload,
                {
                    headers: {
                        'X-Alchemy-Token': token,
                        'Content-Type': 'application/json',
                    }
                }
            );

            const data = resp.data.data;
            wh = await prisma.blockcypherWallet.create({
                data: {
                    coin: Coin.ETH,
                    walletName: data.id,
                    walletAddresses: data.addresses,
                    hookUnconfirmedId: data.id,
                    hookConfirmationId: data.id
                }
            });

            return wh;
        }

        // 2b) If it exists and we have new addresses, PATCH them on
        if (addAddresses?.length) {
            await axios.patch(
                `${urlBase}/update-webhook-addresses`,
                {
                    webhook_id: wh.hookUnconfirmedId,
                    addresses_to_add: withAddedAddresses,
                    addresses_to_remove: []
                },
                {
                    headers: {
                        'X-Alchemy-Token': token,
                        'Content-Type': 'application/json'
                    }
                }
            );
            // update our DB copy (assumes `addresses` is a `string[]` column)
            wh = await prisma.blockcypherWallet.update({
                where: { id: wh.id },
                data: {
                    walletAddresses: withAddedAddresses.filter(a => !walletAddresses.includes(a))
                }
            });
        }

        return wh;
    }


    private static async ensureBcWallet(coin: Coin, addAddresses?: string[]): Promise<BlockcypherWallet> {
        try {
            if (coin === 'ETH') {
                throw new Error('ETH wallets are not supported');
            }

            // 1) Look for an existing wallet record
            let bc = await prisma.blockcypherWallet.findFirst({
                where: { coin }
            });
            if (bc) return bc;

            const depositAddresses = await prisma.depositAddress.findMany({
                where: { coin }
            });
            const walletAddresses = depositAddresses.map(d => d.address);
            const withAddedAddresses = addAddresses ? [...walletAddresses, ...addAddresses] : walletAddresses;

            // 2) Create a brand‑new BlockCypher wallet
            const walletName = `${coin}-${Date.now()}`;

            await axios.post(
                `https://api.blockcypher.com/v1/${coin.toLowerCase()}/main/wallets?token=${process.env.BC_TOKEN}`,
                { name: walletName, addresses: withAddedAddresses }
            );

            // 3) Register two hooks on that wallet
            const hookUnconfirmed = await axios.post<BlockCypherHookResponse>(
                `https://api.blockcypher.com/v1/${coin.toLowerCase()}/main/hooks?token=${process.env.BC_TOKEN}`,
                { event: 'unconfirmed-tx', wallet_name: walletName, url: process.env.BC_WEBHOOK_URL }
            );
            const hookConfirmation = await axios.post<BlockCypherHookResponse>(
                `https://api.blockcypher.com/v1/${coin.toLowerCase()}/main/hooks?token=${process.env.BC_TOKEN}`,
                { event: 'tx-confirmation', wallet_name: walletName, url: process.env.BC_WEBHOOK_URL, confirmations: this.getRequiredConfirmations(coin) }
            );

            // 4) Persist
            bc = await prisma.blockcypherWallet.create({
                data: {
                    coin,
                    walletName,
                    walletAddresses: withAddedAddresses,
                    hookUnconfirmedId: hookUnconfirmed.data.id,
                    hookConfirmationId: hookConfirmation.data.id
                }
            });

            return bc;
        } catch (error) {
            if (error instanceof AxiosError) {
                console.error('BlockCypher API error:', error.response?.data);
            }
            console.error('Failed to ensure BlockCypher wallet:', error);
            throw error;
        }
    }

    private static async generateBitcoinAddress(userId: string, coin: Coin): Promise<string> {
        const [{ BIP32Factory }, ecc, bitcoin] = await Promise.all([
            import('bip32'),
            import('tiny-secp256k1'),
            import('bitcoinjs-lib')
        ]);

        const bip32 = BIP32Factory(ecc);

        const xpub = coin === 'BTC' ? process.env.BTC_XPUB : process.env.LTC_XPUB;
        if (!xpub) {
            throw new Error(`${coin}_XPUB not configured`);
        }

        // Get next derivation index
        const lastAddressResult = await prisma.depositAddress.aggregate({
            _max: { index: true },
            where: { coin }
        });
        const nextIndex = (lastAddressResult._max.index ?? -1) + 1;

        // Generate address
        const network = coin === 'BTC' ? bitcoin.networks.bitcoin : litecoinNetwork;
        const node = bip32.fromBase58(xpub, network);
        const derivedNode = node.derive(0).derive(nextIndex);

        const payment = bitcoin.payments.p2wpkh({
            pubkey: Buffer.from(derivedNode.publicKey),
            network
        });

        if (!payment.address) {
            throw new Error('Failed to generate address from payment');
        }

        const address = payment.address;

        // Set expiration to 7 days from now
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 7);

        const bc = await this.ensureBcWallet(coin, [address]);

        // Save to database
        await prisma.depositAddress.create({
            data: {
                userId,
                coin,
                address,
                index: nextIndex,
                expiresAt,
                walletName: bc.walletName
            }
        });

        return address;
    }

    /**
     * Get required confirmations for each coin
     */
    private static getRequiredConfirmations(coin: Coin): number {
        switch (coin) {
            case 'BTC':
                return 2;
            case 'LTC':
                return 2;
            case 'ETH':
                return 12;
            default:
                return 2;
        }
    }
} 