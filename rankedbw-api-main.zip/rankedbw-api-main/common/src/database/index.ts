import connectRedis from './connectors/redis';

export default { connectRedis };
