import { PrismaClient } from "../generated";

const globalForPrisma = global as unknown as { prisma: PrismaClient };

export const prisma =
  globalForPrisma.prisma ||
  new PrismaClient({
    datasourceUrl: process.env.DATABASE_URL,
    // log: ["error", "warn", "query", "info"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;