-- CreateTable
CREATE TABLE "Season" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "startDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "endDate" TIMESTAMP(3),
    "ruleset" TEXT NOT NULL DEFAULT 'Standard',
    "archived" BOOLEAN NOT NULL DEFAULT false,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Season_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SeasonTopPlayer" (
    "id" TEXT NOT NULL,
    "playerId" TEXT NOT NULL,
    "finalElo" INTEGER NOT NULL,
    "position" INTEGER NOT NULL,
    "seasonId" TEXT NOT NULL,

    CONSTRAINT "SeasonTopPlayer_pkey" PRIMARY KEY ("id")
);

-- AddSeasonIdToGame
ALTER TABLE "Game" ADD COLUMN "seasonId" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "Season_name_key" ON "Season"("name");

-- AddForeignKey
ALTER TABLE "SeasonTopPlayer" ADD CONSTRAINT "SeasonTopPlayer_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "Player"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SeasonTopPlayer" ADD CONSTRAINT "SeasonTopPlayer_seasonId_fkey" FOREIGN KEY ("seasonId") REFERENCES "Season"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Game" ADD CONSTRAINT "Game_seasonId_fkey" FOREIGN KEY ("seasonId") REFERENCES "Season"("id") ON DELETE SET NULL ON UPDATE CASCADE; 