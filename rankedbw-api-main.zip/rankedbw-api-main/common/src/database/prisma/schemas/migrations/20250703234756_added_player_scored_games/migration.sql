-- AlterTable
ALTER TABLE "Player" ADD COLUMN     "scoredGames" INTEGER NOT NULL DEFAULT 0;
