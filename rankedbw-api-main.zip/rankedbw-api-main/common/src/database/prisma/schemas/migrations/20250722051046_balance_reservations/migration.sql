/*
  Warnings:

  - You are about to drop the column `balance` on the `User` table. All the data in the column will be lost.

*/
-- CreateEnum
CREATE TYPE "ReservationReason" AS ENUM ('BET', 'WITHDRAWAL');

-- AlterTable
ALTER TABLE "User" DROP COLUMN "balance";

-- CreateTable
CREATE TABLE "ReservedBalance" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "coin" "Coin" NOT NULL,
    "amount" DECIMAL(18,8) NOT NULL,
    "reason" "ReservationReason" NOT NULL,
    "referenceId" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ReservedBalance_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ReservedBalance_userId_coin_idx" ON "ReservedBalance"("userId", "coin");

-- CreateIndex
CREATE INDEX "ReservedBalance_referenceId_idx" ON "ReservedBalance"("referenceId");

-- CreateIndex
CREATE INDEX "ReservedBalance_expiresAt_idx" ON "ReservedBalance"("expiresAt");

-- AddForeignKey
ALTER TABLE "ReservedBalance" ADD CONSTRAINT "ReservedBalance_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
