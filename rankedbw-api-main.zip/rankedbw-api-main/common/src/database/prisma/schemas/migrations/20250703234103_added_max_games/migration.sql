-- AlterTable
ALTER TABLE "Season" ADD COLUMN     "maxGames" INTEGER;
