/*
  Warnings:

  - You are about to drop the column `claimedELO` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `claimedScreenshares` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `elo` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `gamesPlayed` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `losses` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `mvps` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `peakElo` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `position` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `scoredGames` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `screenshares` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `streak` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `totalXp` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the column `wins` on the `Player` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Player" DROP COLUMN "claimedELO",
DROP COLUMN "claimedScreenshares",
DROP COLUMN "elo",
DROP COLUMN "gamesPlayed",
DROP COLUMN "losses",
DROP COLUMN "mvps",
DROP COLUMN "peakElo",
DROP COLUMN "position",
DROP COLUMN "scoredGames",
DROP COLUMN "screenshares",
DROP COLUMN "streak",
DROP COLUMN "totalXp",
DROP COLUMN "wins";
