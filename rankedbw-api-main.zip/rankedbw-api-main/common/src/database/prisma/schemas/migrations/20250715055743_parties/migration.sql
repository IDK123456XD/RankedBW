-- CreateTable
CREATE TABLE "Party" (
    "id" TEXT NOT NULL,
    "leader" TEXT NOT NULL,
    "members" TEXT[],
    "autoWarp" BOOLEAN NOT NULL,
    "lastVcJoin" TIMESTAMP(3),
    "invites" TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Party_pkey" PRIMARY KEY ("id")
);
