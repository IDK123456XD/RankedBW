-- AlterTable
ALTER TABLE "public"."PlayerStatistics" ADD COLUMN     "lastStatResetAt" TIMESTAMP(3);
