-- AlterTable
ALTER TABLE "DepositAddress" ADD COLUMN     "hookId" TEXT;
