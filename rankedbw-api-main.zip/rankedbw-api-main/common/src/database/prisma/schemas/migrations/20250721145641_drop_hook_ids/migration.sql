/*
  Warnings:

  - You are about to drop the column `hookIds` on the `DepositAddress` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "DepositAddress" DROP COLUMN "hookIds";
