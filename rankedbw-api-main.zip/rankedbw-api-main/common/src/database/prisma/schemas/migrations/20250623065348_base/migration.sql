-- CreateEnum
CREATE TYPE "TeamColors" AS ENUM ('red', 'blue', 'green', 'yellow', 'aqua', 'white', 'pink', 'gray');

-- CreateEnum
CREATE TYPE "PunishmentType" AS ENUM ('rankedban', 'rankedunban', 'mute', 'unmute', 'strike', 'strikeRemove');

-- CreateEnum
CREATE TYPE "PickingTypes" AS ENUM ('random', '1', '2');

-- CreateEnum
CREATE TYPE "GameStyles" AS ENUM ('josie', '2v2v2v2v2v2v2v2', '4v4', '2v2', '1v1');

-- CreateEnum
CREATE TYPE "VotingTypes" AS ENUM ('pugs', 'pups');

-- CreateTable
CREATE TABLE "GamePlayer" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "preElo" INTEGER NOT NULL DEFAULT 0,
    "postElo" INTEGER NOT NULL DEFAULT 0,
    "mvp" BOOLEAN NOT NULL DEFAULT false,
    "discordTeam" INTEGER NOT NULL,
    "team" "TeamColors",
    "win" BOOLEAN NOT NULL DEFAULT false,
    "kills" INTEGER NOT NULL DEFAULT 0,
    "deaths" INTEGER NOT NULL DEFAULT 0,
    "gameId" TEXT,

    CONSTRAINT "GamePlayer_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Game" (
    "id" TEXT NOT NULL,
    "gameId" INTEGER NOT NULL,
    "queueChannelId" TEXT NOT NULL,
    "team1Voice" TEXT NOT NULL,
    "team2Voice" TEXT NOT NULL,
    "bannedMaps" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "mapPlaying" TEXT,
    "finished" BOOLEAN NOT NULL DEFAULT false,
    "voided" BOOLEAN NOT NULL DEFAULT false,
    "gameStyle" "GameStyles" NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Game_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Map" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "gameStyle" "GameStyles" NOT NULL,
    "team1" "TeamColors"[],
    "team2" "TeamColors"[],

    CONSTRAINT "Map_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Punishment" (
    "id" TEXT NOT NULL,
    "type" "PunishmentType" NOT NULL,
    "reason" TEXT NOT NULL,
    "staff" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3),
    "expired" BOOLEAN NOT NULL,
    "playerId" TEXT,

    CONSTRAINT "Punishment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PlayerSkins" (
    "id" TEXT NOT NULL,
    "fullBodySkin" TEXT NOT NULL,
    "headSkin" TEXT NOT NULL,
    "vanillaSkin" TEXT,

    CONSTRAINT "PlayerSkins_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Player" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "minecraftName" TEXT NOT NULL,
    "uuid" TEXT NOT NULL,
    "nickname" TEXT,
    "eloPrefix" BOOLEAN NOT NULL DEFAULT true,
    "elo" INTEGER NOT NULL DEFAULT 0,
    "lastPlayed" TIMESTAMP(3),
    "lastEloDecay" TIMESTAMP(3),
    "partyIgnoreList" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "backgroundFileName" TEXT NOT NULL DEFAULT 'cityscape.png',
    "leftRoleIds" TEXT[],
    "winStreak" INTEGER NOT NULL DEFAULT 0,
    "claimedELO" BOOLEAN NOT NULL DEFAULT false,
    "lastMojangFetch" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "playerSkinsId" TEXT NOT NULL,

    CONSTRAINT "Player_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Settings" (
    "id" TEXT NOT NULL,
    "partySize" INTEGER NOT NULL DEFAULT 4,
    "partyEnabled" BOOLEAN NOT NULL DEFAULT true,
    "pickingType" "PickingTypes" NOT NULL DEFAULT '1',
    "queuesOpen" BOOLEAN NOT NULL DEFAULT true,
    "gameStyle" "GameStyles" NOT NULL DEFAULT '4v4',
    "teamSize" INTEGER NOT NULL DEFAULT 4,
    "hypixelAPIKey" TEXT,

    CONSTRAINT "Settings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Voting" (
    "id" TEXT NOT NULL,
    "type" "VotingTypes" NOT NULL,
    "messageId" TEXT NOT NULL,
    "candidateId" TEXT NOT NULL,
    "upvoteVoters" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "downvoteVoters" TEXT[] DEFAULT ARRAY[]::TEXT[],

    CONSTRAINT "Voting_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Game_gameId_key" ON "Game"("gameId");

-- CreateIndex
CREATE UNIQUE INDEX "Map_name_key" ON "Map"("name");

-- CreateIndex
CREATE UNIQUE INDEX "Player_userId_key" ON "Player"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "Player_minecraftName_key" ON "Player"("minecraftName");

-- CreateIndex
CREATE UNIQUE INDEX "Player_uuid_key" ON "Player"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "Voting_messageId_key" ON "Voting"("messageId");

-- AddForeignKey
ALTER TABLE "GamePlayer" ADD CONSTRAINT "GamePlayer_userId_fkey" FOREIGN KEY ("userId") REFERENCES "Player"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GamePlayer" ADD CONSTRAINT "GamePlayer_gameId_fkey" FOREIGN KEY ("gameId") REFERENCES "Game"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Punishment" ADD CONSTRAINT "Punishment_playerId_fkey" FOREIGN KEY ("playerId") REFERENCES "Player"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Player" ADD CONSTRAINT "Player_playerSkinsId_fkey" FOREIGN KEY ("playerSkinsId") REFERENCES "PlayerSkins"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
