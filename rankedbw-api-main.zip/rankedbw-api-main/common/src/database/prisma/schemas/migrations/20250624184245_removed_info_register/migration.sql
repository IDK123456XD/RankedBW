-- AlterTable
ALTER TABLE "Player" ALTER COLUMN "fullBodySkin" DROP NOT NULL;
