import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return NextResponse.json({}, { headers: corsHeaders });
}

interface GamePlayerDetail {
  userId: string;
  minecraftName: string;
  preElo: number;
  postElo: number;
  eloDiff: number;
  mvp: boolean;
  win: boolean;
  discordTeam: number;
}

interface GameDetail {
  id: string;
  gameId: string;
  mapPlaying: string | null;
  finished: boolean;
  voided: boolean;
  lossVoided: boolean;
  gameStyle: string;
  createdAt: Date;
  updatedAt: Date;
  status: string;
  reason: string | null;
  season: {
    id: string;
    name: string;
  } | null;
  team1Players: GamePlayerDetail[];
  team2Players: GamePlayerDetail[];
  winningTeam: number | null;
}

async function getGameDetails(gameId: string): Promise<GameDetail | null> {
  try {
    // Find the game with all related data
    const game = await prisma.game.findFirst({
      where: {
        OR: [
          { gameId: gameId },
          { id: gameId }
        ]
      },
      include: {
        season: {
          select: {
            id: true,
            name: true,
          },
        },
        players: {
          include: {
            user: {
              select: {
                userId: true,
                minecraftName: true,
              },
            },
          },
          orderBy: {
            discordTeam: 'asc',
          },
        },
      },
    });

    if (!game) {
      return null;
    }

    // Separate players into teams
    const team1Players: GamePlayerDetail[] = [];
    const team2Players: GamePlayerDetail[] = [];
    let winningTeam: number | null = null;

    game.players.forEach((player) => {
      const playerDetail: GamePlayerDetail = {
        userId: player.user.userId,
        minecraftName: player.user.minecraftName,
        preElo: player.preElo,
        postElo: player.postElo,
        eloDiff: player.eloDiff,
        mvp: player.mvp,
        win: player.win,
        discordTeam: player.discordTeam,
      };

      if (player.discordTeam === 1) {
        team1Players.push(playerDetail);
        if (player.win && winningTeam === null) {
          winningTeam = 1;
        }
      } else {
        team2Players.push(playerDetail);
        if (player.win && winningTeam === null) {
          winningTeam = 2;
        }
      }
    });

    return {
      id: game.id,
      gameId: game.gameId,
      mapPlaying: game.mapPlaying,
      finished: game.finished,
      voided: game.voided,
      lossVoided: game.lossVoided,
      gameStyle: game.gameStyle,
      createdAt: game.createdAt,
      updatedAt: game.updatedAt,
      status: game.status,
      reason: game.reason,
      season: game.season,
      team1Players,
      team2Players,
      winningTeam,
    };
  } catch (error) {
    console.error('Error fetching game details:', error);
    throw error;
  }
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ gameid: string }> }
) {
  try {
    const { gameid } = await params;
    const gameId = gameid;

    if (!gameId) {
      return NextResponse.json(
        {
          success: false,
          error: 'Game ID is required',
          code: 'MISSING_GAME_ID',
        },
        { status: 400, headers: corsHeaders }
      );
    }

    const gameDetails = await getGameDetails(gameId);

    if (!gameDetails) {
      return NextResponse.json(
        {
          success: false,
          error: 'Game not found',
          code: 'GAME_NOT_FOUND',
        },
        { status: 404, headers: corsHeaders }
      );
    }

    return NextResponse.json({
      success: true,
      data: gameDetails,
    }, { headers: corsHeaders });
  } catch (error) {
    console.error('Error in game details API:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch game details',
        code: 'INTERNAL_ERROR',
      },
      { status: 500, headers: corsHeaders }
    );
  }
}

