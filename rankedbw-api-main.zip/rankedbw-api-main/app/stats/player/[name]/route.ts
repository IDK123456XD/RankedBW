import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return NextResponse.json({}, { headers: corsHeaders });
}

interface RecentGame {
  id: string;
  gameId: string;
  mapPlaying: string | null;
  createdAt: Date;
  won: boolean;
  mvp: boolean;
  eloDiff: number;
  teammates: {
    minecraftName: string;
    userId: string;
  }[];
  opponents: {
    minecraftName: string;
    userId: string;
  }[];
}

interface PlayerProfile {
  player: {
    id: string;
    userId: string;
    minecraftName: string;
    nickname: string | null;
    winStreak: number;
  };
  statistics: {
    elo: number;
    wins: number;
    mvps: number;
    gamesPlayed: number;
    losses: number;
    peakElo: number;
  };
  leaderboardRank: number;
  recentGames: RecentGame[];
}

async function getPlayerProfile(playerName: string): Promise<PlayerProfile | null> {
  try {
    // Get player data - case insensitive search
    const player = await prisma.player.findFirst({
      where: {
        minecraftName: {
          equals: playerName,
          mode: 'insensitive',
        },
      },
      select: {
        id: true,
        userId: true,
        minecraftName: true,
        nickname: true,
        winStreak: true,
      },
    });

    if (!player) {
      return null;
    }

    // Get player statistics from active season only
    const stats = await prisma.playerStatistics.findFirst({
      where: {
        playerId: player.id,
        season: {
          active: true,
        },
      },
      select: {
        elo: true,
        wins: true,
        mvps: true,
        gamesPlayed: true,
        losses: true,
        peakElo: true,
      },
    });

    if (!stats) {
      return {
        player,
        statistics: { elo: 0, wins: 0, mvps: 0, gamesPlayed: 0, losses: 0, peakElo: 0 },
        leaderboardRank: 0,
        recentGames: [],
      };
    }

    // Calculate leaderboard rank (count players with higher ELO)
    const playersWithHigherElo = await prisma.playerStatistics.count({
      where: {
        season: {
          active: true,
        },
        elo: {
          gt: stats.elo,
        },
      },
    });
    const leaderboardRank = playersWithHigherElo + 1;

    // Get recent 3 games for this player
    const recentGamePlayers = await prisma.gamePlayer.findMany({
      where: {
        userId: player.id,
        Game: {
          status: 'SCORED',
          voided: false,
          season: {
            active: true,
          },
        },
      },
      include: {
        Game: {
          include: {
            players: {
              include: {
                user: {
                  select: {
                    minecraftName: true,
                    userId: true,
                  },
                },
              },
            },
          },
        },
      },
      orderBy: {
        Game: {
          createdAt: 'desc',
        },
      },
      take: 3,
    });

    const recentGames: RecentGame[] = recentGamePlayers.map((gp) => {
      const game = gp.Game!;
      const playerTeam = gp.discordTeam;

      // Get teammates (same team, including the player)
      const teammates = game.players
        .filter((p) => p.discordTeam === playerTeam)
        .map((p) => ({
          minecraftName: p.user.minecraftName,
          userId: p.user.userId,
        }));

      // Get opponents (different team)
      const opponents = game.players
        .filter((p) => p.discordTeam !== playerTeam)
        .map((p) => ({
          minecraftName: p.user.minecraftName,
          userId: p.user.userId,
        }));

      return {
        id: game.id,
        gameId: game.gameId,
        mapPlaying: game.mapPlaying,
        createdAt: game.createdAt,
        won: gp.win,
        mvp: gp.mvp,
        eloDiff: gp.eloDiff,
        teammates,
        opponents,
      };
    });

    return {
      player,
      statistics: stats,
      leaderboardRank,
      recentGames,
    };
  } catch (error) {
    console.error('Error fetching player profile:', error);
    throw error;
  }
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ name: string }> }
) {
  try {
    const { name } = await params;
    const playerName = name;

    if (!playerName) {
      return NextResponse.json(
        {
          success: false,
          error: 'Player name is required',
          code: 'MISSING_PLAYER_NAME',
        },
        { status: 400, headers: corsHeaders }
      );
    }

    const profile = await getPlayerProfile(playerName);

    if (!profile) {
      return NextResponse.json(
        {
          success: false,
          error: 'Player not found',
          code: 'PLAYER_NOT_FOUND',
        },
        { status: 404, headers: corsHeaders }
      );
    }

    return NextResponse.json({
      success: true,
      data: profile,
    }, { headers: corsHeaders });
  } catch (error) {
    console.error('Error in player profile API:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch player profile',
        code: 'INTERNAL_ERROR',
      },
      { status: 500, headers: corsHeaders }
    );
  }
}
