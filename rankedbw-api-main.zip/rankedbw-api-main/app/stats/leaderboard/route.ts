import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return NextResponse.json({}, { headers: corsHeaders });
}

const VALID_STAT_TYPES = ['elo', 'wins', 'mvps', 'gamesPlayed', 'losses', 'streak', 'peakElo', 'winLossRatio'];
const DEFAULT_STAT_TYPE = 'elo';
const DEFAULT_PAGE_SIZE = 25;
const MAX_PAGES = 200;
const MAX_TOTAL_ITEMS = 20000;

interface LeaderboardEntry {
  rank: number;
  minecraftName: string;
  userId: string;
  value: number;
}

function isValidStatType(statType: string): boolean {
  return VALID_STAT_TYPES.includes(statType);
}

function getStatColumn(statType: string): { orderBy: string; columnName: string } {
  switch (statType) {
    case 'wins':
      return { orderBy: 'ps.wins DESC', columnName: 'ps.wins' };
    case 'elo':
      return { orderBy: 'ps.elo DESC', columnName: 'ps.elo' };
    case 'mvps':
      return { orderBy: 'ps.mvps DESC', columnName: 'ps.mvps' };
    case 'gamesPlayed':
      return { orderBy: 'ps."gamesPlayed" DESC', columnName: 'ps."gamesPlayed"' };
    case 'losses':
      return { orderBy: 'ps.losses DESC', columnName: 'ps.losses' };
    case 'streak':
      return { orderBy: 'ps.streak DESC', columnName: 'ps.streak' };
    case 'peakElo':
      return { orderBy: 'ps."peakElo" DESC', columnName: 'ps."peakElo"' };
    default:
      return { orderBy: 'ps.elo DESC', columnName: 'ps.elo' };
  }
}

function getStatDisplayName(statType: string): string {
  const names: Record<string, string> = {
    elo: 'ELO Rating',
    wins: 'Wins',
    mvps: 'MVPs',
    gamesPlayed: 'Games Played',
    losses: 'Losses',
    streak: 'Win Streak',
    peakElo: 'Peak ELO',
    winLossRatio: 'Win/Loss Ratio',
  };
  return names[statType] || 'ELO Rating';
}

async function getLeaderboardData(
  statType: string,
  limit: number,
  offset: number
): Promise<{ leaderboard: LeaderboardEntry[]; totalCount: number }> {
  // Special handling for winLossRatio
  if (statType === 'winLossRatio') {
    // Fetch all stats to calculate ratio
    const allStats = await prisma.playerStatistics.findMany({
      where: {
        season: {
          active: true,
        },
        // Only include players with at least 1 game played
        gamesPlayed: {
          gt: 0,
        },
      },
      include: {
        player: {
          select: {
            minecraftName: true,
            userId: true,
          },
        },
      },
    });

    // Calculate win/loss ratio and sort
    const statsWithRatio = allStats
      .map((stat) => {
        const ratio = stat.losses === 0 
          ? stat.wins // If no losses, ratio equals wins
          : stat.wins / stat.losses;
        return {
          minecraftName: stat.player.minecraftName,
          userId: stat.player.userId,
          value: ratio,
        };
      })
      .sort((a, b) => b.value - a.value) // Sort descending by ratio
      .slice(0, MAX_TOTAL_ITEMS); // Cap at max items

    const totalCount = statsWithRatio.length;

    // Paginate
    const paginatedStats = statsWithRatio.slice(offset, offset + limit);

    const leaderboard: LeaderboardEntry[] = paginatedStats.map((stat, index) => ({
      rank: offset + index + 1,
      minecraftName: stat.minecraftName,
      userId: stat.userId,
      value: stat.value,
    }));

    return { leaderboard, totalCount };
  }

  // Get total count - only from active season
  const totalCount = await prisma.playerStatistics.count({
    where: {
      season: {
        active: true,
      },
    },
  });

  const cappedCount = totalCount > MAX_TOTAL_ITEMS ? MAX_TOTAL_ITEMS : totalCount;

  // Check if offset is within bounds
  if (offset >= MAX_TOTAL_ITEMS) {
    return { leaderboard: [], totalCount: cappedCount };
  }

  // Adjust limit if needed
  if (offset + limit > MAX_TOTAL_ITEMS) {
    limit = MAX_TOTAL_ITEMS - offset;
  }

  // Determine order by field
  const orderByField = statType as keyof {
    elo: number;
    wins: number;
    mvps: number;
    gamesPlayed: number;
    losses: number;
    streak: number;
    peakElo: number;
  };

  // Get leaderboard data - only from active season using Prisma
  const stats = await prisma.playerStatistics.findMany({
    where: {
      season: {
        active: true,
      },
    },
    include: {
      player: {
        select: {
          minecraftName: true,
          userId: true,
        },
      },
    },
    orderBy: {
      [orderByField]: 'desc',
    },
    take: limit,
    skip: offset,
  });

  const leaderboard: LeaderboardEntry[] = stats.map((stat, index) => ({
    rank: offset + index + 1,
    minecraftName: stat.player.minecraftName,
    userId: stat.player.userId,
    value: stat[orderByField] as number,
  }));

  return { leaderboard, totalCount: cappedCount };
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const statType = searchParams.get('type') || DEFAULT_STAT_TYPE;
    const pageStr = searchParams.get('page') || '1';

    // Validate stat type
    if (!isValidStatType(statType)) {
      return NextResponse.json(
        {
          success: false,
          error: 'Invalid stat type',
          code: 'INVALID_STAT_TYPE',
        },
        { status: 400, headers: corsHeaders }
      );
    }

    // Validate page number
    let page = parseInt(pageStr);
    if (isNaN(page) || page < 1) {
      page = 1;
    }

    if (page > MAX_PAGES) {
      return NextResponse.json(
        {
          success: false,
          error: `Page ${page} is too high. Maximum is ${MAX_PAGES}.`,
          code: 'INVALID_PAGE',
          maxPages: MAX_PAGES,
        },
        { status: 400, headers: corsHeaders }
      );
    }

    const limit = DEFAULT_PAGE_SIZE;
    const offset = (page - 1) * limit;

    // Get leaderboard data
    const { leaderboard, totalCount } = await getLeaderboardData(statType, limit, offset);

    // Calculate pagination
    let totalPages = Math.ceil(totalCount / limit);
    if (totalPages === 0) {
      totalPages = 1;
    }
    if (totalPages > MAX_PAGES) {
      totalPages = MAX_PAGES;
    }

    // Return response
    return NextResponse.json({
      success: true,
      data: {
        leaderboard,
        pagination: {
          currentPage: page,
          totalPages,
          totalCount,
          hasNext: page < totalPages,
          hasPrev: page > 1,
          pageSize: limit,
        },
        metadata: {
          statType,
          statName: getStatDisplayName(statType),
        },
      },
    }, { headers: corsHeaders });
  } catch (error) {
    console.error('Error in leaderboard API:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch leaderboard data',
        code: 'INTERNAL_ERROR',
      },
      { status: 500, headers: corsHeaders }
    );
  }
}

