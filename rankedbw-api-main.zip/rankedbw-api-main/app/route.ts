import { NextResponse } from 'next/server';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export async function OPTIONS() {
  return NextResponse.json({}, { headers: corsHeaders });
}

export async function GET() {
  return NextResponse.json({
    name: 'Ranked Bedwars Stats API',
    version: '1.0.0',
    description: 'Public API for Ranked Bedwars statistics',
    baseUrl: 'https://api.rankedbw.net',
    endpoints: {
      leaderboard: {
        path: '/stats/leaderboard',
        method: 'GET',
        description: 'Get leaderboard rankings for various statistics',
        parameters: {
          type: {
            type: 'string',
            required: false,
            default: 'elo',
            options: ['elo', 'wins', 'mvps', 'gamesPlayed', 'losses', 'streak', 'peakElo', 'winLossRatio'],
            description: 'The statistic type to rank by',
          },
          page: {
            type: 'number',
            required: false,
            default: 1,
            description: 'Page number for pagination (max 200 pages)',
          },
        },
        example: '/stats/leaderboard?type=elo&page=1',
      },
      player: {
        path: '/stats/player/{name}',
        method: 'GET',
        description: 'Get detailed player profile and statistics',
        parameters: {
          name: {
            type: 'string',
            required: true,
            description: 'Minecraft username (case insensitive)',
          },
        },
        example: '/stats/player/Steve',
      },
      game: {
        path: '/stats/game/{gameid}',
        method: 'GET',
        description: 'Get detailed information about a specific game',
        parameters: {
          gameid: {
            type: 'string',
            required: true,
            description: 'Game ID',
          },
        },
        example: '/stats/game/12345',
      },
      recentGames: {
        path: '/stats/recent-games',
        method: 'GET',
        description: 'Get recently played games',
        parameters: {
          page: {
            type: 'number',
            required: false,
            default: 1,
            description: 'Page number for pagination (max 50 pages)',
          },
        },
        example: '/stats/recent-games?page=1',
      },
    },
    responseFormat: {
      success: 'boolean',
      data: 'object | null',
      error: 'string | null (only on error)',
      code: 'string | null (error code)',
    },
    cors: {
      enabled: true,
      allowedOrigins: '*',
      allowedMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
      note: 'API is accessible from all origins',
    },
    rateLimit: {
      enabled: false,
      note: 'Please be respectful with API usage',
    },
  }, { headers: corsHeaders });
}

