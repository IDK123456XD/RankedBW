import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

const ALLOWED_ORIGINS = [
  'https://rankedbw.net',
  'https://www.rankedbw.net',
  'https://stats.rankedbw.net',
  'https://api.rankedbw.net',
];

function isOriginAllowed(origin: string | null, host: string | null): boolean {
  if (host && (host.startsWith('localhost') || host.startsWith('127.0.0.1'))) {
    return true;
  }
  
  if (!origin) return false;
  
  if (origin.startsWith('http://localhost') || origin.startsWith('http://127.0.0.1') || origin.startsWith('https://localhost') || origin.startsWith('https://127.0.0.1')) {
    return true;
  }
  
  return ALLOWED_ORIGINS.some(allowed => origin === allowed || origin.startsWith(allowed));
}

export function proxy(request: NextRequest) {
  const origin = request.headers.get('origin');
  const referer = request.headers.get('referer');
  const host = request.headers.get('host');
  
  const requestOrigin = origin || (referer ? new URL(referer).origin : null);
  
  if (!isOriginAllowed(requestOrigin, host)) {
    return NextResponse.json(
      {
        success: false,
        error: 'Access denied: Origin not allowed',
        code: 'ORIGIN_NOT_ALLOWED',
      },
      { status: 403 }
    );
  }
  
  const response = NextResponse.next();
  
  response.headers.set('Access-Control-Allow-Origin', requestOrigin || ALLOWED_ORIGINS[0]);
  response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  response.headers.set('Access-Control-Allow-Credentials', 'true');
  response.headers.set('Access-Control-Max-Age', '86400');
  
  if (request.method === 'OPTIONS') {
    return new NextResponse(null, {
      status: 200,
      headers: {
        'Access-Control-Allow-Origin': requestOrigin || ALLOWED_ORIGINS[0],
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Credentials': 'true',
        'Access-Control-Max-Age': '86400',
      },
    });
  }
  
  return response;
}

export const config = {
  matcher: '/:path*',
};

