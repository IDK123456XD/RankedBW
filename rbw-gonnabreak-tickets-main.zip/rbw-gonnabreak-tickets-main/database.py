import sqlite3
import json
from typing import Dict, List, Optional, Tuple
from contextlib import contextmanager
import os

# Use environment variable for DB path, with fallback to current directory
DB_PATH = os.getenv("DB_PATH", "support_bot.db")


@contextmanager
def get_db():
    """Context manager for database connections"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()


def init_database():
    """Initialize database schema"""
    with get_db() as conn:
        cursor = conn.cursor()
        
        # Leaderboard table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS leaderboard (
                user_id INTEGER PRIMARY KEY,
                ticket_count INTEGER NOT NULL DEFAULT 0
            )
        """)
        
        # Active tickets table - tracks which users have open tickets in which categories
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS active_tickets (
                user_id INTEGER NOT NULL,
                category TEXT NOT NULL,
                channel_id INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, category)
            )
        """)
        
        # Ticket states table - stores the full state of each ticket
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ticket_states (
                channel_id INTEGER PRIMARY KEY,
                user_id INTEGER NOT NULL,
                category TEXT NOT NULL,
                state_data TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Ticket opening messages table - tracks the opening channel messages
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS ticket_opening_messages (
                channel_id INTEGER PRIMARY KEY,
                message_id INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create indexes for performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_active_tickets_user ON active_tickets(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_active_tickets_channel ON active_tickets(channel_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_ticket_states_user ON ticket_states(user_id)")
        
        conn.commit()


# ==================== LEADERBOARD FUNCTIONS ====================

def get_leaderboard() -> Dict[int, int]:
    """Get the full leaderboard as a dictionary"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user_id, ticket_count FROM leaderboard")
        return {row['user_id']: row['ticket_count'] for row in cursor.fetchall()}


def increment_leaderboard(user_id: int, amount: int = 1):
    """Increment a user's ticket count"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO leaderboard (user_id, ticket_count)
            VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                ticket_count = ticket_count + ?
        """, (user_id, amount, amount))


def get_top_leaderboard(limit: int = 10) -> List[Tuple[int, int]]:
    """Get top N users from leaderboard, sorted by ticket count"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT user_id, ticket_count 
            FROM leaderboard 
            ORDER BY ticket_count DESC 
            LIMIT ?
        """, (limit,))
        return [(row['user_id'], row['ticket_count']) for row in cursor.fetchall()]


# ==================== ACTIVE TICKETS FUNCTIONS ====================

def add_active_ticket(user_id: int, category: str, channel_id: int):
    """Register a new active ticket"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO active_tickets (user_id, category, channel_id)
            VALUES (?, ?, ?)
        """, (user_id, category, channel_id))


def remove_active_ticket(user_id: int, category: str):
    """Remove an active ticket when it's closed"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            DELETE FROM active_tickets 
            WHERE user_id = ? AND category = ?
        """, (user_id, category))


def get_user_active_tickets(user_id: int) -> Dict[str, int]:
    """Get all active tickets for a user"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT category, channel_id 
            FROM active_tickets 
            WHERE user_id = ?
        """, (user_id,))
        return {row['category']: row['channel_id'] for row in cursor.fetchall()}


def has_active_ticket(user_id: int, category: str) -> bool:
    """Check if a user has an active ticket in a category"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 1 FROM active_tickets 
            WHERE user_id = ? AND category = ?
        """, (user_id, category))
        return cursor.fetchone() is not None


def get_all_active_tickets() -> Dict[int, Dict[str, int]]:
    """
    Get all active tickets in the format:
    {user_id: {category: channel_id}}
    """
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user_id, category, channel_id FROM active_tickets")
        
        result = {}
        for row in cursor.fetchall():
            user_id = row['user_id']
            if user_id not in result:
                result[user_id] = {}
            result[user_id][row['category']] = row['channel_id']
        
        return result


# ==================== TICKET STATES FUNCTIONS ====================

def save_ticket_state(channel_id: int, user_id: int, category: str, state_data: dict):
    """Save or update a ticket's state"""
    with get_db() as conn:
        cursor = conn.cursor()
        
        # Make a copy to avoid modifying original
        state_copy = state_data.copy()
        
        # Ensure datetime objects are converted to strings
        if 'createdAt' in state_copy and not isinstance(state_copy['createdAt'], str):
            state_copy['createdAt'] = state_copy['createdAt'].isoformat()
        
        # Serialize state data to JSON
        try:
            state_json = json.dumps(state_copy)
        except TypeError as e:
            # If there's a serialization error, log it and try with a sanitized version
            print(f"Error serializing state for channel {channel_id}: {e}")
            # Remove problematic fields and try again
            state_copy = {k: v for k, v in state_copy.items() 
                         if isinstance(v, (str, int, bool, list, dict, type(None)))}
            state_json = json.dumps(state_copy)
        
        cursor.execute("""
            INSERT INTO ticket_states (channel_id, user_id, category, state_data, updated_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(channel_id) DO UPDATE SET
                state_data = ?,
                updated_at = CURRENT_TIMESTAMP
        """, (channel_id, user_id, category, state_json, state_json))


def get_ticket_state(channel_id: int) -> Optional[dict]:
    """Get a ticket's state by channel ID"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT state_data FROM ticket_states 
            WHERE channel_id = ?
        """, (channel_id,))
        
        row = cursor.fetchone()
        if row:
            return json.loads(row['state_data'])
        return None


def remove_ticket_state(channel_id: int):
    """Remove a ticket state when ticket is closed"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            DELETE FROM ticket_states 
            WHERE channel_id = ?
        """, (channel_id,))


def get_all_ticket_states() -> Dict[int, dict]:
    """Get all ticket states as {channel_id: state_dict}"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT channel_id, state_data FROM ticket_states")
        
        return {
            row['channel_id']: json.loads(row['state_data']) 
            for row in cursor.fetchall()
        }


# ==================== TICKET OPENING MESSAGES FUNCTIONS ====================

def save_opening_message(channel_id: int, message_id: int):
    """Save a ticket opening message ID"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO ticket_opening_messages (channel_id, message_id)
            VALUES (?, ?)
            ON CONFLICT(channel_id) DO UPDATE SET
                message_id = ?
        """, (channel_id, message_id, message_id))


def get_opening_message(channel_id: int) -> Optional[int]:
    """Get a ticket opening message ID"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT message_id FROM ticket_opening_messages 
            WHERE channel_id = ?
        """, (channel_id,))
        
        row = cursor.fetchone()
        return row['message_id'] if row else None


def remove_opening_message(channel_id: int):
    """Remove a ticket opening message"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            DELETE FROM ticket_opening_messages 
            WHERE channel_id = ?
        """, (channel_id,))


def get_all_opening_messages() -> Dict[int, int]:
    """Get all opening messages as {channel_id: message_id}"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT channel_id, message_id FROM ticket_opening_messages")
        
        return {
            row['channel_id']: row['message_id'] 
            for row in cursor.fetchall()
        }


# ==================== MIGRATION HELPER ====================

def migrate_from_leaderboard_txt():
    """
    Migrate data from old leaderboard.txt file to database.
    This is a one-time migration helper.
    """
    if not os.path.exists("leaderboard.txt"):
        return
    
    print("Migrating leaderboard.txt to database...")
    
    with get_db() as conn:
        cursor = conn.cursor()
        
        with open("leaderboard.txt", "r") as f:
            for line in f:
                line = line.strip()
                if ":" in line:
                    try:
                        user_id, count = line.split(":")
                        cursor.execute("""
                            INSERT INTO leaderboard (user_id, ticket_count)
                            VALUES (?, ?)
                            ON CONFLICT(user_id) DO UPDATE SET
                                ticket_count = ?
                        """, (int(user_id), int(count), int(count)))
                    except ValueError:
                        print(f"Skipping invalid line: {line}")
    
    # Rename old file as backup
    os.rename("leaderboard.txt", "leaderboard.txt.backup")
    print("Migration complete! Old file backed up as leaderboard.txt.backup")
