import discord
from discord import app_commands
from discord.ext import commands
import os
from datetime import datetime
from typing import Dict, List, Optional
import asyncio
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as RLImage, Table, TableStyle, KeepTogether, PageBreak
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.colors import HexColor, white, black
import aiohttp

try:
    import database as db
    DATABASE_AVAILABLE = True
except Exception as e:
    DATABASE_AVAILABLE = False

# channel ids
supportChannelId = 1439760484655038536
ticketOpeningsChannelId = 1387845861018697838
ticketArchivesChannelId = 1382406640262975508
staffPingRoleId = 1449454364329771129 # ticket pings 
staffRoleIds = [1382406422322741278, 1387284958422368266] # initial access to ticket
viewCommandRoleIds = [1382406419487129620, 1383922684353843351, 1387284958422368266, 1383922459841134662] # list of staff roles
guildId = 1020646109992992828  # rbw disc server ID

categories = {
    "general": 1449135336029421568,
    "report": 1449135395768893492,
    "appeals": 1449135441201856573,
    "scoring": 1449135502623248496,
    "store": 1449135545966919751,
    "payouts": 1449135591055687831
}

# colours
embedColor = 0x004CFF
discordBg = HexColor('#2f3136')
discordEmbedBg = HexColor('#202225')

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

# temp ticket data
activeTickets: Dict[int, Dict[str, int]] = {}
ticketStates: Dict[int, dict] = {}
ticketOpeningMessages: Dict[int, int] = {}

# ticket questions
questionFlows = {
    "general": [
        {"type": "text", "question": "What can we help you with?", "detail": "Please describe your question or issue in detail", "await_text": "Awaiting your question"}
    ],
    "scoring": [
        {
            "type": "dropdown",
            "question": "What's the problem with?",
            "detail": "Select the category that best describes your issue",
            "await_text": "Awaiting selection",
            "options": [
                {"label": "My stats", "value": "my_stats", "emoji": "📊"},
                {"label": "My Ranked Game", "value": "my_ranked_game", "emoji": "🏆"}
            ],
            "next": {
                "my_stats": [
                    {"type": "text", "question": "Which stat is wrong, and why?", "detail": "Please specify the stat and explain the discrepancy", "await_text": "Awaiting stat details"}
                ],
                "my_ranked_game": [
                    {"type": "text", "question": "What is the Game ID?", "detail": "Please provide the game ID number from RBW", "await_text": "Awaiting Game ID"},
                    {
                        "type": "dropdown",
                        "question": "What is the issue with your game?",
                        "detail": "Select the issue type that applies",
                        "await_text": "Awaiting issue selection",
                        "options": [
                            {"label": "I need the game voided", "value": "voided", "emoji": "🚫"},
                            {"label": "I need the game scored", "value": "scored", "emoji": "✅"},
                            {"label": "The game wasn't scored correctly", "value": "incorrect", "emoji": "⚠️"}
                        ],
                        "next": {
                            "voided": [
                                {"type": "text", "question": "Why should it be voided?", "detail": "Explain the reason this game should be voided", "await_text": "Awaiting void reason"},
                                {"type": "text", "question": "Submit the replay command", "detail": "Provide the replay command for this game (e.g. /replay <id>)", "await_text": "Awaiting replay command"}
                            ],
                            "scored": [],
                            "incorrect": []
                        }
                    }
                ]
            }
        }
    ],
    "report": [
        {"type": "text", "question": "Discord ID / IGN of player you're reporting", "detail": "Provide their Discord ID or in-game name (IGN)", "await_text": "Awaiting player info"},
        {"type": "text", "question": "What offense did they commit?", "detail": "Describe which rule they broke in detail", "await_text": "Awaiting offense details"},
        {"type": "text", "question": "Do you have any proof?", "detail": "Provide links to screenshots, videos, or other evidence", "await_text": "Awaiting proof"}
    ],
    "appeals": [
        {"type": "text", "question": "What punishment would you like to appeal?", "detail": "Specify the ban, mute, or strike you're appealing", "await_text": "Awaiting punishment type"},
        {"type": "text", "question": "Why should we revoke this punishment?", "detail": "Explain your reasoning for why this appeal should be granted", "await_text": "Awaiting reasoning"}
    ],
    "store": [
        {"type": "text", "question": "What have you purchased?", "detail": "Describe the item, package, or rank you bought", "await_text": "Awaiting purchase details"}
    ],
    "payouts": [
        {"type": "text", "question": "What prize did you win?", "detail": "Specify the tournament or event prize you're claiming", "await_text": "Awaiting prize details"}
    ]
}


def persistTicketState(channelId: int):
    if not DATABASE_AVAILABLE:
        return
    try:
        if channelId in ticketStates:
            state = ticketStates[channelId]
            db.save_ticket_state(
                channelId, 
                state["userId"], 
                state["category"], 
                state
            )
    except:
        pass


class TicketCategoryView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(emoji="💬", style=discord.ButtonStyle.secondary, custom_id="ticket:general")
    async def general_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await createTicket(interaction, "general")

    @discord.ui.button(emoji="🚨", style=discord.ButtonStyle.secondary, custom_id="ticket:report")
    async def report_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await createTicket(interaction, "report")

    @discord.ui.button(emoji="⚖️", style=discord.ButtonStyle.secondary, custom_id="ticket:appeals")
    async def appeals_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await createTicket(interaction, "appeals")

    @discord.ui.button(emoji="🎯", style=discord.ButtonStyle.secondary, custom_id="ticket:scoring")
    async def scoring_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await createTicket(interaction, "scoring")

    @discord.ui.button(emoji="🛍️", style=discord.ButtonStyle.secondary, custom_id="ticket:store")
    async def store_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await createTicket(interaction, "store")

    @discord.ui.button(emoji="💸", style=discord.ButtonStyle.secondary, custom_id="ticket:payouts")
    async def payouts_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await createTicket(interaction, "payouts")


class StartTicketView(discord.ui.View):
    def __init__(self, channelId: int):
        super().__init__(timeout=None)
        self.channelId = channelId

    @discord.ui.button(label="Start Ticket", style=discord.ButtonStyle.green, emoji="🚀", custom_id=f"start_ticket")
    async def start_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.channel_id != self.channelId:
            return
        
        state = ticketStates.get(self.channelId)
        if not state or interaction.user.id != state["userId"]:
            await interaction.response.send_message("Only the ticket creator can start the ticket.", ephemeral=True, delete_after=15)
            return
        
        await interaction.response.defer()
        
        user = interaction.guild.get_member(state["userId"])
        if user:
            await interaction.channel.set_permissions(user, read_messages=True, send_messages=True)
        
        button.disabled = True
        await interaction.message.edit(view=self)
        
        state["mainMessageId"] = interaction.message.id
        persistTicketState(self.channelId)
        
        await processNextQuestion(interaction.channel, state, editMessage=interaction.message)


class JoinTicketView(discord.ui.View):
    def __init__(self, channelId: int, status: str = "pending"):
        super().__init__(timeout=None)
        self.channelId = channelId
        self.updateButton(status)

    def updateButton(self, status: str):
        self.clear_items()
        if status == "pending":
            button = discord.ui.Button(
                label="Join Ticket",
                style=discord.ButtonStyle.green,
                custom_id=f"join_ticket:{self.channelId}"
            )
        elif status == "active":
            button = discord.ui.Button(
                label="Join Ticket (Active)",
                style=discord.ButtonStyle.secondary,
                custom_id=f"join_ticket:{self.channelId}",
                disabled=False
            )
        else:
            button = discord.ui.Button(
                label="Ticket Closed",
                style=discord.ButtonStyle.danger,
                custom_id=f"join_ticket:{self.channelId}",
                disabled=True
            )
        
        button.callback = self.joinCallback
        self.add_item(button)

    async def joinCallback(self, interaction: discord.Interaction):
        channel = bot.get_channel(self.channelId)
        if not channel:
            await interaction.response.send_message("Ticket channel not found.", ephemeral=True, delete_after=15)
            return

        pingMsg = await channel.send(f"{interaction.user.mention}")
        await pingMsg.delete()
        
        joinEmbed = discord.Embed(
            description=f"{interaction.user.mention} has joined the ticket.",
            color=embedColor
        )
        joinEmbed.set_footer(text="Ranked Bedwars Support • RBW")
        await channel.send(embed=joinEmbed)
        
        if ticketStates.get(self.channelId, {}).get("status") == "pending":
            ticketStates[self.channelId]["status"] = "active"
            persistTicketState(self.channelId)
            self.updateButton("active")
            
            try:
                await interaction.message.edit(view=self)
            except:
                pass

        await interaction.response.send_message(f"Joined ticket {channel.mention}", ephemeral=True, delete_after=15)


class QuestionView(discord.ui.View):
    def __init__(self, channelId: int, options: List[dict], questionData: dict):
        super().__init__(timeout=None)
        self.channelId = channelId
        self.questionData = questionData
        
        selectOptions = [
            discord.SelectOption(label=opt["label"], value=opt["value"], emoji=opt.get("emoji"))
            for opt in options
        ]
        
        select = discord.ui.Select(
            placeholder="Select an option...",
            options=selectOptions,
            custom_id=f"question:{channelId}",
            disabled=False
        )
        select.callback = self.selectCallback
        self.add_item(select)

    async def selectCallback(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        self.children[0].disabled = True
        await interaction.message.edit(view=self)
        
        selectedValue = interaction.data["values"][0]
        selectedLabel = next(opt["label"] for opt in self.questionData["options"] if opt["value"] == selectedValue)
        
        state = ticketStates[self.channelId]
        state["answers"].append({
            "question": self.questionData["question"],
            "answer": selectedLabel,
            "type": "dropdown"
        })
        
        if "next" in self.questionData and selectedValue in self.questionData["next"]:
            nextQuestions = self.questionData["next"][selectedValue]
            state["currentFlow"] = nextQuestions
            state["currentIndex"] = 0
            persistTicketState(self.channelId)
            await processNextQuestion(interaction.channel, state, editMessage=interaction.message)
        else:
            persistTicketState(self.channelId)
            await finishQuestions(interaction.channel, state, editMessage=interaction.message)


class AwaitingView(discord.ui.View):
    def __init__(self, text: str):
        super().__init__(timeout=None)
        button = discord.ui.Button(label=text, style=discord.ButtonStyle.secondary, disabled=True)
        self.add_item(button)


class SummaryView(discord.ui.View):
    def __init__(self, channelId: int):
        super().__init__(timeout=None)
        self.channelId = channelId

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.green, emoji="✅")
    async def confirmButton(self, interaction: discord.Interaction, button: discord.ui.Button):
        state = ticketStates.get(self.channelId)
        if not state or interaction.user.id != state["userId"]:
            await interaction.response.send_message("Only the ticket creator can confirm.", ephemeral=True, delete_after=15)
            return
        
        await interaction.response.defer()
        
        for item in self.children:
            item.disabled = True
        await interaction.message.edit(view=self)
        
        final_embed = discord.Embed(
            description="A staff member will be here to help shortly.",
            color=embedColor
        )
        final_embed.set_footer(text="Ranked Bedwars Support • RBW")
        await interaction.channel.send(embed=final_embed)
        
        await sendToTicketOpenings(interaction.channel, state)
        
        state["confirmed"] = True
        persistTicketState(self.channelId)

    @discord.ui.button(label="Restart", style=discord.ButtonStyle.primary, emoji="🔄")
    async def restartButton(self, interaction: discord.Interaction, button: discord.ui.Button):
        state = ticketStates.get(self.channelId)
        if not state or interaction.user.id != state["userId"]:
            await interaction.response.send_message("Only the ticket creator can restart.", ephemeral=True, delete_after=15)
            return
        
        await interaction.response.defer()
        
        state["answers"] = []
        state["currentFlow"] = questionFlows[state["category"]]
        state["currentIndex"] = 0
        persistTicketState(self.channelId)
        
        await processNextQuestion(interaction.channel, state, editMessage=interaction.message)

    @discord.ui.button(label="Close", style=discord.ButtonStyle.danger, emoji="⛔")
    async def closeButton(self, interaction: discord.Interaction, button: discord.ui.Button):
        state = ticketStates.get(self.channelId)
        if not state or interaction.user.id != state["userId"]:
            await interaction.response.send_message("Only the ticket creator can close.", ephemeral=True, delete_after=15)
            return
        
        await interaction.response.defer()
        
        closeEmbed = discord.Embed(
            description="🔒 Ticket closing. This channel will be deleted shortly.",
            color=embedColor
        )
        closeEmbed.set_footer(text="Ranked Bedwars Support • RBW")
        await interaction.channel.send(embed=closeEmbed)
        
        userId = state["userId"]
        category = state["category"]
        
        if DATABASE_AVAILABLE:
            try:
                db.remove_active_ticket(userId, category)
                db.remove_ticket_state(self.channelId)
                db.remove_opening_message(self.channelId)
            except:
                pass
        
        if userId in activeTickets and category in activeTickets[userId]:
            del activeTickets[userId][category]
            if not activeTickets[userId]:
                del activeTickets[userId]
        
        if self.channelId in ticketStates:
            del ticketStates[self.channelId]
        if self.channelId in ticketOpeningMessages:
            del ticketOpeningMessages[self.channelId]
        
        await asyncio.sleep(3)
        try:
            await interaction.channel.delete()
        except:
            pass


class RoleRemoveView(discord.ui.View):
    def __init__(self, channel: discord.TextChannel, roles: List[discord.Role]):
        super().__init__(timeout=180)
        self.channel = channel
        self.ephemeralMsg = None
        
        options = [
            discord.SelectOption(label=role.name, value=str(role.id))
            for role in roles
        ]
        
        select = discord.ui.Select(
            placeholder="Select the minimum required role...",
            options=options
        )
        select.callback = self.selectCallback
        self.add_item(select)

    async def selectCallback(self, interaction: discord.Interaction):
        roleId = int(interaction.data["values"][0])
        role = interaction.guild.get_role(roleId)
        
        if not role:
            await interaction.response.send_message("Role not found.", ephemeral=True, delete_after=15)
            return
        
        try:
            selectedIndex = viewCommandRoleIds.index(roleId)
        except ValueError:
            await interaction.response.send_message("Invalid role selection.", ephemeral=True, delete_after=15)
            return
        
        rolesToRemove = []
        for i in range(selectedIndex + 1, len(viewCommandRoleIds)):
            roleToRemove = interaction.guild.get_role(viewCommandRoleIds[i])
            if roleToRemove:
                await self.channel.set_permissions(roleToRemove, view_channel=False)
                rolesToRemove.append(roleToRemove.mention)
        
        await interaction.response.defer()
        
        if len(rolesToRemove) == 0:
            description = f"🔐 Ticket viewing restricted to **{role.name}** and above. No roles were removed (already at lowest tier)."
        elif len(rolesToRemove) == 1:
            description = f"🔐 Ticket viewing restricted to **{role.name}** and above.\nRole {rolesToRemove[0]} no longer has permission to view this ticket."
        else:
            description = f"🔐 Ticket viewing restricted to **{role.name}** and above.\nRoles {', '.join(rolesToRemove)} no longer have permission to view this ticket."
        
        embed = discord.Embed(
            description=description,
            color=embedColor
        )
        embed.set_footer(text="Ranked Bedwars Support • RBW")
        await self.channel.send(embed=embed)
        
        if self.ephemeralMsg:
            try:
                await self.ephemeralMsg.delete()
            except:
                pass


async def sendToTicketOpenings(channel: discord.TextChannel, state: dict):
    guild = channel.guild
    openingsChannel = guild.get_channel(ticketOpeningsChannelId)
    
    if not openingsChannel:
        return
    
    user = guild.get_member(state["userId"])
    if not user:
        return
    
    staffRole = guild.get_role(1439799191194046504)
    
    embed = discord.Embed(
        title="📩 New Ticket",
        description="A new support ticket has been created. Click below to join.",
        color=embedColor
    )
    embed.add_field(name="User", value=f"{user.mention} ({user.display_name})", inline=False)
    embed.add_field(name="Type", value=state["category"].capitalize(), inline=False)
    embed.add_field(name="Level", value=staffRole.mention if staffRole else "@Staff", inline=False)
    embed.set_footer(text="Ranked Bedwars Support • RBW")
    
    view = JoinTicketView(channel.id, "pending")
    openingMsg = await openingsChannel.send(embed=embed, view=view)
    ticketOpeningMessages[channel.id] = openingMsg.id
    
    if DATABASE_AVAILABLE:
        try:
            db.save_opening_message(channel.id, openingMsg.id)
        except:
            pass
    
    ticketPingRole = guild.get_role(staffPingRoleId)
    if ticketPingRole:
        await openingsChannel.send(f"{ticketPingRole.mention}")


async def createTicket(interaction: discord.Interaction, category: str):
    user = interaction.user
    
    has_ticket = False
    existing_channel_id = None
    
    if DATABASE_AVAILABLE:
        try:
            if db.has_active_ticket(user.id, category):
                user_tickets = db.get_user_active_tickets(user.id)
                existing_channel_id = user_tickets.get(category)
                has_ticket = True
        except:
            pass
    
    if not has_ticket and user.id in activeTickets and category in activeTickets[user.id]:
        existing_channel_id = activeTickets[user.id][category]
        has_ticket = True
    
    if has_ticket:
        existingChannel = bot.get_channel(existing_channel_id) if existing_channel_id else None
        await interaction.response.send_message(
            f"You already have an active {category} ticket: {existingChannel.mention if existingChannel else 'Channel not found'}",
            ephemeral=True,
            delete_after=15
        )
        return

    await interaction.response.defer(ephemeral=True)

    guild = interaction.guild
    ticketCategory = guild.get_channel(categories[category])
    
    if not ticketCategory:
        await interaction.followup.send("Ticket category not found.", ephemeral=True)
        return

    channelName = f"ticket-{user.name}".lower()[:100]
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(read_messages=False),
        user: discord.PermissionOverwrite(read_messages=True, send_messages=False),  # muted until they press Start Ticket
        guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
    }
    
    for roleId in staffRoleIds:
        role = guild.get_role(roleId)
        if role:
            overwrites[role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

    ticketChannel = await ticketCategory.create_text_channel(
        name=channelName,
        overwrites=overwrites
    )

    if DATABASE_AVAILABLE:
        try:
            db.add_active_ticket(user.id, category, ticketChannel.id)
        except:
            pass
    
    if user.id not in activeTickets:
        activeTickets[user.id] = {}
    activeTickets[user.id][category] = ticketChannel.id

    state = {
        "userId": user.id,
        "category": category,
        "status": "pending",
        "answers": [],
        "currentFlow": questionFlows[category],
        "currentIndex": 0,
        "createdAt": datetime.now().isoformat(),
        "confirmed": False,
        "mainMessageId": None
    }
    
    ticketStates[ticketChannel.id] = state
    
    if DATABASE_AVAILABLE:
        try:
            db.save_ticket_state(ticketChannel.id, user.id, category, state)
        except:
            pass

    await ticketChannel.send(f"{user.mention}")

    welcomeEmbed = discord.Embed(
        title="Ranked Bedwars Support",
        description=f"Thank you for opening a support ticket!\n\nYou've selected the **{category}** category. Please click the button below to begin answering a few questions so we can better assist you.\n\n*All information will be reviewed by our support team.*",
        color=embedColor
    )
    welcomeEmbed.set_footer(text="Ranked Bedwars Support • RBW")
    
    view = StartTicketView(ticketChannel.id)
    await ticketChannel.send(embed=welcomeEmbed, view=view)

    await interaction.followup.send(f"Ticket created: {ticketChannel.mention}", ephemeral=True)


async def processNextQuestion(channel: discord.TextChannel, state: dict, editMessage: discord.Message = None):
    currentFlow = state["currentFlow"]
    currentIndex = state["currentIndex"]

    if currentIndex >= len(currentFlow):
        await finishQuestions(channel, state, editMessage=editMessage)
        return

    questionData = currentFlow[currentIndex]
    
    questionText = questionData["question"]
    detailText = questionData.get("detail", "")
    
    if questionData["type"] == "text":
        embed = discord.Embed(
            title=questionText,
            description=f"```\n{detailText}\n```" if detailText else "",
            color=embedColor
        )
        embed.set_footer(text="Please answer in ONE message • Ranked Bedwars Support")
        
        view = AwaitingView(questionData.get("await_text", "Awaiting response"))
        
        if editMessage:
            await editMessage.edit(embed=embed, view=view)
            msg = editMessage
        else:
            msg = await channel.send(embed=embed, view=view)
            state["mainMessageId"] = msg.id
        
        state["waitingFor"] = "text"
        persistTicketState(channel.id)
        
    elif questionData["type"] == "dropdown":
        embed = discord.Embed(
            title=questionText,
            description=f"```\n{detailText}\n```" if detailText else "",
            color=embedColor
        )
        embed.set_footer(text="Select an option below • Ranked Bedwars Support")
        
        view = QuestionView(channel.id, questionData["options"], questionData)
        
        if editMessage:
            await editMessage.edit(embed=embed, view=view)
            msg = editMessage
        else:
            msg = await channel.send(embed=embed, view=view)
            state["mainMessageId"] = msg.id
        
        state["waitingFor"] = "dropdown"
        persistTicketState(channel.id)


async def finishQuestions(channel: discord.TextChannel, state: dict, editMessage: discord.Message = None):
    embed = discord.Embed(
        title="Ticket Summary",
        description="Here's a summary of your responses. Please review and confirm:",
        color=embedColor
    )

    for i, qa in enumerate(state["answers"], 1):
        answerFormatted = f"```\n{qa['answer']}\n```"
        embed.add_field(
            name=f"Q{i}: {qa['question']}",
            value=answerFormatted,
            inline=False
        )
    
    embed.set_footer(text="Ranked Bedwars Support • RBW")

    view = SummaryView(channel.id)
    
    if editMessage:
        await editMessage.edit(embed=embed, view=view)
    else:
        await channel.send(embed=embed, view=view)
    
    state["waitingFor"] = None
    persistTicketState(channel.id)


async def updateOpeningStatus(channelId: int, status: str):
    if channelId not in ticketOpeningMessages:
        return
    
    openingMsgId = ticketOpeningMessages[channelId]
    openingsChannel = bot.get_channel(ticketOpeningsChannelId)
    
    if not openingsChannel:
        return
    
    try:
        openingMsg = await openingsChannel.fetch_message(openingMsgId)
        view = JoinTicketView(channelId, status)
        await openingMsg.edit(view=view)
    except:
        pass


async def createTicket_archive(channel: discord.TextChannel, closedBy: discord.Member):
    messages = []
    async for message in channel.history(limit=None, oldest_first=True):
        if not message.author.bot:
            messages.append(message)

    pdfBuffer = BytesIO()
    
    def addBg(canvasObj, doc):
        canvasObj.saveState()
        canvasObj.setFillColor(discordBg)
        canvasObj.rect(0, 0, letter[0], letter[1], fill=1, stroke=0)
        canvasObj.restoreState()
    
    doc = SimpleDocTemplate(
        pdfBuffer, 
        pagesize=letter,
        topMargin=0.75*inch,
        bottomMargin=0.75*inch,
        leftMargin=0.75*inch,
        rightMargin=0.75*inch
    )
    
    story = []
    styles = getSampleStyleSheet()
    
    titleStyle = ParagraphStyle(
        'DiscordTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor=white,
        spaceAfter=20,
        alignment=TA_CENTER,
        fontName='Helvetica-Bold'
    )
    
    sectionStyle = ParagraphStyle(
        'DiscordSection',
        parent=styles['Heading2'],
        fontSize=16,
        textColor=HexColor('#5865F2'),
        spaceAfter=14,
        spaceBefore=20,
        fontName='Helvetica-Bold'
    )
    
    messageAuthorStyle = ParagraphStyle(
        'MessageAuthor',
        parent=styles['Normal'],
        fontSize=11,
        textColor=HexColor('#FFFFFF'),
        fontName='Helvetica-Bold',
        spaceAfter=4
    )
    
    messageContentStyle = ParagraphStyle(
        'MessageContent',
        parent=styles['Normal'],
        fontSize=10,
        textColor=HexColor('#DCDDDE'),
        leftIndent=0,
        spaceAfter=12,
        leading=14
    )
    
    metadataStyle = ParagraphStyle(
        'Metadata',
        parent=styles['Normal'],
        fontSize=10,
        textColor=HexColor('#B9BBBE'),
        leading=16
    )

    story.append(Paragraph("RANKED BEDWARS SUPPORT TICKET", titleStyle))
    story.append(Spacer(1, 0.3*inch))
    
    state = ticketStates.get(channel.id, {})
    user = channel.guild.get_member(state.get("userId", 0))
    
    # Handle createdAt - it might be a string (ISO format) or datetime
    created_at = state.get('createdAt', datetime.now())
    if isinstance(created_at, str):
        try:
            created_at = datetime.fromisoformat(created_at)
        except:
            created_at = datetime.now()
    
    metadataData = [
        [Paragraph("<b>Category</b>", metadataStyle), Paragraph(state.get('category', 'Unknown').upper(), metadataStyle)],
        [Paragraph("<b>User</b>", metadataStyle), Paragraph(f"{user.display_name} ({state.get('userId', 'Unknown')})" if user else 'Unknown', metadataStyle)],
        [Paragraph("<b>Created</b>", metadataStyle), Paragraph(created_at.strftime('%B %d, %Y at %I:%M %p'), metadataStyle)],
        [Paragraph("<b>Closed By</b>", metadataStyle), Paragraph(f"{closedBy.display_name} ({closedBy.id})", metadataStyle)],
        [Paragraph("<b>Closed At</b>", metadataStyle), Paragraph(datetime.now().strftime('%B %d, %Y at %I:%M %p'), metadataStyle)]
    ]
    
    metadataTable = Table(metadataData, colWidths=[1.8*inch, 4.2*inch])
    metadataTable.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), discordEmbedBg),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('LINEBELOW', (0, 0), (-1, -2), 0.5, HexColor('#40444B')),
    ]))
    story.append(metadataTable)
    story.append(Spacer(1, 0.35*inch))
    
    if state.get("answers"):
        story.append(Paragraph("📋 INITIAL RESPONSES", sectionStyle))
        story.append(Spacer(1, 0.1*inch))
        
        qaData = []
        for qa in state["answers"]:
            qText = qa['question'].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            aText = qa['answer'].replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            
            qaData.append([
                Paragraph(f"<b>Q:</b> {qText}", metadataStyle),
            ])
            qaData.append([
                Paragraph(f"<font color='#00D9FF'><b>A:</b></font> {aText}", messageContentStyle),
            ])
        
        qaTable = Table(qaData, colWidths=[6*inch])
        qaTable.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), discordEmbedBg),
            ('LEFTPADDING', (0, 0), (-1, -1), 14),
            ('RIGHTPADDING', (0, 0), (-1, -1), 14),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ]))
        story.append(qaTable)
        
        story.append(Spacer(1, 0.5*inch))
        footerText = Paragraph(
            "<font color='#72767D'>This ticket was handled by the Ranked Bedwars Support Team</font>",
            ParagraphStyle(
                'Footer',
                parent=metadataStyle,
                fontSize=9,
                alignment=TA_CENTER,
                textColor=HexColor('#72767D')
            )
        )
        story.append(footerText)
        
        story.append(PageBreak())
    
    if messages:
        story.append(Paragraph("💬 CONVERSATION HISTORY", sectionStyle))
        story.append(Spacer(1, 0.15*inch))

        async with aiohttp.ClientSession() as session:
            for msg in messages:
                timestamp = msg.created_at.strftime('%m/%d/%Y %I:%M %p')
                authorName = msg.author.display_name.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                
                messageBlock = []
                
                authorHeader = Paragraph(
                    f"<font color='#5865F2'><b>{authorName}</b></font> <font color='#72767D'>• {timestamp}</font>",
                    messageAuthorStyle
                )
                messageBlock.append(authorHeader)
                
                if msg.content:
                    content = msg.content.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                    messageBlock.append(Paragraph(content, messageContentStyle))
                
                for attachment in msg.attachments:
                    if attachment.content_type and attachment.content_type.startswith('image'):
                        try:
                            async with session.get(attachment.url) as resp:
                                if resp.status == 200:
                                    imgData = await resp.read()
                                    imgBuffer = BytesIO(imgData)
                                    img = RLImage(imgBuffer, width=3.5*inch, height=2.625*inch, kind='proportional', hAlign='LEFT')
                                    messageBlock.append(Spacer(1, 0.1*inch))
                                    messageBlock.append(img)
                        except:
                            messageBlock.append(Paragraph(f"<font color='#00AFF4'>[Image: {attachment.filename}]</font>", messageContentStyle))
                    else:
                        messageBlock.append(Paragraph(f"<font color='#00AFF4'>[Attachment: {attachment.filename}]</font>", messageContentStyle))
                
                messageBlock.append(Spacer(1, 0.15*inch))
                
                story.append(KeepTogether(messageBlock))

    doc.build(story, onFirstPage=addBg, onLaterPages=addBg)
    pdfBuffer.seek(0)
    
    return pdfBuffer


@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")
    
    # Initialize database if available
    global activeTickets, ticketStates, ticketOpeningMessages
    
    if DATABASE_AVAILABLE:
        try:
            print("Initializing database...")
            db.init_database()
            print("Database initialized successfully")
            
            # Migrate old leaderboard.txt if it exists
            db.migrate_from_leaderboard_txt()
            
            # Restore state from database
            print("Restoring ticket states from database...")
            
            activeTickets = db.get_all_active_tickets()
            ticketStates = db.get_all_ticket_states()
            ticketOpeningMessages = db.get_all_opening_messages()
            
            print(f"Restored {len(activeTickets)} active users with tickets")
            print(f"Restored {len(ticketStates)} ticket states")
            print(f"Restored {len(ticketOpeningMessages)} opening messages")
        except Exception as e:
            print(f"Error during database initialization: {e}")
            print("Continuing without persistence...")
            activeTickets = {}
            ticketStates = {}
            ticketOpeningMessages = {}
    else:
        print("Running without database persistence")
        activeTickets = {}
        ticketStates = {}
        ticketOpeningMessages = {}
    
    bot.add_view(TicketCategoryView())
    
    for channelId, state in ticketStates.items():
        if channelId in ticketOpeningMessages:
            view = JoinTicketView(channelId, state.get("status", "pending"))
            bot.add_view(view)
    
    try:
        guild = discord.Object(id=guildId)
        bot.tree.copy_global_to(guild=guild)
        synced = await bot.tree.sync(guild=guild)
        print(f"Synced {len(synced)} command(s) to guild {guild}")
    except Exception as e:
        print(f"Failed to sync commands: {e}")


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return
    
    channelId = message.channel.id
    
    if channelId in ticketStates:
        state = ticketStates[channelId]
        
        if state.get("waitingFor") == "text" and message.author.id == state["userId"]:
            currentQuestion = state["currentFlow"][state["currentIndex"]]
            state["answers"].append({
                "question": currentQuestion["question"],
                "answer": message.content,
                "type": "text"
            })
            state["currentIndex"] += 1
            persistTicketState(channelId)
            
            try:
                await message.delete()
            except:
                pass
            
            mainMsgId = state.get("mainMessageId")
            if mainMsgId:
                try:
                    mainMsg = await message.channel.fetch_message(mainMsgId)
                    await processNextQuestion(message.channel, state, editMessage=mainMsg)
                except Exception as e:
                    print(f"Error editing message: {e}")
                    await processNextQuestion(message.channel, state)


def isStaff():
    async def predicate(interaction: discord.Interaction) -> bool:
        userRoleIds = [role.id for role in interaction.user.roles]
        return any(roleId in staffRoleIds for roleId in userRoleIds)
    return app_commands.check(predicate)


ticketGroup = app_commands.Group(
    name="ticket",
    description="Ticket management commands"
)


@ticketGroup.command(name="activate", description="Activate the ticket system")
@isStaff()
async def activate(interaction: discord.Interaction):
    channel = interaction.guild.get_channel(supportChannelId)
    
    if not channel:
        await interaction.response.send_message("Support channel not found.", ephemeral=True, delete_after=15)
        return

    embed = discord.Embed(
        title="Ranked Bedwars Support",
        description=(
            "Select the category that best fits your needs:\n\n"
            "💬 **General** — Ask questions and get help\n\n"
            "🚨 **Report** — Report a player for breaking the rules.\n\n"
            "⚖️ **Appeals** — Appeal a strike, mute, or ban\n\n"
            "🎯 **Scoring** — Dispute game outcomes or stats\n\n"
            "🛍️ **Store** — Store or payment issues\n\n"
            "💸 **Payouts** — Prize claims and payouts"
        ),
        color=embedColor
    )
    embed.set_footer(text="Click a button below to open a ticket • Ranked Bedwars Support")
    
    view = TicketCategoryView()
    await channel.send(embed=embed, view=view)
    
    await interaction.response.send_message(
        f"{interaction.user.mention} has activated Ranked Bedwars Support tickets.",
        ephemeral=False
    )


@ticketGroup.command(name="close", description="Close the current ticket")
@isStaff()
async def closeTicket(interaction: discord.Interaction):
    channelId = interaction.channel_id
    
    if channelId not in ticketStates:
        await interaction.response.send_message("This is not a ticket channel.", ephemeral=True, delete_after=15)
        return

    await interaction.response.defer(ephemeral=True)

    state = ticketStates[channelId]
    userId = state["userId"]
    category = state["category"]

    if DATABASE_AVAILABLE:
        try:
            db.increment_leaderboard(interaction.user.id, 1)
        except:
            pass

    await updateOpeningStatus(channelId, "closed")

    archivesChannel = interaction.guild.get_channel(ticketArchivesChannelId)
    if archivesChannel:
        user = interaction.guild.get_member(userId)
        embed = discord.Embed(
            title="📁 Ticket Archived",
            description=f"**Channel:** `{interaction.channel.name}`\n**Category:** {category.capitalize()}\n**User:** {user.mention if user else 'Unknown'}",
            color=embedColor,
            timestamp=datetime.now()
        )
        embed.add_field(name="Closed by", value=interaction.user.mention, inline=True)
        embed.set_footer(text="Ranked Bedwars Support • RBW")
        await archivesChannel.send(embed=embed)
        
        pdfBuffer = await createTicket_archive(interaction.channel, interaction.user)
        file = discord.File(pdfBuffer, filename=f"ticket-{user.name if user else 'unknown'}.pdf")
        await archivesChannel.send(file=file)

    # Remove from database if available
    if DATABASE_AVAILABLE:
        try:
            db.remove_active_ticket(userId, category)
            db.remove_ticket_state(channelId)
            db.remove_opening_message(channelId)
        except:
            pass
    
    # Remove from in-memory caches
    if userId in activeTickets and category in activeTickets[userId]:
        del activeTickets[userId][category]
        if not activeTickets[userId]:
            del activeTickets[userId]

    if channelId in ticketStates:
        del ticketStates[channelId]
    if channelId in ticketOpeningMessages:
        del ticketOpeningMessages[channelId]

    await interaction.followup.send("Ticket closed and archived.", ephemeral=True)

    await asyncio.sleep(5)
    try:
        await interaction.channel.delete()
    except:
        pass


@ticketGroup.command(name="leaderboard", description="View the ticket closure leaderboard")
@isStaff()
async def leaderboard(interaction: discord.Interaction):
    sortedLeaderboard = []
    
    if DATABASE_AVAILABLE:
        try:
            sortedLeaderboard = db.get_top_leaderboard(10)
        except:
            pass
    
    if not sortedLeaderboard:
        await interaction.response.send_message("No tickets have been closed yet.", ephemeral=True, delete_after=15)
        return
    
    embed = discord.Embed(
        title="🏆 Ticket Closure Leaderboard",
        description="Top staff members by tickets closed:",
        color=embedColor
    )

    for i, (userId, count) in enumerate(sortedLeaderboard, 1):
        user = interaction.guild.get_member(userId)
        userName = user.display_name if user else f"User {userId}"
        
        medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"**{i}.**"
        embed.add_field(
            name=f"{medal} {userName}",
            value=f"`{count}` tickets closed",
            inline=False
        )
    
    embed.set_footer(text="Ranked Bedwars Support • RBW")

    await interaction.response.send_message(embed=embed)


@ticketGroup.command(name="add", description="Add a user to the ticket")
@isStaff()
async def addUser(interaction: discord.Interaction, user: discord.Member):
    channelId = interaction.channel_id
    
    if channelId not in ticketStates:
        await interaction.response.send_message("This is not a ticket channel.", ephemeral=True, delete_after=15)
        return

    await interaction.channel.set_permissions(
        user,
        read_messages=True,
        send_messages=True
    )

    embed = discord.Embed(
        description=f"Added {user.mention} to this ticket.",
        color=embedColor
    )
    embed.set_footer(text="Ranked Bedwars Support • RBW")
    await interaction.response.send_message(embed=embed)


@ticketGroup.command(name="remove", description="Remove a user from the ticket")
@isStaff()
async def removeUser(interaction: discord.Interaction, user: discord.Member):
    channelId = interaction.channel_id
    
    if channelId not in ticketStates:
        await interaction.response.send_message("This is not a ticket channel.", ephemeral=True, delete_after=15)
        return

    state = ticketStates[channelId]
    
    if user.id == state["userId"]:
        await interaction.response.send_message("Cannot remove the ticket creator.", ephemeral=True, delete_after=15)
        return

    await interaction.channel.set_permissions(user, overwrite=None)

    embed = discord.Embed(
        description=f"Removed {user.mention} from this ticket.",
        color=embedColor
    )
    embed.set_footer(text="Ranked Bedwars Support • RBW")
    await interaction.response.send_message(embed=embed)


@ticketGroup.command(name="view", description="Manage which roles can view this ticket")
@isStaff()
async def viewTicket(interaction: discord.Interaction):
    channelId = interaction.channel_id
    
    if channelId not in ticketStates:
        await interaction.response.send_message("This is not a ticket channel.", ephemeral=True, delete_after=15)
        return
    
    roles = [interaction.guild.get_role(roleId) for roleId in viewCommandRoleIds]
    roles = [r for r in roles if r is not None]
    
    if not roles:
        await interaction.response.send_message("No roles available to manage.", ephemeral=True, delete_after=15)
        return
    
    view = RoleRemoveView(interaction.channel, roles)
    await interaction.response.send_message("Select the role you must be at or above, to view the ticket:", view=view, ephemeral=True)
    
    try:
        ephemeralMsg = await interaction.original_response()
        view.ephemeralMsg = ephemeralMsg
    except:
        pass


@ticketGroup.command(name="rename", description="Rename the current ticket channel")
@isStaff()
async def renameTicket(interaction: discord.Interaction, name: str):
    channelId = interaction.channel_id
    
    if channelId not in ticketStates:
        await interaction.response.send_message("This is not a ticket channel.", ephemeral=True, delete_after=15)
        return
    
    # Clean and validate the name
    cleaned_name = name.lower().replace(" ", "-")
    # Discord channel names can only contain alphanumeric, hyphens, and underscores
    cleaned_name = ''.join(c for c in cleaned_name if c.isalnum() or c in '-_')
    # Limit to 100 characters (Discord's max)
    cleaned_name = cleaned_name[:100]
    
    if not cleaned_name:
        await interaction.response.send_message("Invalid channel name. Please use alphanumeric characters, hyphens, or underscores.", ephemeral=True, delete_after=15)
        return
    
    old_name = interaction.channel.name
    
    await interaction.response.defer()
    
    try:
        await interaction.channel.edit(name=cleaned_name)
        
        embed = discord.Embed(
            description=f"✏️ Channel renamed from `{old_name}` to `{cleaned_name}`",
            color=embedColor
        )
        embed.set_footer(text="Ranked Bedwars Support • RBW")
        await interaction.followup.send(embed=embed)
    except discord.errors.Forbidden:
        await interaction.followup.send("I don't have permission to rename this channel.", ephemeral=True)
    except Exception as e:
        await interaction.followup.send(f"Failed to rename channel: {str(e)}", ephemeral=True)


bot.tree.add_command(ticketGroup)


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure):
        if not interaction.response.is_done():
            await interaction.response.send_message(
                "You don't have permission to use this command.",
                ephemeral=True,
                delete_after=15
            )
    else:
        print(f"Error: {error}")
        if not interaction.response.is_done():
            try:
                await interaction.response.send_message(
                    "An error occurred while executing this command.",
                    ephemeral=True,
                    delete_after=15
                )
            except:
                pass

if __name__ == "__main__":
    import os
    from dotenv import load_dotenv
    
    # Load environment variables from .env file
    load_dotenv()
    
    # Get Discord token from environment
    token = os.getenv("DISCORD_BOT_TOKEN")
    if not token:
        raise ValueError("DISCORD_BOT_TOKEN not found in environment variables! Please set it in .env file")
    
    bot.run(token)