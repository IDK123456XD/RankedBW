package main

import (
	"log"
	"os"
	"os/signal"
	"syscall"

	"rankedbw-bot-registration/database"

	"github.com/bwmarrin/discordgo"
	"github.com/joho/godotenv"
)

func main() {
	if err := godotenv.Load(); err != nil {
		log.Fatalf("Error loading .env file: %v", err)
	}

	if err := database.InitMySQL(); err != nil {
		log.Fatalf("Failed to connect to MySQL: %v", err)
	}
	if err := database.EnsureDatabaseAndTables(database.DB); err != nil {
		log.Fatalf("Failed to ensure database/tables: %v", err)
	}

	botToken := os.Getenv("BOT_TOKEN")
	if botToken == "" {
		log.Fatal("BOT_TOKEN not set in .env")
	}

	sess, err := discordgo.New("Bot " + botToken)
	if err != nil {
		log.Fatalf("Error creating Discord session: %v", err)
	}

	sess.AddHandler(func(s *discordgo.Session, r *discordgo.Ready) {
		log.Println("Bot is up!")
		RegisterCommands(s)
	})

	if err := sess.Open(); err != nil {
		log.Fatalf("Error opening Discord session: %v", err)
	}
	defer sess.Close()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	<-stop
	log.Println("Shutting down...")
}
