package commands

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"

	"rankedbw-bot-registration/database"

	"github.com/bwmarrin/discordgo"
)

type RegisterCommand struct{}

type HypixelProfile struct {
	Player struct {
		Displayname string `json:"displayname"`
		SocialMedia struct {
			Links struct {
				DISCORD string `json:"DISCORD"`
			} `json:"links"`
		} `json:"socialMedia"`
	} `json:"player"`
}

func (c *RegisterCommand) Data() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        "register",
		Description: "Register your Minecraft account to Ranked BedWars.",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "username",
				Description: "Your Minecraft username",
				Required:    true,
			},
		},
	}
}

func (c *RegisterCommand) Handler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	username := ""
	for _, opt := range i.ApplicationCommandData().Options {
		if opt.Name == "username" {
			username = opt.StringValue()
		}
	}
	if username == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "You must provide a Minecraft username.",
			},
		})
		return
	}

	apiKey := os.Getenv("HYPIXEL_API_KEY")
	if apiKey == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "Hypixel API key is not set. Please contact an admin.",
			},
		})
		return
	}
	url := fmt.Sprintf("https://api.hypixel.net/player?key=%s&name=%s", apiKey, username)
	resp, err := http.Get(url)
	if err != nil || resp.StatusCode != 200 {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "Failed to contact Hypixel API. Try again later.",
			},
		})
		return
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	var profile HypixelProfile
	json.Unmarshal(body, &profile)

	discordTag := ""
	if profile.Player.SocialMedia.Links.DISCORD != "" {
		discordTag = profile.Player.SocialMedia.Links.DISCORD
	}

	userDiscord := i.Member.User.String()
	if discordTag == "" {
		embed := &discordgo.MessageEmbed{
			Title:       "Discord Not Linked",
			Description: fmt.Sprintf("Your Discord is not linked on Hypixel. Your Discord username is %s. The Minecraft Account '%s' is not linked to any Discord. Visit #how-to-register for a simple guide on registering in our Discord.", userDiscord, username),
			Color:       0xffa500,
		}
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{embed},
			},
		})
		return
	}

	if discordTag != userDiscord {
		embed := &discordgo.MessageEmbed{
			Title:       "Discord Mismatch",
			Description: fmt.Sprintf("Your Discord is not linked on Hypixel. Your Discord username is %s. The Minecraft Account '%s' is linked to the wrong Discord (%s). Visit #how-to-register for a simple guide on registering in our Discord.", userDiscord, username, discordTag),
			Color:       0xffa500,
		}
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{embed},
			},
		})
		return
	}

	elo := 1000
	newNick := fmt.Sprintf("[%d] %s", elo, username)
	errNick := s.GuildMemberNickname(i.GuildID, i.Member.User.ID, newNick)
	if errNick != nil {
		log.Printf("Failed to update nickname: %v", errNick)
	}

	registeredRole := os.Getenv("REGISTERED_ROLE_ID")
	if registeredRole != "" {
		s.GuildMemberRoleAdd(i.GuildID, i.Member.User.ID, registeredRole)
	}

	db := database.DB
	if db == nil {
		log.Printf("Database connection is not initialized!")
	} else {
		_, errInsert := db.Exec(`INSERT INTO discord_register (discord_id, minecraft_username, registered_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE minecraft_username = VALUES(minecraft_username)`, i.Member.User.ID, username)
		if errInsert != nil {
			log.Printf("Failed to insert registration into DB: %v", errInsert)
		}
	}

	embed := &discordgo.MessageEmbed{
		Title:       "Registration Successful!",
		Description: fmt.Sprintf("You are now registered as %s.", username),
		Color:       0x00ff00,
	}
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}
