package commands

import (
	"fmt"
	"log"
	"os"

	"rankedbw-bot-registration/database"

	"github.com/bwmarrin/discordgo"
)

type UnregisterCommand struct{}

func (c *UnregisterCommand) Data() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        "unregister",
		Description: "Unregister a user",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "user",
				Description: "The user to unregister",
				Required:    true,
			},
		},
	}
}

func (c *UnregisterCommand) Handler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	member, err := s.GuildMember(i.GuildID, i.Member.User.ID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "Failed to check permissions.",
			},
		})
		return
	}
	managerRole := os.Getenv("REGISTRATION_MANAGER")
	if managerRole == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "REGISTRATION_MANAGER role is not set in the environment.",
			},
		})
		return
	}
	hasManagerRole := false
	for _, roleID := range member.Roles {
		if roleID == managerRole {
			hasManagerRole = true
			break
		}
	}
	if !hasManagerRole {
		embed := &discordgo.MessageEmbed{
			Title:       "Missing Permission",
			Description: "You do not have the required permissions to use this command.",
			Color:       0xff0000,
		}
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{embed},
			},
		})
		return
	}

	var userID string
	for _, opt := range i.ApplicationCommandData().Options {
		if opt.Name == "user" {
			userID = opt.UserValue(nil).ID
		}
	}
	if userID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "You must specify a user to unregister.",
			},
		})
		return
	}

	db := database.DB
	_, err = db.Exec(`DELETE FROM discord_register WHERE discord_id = ?`, userID)
	if err != nil {
		log.Printf("Failed to delete registration from DB: %v", err)
	}

	registeredRole := os.Getenv("REGISTERED_ROLE_ID")
	if registeredRole != "" {
		errRole := s.GuildMemberRoleRemove(i.GuildID, userID, registeredRole)
		if errRole != nil {
			log.Printf("Failed to remove role: %v", errRole)
		}
	}

	errNick := s.GuildMemberNickname(i.GuildID, userID, "")
	if errNick != nil {
		log.Printf("Failed to reset nickname: %v", errNick)
	}

	embed := &discordgo.MessageEmbed{
		Title:       "Unregistration Successful!",
		Description: fmt.Sprintf("<@%s> has been unregistered.", userID),
		Color:       0x00ff00,
	}
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}
