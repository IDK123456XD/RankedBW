package commands

import (
	"fmt"
	"log"
	"os"

	"rankedbw-bot-registration/database"

	"github.com/bwmarrin/discordgo"
)

type ForceRegisterCommand struct{}

func (c *ForceRegisterCommand) Data() *discordgo.ApplicationCommand {
	return &discordgo.ApplicationCommand{
		Name:        "force-register",
		Description: "Force register a user",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionUser,
				Name:        "user",
				Description: "The user to register",
				Required:    true,
			},
			{
				Type:        discordgo.ApplicationCommandOptionString,
				Name:        "username",
				Description: "Minecraft username",
				Required:    true,
			},
		},
	}
}

func (c *ForceRegisterCommand) Handler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	member, err := s.GuildMember(i.GuildID, i.Member.User.ID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "Failed to check permissions.",
			},
		})
		return
	}
	managerRole := os.Getenv("REGISTRATION_MANAGER")
	if managerRole == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "REGISTRATION_MANAGER role is not set in the environment.",
			},
		})
		return
	}
	hasManagerRole := false
	for _, roleID := range member.Roles {
		if roleID == managerRole {
			hasManagerRole = true
			break
		}
	}
	if !hasManagerRole {
		embed := &discordgo.MessageEmbed{
			Title:       "Missing Permission",
			Description: "You must have the Registration Manager role to use this command.",
			Color:       0x00ff00,
		}
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{embed},
			},
		})
		return
	}

	var userID, username string
	for _, opt := range i.ApplicationCommandData().Options {
		if opt.Name == "user" {
			userID = opt.UserValue(nil).ID
		}
		if opt.Name == "username" {
			username = opt.StringValue()
		}
	}
	if userID == "" || username == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Content: "You must specify both a user and a Minecraft username.",
			},
		})
		return
	}

	db := database.DB
	_, err = db.Exec(`INSERT INTO discord_register (discord_id, minecraft_username, registered_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE minecraft_username = VALUES(minecraft_username)`, userID, username)
	if err != nil {
		log.Printf("Failed to force register in DB: %v", err)
	}

	registeredRole := os.Getenv("REGISTERED_ROLE_ID")
	if registeredRole != "" {
		s.GuildMemberRoleAdd(i.GuildID, userID, registeredRole)
	}

	newNick := fmt.Sprintf("[0] %s", username)
	errNick := s.GuildMemberNickname(i.GuildID, userID, newNick)
	if errNick != nil {
		log.Printf("Failed to set nickname: %v", errNick)
	}

	embed := &discordgo.MessageEmbed{
		Title:       "Force Registration Successful!",
		Description: fmt.Sprintf("<@%s> is now registered as %s.", userID, username),
		Color:       0x00ff00,
	}
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}
