package database

import (
	"database/sql"
	"fmt"
)

func EnsureDatabaseAndTables(db *sql.DB) error {
	_, err := db.Exec("CREATE DATABASE IF NOT EXISTS rankedbw")
	if err != nil {
		return fmt.Errorf("failed to create database: %w", err)
	}
	_, err = db.Exec("USE rankedbw")
	if err != nil {
		return fmt.Errorf("failed to switch to database: %w", err)
	}
	_, err = db.Exec(`
		CREATE TABLE IF NOT EXISTS discord_register (
			id INT AUTO_INCREMENT PRIMARY KEY,
			discord_id VARCHAR(32) NOT NULL UNIQUE,
			minecraft_username VARCHAR(32) NOT NULL,
			registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
		)
	`)
	if err != nil {
		return fmt.Errorf("failed to create discord_register table: %w", err)
	}
	return nil
}
