package main

import (
	"log"
	"os"

	"rankedbw-bot-registration/commands"

	"github.com/bwmarrin/discordgo"
)

type Command interface {
	Data() *discordgo.ApplicationCommand
	Handler(s *discordgo.Session, i *discordgo.InteractionCreate)
}

func loadCommands() []Command {
	return []Command{
		&commands.RegisterCommand{},
		&commands.UnregisterCommand{},
		&commands.ForceRegisterCommand{},
	}
}

func RegisterCommands(s *discordgo.Session) {
	devGuild := os.Getenv("DEV_GUILD_ID")
	if devGuild == "" {
		log.Fatal("DEV_GUILD_ID not set in .env")
	}
	for _, cmd := range loadCommands() {
		_, err := s.ApplicationCommandCreate(s.State.User.ID, devGuild, cmd.Data())
		if err != nil {
			log.Printf("Cannot create command %s: %v", cmd.Data().Name, err)
		}
		s.AddHandler(func(s *discordgo.Session, i *discordgo.InteractionCreate) {
			if i.ApplicationCommandData().Name == cmd.Data().Name {
				cmd.Handler(s, i)
			}
		})
	}
}

func RegisterCommandsGlobal(s *discordgo.Session) {
	for _, cmd := range loadCommands() {
		_, err := s.ApplicationCommandCreate(s.State.User.ID, "", cmd.Data())
		if err != nil {
			log.Printf("Cannot create global command %s: %v", cmd.Data().Name, err)
		}
	}
}
