export default {
    tokens: [
        'MTQzOTcyNjgyNTY0MjI2MjYxMA.GJtYAa._mQlstCZWpgt5HaoDNtFKTaDJjsl409R5WLhzE',
        'MTQzOTcyNzgwODMwMDcxMjE2OA.GF-hyT.XSPT3AAXwkdvTxtWmV2wo1kDObZwjPwSmFGc2g',
        'MTQzOTcyODE2NjU1NzA2MTI4MQ.GWRq5d.Ajxk57C63VkrFoA3vDKqk2ZYFKGa1L9N8qoRv8',
        'MTQzOTcyODU0OTQ4ODYyMzY1OA.G1ebL0.PPE1uwLYRKjZYWQmZ8ZejHX5ma3wg5k3gxFPZ4',
        'MTQzOTcyODgzMjU2MjIwNDc5Mw.G3TXg6.RVXh346fv-ZooJS80xO7iXwxWow2zI9tmsvJJ4',
        'MTQzOTcyOTE3MjY3NDExNzczMg.GtaeBu.sKx9IJs0qDO0pWU63DArxTUHDhfick68ZpJthw',
        'MTQzOTcyOTUyMzc2NjU5MTQ5OA.GLav_Z.VeOF3mtaJIMY2LNRRxzUnpDJIR_aQV_ieynQ7s',
        'MTQzOTcyOTk5NDA1NzEyNTg5OA.God4Fx.3X2yhlbHTvOHoDln1Ldj7F3pQTeZGKPWkDcM_g'
    ]
}