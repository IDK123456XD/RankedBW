import { Client, GatewayIntentBits, Collection, DiscordAPIError } from 'discord.js';
import Redis from 'ioredis';
import settings from './settings';
import dotenv from 'dotenv';

dotenv.config();

interface MoveRequest {
  memberId: string;
  channelId: string;
  guildId: string;
}

interface RoleRequest {
  memberId: string;
  roleId: string;
  guildId: string;
  action: 'add' | 'remove';
}

interface NicknameRequest {
  memberId: string;
  guildId: string;
  nickname: string | null;
}

interface BotInstance {
  client: Client;
  token: string;
  isReady: boolean;
  cooldownUntil: number; // Timestamp when the bot will be available again
}

class BedwarsWorker {
  private redis: Redis;
  private bots: Collection<string, BotInstance>;
  private lastUsedBotIndex: number = -1; // Track which bot was used last for round-robin

  constructor() {
    this.redis = new Redis({
      host: process.env.REDIS_HOST,
      port: parseInt(process.env.REDIS_PORT),
      password: process.env.REDIS_PASSWORD,
      username: process.env.REDIS_USERNAME,
      maxRetriesPerRequest: 3,
    });

    this.bots = new Collection();
    this.initializeBots();
    this.setupRedisSubscription();
  }

  private async initializeBots(): Promise<void> {
    console.log('🤖 Initializing Discord bots...');

    for (let i = 0; i < settings.tokens.length; i++) {
      const token = settings.tokens[i];
      const client = new Client({
        intents: [
          GatewayIntentBits.Guilds,
          GatewayIntentBits.GuildMembers,
          GatewayIntentBits.GuildVoiceStates
        ]
      });

      const botInstance: BotInstance = {
        client,
        token,
        isReady: false,
        cooldownUntil: 0
      };

      client.once('ready', () => {
        botInstance.isReady = true;
        console.log(`✅ Bot ${i + 1} logged in as ${client.user?.tag}`);
      });

      client.on('error', (error: Error) => {
        console.error(`❌ Bot ${i + 1} encountered an error:`, error);
      });

      try {
        await client.login(token);
        this.bots.set(token, botInstance);
        console.log(`🔑 Bot ${i + 1} attempting to login...`);
      } catch (error) {
        console.error(`❌ Failed to login bot ${i + 1}:`, error);
      }
    }
  }

  private setupRedisSubscription(): void {
    console.log('🔴 Setting up Redis subscriptions...');

    // Subscribe to all required channels
    this.redis.subscribe('queue:move', 'change:role', 'change:nickname', (err: Error | null, count: number) => {
      if (err) {
        console.error('❌ Redis subscription error:', err);
        return;
      }
      console.log(`✅ Subscribed to ${count} channels`);
    });

    this.redis.on('message', async (channel: string, message: string) => {
      try {
        switch (channel) {
          case 'queue:move':
            const moveRequest: MoveRequest = JSON.parse(message);
            await this.handleMoveRequest(moveRequest, 0);
            break;

          case 'change:role':
            const roleRequest: RoleRequest = JSON.parse(message);
            await this.handleRoleRequest(roleRequest, 0);
            break;

          case 'change:nickname':
            const nicknameRequest: NicknameRequest = JSON.parse(message);
            await this.handleNicknameRequest(nicknameRequest, 0);
            break;

          default:
            console.log(`⚠️ Received message on unknown channel: ${channel}`);
        }
      } catch (error) {
        console.error(`❌ Error parsing request on channel ${channel}:`, error);
      }
    });

    this.redis.on('error', (error: Error) => {
      console.error('❌ Redis connection error:', error);
    });

    this.redis.on('connect', () => {
      console.log('✅ Connected to Redis');
    });
  }

  private getAvailableBot(): BotInstance | null {
    const now = Date.now();
    const availableBots = this.bots.filter(bot => bot.isReady && bot.cooldownUntil <= now);

    if (availableBots.size === 0) {
      console.log('⚠️  No available bots right now (all on cooldown or not ready)');
      return null;
    }

    // Convert to array for easier indexing
    const availableBotsArray = Array.from(availableBots.values());
    
    // Round-robin selection: move to next bot in sequence
    this.lastUsedBotIndex = (this.lastUsedBotIndex + 1) % availableBotsArray.length;
    const selectedBot = availableBotsArray[this.lastUsedBotIndex];
    
    console.log(`🤖 Using bot ${this.lastUsedBotIndex + 1}/${availableBotsArray.length}: ${selectedBot.client.user?.tag || 'Unknown'}`);
    
    return selectedBot;
  }

  private handleRateLimit(bot: BotInstance, error: DiscordAPIError): void {
    // Try to get retry after from various possible locations
    const retryAfter = (error as any).retryAfter ||
      (error as any).retry_after ||
      ((error as any).requestData?.retryAfter) ||
      1; // Default to 1 second

    const cooldownMs = Math.ceil(retryAfter * 1000); // Convert to milliseconds and round up
    bot.cooldownUntil = Date.now() + cooldownMs;

    console.log(`⏰ Bot ${bot.client.user?.tag} hit rate limit, cooling down for ${retryAfter}s`);
    console.log(`   Rate limit error details:`, error.message);
  }

  private async handleMoveRequest(request: MoveRequest, retryCount: number = 0): Promise<void> {
    const { memberId, channelId, guildId } = request;
    const maxRetries = 10; // Maximum number of retries

    console.log(`🎯 Processing move request: Member ${memberId} to Channel ${channelId} in Guild ${guildId}${retryCount > 0 ? ` (Retry ${retryCount})` : ''}`);

    const availableBot = this.getAvailableBot();
    if (!availableBot) {
      if (retryCount < maxRetries) {
        console.log(`⚠️  No available bots right now, retrying in 1 second... (Attempt ${retryCount + 1}/${maxRetries + 1})`);
        setTimeout(() => {
          this.handleMoveRequest(request, retryCount + 1);
        }, 1000);
        return;
      } else {
        console.log(`❌ No available bots to handle the request after ${maxRetries} retries`);
        return;
      }
    }

    try {
      const guild = await availableBot.client.guilds.fetch(guildId);
      if (!guild) {
        console.error(`❌ Guild ${guildId} not found`);
        return;
      }

      const member = await guild.members.fetch(memberId);
      if (!member) {
        console.error(`❌ Member ${memberId} not found in guild ${guildId}`);
        return;
      }

      const targetChannel = await guild.channels.fetch(channelId);
      if (!targetChannel || !targetChannel.isVoiceBased()) {
        console.error(`❌ Voice channel ${channelId} not found or invalid`);
        return;
      }

      // Check if member is in a voice channel
      if (!member.voice.channel) {
        console.log(`⚠️  Member ${member.user.tag} is not in a voice channel`);
        return;
      }

      // Move the member
      await member.voice.setChannel(targetChannel);
      console.log(`✅ Successfully moved ${member.user.tag} to ${targetChannel.name} using bot ${availableBot.client.user?.tag}`);
    } catch (error) {
      console.log("Received move request error", error);

      if (error instanceof DiscordAPIError && error.status === 429) {
        console.log("Rate limit hit", error.status);

        this.handleRateLimit(availableBot, error);
        // Retry the request
        setTimeout(() => {
          this.handleMoveRequest(request, retryCount + 1);
        }, 500);
        return;
      }
      console.error('❌ Error moving member:', error);
    }
  }

  private async handleRoleRequest(request: RoleRequest, retryCount: number = 0): Promise<void> {
    const { memberId, roleId, guildId, action } = request;
    const maxRetries = 10; // Maximum number of retries

    console.log(`🎯 Processing role request: ${action} role ${roleId} ${action === 'add' ? 'to' : 'from'} member ${memberId} in Guild ${guildId}${retryCount > 0 ? ` (Retry ${retryCount})` : ''}`);

    const availableBot = this.getAvailableBot();
    if (!availableBot) {
      if (retryCount < maxRetries) {
        console.log(`⚠️  No available bots right now, retrying in 1 second... (Attempt ${retryCount + 1}/${maxRetries + 1})`);
        setTimeout(() => {
          this.handleRoleRequest(request, retryCount + 1);
        }, 1000);
        return;
      } else {
        console.log(`❌ No available bots to handle the request after ${maxRetries} retries`);
        return;
      }
    }

    try {
      const guild = await availableBot.client.guilds.fetch(guildId);
      if (!guild) {
        console.error(`❌ Guild ${guildId} not found`);
        return;
      }

      const member = await guild.members.fetch(memberId);
      if (!member) {
        console.error(`❌ Member ${memberId} not found in guild ${guildId}`);
        return;
      }

      const role = await guild.roles.fetch(roleId);
      if (!role) {
        console.error(`❌ Role ${roleId} not found in guild ${guildId}`);
        return;
      }

      // Add or remove the role
      if (action === 'add') {
        await member.roles.add(role);
        console.log(`✅ Successfully added role ${role.name} to ${member.user.tag} using bot ${availableBot.client.user?.tag}`);
      } else {
        await member.roles.remove(role);
        console.log(`✅ Successfully removed role ${role.name} from ${member.user.tag} using bot ${availableBot.client.user?.tag}`);
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.status === 429) {
        this.handleRateLimit(availableBot, error);
        // Retry the request
        setTimeout(() => {
          this.handleRoleRequest(request, retryCount + 1);
        }, 500);
        return;
      }
      console.error(`❌ Error ${action === 'add' ? 'adding' : 'removing'} role:`, error);
    }
  }

  private async handleNicknameRequest(request: NicknameRequest, retryCount: number = 0): Promise<void> {
    const { memberId, guildId, nickname } = request;
    const maxRetries = 10; // Maximum number of retries

    console.log(`🎯 Processing nickname request: Set nickname for member ${memberId} to "${nickname || 'reset'}" in Guild ${guildId}${retryCount > 0 ? ` (Retry ${retryCount})` : ''}`);

    const availableBot = this.getAvailableBot();
    if (!availableBot) {
      if (retryCount < maxRetries) {
        console.log(`⚠️  No available bots right now, retrying in 1 second... (Attempt ${retryCount + 1}/${maxRetries + 1})`);
        setTimeout(() => {
          this.handleNicknameRequest(request, retryCount + 1);
        }, 1000);
        return;
      } else {
        console.log(`❌ No available bots to handle the request after ${maxRetries} retries`);
        return;
      }
    }

    try {
      const guild = await availableBot.client.guilds.fetch(guildId);
      if (!guild) {
        console.error(`❌ Guild ${guildId} not found`);
        return;
      }

      const member = await guild.members.fetch(memberId);
      if (!member) {
        console.error(`❌ Member ${memberId} not found in guild ${guildId}`);
        return;
      }

      // Set the nickname (null will reset to default)
      await member.setNickname(nickname?.slice(0, 32) || null);
      console.log(`✅ Successfully ${nickname ? 'set' : 'reset'} nickname for ${member.user.tag} to "${nickname || member.user.username}" using bot ${availableBot.client.user?.tag}`);
    } catch (error) {
      if (error instanceof DiscordAPIError && error.status === 429) {
        this.handleRateLimit(availableBot, error);
        // Retry the request
        setTimeout(() => {
          this.handleNicknameRequest(request, retryCount + 1);
        }, 500);
        return;
      }
      console.error('❌ Error setting nickname:', error);
    }
  }

  public async shutdown(): Promise<void> {
    console.log('🛑 Shutting down BedwarsWorker...');

    // Disconnect from Redis
    this.redis.disconnect();

    // Logout all bots
    for (const botInstance of this.bots.values()) {
      await botInstance.client.destroy();
    }

    console.log('✅ Shutdown complete');
  }
}

// Initialize the worker
const worker = new BedwarsWorker();

// Graceful shutdown
process.on('SIGINT', async () => {
  await worker.shutdown();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await worker.shutdown();
  process.exit(0);
});

export default worker;
