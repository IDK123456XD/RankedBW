// Import Prisma client from the common directory
export { prisma } from '../common/src/database/connectors/prisma';
export type * from '../common/src/database/generated';

