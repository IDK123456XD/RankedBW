/**
 * Authentication Manager for Tebex Discord OAuth
 * Handles storing and retrieving Discord auth tokens
 */

const AUTH_TOKEN_KEY = 'tebex_discord_auth_token';
const AUTH_EXPIRY_KEY = 'tebex_discord_auth_expiry';
const AUTH_USER_KEY = 'tebex_discord_user';

export interface AuthUser {
  id: string;
  username: string;
  discriminator?: string;
  avatar?: string;
}

export class AuthManager {
  /**
   * Check if user is authenticated
   */
  static isAuthenticated(): boolean {
    if (typeof window === 'undefined') return false;
    
    const token = localStorage.getItem(AUTH_TOKEN_KEY);
    const expiry = localStorage.getItem(AUTH_EXPIRY_KEY);
    
    if (!token || !expiry) {
      return false;
    }
    
    // Check if token is expired
    const expiryTime = parseInt(expiry, 10);
    if (Date.now() > expiryTime) {
      this.clearAuth();
      return false;
    }
    
    return true;
  }

  /**
   * Store authentication token and user info
   */
  static setAuth(token: string, user?: AuthUser, expiresIn: number = 24 * 60 * 60 * 1000) {
    if (typeof window === 'undefined') return;
    
    const expiryTime = Date.now() + expiresIn;
    
    localStorage.setItem(AUTH_TOKEN_KEY, token);
    localStorage.setItem(AUTH_EXPIRY_KEY, expiryTime.toString());
    
    if (user) {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
    }
  }

  /**
   * Get authentication token
   */
  static getToken(): string | null {
    if (typeof window === 'undefined') return null;
    
    if (!this.isAuthenticated()) {
      return null;
    }
    
    return localStorage.getItem(AUTH_TOKEN_KEY);
  }

  /**
   * Get authenticated user info
   */
  static getUser(): AuthUser | null {
    if (typeof window === 'undefined') return null;
    
    if (!this.isAuthenticated()) {
      return null;
    }
    
    const userJson = localStorage.getItem(AUTH_USER_KEY);
    if (!userJson) return null;
    
    try {
      return JSON.parse(userJson);
    } catch {
      return null;
    }
  }

  /**
   * Clear authentication
   */
  static clearAuth() {
    if (typeof window === 'undefined') return;
    
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(AUTH_EXPIRY_KEY);
    localStorage.removeItem(AUTH_USER_KEY);
  }

  /**
   * Parse authentication from URL parameters (after OAuth callback)
   * Tebex returns: signature, discord_id, discord_tag
   */
  static parseAuthFromUrl(): { token: string; user?: AuthUser } | null {
    if (typeof window === 'undefined') return null;
    
    const params = new URLSearchParams(window.location.search);
    
    // Tebex Discord OAuth returns 'signature' as the auth token
    const signature = params.get('signature');
    const discordId = params.get('discord_id');
    const discordTag = params.get('discord_tag');
    
    if (!signature) return null;
    
    // Parse Discord user info if available
    let user: AuthUser | undefined;
    if (discordId && discordTag) {
      // Discord tag format: username#discriminator or just username
      const decodedTag = decodeURIComponent(discordTag);
      const [username, discriminator] = decodedTag.includes('#') 
        ? decodedTag.split('#')
        : [decodedTag, undefined];
      
      user = {
        id: discordId,
        username: username,
        discriminator: discriminator,
      };
    }
    
    return { token: signature, user };
  }
}

export const authManager = AuthManager;

