"use client";

import { motion } from "framer-motion";
import { ArrowLeft, Trophy, Medal, Gamepad2, Target, Flame, Award, User, Loader2, AlertCircle, Crown, Users, Swords, Map, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import Image from "next/image";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { getEloColor, getEloRankName, getEloRank } from "@/lib/elo-ranks";

interface RecentGame {
  id: string;
  gameId: string;
  mapPlaying: string | null;
  createdAt: string;
  won: boolean;
  mvp: boolean;
  eloDiff: number;
  teammates: {
    minecraftName: string;
    userId: string;
  }[];
  opponents: {
    minecraftName: string;
    userId: string;
  }[];
}

interface PlayerProfile {
  player: {
    id: string;
    userId: string;
    minecraftName: string;
    nickname: string | null;
    winStreak: number;
  };
  statistics: {
    elo: number;
    wins: number;
    mvps: number;
    gamesPlayed: number;
    losses: number;
    peakElo: number;
  };
  leaderboardRank: number;
  recentGames: RecentGame[];
}

export default function PlayerProfilePage({ params }: { params: Promise<{ name: string }> }) {
  const router = useRouter();
  const [profile, setProfile] = useState<PlayerProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [playerName, setPlayerName] = useState<string>('');

  useEffect(() => {
    const fetchProfile = async () => {
      setIsLoading(true);
      setError(null);

      try {
        const resolvedParams = await params;
        const name = resolvedParams.name;
        setPlayerName(name);
        
        const response = await fetch(`/api/stats/player/${name}`);
        const data = await response.json();

        if (data.success && data.data) {
          setProfile(data.data);
        } else {
          setError(data.error || 'Player not found');
        }
      } catch (err) {
        console.error('Error fetching player profile:', err);
        setError('Failed to load player profile');
      } finally {
        setIsLoading(false);
      }
    };

    fetchProfile();
  }, [params]);

  const copyDiscordId = (id: string) => {
    navigator.clipboard.writeText(id);
    alert('Discord ID copied: ' + id);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen py-24 relative">
        <div className="starfield" />
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex items-center justify-center min-h-[60vh]">
            <Loader2 className="w-12 h-12 animate-spin text-primary" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen py-24 relative">
        <div className="starfield" />
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-2xl mx-auto">
            <Button variant="ghost" asChild className="mb-8">
              <Link href="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Leaderboards
              </Link>
            </Button>

            <Card className="border-2 border-red-500/30">
              <CardContent className="p-12 text-center">
                <AlertCircle className="w-16 h-16 mx-auto mb-4 text-red-500" />
                <h2 className="text-3xl font-bold mb-2">Player Not Found</h2>
                <p className="text-foreground/70 mb-6">
                  {error || `The player "${playerName}" could not be found.`}
                </p>
                <Button asChild>
                  <Link href="/">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Leaderboards
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-24 relative">
      <div className="starfield" />
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Back Button */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-8"
        >
          <Button variant="ghost" asChild>
            <Link href="/">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Leaderboards
            </Link>
          </Button>
        </motion.div>

        <div className="max-w-6xl mx-auto">
          {/* Profile Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <Card className="border-2 border-primary/30 overflow-hidden">
              <CardContent className="p-8">
                <div className="flex items-center gap-8">
                  {/* Player Avatar */}
                  <div className="relative flex-shrink-0">
                    <div className="w-32 h-32 rounded-2xl overflow-hidden bg-gradient-to-br from-primary/20 to-purple-500/20 p-2">
                      <Image
                        src={`https://starlightskins.lunareclipse.studio/render/ultimate/${profile.player.minecraftName}/full`}
                        alt={profile.player.minecraftName}
                        width={128}
                        height={256}
                        className="object-contain w-full h-full"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = `https://mc-heads.net/avatar/${profile.player.minecraftName}/128`;
                        }}
                      />
                    </div>
                  </div>

                  {/* Player Info - Left Side */}
                  <div className="flex-1">
                    <h1 className="text-4xl md:text-5xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
                      {profile.player.minecraftName}
                    </h1>
                    <div className="flex items-center gap-3 mt-3">
                      <div className="flex items-center gap-2 px-3 py-2 bg-blue-500/10 rounded-lg border border-blue-500/20">
                        <Trophy className="w-4 h-4 text-blue-400" />
                        <span className="text-sm font-medium">#{profile.leaderboardRank.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* ELO - Right Side */}
                  <div className="flex-shrink-0">
                    <div className="flex items-center gap-4 px-6 py-4 rounded-xl border-2" style={{ 
                      borderColor: `${getEloColor(profile.statistics.elo)}40`,
                      backgroundColor: `${getEloColor(profile.statistics.elo)}10`
                    }}>
                      {/* Rank Icon */}
                      <div className="w-16 h-16 flex items-center justify-center flex-shrink-0">
                        <Image
                          src={`/images/ranks/${getEloRankName(profile.statistics.elo).toLowerCase()} rank.png`}
                          alt={getEloRankName(profile.statistics.elo)}
                          width={64}
                          height={64}
                          className="drop-shadow-lg"
                        />
                      </div>
                      
                      {/* ELO Number and Rank Name */}
                      <div className="flex flex-col">
                        <span className="text-4xl font-bold leading-none" style={{ color: getEloColor(profile.statistics.elo) }}>
                          {profile.statistics.elo}
                        </span>
                        <span className="text-sm font-bold uppercase tracking-wider mt-1" style={{ color: getEloColor(profile.statistics.elo) }}>
                          {getEloRankName(profile.statistics.elo)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Statistics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Card className="border-2 border-green-500/30 bg-gradient-to-br from-green-500/5 to-transparent">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-400">
                    <Trophy className="w-6 h-6" />
                    Wins
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-foreground">
                    {profile.statistics.wins.toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
            >
              <Card className="border-2 border-yellow-500/30 bg-gradient-to-br from-yellow-500/5 to-transparent">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-yellow-400">
                    <Medal className="w-6 h-6" />
                    MVPs
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-foreground">
                    {profile.statistics.mvps.toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="border-2 border-blue-500/30 bg-gradient-to-br from-blue-500/5 to-transparent">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-400">
                    <Gamepad2 className="w-6 h-6" />
                    Games Played
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-foreground">
                    {profile.statistics.gamesPlayed.toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.25 }}
            >
              <Card className="border-2 border-red-500/30 bg-gradient-to-br from-red-500/5 to-transparent">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-400">
                    <Target className="w-6 h-6" />
                    Losses
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-foreground">
                    {profile.statistics.losses.toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Card className="border-2 border-orange-500/30 bg-gradient-to-br from-orange-500/5 to-transparent">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-orange-400">
                    <Flame className="w-6 h-6" />
                    Win Streak
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-foreground">
                    {profile.player.winStreak.toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
            >
              <Card className="border-2 border-purple-500/30 bg-gradient-to-br from-purple-500/5 to-transparent">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-purple-400">
                    <Award className="w-6 h-6" />
                    Peak ELO
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold" style={{ color: getEloColor(profile.statistics.peakElo) }}>
                    {profile.statistics.peakElo.toLocaleString()}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Recent Games Section */}
          {profile.recentGames && profile.recentGames.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="mt-8"
            >
              <Card className="border-2 border-cyan-500/30 bg-gradient-to-br from-cyan-500/5 to-transparent">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-cyan-400 text-2xl">
                    <Gamepad2 className="w-7 h-7" />
                    Recent Games
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {profile.recentGames.map((game, index) => (
                      <Link key={game.id} href={`/game/${game.gameId}`} className="block">
                        <motion.div
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all hover:scale-[1.02] ${
                            game.won
                              ? 'border-green-500/30 bg-gradient-to-r from-green-500/10 to-transparent hover:border-green-500/50'
                              : 'border-red-500/30 bg-gradient-to-r from-red-500/10 to-transparent hover:border-red-500/50'
                          }`}
                        >
                        {/* Game Header */}
                        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                          <div className="flex items-center gap-3">
                            {game.mvp && (
                              <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-yellow-500/20 text-yellow-400 font-semibold">
                                <Crown className="w-4 h-4" />
                                MVP
                              </div>
                            )}
                            <div className={`flex items-center gap-1 px-3 py-1 rounded-full font-semibold ${
                              game.eloDiff >= 0
                                ? 'bg-green-500/20 text-green-400'
                                : 'bg-red-500/20 text-red-400'
                            }`}>
                              {game.eloDiff >= 0 ? '+' : ''}{game.eloDiff} ELO
                            </div>
                          </div>
                          <div className="flex items-center gap-3 text-sm text-foreground/60">
                            {game.mapPlaying && (
                              <div className="flex items-center gap-1">
                                <Map className="w-4 h-4" />
                                {game.mapPlaying}
                              </div>
                            )}
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {new Date(game.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>

                        {/* Teams */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                          {/* Teammates */}
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm font-semibold text-blue-400">
                              <Users className="w-4 h-4" />
                              Teammates
                            </div>
                            <div className="space-y-1">
                              {game.teammates.map((teammate) => (
                                <div
                                  key={teammate.userId}
                                  onClick={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    router.push(`/player/${teammate.minecraftName}`);
                                  }}
                                  className="flex items-center gap-2 p-2 rounded bg-blue-500/10 hover:bg-blue-500/20 transition-colors cursor-pointer"
                                >
                                  <Image
                                    src={`https://mc-heads.net/avatar/${teammate.minecraftName}/24`}
                                    alt={teammate.minecraftName}
                                    width={24}
                                    height={24}
                                    className="rounded"
                                  />
                                  <span className="text-sm">{teammate.minecraftName}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Opponents */}
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm font-semibold text-red-400">
                              <Swords className="w-4 h-4" />
                              Opponents
                            </div>
                            <div className="space-y-1">
                              {game.opponents.map((opponent) => (
                                <div
                                  key={opponent.userId}
                                  onClick={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    router.push(`/player/${opponent.minecraftName}`);
                                  }}
                                  className="flex items-center gap-2 p-2 rounded bg-red-500/10 hover:bg-red-500/20 transition-colors cursor-pointer"
                                >
                                  <Image
                                    src={`https://mc-heads.net/avatar/${opponent.minecraftName}/24`}
                                    alt={opponent.minecraftName}
                                    width={24}
                                    height={24}
                                    className="rounded"
                                  />
                                  <span className="text-sm">{opponent.minecraftName}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                        </motion.div>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}

