"use client";

import StatsPage from "../page";

export default function LeaderboardsPage() {
  return <StatsPage />;
}

