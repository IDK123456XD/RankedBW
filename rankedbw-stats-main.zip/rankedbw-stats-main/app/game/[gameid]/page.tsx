"use client";

import { motion } from "framer-motion";
import {
  ArrowLeft,
  Trophy,
  Crown,
  Map,
  Calendar,
  Clock,
  Shield,
  Swords,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  CheckCircle,
  XCircle,
  Gamepad2,
  Users,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import Image from "next/image";
import { useState, useEffect } from "react";

interface GamePlayerDetail {
  userId: string;
  minecraftName: string;
  preElo: number;
  postElo: number;
  eloDiff: number;
  mvp: boolean;
  win: boolean;
  discordTeam: number;
}

interface GameDetail {
  id: string;
  gameId: string;
  mapPlaying: string | null;
  finished: boolean;
  voided: boolean;
  lossVoided: boolean;
  gameStyle: string;
  createdAt: string;
  updatedAt: string;
  status: string;
  reason: string | null;
  season: {
    id: string;
    name: string;
  } | null;
  team1Players: GamePlayerDetail[];
  team2Players: GamePlayerDetail[];
  winningTeam: number | null;
}

export default function GameDetailPage({ params }: { params: Promise<{ gameid: string }> }) {
  const [game, setGame] = useState<GameDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchGameDetails = async () => {
      setIsLoading(true);
      setError(null);

      try {
        const resolvedParams = await params;
        const gameId = resolvedParams.gameid;
        
        const response = await fetch(`/api/stats/game/${gameId}`);
        const data = await response.json();

        if (data.success) {
          setGame(data.data);
        } else {
          setError(data.error || "Failed to fetch game details");
        }
      } catch (err) {
        console.error("Error fetching game details:", err);
        setError("Failed to load game details");
      } finally {
        setIsLoading(false);
      }
    };

    fetchGameDetails();
  }, [params]);

  if (isLoading) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-blue-500 mx-auto mb-4" />
          <p className="text-foreground/60">Loading game details...</p>
        </div>
      </div>
    );
  }

  if (error || !game) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-6">
            <div className="text-center">
              <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2">Game Not Found</h2>
              <p className="text-foreground/60 mb-4">
                {error || "The game you're looking for doesn't exist."}
              </p>
              <Link href="/">
                <Button>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Stats
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const gameDate = new Date(game.createdAt);
  const isTeam1Winner = game.winningTeam === 1;
  const isTeam2Winner = game.winningTeam === 2;

  const getStatusBadge = () => {
    if (game.voided) {
      return (
        <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-500/20 text-red-400 font-semibold">
          <XCircle className="w-5 h-5" />
          VOIDED
        </div>
      );
    }
    if (game.lossVoided) {
      return (
        <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-yellow-500/20 text-yellow-400 font-semibold">
          <AlertCircle className="w-5 h-5" />
          LOSS VOIDED
        </div>
      );
    }
    if (game.status === "SCORED") {
      return (
        <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-green-500/20 text-green-400 font-semibold">
          <CheckCircle className="w-5 h-5" />
          COMPLETED
        </div>
      );
    }
    return (
      <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-500/20 text-blue-400 font-semibold">
        <Clock className="w-5 h-5" />
        {game.status}
      </div>
    );
  };

  return (
    <div className="min-h-screen py-24 relative">
      <div className="starfield" />
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Back Button */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-8"
        >
          <Button variant="ghost" asChild>
            <Link href="/">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Stats
            </Link>
          </Button>
        </motion.div>

        <div className="max-w-6xl mx-auto">
          {/* Game Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <Card className="border-2 border-primary/30 overflow-hidden">
              <CardContent className="p-8">
              <div className="space-y-4">
                {/* Title and Status */}
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-3">
                    <Gamepad2 className="w-8 h-8 text-cyan-400" />
                    <div>
                      <h1 className="text-3xl font-bold">Game {game.gameId}</h1>
                    </div>
                  </div>
                  {getStatusBadge()}
                </div>

                {/* Game Info */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-4">
                  {game.mapPlaying && (
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-purple-500/10">
                      <Map className="w-5 h-5 text-purple-400" />
                      <div>
                        <p className="text-xs text-foreground/60">Map</p>
                        <p className="font-semibold">{game.mapPlaying}</p>
                      </div>
                    </div>
                  )}
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-blue-500/10">
                    <Calendar className="w-5 h-5 text-blue-400" />
                    <div>
                      <p className="text-xs text-foreground/60">Date</p>
                      <p className="font-semibold">{gameDate.toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-green-500/10">
                    <Shield className="w-5 h-5 text-green-400" />
                    <div>
                      <p className="text-xs text-foreground/60">Game Style</p>
                      <p className="font-semibold">{game.gameStyle}</p>
                    </div>
                  </div>
                  {game.season && (
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-orange-500/10">
                      <Trophy className="w-5 h-5 text-orange-400" />
                      <div>
                        <p className="text-xs text-foreground/60">Season</p>
                        <p className="font-semibold">{game.season.name}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Void Reason */}
                {(game.voided || game.lossVoided) && game.reason && (
                  <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/30">
                    <p className="text-sm">
                      <span className="font-semibold text-red-400">Reason: </span>
                      {game.reason}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Teams Display */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Team 1 */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card
              className={`border-2 ${
                isTeam1Winner
                  ? "border-green-500/50 bg-gradient-to-br from-green-500/10 to-transparent"
                  : "border-red-500/30 bg-gradient-to-br from-red-500/5 to-transparent"
              }`}
            >
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Shield className={`w-6 h-6 ${isTeam1Winner ? "text-green-400" : "text-red-400"}`} />
                    <span>Team 1</span>
                  </div>
                  {isTeam1Winner && (
                    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/20 text-green-400 font-semibold text-sm">
                      <Trophy className="w-4 h-4" />
                      VICTORY
                    </div>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {game.team1Players.map((player) => (
                    <Link
                      key={player.userId}
                      href={`/player/${player.minecraftName}`}
                      className="block"
                    >
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          player.mvp
                            ? "border-yellow-500/40 bg-gradient-to-r from-yellow-500/10 to-transparent"
                            : "border-foreground/10 hover:border-foreground/20 bg-background/50"
                        }`}
                      >
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-3 min-w-0">
                            <Image
                              src={`https://mc-heads.net/avatar/${player.minecraftName}/40`}
                              alt={player.minecraftName}
                              width={40}
                              height={40}
                              className="rounded"
                            />
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <p className="font-semibold truncate">{player.minecraftName}</p>
                                {player.mvp && <Crown className="w-4 h-4 text-yellow-400 flex-shrink-0" />}
                              </div>
                              <div className="flex items-center gap-2 text-sm text-foreground/60">
                                <span>{player.preElo} → {player.postElo}</span>
                              </div>
                            </div>
                          </div>
                          <div className={`flex items-center gap-1 px-3 py-1 rounded-full font-bold whitespace-nowrap ${
                            player.eloDiff >= 0
                              ? "bg-green-500/20 text-green-400"
                              : "bg-red-500/20 text-red-400"
                          }`}>
                            {player.eloDiff >= 0 ? (
                              <TrendingUp className="w-4 h-4" />
                            ) : (
                              <TrendingDown className="w-4 h-4" />
                            )}
                            {player.eloDiff >= 0 ? "+" : ""}{player.eloDiff}
                          </div>
                        </div>
                      </motion.div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Team 2 */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card
              className={`border-2 ${
                isTeam2Winner
                  ? "border-green-500/50 bg-gradient-to-br from-green-500/10 to-transparent"
                  : "border-red-500/30 bg-gradient-to-br from-red-500/5 to-transparent"
              }`}
            >
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Swords className={`w-6 h-6 ${isTeam2Winner ? "text-green-400" : "text-red-400"}`} />
                    <span>Team 2</span>
                  </div>
                  {isTeam2Winner && (
                    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/20 text-green-400 font-semibold text-sm">
                      <Trophy className="w-4 h-4" />
                      VICTORY
                    </div>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {game.team2Players.map((player) => (
                    <Link
                      key={player.userId}
                      href={`/player/${player.minecraftName}`}
                      className="block"
                    >
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          player.mvp
                            ? "border-yellow-500/40 bg-gradient-to-r from-yellow-500/10 to-transparent"
                            : "border-foreground/10 hover:border-foreground/20 bg-background/50"
                        }`}
                      >
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-3 min-w-0">
                            <Image
                              src={`https://mc-heads.net/avatar/${player.minecraftName}/40`}
                              alt={player.minecraftName}
                              width={40}
                              height={40}
                              className="rounded"
                            />
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <p className="font-semibold truncate">{player.minecraftName}</p>
                                {player.mvp && <Crown className="w-4 h-4 text-yellow-400 flex-shrink-0" />}
                              </div>
                              <div className="flex items-center gap-2 text-sm text-foreground/60">
                                <span>{player.preElo} → {player.postElo}</span>
                              </div>
                            </div>
                          </div>
                          <div className={`flex items-center gap-1 px-3 py-1 rounded-full font-bold whitespace-nowrap ${
                            player.eloDiff >= 0
                              ? "bg-green-500/20 text-green-400"
                              : "bg-red-500/20 text-red-400"
                          }`}>
                            {player.eloDiff >= 0 ? (
                              <TrendingUp className="w-4 h-4" />
                            ) : (
                              <TrendingDown className="w-4 h-4" />
                            )}
                            {player.eloDiff >= 0 ? "+" : ""}{player.eloDiff}
                          </div>
                        </div>
                      </motion.div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
        </div>
      </div>
    </div>
  );
}

