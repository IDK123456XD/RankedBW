import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { CartProvider } from "@/lib/cart-context";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  metadataBase: new URL("https://stats.rankedbw.net"),
  title: "Ranked Bedwars Stats",
  description: "View player statistics, leaderboards, and game history for Ranked Bedwars",
  keywords: "Minecraft, Bedwars, Stats, Leaderboard, ELO",
  openGraph: {
    title: "Ranked Bedwars Stats",
    description: "View player statistics, leaderboards, and game history for Ranked Bedwars",
    images: ["/images/logo.png"],
    url: "https://stats.rankedbw.net/",
  },
  twitter: {
    card: "summary_large_image",
    title: "Ranked Bedwars Stats",
    description: "View player statistics, leaderboards, and game history for Ranked Bedwars",
    images: ["/images/logo.png"],
  },
  icons: {
    icon: "/images/logo.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#3b82f6",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} gradient-bg`}>
        <CartProvider>
          <Navigation />
          <main className="pt-20">{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  );
}