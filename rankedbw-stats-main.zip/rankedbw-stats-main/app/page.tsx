"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Trophy, Medal, TrendingUp, Gamepad2, Target, Flame, Search, Crown, Award, Loader2, AlertCircle, ArrowLeft, ArrowRight, Map, Calendar, Shield, Swords, Database, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState, useEffect } from "react";
import Image from "next/image";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { getEloColor, getEloRankName } from "@/lib/elo-ranks";

interface LeaderboardEntry {
  rank: number;
  minecraftName: string;
  userId: string;
  value: number;
}

interface RecentGame {
  id: string;
  gameId: string;
  mapPlaying: string | null;
  createdAt: string;
  gameStyle: string;
  status: string;
  team1: {
    minecraftName: string;
    userId: string;
    won: boolean;
  }[];
  team2: {
    minecraftName: string;
    userId: string;
    won: boolean;
  }[];
}

type ViewMode = "leaderboards" | "recent-games";

export default function StatsPage() {
  const router = useRouter();
  const pathname = usePathname();
  
  const getInitialViewMode = (): ViewMode => {
    if (pathname === "/recent-games") return "recent-games";
    return "leaderboards";
  };
  
  const [viewMode, setViewMode] = useState<ViewMode>(getInitialViewMode());
  const [selectedStat, setSelectedStat] = useState("elo");
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Leaderboard state
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardEntry[]>([]);
  const [leaderboardPagination, setLeaderboardPagination] = useState<any>(null);
  const [leaderboardLoading, setLeaderboardLoading] = useState(true);
  const [leaderboardError, setLeaderboardError] = useState<string | null>(null);

  // Recent games state
  const [recentGames, setRecentGames] = useState<RecentGame[]>([]);
  const [recentGamesPagination, setRecentGamesPagination] = useState<any>(null);
  const [recentGamesLoading, setRecentGamesLoading] = useState(false);
  const [recentGamesError, setRecentGamesError] = useState<string | null>(null);

  const statTypes = [
    { id: "elo", name: "ELO Rating", icon: TrendingUp, gradient: "from-blue-500 to-cyan-500" },
    { id: "wins", name: "Wins", icon: Trophy, gradient: "from-green-500 to-emerald-500" },
    { id: "losses", name: "Losses", icon: Target, gradient: "from-red-500 to-orange-500" },
    { id: "winLossRatio", name: "Win/Loss Ratio", icon: BarChart3, gradient: "from-teal-500 to-cyan-500" },
    { id: "mvps", name: "MVPs", icon: Crown, gradient: "from-yellow-500 to-amber-500" },
    { id: "gamesPlayed", name: "Games Played", icon: Gamepad2, gradient: "from-purple-500 to-pink-500" },
    { id: "streak", name: "Win Streak", icon: Flame, gradient: "from-orange-500 to-red-500" },
    { id: "peakElo", name: "Peak ELO", icon: Award, gradient: "from-indigo-500 to-purple-500" },
  ];

  useEffect(() => {
    if (pathname === "/recent-games") {
      setViewMode("recent-games");
    } else if (pathname === "/leaderboards" || pathname === "/") {
      setViewMode("leaderboards");
    }
    setCurrentPage(1);
  }, [pathname]);

  // Fetch leaderboard data
  useEffect(() => {
    if (viewMode === "leaderboards") {
      const fetchLeaderboard = async () => {
        setLeaderboardLoading(true);
        setLeaderboardError(null);

        try {
          const response = await fetch(`/api/stats/leaderboard?type=${selectedStat}&page=${currentPage}`);
          const data = await response.json();

          if (data.success && data.data) {
            setLeaderboardData(data.data.leaderboard);
            setLeaderboardPagination(data.data.pagination);
          } else {
            setLeaderboardError(data.error || 'Failed to load leaderboard');
            setLeaderboardData([]);
          }
        } catch (err) {
          console.error('Error fetching leaderboard:', err);
          setLeaderboardError('Failed to load leaderboard data');
          setLeaderboardData([]);
        } finally {
          setLeaderboardLoading(false);
        }
      };

      fetchLeaderboard();
    }
  }, [selectedStat, currentPage, viewMode]);

  // Fetch recent games data
  useEffect(() => {
    if (viewMode === "recent-games") {
      const fetchRecentGames = async () => {
        setRecentGamesLoading(true);
        setRecentGamesError(null);

        try {
          const response = await fetch(`/api/stats/recent-games?page=${currentPage}`);
          const data = await response.json();

          if (data.success && data.data) {
            setRecentGames(data.data.games);
            setRecentGamesPagination(data.data.pagination);
          } else {
            setRecentGamesError(data.error || 'Failed to load recent games');
            setRecentGames([]);
          }
        } catch (err) {
          console.error('Error fetching recent games:', err);
          setRecentGamesError('Failed to load recent games');
          setRecentGames([]);
        } finally {
          setRecentGamesLoading(false);
        }
      };

      fetchRecentGames();
    }
  }, [currentPage, viewMode]);

  const handleViewModeChange = (mode: ViewMode) => {
    setViewMode(mode);
    setCurrentPage(1);
    if (mode === "leaderboards") {
      router.push("/leaderboards");
    } else {
      router.push("/recent-games");
    }
  };

  const handleStatChange = (statId: string) => {
    setSelectedStat(statId);
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/player/${searchQuery.trim()}`);
    }
  };

  const currentStatType = statTypes.find((st) => st.id === selectedStat);
  const CurrentIcon = currentStatType?.icon || Database;

  return (
    <div className="min-h-screen gradient-bg">
      <div className="container mx-auto px-4 py-12 max-w-7xl">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-4 flex items-center justify-center gap-4">
            <TrendingUp className="w-12 h-12 text-cyan-400" />
            <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
              Statistics
            </span>
          </h1>
          <p className="text-xl text-foreground/60 max-w-2xl mx-auto">
            Track your performance, climb the ranks, and compete for the top spot
          </p>
        </motion.div>

        {/* View Mode Toggle */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="flex justify-center mb-8"
        >
          <div className="inline-flex gap-2 p-2 rounded-lg bg-background/50 border border-foreground/10">
            <Button
              variant={viewMode === "leaderboards" ? "default" : "ghost"}
              onClick={() => handleViewModeChange("leaderboards")}
              className={viewMode === "leaderboards" ? "bg-gradient-to-r from-cyan-500 to-blue-500" : ""}
            >
              <Trophy className="w-4 h-4 mr-2" />
              Leaderboards
            </Button>
            <Button
              variant={viewMode === "recent-games" ? "default" : "ghost"}
              onClick={() => handleViewModeChange("recent-games")}
              className={viewMode === "recent-games" ? "bg-gradient-to-r from-cyan-500 to-blue-500" : ""}
            >
              <Gamepad2 className="w-4 h-4 mr-2" />
              Recent Games
            </Button>
          </div>
        </motion.div>

        {/* Search Player */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex justify-center mb-8"
        >
          <form onSubmit={handleSearch} className="w-full max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-foreground/40 w-5 h-5" />
              <Input
                type="text"
                placeholder="Search for a player..."
                value={searchQuery}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                className="pl-11 bg-background/50 border-foreground/20 h-11"
              />
            </div>
          </form>
        </motion.div>

        {/* Content */}
        <AnimatePresence mode="wait">
          {viewMode === "leaderboards" ? (
            <motion.div
              key="leaderboards"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {leaderboardLoading ? (
                <div className="flex flex-col items-center justify-center py-20">
                  <Loader2 className="w-12 h-12 animate-spin text-cyan-500 mb-4" />
                  <p className="text-foreground/60">Loading leaderboard...</p>
                </div>
              ) : leaderboardError ? (
                <Card className="border-red-500/30">
                  <CardContent className="pt-6">
                    <div className="text-center py-12">
                      <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                      <p className="text-foreground/60">{leaderboardError}</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <>
                  <Card className={`border-2 bg-gradient-to-br ${currentStatType?.gradient ? `from-${currentStatType.gradient.split(' ')[0].split('-')[1]}-500/5` : 'from-cyan-500/5'} to-transparent border-cyan-500/30`}>
                    <CardHeader>
                      <div className="flex items-center justify-between gap-4 flex-wrap">
                        <CardTitle className="flex items-center gap-3 text-2xl">
                          <div className={`p-3 rounded-lg bg-gradient-to-br ${currentStatType?.gradient || 'from-cyan-500 to-blue-500'}`}>
                            <CurrentIcon className="w-6 h-6 text-white" />
                          </div>
                          {currentStatType?.name} Leaderboard
                        </CardTitle>
                        <Select value={selectedStat} onValueChange={handleStatChange}>
                          <SelectTrigger className="w-[200px] bg-background/50 border-foreground/20">
                            <SelectValue placeholder="Select stat type" />
                          </SelectTrigger>
                          <SelectContent>
                            {statTypes.map((stat) => {
                              const Icon = stat.icon;
                              return (
                                <SelectItem key={stat.id} value={stat.id}>
                                  <div className="flex items-center gap-2">
                                    <Icon className="w-4 h-4" />
                                    {stat.name}
                                  </div>
                                </SelectItem>
                              );
                            })}
                          </SelectContent>
                        </Select>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {leaderboardData.map((entry, index) => {
                          const isTop3 = entry.rank <= 3;
                          const rankColor =
                            entry.rank === 1
                              ? "from-yellow-500 to-yellow-600"
                              : entry.rank === 2
                              ? "from-gray-400 to-gray-500"
                              : entry.rank === 3
                              ? "from-orange-500 to-orange-600"
                              : "from-foreground/20 to-foreground/10";

                          return (
                            <motion.div
                              key={entry.userId}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ duration: 0.3, delay: index * 0.03 }}
                            >
                              <Link href={`/player/${entry.minecraftName}`}>
                                <div
                                  className={`group flex items-center justify-between p-4 rounded-xl border-2 transition-all cursor-pointer ${
                                    isTop3
                                      ? "border-yellow-500/40 bg-gradient-to-r from-yellow-500/10 via-transparent to-transparent hover:border-yellow-500/60 hover:from-yellow-500/20"
                                      : "border-foreground/10 hover:border-cyan-500/30 bg-background/30 hover:bg-background/50"
                                  } hover:scale-[1.02] hover:shadow-lg`}
                                >
                                  <div className="flex items-center gap-4">
                                    {/* Rank Badge */}
                                    <div className={`flex items-center justify-center w-14 h-14 rounded-lg bg-gradient-to-br ${rankColor} ${!isTop3 && 'opacity-50'}`}>
                                      {entry.rank === 1 && <Crown className="w-7 h-7 text-white" />}
                                      {entry.rank === 2 && <Medal className="w-7 h-7 text-white" />}
                                      {entry.rank === 3 && <Award className="w-7 h-7 text-white" />}
                                      {entry.rank > 3 && <span className="text-xl font-bold text-white">#{entry.rank}</span>}
                                    </div>

                                    {/* Player Info */}
                                    <div className="relative">
                                      <Image
                                        src={`https://mc-heads.net/avatar/${entry.minecraftName}/48`}
                                        alt={entry.minecraftName}
                                        width={48}
                                        height={48}
                                        className="rounded-lg border-2 border-foreground/10"
                                      />
                                    </div>
                                    <div>
                                      <p className="font-bold text-lg group-hover:text-cyan-400 transition-colors">{entry.minecraftName}</p>
                                    </div>
                                  </div>

                                  {/* Stats Value */}
                                  <div className="text-right">
                                    {selectedStat === 'elo' || selectedStat === 'peakElo' ? (
                                      <>
                                        <p className="text-3xl font-bold" style={{ color: getEloColor(entry.value) }}>
                                          {entry.value.toLocaleString()}
                                        </p>
                                        <p className="text-sm text-foreground/60">{getEloRankName(entry.value)}</p>
                                      </>
                                    ) : selectedStat === 'winLossRatio' ? (
                                      <>
                                        <p className="text-3xl font-bold bg-gradient-to-r from-teal-400 to-cyan-400 bg-clip-text text-transparent">
                                          {entry.value.toFixed(2)}
                                        </p>
                                        <p className="text-sm text-foreground/60">W/L Ratio</p>
                                      </>
                                    ) : (
                                      <>
                                        <p className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                                          {entry.value.toLocaleString()}
                                        </p>
                                        <p className="text-sm text-foreground/60">{currentStatType?.name}</p>
                                      </>
                                    )}
                                  </div>
                                </div>
                              </Link>
                            </motion.div>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Pagination */}
                  {leaderboardPagination && leaderboardPagination.totalPages > 1 && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.5, delay: 0.2 }}
                      className="flex items-center justify-center gap-4 mt-8"
                    >
                      <Button
                        variant="outline"
                        size="lg"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={!leaderboardPagination.hasPrev}
                        className="gap-2"
                      >
                        <ArrowLeft className="w-4 h-4" />
                        Previous
                      </Button>
                      <div className="px-6 py-2 rounded-lg bg-background/50 border border-foreground/20">
                        <span className="font-semibold">
                          Page {leaderboardPagination.currentPage} of {leaderboardPagination.totalPages}
                        </span>
                      </div>
                      <Button
                        variant="outline"
                        size="lg"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={!leaderboardPagination.hasNext}
                        className="gap-2"
                      >
                        Next
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </motion.div>
                  )}
                </>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="recent-games"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {recentGamesLoading ? (
                <div className="flex flex-col items-center justify-center py-20">
                  <Loader2 className="w-12 h-12 animate-spin text-cyan-500 mb-4" />
                  <p className="text-foreground/60">Loading recent games...</p>
                </div>
              ) : recentGamesError ? (
                <Card className="border-red-500/30">
                  <CardContent className="pt-6">
                    <div className="text-center py-12">
                      <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                      <p className="text-foreground/60">{recentGamesError}</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <>
                  <div className="space-y-4">
                    {recentGames.map((game, index) => {
                      const team1Won = game.team1.some((p) => p.won);
                      const team2Won = game.team2.some((p) => p.won);

                      return (
                        <motion.div
                          key={game.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                        >
                          <Link href={`/game/${game.gameId}`}>
                            <Card className="border-2 border-foreground/10 hover:border-cyan-500/30 transition-all hover:scale-[1.01] cursor-pointer bg-background/30 hover:shadow-lg">
                              <CardContent className="pt-6">
                                {/* Game Header */}
                                <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
                                  <div className="flex items-center gap-3">
                                    <div className="p-2 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-500">
                                      <Gamepad2 className="w-5 h-5 text-white" />
                                    </div>
                                    <div>
                                      <p className="font-bold text-lg">Game #{game.gameId}</p>
                                      <p className="text-sm text-foreground/60">Click to view details</p>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-4 text-sm text-foreground/60">
                                    {game.mapPlaying && (
                                      <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-purple-500/10">
                                        <Map className="w-4 h-4" />
                                        {game.mapPlaying}
                                      </div>
                                    )}
                                    <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-blue-500/10">
                                      <Shield className="w-4 h-4" />
                                      {game.gameStyle}
                                    </div>
                                    <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-green-500/10">
                                      <Calendar className="w-4 h-4" />
                                      {new Date(game.createdAt).toLocaleDateString()}
                                    </div>
                                  </div>
                                </div>

                                {/* Teams */}
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  {/* Team 1 */}
                                  <div
                                    className={`p-4 rounded-lg border-2 ${
                                      team1Won
                                        ? "border-green-500/40 bg-gradient-to-br from-green-500/10 to-transparent"
                                        : "border-red-500/30 bg-gradient-to-br from-red-500/5 to-transparent"
                                    }`}
                                  >
                                    <div className="flex items-center justify-between mb-3">
                                      <div className="flex items-center gap-2 font-semibold">
                                        <Shield className="w-5 h-5 text-blue-400" />
                                        Team 1
                                      </div>
                                      {team1Won && (
                                        <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/20 text-green-400 text-xs font-bold">
                                          <Trophy className="w-3 h-3" />
                                          VICTORY
                                        </div>
                                      )}
                                    </div>
                                    <div className="space-y-2">
                                      {game.team1.map((player) => (
                                        <div key={player.userId} className="flex items-center gap-2">
                                          <Image
                                            src={`https://mc-heads.net/avatar/${player.minecraftName}/24`}
                                            alt={player.minecraftName}
                                            width={24}
                                            height={24}
                                            className="rounded"
                                          />
                                          <span className="text-sm font-medium">{player.minecraftName}</span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>

                                  {/* Team 2 */}
                                  <div
                                    className={`p-4 rounded-lg border-2 ${
                                      team2Won
                                        ? "border-green-500/40 bg-gradient-to-br from-green-500/10 to-transparent"
                                        : "border-red-500/30 bg-gradient-to-br from-red-500/5 to-transparent"
                                    }`}
                                  >
                                    <div className="flex items-center justify-between mb-3">
                                      <div className="flex items-center gap-2 font-semibold">
                                        <Swords className="w-5 h-5 text-red-400" />
                                        Team 2
                                      </div>
                                      {team2Won && (
                                        <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-green-500/20 text-green-400 text-xs font-bold">
                                          <Trophy className="w-3 h-3" />
                                          VICTORY
                                        </div>
                                      )}
                                    </div>
                                    <div className="space-y-2">
                                      {game.team2.map((player) => (
                                        <div key={player.userId} className="flex items-center gap-2">
                                          <Image
                                            src={`https://mc-heads.net/avatar/${player.minecraftName}/24`}
                                            alt={player.minecraftName}
                                            width={24}
                                            height={24}
                                            className="rounded"
                                          />
                                          <span className="text-sm font-medium">{player.minecraftName}</span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          </Link>
                        </motion.div>
                      );
                    })}
                  </div>

                  {/* Pagination */}
                  {recentGamesPagination && recentGamesPagination.totalPages > 1 && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.5, delay: 0.2 }}
                      className="flex items-center justify-center gap-4 mt-8"
                    >
                      <Button
                        variant="outline"
                        size="lg"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={!recentGamesPagination.hasPrev}
                        className="gap-2"
                      >
                        <ArrowLeft className="w-4 h-4" />
                        Previous
                      </Button>
                      <div className="px-6 py-2 rounded-lg bg-background/50 border border-foreground/20">
                        <span className="font-semibold">
                          Page {recentGamesPagination.currentPage} of {recentGamesPagination.totalPages}
                        </span>
                      </div>
                      <Button
                        variant="outline"
                        size="lg"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={!recentGamesPagination.hasNext}
                        className="gap-2"
                      >
                        Next
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </motion.div>
                  )}
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
