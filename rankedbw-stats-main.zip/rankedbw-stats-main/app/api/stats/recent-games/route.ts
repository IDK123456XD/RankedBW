import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

interface RecentGameData {
  id: string;
  gameId: string;
  mapPlaying: string | null;
  createdAt: Date;
  gameStyle: string;
  status: string;
  team1: {
    minecraftName: string;
    userId: string;
    won: boolean;
  }[];
  team2: {
    minecraftName: string;
    userId: string;
    won: boolean;
  }[];
}

const DEFAULT_PAGE_SIZE = 20;
const MAX_PAGES = 50;
const MAX_TOTAL_ITEMS = DEFAULT_PAGE_SIZE * MAX_PAGES;

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = DEFAULT_PAGE_SIZE;
    const offset = (page - 1) * limit;

    // Check if page is within bounds
    if (page > MAX_PAGES) {
      return NextResponse.json(
        {
          success: false,
          error: 'Page number exceeds maximum allowed pages',
          code: 'PAGE_OUT_OF_BOUNDS',
        },
        { status: 400 }
      );
    }

    // Get total count of completed games in active season
    const totalCount = await prisma.game.count({
      where: {
        status: 'SCORED',
        voided: false,
        season: {
          active: true,
        },
      },
    });

    const cappedCount = totalCount > MAX_TOTAL_ITEMS ? MAX_TOTAL_ITEMS : totalCount;

    // Fetch recent games
    const games = await prisma.game.findMany({
      where: {
        status: 'SCORED',
        voided: false,
        season: {
          active: true,
        },
      },
      include: {
        players: {
          include: {
            user: {
              select: {
                minecraftName: true,
                userId: true,
              },
            },
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
      take: limit,
      skip: offset,
    });

    const recentGames: RecentGameData[] = games.map((game) => {
      const team1 = game.players
        .filter((p) => p.discordTeam === 1)
        .map((p) => ({
          minecraftName: p.user.minecraftName,
          userId: p.user.userId,
          won: p.win,
        }));

      const team2 = game.players
        .filter((p) => p.discordTeam === 2)
        .map((p) => ({
          minecraftName: p.user.minecraftName,
          userId: p.user.userId,
          won: p.win,
        }));

      return {
        id: game.id,
        gameId: game.gameId,
        mapPlaying: game.mapPlaying,
        createdAt: game.createdAt,
        gameStyle: game.gameStyle,
        status: game.status,
        team1,
        team2,
      };
    });

    const totalPages = Math.min(Math.ceil(totalCount / limit), MAX_PAGES);
    const hasNextPage = page < totalPages;
    const hasPrevPage = page > 1;

    return NextResponse.json({
      success: true,
      data: {
        games: recentGames,
        pagination: {
          currentPage: page,
          totalPages,
          totalCount: cappedCount,
          pageSize: limit,
          hasNext: hasNextPage,
          hasPrev: hasPrevPage,
        },
      },
    });
  } catch (error) {
    console.error('Error fetching recent games:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to fetch recent games',
        code: 'INTERNAL_ERROR',
      },
      { status: 500 }
    );
  }
}

