import { Coin } from "@/common/src/database/generated";
import { Decimal } from "@/common/src/database/generated/runtime/library";

export interface DepositJob {
    userId: string;
    txId: string;
    address: string;
    coin: Coin;
    amount: Decimal;
    event: 'unconfirmed-tx' | 'tx-confirmation';
    confirmations: number;
    blockHeight: number | null;
    seenAt: string;
}