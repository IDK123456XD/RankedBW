import { GameStyles } from "./database/generated";

export default {
    guild: '1020646109992992828',
    season: 1,
    partyDeleteIdleTime: 60 * 60 * 1000,
    voiceChannels: {
        waitingRoom: '1382406523421982741',
        queue1: '1386047850848452870',
        queue2: '1382406529923158177',
        queue3: '1382406533010292766',
        queue4: '1382406525984706591',
    },
    channels: {
        scoring: '1382406637435883591',
        pupsAnnouncements: '1382406585992740904',
        pupsVoting: '1387128063510446080',
        pugsAnnouncements: '1382406577151017010',
        pugsVoting: '1387626001231642724',
        premiumAnnouncements: '1387163345135599656',
        staffAnnouncements: '1197335869498081310',
        register: '1197330268562935818',
        support: '1382406554501906576',
        muteLogs: '1382406638744633394',
        punishmentLogs: '1382406638744633394',
        botStatus: '1197329340204064828',
        bounties: '1197329141545058405',
        gameChannelLogs: '1197330074408587429',
        botLogs: '1387971109214879836',
        gameLogs: '1197321221600190554',
        howToRegister: '1384970473875570768',
        pitAnnouncements: '1383919870026059827',
        games: '1393395893423702057',
        premiumLogs: '1387163574249590935',
        pugsLogs: '1387297578713874542',
        pupsLogs: '1387322000053108809',
        pitLogs: '1387622968540266668',
        alerts: '1386049228895424643',
        punishments: '1386050102589915217',
        activeScreenshares: '1387945946280886312',
        screenshareLogs: '1384630245910511616',
        screenshareRequests: '1386050078044848128',
        failedGames: '1382406636009685065',
    },
    categories: {
        teams: '1388021494923137105',
        screenshare: '1201388690434437261',
        customRoleClaim: '1206758430686187561',
    },
    roles: {
        pitOwner: '1392058270537093142',
        helper: '1382406419487129620',
        moderator: '1383922684353843351',
        seniorModerator: '1387284958422368266',
        developer: '1382406418203807835',
        administrator: '1383922459841134662',
        owner: '1383578911933202586',
        registered: '1382406476500435155',
        staff: '1382406422322741278',
        prime: '1382406425397035159',
        primePlus: '1387380487299006605',
        primePlusPlus: '1387380506953384087',
        booster: '1383582362729713674',
        pupsOwner: '1387323524204724235',
        pupsManager: '1383509536815579227',
        pups: '1382406468615147550',
        pugsSpec: '1385848196793630834',
        pugsManager: '1383509567211569212',
        pugs: '1382406467440611352',
        premiumManager: '1384987826634096801',
        premium: '1382406466253750318',
        rankedBan: '1382406473308700712',
        muted: '1382406471802818570',
        tourneyBan: '1392290409472069706',
        ticketBan: '1382406474323726409',
        frozen: '1385848366436581421',
        screenshare: '1382406420724580656',
        supporter: '1383582362729713674',
        supporterPlus: '1382406426437091371',
        creator: '1382406424356720681',
        pugsTrial: '1385848627234078831',
        pitManager: '1383921839608299580',
        pit: '1383921793852506252'
    },
}

export type MapType = {
    name: string;
    height_limit: number | null;
    in_rotation: boolean;
    gameStyle: GameStyles[];
}

export const ALLOWED_MAPS: MapType[] = [
    {
        name: "Aquarium",
        height_limit: 111,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Arcade",
        height_limit: null,
        in_rotation: false,
        gameStyle: [GameStyles.v2v2, GameStyles.v1v1]
    },
    {
        name: "Archway",
        height_limit: 87,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Artemis",
        height_limit: 97,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Bio-Hazard",
        height_limit: 96,
        in_rotation: true,
        gameStyle: [GameStyles.v2v2, GameStyles.v1v1]
    },
    {
        name: "Boletum",
        height_limit: 121,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Build Site",
        height_limit: null,
        in_rotation: false,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Carapace",
        height_limit: 91,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Cascade",
        height_limit: 88,
        in_rotation: true,
        gameStyle: [GameStyles.v2v2, GameStyles.v1v1]
    },
    {
        name: "Catalyst",
        height_limit: 102,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Chained/Unchained",
        height_limit: 90,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Chalk Cliffs",
        height_limit: null,
        in_rotation: false,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Eastwood/Deadwood/Coastal",
        height_limit: 101,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Extinction",
        height_limit: null,
        in_rotation: false,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Invasion/Comet",
        height_limit: 116,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Katsu",
        height_limit: 97,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Lectus/Mortuus",
        height_limit: 91,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Meso",
        height_limit: 96,
        in_rotation: true,
        gameStyle: [GameStyles.v2v2, GameStyles.v1v1]
    },
    {
        name: "Mirage",
        height_limit: 87,
        in_rotation: true,
        gameStyle: [GameStyles.v2v2, GameStyles.v1v1]
    },
    {
        name: "Nebuc",
        height_limit: null,
        in_rotation: false,
        gameStyle: [GameStyles.v2v2, GameStyles.v1v1]
    },
    {
        name: "Obelisk",
        height_limit: 95,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Paladin",
        height_limit: 99,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Planet 98",
        height_limit: 106,
        in_rotation: true,
        gameStyle: [GameStyles.v4v4]
    },
    {
        name: "Playground",
        height_limit: 101,
        in_rotation: true,
        gameStyle: [GameStyles.v2v2, GameStyles.v1v1]
    }
];


export const CLAIM_ELO_DATA = [
    {
        name: 'Staff',
        role: '1382406422322741278',
        amount: 300,
    },
    {
        name: 'Prime',
        role: '1382406425397035159',
        amount: 400,
    },
    {
        name: 'Pit',
        role: '1383921793852506252',
        amount: 350,
    },
    {
        name: 'Pups',
        role: '1382406468615147550',
        amount: 625,
    },
    {
        name: 'Pugs',
        role: '1382406467440611352',
        amount: 650,
    },
    {
        name: 'Premium',
        role: '1382406466253750318',
        amount: 675,
    },
    {
        name: 'Booster',
        role: '1383582362729713674',
        amount: 200
    }
];

export const ELO_DATA = [
    {
        name: 'Coal',
        roleId: '1382406464366317700',
        emoji: '<:rankcoal:1390374803055185940>',
        min: 0,
        max: 99,
        gain: 35,
        loss: 10,
        mvp: 15,
        bounty: 0,
        color: '#2e2e2e'
    },
    {
        name: 'Iron',
        roleId: '1382406462894247939',
        emoji: '<:rankiron:1390374800484077628>',
        min: 100,
        max: 199,
        gain: 30,
        loss: 10,
        mvp: 15,
        bounty: 0,
        color: '#a3a3a3'
    },
    {
        name: 'Gold',
        roleId: '1382406461887348939',
        emoji: '<:rankgold:1390374798680657950>',
        min: 200,
        max: 299,
        gain: 30,
        loss: 15,
        mvp: 15,
        bounty: 0,

        color: '#e6c34a'
    },
    {
        name: 'Diamond',
        roleId: '1382406461132505098',
        emoji: '<:rankdiamond:1390374796352688138>',
        min: 300,
        max: 399,
        gain: 25,
        loss: 15,
        mvp: 10,
        bounty: 0,

        color: '#84e6e6'
    },
    {
        name: 'Emerald',
        roleId: '1382406459710505012',
        emoji: '<:rankemerald:1390374794700001480>',
        min: 400,
        max: 499,
        gain: 25,
        loss: 20,
        mvp: 10,
        bounty: 0,

        color: '#3cff00'
    },
    {
        name: 'Sapphire',
        roleId: '1382406458750271550',
        emoji: '<:ranksapphire:1390374792925937795>',
        min: 500,
        max: 599,
        gain: 20,
        loss: 20,
        mvp: 10,
        bounty: 0,

        color: '#387aff'
    },
    {
        name: 'Ruby',
        roleId: '1382406457559093383',
        emoji: '<:rankruby:1390374791206146208>',
        min: 600,
        max: 699,
        gain: 20,
        loss: 25,
        mvp: 5,
        bounty: 0,

        color: '#c72e2e'
    },
    {
        name: 'Crystal',
        roleId: '1382406450525114420',
        emoji: '<:rankcrystal:1390374789365108736>',
        min: 700,
        max: 799,
        gain: 15,
        loss: 25,
        mvp: 5,
        bounty: 0,

        color: '#f293d4'
    },
    {
        name: 'Opal',
        roleId: '1382406449166291046',
        emoji: '<:rankopal:1390374787817275544>',
        min: 800,
        max: 899,
        gain: 15,
        loss: 30,
        mvp: 5,
        bounty: 0,

        color: '#627dff'
    },
    {
        name: 'Amethyst',
        roleId: '1382406447610069053',
        emoji: '<:rankamethyst:1390375058580705391>',
        min: 900,
        max: 999,
        gain: 10,
        loss: 30,
        mvp: 5,
        bounty: 0,

        color: '#b378f1'
    },
    {
        name: 'Obsidian',
        roleId: '1382406446142066841',
        emoji: '<:rankobsidian:1390375055707340911>',
        min: 1000,
        max: 1099,
        gain: 10,
        loss: 35,
        mvp: 5,
        bounty: 0,

        color: '#502372'
    },
    {
        name: 'Aquamarine',
        roleId: '1382406444791496765',
        emoji: '<:rankaquamarine:1390375053295751229>',
        min: 1100,
        max: 1199,
        gain: 10,
        loss: 35,
        mvp: 5,
        bounty: 0,

        color: '#77cdd6'
    },
    {
        name: 'Aventurine',
        roleId: '1382406443616960592',
        emoji: '<:rankaventurine:1390375051789996196>',
        min: 1200,
        max: 1299,
        gain: 10,
        loss: 35,
        mvp: 5,
        bounty: 0,

        color: '#054d2a'
    },
    {
        name: 'Onyx',
        roleId: '1382406442081980536',
        emoji: '<:rankonyx:1390375049646833724>',
        min: 1300,
        max: 1399,
        gain: 10,
        loss: 40,
        mvp: 5,
        bounty: 0,

        color: '#090909'
    },
    {
        name: 'Quartz',
        roleId: '1382406440492335196',
        emoji: '<:rankquartz:1390375047604080650>',
        min: 1400,
        max: 1499,
        gain: 5,
        loss: 45,
        mvp: 5,
        bounty: 0,

        color: '#ffffff'
    },
    {
        name: 'Topaz',
        roleId: '1382406439384911933',
        emoji: '<:ranktopaz:1390375045330899054>',
        min: 1500,
        max: 1599,
        gain: 5,
        loss: 50,
        mvp: 5,
        bounty: 0,

        color: '#f4831f'
    },
    {
        name: 'Zircon',
        roleId: '1382406438617616404',
        emoji: '<:rankzircon:1390375042939883693>',
        min: 1600,
        max: 1699,
        gain: 5,
        loss: 55,
        mvp: 5,
        bounty: 0,

        color: '#3399ff'
    },
    {
        name: 'Pearl',
        roleId: '1382406437237686534',
        emoji: '<:rankpearl:1390375034530435132>',
        min: 1700,
        max: 1799,
        gain: 5,
        loss: 60,
        mvp: 5,
        bounty: 0,

        color: '#f7f0da'
    },
    {
        name: 'Moonstone',
        roleId: '1382406435912290496',
        emoji: '<:rankmoonstone:1390375040700383272>',
        min: 1800,
        max: 1899,
        gain: 5,
        loss: 65,
        mvp: 5,
        bounty: 0,

        color: '#7da6c5'
    },
    {
        name: 'Celestite',
        roleId: '1382406434876166225',
        emoji: '<:rankcelestite:1390375038808490065>',
        min: 1900,
        max: 1999,
        gain: 5,
        loss: 70,
        mvp: 5,
        bounty: 0,

        color: '#7da8e3'
    },
    {
        name: 'Elite',
        roleId: '1382406433861009498',
        emoji: '<:rankelite:1390375036258619392>',
        min: 2000,
        max: 5000,
        gain: 5,
        loss: 75,
        mvp: 5,
        bounty: 0,

        color: '#8c0000'
    }
];