export class QueueRestrictions {
    queueChannelId: string;
    channelName: string;
    minElo: number;
    maxElo: number;
    requiredRoles: string[];
    specialRoles: string[];

    constructor(data: QueueRestrictions) {
        this.queueChannelId = data.queueChannelId;
        this.channelName = data.channelName;
        this.minElo = data.minElo;
        this.maxElo = data.maxElo;
        this.requiredRoles = data.requiredRoles;
        this.specialRoles = data.specialRoles;
    }
}