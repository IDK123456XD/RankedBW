/*
  Warnings:

  - The values [josie,2v2v2v2v2v2v2v2] on the enum `GameStyles` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "GameStyles_new" AS ENUM ('4v4', '2v2', '1v1');
ALTER TABLE "Settings" ALTER COLUMN "gameStyle" DROP DEFAULT;
ALTER TABLE "Game" ALTER COLUMN "gameStyle" TYPE "GameStyles_new" USING ("gameStyle"::text::"GameStyles_new");
ALTER TABLE "Map" ALTER COLUMN "gameStyle" TYPE "GameStyles_new" USING ("gameStyle"::text::"GameStyles_new");
ALTER TABLE "Settings" ALTER COLUMN "gameStyle" TYPE "GameStyles_new" USING ("gameStyle"::text::"GameStyles_new");
ALTER TYPE "GameStyles" RENAME TO "GameStyles_old";
ALTER TYPE "GameStyles_new" RENAME TO "GameStyles";
DROP TYPE "GameStyles_old";
ALTER TABLE "Settings" ALTER COLUMN "gameStyle" SET DEFAULT '4v4';
COMMIT;
