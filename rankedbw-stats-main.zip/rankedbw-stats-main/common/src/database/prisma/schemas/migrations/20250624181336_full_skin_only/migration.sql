/*
  Warnings:

  - You are about to drop the column `playerSkinsId` on the `Player` table. All the data in the column will be lost.
  - You are about to drop the `PlayerSkins` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `fullBodySkin` to the `Player` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "Player" DROP CONSTRAINT "Player_playerSkinsId_fkey";

-- AlterTable
ALTER TABLE "Player" DROP COLUMN "playerSkinsId",
ADD COLUMN     "fullBodySkin" TEXT NOT NULL;

-- DropTable
DROP TABLE "PlayerSkins";
