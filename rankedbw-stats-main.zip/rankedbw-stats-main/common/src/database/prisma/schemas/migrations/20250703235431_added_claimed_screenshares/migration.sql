-- AlterTable
ALTER TABLE "Player" ADD COLUMN     "claimedScreenshares" INTEGER NOT NULL DEFAULT 0;
