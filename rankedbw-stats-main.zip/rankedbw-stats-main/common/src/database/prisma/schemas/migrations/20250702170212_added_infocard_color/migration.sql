-- CreateEnum
CREATE TYPE "InfocardColor" AS ENUM ('light', 'dark');

-- AlterTable
ALTER TABLE "Infocard" ADD COLUMN     "color" "InfocardColor" NOT NULL DEFAULT 'light';
