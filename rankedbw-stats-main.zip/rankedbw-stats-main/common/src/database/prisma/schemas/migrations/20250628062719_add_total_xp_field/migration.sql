-- CreateEnum
CREATE TYPE "ScreenshareStatus" AS ENUM ('OPEN', 'CLAIMED', 'CLOSED', 'TIMED_OUT');

-- AlterTable
ALTER TABLE "Player" ADD COLUMN     "screenshares" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "totalXp" INTEGER NOT NULL DEFAULT 0,
ALTER COLUMN "level" SET DEFAULT 1;

-- CreateTable
CREATE TABLE "screenshares" (
    "id" TEXT NOT NULL,
    "threadId" TEXT NOT NULL,
    "targetUserId" TEXT NOT NULL,
    "requesterUserId" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "dontLogImageUrl" TEXT NOT NULL,
    "claimedByUserId" TEXT,
    "status" "ScreenshareStatus" NOT NULL DEFAULT 'OPEN',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "closedAt" TIMESTAMP(3),

    CONSTRAINT "screenshares_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "screenshares_threadId_key" ON "screenshares"("threadId");
