/*
  Warnings:

  - You are about to drop the column `hookId` on the `DepositAddress` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "DepositAddress" DROP COLUMN "hookId",
ADD COLUMN     "hookIds" TEXT[];
