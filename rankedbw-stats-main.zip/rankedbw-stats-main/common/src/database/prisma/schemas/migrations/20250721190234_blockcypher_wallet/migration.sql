-- CreateTable
CREATE TABLE "BlockcypherWallet" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "coin" TEXT NOT NULL,
    "walletName" TEXT NOT NULL,
    "hookUnconfirmedId" TEXT NOT NULL,
    "hookConfirmationId" TEXT NOT NULL,

    CONSTRAINT "BlockcypherWallet_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "BlockcypherWallet_walletName_key" ON "BlockcypherWallet"("walletName");
