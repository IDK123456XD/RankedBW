-- AlterTable
ALTER TABLE "screenshares" ADD COLUMN     "requestMessageId" TEXT;
