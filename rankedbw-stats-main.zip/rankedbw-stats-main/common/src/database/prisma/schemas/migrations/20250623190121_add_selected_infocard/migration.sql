-- AlterTable
ALTER TABLE "Player" ADD COLUMN     "gamesPlayed" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "level" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "losses" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "mvps" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "position" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "rank" TEXT NOT NULL DEFAULT 'Unranked',
ADD COLUMN     "selectedInfocardId" TEXT,
ADD COLUMN     "streak" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "wins" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "xp" INTEGER NOT NULL DEFAULT 0;

-- CreateTable
CREATE TABLE "Infocard" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "image" TEXT NOT NULL,

    CONSTRAINT "Infocard_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_InfocardToPlayer" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL,

    CONSTRAINT "_InfocardToPlayer_AB_pkey" PRIMARY KEY ("A","B")
);

-- CreateIndex
CREATE UNIQUE INDEX "Infocard_name_key" ON "Infocard"("name");

-- CreateIndex
CREATE INDEX "_InfocardToPlayer_B_index" ON "_InfocardToPlayer"("B");

-- AddForeignKey
ALTER TABLE "Player" ADD CONSTRAINT "Player_selectedInfocardId_fkey" FOREIGN KEY ("selectedInfocardId") REFERENCES "Infocard"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_InfocardToPlayer" ADD CONSTRAINT "_InfocardToPlayer_A_fkey" FOREIGN KEY ("A") REFERENCES "Infocard"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_InfocardToPlayer" ADD CONSTRAINT "_InfocardToPlayer_B_fkey" FOREIGN KEY ("B") REFERENCES "Player"("id") ON DELETE CASCADE ON UPDATE CASCADE;
