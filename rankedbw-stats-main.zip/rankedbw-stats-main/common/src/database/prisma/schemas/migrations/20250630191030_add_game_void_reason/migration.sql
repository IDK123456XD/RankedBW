-- AlterEnum
ALTER TYPE "EloHistoryReason" ADD VALUE 'GameVoid';
