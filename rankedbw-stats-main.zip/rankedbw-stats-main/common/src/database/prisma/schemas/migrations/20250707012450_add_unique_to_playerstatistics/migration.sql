/*
  Warnings:

  - A unique constraint covering the columns `[playerId,seasonId]` on the table `PlayerStatistics` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "PlayerStatistics_playerId_seasonId_key" ON "PlayerStatistics"("playerId", "seasonId");
