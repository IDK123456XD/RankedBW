-- AlterTable
ALTER TABLE "Settings" ADD COLUMN     "ruleset" TEXT;
