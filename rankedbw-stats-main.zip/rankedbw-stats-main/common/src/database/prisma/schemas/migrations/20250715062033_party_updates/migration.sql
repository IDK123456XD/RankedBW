/*
  Warnings:

  - A unique constraint covering the columns `[leader]` on the table `Party` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "Party" ALTER COLUMN "autoWarp" SET DEFAULT false;

-- CreateIndex
CREATE UNIQUE INDEX "Party_leader_key" ON "Party"("leader");