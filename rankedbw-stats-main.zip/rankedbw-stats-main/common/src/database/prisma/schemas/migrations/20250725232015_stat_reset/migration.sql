-- AlterTable
ALTER TABLE "PlayerStatistics" ADD COLUMN     "statResetCount" INTEGER NOT NULL DEFAULT 0;
