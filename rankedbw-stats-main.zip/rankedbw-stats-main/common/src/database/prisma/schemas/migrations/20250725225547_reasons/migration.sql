-- AlterTable
ALTER TABLE "EloHistory" ADD COLUMN     "extraReason" TEXT;

-- AlterTable
ALTER TABLE "Game" ADD COLUMN     "reason" TEXT;
