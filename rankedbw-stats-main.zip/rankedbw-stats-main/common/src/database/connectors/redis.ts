import Redis from 'ioredis';

interface CachedConnection {
  [id: string]: Redis;
}

const cached: CachedConnection = {};

export default async function connectCache(id?: string) {
  if (!id) id = 'default';
  if (id && cached[id]) return cached[id];

  const { REDIS_HOST, REDIS_PORT, REDIS_PASSWORD, REDIS_USERNAME } = process.env;
  if ((!REDIS_HOST || !REDIS_PORT) && !REDIS_PASSWORD && !REDIS_USERNAME) {
    throw new Error('Environment variable REDIS_HOST, REDIS_PORT, REDIS_PASSWORD, or REDIS_USERNAME was not provided');
  }

  try {
    const connection = new Redis({
      host: REDIS_HOST,
      port: parseInt(REDIS_PORT!),
      password: REDIS_PASSWORD,
      username: REDIS_USERNAME,
      maxRetriesPerRequest: 0,
    });

    await new Promise<void>((resolve, reject) => {
      connection.on('ready', () => {
        console.log('[REDIS] Connected to the Redis successfully.');
        if (id) {
          cached[id] = connection;
        }
        resolve();
      });

      connection.on('error', (error) => {
        reject(error);
      });
    });

    return id ? cached[id] : connection;
  } catch (error) {
    console.error('[REDIS] Failed to connect to Redis.');
    console.error('[REDIS]', error);
    process.exit(2);
  }
}
