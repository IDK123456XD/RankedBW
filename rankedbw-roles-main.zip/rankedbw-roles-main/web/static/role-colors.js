(function(){
  const COLOR_INPUT_IDS = [
    'adminPrimaryColor','adminSecondaryColor','editAdminPrimaryColor','editAdminSecondaryColor',
    'primaryColor','secondaryColor','editPrimaryColor','editSecondaryColor'
  ];
  let currentTargetId = null;

  const LABEL_MAP = {
    adminPrimaryColor: 'Primary Color',
    primaryColor: 'Primary Color',
    editPrimaryColor: 'Primary Color',
    editAdminPrimaryColor: 'Primary Color',
    adminSecondaryColor: 'Secondary Color',
    secondaryColor: 'Secondary Color',
    editSecondaryColor: 'Secondary Color',
    editAdminSecondaryColor: 'Secondary Color'
  };

  function clamp(v){ return Math.max(0, Math.min(255, v|0)); }
  function toHex(v){ return v.toString(16).padStart(2,'0'); }
  function rgbToHex(r,g,b){ return '#' + toHex(r)+toHex(g)+toHex(b); }
  function parse(str){
    if(!str) return null; str=str.trim();
    let m = str.match(/^#([0-9a-f]{3})$/i); if(m){ const h=m[1]; return {r:parseInt(h[0]+h[0],16),g:parseInt(h[1]+h[1],16),b:parseInt(h[2]+h[2],16)}; }
    m = str.match(/^#([0-9a-f]{6})$/i); if(m){ const h=m[1]; return {r:parseInt(h.slice(0,2),16),g:parseInt(h.slice(2,4),16),b:parseInt(h.slice(4,6),16)}; }
    m = str.match(/^rgb\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/i); if(m){ return {r:clamp(+m[1]),g:clamp(+m[2]),b:clamp(+m[3])}; }
    return null;
  }

  function updatePreview(rgb){
    const preview = document.getElementById('roleColorPreview');
    if(preview && rgb){ preview.style.background = rgbToHex(rgb.r,rgb.g,rgb.b); }
  }

  function syncUI(rgb){
    if(!rgb) return;
    const hex = document.getElementById('roleColorHex');
    const r = document.getElementById('roleColorR');
    const g = document.getElementById('roleColorG');
    const b = document.getElementById('roleColorB');
    if(hex){ hex.value = rgbToHex(rgb.r,rgb.g,rgb.b); }
    if(r) r.value = rgb.r; if(g) g.value = rgb.g; if(b) b.value = rgb.b;
    updatePreview(rgb);
  }

  function randomColor(){ return { r: Math.floor(Math.random()*256), g: Math.floor(Math.random()*256), b: Math.floor(Math.random()*256)}; }

  function applyToTarget(rgb){
    if(!currentTargetId) return;
    const input = document.getElementById(currentTargetId);
    if(!input) return;
    const hex = rgbToHex(rgb.r,rgb.g,rgb.b);
    input.value = hex;
    const trigger = document.querySelector(`[data-color-target="${currentTargetId}"]`);
    if(trigger){
      const swatch = trigger.querySelector('.role-color-swatch');
      const code = trigger.querySelector('.role-color-code');
      if(swatch) swatch.style.background = hex;
      if(code) code.textContent = hex;
    }
    ['input','change'].forEach(evt=> input.dispatchEvent(new Event(evt,{bubbles:true})));
  }

  function openModalFor(id){
    currentTargetId = id;
    const input = document.getElementById(id);
    if(!input) return;
    const rgb = parse(input.value) || {r:52,g:152,b:219};
    syncUI(rgb);
    const modalEl = document.getElementById('roleColorModal');
    if(modalEl){
      const titleEl = modalEl.querySelector('.modal-title');
      if(titleEl){
        const label = LABEL_MAP[id] || 'Role Color';
        titleEl.innerHTML = `<i class="fas fa-eye-dropper"></i> Pick ${label}`;
      }
      const m = bootstrap.Modal.getOrCreateInstance(modalEl); m.show();
    }
  }

  function transformInput(input){
    if(input.dataset.enhanced === '1') return;
    input.dataset.enhanced = '1';
    input.classList.add('role-color-original');
    input.setAttribute('aria-hidden','true');
    input.setAttribute('autocomplete','off');
    input.style.display = 'none';
    input.tabIndex = -1;
  const box = document.createElement('div');
  box.className = 'role-color-box';
  box.dataset.colorTarget = input.id;
  box.style.setProperty('--role-color-box-bg', input.value);
  box.title = (LABEL_MAP[input.id]||'Color') + ' ' + input.value;
  const code = document.createElement('span'); code.className='role-color-code'; code.textContent = input.value;
  box.appendChild(code);
  box.addEventListener('click', ()=>{ if(box.classList.contains('disabled') || input.disabled) return; openModalFor(input.id); });
  input.parentNode.insertBefore(box, input);
  }

  function syncDisabledStates(){
    COLOR_INPUT_IDS.forEach(id=>{
      const input = document.getElementById(id);
      if(!input) return;
      const trigger = document.querySelector(`[data-color-target="${id}"]`);
      if(trigger){
        if(input.disabled){ trigger.classList.add('disabled'); trigger.setAttribute('aria-disabled','true'); }
        else { trigger.classList.remove('disabled'); trigger.removeAttribute('aria-disabled'); }
      }
    });
  }

  function initialApply(){
    COLOR_INPUT_IDS.forEach(id=>{ const el = document.getElementById(id); if(el) transformInput(el); });
    syncDisabledStates();
  }

  document.addEventListener('DOMContentLoaded', ()=>{
    initialApply();
    const disabledObserver = new MutationObserver(syncDisabledStates);
    COLOR_INPUT_IDS.forEach(id=>{ const el=document.getElementById(id); if(el) disabledObserver.observe(el,{attributes:true, attributeFilter:['disabled']}); });
    const addObserver = new MutationObserver((mutations)=>{
      let changed=false;
      mutations.forEach(m=>{
        m.addedNodes && m.addedNodes.forEach(n=>{
          if(!(n instanceof HTMLElement)) return;
          COLOR_INPUT_IDS.forEach(id=>{
            if(n.id === id && !n.dataset.enhanced){ transformInput(n); changed=true; }
            const found = n.querySelector && n.querySelector('#'+id);
            if(found && !found.dataset.enhanced){ transformInput(found); changed=true; }
          });
        });
      });
      if(changed) syncDisabledStates();
    });
    addObserver.observe(document.body,{childList:true, subtree:true});
  ['createRoleModal','editRoleModal','createAdminRoleModal','editAdminRoleModal'].forEach(mid=>{
      const mEl = document.getElementById(mid);
      if(mEl){
        mEl.addEventListener('show.bs.modal', ()=>{
          COLOR_INPUT_IDS.forEach(id=>{ const el = document.getElementById(id); if(el) transformInput(el); });
          syncDisabledStates();
        });
      }
    });

    const hex = document.getElementById('roleColorHex');
    const r = document.getElementById('roleColorR');
    const g = document.getElementById('roleColorG');
    const b = document.getElementById('roleColorB');
    const applyBtn = document.getElementById('roleColorApplyBtn');
    const randomBtn = document.getElementById('roleColorRandomBtn');

    function currentRGB(){ return parse(hex.value) || {r:clamp(+r.value||0), g:clamp(+g.value||0), b:clamp(+b.value||0)}; }

    hex && hex.addEventListener('input', ()=>{ const rgb = parse(hex.value); if(rgb){ syncUI(rgb); } });
    [r,g,b].forEach(inp=> inp && inp.addEventListener('input', ()=>{ const rgb = {r:clamp(+r.value||0),g:clamp(+g.value||0),b:clamp(+b.value||0)}; syncUI(rgb); }));
    applyBtn && applyBtn.addEventListener('click', ()=>{ const rgb = currentRGB(); applyToTarget(rgb); const modalEl=document.getElementById('roleColorModal'); if(modalEl){ bootstrap.Modal.getInstance(modalEl)?.hide(); } });
    randomBtn && randomBtn.addEventListener('click', ()=>{ const rgb = randomColor(); syncUI(rgb); });
  });
})();
