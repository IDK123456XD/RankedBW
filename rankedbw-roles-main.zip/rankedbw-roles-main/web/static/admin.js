let currentRoles = [];
let currentUsers = [];
let editingRoleId = null;
let currentEditingRoleId = null;
let currentEditingRoleData = null;
const ADMIN_EMOJI_DATA_VERSION = '20250909-1';

document.addEventListener('DOMContentLoaded', function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    initializeCustomColorPickers();
    loadRoles();
    setupEventListeners();
    syncSecondaryColorVisibility('admin');
    syncSecondaryColorVisibility('editAdmin');
});

function initializeCustomColorPickers() {
    const primaryGroup = document.getElementById('adminPrimaryColorGroup');
    if (primaryGroup) {
        const primaryPicker = createColorInputGroup('adminPrimaryColor', 'Primary Color', '#3498db', {
            onChange: updateAdminColorPreview,
            hideInput: true
        });
        primaryGroup.appendChild(primaryPicker);
    }

    const secondaryContainer = document.getElementById('adminSecondaryColorContainer');
    if (secondaryContainer) {
        const secondaryPicker = createColorInputGroup('adminSecondaryColor', 'Secondary Color', '#9b59b6', {
            onChange: updateAdminColorPreview,
            hideInput: true
        });
        secondaryContainer.appendChild(secondaryPicker);
        
        const secondaryInput = secondaryContainer.querySelector('#adminSecondaryColor');
        const secondaryPreview = secondaryContainer.querySelector('.color-preview');
        if (secondaryInput && secondaryPreview) {
            secondaryInput.disabled = true;
            secondaryPreview.style.opacity = '0.5';
            secondaryPreview.style.pointerEvents = 'none';
        }
    }

    const editPrimaryGroup = document.getElementById('editAdminPrimaryColorGroup');
    if (editPrimaryGroup) {
        const editPrimaryPicker = createColorInputGroup('editAdminPrimaryColor', 'Primary Color', '#3498db', {
            onChange: updateEditColorPreview,
            hideInput: true
        });
        editPrimaryGroup.appendChild(editPrimaryPicker);
    }

    const editSecondaryContainer = document.getElementById('editAdminSecondaryColorContainer');
    if (editSecondaryContainer) {
        const editSecondaryPicker = createColorInputGroup('editAdminSecondaryColor', 'Secondary Color', '#9b59b6', {
            onChange: updateEditColorPreview,
            hideInput: true
        });
        editSecondaryContainer.appendChild(editSecondaryPicker);
        
        const editSecondaryInput = editSecondaryContainer.querySelector('#editAdminSecondaryColor');
        const editSecondaryPreview = editSecondaryContainer.querySelector('.color-preview');
        if (editSecondaryInput && editSecondaryPreview) {
            editSecondaryInput.disabled = true;
            editSecondaryPreview.style.opacity = '0.5';
            editSecondaryPreview.style.pointerEvents = 'none';
        }
    }

    const createSecGroup = document.getElementById('adminSecondaryColorGroup');
    if (createSecGroup) createSecGroup.style.display = 'none';
    const editSecGroup = document.getElementById('editAdminSecondaryColorGroup');
    if (editSecGroup) editSecGroup.style.display = 'none';

    updateAdminColorPreview();
    updateEditColorPreview();
}

function updateAdminColorPreview() {
    const colorType = document.querySelector('input[name="adminColorType"]:checked')?.value || 'solid';
    const primaryColor = document.getElementById('adminPrimaryColor')?.value || '#3498db';
    const secondaryColor = document.getElementById('adminSecondaryColor')?.value || '#9b59b6';
    const preview = document.getElementById('adminColorPreview');

    if (!preview) return;

    if (colorType === 'gradient') {
        preview.style.background = `linear-gradient(45deg, ${primaryColor}, ${secondaryColor})`;
    } else {
        preview.style.background = primaryColor;
    }

    const primaryPreview = document.querySelector('[data-target="adminPrimaryColor"]');
    if (primaryPreview) {
        primaryPreview.style.backgroundColor = primaryColor;
    }

    const secondaryPreview = document.querySelector('[data-target="adminSecondaryColor"]');
    if (secondaryPreview) {
        secondaryPreview.style.backgroundColor = secondaryColor;
    }
}

function setupEventListeners() {
    const createForm = document.getElementById('adminCreateRoleForm');
    if (createForm) {
        createForm.addEventListener('submit', handleCreateRole);
    }
    const createBtn = document.getElementById('adminCreateRoleBtn');
    if (createBtn) {
        createBtn.addEventListener('click', handleCreateRole);
    }

        adminEmojiData = {
            smileys: ['😀','😃','😄','😁','😆','😅','😂','🤣'],
            animals: ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🕷️','🕸️'],
            food: ['🍎','🍊','🍋','🍌','🍉','🍇','🍓']
        };
    const editForm = document.getElementById('adminEditRoleForm');
    if (editForm) {
        editForm.addEventListener('submit', handleEditRole);
    }

    const saveBtn = document.getElementById('adminSaveRoleBtn');
    if (saveBtn) {
        saveBtn.addEventListener('click', handleEditRole);
    }

    setupColorToggle('admin', 'adminColorType');
    setupColorToggle('editAdmin', 'editAdminColorType');

    setupExpiryToggle('admin', 'adminExpiryType');
    setupExpiryToggle('editAdmin', 'editAdminExpiryType');

    setupIconToggle('admin', 'adminIconType');
    setupIconToggle('editAdmin', 'editAdminIconType');

    initializeAdminEmojiPickers();

    const assignCheckbox = document.getElementById('adminAssignOnCreate');
    if (assignCheckbox) {
        assignCheckbox.addEventListener('change', function () {
            const userAssignment = document.getElementById('adminUserAssignment');
            if (userAssignment) {
                userAssignment.style.display = this.checked ? 'block' : 'none';
            }
        });
    }

    const directIDCheckbox = document.getElementById('adminDirectID');
    if (directIDCheckbox) {
        directIDCheckbox.addEventListener('change', function () {
            const directIDInput = document.getElementById('adminDirectIDInput');
            const userSearchInput = document.getElementById('adminUserSearch');
            if (directIDInput && userSearchInput) {
                if (this.checked) {
                    directIDInput.style.display = 'block';
                    userSearchInput.style.display = 'none';
                } else {
                    directIDInput.style.display = 'none';
                    userSearchInput.style.display = 'block';
                }
            }
        });
    }

    const grantRoleBtn = document.getElementById('adminConfirmGrantRoleBtn');
    if (grantRoleBtn) {
        grantRoleBtn.addEventListener('click', confirmAssignRole);
    }

    setupUserSearch();

    setupRoleSearch();
}

function setupUserSearch() {
    const userSearchInput = document.getElementById('adminUserSearch');
    const userSearchResults = document.getElementById('adminSearchResults');

    if (userSearchInput && userSearchResults) {
        let searchTimeout;

        userSearchInput.addEventListener('input', function () {
            clearTimeout(searchTimeout);
            const query = this.value.trim();

            if (query.length < 2) {
                userSearchResults.style.display = 'none';
                return;
            }

            searchTimeout = setTimeout(() => {
                searchUsers(query, 'admin');
            }, 300);
        });

        document.addEventListener('click', function (e) {
            if (!userSearchInput.contains(e.target) && !userSearchResults.contains(e.target)) {
                userSearchResults.style.display = 'none';
            }
        });
    }

    const grantSearchInput = document.getElementById('adminGrantUserSearch');
    const grantSearchResults = document.getElementById('adminGrantSearchResults');

    if (grantSearchInput && grantSearchResults) {
        let searchTimeout;

        grantSearchInput.addEventListener('input', function () {
            clearTimeout(searchTimeout);
            const query = this.value.trim();

            if (query.length < 2) {
                grantSearchResults.style.display = 'none';
                const confirmBtn = document.getElementById('adminConfirmGrantRoleBtn');
                if (confirmBtn) {
                    confirmBtn.disabled = true;
                }
                const preview = document.getElementById('adminGrantUserPreview');
                if (preview) {
                    preview.style.display = 'none';
                }
                return;
            }

            if (/^\d{17,19}$/.test(query)) {
                selectUserById(query, 'adminGrant');
                return;
            }

            searchTimeout = setTimeout(() => {
                searchUsers(query, 'adminGrant');
            }, 300);
        });

        document.addEventListener('click', function (e) {
            if (!grantSearchInput.contains(e.target) && !grantSearchResults.contains(e.target)) {
                grantSearchResults.style.display = 'none';
            }
        });
    }
}

async function searchUsers(query, prefix) {
    try {
        const response = await fetch(`/admin/search-users?q=${encodeURIComponent(query)}`);
        const data = await response.json();

        if (data.users && data.users.length > 0) {
            currentUsers = data.users;
            displayUserResults(data.users, prefix);
        } else {
            const resultsContainer = document.getElementById(prefix + 'UsersList') || document.getElementById(prefix + 'SearchResults');
            if (resultsContainer) {
                resultsContainer.innerHTML = '<div class="dropdown-item text-muted">No users found</div>';
                resultsContainer.parentElement.style.display = 'block';
            }
        }
    } catch (error) {
        const resultsContainer = document.getElementById(prefix + 'UsersList') || document.getElementById(prefix + 'SearchResults');
        if (resultsContainer) {
            resultsContainer.innerHTML = '<div class="dropdown-item text-danger">Error searching users</div>';
            resultsContainer.parentElement.style.display = 'block';
        }
    }
}

function displayUserResults(users, prefix) {
    const resultsContainer = document.getElementById(prefix + 'UsersList');
    const resultsParent = document.getElementById(prefix + 'SearchResults');

    if (!resultsContainer || !resultsParent) return;

    resultsContainer.innerHTML = users.map(user => {
        const avatarUrl = user.avatar && user.avatar.startsWith('http')
            ? user.avatar
            : user.avatar
                ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=32`
                : '';

        return `
            <div class="dropdown-item user-result" onclick="selectUser('${user.id}', '${user.username}', '${user.display_name}', '${avatarUrl}', '${prefix}')">
                <div class="d-flex align-items-center">
                    ${avatarUrl
                ? `<img src="${avatarUrl}" alt="Avatar" class="rounded-circle me-2" width="32" height="32">`
                : '<i class="fas fa-user fa-lg text-muted me-2"></i>'
            }
                    <div>
                        <div class="fw-bold">${user.username}</div>
                        <small class="text-muted">${user.display_name}</small>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    resultsParent.style.display = 'block';
}

function selectUser(userId, username, displayName, avatar, prefix) {
    const searchInput = document.getElementById(prefix + 'UserSearch');
    const resultsContainer = document.getElementById(prefix + 'SearchResults');
    const previewContainer = document.getElementById(prefix + 'UserPreview');
    const avatarElement = document.getElementById(prefix + 'SelectedUserAvatar');
    const iconElement = document.getElementById(prefix + 'SelectedUserIcon');
    const nameElement = document.getElementById(prefix + 'SelectedUserName');
    const detailElement = document.getElementById(prefix + 'SelectedUserDetail');

    if (searchInput) {
        searchInput.value = username;
        searchInput.dataset.userId = userId;
    }

    if (resultsContainer) {
        resultsContainer.style.display = 'none';
    }

    if (previewContainer) {
        previewContainer.style.display = 'block';

        if (avatarElement && iconElement) {
            if (avatar && avatar !== 'null') {
                avatarElement.src = avatar;
                avatarElement.style.display = 'block';
                iconElement.style.display = 'none';
            } else {
                avatarElement.style.display = 'none';
                iconElement.style.display = 'block';
            }
        }

        if (nameElement) {
            nameElement.textContent = username;
        }

        if (detailElement) {
            detailElement.textContent = displayName;
        }
    }

    if (prefix === 'adminGrant') {
        const confirmBtn = document.getElementById('adminConfirmGrantRoleBtn');
        if (confirmBtn) {
            confirmBtn.disabled = false;
        }
    }
}

async function selectUserById(userId, prefix) {
    try {
        const response = await fetch(`/admin/search-users?q=${encodeURIComponent(userId)}`);
        const data = await response.json();

        if (data.users && data.users.length > 0) {
            const user = data.users[0];
            selectUser(user.id, user.username, user.display_name, user.avatar, prefix);
        } else {
            selectUser(userId, userId, `User ID: ${userId}`, '', prefix);
        }
    } catch (error) {
        selectUser(userId, userId, `User ID: ${userId}`, '', prefix);
    }
}

async function loadRoles() {
    try {
        showLoading('adminRolesList');
        const response = await fetch('/admin/roles');
        const data = await response.json();

        if (data.roles) {
            currentRoles = data.roles;
            displayRoles(data.roles);
            updateRoleStats(data.roles);
        } else {
            document.getElementById('adminRolesList').innerHTML = '<div class="text-center text-muted py-4">No roles found</div>';
            updateRoleStats([]);
        }
    } catch (error) {
        showError('Failed to load roles');
    }
}

function updateRoleStats(roles) {
    const totalRolesEl = document.getElementById('totalRoles');
    const activeRolesEl = document.getElementById('activeRoles');
    
    if (totalRolesEl) {
        totalRolesEl.textContent = roles.length;
        
        animateValue(totalRolesEl, 0, roles.length, 1000);
    }
    
    if (activeRolesEl) {
        const activeCount = roles.filter(role => role.SlotUsage > 0).length;
        activeRolesEl.textContent = activeCount;
        
        animateValue(activeRolesEl, 0, activeCount, 1200);
    }
}

function animateValue(element, start, end, duration) {
    if (start === end) return;
    const range = end - start;
    const stepTime = Math.abs(Math.floor(duration / range));
    let current = start;
    const increment = end > start ? 1 : -1;
    
    const timer = setInterval(() => {
        current += increment;
        element.textContent = current;
        if (current === end) {
            clearInterval(timer);
        }
    }, stepTime);
}

function displayRoles(roles) {
    const container = document.getElementById('adminRolesList');

    if (!container) {
        return;
    }

    if (roles.length === 0) {
        container.innerHTML = '<div class="text-center text-muted py-4">No custom roles found</div>';
        return;
    }

    container.innerHTML = roles.map(role => createRoleCard(role)).join('');
}

function createSearchRoleCard(role) {
    return `
        <div class="admin-search-card" onclick="selectRoleFromSearch('${role.id}')">
            <div class="search-card-header">
                <div class="search-role-type ${role.type}">${role.type}</div>
            </div>
            <div class="search-card-body">
                <h6>${role.name}</h6>
                <div class="search-card-meta">
                    <div><strong>ID:</strong> <code>${role.id.substring(0, 12)}...</code></div>
                    ${role.owner ? `<div><strong>Owner:</strong> ${role.owner}</div>` : ''}
                    <div><strong>Color:</strong> <span style="display: inline-block; width: 16px; height: 16px; background-color: ${role.color}; border-radius: 3px; vertical-align: middle; margin-left: 0.5rem;"></span></div>
                </div>
                <div class="search-card-stats">
                    <div class="search-stat-item">
                        <span class="search-stat-value">${role.memberCount || 0}</span>
                        <span class="search-stat-label">Members</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function createRoleCard(role) {
    const colorDisplay = role.color.type === 'gradient'
        ? `background: linear-gradient(135deg, ${role.color.primary}, ${role.color.secondary})`
        : `background-color: ${role.color.primary}`;

    const iconDisplay = role.icon && role.icon.type === 'emoji'
        ? role.icon.value
        : role.icon && role.icon.type === 'custom'
            ? `<img src="${role.icon.value}" alt="" width="24" height="24" class="rounded">`
            : '<i class="fas fa-crown text-warning"></i>';

    const expiryDisplay = role.expires_at
        ? new Date(role.expires_at).getFullYear() > 2100
            ? 'Never expires'
            : `Expires: ${new Date(role.expires_at).toLocaleDateString()}`
        : 'Never expires';

    const progressPercentage = (role.slots.used / role.slots.total) * 100;
    const progressColor = progressPercentage > 90 ? 'bg-danger' : progressPercentage > 70 ? 'bg-warning' : 'bg-success';
    
    const truncatedName = role.name.length > 20 ? role.name.substring(0, 17) + '...' : role.name;
    const nameWithTooltip = role.name.length > 20 
        ? `<span class="role-name-truncated" title="${role.name}" data-bs-toggle="tooltip" data-bs-placement="top">${truncatedName}</span>`
        : `<span class="role-name-full">${role.name}</span>`;

    return `
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="modern-role-card h-100">
                <div class="role-card-header">
                    <div class="role-color-orb" style="${colorDisplay}"></div>
                    <div class="role-info-section">
                        <h6 class="role-title">${nameWithTooltip}</h6>
                        <div class="role-meta">
                            <span class="role-icon">${iconDisplay}</span>
                            <code class="role-id">${role.id.substring(0, 8)}...</code>
                        </div>
                    </div>
                    <div class="role-status-badge">
                        <span class="status-indicator ${progressPercentage > 90 ? 'status-critical' : progressPercentage > 70 ? 'status-warning' : 'status-good'}"></span>
                    </div>
                </div>
                
                <div class="role-stats-section">
                    <div class="stat-item">
                        <div class="stat-header">
                            <span class="stat-label">Slot Usage</span>
                            <span class="stat-value">${role.slots.used}/${role.slots.total}</span>
                        </div>
                        <div class="modern-progress-bar">
                            <div class="progress-fill ${progressColor.replace('bg-', '')}" style="width: ${progressPercentage}%"></div>
                        </div>
                    </div>
                    
                    <div class="expiry-info">
                        <i class="fas fa-clock icon-muted"></i>
                        <span class="expiry-text">${expiryDisplay}</span>
                    </div>
                </div>
                
                <div class="role-actions-section">
                    <div class="action-group primary-actions">
                        <button class="modern-btn btn-edit" onclick="editRole('${role.id}')" title="Edit Role">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="modern-btn btn-assign" onclick="assignRole('${role.id}')" title="Assign Role">
                            <i class="fas fa-user-plus"></i>
                        </button>
                        <button class="modern-btn btn-delete" onclick="deleteRole('${role.id}')" title="Delete Role">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                    
                    <div class="action-group secondary-actions">
                        <button class="modern-btn btn-view" onclick="viewRoleMembers('${role.id}')" title="View & Manage Members">
                            <i class="fas fa-users"></i>
                        </button>
                        <button class="modern-btn btn-transfer" onclick="transferRoleOwnership('${role.id}')" title="Transfer Ownership">
                            <i class="fas fa-exchange-alt"></i>
                        </button>
                        <button class="modern-btn btn-info" onclick="quickRoleInfo('${role.id}')" title="Quick Info">
                            <i class="fas fa-info-circle"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function setupColorToggle(prefix, radioName) {
    const solidRadio = document.getElementById(prefix + 'SolidColor');
    const gradientRadio = document.getElementById(prefix + 'GradientColor');
    const secondaryColorInput = document.getElementById(prefix + 'SecondaryColor');
    const secondaryColorContainer = document.getElementById(prefix + 'SecondaryColorContainer');
    const secondaryColorGroup = document.getElementById(prefix + 'SecondaryColorGroup');

    if (solidRadio && gradientRadio) {
        solidRadio.addEventListener('change', function () {
            if (this.checked) {
                if (secondaryColorInput) {
                    secondaryColorInput.disabled = true;
                }
                if (secondaryColorContainer) {
                    const preview = secondaryColorContainer.querySelector('.color-preview');
                    if (preview) {
                        preview.style.opacity = '0.5';
                        preview.style.pointerEvents = 'none';
                    }
                }
                if (secondaryColorGroup) {
                    secondaryColorGroup.style.display = 'none';
                }
                if (prefix === 'admin') {
                    updateAdminColorPreview();
                } else if (prefix === 'editAdmin') {
                    updateEditColorPreview();
                }
            }
        });

        gradientRadio.addEventListener('change', function () {
            if (this.checked) {
                if (secondaryColorInput) {
                    secondaryColorInput.disabled = false;
                }
                if (secondaryColorContainer) {
                    const preview = secondaryColorContainer.querySelector('.color-preview');
                    if (preview) {
                        preview.style.opacity = '1';
                        preview.style.pointerEvents = 'auto';
                    }
                }
                if (secondaryColorGroup) {
                    secondaryColorGroup.style.display = '';
                }
                if (prefix === 'admin') {
                    updateAdminColorPreview();
                } else if (prefix === 'editAdmin') {
                    updateEditColorPreview();
                }
            }
        });
    }
}

function syncSecondaryColorVisibility(prefix){
    const gradientRadio = document.getElementById(prefix + 'GradientColor');
    const solidRadio = document.getElementById(prefix + 'SolidColor');
    const secondaryColorInput = document.getElementById(prefix + 'SecondaryColor');
    const secondaryColorContainer = document.getElementById(prefix + 'SecondaryColorContainer');
    const secondaryColorGroup = document.getElementById(prefix + 'SecondaryColorGroup');
    if(!gradientRadio || !solidRadio) return;
    const gradient = gradientRadio.checked;
    if(gradient){
        if(secondaryColorInput) secondaryColorInput.disabled = false;
        if(secondaryColorGroup) secondaryColorGroup.style.display = '';
        if(secondaryColorContainer){
            const preview = secondaryColorContainer.querySelector('.color-preview');
            if(preview){ preview.style.opacity='1'; preview.style.pointerEvents='auto'; }
        }
    } else {
        if(secondaryColorInput) secondaryColorInput.disabled = true;
        if(secondaryColorGroup) secondaryColorGroup.style.display = 'none';
        if(secondaryColorContainer){
            const preview = secondaryColorContainer.querySelector('.color-preview');
            if(preview){ preview.style.opacity='0.5'; preview.style.pointerEvents='none'; }
        }
    }
    if(prefix === 'admin') updateAdminColorPreview(); else if(prefix === 'editAdmin') updateEditColorPreview();
}

function setupExpiryToggle(prefix, radioName) {
    const neverRadio = document.getElementById(prefix + 'NeverExpire');
    const customRadio = document.getElementById(prefix + 'CustomExpiry');
    const expiryInputs = document.getElementById(prefix + 'ExpiryInputs');

    if (neverRadio && customRadio && expiryInputs) {
        neverRadio.addEventListener('change', function () {
            if (this.checked) {
                expiryInputs.style.display = 'none';
            }
        });

        customRadio.addEventListener('change', function () {
            if (this.checked) {
                expiryInputs.style.display = 'block';
            }
        });
    }
}

function setupIconToggle(prefix, radioName) {
    const noIconRadio = document.getElementById(prefix + 'NoIcon');
    const emojiRadio = document.getElementById(prefix + 'EmojiIcon');
    const customRadio = document.getElementById(prefix + 'CustomIcon');
    const emojiInput = document.getElementById(prefix + 'EmojiInput');
    const customImageInput = document.getElementById(prefix + 'CustomImageInput');

    if (noIconRadio && emojiRadio && customRadio) {
        noIconRadio.addEventListener('change', function () {
            if (this.checked) {
                if (emojiInput) emojiInput.style.display = 'none';
                if (customImageInput) customImageInput.style.display = 'none';
                if (prefix === 'admin') {
                    clearAdminImageUpload('admin');
                } else if (prefix === 'editAdmin') {
                    clearAdminImageUpload('editAdmin');
                }
            }
        });

        emojiRadio.addEventListener('change', function () {
            if (this.checked) {
                if (emojiInput) emojiInput.style.display = 'block';
                if (customImageInput) customImageInput.style.display = 'none';
                if (prefix === 'admin') {
                    clearAdminImageUpload('admin');
                } else if (prefix === 'editAdmin') {
                    clearAdminImageUpload('editAdmin');
                }
            }
        });

        customRadio.addEventListener('change', function () {
            if (this.checked) {
                if (emojiInput) emojiInput.style.display = 'none';
                if (customImageInput) customImageInput.style.display = 'block';
            }
        });
    }
}

let adminEmojiData = {};
let adminEmojiLoaded = false;

async function loadAdminEmojiData() {
    if (adminEmojiLoaded) return;
    try {
        const res = await fetch('/static/emoji-data.json');
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        if (typeof data === 'object') {
            adminEmojiData = data;
            adminEmojiLoaded = true;
        }
    } catch (e) {
        console.error('Failed to load emoji dataset', e);
        adminEmojiData = {
            smileys: ['�','�','�','�','�','�','🤣','�'],
            animals: ['�','�','�','�','�','�','�','�'],
            food: ['�','�','�','�','�','�','�','�']
        };
    }
}

async function initializeAdminEmojiPickers() {
    if (typeof loadAdminEmojiData === 'function') {
        await loadAdminEmojiData();
    }
    const adminEmojiPickerBtn = document.getElementById('adminEmojiPickerBtn');
    if (adminEmojiPickerBtn) {
        adminEmojiPickerBtn.addEventListener('click', function () {
            const picker = document.getElementById('adminEmojiPicker');
            if (picker) {
                const isHidden = picker.style.display === 'none' || picker.style.display === '';
                picker.style.display = isHidden ? 'block' : 'none';
            }
        });
    }

    const editAdminEmojiPickerBtn = document.getElementById('editAdminEmojiPickerBtn');
    if (editAdminEmojiPickerBtn) {
        editAdminEmojiPickerBtn.addEventListener('click', function () {
            const picker = document.getElementById('editAdminEmojiPicker');
            if (picker) {
                const isHidden = picker.style.display === 'none' || picker.style.display === '';
                picker.style.display = isHidden ? 'block' : 'none';
            }
        });
    }

    document.querySelectorAll('#adminEmojiPicker .emoji-category-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const category = this.dataset.category;
            showAdminEmojiCategory('admin', category);

            document.querySelectorAll('#adminEmojiPicker .emoji-category-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });

    document.querySelectorAll('#editAdminEmojiPicker .emoji-category-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const category = this.dataset.category;
            showAdminEmojiCategory('editAdmin', category);

            document.querySelectorAll('#editAdminEmojiPicker .emoji-category-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });

    showAdminEmojiCategory('admin', 'smileys');
    showAdminEmojiCategory('editAdmin', 'smileys');

    const adminCreateUpload = document.getElementById('adminImageUpload');
    const adminEditUpload = document.getElementById('editAdminImageUpload');

    if (adminCreateUpload) {
        adminCreateUpload.addEventListener('change', function () {
            handleAdminFileUpload(this, 'admin');
        });
    }

    if (adminEditUpload) {
        adminEditUpload.addEventListener('change', function () {
            handleAdminFileUpload(this, 'editAdmin');
        });
    }

    document.addEventListener('click', function (e) {
        if (e.target && e.target.id === 'adminRemoveImageBtn') {
            clearAdminImageUpload('admin');
        }
        if (e.target && e.target.id === 'editAdminRemoveImageBtn') {
            clearAdminImageUpload('editAdmin');
        }
    });
}

function showAdminEmojiCategory(modalType, category) {
    const gridId = modalType === 'admin' ? 'adminEmojiGrid' : 'editAdminEmojiGrid';
    const grid = document.getElementById(gridId);

    if (!grid) {
        return;
    }

    grid.innerHTML = '';

    const emojis = adminEmojiData[category] || [];
    emojis.forEach(emoji => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'emoji-item';
        button.textContent = emoji;
        button.addEventListener('click', () => selectAdminEmoji(modalType, emoji));
        grid.appendChild(button);
    });

}

function selectAdminEmoji(modalType, emoji) {

    if (modalType === 'admin') {
        const emojiInput = document.getElementById('adminEmojiValue');
        if (emojiInput) {
            emojiInput.value = emoji;
            const picker = document.getElementById('adminEmojiPicker');
            if (picker) {
                picker.style.display = 'none';
            }
        }
    } else {
        const emojiInput = document.getElementById('editAdminEmojiValue');
        if (emojiInput) {
            emojiInput.value = emoji;
            const picker = document.getElementById('editAdminEmojiPicker');
            if (picker) {
                picker.style.display = 'none';
            }
        }
    }
}

function handleAdminFileUpload(input, modalType) {
    const file = input.files[0];
    let previewId;

    if (modalType === 'admin') {
        previewId = 'adminImagePreview';
    } else {
        previewId = 'editAdminImagePreview';
    }

    if (!file) {
        hideAdminImagePreview(previewId);
        return;
    }

    if (!file.type.startsWith('image/')) {
        showToast('Please select an image file.', 'error');
        input.value = '';
        return;
    }

    const maxSize = 256 * 1024;
    if (file.size > maxSize) {
        showToast(`File size must be under 256KB. Current size: ${(file.size / 1024).toFixed(1)}KB`, 'error');
        input.value = '';
        return;
    }

    const img = new Image();
    const reader = new FileReader();

    reader.onload = function (e) {
        img.onload = function () {
            if (img.width < 64 || img.height < 64) {
                showToast(`Image must be at least 64x64 pixels. Current size: ${img.width}x${img.height}`, 'error');
                input.value = '';
                return;
            }

            showToast(`Valid image: ${img.width}x${img.height}, ${(file.size / 1024).toFixed(1)}KB`, 'success');

            updateAdminImagePreview(previewId, e.target.result);

            input.fileData = e.target.result;
        };

        img.src = e.target.result;
    };

    reader.readAsDataURL(file);
}

function updateAdminImagePreview(previewId, src) {
    const preview = document.getElementById(previewId);
    if (!preview) return;

    const previewImg = preview.querySelector('img');
    if (previewImg) {
        previewImg.src = src;
        preview.style.display = 'block';
    }
}

function hideAdminImagePreview(previewId) {
    const preview = document.getElementById(previewId);
    if (preview) {
        preview.style.display = 'none';
        const img = preview.querySelector('img');
        if (img) {
            img.src = '';
        }
    }
}

function clearAdminImageUpload(modalType) {
    let uploadId, previewId;

    if (modalType === 'admin') {
        uploadId = 'adminImageUpload';
        previewId = 'adminImagePreview';
    } else {
        uploadId = 'editAdminImageUpload';
        previewId = 'editAdminImagePreview';
    }

    const upload = document.getElementById(uploadId);
    if (upload) {
        upload.value = '';
        upload.fileData = null;
    }

    hideAdminImagePreview(previewId);
}

async function handleCreateRole(e) {
    if (e && typeof e.preventDefault === 'function') e.preventDefault();

    console.debug('[Admin] Create Role clicked');

    const roleName = document.getElementById('adminRoleName').value;
    const slots = parseInt(document.getElementById('adminSlots').value);

    if(!roleName){ showError('Role name required'); return; }
    if(isNaN(slots)||slots<1){ showError('Slots invalid'); return; }

    const colorType = document.querySelector('input[name="adminColorType"]:checked').value;
    const color = {
        type: colorType,
        primary: document.getElementById('adminPrimaryColor').value,
        secondary: colorType === 'gradient' ? document.getElementById('adminSecondaryColor').value : ''
    };

    const iconType = document.querySelector('input[name="adminIconType"]:checked').value;
    let icon = { type: 'none' };

    if (iconType === 'emoji') {
        const emojiValue = document.getElementById('adminEmojiValue').value;
        if (emojiValue) {
            icon = { type: 'emoji', value: emojiValue };
        }
    } else if (iconType === 'custom') {
        const imageUpload = document.getElementById('adminImageUpload');
        if (imageUpload && imageUpload.fileData) {
            icon = { type: 'custom', value: imageUpload.fileData };
        }
    }

    const expiryType = document.querySelector('input[name="adminExpiryType"]:checked').value;
    let expiryDays = 0;
    let expiryHours = 0;

    if (expiryType === 'custom') {
        expiryDays = parseInt(document.getElementById('adminExpiryDays').value) || 0;
        expiryHours = parseInt(document.getElementById('adminExpiryHours').value) || 0;
    }

    const roleData = {
        name: roleName,
        color: color,
        icon: icon,
        slots: slots,
        expiry_type: expiryType,
        expiry_days: expiryDays,
        expiry_hours: expiryHours
    };

    const assignCheckbox = document.getElementById('adminAssignOnCreate');
    const userSearchInput = document.getElementById('adminUserSearch');
    const directIDCheckbox = document.getElementById('adminDirectID');
    const directIDInput = document.getElementById('adminDirectIDInput');

    if (assignCheckbox && assignCheckbox.checked) {
        let userID = null;

        if (directIDCheckbox && directIDCheckbox.checked && directIDInput && directIDInput.value.trim()) {
            userID = directIDInput.value.trim();
        } else if (userSearchInput && userSearchInput.dataset.userId) {
            userID = userSearchInput.dataset.userId;
        }

        if (userID) {
            roleData.assign_to_user_id = userID;
        } else {
            if (directIDCheckbox && directIDCheckbox.checked) {
            } else {
                showError('Please select a user or provide a Discord User ID');
                return;
            }
        }
    }

    const imageUpload = document.getElementById('adminImageUpload');

    try {
        const response = await fetch('/admin/roles', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(roleData)
        });

        const result = await response.json();

        if (response.ok) {
            showSuccess('Role created successfully!');
            bootstrap.Modal.getInstance(document.getElementById('createAdminRoleModal')).hide();
            resetCreateForm();
            loadRoles();
        } else {
            showError(result.error || 'Failed to create role');
        }
    } catch (error) {
        showError('Failed to create role');
    }
}

async function handleEditRole(e) {
    e.preventDefault();

    if (!currentEditingRoleId) {
        showError('No role selected for editing');
        return;
    }

    const roleName = document.getElementById('editAdminRoleName').value;
    const slots = parseInt(document.getElementById('editAdminSlots').value);

    const colorType = document.querySelector('input[name="editAdminColorType"]:checked').value;
    const color = {
        type: colorType,
        primary: document.getElementById('editAdminPrimaryColor').value,
        secondary: colorType === 'gradient' ? document.getElementById('editAdminSecondaryColor').value : ''
    };

    const iconType = document.querySelector('input[name="editAdminIconType"]:checked').value;
    let icon = { type: 'none' };

    if (iconType === 'emoji') {
        const emojiValue = document.getElementById('editAdminEmojiValue').value;
        if (emojiValue) {
            icon = { type: 'emoji', value: emojiValue };
        }
    } else if (iconType === 'custom') {
        const imageUpload = document.getElementById('editAdminImageUpload');
        if (imageUpload && imageUpload.fileData) {
            icon = { type: 'custom', value: imageUpload.fileData };
        } else if (currentEditingRoleData && currentEditingRoleData.icon && currentEditingRoleData.icon.type === 'custom') {
            if (currentEditingRoleData.icon.url) {
                icon = { type: 'custom', url: currentEditingRoleData.icon.url };
            } else if (currentEditingRoleData.icon.value) {
                icon = { type: 'custom', value: currentEditingRoleData.icon.value };
            }
        }
    }

    const expiryType = document.querySelector('input[name="editAdminExpiryType"]:checked').value;
    let expiryDays = 0;
    let expiryHours = 0;

    if (expiryType === 'custom') {
        expiryDays = parseInt(document.getElementById('editAdminExpiryDays').value) || 0;
        expiryHours = parseInt(document.getElementById('editAdminExpiryHours').value) || 0;
    }

    const roleData = {
        name: roleName,
        color: color,
        icon: icon,
        slots: slots,
        expiry_type: expiryType,
        expiry_days: expiryDays,
        expiry_hours: expiryHours
    };

    try {
        const response = await fetch(`/admin/roles/${currentEditingRoleId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(roleData)
        });

        const result = await response.json();

        if (response.ok) {
            showSuccess('Role updated successfully!');
            bootstrap.Modal.getInstance(document.getElementById('editAdminRoleModal')).hide();
            currentEditingRoleId = null;
            loadRoles();
        } else {
            showError(result.error || 'Failed to update role');
        }
    } catch (error) {
        showError('Failed to update role');
    }
}

function resetCreateForm() {
    document.getElementById('adminRoleName').value = '';
    document.getElementById('adminSlots').value = '2';

    document.getElementById('adminSolidColor').checked = true;
    document.getElementById('adminSecondaryColor').disabled = true;
    document.getElementById('adminPrimaryColor').value = '#3498db';
    document.getElementById('adminSecondaryColor').value = '#9b59b6';
    const createSecGroup = document.getElementById('adminSecondaryColorGroup');
    if (createSecGroup) createSecGroup.style.display = 'none';
    updateAdminColorPreview();

    document.getElementById('adminNoIcon').checked = true;
    document.getElementById('adminEmojiInput').style.display = 'none';
    document.getElementById('adminCustomImageInput').style.display = 'none';
    document.getElementById('adminEmojiValue').value = '';

    clearAdminImageUpload('admin');

    document.getElementById('adminNeverExpire').checked = true;
    document.getElementById('adminExpiryInputs').style.display = 'none';
    document.getElementById('adminExpiryDays').value = '30';
    document.getElementById('adminExpiryHours').value = '0';

    document.getElementById('adminAssignOnCreate').checked = false;
    document.getElementById('adminUserAssignment').style.display = 'none';
    document.getElementById('adminUserSearch').value = '';
    delete document.getElementById('adminUserSearch').dataset.userId;
    document.getElementById('adminUserPreview').style.display = 'none';
}

async function confirmAssignRole() {
    const userSearchInput = document.getElementById('adminGrantUserSearch');
    const userId = userSearchInput ? userSearchInput.dataset.userId : null;

    if (!userId) {
        showError('Please select a user');
        return;
    }

    if (!editingRoleId) {
        showError('No role selected');
        return;
    }

    try {
        const response = await fetch(`/admin/roles/${editingRoleId}/grant`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId })
        });

        const result = await response.json();

        if (response.ok) {
            showSuccess('Role assigned successfully!');
            bootstrap.Modal.getInstance(document.getElementById('adminGrantRoleModal')).hide();
            loadRoles();
            if (userSearchInput) {
                userSearchInput.value = '';
                delete userSearchInput.dataset.userId;
            }
            const confirmBtn = document.getElementById('adminConfirmGrantRoleBtn');
            if (confirmBtn) {
                confirmBtn.disabled = true;
            }
        } else {
            showError(result.error || 'Failed to assign role');
        }
    } catch (error) {
        showError('Failed to assign role');
    }
}

function assignRole(roleId) {
    editingRoleId = roleId;
    const role = currentRoles.find(r => r.id === roleId);

    if (role) {
        const titleElement = document.getElementById('adminGrantRoleName');
        if (titleElement) {
            titleElement.textContent = role.name;
        }

        const slotInfoElement = document.getElementById('grantRoleSlotInfo');
        if (slotInfoElement) {
            slotInfoElement.textContent = `${role.slots.used}/${role.slots.total} slots used`;
        }
    }

    const searchInput = document.getElementById('adminGrantUserSearch');
    if (searchInput) {
        searchInput.value = '';
        delete searchInput.dataset.userId;
    }

    const previewElement = document.getElementById('adminGrantUserPreview');
    if (previewElement) {
        previewElement.style.display = 'none';
    }

    const confirmBtn = document.getElementById('adminConfirmGrantRoleBtn');
    if (confirmBtn) {
        confirmBtn.disabled = true;
    }

    const modal = document.getElementById('adminGrantRoleModal');
    if (modal) {
        new bootstrap.Modal(modal).show();
    }
}

async function deleteRole(roleId) {
    const role = currentRoles.find(r => r.id === roleId);
    if (!role) {
        showError('Role not found');
        return;
    }

    if (!confirm(`Are you sure you want to delete the role "${role.name}"? This action cannot be undone and will remove the role from Discord.`)) {
        return;
    }

    try {
        const response = await fetch(`/admin/roles/${roleId}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showSuccess('Role deleted successfully!');
            loadRoles();
        } else {
            const result = await response.json();
            showError(result.error || 'Failed to delete role');
        }
    } catch (error) {
        showError('Failed to delete role');
    }
}

function editRole(roleId) {
    const role = currentRoles.find(r => r.id === roleId);
    if (!role) {
        showError('Role not found');
        return;
    }

    (function ensureEditColorInputs(){
        if(!document.getElementById('editAdminPrimaryColor')){
            const grp=document.getElementById('editAdminPrimaryColorGroup');
            if(grp){
                grp.innerHTML='';
                try { grp.appendChild(createColorInputGroup('editAdminPrimaryColor','Primary Color','#3498db',{onChange:updateEditColorPreview,hideInput:true})); } catch(e){ console.warn('Failed to rebuild primary color input',e); }
            }
        }
        if(!document.getElementById('editAdminSecondaryColor')){
            const grp2=document.getElementById('editAdminSecondaryColorContainer');
            if(grp2){
                grp2.innerHTML='';
                try { grp2.appendChild(createColorInputGroup('editAdminSecondaryColor','Secondary Color','#9b59b6',{onChange:updateEditColorPreview,hideInput:true})); } catch(e){ console.warn('Failed to rebuild secondary color input',e); }
            }
        }
    })();

    currentEditingRoleId = roleId;
    currentEditingRoleData = role;

    const nameEl=document.getElementById('editAdminRoleName'); if(nameEl) nameEl.value = role.name || '';
    const slotsEl=document.getElementById('editAdminSlots'); if(slotsEl) slotsEl.value = role.slots.total || 1;

    const gradRadio=document.getElementById('editAdminGradientColor');
    const solidRadio=document.getElementById('editAdminSolidColor');
    const primInput=document.getElementById('editAdminPrimaryColor');
    const secInput=document.getElementById('editAdminSecondaryColor');

    if (role.color && role.color.type === 'gradient') {
        if(gradRadio) gradRadio.checked = true;
        if(primInput) primInput.value = role.color.primary || '#3498db';
        if(secInput){ secInput.value = role.color.secondary || '#9b59b6'; secInput.disabled = false; }
    } else {
        if(solidRadio) solidRadio.checked = true;
        if(primInput) primInput.value = (role.color && role.color.primary) || '#3498db';
        if(secInput) secInput.disabled = true;
    }

    const emojiIconRadio=document.getElementById('editAdminEmojiIcon');
    const customIconRadio=document.getElementById('editAdminCustomIcon');
    const noIconRadio=document.getElementById('editAdminNoIcon');
    const emojiInputWrap=document.getElementById('editAdminEmojiInput');
    const customImageWrap=document.getElementById('editAdminCustomImageInput');
    const emojiValueEl=document.getElementById('editAdminEmojiValue');

    if (role.icon && role.icon.type === 'emoji' && role.icon.value !== '') {
        if(emojiIconRadio) emojiIconRadio.checked = true;
        if(emojiValueEl) emojiValueEl.value = role.icon.value;
        if(emojiInputWrap) emojiInputWrap.style.display = 'block';
        if(customImageWrap) customImageWrap.style.display = 'none';
    } else if (role.icon && role.icon.type === 'custom' && role.icon.url !== '') {
        if(customIconRadio) customIconRadio.checked = true;
        if(customImageWrap) customImageWrap.style.display = 'block';
        if(emojiInputWrap) emojiInputWrap.style.display = 'none';
        if (role.icon.url) {
            updateAdminImagePreview('editAdminImagePreview', role.icon.url);
        }
    } else {
        if(noIconRadio) noIconRadio.checked = true;
        if(emojiInputWrap) emojiInputWrap.style.display = 'none';
        if(customImageWrap) customImageWrap.style.display = 'none';
    }

    const customExpiryRadio=document.getElementById('editAdminCustomExpiry');
    const neverExpiryRadio=document.getElementById('editAdminNeverExpire');
    const expiryInputsWrap=document.getElementById('editAdminExpiryInputs');
    const expiryDaysEl=document.getElementById('editAdminExpiryDays');
    const expiryHoursEl=document.getElementById('editAdminExpiryHours');

    if (role.expires_at && role.expires_at !== '0001-01-01T00:00:00Z') {
        if(customExpiryRadio) customExpiryRadio.checked = true;
        if(expiryInputsWrap) expiryInputsWrap.style.display = 'block';
        const now = new Date();
        const expiryDate = new Date(role.expires_at);
        const diffMs = expiryDate - now;
        if (diffMs > 0) {
            const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
            const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            if(expiryDaysEl) expiryDaysEl.value = diffDays;
            if(expiryHoursEl) expiryHoursEl.value = diffHours;
        }
    } else {
        if(neverExpiryRadio) neverExpiryRadio.checked = true;
        if(expiryInputsWrap) expiryInputsWrap.style.display = 'none';
    }

    updateEditColorPreview();

    currentEditingRoleId = roleId;

    const modal = new bootstrap.Modal(document.getElementById('editAdminRoleModal'));
    modal.show();

    setTimeout(()=>{ syncSecondaryColorVisibility('editAdmin'); }, 30);
}

function updateEditColorPreview() {
    const preview = document.getElementById('editAdminColorPreview');
    if (!preview) return;

    const isGradient = document.getElementById('editAdminGradientColor').checked;
    const primaryColor = document.getElementById('editAdminPrimaryColor').value;
    const secondaryColor = document.getElementById('editAdminSecondaryColor').value;

    if (isGradient) {
        preview.style.background = `linear-gradient(45deg, ${primaryColor}, ${secondaryColor})`;
    } else {
        preview.style.background = primaryColor;
    }

    const primaryPreview = document.querySelector('[data-target="editAdminPrimaryColor"]');
    if (primaryPreview) {
        primaryPreview.style.backgroundColor = primaryColor;
    }

    const secondaryPreview = document.querySelector('[data-target="editAdminSecondaryColor"]');
    if (secondaryPreview) {
        secondaryPreview.style.backgroundColor = secondaryColor;
    }
}

function showLoading(containerId) {
    const container = document.getElementById(containerId);
    if (container) {
        container.innerHTML = `
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        `;
    }
}

function showSuccess(message) {
    showToast(message, 'success');
}

function showError(message) {
    showToast(message, 'danger');
}

function showToast(message, type) {
    const toastContainer = document.getElementById('toastContainer') || createToastContainer();

    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;

    toastContainer.appendChild(toast);

    const bsToast = new bootstrap.Toast(toast, { delay: 5000 });
    bsToast.show();

    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container position-fixed top-0 end-0 p-3';
    container.style.zIndex = '9999';
    document.body.appendChild(container);
    return container;
}

function setupRoleSearch() {
    const searchBtn = document.getElementById('searchRoleBtn');
    const searchInput = document.getElementById('roleSearchInput');
    const searchByNameBtn = document.getElementById('searchRoleByNameBtn');
    const searchByNameInput = document.getElementById('roleNameSearchInput');

    if (searchBtn) {
        searchBtn.addEventListener('click', handleRoleSearch);
    }

    if (searchInput) {
        searchInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                handleRoleSearch();
            }
        });
    }

    if (searchByNameBtn) {
        searchByNameBtn.addEventListener('click', handleRoleSearchByName);
    }

    if (searchByNameInput) {
        searchByNameInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                handleRoleSearchByName();
            }
        });
    }
}

function handleRoleSearch() {
    const searchInput = document.getElementById('roleSearchInput');
    const roleID = searchInput.value.trim();

    if (!roleID) {
        showToast('Please enter a role ID', 'warning');
        return;
    }

    const searchBtn = document.getElementById('searchRoleBtn');
    const originalText = searchBtn.innerHTML;
    searchBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Searching...';
    searchBtn.disabled = true;

    fetch(`/admin/search-role/${roleID}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showToast(data.error, 'error');
                hideRoleSearchResults();
            } else {
                displayRoleSearchResults(data);
            }
        })
        .catch(error => {
            showToast('Error searching for role', 'error');
            hideRoleSearchResults();
        })
        .finally(() => {
            searchBtn.innerHTML = originalText;
            searchBtn.disabled = false;
        });
}

function displayRoleSearchResults(data) {
    const resultsContainer = document.getElementById('roleSearchResults');
    const roleInfoContainer = document.getElementById('roleInfo');
    const roleMembersContainer = document.getElementById('roleMembers');

    currentRoleInfo = data.roleInfo;

    resultsContainer.style.display = 'block';

    const roleInfo = data.roleInfo;
    let roleInfoHTML = '';

    if (roleInfo.type === 'custom') {
        const expiryDate = new Date(roleInfo.expiresAt).toLocaleDateString();
        const createdDate = new Date(roleInfo.createdAt).toLocaleDateString();

        roleInfoHTML = `
            <div class="row">
                <div class="col-md-6">
                    <div class="card h-100">
                        <div class="card-body">
                            <h6 class="card-title">
                                <i class="fas fa-crown text-warning"></i> Custom Role
                            </h6>
                            <p class="card-text">
                                <strong>Name:</strong> ${roleInfo.name}<br>
                                <strong>Discord ID:</strong> <code>${roleInfo.discordID}</code><br>
                                <strong>Database ID:</strong> <code>${roleInfo.id}</code><br>
                                <strong>Owner:</strong> ${roleInfo.owner} (<code>${roleInfo.ownerID}</code>)<br>
                                <strong>Slots:</strong> ${roleInfo.slots.used}/${roleInfo.slots.total}<br>
                                <strong>Expires:</strong> ${expiryDate}<br>
                                <strong>Created:</strong> ${createdDate}
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card h-100">
                        <div class="card-body">
                            <h6 class="card-title">
                                <i class="fas fa-palette"></i> Visual Settings
                            </h6>
                            <div class="mb-2">
                                <strong>Color:</strong>
                                <div class="d-inline-block ms-2" style="width: 20px; height: 20px; background: ${roleInfo.color.type === 'gradient' ? `linear-gradient(135deg, ${roleInfo.color.primary}, ${roleInfo.color.secondary})` : roleInfo.color.primary}; border: 1px solid #ccc; border-radius: 3px;"></div>
                                <small class="text-muted ms-2">${roleInfo.color.primary}</small>
                            </div>
                            ${roleInfo.icon && roleInfo.icon.type === 'emoji' ? `
                                <div class="mb-2">
                                    <strong>Icon:</strong> ${roleInfo.icon.value}
                                </div>
                            ` : ''}
                            ${roleInfo.icon && roleInfo.icon.type === 'custom' && roleInfo.icon.url ? `
                                <div class="mb-2">
                                    <strong>Icon:</strong><br>
                                    <img src="${roleInfo.icon.url}" alt="Role icon" style="width: 32px; height: 32px; border-radius: 3px;">
                                </div>
                            ` : ''}
                        </div>
                    </div>
                </div>
            </div>
        `;
    } else {
        roleInfoHTML = `
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">
                        <i class="fab fa-discord text-primary"></i> Discord Server Role
                    </h6>
                    <p class="card-text">
                        <strong>Name:</strong> ${roleInfo.name}<br>
                        <strong>ID:</strong> <code>${roleInfo.id}</code><br>
                        <strong>Color:</strong> 
                        <div class="d-inline-block ms-2" style="width: 20px; height: 20px; background: ${roleInfo.color}; border: 1px solid #ccc; border-radius: 3px;"></div>
                        <small class="text-muted ms-2">${roleInfo.color}</small><br>
                        <strong>Position:</strong> ${roleInfo.position}
                    </p>
                </div>
            </div>
        `;
    }

    roleInfoContainer.innerHTML = roleInfoHTML;

    let membersHTML = '';
    if (data.members && data.members.length > 0) {
        membersHTML = data.members.map(member => {
            const avatarUrl = member.avatar
                ? `https://cdn.discordapp.com/avatars/${member.id}/${member.avatar}.png`
                : 'https://cdn.discordapp.com/embed/avatars/0.png';

            const displayName = member.display || member.nickname || member.username;
            const initials = displayName.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);

            return `
                <div class="admin-member-card">
                    <div class="admin-member-avatar">
                        ${member.avatar ? `<img src="${avatarUrl}" alt="Avatar" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">` : initials}
                    </div>
                    <div class="admin-member-info">
                        <div class="admin-member-name">${displayName}</div>
                        <div class="admin-member-id">${member.id}</div>
                    </div>
                    <button class="admin-member-remove" onclick="removeMemberFromRoleAdmin('${member.id}', '${displayName}', this)" title="Remove member">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
        }).join('');
    } else {
        membersHTML = `
            <div class="no-members-state">
                <div class="no-members-icon">
                    <i class="fas fa-users"></i>
                </div>
                <h4>No members found</h4>
                <p>This role has no members assigned to it</p>
            </div>
        `;
    }

    roleMembersContainer.innerHTML = membersHTML;
    
    const memberCountSpan = document.getElementById('memberCount');
    if (memberCountSpan) {
        memberCountSpan.textContent = data.count || 0;
    }
    
    const transferBtn = document.getElementById('transferRoleBtn');
    const removeAllBtn = document.getElementById('removeAllMembersBtn');
    
    if (roleInfo.type === 'custom') {
        if (transferBtn) {
            transferBtn.style.display = 'inline-block';
            transferBtn.onclick = () => showTransferRoleModal(roleInfo);
        }
        if (removeAllBtn && data.count > 0) {
            removeAllBtn.style.display = 'inline-block';
            removeAllBtn.onclick = () => removeAllMembersFromRole(roleInfo);
        }
    } else {
        if (transferBtn) transferBtn.style.display = 'none';
        if (removeAllBtn) removeAllBtn.style.display = 'none';
    }
}

let currentRoleInfo = null;

function handleRoleSearchByName() {
    const searchInput = document.getElementById('roleNameSearchInput');
    const roleName = searchInput.value.trim();

    if (!roleName || roleName.length < 2) {
        showToast('Please enter at least 2 characters', 'warning');
        return;
    }

    const searchBtn = document.getElementById('searchRoleByNameBtn');
    const originalText = searchBtn.innerHTML;
    searchBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Searching...';
    searchBtn.disabled = true;

    fetch(`/admin/search-roles-by-name?name=${encodeURIComponent(roleName)}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showToast(data.error, 'error');
                hideRoleNameSearchResults();
            } else {
                displayRoleNameSearchResults(data.roles || []);
            }
        })
        .catch(error => {
            showToast('Error searching for roles', 'error');
            hideRoleNameSearchResults();
        })
        .finally(() => {
            searchBtn.innerHTML = originalText;
            searchBtn.disabled = false;
        });
}

function displayRoleNameSearchResults(roles) {
    const resultsContainer = document.getElementById('roleNameSearchResults');
    const roleResultsContainer = document.getElementById('roleNameResults');
    const resultsCountEl = document.getElementById('resultsCount');
    
    if (resultsCountEl) {
        const currentCount = parseInt(resultsCountEl.textContent) || 0;
        animateValue(resultsCountEl, currentCount, roles.length, 500);
    }
    
    if (roles.length === 0) {
        roleResultsContainer.innerHTML = `
            <div class="no-results-state">
                <div class="no-results-icon">
                    <i class="fas fa-search"></i>
                </div>
                <h4>No roles found</h4>
                <p>Try adjusting your search terms</p>
            </div>
        `;
    } else {
        roleResultsContainer.innerHTML = roles.map(role => createSearchRoleCard(role)).join('');
    }
    
    resultsContainer.style.display = 'block';
}

function hideRoleNameSearchResults() {
    const resultsContainer = document.getElementById('roleNameSearchResults');
    if (resultsContainer) {
        resultsContainer.style.display = 'none';
    }
}

function selectRoleFromSearch(roleId) {
    const roleSearchInput = document.getElementById('roleSearchInput');
    if (roleSearchInput) {
        roleSearchInput.value = roleId;
        handleRoleSearch();
    }
}

function removeMemberFromRoleAdmin(userId, displayName, buttonElement) {
    if (!currentRoleInfo) {
        showToast('No role selected', 'error');
        return;
    }
    
    if (!confirm(`Are you sure you want to remove ${displayName} from this role?`)) {
        return;
    }
    
    const endpoint = currentRoleInfo.type === 'custom' 
        ? `/admin/roles/${currentRoleInfo.id}/remove-member/${userId}`
        : `/admin/discord-roles/${currentRoleInfo.id}/remove-member/${userId}`;
    
    fetch(endpoint, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            showToast(data.error, 'error');
        } else {
            showToast(`Removed ${displayName} from role`, 'success');
            const memberCard = buttonElement.closest('.admin-member-card');
            if (memberCard) {
                memberCard.remove();
            }
            const memberCountSpan = document.getElementById('memberCount');
            if (memberCountSpan) {
                const currentCount = parseInt(memberCountSpan.textContent) || 0;
                memberCountSpan.textContent = Math.max(0, currentCount - 1);
            }
        }
    })
    .catch(error => {
        showToast('Error removing member from role', 'error');
    });
}

function removeAllMembersFromRole(roleInfo) {
    if (!confirm(`Are you sure you want to remove ALL members from the role "${roleInfo.name}"? This action cannot be undone.`)) {
        return;
    }
    
    const endpoint = `/admin/roles/${roleInfo.id}/remove-all-members`;
    
    fetch(endpoint, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            showToast(data.error, 'error');
        } else {
            showToast(`Removed all members from role "${roleInfo.name}"`, 'success');
            handleRoleSearch();
        }
    })
    .catch(error => {
        showToast('Error removing all members from role', 'error');
    });
}

function showTransferRoleModal(roleInfo) {
    currentRoleInfo = roleInfo;
    
    const modal = new bootstrap.Modal(document.getElementById('transferRoleModal'));
    const currentRoleDiv = document.getElementById('transferCurrentRole');
    const targetUserInput = document.getElementById('transferTargetUser');
    
    targetUserInput.value = '';
    hideTransferUserSearch();
    
    currentRoleDiv.innerHTML = `
        <div class="d-flex align-items-center">
            <div class="me-3">
                <i class="fas fa-crown text-warning fa-2x"></i>
            </div>
            <div>
                <h6 class="mb-1">${roleInfo.name}</h6>
                <small class="text-muted">ID: <code>${roleInfo.id}</code></small>
                <br>
                <small class="text-muted">Current Owner: ${roleInfo.owner || 'Unknown'}</small>
            </div>
        </div>
    `;
    
    setupTransferUserSearch();
    
    modal.show();
}

function setupTransferUserSearch() {
    const targetUserInput = document.getElementById('transferTargetUser');
    const confirmBtn = document.getElementById('confirmTransferRoleBtn');
    
    let searchTimeout;
    
    targetUserInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        const query = this.value.trim();
        
        confirmBtn.disabled = true;
        hideTransferUserPreview();
        
        if (/^\d{17,19}$/.test(query)) {
            validateDiscordId(query, 'transfer');
            return;
        }
        
        if (query.length < 2) {
            hideTransferUserSearch();
            return;
        }
        
        searchTimeout = setTimeout(() => {
            searchUsersForTransfer(query);
        }, 300);
    });
    
    confirmBtn.addEventListener('click', handleTransferRole);
}

function searchUsersForTransfer(query) {
    fetch(`/admin/search-users?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            displayTransferUserSearchResults(data.users || []);
        })
        .catch(error => {
            console.error('Error searching users:', error);
        });
}

function displayTransferUserSearchResults(users) {
    const resultsContainer = document.getElementById('transferUserSearchResults');
    const usersList = document.getElementById('transferUsersList');
    
    if (users.length === 0) {
        hideTransferUserSearch();
        return;
    }
    
    usersList.innerHTML = users.map(user => {
        const avatarUrl = user.avatar 
            ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=32`
            : 'https://cdn.discordapp.com/embed/avatars/0.png';
            
        return `
            <div class="dropdown-item user-result" onclick="selectTransferUser('${user.id}', '${user.username}', '${user.display_name}', '${avatarUrl}')">
                <div class="d-flex align-items-center">
                    <img src="${avatarUrl}" alt="Avatar" class="rounded-circle me-2" width="32" height="32">
                    <div>
                        <div class="fw-bold">${user.username}</div>
                        <small class="text-muted">${user.display_name}</small>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    resultsContainer.style.display = 'block';
}

function selectTransferUser(userId, username, displayName, avatarUrl) {
    const targetUserInput = document.getElementById('transferTargetUser');
    targetUserInput.value = userId;
    
    showTransferUserPreview(userId, username, displayName, avatarUrl);
    hideTransferUserSearch();
    
    const confirmBtn = document.getElementById('confirmTransferRoleBtn');
    confirmBtn.disabled = false;
}

function showTransferUserPreview(userId, username, displayName, avatarUrl) {
    const previewContainer = document.getElementById('transferUserPreview');
    const userNameDiv = document.getElementById('transferSelectedUserName');
    const userIdDiv = document.getElementById('transferSelectedUserID');
    const avatarImg = document.getElementById('transferSelectedUserAvatar');
    const avatarIcon = document.getElementById('transferSelectedUserIcon');
    
    userNameDiv.textContent = displayName || username;
    userIdDiv.textContent = userId;
    
    if (avatarUrl && avatarUrl !== 'https://cdn.discordapp.com/embed/avatars/0.png') {
        avatarImg.src = avatarUrl;
        avatarImg.style.display = 'block';
        avatarIcon.style.display = 'none';
    } else {
        avatarImg.style.display = 'none';
        avatarIcon.style.display = 'block';
    }
    
    previewContainer.style.display = 'block';
}

function hideTransferUserPreview() {
    const previewContainer = document.getElementById('transferUserPreview');
    if (previewContainer) {
        previewContainer.style.display = 'none';
    }
}

function hideTransferUserSearch() {
    const resultsContainer = document.getElementById('transferUserSearchResults');
    if (resultsContainer) {
        resultsContainer.style.display = 'none';
    }
}

function validateDiscordId(discordId, prefix) {
    if (prefix === 'transfer') {
        const confirmBtn = document.getElementById('confirmTransferRoleBtn');
        if (/^\d{17,19}$/.test(discordId)) {
            showTransferUserPreview(discordId, 'Discord User', `User ID: ${discordId}`, '');
            confirmBtn.disabled = false;
        } else {
            confirmBtn.disabled = true;
        }
    }
}

function handleTransferRole() {
    if (!currentRoleInfo) {
        showToast('No role selected', 'error');
        return;
    }
    
    const targetUserInput = document.getElementById('transferTargetUser');
    const newOwnerId = targetUserInput.value.trim();
    
    if (!newOwnerId) {
        showToast('Please select a target user', 'warning');
        return;
    }
    
    const confirmBtn = document.getElementById('confirmTransferRoleBtn');
    const originalText = confirmBtn.innerHTML;
    confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Transferring...';
    confirmBtn.disabled = true;
    
    fetch(`/admin/roles/${currentRoleInfo.id}/transfer`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            new_owner_id: newOwnerId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            showToast(data.error, 'error');
        } else {
            showToast(`Role "${currentRoleInfo.name}" transferred successfully`, 'success');
            const modal = bootstrap.Modal.getInstance(document.getElementById('transferRoleModal'));
            modal.hide();
            handleRoleSearch();
        }
    })
    .catch(error => {
        showToast('Error transferring role', 'error');
    })
    .finally(() => {
        confirmBtn.innerHTML = originalText;
        confirmBtn.disabled = false;
    });
}

function viewRoleMembers(roleId) {
    const roleSearchInput = document.getElementById('roleSearchInput');
    if (roleSearchInput) {
        roleSearchInput.value = roleId;
        handleRoleSearch();
        
        setTimeout(() => {
            const resultsSection = document.getElementById('roleSearchResults');
            if (resultsSection) {
                resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }, 500);
    }
}

function transferRoleOwnership(roleId) {
    fetch(`/admin/search-role/${roleId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showToast(data.error, 'error');
            } else {
                showTransferRoleModal(data.roleInfo);
            }
        })
        .catch(error => {
            showToast('Error loading role information', 'error');
        });
}

function quickRoleInfo(roleId) {
    fetch(`/admin/search-role/${roleId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showToast(data.error, 'error');
            } else {
                showQuickRoleInfoModal(data.roleInfo, data.members, data.count);
            }
        })
        .catch(error => {
            showToast('Error loading role information', 'error');
        });
}

function showQuickRoleInfoModal(roleInfo, members, memberCount) {
    const modalId = 'quickRoleInfoModal';
    let modal = document.getElementById(modalId);
    
    if (modal) {
        modal.remove();
    }
    
    const expiryDate = roleInfo.expiresAt ? new Date(roleInfo.expiresAt).toLocaleDateString() : 'Never';
    const createdDate = roleInfo.createdAt ? new Date(roleInfo.createdAt).toLocaleDateString() : 'Unknown';
    
    const colorDisplay = roleInfo.color.type === 'gradient'
        ? `linear-gradient(135deg, ${roleInfo.color.primary}, ${roleInfo.color.secondary})`
        : roleInfo.color.primary;
    
    const iconDisplay = roleInfo.icon && roleInfo.icon.type === 'emoji'
        ? roleInfo.icon.value
        : roleInfo.icon && roleInfo.icon.type === 'custom'
            ? `<img src="${roleInfo.icon.value}" alt="" width="24" height="24">`
            : '<i class="fas fa-cog text-muted"></i>';
    
    const modalHTML = `
        <div class="modal fade" id="${modalId}" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title d-flex align-items-center">
                            <div class="me-3 rounded-circle d-flex align-items-center justify-content-center" 
                                 style="width: 40px; height: 40px; background: ${colorDisplay}; border: 2px solid rgba(255,255,255,0.3);">
                                ${iconDisplay}
                            </div>
                            ${roleInfo.name}
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card border-0 bg-light">
                                    <div class="card-body">
                                        <h6 class="card-title"><i class="fas fa-info-circle text-primary"></i> Role Details</h6>
                                        <table class="table table-sm table-borderless">
                                            <tr><td class="fw-bold">Discord ID:</td><td><code>${roleInfo.discordID || roleInfo.id}</code></td></tr>
                                            ${roleInfo.type === 'custom' ? `<tr><td class="fw-bold">Database ID:</td><td><code>${roleInfo.id}</code></td></tr>` : ''}
                                            ${roleInfo.owner ? `<tr><td class="fw-bold">Owner:</td><td>${roleInfo.owner}</td></tr>` : ''}
                                            <tr><td class="fw-bold">Created:</td><td>${createdDate}</td></tr>
                                            <tr><td class="fw-bold">Expires:</td><td>${expiryDate}</td></tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card border-0 bg-light">
                                    <div class="card-body">
                                        <h6 class="card-title"><i class="fas fa-users text-success"></i> Member Info</h6>
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span>Total Members:</span>
                                            <span class="badge bg-primary">${memberCount}</span>
                                        </div>
                                        ${roleInfo.slots ? `
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <span>Slot Usage:</span>
                                                <span class="badge bg-secondary">${roleInfo.slots.used}/${roleInfo.slots.total}</span>
                                            </div>
                                            <div class="progress mb-2" style="height: 8px;">
                                                <div class="progress-bar" style="width: ${(roleInfo.slots.used / roleInfo.slots.total) * 100}%"></div>
                                            </div>
                                        ` : ''}
                                        ${roleInfo.color ? `
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span>Color:</span>
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2 rounded" style="width: 20px; height: 20px; background: ${colorDisplay}; border: 1px solid #ccc;"></div>
                                                    <code class="small">${roleInfo.color.primary}</code>
                                                </div>
                                            </div>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        ${members && members.length > 0 ? `
                            <div class="mt-3">
                                <h6><i class="fas fa-users"></i> Recent Members (${Math.min(members.length, 6)} of ${memberCount})</h6>
                                <div class="row">
                                    ${members.slice(0, 6).map(member => {
                                        const avatarUrl = member.avatar 
                                            ? `https://cdn.discordapp.com/avatars/${member.id}/${member.avatar}.png`
                                            : 'https://cdn.discordapp.com/embed/avatars/0.png';
                                        const displayName = member.display || member.nickname || member.username;
                                        
                                        return `
                                            <div class="col-md-4 mb-2">
                                                <div class="d-flex align-items-center">
                                                    <img src="${avatarUrl}" alt="Avatar" class="rounded-circle me-2" style="width: 32px; height: 32px;">
                                                    <div>
                                                        <div class="small fw-bold">${displayName}</div>
                                                        <div class="text-muted" style="font-size: 0.75rem;">${member.id.substring(0, 8)}...</div>
                                                    </div>
                                                </div>
                                            </div>
                                        `;
                                    }).join('')}
                                </div>
                                ${members.length > 6 ? `<small class="text-muted">and ${members.length - 6} more...</small>` : ''}
                            </div>
                        ` : ''}
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="viewRoleMembers('${roleInfo.id}'); bootstrap.Modal.getInstance(document.getElementById('${modalId}')).hide();">
                            <i class="fas fa-users"></i> View Full Member List
                        </button>
                        ${roleInfo.type === 'custom' ? `
                            <button type="button" class="btn btn-warning" onclick="transferRoleOwnership('${roleInfo.id}'); bootstrap.Modal.getInstance(document.getElementById('${modalId}')).hide();">
                                <i class="fas fa-exchange-alt"></i> Transfer
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const modalElement = document.getElementById(modalId);
    const bsModal = new bootstrap.Modal(modalElement);
    bsModal.show();
    
    modalElement.addEventListener('hidden.bs.modal', function () {
        modalElement.remove();
    });
}

function hideRoleSearchResults() {
    const resultsContainer = document.getElementById('roleSearchResults');
    resultsContainer.style.display = 'none';
}

window.removeMemberFromRoleAdmin = removeMemberFromRoleAdmin;
