class CustomColorPicker {
    constructor(){
        this.currentTarget=null; this.currentColor='#007BFF'; this.callbacks={}; this.isOpen=false;
        this.presetColors=['#FF5555','#FF884D','#FFBB33','#FFE066','#66CC66','#33CCCC','#3399FF','#9966FF','#FBB0DE','#FF99CC','#555555','#888888','#BBBBBB','#FFFFFF'];
        this._focusBypass=(e)=>{ if(!this.isOpen) return; if(this.modal&&this.modal.contains(e.target)) e.stopPropagation(); };
        this._build();
    }
    _build(){
        const m=document.createElement('div'); m.className='custom-color-picker-modal'; m.id='customColorPickerModal';
        m.innerHTML=`<div class="color-picker-dialog simple"><div class="color-picker-header"><h3 class="color-picker-title">Pick Color</h3><button type="button" class="color-picker-close" aria-label="Close">&times;</button></div><div class="color-picker-content simple"><div class="color-preview-large" id="cpPreview"><div id="cpPreviewText" class="cp-preview-overlay">#007BFF</div></div><div class="simple-rgb-grid"><label class="cp-field" data-field="r"><span class="cp-label">R</span><input id="cpR" class="simple-rgb" type="text" value="0" autocomplete="off" inputmode="numeric"></label><label class="cp-field" data-field="g"><span class="cp-label">G</span><input id="cpG" class="simple-rgb" type="text" value="0" autocomplete="off" inputmode="numeric"></label><label class="cp-field" data-field="b"><span class="cp-label">B</span><input id="cpB" class="simple-rgb" type="text" value="0" autocomplete="off" inputmode="numeric"></label><label class="cp-field hex-label" data-field="hex"><span class="cp-label">Hex</span><div class="cp-hex-wrap">#<input id="cpHex" class="simple-hex" type="text" value="007BFF" maxlength="6" autocomplete="off" spellcheck="false"><button type="button" class="cp-copy" title="Copy Hex" aria-label="Copy Hex">⧉</button></div></label></div><div class="simple-presets">${this.presetColors.map(c=>`<button type="button" class="preset-btn" data-color="${c}" style="--swatch:${c}"></button>`).join('')}</div></div><div class="color-picker-actions"><button type="button" class="color-picker-btn cancel">Cancel</button><button type="button" class="color-picker-btn apply">Apply</button></div></div>`;
        document.body.appendChild(m); this.modal=m; this._wire();
    }
    _wire(){
        const q=s=>this.modal.querySelector(s);
        q('.color-picker-close').onclick=()=>this.close(); q('.color-picker-btn.cancel').onclick=()=>this.close(); q('.color-picker-btn.apply').onclick=()=>this._apply();
        this.modal.addEventListener('click',e=>{ if(e.target===this.modal) this.close(); });
        ['cpR','cpG','cpB','cpHex'].forEach(id=>{ const el=q('#'+id); if(!el) return; el.oninput=()=>this._onInput(id); el.onfocus=()=>setTimeout(()=>el.select(),0); });
        this.modal.querySelectorAll('.preset-btn').forEach(b=>b.addEventListener('click',()=>this.setColor(b.dataset.color)));
        const copyBtn=this.modal.querySelector('.cp-copy'); if(copyBtn){ copyBtn.addEventListener('click',()=>{ if(navigator.clipboard){ navigator.clipboard.writeText(this.currentColor).then(()=>{ copyBtn.classList.add('ok'); setTimeout(()=>copyBtn.classList.remove('ok'),900); }); } }); }
        const preview=this.modal.querySelector('#cpPreview'); if(preview){ preview.addEventListener('click',()=>{ const overlay=this.modal.querySelector('#cpPreviewText'); if(overlay){ overlay.classList.toggle('dim'); } }); }
    }
    _onInput(id){
        if(id==='cpHex'){
            const hexEl=this.modal.querySelector('#cpHex');
            hexEl.value=hexEl.value.replace(/[^0-9a-fA-F]/g,'').toUpperCase();
            if(hexEl.value.length===6){ this.setColor('#'+hexEl.value,false); hexEl.classList.remove('invalid'); }
            else hexEl.classList.add('invalid');
            return;
        }
        const r=this._clean(this.modal.querySelector('#cpR').value);
        const g=this._clean(this.modal.querySelector('#cpG').value);
        const b=this._clean(this.modal.querySelector('#cpB').value);
        this.modal.querySelector('#cpR').value=r; this.modal.querySelector('#cpG').value=g; this.modal.querySelector('#cpB').value=b;
        if(r!==''&&g!==''&&b!==''){ const hex=this._rgbToHex(r,g,b); this.currentColor=hex; this.modal.querySelector('#cpHex').value=hex.slice(1); this._preview(); this._markPreset(); }
    }
    _clean(v){ v=v.replace(/[^0-9]/g,''); if(v==='') return ''; let n=parseInt(v,10); if(n>255) n=255; return String(n); }
    setColor(hex,upd=true){ if(!hex) return; if(!hex.startsWith('#')) hex='#'+hex; if(!/^#[0-9A-Fa-f]{6}$/.test(hex)) return; this.currentColor=hex.toUpperCase(); if(upd){ const {r,g,b}=this._hexToRGB(hex); this.modal.querySelector('#cpR').value=r; this.modal.querySelector('#cpG').value=g; this.modal.querySelector('#cpB').value=b; this.modal.querySelector('#cpHex').value=hex.slice(1);} this._preview(); this._markPreset(); }
    _preview(){ const p=this.modal.querySelector('#cpPreview'); if(p) p.style.background=this.currentColor; const t=this.modal.querySelector('#cpPreviewText'); if(t) t.textContent=this.currentColor; }
    _markPreset(){ const btns=this.modal.querySelectorAll('.preset-btn'); btns.forEach(b=>b.classList.remove('active')); const match=[...btns].find(b=>b.dataset.color.toUpperCase()===this.currentColor); if(match) match.classList.add('active'); }
    open(target,color='#007BFF',opts={}){ this.currentTarget=target; this.callbacks=opts; this.isOpen=true; this.modal.classList.add('show'); if(!this._focusHooked){ document.addEventListener('focusin',this._focusBypass,true); this._focusHooked=true; } this.setColor(color); if(opts.title) this.modal.querySelector('.color-picker-title').textContent=opts.title; setTimeout(()=>{ const r=this.modal.querySelector('#cpR'); if(r){ r.focus(); r.select(); }},20); }
    close(){ this.modal.classList.remove('show'); this.isOpen=false; this.currentTarget=null; if(this._focusHooked){ document.removeEventListener('focusin',this._focusBypass,true); this._focusHooked=false; } }
    _apply(){ if(this.currentTarget&&this.callbacks.onApply) this.callbacks.onApply(this.currentColor,this.currentTarget); this.close(); }
    _hexToRGB(h){ return { r:parseInt(h.slice(1,3),16), g:parseInt(h.slice(3,5),16), b:parseInt(h.slice(5,7),16) }; }
    _rgbToHex(r,g,b){ const toH=n=>('0'+Number(n).toString(16)).slice(-2).toUpperCase(); return '#'+toH(r)+toH(g)+toH(b); }
}

function createColorInputGroup(id, label, defaultColor = '#007bff', options = {}) {
    const container = document.createElement('div');
    container.className = 'color-input-group';
    
    const preview = document.createElement('div');
    preview.className = 'color-preview';
    preview.style.backgroundColor = defaultColor;
    preview.dataset.target = id;
    
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'color-input-field';
    input.id = id;
    input.value = defaultColor.toUpperCase();
    input.placeholder = '#007BFF';
    input.maxLength = 7;
    
    if (options.hideInput) {
        input.style.display = 'none';
    }
    
    const labelElement = document.createElement('label');
    labelElement.textContent = label;
    labelElement.htmlFor = id;
    labelElement.className = 'form-label';
    
    input.addEventListener('input', function() {
        let value = this.value.trim();
        if (!value.startsWith('#')) {
            value = '#' + value;
        }
        
        if (/^#[0-9A-Fa-f]{6}$/.test(value)) {
            preview.style.backgroundColor = value;
            this.value = value.toUpperCase();
            
            const event = new Event('change', { bubbles: true });
            this.dispatchEvent(event);
        }
    });
    
    preview.addEventListener('click', function() {
        if (window.colorPicker) {
            window.colorPicker.open(this, input.value, {
                title: `Choose ${label}`,
                onApply: (color, target) => {
                    input.value = color.toUpperCase();
                    preview.style.backgroundColor = color;
                    
                    const event = new Event('change', { bubbles: true });
                    input.dispatchEvent(event);
                    
                    if (options.onChange) {
                        options.onChange(color);
                    }
                }
            });
        }
    });
    
    container.appendChild(labelElement);
    container.appendChild(preview);
    container.appendChild(input);
    
    return container;
}

document.addEventListener('DOMContentLoaded', function() {
    if (!window.colorPicker) {
        window.colorPicker = new CustomColorPicker();
    }
    if (!window.__colorPickerDebug) {
        window.__colorPickerDebug = () => {
            const ids = ['redValue','greenValue','blueValue','hexColorInput'];
            const rows = ids.map(id => {
                const el = document.getElementById(id);
                if (!el) return `${id}: missing`;
                const cs = getComputedStyle(el);
                return `${id}: ro=${el.readOnly} dis=${el.disabled} pe=${cs.pointerEvents} vis=${cs.visibility} disp=${cs.display}`;
            }).join('\n');
            console.log('[ColorPickerDebug]\n' + rows);
        };
        window.addEventListener('keydown', (e) => {
            if (e.altKey && e.key === 'C') { window.__colorPickerDebug(); }
        });
    }
});

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { CustomColorPicker, createColorInputGroup };
}
