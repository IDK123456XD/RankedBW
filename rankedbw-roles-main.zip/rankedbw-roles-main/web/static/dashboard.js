let isCreatingRole = false;
let eventListenersSetup = false;
let currentColorTarget = null;

function showCustomAlert(message, type = 'info', title = null) {
    return new Promise((resolve) => {
        const existingAlert = document.querySelector('.custom-alert-overlay');
        if (existingAlert) {
            existingAlert.remove();
        }

        const overlay = document.createElement('div');
        overlay.className = 'custom-alert-overlay';

        const defaults = {
            success: { title: 'Success', icon: 'fas fa-check-circle' },
            error: { title: 'Error', icon: 'fas fa-times-circle' },
            warning: { title: 'Warning', icon: 'fas fa-exclamation-triangle' },
            info: { title: 'Information', icon: 'fas fa-info-circle' }
        };

        const alertTitle = title || defaults[type].title;
        const alertIcon = defaults[type].icon;

        overlay.innerHTML = `
            <div class="custom-alert">
                <div class="custom-alert-icon ${type}">
                    <i class="${alertIcon}"></i>
                </div>
                <div class="custom-alert-title">${alertTitle}</div>
                <div class="custom-alert-message">${message}</div>
                <div class="custom-alert-buttons">
                    <button class="custom-alert-btn primary" onclick="closeCustomAlert(true)">OK</button>
                </div>
            </div>
        `;

        document.body.appendChild(overlay);

        setTimeout(() => {
            overlay.classList.add('show');
        }, 10);

        overlay.resolve = resolve;
    });
}

function showCustomConfirm(message, title = 'Confirm') {
    return new Promise((resolve) => {
        const existingAlert = document.querySelector('.custom-alert-overlay');
        if (existingAlert) {
            existingAlert.remove();
        }

        const overlay = document.createElement('div');
        overlay.className = 'custom-alert-overlay';

        overlay.innerHTML = `
            <div class="custom-alert">
                <div class="custom-alert-icon warning">
                    <i class="fas fa-question-circle"></i>
                </div>
                <div class="custom-alert-title">${title}</div>
                <div class="custom-alert-message">${message}</div>
                <div class="custom-alert-buttons">
                    <button class="custom-alert-btn secondary" onclick="closeCustomAlert(false)">Cancel</button>
                    <button class="custom-alert-btn primary" onclick="closeCustomAlert(true)">Confirm</button>
                </div>
            </div>
        `;

        document.body.appendChild(overlay);

        setTimeout(() => {
            overlay.classList.add('show');
        }, 10);

        overlay.resolve = resolve;
    });
}

function showCustomInput(message, title = 'Enter Information', placeholder = '') {
    return new Promise((resolve) => {
        const existingAlert = document.querySelector('.custom-alert-overlay');
        if (existingAlert) {
            existingAlert.remove();
        }

        const overlay = document.createElement('div');
        overlay.className = 'custom-alert-overlay';

        overlay.innerHTML = `
            <div class="custom-alert">
                <div class="custom-alert-icon info">
                    <i class="fas fa-edit"></i>
                </div>
                <div class="custom-alert-title">${title}</div>
                <div class="custom-alert-message">${message}</div>
                <div class="custom-alert-input" style="margin: 1rem 0;">
                    <input type="text" class="form-control" id="customInputField" placeholder="${placeholder}" style="background: var(--bg-input); border: 1px solid var(--border-color); color: var(--text-primary); padding: 0.75rem; border-radius: 6px; width: 100%;">
                </div>
                <div class="custom-alert-buttons">
                    <button class="custom-alert-btn secondary" onclick="closeCustomInput(null)">Cancel</button>
                    <button class="custom-alert-btn primary" onclick="closeCustomInput('submit')">OK</button>
                </div>
            </div>
        `;

        document.body.appendChild(overlay);

        setTimeout(() => {
            overlay.classList.add('show');
            const input = overlay.querySelector('#customInputField');
            if (input) {
                input.focus();
                input.addEventListener('keypress', function (e) {
                    if (e.key === 'Enter') {
                        closeCustomInput('submit');
                    }
                });
            }
        }, 10);

        overlay.resolve = resolve;
    });
}

function closeCustomInput(action) {
    const overlay = document.querySelector('.custom-alert-overlay');
    if (overlay) {
        let result = null;
        if (action === 'submit') {
            const input = overlay.querySelector('#customInputField');
            result = input ? input.value : null;
        }

        overlay.classList.remove('show');
        setTimeout(() => {
            if (overlay.resolve) {
                overlay.resolve(result);
            }
            overlay.remove();
        }, 300);
    }
}

function closeCustomAlert(result) {
    const overlay = document.querySelector('.custom-alert-overlay');
    if (overlay) {
        overlay.classList.remove('show');
        setTimeout(() => {
            if (overlay.resolve) {
                overlay.resolve(result);
            }
            overlay.remove();
        }, 300);
    }
}

document.addEventListener('DOMContentLoaded', function () {
    initializeCustomColorPickers();
    setupEventListeners();
    initializeColorPreview();
    initializeIconHandlers();
    initializeEmojiPicker();
    initializeCustomColorPicker();
    checkPurchaseStatus();
});

function initializeCustomColorPickers() {
    const primaryGroup = document.getElementById('primaryColorGroup');
    if (primaryGroup) {
        const primaryPicker = createColorInputGroup('primaryColor', 'Primary Color', '#5865f2', {
            onChange: updateColorPreview,
            hideInput: true
        });
        primaryGroup.appendChild(primaryPicker);
    }

    const secondaryContainer = document.getElementById('secondaryColorContainer');
    if (secondaryContainer) {
        const secondaryPicker = createColorInputGroup('secondaryColor', 'Secondary Color', '#7289da', {
            onChange: updateColorPreview,
            hideInput: true
        });
        secondaryContainer.appendChild(secondaryPicker);
        
        const secondaryInput = secondaryContainer.querySelector('#secondaryColor');
        const secondaryPreview = secondaryContainer.querySelector('.color-preview');
        if (secondaryInput && secondaryPreview) {
            secondaryInput.disabled = true;
            secondaryPreview.style.opacity = '0.5';
            secondaryPreview.style.pointerEvents = 'none';
        }
    }

    const editPrimaryGroup = document.getElementById('editPrimaryColorGroup');
    if (editPrimaryGroup) {
        const editPrimaryPicker = createColorInputGroup('editPrimaryColor', 'Primary Color', '#5865f2', {
            onChange: updateColorPreview,
            hideInput: true
        });
        editPrimaryGroup.appendChild(editPrimaryPicker);
    }

    const editSecondaryContainer = document.getElementById('editSecondaryColorContainer');
    if (editSecondaryContainer) {
        const editSecondaryPicker = createColorInputGroup('editSecondaryColor', 'Secondary Color', '#7289da', {
            onChange: updateColorPreview,
            hideInput: true
        });
        editSecondaryContainer.appendChild(editSecondaryPicker);
        
        const editSecondaryInput = editSecondaryContainer.querySelector('#editSecondaryColor');
        const editSecondaryPreview = editSecondaryContainer.querySelector('.color-preview');
        if (editSecondaryInput && editSecondaryPreview) {
            editSecondaryInput.disabled = true;
            editSecondaryPreview.style.opacity = '0.5';
            editSecondaryPreview.style.pointerEvents = 'none';
        }
    }
}

function showCreateModal() {
    if (!window.editingRoleId) {
        resetCreateModal();
    }

    const modal = document.getElementById('createRoleModal');
    if (modal) {
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
        
        setTimeout(() => {
            updateColorPreview();
        }, 100);
    }
}

function resetCreateModal() {
    const form = document.getElementById('createRoleForm');
    if (form) {
        form.reset();
    }

    document.getElementById('solidColor').checked = true;
    document.getElementById('noIcon').checked = true;
    
    const primaryInput = document.getElementById('primaryColor');
    const secondaryInput = document.getElementById('secondaryColor');
    if (primaryInput) primaryInput.value = '#5865f2';
    if (secondaryInput) secondaryInput.value = '#7289da';

    handleColorTypeChange('solid');
    handleIconTypeChange('none');

    updateColorPreview();
    clearImagePreview();

    const modalTitle = document.querySelector('.modal-title');
    if (modalTitle) modalTitle.textContent = 'Create New Role';
    
    const createRoleBtnText = document.getElementById('createRoleBtnText');
    if (createRoleBtnText) createRoleBtnText.textContent = 'Create Role';

    window.editingRoleId = null;
}

function hideCreateModal() {
    const modal = document.getElementById('createRoleModal');
    if (modal) {
        const bsModal = bootstrap.Modal.getInstance(modal);
        if (bsModal) {
            bsModal.hide();
        }
    }
}

function setupEventListeners() {
    if (eventListenersSetup) {
        return;
    }

    document.querySelectorAll('input[name="colorType"]').forEach(radio => {
        radio.addEventListener('change', function () {
            handleColorTypeChange(this.value);
        });
    });

    document.querySelectorAll('input[name="iconType"]').forEach(radio => {
        radio.addEventListener('change', function () {
            handleIconTypeChange(this.value);
        });
    });

    const fileInput = document.getElementById('imageUpload');
    if (fileInput) {
        fileInput.addEventListener('change', handleFileUpload);
    }

    const removeImageBtn = document.getElementById('removeImageBtn');
    if (removeImageBtn) {
        removeImageBtn.addEventListener('click', function () {
            clearImagePreview();
        });
    }

    setupRoleActionHandlers();

    eventListenersSetup = true;
}

function handleColorTypeChange(colorType) {
    const secondaryColorGroup = document.getElementById('secondaryColorGroup');
    const secondaryInput = document.getElementById('secondaryColor');
    const secondaryContainer = document.getElementById('secondaryColorContainer');

    if (colorType === 'gradient') {
        if (secondaryColorGroup) secondaryColorGroup.style.display = 'block';
        if (secondaryInput) secondaryInput.disabled = false;
        if (secondaryContainer) {
            const preview = secondaryContainer.querySelector('.color-preview');
            if (preview) {
                preview.style.opacity = '1';
                preview.style.pointerEvents = 'auto';
            }
        }
    } else {
        if (secondaryColorGroup) secondaryColorGroup.style.display = 'none';
        if (secondaryInput) secondaryInput.disabled = true;
        if (secondaryContainer) {
            const preview = secondaryContainer.querySelector('.color-preview');
            if (preview) {
                preview.style.opacity = '0.5';
                preview.style.pointerEvents = 'none';
            }
        }
    }

    updateColorPreview();
}

function handleIconTypeChange(iconType) {
    const emojiGroup = document.getElementById('emojiInput');
    const customIconGroup = document.getElementById('customImageInput');

    if (emojiGroup) emojiGroup.style.display = 'none';
    if (customIconGroup) customIconGroup.style.display = 'none';

    if (iconType !== 'emoji') {
        const emojiValue = document.getElementById('emojiValue');
        if (emojiValue) emojiValue.value = '';
    }

    if (iconType !== 'custom') {
        const imageInput = document.getElementById('imageInput');
        if (imageInput) {
            imageInput.value = '';
            clearImagePreview();
        }
    }

    if (iconType === 'emoji' && emojiGroup) {
        emojiGroup.style.display = 'block';
    } else if (iconType === 'custom' && customIconGroup) {
        customIconGroup.style.display = 'block';
    }
}

function updateColorPreview() {
    const colorType = document.querySelector('input[name="colorType"]:checked')?.value || 'solid';
    const primaryColor = document.getElementById('primaryColor')?.value || '#5865f2';
    const secondaryColor = document.getElementById('secondaryColor')?.value || '#7289da';
    const preview = document.getElementById('colorPreview');

    if (!preview) return;

    if (colorType === 'gradient') {
        preview.style.background = `linear-gradient(45deg, ${primaryColor}, ${secondaryColor})`;
    } else {
        preview.style.background = primaryColor;
    }
    
    const primaryPreview = document.querySelector('[data-target="primaryColor"]');
    if (primaryPreview) {
        primaryPreview.style.backgroundColor = primaryColor;
    }
    
    const secondaryPreview = document.querySelector('[data-target="secondaryColor"]');
    if (secondaryPreview) {
        secondaryPreview.style.backgroundColor = secondaryColor;
    }
}

function initializeColorPreview() {
    updateColorPreview();
}

function initializeIconHandlers() {
    handleColorTypeChange('solid');
    handleIconTypeChange('none');
}

function openCustomColorPicker(targetId) {
    currentColorTarget = targetId;
    const currentColor = document.getElementById(targetId).value;

    const rgb = hexToRgb(currentColor);

    document.getElementById('redSlider').value = rgb.r;
    document.getElementById('greenSlider').value = rgb.g;
    document.getElementById('blueSlider').value = rgb.b;

    updateColorDisplay();

    const modal = document.getElementById('customColorPickerModal');
    if (modal) {
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
    }
}

function selectPresetColor(color) {
    const rgb = hexToRgb(color);

    document.getElementById('redSlider').value = rgb.r;
    document.getElementById('greenSlider').value = rgb.g;
    document.getElementById('blueSlider').value = rgb.b;

    updateColorDisplay();
}

function updateColorDisplay() {
    const r = parseInt(document.getElementById('redSlider').value);
    const g = parseInt(document.getElementById('greenSlider').value);
    const b = parseInt(document.getElementById('blueSlider').value);

    document.getElementById('redValue').textContent = r;
    document.getElementById('greenValue').textContent = g;
    document.getElementById('blueValue').textContent = b;

    const hex = rgbToHex(r, g, b);
    document.getElementById('hexColorInput').value = hex;

    document.getElementById('colorPreviewLarge').style.background = hex;
}

function applyCustomColor() {
    if (currentColorTarget) {
        const hex = document.getElementById('hexColorInput').value;
        document.getElementById(currentColorTarget).value = hex;

        updateColorPreview();

        const modal = document.getElementById('customColorPickerModal');
        if (modal) {
            const bsModal = bootstrap.Modal.getInstance(modal);
            if (bsModal) {
                bsModal.hide();
            }
        }
    }
}

function initializeCustomColorPicker() {
    setTimeout(() => {
        ['redSlider', 'greenSlider', 'blueSlider'].forEach(id => {
            const slider = document.getElementById(id);
            if (slider) {
                slider.addEventListener('input', updateColorDisplay);
            }
        });

        const hexInput = document.getElementById('hexColorInput');
        if (hexInput) {
            hexInput.addEventListener('input', function () {
                const hex = this.value;
                if (hex.match(/^#[0-9A-F]{6}$/i)) {
                    const rgb = hexToRgb(hex);
                    if (rgb) {
                        document.getElementById('redSlider').value = rgb.r;
                        document.getElementById('greenSlider').value = rgb.g;
                        document.getElementById('blueSlider').value = rgb.b;
                        updateColorDisplay();
                    }
                }
            });
        }
    }, 500);
}

function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

function rgbToHex(r, g, b) {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

let emojiData = {};
let emojiDataLoaded = false;
const DASHBOARD_EMOJI_DATA_VERSION = '20250109-1';

async function loadEmojiData() {
    if (emojiDataLoaded) return;
    try {
        const res = await fetch('/static/emoji-data.json?v=' + DASHBOARD_EMOJI_DATA_VERSION);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        if (typeof data === 'object' && Object.keys(data).length) {
            emojiData = data;
            emojiDataLoaded = true;
        }
    } catch (err) {
        console.error('Failed to load emoji-data.json, using fallback', err);
        emojiData = {
            smileys: ['😀','😃','😄','😁','😆','😅','😂','🤣'],
            animals: ['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🕷️','🕸️'],
            food: ['🍎','🍊','🍋','🍌','🍉','🍇','🍓','🍈'],
            activities: ['⚽','🏀','🏈','⚾','🎾','🏐','🏉','🏓'],
            travel: ['🚗','🚕','🚙','🚌','🚎','🏎️','🚓','🚑'],
            objects: ['💡','🔦','🕯️','💸','💰','💳','💎','⚖️'],
            symbols: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍'],
            flags: ['🏳️','🏴','🏁','🚩','🏳️‍🌈','🏳️‍⚧️']
        };
    }
}

async function initializeEmojiPicker() {
    const emojiBtn = document.getElementById('emojiPickerBtn');
    if (emojiBtn) {
        emojiBtn.addEventListener('click', function () {
            showEmojiPicker();
        });
    }

    await loadEmojiData();

    document.querySelectorAll('.emoji-category-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const category = this.dataset.category;
            populateEmojiGrid(category);

            document.querySelectorAll('.emoji-category-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });

    const defaultCategory = emojiData.smileys ? 'smileys' : Object.keys(emojiData)[0];
    if (defaultCategory) populateEmojiGrid(defaultCategory);
}

function showEmojiPicker() {
    const picker = document.getElementById('emojiPicker');
    if (picker) {
        picker.style.display = picker.style.display === 'none' ? 'block' : 'none';
    }
}

function populateEmojiGrid(category) {
    const grid = document.getElementById('emojiGrid');
    if (!grid || !emojiData[category]) return;

    grid.innerHTML = '';

    emojiData[category].forEach(emoji => {
        const span = document.createElement('span');
        span.textContent = emoji;
        span.className = 'emoji-item';
        span.addEventListener('click', function () {
            selectEmoji(emoji);
        });
        grid.appendChild(span);
    });
}

function selectEmoji(emoji) {
    const emojiInput = document.getElementById('emojiValue');
    if (emojiInput) {
        emojiInput.value = emoji;
    }

    const picker = document.getElementById('emojiPicker');
    if (picker) {
        picker.style.display = 'none';
    }
}

function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) {
        clearImagePreview();
        return;
    }

    const validTypes = ['image/png', 'image/jpeg', 'image/jpg', 'image/gif'];
    if (!validTypes.includes(file.type)) {
        showCustomAlert('Please select a valid image file (PNG, JPG, JPEG, or GIF)', 'warning');
        clearImagePreview();
        return;
    }

    const maxSize = 256 * 1024;
    if (file.size > maxSize) {
        showCustomAlert('File size must be less than 256KB', 'warning');
        clearImagePreview();
        return;
    }

    const reader = new FileReader();
    reader.onload = function (e) {
        showImagePreview(e.target.result);
    };
    reader.readAsDataURL(file);
}

function showImagePreview(imageSrc) {
    const previewContainer = document.getElementById('imagePreview');
    const previewImg = document.getElementById('previewImg');

    if (previewContainer && previewImg) {
        previewImg.src = imageSrc;
        previewContainer.style.display = 'flex';
    }
}

function clearImagePreview() {
    const fileInput = document.getElementById('imageUpload');
    const previewContainer = document.getElementById('imagePreview');
    const previewImg = document.getElementById('previewImg');

    if (fileInput) fileInput.value = '';
    if (previewContainer) previewContainer.style.display = 'none';
    if (previewImg) previewImg.src = '';
}

async function checkPurchaseStatus() {
    try {
        const response = await fetch('/api/purchase-status');
        const data = await response.json();
        updateUIBasedOnPurchaseStatus(data);
    } catch (error) {
        console.error('Failed to check purchase status:', error);
    }
}

function updateUIBasedOnPurchaseStatus(purchaseData) {
    const createRoleBtn = document.getElementById('createRoleBtn');
    if (!createRoleBtn) return;

    const isEditing = !!window.editingRoleId;
    if (purchaseData.canCreateRole || isEditing) {
        createRoleBtn.disabled = false;
        if (!isEditing) {
            createRoleBtn.innerHTML = '<i class="fas fa-plus"></i> Create Role';
        }
        createRoleBtn.className = 'btn btn-primary';
    } else {
        createRoleBtn.disabled = true;
        createRoleBtn.innerHTML = '<i class="fas fa-plus"></i> Create Role';
        createRoleBtn.className = 'btn btn-secondary';
    }
}

async function createRole() {
    if (isCreatingRole) {
        return;
    }

    isCreatingRole = true;

    try {
        const name = document.getElementById('roleName')?.value;
        const serverId = "1020646109992992828";
        const colorType = document.querySelector('input[name="colorType"]:checked')?.value;
        const primaryColor = document.getElementById('primaryColor')?.value;
        const secondaryColor = document.getElementById('secondaryColor')?.value;
        const iconType = document.querySelector('input[name="iconType"]:checked')?.value;

        if (!name) {
            showCustomAlert('Please enter a role name', 'warning');
            return;
        }

        const roleData = {
            name: name,
            color: {
                type: colorType,
                primary: primaryColor,
                secondary: colorType === 'gradient' ? secondaryColor : ''
            },
            icon: {
                type: iconType,
                value: ''
            },
            server_id: serverId
        };

        if (iconType === 'emoji') {
            roleData.icon.value = document.getElementById('emojiValue')?.value || '';
        } else if (iconType === 'custom') {
            const fileInput = document.getElementById('imageUpload');
            if (fileInput?.files?.length > 0) {
                const file = fileInput.files[0];
                const reader = new FileReader();
                reader.onload = function (e) {
                    roleData.icon.value = e.target.result;
                    submitRoleData(roleData);
                };
                reader.readAsDataURL(file);
                return;
            }
        } else if (iconType === 'none') {
            roleData.icon.value = '';
        }

        await submitRoleData(roleData);

    } catch (error) {
        showCustomAlert('Error creating role: ' + error.message, 'error');
    } finally {
        isCreatingRole = false;
    }
}

async function submitRoleData(roleData) {
    const isEditing = window.editingRoleId;
    const url = isEditing ? `/api/roles/${window.editingRoleId}` : '/api/roles';
    const method = isEditing ? 'PUT' : 'POST';

    try {
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(roleData)
        });

        const result = await response.json();

        if (response.ok) {
            showCustomAlert(isEditing ? 'Role updated successfully!' : 'Role created successfully!', 'success');
            hideCreateModal();

            if (isEditing) {
                window.editingRoleId = null;
                const modalTitle = document.querySelector('.modal-title');
                if (modalTitle) modalTitle.textContent = 'Create New Role';
            }

            window.location.reload();
        } else {
            showCustomAlert('Error ' + (isEditing ? 'updating' : 'creating') + ' role: ' + (result.error || 'Unknown error'), 'error');
        }

    } catch (error) {
        showCustomAlert('Network error occurred', 'error');
    }

}

function setupRoleActionHandlers() {
    document.querySelectorAll('.grant-role-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const roleId = this.getAttribute('data-role-id');
            const roleName = this.getAttribute('data-role-name');
            grantRole(roleId, roleName);
        });
    });

    document.querySelectorAll('.edit-role-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const roleId = this.getAttribute('data-role-id');
            if (roleId) {
                editRole(roleId);
            }
        });
    });

    document.querySelectorAll('.delete-role-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const roleId = this.getAttribute('data-role-id');
            if (roleId) {
                deleteRole(roleId);
            }
        });
    });
}

async function grantRole(roleId, roleName) {
    const userId = await showCustomInput(
        `Enter the Discord User ID to grant the "${roleName}" role to:`,
        'Grant Role',
        '123456789012345678'
    );

    if (!userId) {
        return;
    }

    if (!/^\d{17,19}$/.test(userId)) {
        showCustomAlert('Please enter a valid Discord User ID (17-19 digits)', 'warning');
        return;
    }

    const roleCard = document.querySelector(`[data-role-id="${roleId}"]`);
    if (roleCard) {
        const existingMembers = roleCard.querySelectorAll('.member-badge[data-user-id]');
        for (const memberBadge of existingMembers) {
            if (memberBadge.getAttribute('data-user-id') === userId) {
                showCustomAlert('This user is already a member of this role', 'warning');
                return;
            }
        }
    }

    const confirmed = await showCustomConfirm(`Grant the "${roleName}" role to user ${userId}?`, 'Grant Role');
    if (confirmed) {
        grantRoleToUser(roleId, userId);
    }
}

async function grantRoleToUser(roleId, userId) {
    try {
        const response = await fetch(`/api/roles/${roleId}/grant`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_id: userId
            })
        });

        const result = await response.json();

        if (response.ok) {
            showCustomAlert('Role granted successfully!', 'success');
            window.location.reload();
        } else {
            showCustomAlert('Error granting role: ' + (result.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        showCustomAlert('Network error occurred', 'error');
    }
}

function editRole(roleId) {
    const roleCard = document.querySelector(`[data-role-id="${roleId}"]`);
    if (!roleCard) {
        showCustomAlert('Role not found', 'error');
        return;
    }

    const currentName = roleCard.querySelector('.role-name-full').textContent;
    const currentColorType = roleCard.getAttribute('data-color-type');
    const currentPrimaryColor = roleCard.getAttribute('data-color-primary');
    const currentSecondaryColor = roleCard.getAttribute('data-color-secondary');
    const currentIconType = roleCard.getAttribute('data-icon-type');
    const currentIconValue = roleCard.getAttribute('data-icon-value');

    document.getElementById('roleName').value = currentName;

    if (currentColorType === 'gradient') {
        document.getElementById('gradientColor').checked = true;
        handleColorTypeChange('gradient');
    } else {
        document.getElementById('solidColor').checked = true;
        handleColorTypeChange('solid');
    }

    document.getElementById('primaryColor').value = currentPrimaryColor;
    if (currentSecondaryColor) {
        document.getElementById('secondaryColor').value = currentSecondaryColor;
    }
    updateColorPreview();

    document.getElementById('emojiValue').value = '';
    const imageInput = document.getElementById('imageInput');
    if (imageInput) imageInput.value = '';
    clearImagePreview();

    if (currentIconType === 'emoji') {
        document.getElementById('emojiIcon').checked = true;
        handleIconTypeChange('emoji');
        if (currentIconValue) {
            document.getElementById('emojiValue').value = currentIconValue;
        }
    } else if (currentIconType === 'custom') {
        document.getElementById('customIcon').checked = true;
        handleIconTypeChange('custom');
    } else {
        document.getElementById('noIcon').checked = true;
        handleIconTypeChange('none');
    }

    window.editingRoleId = roleId;

    const createRoleBtn = document.getElementById('createRoleBtn');
    if (createRoleBtn) {
        createRoleBtn.disabled = false;
        createRoleBtn.className = 'btn btn-primary';
    }

    showCreateModal();

    const modalTitle = document.querySelector('.modal-title');
    if (modalTitle) modalTitle.textContent = 'Edit Role';
    
    const createRoleBtnText = document.getElementById('createRoleBtnText');
    if (createRoleBtnText) createRoleBtnText.textContent = 'Update Role';

    if (typeof updateUIBasedOnPurchaseStatus === 'function' && window.lastPurchaseStatus) {
        updateUIBasedOnPurchaseStatus(window.lastPurchaseStatus);
    }
}

async function deleteRole(roleId) {
    const roleCard = document.querySelector(`[data-role-id="${roleId}"]`);
    const roleName = roleCard ? roleCard.querySelector('.role-name-full').textContent : 'this role';

    const confirmed = await showCustomConfirm(`Are you sure you want to delete "${roleName}"? This action cannot be undone.`, 'Delete Role');
    if (confirmed) {
        deleteRoleFromServer(roleId);
    }
}

async function deleteRoleFromServer(roleId) {
    try {
        const response = await fetch(`/api/roles/${roleId}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showCustomAlert('Role deleted successfully!', 'success');
            window.location.reload();
        } else {
            const result = await response.json();
            showCustomAlert('Error deleting role: ' + (result.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        showCustomAlert('Network error occurred', 'error');
    }
}

async function removeMemberFromRole(roleId, userId, buttonElement) {
    const memberBadge = buttonElement.closest('.modern-member-badge') || buttonElement.closest('.member-badge');
    
    if (!memberBadge) {
        showCustomAlert('Error: Could not find member element', 'error');
        return;
    }
    
    const memberText = memberBadge.textContent.replace('×', '').trim();

    const roleCard = document.querySelector(`[data-role-id="${roleId}"]`);
    const roleOwnerID = roleCard ? roleCard.getAttribute('data-role-owner') : null;

    if (window.currentUser && window.currentUser.discordId === userId && roleOwnerID === userId) {
        showCustomAlert('You cannot remove yourself from a role that you own. Transfer ownership first or delete the role instead.', 'warning', 'Cannot Remove Owner');
        return;
    }

    const confirmed = await showCustomConfirm(
        `Are you sure you want to remove ${memberText} from this role?`,
        'Remove Member'
    );

    if (!confirmed) return;

    try {
        const response = await fetch(`/api/roles/${roleId}/members/${userId}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showCustomAlert('Member removed successfully!', 'success');
            memberBadge.remove();
            const roleCard = document.querySelector(`[data-role-id="${roleId}"]`);
            if (roleCard) {
                const membersList = roleCard.querySelector('.member-list');
                const remainingMembers = membersList.querySelectorAll('.member-badge').length;
                if (remainingMembers === 0) {
                    const roleMembers = roleCard.querySelector('.role-members');
                    if (roleMembers) {
                        roleMembers.style.display = 'none';
                    }
                }
            }
        } else {
            const result = await response.json();
            showCustomAlert('Error removing member: ' + (result.error || 'Unknown error'), 'error');
        }
    } catch (error) {
        showCustomAlert('Network error occurred', 'error');
    }
}

window.showCreateModal = showCreateModal;
window.resetCreateModal = resetCreateModal;
window.hideCreateModal = hideCreateModal;
window.createRole = createRole;
window.openCustomColorPicker = openCustomColorPicker;
window.selectPresetColor = selectPresetColor;
window.applyCustomColor = applyCustomColor;
window.grantRole = grantRole;
window.editRole = editRole;
window.deleteRole = deleteRole;
window.removeMemberFromRole = removeMemberFromRole;
window.showCustomAlert = showCustomAlert;
window.showCustomConfirm = showCustomConfirm;
window.showCustomInput = showCustomInput;
window.closeCustomAlert = closeCustomAlert;
window.closeCustomInput = closeCustomInput;
