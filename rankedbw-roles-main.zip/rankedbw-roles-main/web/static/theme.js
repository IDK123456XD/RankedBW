(function(){
  const STORAGE_KEY = 'rr_theme_accent_v1';
  const DEFAULT_ACCENT = '#58a6ff';

  function clamp(v){ return Math.max(0, Math.min(255, v|0)); }
  function toHex(v){ return v.toString(16).padStart(2,'0'); }

  function parseColor(input){
    if(!input) return null;
    input = input.trim();
    let m = input.match(/^#([0-9a-f]{3})$/i);
    if(m){
      const h = m[1];
      return {
        r: parseInt(h[0]+h[0],16),
        g: parseInt(h[1]+h[1],16),
        b: parseInt(h[2]+h[2],16)
      };
    }
    m = input.match(/^#([0-9a-f]{6})$/i);
    if(m){
      const h = m[1];
      return { r: parseInt(h.slice(0,2),16), g: parseInt(h.slice(2,4),16), b: parseInt(h.slice(4,6),16) };
    }
    m = input.match(/^rgb\s*\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/i);
    if(m){
      return { r: clamp(+m[1]), g: clamp(+m[2]), b: clamp(+m[3]) };
    }
    return null;
  }

  function rgbToHex({r,g,b}){ return '#' + toHex(r) + toHex(g) + toHex(b); }
  function hexToRgb(hex){ return parseColor(hex); }

  function deriveVariants({r,g,b}){
    const lighten = (f)=>({ r: clamp(r + (255-r)*f), g: clamp(g + (255-g)*f), b: clamp(b + (255-b)*f) });
    const darken  = (f)=>({ r: clamp(r*(1-f)), g: clamp(g*(1-f)), b: clamp(b*(1-f)) });
    const light = lighten(0.35); 
    const dark = darken(0.25);   
    return { light, dark };
  }

  function applyTheme(rgb){
    if(!rgb) return;
    const {light, dark} = deriveVariants(rgb);
    const root = document.documentElement;
    const hex = rgbToHex(rgb);
    const hexLight = rgbToHex(light);
    const hexDark = rgbToHex(dark);

    root.style.setProperty('--accent', hex);
    root.style.setProperty('--accent-light', hexLight);
    root.style.setProperty('--accent-dark', hexDark);
    root.style.setProperty('--sky-blue', hex);
    root.style.setProperty('--sky-blue-light', hexLight);
    root.style.setProperty('--sky-blue-dark', hexDark);

    const luminance = (0.2126*rgb.r + 0.7152*rgb.g + 0.0722*rgb.b)/255;
    const fg = luminance > 0.6 ? '#0f141a' : '#ffffff';
    root.style.setProperty('--accent-fg', fg);
    root.style.setProperty('--sky-blue-text', fg);

    const preview = document.getElementById('themePreview');
    if(preview){
      preview.style.background = `linear-gradient(135deg, ${hex}, ${hexDark})`;
      preview.style.boxShadow = `0 0 0 1px var(--border-color)`;
    }
  }

  function loadStored(){
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if(!stored) return null;
      const obj = JSON.parse(stored);
      if(obj && typeof obj.r==='number') return {r:obj.r,g:obj.g,b:obj.b};
    } catch(e){}
    return null;
  }

  function save(rgb){
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(rgb)); } catch(e){}
  }

  function resetTheme(){
    const rgb = hexToRgb(DEFAULT_ACCENT);
    save(rgb);
    syncUI(rgb);
    applyTheme(rgb);
  }

  function syncUI(rgb){
    const hexInput = document.getElementById('themeHexInput');
    const rInput = document.getElementById('themeR');
    const gInput = document.getElementById('themeG');
    const bInput = document.getElementById('themeB');
    if(!hexInput||!rInput||!gInput||!bInput) return;
    hexInput.value = rgbToHex(rgb);
    rInput.value = rgb.r;
    gInput.value = rgb.g;
    bInput.value = rgb.b;
  }

  function init(){
    const hexInput = document.getElementById('themeHexInput');
    const rInput = document.getElementById('themeR');
    const gInput = document.getElementById('themeG');
    const bInput = document.getElementById('themeB');
    const applyBtn = document.getElementById('applyThemeBtn');
    const resetBtn = document.getElementById('resetThemeBtn');
    if(!hexInput || !rInput || !gInput || !bInput) return;

    const stored = loadStored();
    const start = stored || hexToRgb(DEFAULT_ACCENT);
    syncUI(start);
    applyTheme(start);

    function commit(rgb){
      if(!rgb) return;
      syncUI(rgb);
      applyTheme(rgb);
    }

    hexInput.addEventListener('input', ()=>{
      const rgb = parseColor(hexInput.value);
      if(rgb){ commit(rgb); }
    });

    [rInput,gInput,bInput].forEach(inp=>{
      inp.addEventListener('input', ()=>{
        const rgb = { r: clamp(+rInput.value||0), g: clamp(+gInput.value||0), b: clamp(+bInput.value||0) };
        syncUI(rgb); 
        applyTheme(rgb);
      });
    });

    applyBtn && applyBtn.addEventListener('click', ()=>{
      const current = parseColor(hexInput.value) || { r: clamp(+rInput.value||0), g: clamp(+gInput.value||0), b: clamp(+bInput.value||0) };
      save(current);
      applyTheme(current);
    });

    resetBtn && resetBtn.addEventListener('click', ()=>{
      resetTheme();
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
