package main

import (
	"log"
	"os"
	"os/signal"
	"syscall"

	"ranked-roles/internal/bot"
	"ranked-roles/internal/config"
	"ranked-roles/internal/database"
	"ranked-roles/internal/server"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		log.Fatal("Не удалось загрузить конфиг:", err)
	}

	db, err := database.New(cfg)
	if err != nil {
		log.Fatal("Не удалось подключиться к базе данных:", err)
	}
	defer db.Close()

	discordBot, err := bot.New(cfg, db)
	if err != nil {
		log.Fatal("Не удалось создать Discord-бота:", err)
	}

	if err := discordBot.Start(); err != nil {
		log.Fatal("Не удалось запустить Discord-бота:", err)
	}
	defer discordBot.Stop()

	webServer := server.New(cfg, db, discordBot)
	go func() {
		if err := webServer.Start(); err != nil {
			log.Fatal("Не удалось запустить веб-сервер:", err)
		}
	}()

	log.Println("Бот Ranked Roles запущен.")

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	<-stop

	log.Println("Корректное завершение работы...")
}
