package server

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"ranked-roles/internal/bot"
	"ranked-roles/internal/config"
	"ranked-roles/internal/database"
	"ranked-roles/internal/models"

	"github.com/bwmarrin/discordgo"
	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Server struct {
	router            *gin.Engine
	config            *config.Config
	db                *database.Database
	bot               *bot.Bot
	roleCreationMutex sync.Mutex
	ongoingCreations  map[string]bool
}

type DiscordUser struct {
	ID       string `json:"id"`
	Username string `json:"username"`
	Avatar   string `json:"avatar"`
}

type OAuthResponse struct {
	AccessToken  string `json:"access_token"`
	TokenType    string `json:"token_type"`
	ExpiresIn    int    `json:"expires_in"`
	RefreshToken string `json:"refresh_token"`
	Scope        string `json:"scope"`
}

func New(cfg *config.Config, db *database.Database, discordBot *bot.Bot) *Server {
	gin.SetMode(gin.ReleaseMode)
	router := gin.Default()

	server := &Server{
		router:           router,
		config:           cfg,
		db:               db,
		bot:              discordBot,
		ongoingCreations: make(map[string]bool),
	}

	server.setupRoutes()
	return server
}

func (s *Server) Start() error {
	log.Printf("запуск веб-сервера на порту %s", s.config.Port)
	return s.router.Run(":" + s.config.Port)
}

func (s *Server) setupRoutes() {
	s.router.Static("/static", "./web/static")

	funcMap := template.FuncMap{
		"formatExpiry": func(t time.Time) string {
			if t.Year() >= 2100 {
				return "никогда"
			}
			return t.Format("2006-01-02 15:04")
		},
	}

	s.router.SetFuncMap(funcMap)
	s.router.LoadHTMLGlob("web/templates/*")

	s.router.GET("/", s.handleDashboard)
	s.router.GET("/login", s.handleLogin)
	s.router.GET("/logout", s.handleLogout)
	s.router.GET("/callback", s.handleAuthCallback)

	s.router.GET("/debug/user/:userID/purchase-status", s.handleDebugPurchaseStatus)

	protected := s.router.Group("/api")
	protected.Use(s.authMiddleware())
	{
		protected.GET("/roles", s.handleGetRoles)
		protected.GET("/purchase-status", s.handleGetPurchaseStatus)
		protected.POST("/roles", s.handleCreateRole)
		protected.PUT("/roles/:id", s.handleUpdateRole)
		protected.DELETE("/roles/:id", s.handleDeleteRole)
		protected.POST("/roles/:id/members", s.handleAddRoleMember)
		protected.DELETE("/roles/:id/members/:user_id", s.handleRemoveRoleMember)
		protected.GET("/search-users", s.handleSearchUsers)
		protected.POST("/roles/:id/grant", s.handleGrantRole)
	}

	admin := s.router.Group("/admin")
	admin.Use(s.authMiddleware(), s.adminMiddleware())
	{
		admin.GET("/", s.handleAdminDashboard)
		admin.GET("/roles", s.handleAdminGetRoles)
		admin.POST("/roles", s.handleAdminCreateRole)
		admin.PUT("/roles/:id", s.handleAdminUpdateRole)
		admin.DELETE("/roles/:id", s.handleAdminDeleteRole)
		admin.PUT("/roles/:id/extend", s.handleAdminExtendRole)
		admin.PUT("/roles/:id/slots", s.handleAdminAddSlots)
		admin.POST("/roles/:id/grant", s.handleAdminGrantRole)
		admin.GET("/search-users", s.handleAdminSearchUsers)
		admin.GET("/search-role/:id", s.handleAdminSearchRole)
		admin.GET("/search-roles-by-name", s.handleAdminSearchRolesByName)
		admin.DELETE("/roles/:id/remove-member/:user_id", s.handleAdminRemoveMember)
		admin.DELETE("/roles/:id/remove-all-members", s.handleAdminRemoveAllMembers)
		admin.DELETE("/discord-roles/:id/remove-member/:user_id", s.handleAdminRemoveDiscordMember)
		admin.POST("/roles/:id/transfer", s.handleAdminTransferRole)
	}

	/* не оперативная */
	api := s.router.Group("/api")
	{
		api.GET("/health", s.handleHealth)
	}
}

func (s *Server) handleLogin(c *gin.Context) {
	state := s.generateState()

	s.db.SetCache("oauth_state_"+state, "valid", 10*time.Minute)

	log.Printf("конфигурация oauth - clientid: %s, redirecturl: %s", s.config.ClientID, s.config.RedirectURL)

	authURL := fmt.Sprintf(
		"https://discord.com/api/oauth2/authorize?client_id=%s&redirect_uri=%s&response_type=code&scope=identify&state=%s",
		s.config.ClientID,
		s.config.RedirectURL,
		state,
	)

	log.Printf("перенаправление на: %s", authURL)
	c.Redirect(http.StatusTemporaryRedirect, authURL)
}

func (s *Server) handleLogout(c *gin.Context) {
	sessionToken, err := c.Cookie("session")
	if err == nil {
		s.db.DeleteCache("session_" + sessionToken)
	}

	c.SetCookie("session", "", -1, "/", "", false, true)

	c.Redirect(http.StatusTemporaryRedirect, "/")
}

func (s *Server) handleAuthCallback(c *gin.Context) {
	code := c.Query("code")
	state := c.Query("state")

	_, err := s.db.GetCache("oauth_state_" + state)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный параметр состояния"})
		return
	}

	s.db.DeleteCache("oauth_state_" + state)

	token, err := s.exchangeCodeForToken(code)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обменять код на токен"})
		return
	}

	user, err := s.getDiscordUser(token.AccessToken)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось получить информацию о пользователе"})
		return
	}

	dbUser, err := s.db.GetUserByDiscordID(user.ID)
	if err != nil {
		dbUser = &models.User{
			DiscordID: user.ID,
			Username:  user.Username,
			Avatar:    user.Avatar,
		}
		if err := s.db.CreateUser(dbUser); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось создать пользователя"})
			return
		}
	} else {
		dbUser.Username = user.Username
		dbUser.Avatar = user.Avatar
		if err := s.db.UpdateUser(dbUser); err != nil {
			log.Printf("не удалось обновить пользователя: %v", err)
		}
	}

	sessionToken := s.generateState()
	s.db.SetCache("session_"+sessionToken, user.ID, 24*time.Hour)

	c.SetCookie("session", sessionToken, 86400, "/", "", false, true)

	c.Redirect(http.StatusTemporaryRedirect, "/")
}

func (s *Server) handleDashboard(c *gin.Context) {
	sessionToken, err := c.Cookie("session")
	var userID string

	if err != nil {
		log.Printf("панель управления - cookie сессии не найден, перенаправление на вход")
		c.Redirect(http.StatusFound, "/login")
		return
	}

	userID, err = s.db.GetCache("session_" + sessionToken)
	if err != nil {
		log.Printf("панель управления - недействительный токен сессии, перенаправление на вход")
		c.Redirect(http.StatusFound, "/login")
		return
	}

	log.Printf("панель управления - пользователь авторизован: %s", userID)

	user, err := s.db.GetUserByDiscordID(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось получить данные пользователя"})
		return
	}

	roles, err := s.db.GetCustomRolesByOwner(userID)
	if err != nil {
		roles = []models.CustomRole{}
	}

	for _, role := range roles {
		if role.Icon.Type == "custom" && role.Icon.Value != "" {
			if len(role.Icon.Value) > 100 {
				log.Printf("роль '%s' - тип иконки: '%s', длина значения: %d, первые 50 символов: '%s...', последние 20 символов: '...%s', url иконки: '%s'",
					role.Name, role.Icon.Type, len(role.Icon.Value), role.Icon.Value[:50], role.Icon.Value[len(role.Icon.Value)-20:], role.Icon.URL)
			} else {
				log.Printf("роль '%s' - тип иконки: '%s', значение иконки: '%s', url иконки: '%s'",
					role.Name, role.Icon.Type, role.Icon.Value, role.Icon.URL)
			}
		} else {
			log.Printf("роль '%s' - тип иконки: '%s', значение иконки: '%s', url иконки: '%s'",
				role.Name, role.Icon.Type, role.Icon.Value, role.Icon.URL)
		}
	}

	isAdmin := s.config.IsAdmin(userID)

	availablePurchase, err := s.db.GetAvailablePurchase(userID)
	hasValidPurchase := err == nil && availablePurchase != nil

	activeRoleCount, err := s.db.GetUserActiveRoleCount(userID)
	if err != nil {
		activeRoleCount = 0
	}

	canCreateRole := isAdmin || (hasValidPurchase && activeRoleCount == 0)

	c.HTML(http.StatusOK, "dashboard.html", gin.H{
		"title":           "панель управления",
		"user":            user,
		"roles":           roles,
		"isAdmin":         isAdmin,
		"canCreateRole":   canCreateRole,
		"activeRoleCount": activeRoleCount,
	})
}

func (s *Server) handleGetRoles(c *gin.Context) {
	userID := c.GetString("user_id")

	roles, err := s.db.GetCustomRolesByOwner(userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось получить роли"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"roles": roles})
}

func (s *Server) handleGetPurchaseStatus(c *gin.Context) {
	userID := c.GetString("user_id")
	log.Printf("статус покупки вызван для пользователя: %s", userID)

	isAdmin := s.config.IsAdmin(userID)
	log.Printf("пользователь %s администратор: %t", userID, isAdmin)

	availablePurchase, err := s.db.GetAvailablePurchase(userID)
	hasValidPurchase := err == nil && availablePurchase != nil
	log.Printf("результат доступной покупки - hasvalidpurchase: %t, err: %v", hasValidPurchase, err)

	activeRoleCount, err := s.db.GetUserActiveRoleCount(userID)
	if err != nil {
		log.Printf("ошибка получения активных ролей: %v", err)
		activeRoleCount = 0
	}
	log.Printf("количество активных ролей: %d", activeRoleCount)

	allPurchases, err := s.db.GetUserPurchases(userID)
	if err != nil {
		allPurchases = []models.Purchase{}
	}

	canCreateRole := isAdmin || (hasValidPurchase && activeRoleCount == 0)
	log.Printf("финальный статус покупки - admin: %t, validpurchase: %t, activeroles: %d, cancreate: %t", isAdmin, hasValidPurchase, activeRoleCount, canCreateRole)

	c.JSON(http.StatusOK, gin.H{
		"hasValidPurchase": hasValidPurchase,
		"activeRoleCount":  activeRoleCount,
		"canCreateRole":    canCreateRole,
		"isAdmin":          isAdmin,
		"purchases":        allPurchases,
	})
}

func (s *Server) handleCreateRole(c *gin.Context) {
	userID := c.GetString("user_id")
	log.Printf("создание роли вызвано для пользователя: %s", userID)

	s.roleCreationMutex.Lock()
	if s.ongoingCreations[userID] {
		s.roleCreationMutex.Unlock()
		c.JSON(http.StatusTooManyRequests, gin.H{
			"error": "создание роли уже выполняется. пожалуйста, дождитесь завершения текущего запроса.",
			"code":  "CREATION_IN_PROGRESS",
		})
		return
	}
	s.ongoingCreations[userID] = true
	s.roleCreationMutex.Unlock()

	defer func() {
		s.roleCreationMutex.Lock()
		delete(s.ongoingCreations, userID)
		s.roleCreationMutex.Unlock()
		log.Printf("флаг создания роли очищен для пользователя %s", userID)
	}()

	var req struct {
		Name  string `json:"name" binding:"required"`
		Color struct {
			Type      string `json:"type"`
			Primary   string `json:"primary"`
			Secondary string `json:"secondary"`
		} `json:"color" binding:"required"`
		Icon struct {
			Type  string `json:"type"`
			Value string `json:"value"`
		} `json:"icon"`
		ServerID string `json:"server_id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		log.Printf("создание роли - неверное тело запроса: %v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	log.Printf("создание роли - запрос успешно обработан для роли: %s", req.Name)

	isAdmin := s.config.IsAdmin(userID)
	log.Printf("пользователь %s администратор: %t", userID, isAdmin)

	if !strings.HasPrefix(req.Color.Primary, "#") || len(req.Color.Primary) != 7 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный формат основного цвета"})
		return
	}

	if req.Color.Type == "gradient" {
		if !strings.HasPrefix(req.Color.Secondary, "#") || len(req.Color.Secondary) != 7 {
			c.JSON(http.StatusBadRequest, gin.H{"error": "неверный формат дополнительного цвета для градиента"})
			return
		}
	}

	var availablePurchase *models.Purchase
	if !isAdmin {
		log.Printf("проверка покупки для пользователя: %s", userID)
		var err error
		availablePurchase, err = s.db.GetAvailablePurchase(userID)
		if err != nil {
			log.Printf("покупка не найдена для пользователя %s: %v", userID, err)
			c.JSON(http.StatusForbidden, gin.H{
				"error": "не найдена действующая покупка пользовательской роли. пожалуйста, приобретите пользовательскую роль для создания ролей.",
				"code":  "NO_PURCHASE",
			})
			return
		}
		log.Printf("найдена доступная покупка для пользователя %s: %+v", userID, availablePurchase)
	} else {
		log.Printf("пропуск проверки покупки для администратора: %s", userID)
	}

	existingRole, err := s.db.GetUserCustomRoleOnServer(userID, req.ServerID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось проверить существующие роли"})
		return
	}

	if existingRole != nil {
		log.Printf("пользователь %s уже имеет роль на сервере %s: %s", userID, req.ServerID, existingRole.Name)

		if !isAdmin && availablePurchase != nil && strings.Contains(availablePurchase.ProductType, "Monthly") {
			err := s.db.ExtendRoleExpiration(existingRole.ID, 31)
			if err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось продлить срок действия роли"})
				return
			}

			if err := s.db.MarkPurchaseAsUsed(availablePurchase.ID, existingRole.ID.Hex()); err != nil {
				log.Printf("не удалось пометить покупку как использованную: %v", err)
			}

			log.Printf("продлен срок действия роли для пользователя %s на 31 день", userID)
			c.JSON(http.StatusOK, gin.H{
				"message": "ваша существующая пользовательская роль была продлена на 31 день",
				"role":    existingRole,
			})
			return
		} else {
			c.JSON(http.StatusBadRequest, gin.H{
				"error": "у вас уже есть пользовательская роль на этом сервере. каждый пользователь может иметь только одну роль на сервер.",
				"code":  "ROLE_EXISTS",
			})
			return
		}
	}

	roleColor := models.RoleColor{
		Type:    req.Color.Type,
		Primary: req.Color.Primary,
	}
	if req.Color.Type == "gradient" && req.Color.Secondary != "" {
		roleColor.Secondary = req.Color.Secondary
	}

	log.Printf("создание роли - тип цвета: '%s', основной: '%s', дополнительный: '%s'", roleColor.Type, roleColor.Primary, roleColor.Secondary)

	roleIcon := models.RoleIcon{
		Type:  req.Icon.Type,
		Value: req.Icon.Value,
	}
	if req.Icon.Type == "custom" {
		roleIcon.URL = req.Icon.Value
	}

	valuePreview := req.Icon.Value
	urlPreview := roleIcon.URL
	if len(valuePreview) > 50 {
		valuePreview = valuePreview[:50] + "..."
	}
	if len(urlPreview) > 50 {
		urlPreview = urlPreview[:50] + "..."
	}
	log.Printf("иконка роли - тип: '%s', значение: '%s', url: '%s'", roleIcon.Type, valuePreview, urlPreview)

	discordRole, err := s.bot.CreateAdvancedDiscordRole(req.ServerID, req.Name, roleColor, roleIcon)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось создать роль discord: " + err.Error()})
		return
	}

	if roleIcon.Type == "custom" && discordRole.Icon != "" {
		roleIcon.URL = fmt.Sprintf("https://cdn.discordapp.com/role-icons/%s/%s.png", discordRole.ID, discordRole.Icon)
	}

	var expiresAt time.Time
	if availablePurchase != nil {
		expiresAt = availablePurchase.ExpiresAt
	} else {
		expiresAt = time.Now().AddDate(100, 0, 0)
	}

	customRole := &models.CustomRole{
		Name:          req.Name,
		Color:         roleColor,
		Icon:          roleIcon,
		OwnerID:       userID,
		ServerID:      req.ServerID,
		DiscordRoleID: discordRole.ID,
		Slots: models.RoleSlots{
			Total:   s.config.DefaultSlots,
			Used:    1,
			Members: []string{userID},
		},
		ExpiresAt: expiresAt,
	}

	if err := s.db.CreateCustomRole(customRole); err != nil {
		s.bot.DeleteDiscordRole(req.ServerID, discordRole.ID)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось создать пользовательскую роль"})
		return
	}

	if err := s.bot.AddRoleToUser(req.ServerID, userID, discordRole.ID); err != nil {
		log.Printf("не удалось назначить роль пользователю: %v", err)
	}

	if !isAdmin && availablePurchase != nil {
		if err := s.db.MarkPurchaseAsUsed(availablePurchase.ID, customRole.ID.Hex()); err != nil {
			log.Printf("не удалось пометить покупку как использованную: %v", err)
		}
	}

	c.JSON(http.StatusCreated, gin.H{"role": customRole})
}

func (s *Server) handleUpdateRole(c *gin.Context) {
	userID := c.GetString("user_id")
	roleIDStr := c.Param("id")

	roleID, err := primitive.ObjectIDFromHex(roleIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный идентификатор роли"})
		return
	}

	var req struct {
		Name  string `json:"name"`
		Color struct {
			Type      string `json:"type"`
			Primary   string `json:"primary"`
			Secondary string `json:"secondary"`
		} `json:"color"`
		Icon struct {
			Type  string `json:"type"`
			Value string `json:"value"`
		} `json:"icon"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	role, err := s.db.GetCustomRole(roleID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	if role.OwnerID != userID {
		c.JSON(http.StatusForbidden, gin.H{"error": "это не ваша роль"})
		return
	}

	if req.Name != "" {
		role.Name = req.Name
	}

	if req.Color.Primary != "" {
		if !strings.HasPrefix(req.Color.Primary, "#") || len(req.Color.Primary) != 7 {
			c.JSON(http.StatusBadRequest, gin.H{"error": "неверный формат основного цвета"})
			return
		}

		role.Color.Type = req.Color.Type
		role.Color.Primary = req.Color.Primary

		if req.Color.Type == "gradient" && req.Color.Secondary != "" {
			if !strings.HasPrefix(req.Color.Secondary, "#") || len(req.Color.Secondary) != 7 {
				c.JSON(http.StatusBadRequest, gin.H{"error": "неверный формат дополнительного цвета"})
				return
			}
			role.Color.Secondary = req.Color.Secondary
		}
	}

	if req.Icon.Type != "" {
		role.Icon.Type = req.Icon.Type

		if req.Icon.Type == "none" {
			role.Icon.Value = ""
			role.Icon.URL = ""
		} else if req.Icon.Type == "emoji" {
			role.Icon.Value = req.Icon.Value
			role.Icon.URL = ""
		} else if req.Icon.Type == "custom" {
			role.Icon.Value = req.Icon.Value
			role.Icon.URL = req.Icon.Value
		}
	}

	updatedRole, err := s.bot.UpdateAdvancedDiscordRole(role.ServerID, role.DiscordRoleID, role.Name, role.Color, role.Icon)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль discord: " + err.Error()})
		return
	}

	if updatedRole != nil && updatedRole.Icon != "" && role.Icon.Type == "custom" {
		role.Icon.URL = fmt.Sprintf("https://cdn.discordapp.com/role-icons/%s/%s.png", role.DiscordRoleID, updatedRole.Icon)
		log.Printf("обновлен discord cdn url для роли: %s", role.Icon.URL)
	} else if role.Icon.Type == "none" || role.Icon.Type == "emoji" {
		role.Icon.URL = ""
		log.Printf("очищен url иконки для типа роли: %s", role.Icon.Type)
	}

	if err := s.db.UpdateCustomRole(role); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"role": role})
}

func (s *Server) handleDeleteRole(c *gin.Context) {
	userID := c.GetString("user_id")
	roleIDStr := c.Param("id")

	isAdmin := s.config.IsAdmin(userID)
	if !isAdmin {
		c.JSON(http.StatusForbidden, gin.H{
			"error": "удаление ролей доступно только администраторам. роли будут автоматически удалены по истечении срока действия.",
			"code":  "ADMIN_ONLY",
		})
		return
	}

	roleID, err := primitive.ObjectIDFromHex(roleIDStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный идентификатор роли"})
		return
	}

	role, err := s.db.GetCustomRole(roleID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	if role.OwnerID != userID {
		c.JSON(http.StatusForbidden, gin.H{"error": "это не ваша роль"})
		return
	}

	if err := s.bot.DeleteDiscordRole(role.ServerID, role.DiscordRoleID); err != nil {
		log.Printf("не удалось удалить роль discord: %v", err)
	}

	if err := s.db.DeleteCustomRole(roleID); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось удалить роль"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "роль успешно удалена"})
}

func (s *Server) handleAddRoleMember(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "функция добавления участника скоро появится"})
}

func (s *Server) handleRemoveRoleMember(c *gin.Context) {
	roleID := c.Param("id")
	userIDToRemove := c.Param("user_id")

	if roleID == "" || userIDToRemove == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "требуется идентификатор роли и идентификатор пользователя"})
		return
	}

	currentUserID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "пользователь не авторизован"})
		return
	}

	objectID, err := primitive.ObjectIDFromHex(roleID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный формат идентификатора роли"})
		return
	}

	role, err := s.db.GetCustomRole(objectID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	isAdmin := s.config.IsAdmin(currentUserID.(string))
	if role.OwnerID != currentUserID.(string) && !isAdmin {
		c.JSON(http.StatusForbidden, gin.H{"error": "вы можете управлять только своими ролями"})
		return
	}

	if role.OwnerID == userIDToRemove {
		c.JSON(http.StatusBadRequest, gin.H{"error": "владелец роли не может быть удален из своей роли"})
		return
	}

	if !role.HasMember(userIDToRemove) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "у пользователя нет этой роли"})
		return
	}

	err = s.bot.GetSession().GuildMemberRoleRemove(s.config.DevServerID, userIDToRemove, role.DiscordRoleID)
	if err != nil {
		log.Printf("не удалось удалить роль discord: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось удалить роль из discord"})
		return
	}

	if !role.RemoveMember(userIDToRemove) {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось удалить участника из роли"})
		return
	}

	err = s.db.UpdateCustomRole(role)
	if err != nil {
		s.bot.GetSession().GuildMemberRoleAdd(s.config.DevServerID, userIDToRemove, role.DiscordRoleID)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль в базе данных"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "участник успешно удален",
		"role":    role,
	})
}

func (s *Server) handleAdminDashboard(c *gin.Context) {
	c.HTML(http.StatusOK, "admin.html", gin.H{
		"title": "панель администратора",
	})
}

func (s *Server) handleAdminGetRoles(c *gin.Context) {
	serverID := c.Query("server_id")
	if serverID == "" {
		serverID = s.config.DevServerID
	}

	roles, err := s.db.GetCustomRolesByServer(serverID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось получить роли"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"roles": roles})
}

func (s *Server) handleAdminExtendRole(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "функция продления роли скоро появится"})
}

func (s *Server) handleAdminAddSlots(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"message": "функция добавления слотов скоро появится"})
}

func (s *Server) handleDebugPurchaseStatus(c *gin.Context) {
	userID := c.Param("userID")
	log.Printf("вызван handleDebugPurchaseStatus для пользователя: %s", userID)

	availablePurchase, err := s.db.GetAvailablePurchase(userID)
	hasValidPurchase := err == nil && availablePurchase != nil
	log.Printf("результат GetAvailablePurchase - hasValidPurchase: %t, err: %v", hasValidPurchase, err)
	if availablePurchase != nil {
		log.Printf("доступная покупка: %+v", availablePurchase)
	}

	activeRoleCount, err := s.db.GetUserActiveRoleCount(userID)
	if err != nil {
		log.Printf("ошибка GetUserActiveRoleCount: %v", err)
		activeRoleCount = 0
	}
	log.Printf("количество активных ролей: %d", activeRoleCount)

	allPurchases, err := s.db.GetUserPurchases(userID)
	if err != nil {
		log.Printf("ошибка GetUserPurchases: %v", err)
		allPurchases = []models.Purchase{}
	}
	log.Printf("всего найдено покупок: %d", len(allPurchases))

	canCreateRole := hasValidPurchase && activeRoleCount == 0
	log.Printf("финальный статус покупки - hasValidPurchase: %t, activeRoleCount: %d, canCreateRole: %t", hasValidPurchase, activeRoleCount, canCreateRole)

	c.JSON(http.StatusOK, gin.H{
		"userID":            userID,
		"hasValidPurchase":  hasValidPurchase,
		"activeRoleCount":   activeRoleCount,
		"canCreateRole":     canCreateRole,
		"totalPurchases":    len(allPurchases),
		"purchases":         allPurchases,
		"availablePurchase": availablePurchase,
	})
}

func (s *Server) handleHealth(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status":    "исправно",
		"timestamp": time.Now().Unix(),
	})
}

func (s *Server) authMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		sessionToken, err := c.Cookie("session")
		if err != nil {
			log.Printf("middleware авторизации - cookie сессии не найден: %v", err)
			c.JSON(http.StatusUnauthorized, gin.H{"error": "сессия не найдена"})
			c.Abort()
			return
		}

		userID, err := s.db.GetCache("session_" + sessionToken)
		if err != nil {
			log.Printf("middleware авторизации - недействительный токен сессии %s: %v", sessionToken, err)
			c.JSON(http.StatusUnauthorized, gin.H{"error": "недействительная сессия"})
			c.Abort()
			return
		}

		log.Printf("middleware авторизации - пользователь авторизован: %s", userID)
		c.Set("user_id", userID)
		c.Next()
	}
}

func (s *Server) adminMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		userID := c.GetString("user_id")

		if s.config.IsAdmin(userID) {
			c.Next()
			return
		}

		c.JSON(http.StatusForbidden, gin.H{"error": "требуется доступ администратора"})
		c.Abort()
	}
}

func (s *Server) generateState() string {
	bytes := make([]byte, 32)
	rand.Read(bytes)
	return base64.URLEncoding.EncodeToString(bytes)
}

func (s *Server) exchangeCodeForToken(code string) (*OAuthResponse, error) {
	data := fmt.Sprintf(
		"client_id=%s&client_secret=%s&grant_type=authorization_code&code=%s&redirect_uri=%s",
		s.config.ClientID,
		s.config.ClientSecret,
		code,
		s.config.RedirectURL,
	)

	req, err := http.NewRequest("POST", "https://discord.com/api/oauth2/token", strings.NewReader(data))
	if err != nil {
		return nil, err
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var token OAuthResponse
	if err := json.NewDecoder(resp.Body).Decode(&token); err != nil {
		return nil, err
	}

	return &token, nil
}

func (s *Server) getDiscordUser(accessToken string) (*DiscordUser, error) {
	req, err := http.NewRequest("GET", "https://discord.com/api/users/@me", nil)
	if err != nil {
		return nil, err
	}

	req.Header.Set("Authorization", "Bearer "+accessToken)

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var user DiscordUser
	if err := json.NewDecoder(resp.Body).Decode(&user); err != nil {
		return nil, err
	}

	return &user, nil
}

func (s *Server) handleSearchUsers(c *gin.Context) {
	query := c.Query("q")
	if query == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "требуется параметр запроса 'q'"})
		return
	}

	if len(strings.TrimSpace(query)) < 2 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "запрос должен содержать не менее 2 символов"})
		return
	}

	log.Printf("поиск пользователей с запросом: '%s'", query)

	members, err := s.bot.SearchGuildMembers(s.config.DevServerID, query)
	if err != nil {
		log.Printf("не удалось найти участников сервера: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось найти пользователей"})
		return
	}

	log.Printf("найдено %d участников для запроса '%s'", len(members), query)

	var users []gin.H
	for _, member := range members {
		if member.User != nil {
			user := gin.H{
				"id":       member.User.ID,
				"username": member.User.Username,
				"avatar":   member.User.Avatar,
			}

			if member.Nick != "" {
				user["display_name"] = member.Nick
			}

			if member.User.Discriminator != "0" && member.User.Discriminator != "" {
				user["discriminator"] = member.User.Discriminator
			}

			users = append(users, user)
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"users": users,
		"count": len(users),
	})
}

func (s *Server) handleGrantRole(c *gin.Context) {
	roleID := c.Param("id")
	if roleID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "требуется идентификатор роли"})
		return
	}

	var requestBody struct {
		UserID string `json:"user_id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&requestBody); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверное тело запроса"})
		return
	}

	userID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "пользователь не авторизован"})
		return
	}

	objectID, err := primitive.ObjectIDFromHex(roleID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный формат идентификатора роли"})
		return
	}

	role, err := s.db.GetCustomRole(objectID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	if role.OwnerID != userID.(string) {
		c.JSON(http.StatusForbidden, gin.H{"error": "вы можете выдавать только свои роли"})
		return
	}

	if !role.CanAddMember() {
		c.JSON(http.StatusBadRequest, gin.H{"error": "нет доступных слотов для этой роли"})
		return
	}

	if role.HasMember(requestBody.UserID) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "у пользователя уже есть эта роль"})
		return
	}

	err = s.bot.GetSession().GuildMemberRoleAdd(s.config.DevServerID, requestBody.UserID, role.DiscordRoleID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось выдать роль в discord"})
		return
	}

	if !role.AddMember(requestBody.UserID) {
		s.bot.GetSession().GuildMemberRoleRemove(s.config.DevServerID, requestBody.UserID, role.DiscordRoleID)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось добавить участника в роль"})
		return
	}

	err = s.db.UpdateCustomRole(role)
	if err != nil {
		s.bot.GetSession().GuildMemberRoleRemove(s.config.DevServerID, requestBody.UserID, role.DiscordRoleID)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль в базе данных"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "роль успешно выдана",
		"role":    role,
	})
}

func (s *Server) handleAdminCreateRole(c *gin.Context) {
	var requestBody struct {
		Name           string           `json:"name" binding:"required"`
		Color          models.RoleColor `json:"color" binding:"required"`
		Icon           models.RoleIcon  `json:"icon"`
		Slots          int              `json:"slots" binding:"required,min=1,max=50"`
		ExpiryType     string           `json:"expiry_type" binding:"required"`
		ExpiryDays     int              `json:"expiry_days,omitempty"`
		ExpiryHours    int              `json:"expiry_hours,omitempty"`
		AssignToUserID string           `json:"assign_to_user_id,omitempty"`
	}

	if err := c.ShouldBindJSON(&requestBody); err != nil {
		log.Printf("админ создание роли - неверное тело запроса: %v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверное тело запроса"})
		return
	}

	log.Printf("админ создание роли - получены данные:")
	log.Printf("  название: %s", requestBody.Name)
	log.Printf("  слоты: %d", requestBody.Slots)
	log.Printf("  назначить пользователю: '%s'", requestBody.AssignToUserID)
	log.Printf("  тип иконки: %s", requestBody.Icon.Type)

	adminID, exists := c.Get("user_id")
	if !exists {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "пользователь не авторизован"})
		return
	}

	var expiresAt time.Time
	if requestBody.ExpiryType == "never" {
		expiresAt = time.Now().AddDate(100, 0, 0)
	} else {
		duration := time.Duration(requestBody.ExpiryDays)*24*time.Hour + time.Duration(requestBody.ExpiryHours)*time.Hour
		expiresAt = time.Now().Add(duration)
	}

	discordRole, err := s.bot.CreateAdvancedDiscordRole(s.config.DevServerID, requestBody.Name, requestBody.Color, requestBody.Icon)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось создать роль discord"})
		return
	}

	ownerID := adminID.(string)
	if requestBody.AssignToUserID != "" {
		ownerID = requestBody.AssignToUserID
	}

	role := &models.CustomRole{
		Name:          requestBody.Name,
		Color:         requestBody.Color,
		Icon:          requestBody.Icon,
		OwnerID:       ownerID,
		ServerID:      s.config.DevServerID,
		DiscordRoleID: discordRole.ID,
		Slots: models.RoleSlots{
			Total:   requestBody.Slots,
			Used:    0,
			Members: []string{},
		},
		ExpiresAt: expiresAt,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	if requestBody.AssignToUserID != "" {
		log.Printf("попытка назначить роль пользователю: %s", requestBody.AssignToUserID)
		if role.AddMember(requestBody.AssignToUserID) {
			log.Printf("добавлен участник в роль, теперь выдача discord роли")
			err = s.bot.GetSession().GuildMemberRoleAdd(s.config.DevServerID, requestBody.AssignToUserID, discordRole.ID)
			if err != nil {
				log.Printf("не удалось назначить discord роль: %v", err)
				s.bot.GetSession().GuildRoleDelete(s.config.DevServerID, discordRole.ID)
				c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось назначить роль пользователю в discord"})
				return
			}
			log.Printf("успешно назначена discord роль пользователю")
		} else {
			log.Printf("не удалось добавить участника в роль (роль может быть заполнена)")
		}
	} else {
		log.Printf("назначение пользователя не запрошено")
	}

	err = s.db.CreateCustomRole(role)
	if err != nil {
		s.bot.GetSession().GuildRoleDelete(s.config.DevServerID, discordRole.ID)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось сохранить роль в базе данных"})
		return
	}

	c.JSON(http.StatusCreated, gin.H{
		"message": "роль успешно создана",
		"role":    role,
	})
}

func (s *Server) handleAdminUpdateRole(c *gin.Context) {
	roleID := c.Param("id")
	objectID, err := primitive.ObjectIDFromHex(roleID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный формат идентификатора роли"})
		return
	}

	var requestBody struct {
		Name        string           `json:"name" binding:"required"`
		Color       models.RoleColor `json:"color" binding:"required"`
		Icon        models.RoleIcon  `json:"icon"`
		Slots       int              `json:"slots" binding:"required,min=1,max=50"`
		ExpiryType  string           `json:"expiry_type" binding:"required"`
		ExpiryDays  int              `json:"expiry_days,omitempty"`
		ExpiryHours int              `json:"expiry_hours,omitempty"`
	}

	if err := c.ShouldBindJSON(&requestBody); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверное тело запроса"})
		return
	}

	role, err := s.db.GetCustomRole(objectID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	updatedRole, err := s.bot.UpdateAdvancedDiscordRole(s.config.DevServerID, role.DiscordRoleID, requestBody.Name, requestBody.Color, requestBody.Icon)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль discord"})
		return
	}

	role.Name = requestBody.Name
	role.Color = requestBody.Color
	role.Icon = requestBody.Icon

	if updatedRole != nil && updatedRole.Icon != "" && role.Icon.Type == "custom" {
		role.Icon.URL = fmt.Sprintf("https://cdn.discordapp.com/role-icons/%s/%s.png", role.DiscordRoleID, updatedRole.Icon)
		log.Printf("обновлен discord cdn url для роли: %s", role.Icon.URL)
	} else if role.Icon.Type == "none" || role.Icon.Type == "emoji" {
		role.Icon.URL = ""
		log.Printf("очищен url иконки для типа роли: %s", role.Icon.Type)
	}

	if requestBody.Slots < role.Slots.Total {
		if len(role.Slots.Members) > requestBody.Slots {
			c.JSON(http.StatusBadRequest, gin.H{"error": "нельзя уменьшить количество слотов ниже текущего количества участников"})
			return
		}
	}
	role.Slots.Total = requestBody.Slots

	if requestBody.ExpiryType == "never" {
		role.ExpiresAt = time.Now().AddDate(100, 0, 0)
	} else {
		duration := time.Duration(requestBody.ExpiryDays)*24*time.Hour + time.Duration(requestBody.ExpiryHours)*time.Hour
		role.ExpiresAt = time.Now().Add(duration)
	}

	role.UpdatedAt = time.Now()

	err = s.db.UpdateCustomRole(role)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль в базе данных"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "роль успешно обновлена",
		"role":    role,
	})
}

func (s *Server) handleAdminDeleteRole(c *gin.Context) {
	roleID := c.Param("id")
	objectID, err := primitive.ObjectIDFromHex(roleID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный формат идентификатора роли"})
		return
	}

	role, err := s.db.GetCustomRole(objectID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	err = s.bot.GetSession().GuildRoleDelete(s.config.DevServerID, role.DiscordRoleID)
	if err != nil {
		log.Printf("не удалось удалить роль discord: %v", err)
	}

	err = s.db.DeleteCustomRole(objectID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось удалить роль из базы данных"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "роль успешно удалена"})
}

func (s *Server) handleAdminGrantRole(c *gin.Context) {
	roleID := c.Param("id")
	objectID, err := primitive.ObjectIDFromHex(roleID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный формат идентификатора роли"})
		return
	}

	var requestBody struct {
		UserID string `json:"user_id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&requestBody); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверное тело запроса"})
		return
	}

	role, err := s.db.GetCustomRole(objectID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	if !role.CanAddMember() {
		c.JSON(http.StatusBadRequest, gin.H{"error": "нет доступных слотов для этой роли"})
		return
	}

	if role.HasMember(requestBody.UserID) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "у пользователя уже есть эта роль"})
		return
	}

	err = s.bot.GetSession().GuildMemberRoleAdd(s.config.DevServerID, requestBody.UserID, role.DiscordRoleID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось выдать роль в discord"})
		return
	}

	if !role.AddMember(requestBody.UserID) {
		s.bot.GetSession().GuildMemberRoleRemove(s.config.DevServerID, requestBody.UserID, role.DiscordRoleID)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось добавить участника в роль"})
		return
	}

	err = s.db.UpdateCustomRole(role)
	if err != nil {
		s.bot.GetSession().GuildMemberRoleRemove(s.config.DevServerID, requestBody.UserID, role.DiscordRoleID)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль в базе данных"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "роль успешно выдана",
		"role":    role,
	})
}

func (s *Server) handleAdminSearchUsers(c *gin.Context) {
	s.handleSearchUsers(c)
}

func (s *Server) handleAdminSearchRole(c *gin.Context) {
	roleID := c.Param("id")
	if roleID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "требуется идентификатор роли"})
		return
	}

	var roleInfo gin.H
	var members []gin.H

	if objectID, err := primitive.ObjectIDFromHex(roleID); err == nil {
		customRole, err := s.db.GetCustomRole(objectID)
		if err == nil && customRole != nil {
			owner, _ := s.db.GetUserByDiscordID(customRole.OwnerID)
			ownerName := "неизвестен"
			if owner != nil {
				ownerName = owner.Username
			}

			roleInfo = gin.H{
				"type":      "custom",
				"id":        customRole.ID.Hex(),
				"name":      customRole.Name,
				"discordID": customRole.DiscordRoleID,
				"owner":     ownerName,
				"ownerID":   customRole.OwnerID,
				"color":     customRole.Color,
				"icon":      customRole.Icon,
				"slots":     customRole.Slots,
				"expiresAt": customRole.ExpiresAt,
				"createdAt": customRole.CreatedAt,
			}

			session := s.bot.GetSession()
			for _, memberID := range customRole.Slots.Members {
				user, err := session.User(memberID)
				if err == nil {
					members = append(members, gin.H{
						"id":       memberID,
						"username": user.Username,
						"avatar":   user.Avatar,
					})
				} else {
					members = append(members, gin.H{
						"id":       memberID,
						"username": "неизвестный пользователь",
						"avatar":   "",
					})
				}
			}

			c.JSON(http.StatusOK, gin.H{
				"roleInfo": roleInfo,
				"members":  members,
				"count":    len(members),
			})
			return
		}
	}

	session := s.bot.GetSession()
	discordRole, err := session.State.Role(s.config.DevServerID, roleID)
	if err != nil {
		roles, err := session.GuildRoles(s.config.DevServerID)
		if err != nil {
			c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
			return
		}

		var foundRole *discordgo.Role
		for _, role := range roles {
			if role.ID == roleID {
				foundRole = role
				break
			}
		}

		if foundRole == nil {
			c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
			return
		}
		discordRole = foundRole
	}

	roleInfo = gin.H{
		"type":      "discord",
		"id":        discordRole.ID,
		"name":      discordRole.Name,
		"color":     fmt.Sprintf("#%06x", discordRole.Color),
		"position":  discordRole.Position,
		"createdAt": discordRole.ID,
	}

	guildMembers, err := session.GuildMembers(s.config.DevServerID, "", 1000)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось получить участников сервера"})
		return
	}

	for _, member := range guildMembers {
		for _, memberRoleID := range member.Roles {
			if memberRoleID == roleID {
				displayName := member.User.Username
				if member.Nick != "" {
					displayName = member.Nick
				}
				members = append(members, gin.H{
					"id":       member.User.ID,
					"username": member.User.Username,
					"avatar":   member.User.Avatar,
					"nickname": member.Nick,
					"display":  displayName,
				})
				break
			}
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"roleInfo": roleInfo,
		"members":  members,
		"count":    len(members),
	})
}

func (s *Server) handleAdminSearchRolesByName(c *gin.Context) {
	roleName := c.Query("name")
	if roleName == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Role name is required"})
		return
	}

	var allRoles []gin.H

	customRoles, err := s.db.GetCustomRolesByServer(s.config.DevServerID)
	if err == nil {
		for _, role := range customRoles {
			if strings.Contains(strings.ToLower(role.Name), strings.ToLower(roleName)) {
				owner, _ := s.db.GetUserByDiscordID(role.OwnerID)
				ownerName := "Unknown"
				if owner != nil {
					ownerName = owner.Username
				}

				allRoles = append(allRoles, gin.H{
					"id":          role.ID.Hex(),
					"name":        role.Name,
					"type":        "custom",
					"color":       role.Color.Primary,
					"owner":       ownerName,
					"memberCount": role.Slots.Used,
				})
			}
		}
	}

	session := s.bot.GetSession()
	discordRoles, err := session.GuildRoles(s.config.DevServerID)
	if err == nil {
		for _, role := range discordRoles {
			if strings.Contains(strings.ToLower(role.Name), strings.ToLower(roleName)) {
				guildMembers, _ := session.GuildMembers(s.config.DevServerID, "", 1000)
				memberCount := 0
				for _, member := range guildMembers {
					for _, memberRoleID := range member.Roles {
						if memberRoleID == role.ID {
							memberCount++
							break
						}
					}
				}

				allRoles = append(allRoles, gin.H{
					"id":          role.ID,
					"name":        role.Name,
					"type":        "discord",
					"color":       fmt.Sprintf("#%06x", role.Color),
					"memberCount": memberCount,
				})
			}
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"roles": allRoles,
	})
}

func (s *Server) handleAdminRemoveMember(c *gin.Context) {
	roleID := c.Param("id")
	userID := c.Param("user_id")

	if roleID == "" || userID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "требуется идентификатор роли и пользователя"})
		return
	}

	objectID, err := primitive.ObjectIDFromHex(roleID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный идентификатор роли"})
		return
	}

	customRole, err := s.db.GetCustomRole(objectID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	session := s.bot.GetSession()
	err = session.GuildMemberRoleRemove(s.config.DevServerID, userID, customRole.DiscordRoleID)
	if err != nil {
		log.Printf("не удалось удалить роль discord %s у пользователя %s: %v", customRole.DiscordRoleID, userID, err)
	}

	if customRole.RemoveMember(userID) {
		if err := s.db.UpdateCustomRole(customRole); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль в базе данных"})
			return
		}
		c.JSON(http.StatusOK, gin.H{"message": "пользователь удален из роли"})
	} else {
		c.JSON(http.StatusNotFound, gin.H{"error": "пользователь не найден в роли"})
	}
}

func (s *Server) handleAdminRemoveAllMembers(c *gin.Context) {
	roleID := c.Param("id")

	if roleID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "требуется идентификатор роли"})
		return
	}

	objectID, err := primitive.ObjectIDFromHex(roleID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный идентификатор роли"})
		return
	}

	customRole, err := s.db.GetCustomRole(objectID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	session := s.bot.GetSession()
	removedCount := 0

	for _, memberID := range customRole.Slots.Members {
		err = session.GuildMemberRoleRemove(s.config.DevServerID, memberID, customRole.DiscordRoleID)
		if err != nil {
			log.Printf("не удалось удалить роль discord %s у пользователя %s: %v", customRole.DiscordRoleID, memberID, err)
		} else {
			removedCount++
		}
	}

	customRole.Slots.Members = []string{}
	customRole.Slots.Used = 0
	customRole.UpdatedAt = time.Now()

	if err := s.db.UpdateCustomRole(customRole); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль в базе данных"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message":      "все участники удалены из роли",
		"removedCount": removedCount,
	})
}

func (s *Server) handleAdminRemoveDiscordMember(c *gin.Context) {
	roleID := c.Param("id")
	userID := c.Param("user_id")

	if roleID == "" || userID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "требуется идентификатор роли и пользователя"})
		return
	}

	session := s.bot.GetSession()
	err := session.GuildMemberRoleRemove(s.config.DevServerID, userID, roleID)
	if err != nil {
		log.Printf("не удалось удалить роль discord %s у пользователя %s: %v", roleID, userID, err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось удалить роль у пользователя"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "пользователь удален из роли"})
}

func (s *Server) handleAdminTransferRole(c *gin.Context) {
	roleID := c.Param("id")

	if roleID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "требуется идентификатор роли"})
		return
	}

	var req struct {
		NewOwnerID string `json:"new_owner_id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	objectID, err := primitive.ObjectIDFromHex(roleID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "неверный идентификатор роли"})
		return
	}

	customRole, err := s.db.GetCustomRole(objectID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "роль не найдена"})
		return
	}

	session := s.bot.GetSession()
	newOwner, err := session.User(req.NewOwnerID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "новый владелец не найден в Discord"})
		return
	}

	oldOwnerID := customRole.OwnerID
	customRole.OwnerID = req.NewOwnerID
	customRole.UpdatedAt = time.Now()

	if err := s.db.UpdateCustomRole(customRole); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "не удалось обновить роль в базе данных"})
		return
	}

	dbUser, err := s.db.GetUserByDiscordID(req.NewOwnerID)
	if err != nil {
		dbUser = &models.User{
			DiscordID: req.NewOwnerID,
			Username:  newOwner.Username,
			Avatar:    newOwner.Avatar,
		}
		if err := s.db.CreateUser(dbUser); err != nil {
			log.Printf("не удалось создать запись пользователя для нового владельца: %v", err)
		}
	} else {
		dbUser.Username = newOwner.Username
		dbUser.Avatar = newOwner.Avatar
		if err := s.db.UpdateUser(dbUser); err != nil {
			log.Printf("не удалось обновить запись пользователя для нового владельца: %v", err)
		}
	}

	log.Printf("роль '%s' (%s) передана от %s к %s", customRole.Name, customRole.ID.Hex(), oldOwnerID, req.NewOwnerID)

	c.JSON(http.StatusOK, gin.H{
		"message":      "роль успешно передана",
		"new_owner":    newOwner.Username,
		"new_owner_id": req.NewOwnerID,
	})
}
