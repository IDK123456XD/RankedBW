package models

import (
	"time"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type User struct {
	ID        primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	DiscordID string             `bson:"discord_id" json:"discord_id"`
	Username  string             `bson:"username" json:"username"`
	Avatar    string             `bson:"avatar" json:"avatar"`
	Roles     []CustomRole       `bson:"roles" json:"roles"`
	CreatedAt time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt time.Time          `bson:"updated_at" json:"updated_at"`
}

type CustomRole struct {
	ID            primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	Name          string             `bson:"name" json:"name"`
	Color         RoleColor          `bson:"color" json:"color"`
	Icon          RoleIcon           `bson:"icon" json:"icon"`
	OwnerID       string             `bson:"owner_id" json:"owner_id"`
	ServerID      string             `bson:"server_id" json:"server_id"`
	DiscordRoleID string             `bson:"discord_role_id" json:"discord_role_id"`
	Slots         RoleSlots          `bson:"slots" json:"slots"`
	ExpiresAt     time.Time          `bson:"expires_at" json:"expires_at"`
	CreatedAt     time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt     time.Time          `bson:"updated_at" json:"updated_at"`
}

type RoleColor struct {
	Type      string `bson:"type" json:"type"`
	Primary   string `bson:"primary" json:"primary"`
	Secondary string `bson:"secondary,omitempty" json:"secondary,omitempty"`
	Tertiary  string `bson:"tertiary,omitempty" json:"tertiary,omitempty"`
}

type RoleIcon struct {
	Type  string `bson:"type" json:"type"`
	Value string `bson:"value" json:"value"`
	URL   string `bson:"url,omitempty" json:"url,omitempty"`
}

type RoleSlots struct {
	Total   int      `bson:"total" json:"total"`
	Used    int      `bson:"used" json:"used"`
	Members []string `bson:"members" json:"members"`
}

type Server struct {
	ID              primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	DiscordServerID string             `bson:"discord_server_id" json:"discord_server_id"`
	Name            string             `bson:"name" json:"name"`
	Icon            string             `bson:"icon" json:"icon"`
	OwnerID         string             `bson:"owner_id" json:"owner_id"`
	Administrators  []string           `bson:"administrators" json:"administrators"`
	Settings        ServerSettings     `bson:"settings" json:"settings"`
	CreatedAt       time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt       time.Time          `bson:"updated_at" json:"updated_at"`
}

type ServerSettings struct {
	AllowCustomRoles bool `bson:"allow_custom_roles" json:"allow_custom_roles"`
	MaxRolesPerUser  int  `bson:"max_roles_per_user" json:"max_roles_per_user"`
	DefaultSlots     int  `bson:"default_slots" json:"default_slots"`
	RoleExpiryHours  int  `bson:"role_expiry_hours" json:"role_expiry_hours"`
	RequireApproval  bool `bson:"require_approval" json:"require_approval"`
}

type RoleTransaction struct {
	ID                 primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	UserID             string             `bson:"user_id" json:"user_id"`
	RoleID             primitive.ObjectID `bson:"role_id" json:"role_id"`
	Type               string             `bson:"type" json:"type"`
	Amount             float64            `bson:"amount" json:"amount"`
	Currency           string             `bson:"currency" json:"currency"`
	TebexTransactionID string             `bson:"tebex_transaction_id,omitempty" json:"tebex_transaction_id,omitempty"`
	Status             string             `bson:"status" json:"status"`
	CreatedAt          time.Time          `bson:"created_at" json:"created_at"`
}

func (cr *CustomRole) IsExpired() bool {
	return time.Now().After(cr.ExpiresAt)
}

func (cr *CustomRole) CanAddMember() bool {
	return cr.Slots.Used < cr.Slots.Total
}

func (cr *CustomRole) AddMember(userID string) bool {
	if !cr.CanAddMember() {
		return false
	}

	for _, member := range cr.Slots.Members {
		if member == userID {
			return false
		}
	}

	cr.Slots.Members = append(cr.Slots.Members, userID)
	cr.Slots.Used++
	cr.UpdatedAt = time.Now()
	return true
}

func (cr *CustomRole) RemoveMember(userID string) bool {
	for i, member := range cr.Slots.Members {
		if member == userID {
			cr.Slots.Members = append(cr.Slots.Members[:i], cr.Slots.Members[i+1:]...)
			cr.Slots.Used--
			cr.UpdatedAt = time.Now()
			return true
		}
	}
	return false
}

func (cr *CustomRole) HasMember(userID string) bool {
	for _, member := range cr.Slots.Members {
		if member == userID {
			return true
		}
	}
	return false
}

type Purchase struct {
	ID          primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	UserID      string             `bson:"user_id" json:"user_id"`
	Username    string             `bson:"username" json:"username"`
	ProductType string             `bson:"product_type" json:"product_type"`
	IsPermanent bool               `bson:"is_permanent" json:"is_permanent"`
	ExpiresAt   time.Time          `bson:"expires_at" json:"expires_at"`
	UsedAt      *time.Time         `bson:"used_at,omitempty" json:"used_at,omitempty"`
	RoleID      string             `bson:"role_id,omitempty" json:"role_id,omitempty"`
	MessageID   string             `bson:"message_id" json:"message_id"`
	CreatedAt   time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt   time.Time          `bson:"updated_at" json:"updated_at"`
}

type MessageProcessingState struct {
	ID              primitive.ObjectID `bson:"_id,omitempty" json:"id"`
	ChannelID       string             `bson:"channel_id" json:"channel_id"`
	LastMessageID   string             `bson:"last_message_id" json:"last_message_id"`
	LastProcessedAt time.Time          `bson:"last_processed_at" json:"last_processed_at"`
	CreatedAt       time.Time          `bson:"created_at" json:"created_at"`
	UpdatedAt       time.Time          `bson:"updated_at" json:"updated_at"`
}

func (p *Purchase) IsExpired() bool {
	if p.IsPermanent {
		return false
	}
	return time.Now().After(p.ExpiresAt)
}

func (p *Purchase) IsUsed() bool {
	return p.UsedAt != nil
}
