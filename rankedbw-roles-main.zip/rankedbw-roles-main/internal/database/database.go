package database

import (
	"context"
	"log"
	"time"

	"ranked-roles/internal/config"
	"ranked-roles/internal/models"

	"github.com/redis/go-redis/v9"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type Database struct {
	MongoDB *mongo.Database
	Redis   *redis.Client
	config  *config.Config
}

func New(cfg *config.Config) (*Database, error) {
	mongoClient, err := mongo.Connect(context.Background(), options.Client().ApplyURI(cfg.MongoURI))
	if err != nil {
		return nil, err
	}

	if err := mongoClient.Ping(context.Background(), nil); err != nil {
		return nil, err
	}

	mongodb := mongoClient.Database("ranked_roles")

	redisOpts, err := redis.ParseURL(cfg.RedisURI)
	if err != nil {
		return nil, err
	}

	redisClient := redis.NewClient(redisOpts)

	if err := redisClient.Ping(context.Background()).Err(); err != nil {
		return nil, err
	}

	db := &Database{
		MongoDB: mongodb,
		Redis:   redisClient,
		config:  cfg,
	}

	if err := db.createIndexes(); err != nil {
		return nil, err
	}

	return db, nil
}

func (d *Database) Close() error {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := d.MongoDB.Client().Disconnect(ctx); err != nil {
		return err
	}

	return d.Redis.Close()
}

func (d *Database) createIndexes() error {
	ctx := context.Background()

	usersCollection := d.MongoDB.Collection("users")
	_, err := usersCollection.Indexes().CreateOne(ctx, mongo.IndexModel{
		Keys:    bson.D{{Key: "discord_id", Value: 1}},
		Options: options.Index().SetUnique(true),
	})
	if err != nil {
		return err
	}

	rolesCollection := d.MongoDB.Collection("custom_roles")
	_, err = rolesCollection.Indexes().CreateMany(ctx, []mongo.IndexModel{
		{
			Keys: bson.D{{Key: "owner_id", Value: 1}},
		},
		{
			Keys: bson.D{{Key: "server_id", Value: 1}},
		},
		{
			Keys: bson.D{{Key: "discord_role_id", Value: 1}},
		},
		{
			Keys: bson.D{{Key: "expires_at", Value: 1}},
		},
	})
	if err != nil {
		return err
	}

	serversCollection := d.MongoDB.Collection("servers")
	_, err = serversCollection.Indexes().CreateOne(ctx, mongo.IndexModel{
		Keys:    bson.D{{Key: "discord_server_id", Value: 1}},
		Options: options.Index().SetUnique(true),
	})
	if err != nil {
		return err
	}

	return nil
}

func (d *Database) CreateUser(user *models.User) error {
	user.CreatedAt = time.Now()
	user.UpdatedAt = time.Now()

	collection := d.MongoDB.Collection("users")
	result, err := collection.InsertOne(context.Background(), user)
	if err != nil {
		return err
	}

	user.ID = result.InsertedID.(primitive.ObjectID)
	return nil
}

func (d *Database) GetUserByDiscordID(discordID string) (*models.User, error) {
	collection := d.MongoDB.Collection("users")
	var user models.User

	err := collection.FindOne(context.Background(), bson.M{"discord_id": discordID}).Decode(&user)
	if err != nil {
		return nil, err
	}

	return &user, nil
}

func (d *Database) UpdateUser(user *models.User) error {
	user.UpdatedAt = time.Now()

	collection := d.MongoDB.Collection("users")
	_, err := collection.UpdateOne(
		context.Background(),
		bson.M{"_id": user.ID},
		bson.M{"$set": user},
	)

	return err
}

func (d *Database) CreateCustomRole(role *models.CustomRole) error {
	role.CreatedAt = time.Now()
	role.UpdatedAt = time.Now()

	collection := d.MongoDB.Collection("custom_roles")
	result, err := collection.InsertOne(context.Background(), role)
	if err != nil {
		return err
	}

	role.ID = result.InsertedID.(primitive.ObjectID)
	return nil
}

func (d *Database) GetCustomRole(id primitive.ObjectID) (*models.CustomRole, error) {
	collection := d.MongoDB.Collection("custom_roles")
	var role models.CustomRole

	err := collection.FindOne(context.Background(), bson.M{"_id": id}).Decode(&role)
	if err != nil {
		return nil, err
	}

	return &role, nil
}

func (d *Database) GetCustomRolesByOwner(ownerID string) ([]models.CustomRole, error) {
	collection := d.MongoDB.Collection("custom_roles")
	cursor, err := collection.Find(context.Background(), bson.M{"owner_id": ownerID})
	if err != nil {
		return nil, err
	}
	defer cursor.Close(context.Background())

	var roles []models.CustomRole
	if err := cursor.All(context.Background(), &roles); err != nil {
		return nil, err
	}

	return roles, nil
}

func (d *Database) GetUserCustomRoleOnServer(ownerID, serverID string) (*models.CustomRole, error) {
	collection := d.MongoDB.Collection("custom_roles")
	var role models.CustomRole

	err := collection.FindOne(context.Background(), bson.M{
		"owner_id":  ownerID,
		"server_id": serverID,
	}).Decode(&role)

	if err != nil {
		if err == mongo.ErrNoDocuments {
			return nil, nil
		}
		return nil, err
	}

	return &role, nil
}

func (d *Database) ExtendRoleExpiration(roleID primitive.ObjectID, additionalDays int) error {
	collection := d.MongoDB.Collection("custom_roles")

	var role models.CustomRole
	err := collection.FindOne(context.Background(), bson.M{"_id": roleID}).Decode(&role)
	if err != nil {
		return err
	}

	var newExpiresAt time.Time
	if role.ExpiresAt.After(time.Now()) {
		newExpiresAt = role.ExpiresAt.AddDate(0, 0, additionalDays)
	} else {
		newExpiresAt = time.Now().AddDate(0, 0, additionalDays)
	}

	_, err = collection.UpdateOne(
		context.Background(),
		bson.M{"_id": roleID},
		bson.M{
			"$set": bson.M{
				"expires_at": newExpiresAt,
				"updated_at": time.Now(),
			},
		},
	)

	return err
}

func (d *Database) GetCustomRolesByServer(serverID string) ([]models.CustomRole, error) {
	collection := d.MongoDB.Collection("custom_roles")
	cursor, err := collection.Find(context.Background(), bson.M{"server_id": serverID})
	if err != nil {
		return nil, err
	}
	defer cursor.Close(context.Background())

	var roles []models.CustomRole
	for cursor.Next(context.Background()) {
		var role models.CustomRole
		if err := cursor.Decode(&role); err != nil {
			var rawDoc bson.M
			cursor.Decode(&rawDoc)
			log.Printf("failed decoding role (ID: %v, Name: %v): %v", rawDoc["_id"], rawDoc["name"], err)
			continue
		}
		roles = append(roles, role)
	}

	if err := cursor.Err(); err != nil {
		return nil, err
	}

	return roles, nil
}

func (d *Database) GetCustomRoleByDiscordRoleID(serverID, discordRoleID string) (*models.CustomRole, error) {
	collection := d.MongoDB.Collection("custom_roles")
	var role models.CustomRole
	err := collection.FindOne(context.Background(), bson.M{"server_id": serverID, "discord_role_id": discordRoleID}).Decode(&role)
	if err != nil {
		if err == mongo.ErrNoDocuments {
			return nil, nil
		}
		return nil, err
	}
	return &role, nil
}

func (d *Database) UpdateCustomRole(role *models.CustomRole) error {
	role.UpdatedAt = time.Now()

	collection := d.MongoDB.Collection("custom_roles")
	_, err := collection.UpdateOne(
		context.Background(),
		bson.M{"_id": role.ID},
		bson.M{"$set": role},
	)

	return err
}

func (d *Database) DeleteCustomRole(id primitive.ObjectID) error {
	collection := d.MongoDB.Collection("custom_roles")
	_, err := collection.DeleteOne(context.Background(), bson.M{"_id": id})
	return err
}

func (d *Database) GetExpiredRoles() ([]models.CustomRole, error) {
	collection := d.MongoDB.Collection("custom_roles")
	graceCutoff := time.Now().Add(-48 * time.Hour)
	cursor, err := collection.Find(context.Background(), bson.M{
		"expires_at": bson.M{"$lt": graceCutoff},
	})
	if err != nil {
		return nil, err
	}
	defer cursor.Close(context.Background())

	var roles []models.CustomRole
	if err := cursor.All(context.Background(), &roles); err != nil {
		return nil, err
	}

	return roles, nil
}

func (d *Database) CreateServer(server *models.Server) error {
	server.CreatedAt = time.Now()
	server.UpdatedAt = time.Now()

	collection := d.MongoDB.Collection("servers")
	result, err := collection.InsertOne(context.Background(), server)
	if err != nil {
		return err
	}

	server.ID = result.InsertedID.(primitive.ObjectID)
	return nil
}

func (d *Database) GetServerByDiscordID(discordServerID string) (*models.Server, error) {
	collection := d.MongoDB.Collection("servers")
	var server models.Server

	err := collection.FindOne(context.Background(), bson.M{"discord_server_id": discordServerID}).Decode(&server)
	if err != nil {
		return nil, err
	}

	return &server, nil
}

func (d *Database) UpdateServer(server *models.Server) error {
	server.UpdatedAt = time.Now()

	collection := d.MongoDB.Collection("servers")
	_, err := collection.UpdateOne(
		context.Background(),
		bson.M{"_id": server.ID},
		bson.M{"$set": server},
	)

	return err
}

func (d *Database) CreateTransaction(transaction *models.RoleTransaction) error {
	transaction.CreatedAt = time.Now()

	collection := d.MongoDB.Collection("transactions")
	result, err := collection.InsertOne(context.Background(), transaction)
	if err != nil {
		return err
	}

	transaction.ID = result.InsertedID.(primitive.ObjectID)
	return nil
}

func (d *Database) SetCache(key string, value interface{}, expiration time.Duration) error {
	return d.Redis.Set(context.Background(), key, value, expiration).Err()
}

func (d *Database) GetCache(key string) (string, error) {
	return d.Redis.Get(context.Background(), key).Result()
}

func (d *Database) DeleteCache(key string) error {
	return d.Redis.Del(context.Background(), key).Err()
}

func (d *Database) CreatePurchase(purchase *models.Purchase) error {
	purchase.ID = primitive.NewObjectID()
	purchase.CreatedAt = time.Now()
	purchase.UpdatedAt = time.Now()

	collection := d.MongoDB.Collection("purchases")
	_, err := collection.InsertOne(context.Background(), purchase)
	return err
}

func (d *Database) GetUserPurchases(userID string) ([]models.Purchase, error) {
	collection := d.MongoDB.Collection("purchases")
	filter := bson.M{"user_id": userID}

	cursor, err := collection.Find(context.Background(), filter, options.Find().SetSort(bson.M{"created_at": -1}))
	if err != nil {
		return nil, err
	}
	defer cursor.Close(context.Background())

	var purchases []models.Purchase
	if err := cursor.All(context.Background(), &purchases); err != nil {
		return nil, err
	}

	return purchases, nil
}

func (d *Database) GetAvailablePurchase(userID string) (*models.Purchase, error) {
	collection := d.MongoDB.Collection("purchases")

	filter := bson.M{
		"user_id":      userID,
		"used_at":      bson.M{"$exists": false},
		"product_type": bson.M{"$regex": "Custom", "$options": "i"},
		"$or": []bson.M{
			{"is_permanent": true},
			{"expires_at": bson.M{"$gt": time.Now()}},
		},
	}

	var purchase models.Purchase
	err := collection.FindOne(context.Background(), filter, options.FindOne().SetSort(bson.M{"created_at": 1})).Decode(&purchase)
	if err != nil {
		return nil, err
	}

	return &purchase, nil
}

func (d *Database) MarkPurchaseAsUsed(purchaseID primitive.ObjectID, roleID string) error {
	collection := d.MongoDB.Collection("purchases")
	now := time.Now()

	filter := bson.M{"_id": purchaseID}
	update := bson.M{
		"$set": bson.M{
			"used_at":    now,
			"role_id":    roleID,
			"updated_at": now,
		},
	}

	_, err := collection.UpdateOne(context.Background(), filter, update)
	return err
}

func (d *Database) GetUserActiveRoleCount(userID string) (int, error) {
	collection := d.MongoDB.Collection("custom_roles")
	filter := bson.M{
		"owner_id":   userID,
		"expires_at": bson.M{"$gt": time.Now()},
	}

	count, err := collection.CountDocuments(context.Background(), filter)
	return int(count), err
}

func (d *Database) GetMessageProcessingState(channelID string) (*models.MessageProcessingState, error) {
	collection := d.MongoDB.Collection("message_processing_state")
	filter := bson.M{"channel_id": channelID}

	var state models.MessageProcessingState
	err := collection.FindOne(context.Background(), filter).Decode(&state)
	if err != nil {
		return nil, err
	}

	return &state, nil
}

func (d *Database) UpdateMessageProcessingState(channelID, messageID string) error {
	collection := d.MongoDB.Collection("message_processing_state")
	now := time.Now()

	filter := bson.M{"channel_id": channelID}
	update := bson.M{
		"$set": bson.M{
			"last_message_id":   messageID,
			"last_processed_at": now,
			"updated_at":        now,
		},
		"$setOnInsert": bson.M{
			"created_at": now,
		},
	}

	opts := options.Update().SetUpsert(true)
	_, err := collection.UpdateOne(context.Background(), filter, update, opts)
	return err
}

func (d *Database) CreatePurchaseIfNotExists(purchase *models.Purchase) (bool, error) {
	collection := d.MongoDB.Collection("purchases")

	filter := bson.M{"message_id": purchase.MessageID}
	var existingPurchase models.Purchase
	err := collection.FindOne(context.Background(), filter).Decode(&existingPurchase)

	if err == nil {
		return false, nil
	}

	if err == mongo.ErrNoDocuments {
		purchase.ID = primitive.NewObjectID()
		purchase.CreatedAt = time.Now()
		purchase.UpdatedAt = time.Now()

		_, err := collection.InsertOne(context.Background(), purchase)
		return err == nil, err
	}

	return false, err
}

func (d *Database) GetPurchaseByMessageID(messageID string) (*models.Purchase, error) {
	collection := d.MongoDB.Collection("purchases")
	filter := bson.M{"message_id": messageID}

	var purchase models.Purchase
	err := collection.FindOne(context.Background(), filter).Decode(&purchase)
	if err != nil {
		return nil, err
	}

	return &purchase, nil
}
