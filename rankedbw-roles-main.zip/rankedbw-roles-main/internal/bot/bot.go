package bot

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"ranked-roles/internal/commands"
	_ "ranked-roles/internal/commands/dev"
	"ranked-roles/internal/config"
	"ranked-roles/internal/database"
	"ranked-roles/internal/models"

	"github.com/bwmarrin/discordgo"
)

type Bot struct {
	session *discordgo.Session
	config  *config.Config
	db      *database.Database
}

func New(cfg *config.Config, db *database.Database) (*Bot, error) {
	session, err := discordgo.New("Bot " + cfg.DiscordToken)
	if err != nil {
		return nil, err
	}

	bot := &Bot{
		session: session,
		config:  cfg,
		db:      db,
	}

	session.AddHandler(bot.onReady)
	session.AddHandler(bot.onGuildCreate)
	session.AddHandler(bot.onMessageCreate)
	session.AddHandler(bot.onGuildMemberUpdate)
	session.AddHandler(bot.onGuildMemberAdd)
	session.AddHandler(bot.onInteractionCreate)

	commands.Init(cfg, bot.processMissedPurchaseMessages, bot.fullRescanPurchaseMessages, func(serverID, discordRoleID string) (*models.CustomRole, error) {
		return db.GetCustomRoleByDiscordRoleID(serverID, discordRoleID)
	})

	session.Identify.Intents = discordgo.IntentsGuilds | discordgo.IntentsGuildMembers | discordgo.IntentsGuildMessages | discordgo.IntentsMessageContent

	return bot, nil
}

func (b *Bot) Start() error {
	if err := b.session.Open(); err != nil {
		return err
	}

	go b.roleExpiryChecker()

	go b.processMissedPurchaseMessages()

	return nil
}

func (b *Bot) Stop() error {
	return b.session.Close()
}

func (b *Bot) GetSession() *discordgo.Session {
	return b.session
}

func (b *Bot) SearchGuildMembers(guildID, query string) ([]*discordgo.Member, error) {
	log.Printf("вызван SearchGuildMembers с guildID: %s, запрос: %s", guildID, query)

	members, err := b.session.GuildMembers(guildID, "", 1000)
	if err != nil {
		log.Printf("не удалось получить участников сервера: %v", err)
		return nil, err
	}

	log.Printf("получено %d всего участников сервера", len(members))
	var matchingMembers []*discordgo.Member
	lowerQuery := strings.ToLower(query)

	log.Printf("поиск по запросу: '%s' (в нижнем регистре: '%s')", query, lowerQuery)

	for i, member := range members {
		if member.User != nil {
			username := strings.ToLower(member.User.Username)
			userID := member.User.ID
			displayName := ""

			if member.Nick != "" {
				displayName = strings.ToLower(member.Nick)
			}

			if i < 5 || userID == query {
				log.Printf("участник %d - ID: %s, имя пользователя: %s, отображаемое имя: %s", i, userID, username, displayName)
			}

			if strings.Contains(username, lowerQuery) ||
				strings.Contains(displayName, lowerQuery) ||
				strings.Contains(userID, lowerQuery) {
				log.Printf("найдено совпадение - ID: %s, имя пользователя: %s", userID, username)
				matchingMembers = append(matchingMembers, member)
			}
		}
	}

	if len(matchingMembers) > 10 {
		matchingMembers = matchingMembers[:10]
	}

	return matchingMembers, nil
}

func (b *Bot) onReady(s *discordgo.Session, event *discordgo.Ready) {
	log.Printf("бот ролей готов! авторизован как %s", event.User.String())

	if len(b.config.ForceDeleteCommandIDs) > 0 {
		for _, id := range b.config.ForceDeleteCommandIDs {
			if err := s.ApplicationCommandDelete(s.State.User.ID, b.config.DevServerID, id); err != nil {
				log.Printf("принудительное удаление не удалось для ID команды %s: %v", id, err)
			} else {
				log.Printf("принудительно удалена команда с ID %s", id)
			}
		}
	}

	if b.config.UnregisterSlashCommands {
		existing, err := s.ApplicationCommands(s.State.User.ID, b.config.DevServerID)
		if err != nil {
			log.Printf("не удалось получить существующие команды для отмены регистрации: %v", err)
		} else {
			wanted := map[string]struct{}{}
			for _, rc := range commands.GetCommands() {
				wanted[rc.Name] = struct{}{}
			}
			for _, ec := range existing {
				if _, ok := wanted[ec.Name]; ok {
					if err := s.ApplicationCommandDelete(s.State.User.ID, b.config.DevServerID, ec.ID); err != nil {
						log.Printf("не удалось удалить команду %s: %v", ec.Name, err)
					} else {
						log.Printf("отменена регистрация slash команды: %s", ec.Name)
					}
				}
			}
		}
	}

	if b.config.RegisterSlashCommands {
		for _, c := range commands.GetCommands() {
			if _, err := s.ApplicationCommandCreate(s.State.User.ID, b.config.DevServerID, c); err != nil {
				log.Printf("не удалось зарегистрировать команду %s: %v", c.Name, err)
			} else {
				log.Printf("зарегистрирована slash команда: %s", c.Name)
			}
		}
	}
}

func (b *Bot) onGuildCreate(s *discordgo.Session, event *discordgo.GuildCreate) {
	server, err := b.db.GetServerByDiscordID(event.ID)
	if err != nil {
		newServer := &models.Server{
			DiscordServerID: event.ID,
			Name:            event.Name,
			Icon:            event.Icon,
			OwnerID:         event.OwnerID,
			Settings: models.ServerSettings{
				AllowCustomRoles: true,
				MaxRolesPerUser:  5,
				DefaultSlots:     b.config.DefaultSlots,
				RoleExpiryHours:  b.config.RoleExpiryHours,
				RequireApproval:  false,
			},
		}

		if err := b.db.CreateServer(newServer); err != nil {
			log.Printf("не удалось создать запись сервера: %v", err)
		}
	} else {
		server.Name = event.Name
		server.Icon = event.Icon
		server.OwnerID = event.OwnerID
		if err := b.db.UpdateServer(server); err != nil {
			log.Printf("не удалось обновить сервер: %v", err)
		}
	}
}

func (b *Bot) onGuildMemberUpdate(s *discordgo.Session, event *discordgo.GuildMemberUpdate) {
	if event == nil || event.User == nil {
		return
	}

	roles, err := b.db.GetCustomRolesByServer(event.GuildID)
	if err != nil {
		log.Printf("обновление участника сервера: не удалось получить пользовательские роли для сервера %s: %v", event.GuildID, err)
		return
	}

	currentRoles := make(map[string]struct{}, len(event.Roles))
	for _, rID := range event.Roles {
		currentRoles[rID] = struct{}{}
	}

	userID := event.User.ID
	changed := false

	for _, cr := range roles {
		_, memberStillHasDiscordRole := currentRoles[cr.DiscordRoleID]

		if cr.HasMember(userID) {
			if !memberStillHasDiscordRole {
				if cr.RemoveMember(userID) {
					if err := b.db.UpdateCustomRole(&cr); err != nil {
						log.Printf("обновление участника сервера: не удалось обновить роль %s после ручного удаления: %v", cr.ID.Hex(), err)
					} else {
						log.Printf("освобожден слот: пользователь %s удален из пользовательской роли '%s' (%s) через ручное удаление в discord", userID, cr.Name, cr.DiscordRoleID)
						changed = true
					}
				}
			}
		} else {
			if memberStillHasDiscordRole && cr.CanAddMember() {
				if cr.AddMember(userID) {
					if err := b.db.UpdateCustomRole(&cr); err != nil {
						log.Printf("обновление участника сервера: не удалось обновить роль %s после ручного добавления: %v", cr.ID.Hex(), err)
					} else {
						log.Printf("занят слот: пользователь %s вручную добавлен в пользовательскую роль '%s' (%s)", userID, cr.Name, cr.DiscordRoleID)
						changed = true
					}
				}
			} else if memberStillHasDiscordRole && !cr.CanAddMember() {
				log.Printf("обновление участника сервера: роль '%s' (%s) заполнена; у пользователя %s есть роль discord вручную, но не отслеживается", cr.Name, cr.DiscordRoleID, userID)
			}
		}
	}

	if changed {
	}
}

func (b *Bot) onGuildMemberAdd(s *discordgo.Session, event *discordgo.GuildMemberAdd) {
	if event == nil || event.User == nil {
		return
	}

	userID := event.User.ID
	guildID := event.GuildID

	roles, err := b.db.GetCustomRolesByServer(guildID)
	if err != nil {
		log.Printf("добавление участника сервера: не удалось получить пользовательские роли для сервера %s: %v", guildID, err)
		return
	}

	now := time.Now()
	reGranted := 0
	for _, cr := range roles {
		if !cr.HasMember(userID) {
			continue
		}
		if cr.ExpiresAt.Before(now) {
			continue
		}
		if err := s.GuildMemberRoleAdd(guildID, userID, cr.DiscordRoleID); err != nil {
			log.Printf("добавление участника сервера: не удалось повторно выдать роль %s (%s) пользователю %s: %v", cr.Name, cr.DiscordRoleID, userID, err)
			continue
		}
		reGranted++
	}

	if reGranted > 0 {
		log.Printf("повторно выдано %d пользовательских ролей вернувшемуся пользователю %s на сервере %s", reGranted, userID, guildID)
	}
}

func (b *Bot) onInteractionCreate(s *discordgo.Session, ic *discordgo.InteractionCreate) {
	if ic.Type != discordgo.InteractionApplicationCommand {
		return
	}
	name := ic.ApplicationCommandData().Name
	if handler := commands.GetHandler(name); handler != nil {
		handler(s, ic)
	}
}

func (b *Bot) onMessageCreate(s *discordgo.Session, m *discordgo.MessageCreate) {
	if m.Author.ID == s.State.User.ID {
		return
	}

	if m.ChannelID != b.config.PurchaseChannelID {
		return
	}

	if m.Author.ID != b.config.TebexBotID {
		return
	}

	log.Printf("мониторинг tebex сообщения: %s", m.Content)

	b.processPurchase(m.ID, m.Content, false, time.Now())

	if err := b.db.UpdateMessageProcessingState(m.ChannelID, m.ID); err != nil {
		log.Printf("не удалось обновить состояние обработки сообщений: %v", err)
	}
}

func (b *Bot) parsePurchaseMessageAt(messageID, content string, baseTime time.Time) *models.Purchase {
	if !(strings.Contains(content, "has purchased a Custom Role") || strings.Contains(content, "has purchased Prime++")) {
		return nil
	}

	uidOpen := strings.Index(content, "<@")
	if uidOpen == -1 {
		return nil
	}
	uidClose := strings.Index(content[uidOpen:], ">")
	if uidClose == -1 {
		return nil
	}
	uidClose += uidOpen
	userID := content[uidOpen+2 : uidClose]

	remainder := content[uidClose+1:]
	marker := " has purchased"
	markerPos := strings.Index(remainder, marker)
	username := ""
	if markerPos > 0 {
		raw := strings.TrimSpace(remainder[:markerPos])
		if raw != "" {
			username = raw
		}
	}

	var productType string
	var isPermanent bool
	var expiresAt time.Time
	switch {
	case strings.Contains(content, "Custom Role [Perm]"):
		productType = "Custom Role [Perm]"
		isPermanent = true
		expiresAt = baseTime.AddDate(100, 0, 0)
	case strings.Contains(content, "Custom Role [Monthly]"):
		productType = "Custom Role [Monthly]"
		expiresAt = baseTime.AddDate(0, 1, 0)
	case strings.Contains(content, "has purchased Prime++"):
		productType = "Custom Role [Monthly]"
		expiresAt = baseTime.AddDate(0, 1, 0)
	default:
		log.Printf("неизвестный тип продукта в сообщении: %s", content)
		return nil
	}

	return &models.Purchase{
		UserID:      userID,
		Username:    username,
		ProductType: productType,
		IsPermanent: isPermanent,
		ExpiresAt:   expiresAt,
		MessageID:   messageID,
	}
}

func (b *Bot) parsePurchaseMessage(messageID, content string) *models.Purchase {
	return b.parsePurchaseMessageAt(messageID, content, time.Now())
}

func (b *Bot) processPurchase(messageID, content string, isRescan bool, baseTime time.Time) {
	if !(strings.Contains(content, "has purchased a Custom Role") || strings.Contains(content, "has purchased Prime++")) {
		return
	}
	purchase := b.parsePurchaseMessageAt(messageID, content, baseTime)
	if purchase == nil {
		log.Printf("не удалось разобрать сообщение о покупке пользовательской роли: %s", content)
		return
	}
	if isRescan && purchase.ExpiresAt.Before(time.Now()) {
		log.Printf("пропуск просроченной исторической покупки (сообщение %s пользователь %s истекает:%s)", messageID, purchase.UserID, purchase.ExpiresAt.Format(time.RFC3339))
		return
	}
	created, err := b.db.CreatePurchaseIfNotExists(purchase)
	if err != nil {
		log.Printf("не удалось сохранить покупку: %v", err)
		return
	}
	if created {
		if strings.Contains(purchase.ProductType, "Monthly") {
			if !isRescan || (isRescan && b.config.AutoExtendMonthlyRoles) {
				b.handleMonthlyPurchaseExtension(purchase)
			}
		}
		log.Printf("записана новая покупка для пользователя %s (%s): %s", purchase.Username, purchase.UserID, purchase.ProductType)
	} else if !isRescan {
		log.Printf("покупка уже существует (ID сообщения: %s), пропуск", messageID)
	}
}

func (b *Bot) handleMonthlyPurchaseExtension(purchase *models.Purchase) {
	existingRoles, err := b.db.GetCustomRolesByOwner(purchase.UserID)
	if err != nil {
		log.Printf("не удалось получить существующие роли для пользователя %s: %v", purchase.UserID, err)
		return
	}

	for _, role := range existingRoles {
		if role.ExpiresAt.Before(time.Now().AddDate(50, 0, 0)) {
			err := b.db.ExtendRoleExpiration(role.ID, 31)
			if err != nil {
				log.Printf("не удалось продлить роль %s для пользователя %s: %v", role.Name, purchase.UserID, err)
				continue
			}

			err = b.db.MarkPurchaseAsUsed(purchase.ID, role.ID.Hex())
			if err != nil {
				log.Printf("не удалось пометить покупку как использованную для продления роли: %v", err)
			}

			log.Printf("автоматически продлена роль '%s' для пользователя %s (%s) на 31 день", role.Name, purchase.Username, purchase.UserID)
		}
	}
}

func (b *Bot) processMissedPurchaseMessages() {
	log.Printf("проверка пропущенных сообщений о покупках...")

	state, err := b.db.GetMessageProcessingState(b.config.PurchaseChannelID)
	var lastMessageID string
	if err != nil {
		log.Printf("предыдущее состояние обработки сообщений не найдено, начинаем заново")
		lastMessageID = ""
	} else {
		lastMessageID = state.LastMessageID
		log.Printf("последний обработанный ID сообщения: %s", lastMessageID)
	}

	messages, err := b.fetchMessagesAfter(b.config.PurchaseChannelID, lastMessageID)
	if err != nil {
		log.Printf("не удалось получить пропущенные сообщения: %v", err)
		return
	}

	log.Printf("найдено %d сообщений для обработки", len(messages))

	for i := len(messages) - 1; i >= 0; i-- {
		msg := messages[i]

		if msg.Author.ID != b.config.TebexBotID {
			continue
		}

		log.Printf("обработка пропущенного сообщения: %s", msg.Content)

		b.processPurchase(msg.ID, msg.Content, true, msg.Timestamp)

		if err := b.db.UpdateMessageProcessingState(b.config.PurchaseChannelID, msg.ID); err != nil {
			log.Printf("не удалось обновить состояние обработки сообщений: %v", err)
		}
	}

	log.Printf("завершена обработка пропущенных сообщений")
}

func (b *Bot) fullRescanPurchaseMessages() {
	log.Printf("запуск полного пересканирования канала покупок...")
	channelID := b.config.PurchaseChannelID
	var before string
	var all []*discordgo.Message
	for {
		msgs, err := b.session.ChannelMessages(channelID, 100, before, "", "")
		if err != nil {
			log.Printf("полное пересканирование: ошибка получения: %v", err)
			break
		}
		if len(msgs) == 0 {
			break
		}
		all = append(all, msgs...)
		if len(msgs) < 100 {
			break
		}
		before = msgs[len(msgs)-1].ID
		if len(all)%500 == 0 {
			log.Printf("полное пересканирование: получено %d сообщений пока...", len(all))
		}
	}
	log.Printf("полное пересканирование: всего получено сообщений: %d", len(all))
	for i := len(all) - 1; i >= 0; i-- {
		m := all[i]
		if m.Author == nil || m.Author.ID != b.config.TebexBotID {
			continue
		}
		b.processPurchase(m.ID, m.Content, true, m.Timestamp)
	}
	log.Printf("полное пересканирование завершено.")
}

func (b *Bot) fetchMessagesAfter(channelID, afterMessageID string) ([]*discordgo.Message, error) {
	var allMessages []*discordgo.Message
	var lastMessageID string = afterMessageID

	for {
		var messages []*discordgo.Message
		var err error

		if lastMessageID == "" {
			messages, err = b.session.ChannelMessages(channelID, 100, "", "", "")
		} else {
			messages, err = b.session.ChannelMessages(channelID, 100, "", lastMessageID, "")
		}

		if err != nil {
			return nil, err
		}

		if len(messages) == 0 {
			break
		}

		allMessages = append(allMessages, messages...)

		lastMessageID = messages[len(messages)-1].ID

		if len(messages) < 100 {
			break
		}
	}

	return allMessages, nil
}

func (b *Bot) roleExpiryChecker() {
	ticker := time.NewTicker(10 * time.Minute)
	defer ticker.Stop()
	for range ticker.C {
		b.checkExpiredRoles()
	}
}

func (b *Bot) checkExpiredRoles() {
	expiredRoles, err := b.db.GetExpiredRoles()
	if err != nil {
		log.Printf("не удалось получить просроченные роли: %v", err)
		return
	}

	for _, role := range expiredRoles {
		err := b.session.GuildRoleDelete(role.ServerID, role.DiscordRoleID)
		if err != nil {
			log.Printf("не удалось удалить роль discord %s: %v", role.DiscordRoleID, err)
		}

		err = b.db.DeleteCustomRole(role.ID)
		if err != nil {
			log.Printf("не удалось удалить пользовательскую роль из базы данных: %v", err)
		}

		log.Printf("удалена истекшая роль: %s (владелец: %s)", role.Name, role.OwnerID)
	}
}

func (b *Bot) CreateDiscordRole(guildID, name, color string) (*discordgo.Role, error) {
	colorInt64, err := strconv.ParseInt(strings.TrimPrefix(color, "#"), 16, 32)
	if err != nil {
		return nil, err
	}
	colorInt := int(colorInt64)

	return b.session.GuildRoleCreate(guildID, &discordgo.RoleParams{
		Name:  name,
		Color: &colorInt,
	})
}

func (b *Bot) UpdateDiscordRole(guildID, roleID, name, color string) error {
	colorInt64, err := strconv.ParseInt(strings.TrimPrefix(color, "#"), 16, 32)
	if err != nil {
		return err
	}
	colorInt := int(colorInt64)

	_, err = b.session.GuildRoleEdit(guildID, roleID, &discordgo.RoleParams{
		Name:  name,
		Color: &colorInt,
	})

	return err
}

func (b *Bot) DeleteDiscordRole(guildID, roleID string) error {
	return b.session.GuildRoleDelete(guildID, roleID)
}

func (b *Bot) AddRoleToUser(guildID, userID, roleID string) error {
	return b.session.GuildMemberRoleAdd(guildID, userID, roleID)
}

func (b *Bot) RemoveRoleFromUser(guildID, userID, roleID string) error {
	return b.session.GuildMemberRoleRemove(guildID, userID, roleID)
}

func (b *Bot) CreateAdvancedDiscordRole(guildID, name string, color models.RoleColor, icon models.RoleIcon) (*discordgo.Role, error) {
	log.Printf("создание роли '%s' - тип: '%s', основной: '%s', дополнительный: '%s'", name, color.Type, color.Primary, color.Secondary)

	if color.Type == "gradient" && color.Secondary != "" {
		log.Printf("использование создания градиентной роли")
		return b.createGradientRole(guildID, name, color, icon)
	}

	if color.Type == "holographic" {
		log.Printf("использование создания голографической роли")
		return b.createHolographicRole(guildID, name, color, icon)
	}

	log.Printf("использование создания роли с обычным цветом")
	finalColor := b.getDiscordColor(color.Primary)

	permissions := int64(0)
	mentionable := false

	roleParams := &discordgo.RoleParams{
		Name:        name,
		Color:       &finalColor,
		Permissions: &permissions,
		Mentionable: &mentionable,
	}

	if icon.Type == "emoji" && icon.Value != "" {
		roleParams.UnicodeEmoji = &icon.Value
	} else if icon.Type == "custom" {
		var iconData string
		var err error

		if icon.URL != "" {
			iconData, err = b.downloadAndProcessIcon(icon.URL)
		} else if icon.Value != "" {
			iconData = icon.Value
		}

		if err == nil && iconData != "" {
			roleParams.Icon = &iconData
		}
	}

	role, err := b.session.GuildRoleCreate(guildID, roleParams)
	if err != nil {
		return nil, err
	}

	err = b.positionRoleBelowTarget(guildID, role.ID, "1387642329065848924")
	if err != nil {
		fmt.Printf("предупреждение: не удалось позиционировать роль ниже цели: %v\n", err)
	}

	return role, nil
}

func (b *Bot) createGradientRole(guildID, name string, color models.RoleColor, icon models.RoleIcon) (*discordgo.Role, error) {
	log.Printf("создание градиентной роли с цветами: %s -> %s", color.Primary, color.Secondary)

	primaryColor := b.getDiscordColor(color.Primary)
	secondaryColor := b.getDiscordColor(color.Secondary)

	payload := map[string]interface{}{
		"name":        name,
		"permissions": "0",
		"mentionable": false,
		"colors": map[string]interface{}{
			"primary_color":   primaryColor,
			"secondary_color": secondaryColor,
		},
	}

	if icon.Type == "emoji" && icon.Value != "" {
		payload["unicode_emoji"] = icon.Value
	} else if icon.Type == "custom" {
		var iconData string
		var err error

		if icon.URL != "" {
			iconData, err = b.downloadAndProcessIcon(icon.URL)
		} else if icon.Value != "" {
			iconData = icon.Value
		}

		if err == nil && iconData != "" {
			payload["icon"] = iconData
		}
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("не удалось сериализовать данные: %v", err)
	}

	log.Printf("отправка данных в discord: %s", string(jsonData))

	url := fmt.Sprintf("https://discord.com/api/v10/guilds/%s/roles", guildID)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("не удалось создать запрос: %v", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bot "+b.config.DiscordToken)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("не удалось выполнить запрос: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusCreated {
		body, _ := io.ReadAll(resp.Body)
		log.Printf("ошибка Discord API: %d - %s", resp.StatusCode, string(body))
		return nil, fmt.Errorf("ошибка discord api: %d", resp.StatusCode)
	}

	var role *discordgo.Role
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("не удалось прочитать ответ: %v", err)
	}
	log.Printf("ответ discord api: %s", string(body))

	log.Printf("ответ discord api: %s", string(body))

	if err := json.Unmarshal(body, &role); err != nil {
		return nil, fmt.Errorf("не удалось декодировать ответ: %v", err)
	}

	log.Printf("градиентная роль успешно создана: %s", role.ID)

	err = b.positionRoleBelowTarget(guildID, role.ID, "1387642329065848924")
	if err != nil {
		fmt.Printf("предупреждение: не удалось позиционировать роль ниже цели: %v\n", err)
	}

	return role, nil
}

func (b *Bot) createHolographicRole(guildID, name string, color models.RoleColor, icon models.RoleIcon) (*discordgo.Role, error) {
	log.Printf("создание голографической роли")

	payload := map[string]interface{}{
		"name":        name,
		"permissions": "0",
		"mentionable": false,
		"colors": map[string]interface{}{
			"primary_color":   11127295,
			"secondary_color": 16759788,
			"tertiary_color":  16761760,
		},
	}

	if icon.Type == "emoji" && icon.Value != "" {
		payload["unicode_emoji"] = icon.Value
	} else if icon.Type == "custom" {
		var iconData string
		var err error

		if icon.URL != "" {
			iconData, err = b.downloadAndProcessIcon(icon.URL)
		} else if icon.Value != "" {
			iconData = icon.Value
		}

		if err == nil && iconData != "" {
			payload["icon"] = iconData
		}
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("не удалось сериализовать данные: %v", err)
	}

	url := fmt.Sprintf("https://discord.com/api/v10/guilds/%s/roles", guildID)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("не удалось создать запрос: %v", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bot "+b.config.DiscordToken)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("не удалось выполнить запрос: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusCreated {
		body, _ := io.ReadAll(resp.Body)
		log.Printf("ошибка discord api: %d - %s", resp.StatusCode, string(body))
		return nil, fmt.Errorf("ошибка discord api: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("не удалось прочитать тело ответа: %v", err)
	}
	log.Printf("ответ discord api: %s", string(body))

	var role *discordgo.Role
	if err := json.Unmarshal(body, &role); err != nil {
		return nil, fmt.Errorf("не удалось декодировать ответ: %v", err)
	}

	log.Printf("голографическая роль успешно создана: %s", role.ID)

	err = b.positionRoleBelowTarget(guildID, role.ID, "1387642329065848924")
	if err != nil {
		fmt.Printf("предупреждение: не удалось позиционировать роль ниже цели: %v\n", err)
	}

	return role, nil
}

func (b *Bot) UpdateAdvancedDiscordRole(guildID, roleID, name string, color models.RoleColor, icon models.RoleIcon) (*discordgo.Role, error) {
	if color.Type == "gradient" && color.Secondary != "" {
		return b.updateGradientRole(guildID, roleID, name, color, icon)
	}

	if color.Type == "holographic" {
		return b.updateHolographicRole(guildID, roleID, name, color, icon)
	}

	finalColor := b.getDiscordColor(color.Primary)

	permissions := int64(0)
	mentionable := false

	roleParams := &discordgo.RoleParams{
		Name:        name,
		Color:       &finalColor,
		Permissions: &permissions,
		Mentionable: &mentionable,
	}

	if icon.Type == "emoji" && icon.Value != "" {
		roleParams.UnicodeEmoji = &icon.Value
		emptyIcon := ""
		roleParams.Icon = &emptyIcon
	} else if icon.Type == "custom" {
		var iconData string
		var err error

		if icon.URL != "" {
			iconData, err = b.downloadAndProcessIcon(icon.URL)
		} else if icon.Value != "" {
			iconData = icon.Value
		}

		if err == nil && iconData != "" {
			roleParams.Icon = &iconData
			emptyEmoji := ""
			roleParams.UnicodeEmoji = &emptyEmoji
		}
	} else if icon.Type == "none" {
		emptyIcon := ""
		emptyEmoji := ""
		roleParams.Icon = &emptyIcon
		roleParams.UnicodeEmoji = &emptyEmoji
	}

	role, err := b.session.GuildRoleEdit(guildID, roleID, roleParams)
	return role, err
}

func (b *Bot) updateGradientRole(guildID, roleID, name string, color models.RoleColor, icon models.RoleIcon) (*discordgo.Role, error) {
	log.Printf("обновление градиентной роли %s с цветами: %s -> %s", roleID, color.Primary, color.Secondary)

	primaryColor := b.getDiscordColor(color.Primary)
	secondaryColor := b.getDiscordColor(color.Secondary)

	payload := map[string]interface{}{
		"name":        name,
		"permissions": "0",
		"mentionable": false,
		"colors": map[string]interface{}{
			"primary_color":   primaryColor,
			"secondary_color": secondaryColor,
		},
	}

	if icon.Type == "emoji" && icon.Value != "" {
		payload["unicode_emoji"] = icon.Value
		payload["icon"] = nil
	} else if icon.Type == "custom" {
		var iconData string
		var err error

		if icon.URL != "" {
			iconData, err = b.downloadAndProcessIcon(icon.URL)
		} else if icon.Value != "" {
			iconData = icon.Value
		}

		if err == nil && iconData != "" {
			payload["icon"] = iconData
			payload["unicode_emoji"] = nil
		}
	} else if icon.Type == "none" {
		payload["icon"] = nil
		payload["unicode_emoji"] = nil
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("не удалось сериализовать данные: %v", err)
	}

	url := fmt.Sprintf("https://discord.com/api/v10/guilds/%s/roles/%s", guildID, roleID)
	req, err := http.NewRequest("PATCH", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("не удалось создать запрос: %v", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bot "+b.config.DiscordToken)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("не удалось выполнить запрос: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		log.Printf("ошибка Discord API: %d - %s", resp.StatusCode, string(body))
		return nil, fmt.Errorf("ошибка discord api: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("не удалось прочитать ответ: %v", err)
	}

	var role discordgo.Role
	err = json.Unmarshal(body, &role)
	if err != nil {
		return nil, fmt.Errorf("не удалось десериализовать ответ роли: %v", err)
	}

	log.Printf("градиентная роль успешно обновлена: %s", roleID)
	return &role, nil
}

func (b *Bot) updateHolographicRole(guildID, roleID, name string, color models.RoleColor, icon models.RoleIcon) (*discordgo.Role, error) {
	log.Printf("обновление голографической роли %s", roleID)

	payload := map[string]interface{}{
		"name":        name,
		"permissions": "0",
		"mentionable": false,
		"colors": map[string]interface{}{
			"primary_color":   11127295,
			"secondary_color": 16759788,
			"tertiary_color":  16761760,
		},
	}

	if icon.Type == "emoji" && icon.Value != "" {
		payload["unicode_emoji"] = icon.Value
		payload["icon"] = nil
	} else if icon.Type == "custom" {
		var iconData string
		var err error

		if icon.URL != "" {
			iconData, err = b.downloadAndProcessIcon(icon.URL)
		} else if icon.Value != "" {
			iconData = icon.Value
		}

		if err == nil && iconData != "" {
			payload["icon"] = iconData
			payload["unicode_emoji"] = nil
		}
	} else if icon.Type == "none" {
		payload["icon"] = nil
		payload["unicode_emoji"] = nil
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("не удалось сериализовать данные: %v", err)
	}

	url := fmt.Sprintf("https://discord.com/api/v10/guilds/%s/roles/%s", guildID, roleID)
	req, err := http.NewRequest("PATCH", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("не удалось создать запрос: %v", err)
	}

	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bot "+b.config.DiscordToken)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("не удалось выполнить запрос: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		log.Printf("ошибка discord api: %d - %s", resp.StatusCode, string(body))
		return nil, fmt.Errorf("ошибка discord api: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("не удалось прочитать ответ: %v", err)
	}

	var role discordgo.Role
	err = json.Unmarshal(body, &role)
	if err != nil {
		return nil, fmt.Errorf("не удалось десериализовать ответ роли: %v", err)
	}

	log.Printf("голографическая роль успешно обновлена: %s", roleID)
	return &role, nil
}

func (b *Bot) getDiscordColor(hexColor string) int {
	colorInt64, err := strconv.ParseInt(strings.TrimPrefix(hexColor, "#"), 16, 32)
	if err != nil {
		return 0x3498db
	}
	return int(colorInt64)
}

/* а што ета? */
func (b *Bot) getDiscordColorFromRoleColor(color models.RoleColor) int {
	log.Printf("обработка цвета - тип: '%s', основной: '%s', дополнительный: '%s'", color.Type, color.Primary, color.Secondary)

	blend := func(primary, secondary string) int {
		primaryInt := b.getDiscordColor(primary)
		if primaryInt == 0x3498db && primary != "#3498db" {
			return b.getDiscordColor(secondary)
		}
		secondaryInt := b.getDiscordColor(secondary)
		if secondaryInt == 0x3498db && secondary != "#3498db" {
			return primaryInt
		}
		primaryR := (primaryInt >> 16) & 0xFF
		primaryG := (primaryInt >> 8) & 0xFF
		primaryB := primaryInt & 0xFF
		secondaryR := (secondaryInt >> 16) & 0xFF
		secondaryG := (secondaryInt >> 8) & 0xFF
		secondaryB := secondaryInt & 0xFF
		return ((primaryR + secondaryR) / 2 << 16) | ((primaryG + secondaryG) / 2 << 8) | (primaryB+secondaryB)/2
	}

	if color.Type == "gradient" && color.Secondary != "" {
		blended := blend(color.Primary, color.Secondary)
		log.Printf("смешанный градиентный цвет: %s + %s = #%06X", color.Primary, color.Secondary, blended)
		return blended
	}
	primary := b.getDiscordColor(color.Primary)
	log.Printf("использование только основного цвета: %s = #%06X", color.Primary, primary)
	return primary
}

func (b *Bot) downloadAndProcessIcon(iconURL string) (string, error) {
	if !strings.HasPrefix(iconURL, "data:") {
		return "", fmt.Errorf("разрешены только base64 data url по соображениям безопасности")
	}

	log.Printf("иконка в формате base64, проверка формата")

	parts := strings.Split(iconURL, ",")
	if len(parts) != 2 {
		return "", fmt.Errorf("неверный формат data url")
	}

	header := parts[0]
	if !strings.Contains(header, "image/") {
		return "", fmt.Errorf("не является data url изображения")
	}

	data, err := base64.StdEncoding.DecodeString(parts[1])
	if err != nil {
		return "", fmt.Errorf("неверные данные base64: %v", err)
	}

	if len(data) > 256*1024 {
		return "", fmt.Errorf("изображение слишком большое (макс. 256КБ)")
	}

	log.Printf("base64 изображение проверено - размер: %d байт", len(data))
	return iconURL, nil
}

func (b *Bot) positionRoleBelowTarget(guildID, roleID, targetRoleID string) error {
	time.Sleep(100 * time.Millisecond)

	log.Printf("попытка позиционировать роль %s ниже целевой роли %s", roleID, targetRoleID)

	roles, err := b.session.GuildRoles(guildID)
	if err != nil {
		return err
	}

	log.Printf("найдено %d ролей в сервере", len(roles))

	sort.Slice(roles, func(i, j int) bool {
		return roles[i].Position > roles[j].Position
	})

	for _, role := range roles {
		if role.ID == targetRoleID || role.ID == roleID {
			log.Printf("роль %s (%s) на позиции %d", role.Name, role.ID, role.Position)
		}
	}

	var newOrder []*discordgo.Role
	var ourRole *discordgo.Role
	targetFound := false

	for _, role := range roles {
		if role.ID == roleID {
			ourRole = role
			break
		}
	}

	if ourRole == nil {
		return fmt.Errorf("роль %s не найдена на сервере", roleID)
	}

	for _, role := range roles {
		if role.ID == roleID {
			continue
		}

		newOrder = append(newOrder, role)

		if role.ID == targetRoleID {
			log.Printf("найдена целевая роль, вставляем нашу роль ниже неё")
			newOrder = append(newOrder, ourRole)
			targetFound = true
		}
	}

	if !targetFound {
		return fmt.Errorf("целевая роль %s не найдена на сервере", targetRoleID)
	}

	for i, role := range newOrder {
		role.Position = len(newOrder) - i - 1
	}

	log.Printf("перестановка %d ролей", len(newOrder))

	_, err = b.session.GuildRoleReorder(guildID, newOrder)
	if err != nil {
		log.Printf("ошибка перестановки ролей: %v", err)
	} else {
		log.Printf("позиционирование роли завершено успешно")
	}

	return err
}
