package commands

import (
	"fmt"
	"log"
	"strings"
	"time"

	"ranked-roles/internal/models"

	"github.com/bwmarrin/discordgo"
)

func init() {
	roleInfoCommand := &discordgo.ApplicationCommand{
		Name:        "role-info",
		Description: "Показать информацию о пользовательской роли",
		Options: []*discordgo.ApplicationCommandOption{
			{
				Type:        discordgo.ApplicationCommandOptionRole,
				Name:        "role",
				Description: "роль",
				Required:    true,
			},
		},
	}

	AllCommands = append(AllCommands, RegisteredCommand{Command: roleInfoCommand, Handler: roleInfoHandler})
}

func roleInfoHandler(s *discordgo.Session, ic *discordgo.InteractionCreate) {
	if ic.Type != discordgo.InteractionApplicationCommand {
		return
	}

	data := ic.ApplicationCommandData()
	var targetRole *discordgo.Role
	for _, opt := range data.Options {
		if opt.Name == "role" && opt.RoleValue(s, ic.GuildID) != nil {
			targetRole = opt.RoleValue(s, ic.GuildID)
			break
		}
	}
	if targetRole == nil {
		respondEphemeralPlain(s, ic, "Роль не найдена.")
		return
	}

	if LookupCustomRoleByDiscordRoleID == nil {
		respondEphemeralPlain(s, ic, "Поиск недоступен.")
		return
	}
	role, err := LookupCustomRoleByDiscordRoleID(ic.GuildID, targetRole.ID)
	if err != nil {
		log.Printf("информация о роли: ошибка базы данных: %v", err)
		respondEphemeralPlain(s, ic, "Ошибка базы данных.")
		return
	}
	if role == nil {
		respondEphemeralPlain(s, ic, "Я не управляю этой ролью!")
		return
	}

	embed := buildRoleInfoEmbed(role, targetRole)

	err = s.InteractionRespond(ic.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds:          []*discordgo.MessageEmbed{embed},
			Flags:           discordgo.MessageFlagsEphemeral,
			AllowedMentions: &discordgo.MessageAllowedMentions{},
		},
	})
	if err != nil {
		log.Printf("информация о роли: не удалось ответить: %v", err)
	}
}

func respondEphemeralPlain(s *discordgo.Session, ic *discordgo.InteractionCreate, content string) {
	_ = s.InteractionRespond(ic.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{Content: content, Flags: discordgo.MessageFlagsEphemeral},
	})
}

func buildRoleInfoEmbed(cr *models.CustomRole, dr *discordgo.Role) *discordgo.MessageEmbed {
	now := time.Now()
	remaining := "Постоянная"
	if !cr.ExpiresAt.IsZero() && cr.ExpiresAt.After(now) && cr.ExpiresAt.Before(now.AddDate(50, 0, 0)) {
		dur := cr.ExpiresAt.Sub(now).Round(time.Minute)
		remaining = fmtDuration(dur)
	}
	if cr.ExpiresAt.Before(now) {
		remaining = "Истекла"
	}

	colorDesc := formatColor(cr.Color)
	slotUsage := fmt.Sprintf("%d / %d", cr.Slots.Used, cr.Slots.Total)

	iconLine := "Нет"
	switch cr.Icon.Type {
	case "emoji":
		iconLine = cr.Icon.Value
	case "custom":
		iconLine = "Пользовательское изображение"
	}

	roleType := cr.Color.Type
	if roleType == "" {
		roleType = "solid"
	}
	roleType = titleCase(roleType)
	fields := []*discordgo.MessageEmbedField{
		{Name: "Владелец", Value: fmt.Sprintf("<@%s>", cr.OwnerID), Inline: true},
		{Name: "Роль", Value: fmt.Sprintf("<@&%s>", cr.DiscordRoleID), Inline: true},
		{Name: "Истекает", Value: remaining, Inline: true},
		{Name: "Цвет", Value: colorDesc, Inline: true},
		{Name: "Тип", Value: roleType, Inline: true},
		{Name: "Слоты", Value: slotUsage, Inline: true},
		{Name: "Иконка", Value: iconLine, Inline: true},
	}

	return &discordgo.MessageEmbed{
		Title:       dr.Name,
		Color:       dr.Color,
		Fields:      fields,
		Timestamp:   time.Now().Format(time.RFC3339),
		Description: "Информация об управляемой пользовательской роли",
	}
}

func formatColor(rc models.RoleColor) string {
	switch rc.Type {
	case "gradient":
		return fmt.Sprintf("%s → %s", rc.Primary, rc.Secondary)
	case "holographic":
		return "Голографический"
	default:
		return rc.Primary
	}
}

func titleCase(s string) string {
	if s == "" {
		return s
	}
	return strings.ToUpper(s[:1]) + s[1:]
}

func fmtDuration(d time.Duration) string {
	minutes := int(d.Minutes())
	days := minutes / (60 * 24)
	hours := (minutes / 60) % 24
	if days > 0 {
		return fmt.Sprintf("%dd %dh", days, hours)
	}
	if hours > 0 {
		return fmt.Sprintf("%dh", hours)
	}
	return fmt.Sprintf("%dm", minutes%60)
}
