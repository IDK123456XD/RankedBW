package commands

import (
	"ranked-roles/internal/config"
	"ranked-roles/internal/models"

	"github.com/bwmarrin/discordgo"
)

type CommandHandler func(s *discordgo.Session, ic *discordgo.InteractionCreate)

type RegisteredCommand struct {
	Command *discordgo.ApplicationCommand
	Handler CommandHandler
}

var (
	Cfg                             *config.Config
	ProcessMissedPurchases          func()
	FullRescanPurchases             func()
	LookupCustomRoleByDiscordRoleID func(serverID, discordRoleID string) (*models.CustomRole, error)
)

var AllCommands []RegisteredCommand

func Init(cfg *config.Config, processMissed func(), fullRescan func(), lookup func(serverID, discordRoleID string) (*models.CustomRole, error)) {
	Cfg = cfg
	ProcessMissedPurchases = processMissed
	FullRescanPurchases = fullRescan
	LookupCustomRoleByDiscordRoleID = lookup
}

func GetCommands() []*discordgo.ApplicationCommand {
	cmds := make([]*discordgo.ApplicationCommand, 0, len(AllCommands))
	for _, c := range AllCommands {
		cmds = append(cmds, c.Command)
	}
	return cmds
}

func GetHandler(name string) CommandHandler {
	for _, c := range AllCommands {
		if c.Command.Name == name {
			return c.Handler
		}
	}
	return nil
}
