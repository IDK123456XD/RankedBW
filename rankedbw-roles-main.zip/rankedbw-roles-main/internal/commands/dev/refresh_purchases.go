package dev

import (
	"fmt"
	cmds "ranked-roles/internal/commands"
	"time"

	"github.com/bwmarrin/discordgo"
)

var refreshPurchasesCommand = &discordgo.ApplicationCommand{
	Name:        "refresh-purchases",
	Description: "Разработчик: обновить покупки",
}

func init() {
	cmds.AllCommands = append(cmds.AllCommands, cmds.RegisteredCommand{Command: refreshPurchasesCommand, Handler: refreshPurchasesHandler})
}

func refreshPurchasesHandler(s *discordgo.Session, ic *discordgo.InteractionCreate) {
	if ic.Member == nil || ic.Member.User == nil || ic.Member.User.ID != cmds.Cfg.DeveloperID {
		_ = s.InteractionRespond(ic.Interaction, &discordgo.InteractionResponse{Type: discordgo.InteractionResponseChannelMessageWithSource, Data: &discordgo.InteractionResponseData{Content: "У вас нет прав на использование этой команды.", Flags: 1 << 6}})
		return
	}
	start := time.Now()
	_ = s.InteractionRespond(ic.Interaction, &discordgo.InteractionResponse{Type: discordgo.InteractionResponseDeferredChannelMessageWithSource})
	go func(inter *discordgo.Interaction) {
		if cmds.FullRescanPurchases != nil {
			cmds.FullRescanPurchases()
		} else if cmds.ProcessMissedPurchases != nil {
			cmds.ProcessMissedPurchases()
		}
		dur := time.Since(start)
		_, _ = s.FollowupMessageCreate(inter, true, &discordgo.WebhookParams{Content: fmt.Sprintf("Полное повторное сканирование покупки завершено в: %s", dur.Truncate(time.Millisecond))})
	}(ic.Interaction)
}
