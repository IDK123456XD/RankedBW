package config

import (
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	DiscordToken string
	DevServerID  string
	DeveloperID  string
	AdminIDs     []string

	ForceDeleteCommandIDs  []string
	AutoExtendMonthlyRoles bool

	RegisterSlashCommands   bool
	UnregisterSlashCommands bool

	MongoURI string
	RedisURI string

	Port string

	ClientID     string
	ClientSecret string
	RedirectURL  string

	DefaultSlots    int
	RoleExpiryHours int

	PurchaseChannelID string
	TebexBotID        string
}

// неважно, не общественный
func Load() (*Config, error) {
	cfg := &Config{
		DiscordToken: getEnv("DISCORD_TOKEN", "NONE"),
		DevServerID:  getEnv("DEV_SERVER_ID", "NONE"),
		DeveloperID:  getEnv("DEVELOPER_ID", "NONE"),
		// сделать: перейти на внутренний
		MongoURI: getEnv("MONGO_URI", "NONE"),
		RedisURI: getEnv("REDIS_URI", "NONE"),

		Port: getEnv("PORT", "3006"),

		ClientID:     getEnv("DISCORD_CLIENT_ID", "NOBE"),
		ClientSecret: getEnv("DISCORD_CLIENT_SECRET", "NONE"),
		RedirectURL:  getEnv("DISCORD_REDIRECT_URL", "https://roles.rankedbw.net/callback"),

		DefaultSlots:    getEnvInt("DEFAULT_SLOTS", 4),
		RoleExpiryHours: getEnvInt("ROLE_EXPIRY_HOURS", 1),

		PurchaseChannelID:       getEnv("PURCHASE_CHANNEL_ID", "NONE"),
		TebexBotID:              getEnv("TEBEX_BOT_ID", "NONE"),
		RegisterSlashCommands:   getEnv("REGISTER_SLASH_COMMANDS", "false") == "true",
		UnregisterSlashCommands: getEnv("UNREGISTER_SLASH_COMMANDS", "false") == "true",
		AutoExtendMonthlyRoles:  getEnv("AUTO_EXTEND_MONTHLY_ROLES", "false") == "true",
	}

	adminIDsStr := getEnv("ADMIN_IDS", cfg.DeveloperID)
	if adminIDsStr != "" {
		cfg.AdminIDs = strings.Split(strings.ReplaceAll(adminIDsStr, " ", ""), ",")
	}

	forceDelete := getEnv("FORCE_DELETE_COMMAND_IDS", "")
	if forceDelete != "" {
		clean := strings.ReplaceAll(forceDelete, " ", "")
		parts := strings.Split(clean, ",")
		var filtered []string
		for _, p := range parts {
			if p != "" && p != "0" && len(p) > 10 {
				filtered = append(filtered, p)
			}
		}
		cfg.ForceDeleteCommandIDs = filtered
	}

	return cfg, nil
}

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func getEnvInt(key string, defaultValue int) int {
	if value := os.Getenv(key); value != "" {
		if intValue, err := strconv.Atoi(value); err == nil {
			return intValue
		}
	}
	return defaultValue
}

func (c *Config) GetRoleExpiryDuration() time.Duration {
	return time.Duration(c.RoleExpiryHours) * time.Hour
}

func (c *Config) IsAdmin(userID string) bool {
	for _, adminID := range c.AdminIDs {
		if adminID == userID {
			return true
		}
	}
	return false
}
