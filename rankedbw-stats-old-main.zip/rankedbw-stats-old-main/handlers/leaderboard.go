package handlers

import (
	"fmt"
	"log"
	"net/http"
	"strconv"

	"rankedbw-statistics/config"
	"rankedbw-statistics/models"

	"github.com/gin-gonic/gin"
)

func GetLeaderboard(c *gin.Context) {
	statType := c.DefaultQuery("type", config.DefaultStatType)
	pageStr := c.DefaultQuery("page", "1")

	c.Header("Cache-Control", "public, max-age=60")
	c.Header("X-Content-Type-Options", "nosniff")
	c.Header("X-Frame-Options", "DENY")
	c.Header("X-XSS-Protection", "1; mode=block")

	if !config.IsValidStatType(statType) {
		log.Printf("bad stat type. using default.")
		statType = config.DefaultStatType
	}
	page, err := strconv.Atoi(pageStr)
	if err != nil || page < 1 {
		if err != nil {
			log.Printf("bad page num. using 1.")
		}
		page = 1
	}

	if page > config.MaxPages {
		log.Printf("page too high. using max.")
		c.Redirect(http.StatusFound, fmt.Sprintf("?type=%s&page=%d", statType, config.MaxPages))
		return
	}

	limit := config.DefaultPageSize
	offset := (page - 1) * limit

	leaderboard, totalCount, err := getLeaderboardData(statType, limit, offset)
	if err != nil {
		log.Printf("err getting lb data.")
		c.HTML(http.StatusInternalServerError, "error.html", gin.H{
			"Title": "Error",
			"Error": "could not load lb data",
		})
		return
	}

	if totalCount > config.MaxTotalItems {
		totalCount = config.MaxTotalItems
	}

	totalPages := (totalCount + limit - 1) / limit
	if totalPages == 0 {
		totalPages = 1
	}

	if totalPages > config.MaxPages {
		totalPages = config.MaxPages
	}

	if page > totalPages {
		c.Redirect(http.StatusFound, fmt.Sprintf("?type=%s&page=%d", statType, totalPages))
		return
	}
	c.HTML(http.StatusOK, "leaderboard.html", gin.H{
		"Title":       "Leaderboards",
		"StatType":    statType,
		"Leaderboard": leaderboard,
		"CurrentPage": page,
		"TotalPages":  totalPages,
		"TotalCount":  totalCount,
		"HasPrev":     page > 1,
		"HasNext":     page < totalPages,
		"PrevPage":    page - 1,
		"NextPage":    page + 1,
	})
}

func GetLeaderboardAPI(c *gin.Context) {
	statType := c.DefaultQuery("type", config.DefaultStatType)
	pageStr := c.DefaultQuery("page", "1")

	if !config.IsValidStatType(statType) {
		log.Printf("bad stat type. using default.")
		statType = config.DefaultStatType
	}
	page, err := strconv.Atoi(pageStr)
	if err != nil || page < 1 {
		if err != nil {
			log.Printf("bad page num. using 1.")
		}
		page = 1
	}

	if page > config.MaxPages {
		log.Printf("api page too high.")
		c.JSON(http.StatusBadRequest, gin.H{
			"error":    fmt.Sprintf("page %d too high. max is %d.", page, config.MaxPages),
			"code":     "INVALID_PAGE",
			"maxPages": config.MaxPages,
		})
		return
	}

	limit := config.DefaultPageSize
	offset := (page - 1) * limit

	leaderboard, totalCount, err := getLeaderboardData(statType, limit, offset)
	if err != nil {
		log.Printf("err getting lb data api.")
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "could not load lb data",
			"code":  "INTERNAL_ERROR",
		})
		return
	}

	if totalCount > config.MaxTotalItems {
		totalCount = config.MaxTotalItems
	}

	totalPages := (totalCount + limit - 1) / limit
	if totalPages == 0 {
		totalPages = 1
	}
	if totalPages > config.MaxPages {
		totalPages = config.MaxPages
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data": gin.H{
			"leaderboard": leaderboard,
			"pagination": gin.H{
				"currentPage": page,
				"totalPages":  totalPages,
				"totalCount":  totalCount,
				"hasNext":     page < totalPages,
				"hasPrev":     page > 1,
				"pageSize":    limit,
			},
			"metadata": gin.H{
				"statType": statType,
				"statName": config.GetStatDisplayName(statType),
			},
		},
	})
}

func GetLeaderboardREST(c *gin.Context) {
	statType := c.Param("statType")
	pageStr := c.Param("page")

	if !config.IsValidStatType(statType) {
		statType = config.DefaultStatType
	}
	page, err := strconv.Atoi(pageStr)
	if err != nil || page < 1 {
		page = 1
	}
	if page > config.MaxPages {
		c.Redirect(http.StatusFound, fmt.Sprintf("/leaderboard/%s/%d", statType, config.MaxPages))
		return
	}
	limit := config.DefaultPageSize
	offset := (page - 1) * limit

	leaderboard, totalCount, err := getLeaderboardData(statType, limit, offset)
	if err != nil {
		c.HTML(http.StatusInternalServerError, "error.html", gin.H{
			"Title": "Error",
			"Error": "could not load lb data",
		})
		return
	}
	if totalCount > config.MaxTotalItems {
		totalCount = config.MaxTotalItems
	}

	totalPages := (totalCount + limit - 1) / limit
	hasPrev := page > 1
	hasNext := page < totalPages

	c.HTML(http.StatusOK, "leaderboard.html", gin.H{
		"Title":       "Leaderboards",
		"StatType":    statType,
		"Leaderboard": leaderboard,
		"CurrentPage": page,
		"TotalPages":  totalPages,
		"TotalCount":  totalCount,
		"HasPrev":     hasPrev,
		"HasNext":     hasNext,
		"PrevPage":    page - 1,
		"NextPage":    page + 1,
	})
}

func getLeaderboardData(statType string, limit, offset int) ([]models.LeaderboardEntry, int, error) {
	var orderBy string
	var columnName string

	switch statType {
	case "wins":
		orderBy = "ps.wins DESC"
		columnName = "ps.wins"
	case "elo":
		orderBy = "ps.elo DESC"
		columnName = "ps.elo"
	case "mvps":
		orderBy = "ps.mvps DESC"
		columnName = "ps.mvps"
	case "gamesPlayed":
		orderBy = "ps.\"gamesPlayed\" DESC"
		columnName = "ps.\"gamesPlayed\""
	case "losses":
		orderBy = "ps.losses DESC"
		columnName = "ps.losses"
	case "streak":
		orderBy = "ps.streak DESC"
		columnName = "ps.streak"
	case "peakElo":
		orderBy = "ps.\"peakElo\" DESC"
		columnName = "ps.\"peakElo\""
	default:
		orderBy = "ps.elo DESC"
		columnName = "ps.elo"
	}
	countQuery := `
		SELECT COUNT(*)
		FROM "PlayerStatistics" ps
		JOIN "Player" p ON ps."playerId" = p.id
	`
	var totalCount int
	err := config.DB.QueryRow(countQuery).Scan(&totalCount)
	if err != nil {
		return nil, 0, fmt.Errorf("err getting lb count")
	}

	if totalCount > config.MaxTotalItems {
		totalCount = config.MaxTotalItems
	}
	maxLimit := config.MaxTotalItems
	if offset+limit > maxLimit {
		if offset >= maxLimit {
			return []models.LeaderboardEntry{}, totalCount, nil
		}
		limit = maxLimit - offset
	}

	query := fmt.Sprintf(`
		SELECT 
			(ROW_NUMBER() OVER (ORDER BY %s)) + $3 as rank,
			p."minecraftName",
			p."userId",
			%s as value
		FROM "PlayerStatistics" ps
		JOIN "Player" p ON ps."playerId" = p.id
		ORDER BY %s
		LIMIT $1 OFFSET $2
	`, orderBy, columnName, orderBy)

	rows, err := config.DB.Query(query, limit, offset, offset)
	if err != nil {
		return nil, 0, fmt.Errorf("err getting lb rows")
	}
	defer rows.Close()

	var leaderboard []models.LeaderboardEntry
	for rows.Next() {
		var entry models.LeaderboardEntry
		err := rows.Scan(&entry.Rank, &entry.MinecraftName, &entry.UserID, &entry.Value)
		if err != nil {
			return nil, 0, fmt.Errorf("err scanning lb row")
		}
		leaderboard = append(leaderboard, entry)
	}

	return leaderboard, totalCount, nil
}
