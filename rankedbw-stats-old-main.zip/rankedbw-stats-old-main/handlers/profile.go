package handlers

import (
	"fmt"
	"net/http"
	"rankedbw-statistics/config"
	"rankedbw-statistics/models"

	"github.com/gin-gonic/gin"
)

type PlayerProfile struct {
	Player     models.Player           `json:"player"`
	Statistics models.PlayerStatistics `json:"statistics"`
	AllStats   map[string]int          `json:"allStats"`
	Rankings   map[string]int          `json:"rankings"`
	WinRate    int
	WLR        float64
	FKDR       float64
}

func renderErrorPage(c *gin.Context, title, message string) {
	c.HTML(http.StatusInternalServerError, "error.html", gin.H{
		"Title": title,
		"Error": message,
	})
}

func GetPlayerProfile(c *gin.Context) {
	playerName := c.Param("name")
	if playerName == "" {
		renderErrorPage(c, "error", "player name needed")
		return
	}

	c.Header("Cache-Control", "public, max-age=300")
	c.Header("X-Content-Type-Options", "nosniff")

	profile, err := getPlayerProfile(playerName)
	if err != nil {
		renderErrorPage(c, "not found", "player not found or err loading profile")
		return
	}

	c.HTML(http.StatusOK, "profile.html", gin.H{
		"Title":   "player profile - " + profile.Player.MinecraftName,
		"Profile": profile,
	})
}

func GetPlayerProfileAPI(c *gin.Context) {
	playerName := c.Param("name")
	if playerName == "" {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "player name needed",
			"code":  "MISSING_PLAYER_NAME",
		})
		return
	}

	profile, err := getPlayerProfile(playerName)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{
			"error": "player not found",
			"code":  "PLAYER_NOT_FOUND",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"data":    profile,
	})
}

func getPlayerProfile(playerName string) (*PlayerProfile, error) {
	playerQuery := `
		SELECT id, "userId", "minecraftName", nickname, "winStreak"
		FROM "Player"
		WHERE "minecraftName" = $1
	`
	var playerID, userID, minecraftName string
	var nickname *string
	var winStreak int
	err := config.DB.QueryRow(playerQuery, playerName).Scan(
		&playerID, &userID, &minecraftName, &nickname, &winStreak,
	)
	if err != nil {
		return nil, fmt.Errorf("err getting player row")
	}
	statsQuery := `
		SELECT elo, wins, mvps, "gamesPlayed", losses, "peakElo"
		FROM "PlayerStatistics"
		WHERE "playerId" = $1
		ORDER BY "seasonId" DESC
		LIMIT 1
	`
	var elo, wins, mvps, gamesPlayed, losses, peakElo int
	err = config.DB.QueryRow(statsQuery, playerID).Scan(
		&elo, &wins, &mvps, &gamesPlayed, &losses, &peakElo,
	)
	if err != nil {
		elo, wins, mvps, gamesPlayed, losses, peakElo = 0, 0, 0, 0, 0, 0
	}
	return &PlayerProfile{
		Player: models.Player{
			ID:            playerID,
			UserID:        userID,
			MinecraftName: minecraftName,
			Nickname:      nickname,
			WinStreak:     winStreak,
		},
		Statistics: models.PlayerStatistics{
			Elo:         elo,
			Wins:        wins,
			MVPs:        mvps,
			GamesPlayed: gamesPlayed,
			Losses:      losses,
			PeakElo:     peakElo,
		},
	}, nil
}

func getColumnName(statType string) string {
	switch statType {
	case "wins":
		return "ps1.wins"
	case "elo":
		return "ps1.elo"
	case "mvps":
		return "ps1.mvps"
	case "gamesPlayed":
		return "ps1.gamesPlayed"
	case "losses":
		return "ps1.losses"
	case "streak":
		return "ps1.streak"
	case "peakElo":
		return "ps1.peakElo"
	default:
		return "ps1.elo"
	}
}
