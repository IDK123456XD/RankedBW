// idk js

document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    const rows = document.querySelectorAll('.leaderboard-row');
    rows.forEach((row, index) => {
        row.style.opacity = '0';
        row.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            row.style.transition = 'all 0.5s ease';
            row.style.opacity = '1';
            row.style.transform = 'translateY(0)';
        }, index * 100);
    });

    const statSelector = document.getElementById('statType');
    if (statSelector) {
        statSelector.addEventListener('change', function() {
            showLoadingState();
        });
    }

    initializeTooltips();
    
    addKeyboardNavigation();
}

function showLoadingState() {
    const leaderboardCard = document.querySelector('.leaderboard-card');
    if (leaderboardCard) {
        leaderboardCard.classList.add('loading');
    }
}

function showLeaderboardLoading() {
    const leaderboardTable = document.querySelector('.leaderboard-table tbody');
    if (leaderboardTable) {
        leaderboardTable.style.opacity = '0.5';
        leaderboardTable.style.pointerEvents = 'none';
        
        const statSelector = document.querySelector('.stat-selector');
        if (statSelector && !statSelector.querySelector('.loading-spinner')) {
            const spinner = document.createElement('div');
            spinner.className = 'loading-spinner';
            statSelector.appendChild(spinner);
        }
    }
}

function showNotification(message, type = 'info', duration = 4000) {
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => {
        notification.remove();
    });

    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    let icon = 'fas fa-info-circle';
    switch(type) {
        case 'success':
            icon = 'fas fa-check-circle';
            break;
        case 'error':
            icon = 'fas fa-exclamation-circle';
            break;
        case 'warning':
            icon = 'fas fa-exclamation-triangle';
            break;
    }
    
    notification.innerHTML = `
        <div class="notification-content">
            <i class="${icon}"></i>
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentElement) {
            notification.classList.add('notification-fade-out');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    }, duration);
}

function copyDiscordId(discordId, playerName) {
    if (!discordId || discordId === '') {
        showNotification('No Discord ID available for this player', 'warning');
        return;
    }
    
    const clickedElement = event.target;
    if (clickedElement) {
        clickedElement.classList.add('copied');
        setTimeout(() => {
            clickedElement.classList.remove('copied');
        }, 600);
    }
    
    navigator.clipboard.writeText(discordId).then(() => {
        const message = playerName ? 
            `Copied Discord ID for ${playerName}: ${discordId}` : 
            `Copied Discord ID: ${discordId}`;
        showNotification(message, 'success');
    }).catch(err => {
        console.error('Failed to copy Discord ID:', err);
        showNotification('Failed to copy Discord ID', 'error');
    });
}

function viewProfile(playerName) {
    if (!playerName) {
        showNotification('Invalid player name', 'error');
        return;
    }
    
    const btn = event.target.closest('.view-profile-btn');
    if (btn) {
        const originalContent = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
        btn.disabled = true;
        
        setTimeout(() => {
            window.location.href = `/player/${encodeURIComponent(playerName)}`;
        }, 300);
    }
}

function changeStatType() {
    showLeaderboardLoading();
    const statType = document.getElementById('statType').value;
    showNotification(`Loading ${getStatDisplayName(statType)} leaderboard...`, 'info');
    window.location.href = `?type=${statType}&page=1`;
}

function smoothScrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

document.addEventListener('DOMContentLoaded', function() {
    const paginationBtns = document.querySelectorAll('.pagination-btn');
    paginationBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            showLeaderboardLoading();
            smoothScrollToTop();
            showNotification('Loading page...', 'info');
        });
    });
});

function initializeTooltips() {
    const playerNames = document.querySelectorAll('.player-name[title]');
    
    playerNames.forEach(nameElement => {
        let tooltip = null;
        
        nameElement.addEventListener('mouseenter', function(e) {
            removeTooltip();
            
            tooltip = document.createElement('div');
            tooltip.className = 'custom-tooltip';
            tooltip.textContent = this.getAttribute('title');
            
            tooltip.style.cssText = `
                position: absolute;
                background: var(--dark-bg);
                color: var(--text-primary);
                padding: 0.5rem 1rem;
                border-radius: 6px;
                border: 1px solid var(--border-color);
                font-size: 0.875rem;
                white-space: nowrap;
                z-index: 1000;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
                pointer-events: none;
                opacity: 0;
                transform: translateY(-5px);
                transition: all 0.3s ease;
            `;
            
            document.body.appendChild(tooltip);
            
            const rect = this.getBoundingClientRect();
            tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
            tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
            
            requestAnimationFrame(() => {
                tooltip.style.opacity = '1';
                tooltip.style.transform = 'translateY(0)';
            });
            
            this.removeAttribute('title');
            this.setAttribute('data-original-title', tooltip.textContent);
        });
        
        nameElement.addEventListener('mouseleave', function() {
            removeTooltip();
            
            const originalTitle = this.getAttribute('data-original-title');
            if (originalTitle) {
                this.setAttribute('title', originalTitle);
                this.removeAttribute('data-original-title');
            }
        });
    });
}

function removeTooltip() {
    const existingTooltip = document.querySelector('.custom-tooltip');
    if (existingTooltip) {
        existingTooltip.style.opacity = '0';
        existingTooltip.style.transform = 'translateY(-5px)';
        setTimeout(() => {
            if (existingTooltip.parentNode) {
                existingTooltip.parentNode.removeChild(existingTooltip);
            }
        }, 300);
    }
}

function addKeyboardNavigation() {
    document.addEventListener('keydown', function(e) {
        const currentPage = parseInt(new URLSearchParams(window.location.search).get('page')) || 1;
        const statType = new URLSearchParams(window.location.search).get('type') || 'elo';
        
        if (e.key === 'ArrowLeft' && e.ctrlKey) {
            e.preventDefault();
            const prevBtn = document.querySelector('.prev-btn');
            if (prevBtn) {
                window.location.href = prevBtn.href;
            }
        }
        
        if (e.key === 'ArrowRight' && e.ctrlKey) {
            e.preventDefault();
            const nextBtn = document.querySelector('.next-btn');
            if (nextBtn) {
                window.location.href = nextBtn.href;
            }
        }
        
        if (e.key >= '1' && e.key <= '7' && e.ctrlKey) {
            e.preventDefault();
            const statTypes = ['elo', 'wins', 'mvps', 'gamesPlayed', 'losses', 'streak', 'peakElo'];
            const selectedStat = statTypes[parseInt(e.key) - 1];
            if (selectedStat) {
                window.location.href = `?type=${selectedStat}&page=1`;
            }
        }
    });
}

function formatNumber(num) {
    return num.toLocaleString();
}

function getStatDisplayName(statType) {
    const names = {
        'elo': 'ELO',
        'wins': 'Wins',
        'mvps': 'MVPs',
        'gamesPlayed': 'Games',
        'losses': 'Losses',
        'streak': 'Streak',
        'peakElo': 'Peak ELO'
    };
    return names[statType] || 'Value';
}

document.addEventListener('click', function(e) {
    if (e.target.matches('.pagination-btn')) {
        showLoadingState();
    }
});

function highlightTopRanks() {
    const rows = document.querySelectorAll('.leaderboard-row');
    rows.forEach(row => {
        const rank = parseInt(row.getAttribute('data-rank'));
        if (rank <= 3) {
            row.classList.add('top-rank');
        }
    });
}

document.addEventListener('DOMContentLoaded', highlightTopRanks);

document.addEventListener('DOMContentLoaded', function() {
    const avatarImages = document.querySelectorAll('.player-avatar img');
    avatarImages.forEach(img => {
        img.addEventListener('error', function() {
            this.src = 'https://crafatar.com/avatars/steve?size=32';
        });
    });
});

if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, {
        threshold: 0.1
    });

    document.addEventListener('DOMContentLoaded', function() {
        const animatedElements = document.querySelectorAll('.leaderboard-row, .pagination');
        animatedElements.forEach(el => observer.observe(el));
    });
}
