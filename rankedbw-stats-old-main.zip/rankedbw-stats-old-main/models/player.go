package models

import (
	"time"
)

type Player struct {
	ID                 string     `json:"id"`
	UserID             string     `json:"userId"`
	MinecraftName      string     `json:"minecraftName"`
	UUID               string     `json:"uuid"`
	Nickname           *string    `json:"nickname"`
	EloPrefix          bool       `json:"eloPrefix"`
	LastPlayed         *time.Time `json:"lastPlayed"`
	PartyIgnoreList    []string   `json:"partyIgnoreList"`
	BackgroundFileName string     `json:"backgroundFileName"`
	LeftRoleIds        []string   `json:"leftRoleIds"`
	WinStreak          int        `json:"winStreak"`
	LastMojangFetch    time.Time  `json:"lastMojangFetch"`
	CreatedAt          time.Time  `json:"createdAt"`
	UpdatedAt          *time.Time `json:"updatedAt"`
	SelectedInfocardId *string    `json:"selectedInfocardId"`
	FullBodySkin       *string    `json:"fullBodySkin"`
	TotalXP            int        `json:"totalXp"`
	HeadSkin           *string    `json:"headSkin"`
}
