package models

type PlayerStatistics struct {
	ID                  string `json:"id"`
	PlayerID            string `json:"playerId"`
	SeasonID            string `json:"seasonId"`
	ClaimedELO          bool   `json:"claimedELO"`
	Elo                 int    `json:"elo"`
	Wins                int    `json:"wins"`
	MVPs                int    `json:"mvps"`
	GamesPlayed         int    `json:"gamesPlayed"`
	Losses              int    `json:"losses"`
	Streak              int    `json:"streak"`
	Position            int    `json:"position"`
	Screenshares        int    `json:"screenshares"`
	PeakElo             int    `json:"peakElo"`
	ScoredGames         int    `json:"scoredGames"`
	ClaimedScreenshares int    `json:"claimedScreenshares"`
}

type LeaderboardEntry struct {
	Rank          int    `json:"rank"`
	MinecraftName string `json:"minecraftName"`
	UserID        string `json:"userId"`
	Value         int    `json:"value"`
}
