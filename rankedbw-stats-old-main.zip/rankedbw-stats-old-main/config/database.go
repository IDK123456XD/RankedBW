package config

import (
	"database/sql"
	"fmt"
	"log"
	"os"
	"time"

	_ "github.com/lib/pq"
)

var DB *sql.DB

func InitDatabase() {
	connStr := os.Getenv("RANKEDBW_DATABASE_URL")
	if connStr == "" {
		log.Println("db conn string not set. Set RANKEDBW_DATABASE_URL env var.")
	}

	var err error
	DB, err = sql.Open("postgres", connStr)
	if err != nil {
		log.Fatal("could not connect to db", err)
	}

	DB.SetMaxOpenConns(25)
	DB.SetMaxIdleConns(5)
	DB.SetConnMaxLifetime(5 * time.Minute)

	if err = DB.Ping(); err != nil {
		log.Fatal("could not ping db", err)
	}
	fmt.Println("connected to PostgreSQL db!")
	log.Printf("db pool: MaxOpen=%d, MaxIdle=%d", 25, 5)
}
