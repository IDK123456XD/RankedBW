package config

const (
	DefaultPort = ":3001"

	DefaultPageSize = 20
	MaxPageSize     = 100
	MaxPages        = 5  
	MaxTotalItems   = 100

	DefaultTimeout = 30

	DefaultStatType = "elo"
)

var ValidStatTypes = map[string]string{
	"elo":         "ELO Rating",
	"wins":        "Wins",
	"mvps":        "MVPs",
	"gamesPlayed": "Games Played",
	"losses":      "Losses",
	"streak":      "Win Streak",
	"peakElo":     "Peak ELO",
}

func GetStatDisplayName(statType string) string {
	if name, exists := ValidStatTypes[statType]; exists {
		return name
	}
	return "Unknown"
}

func IsValidStatType(statType string) bool {
	_, exists := ValidStatTypes[statType]
	return exists
}
