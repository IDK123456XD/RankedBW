package main

import (
	"html/template"
	"log"
	"net/http"
	"rankedbw-statistics/config"
	"rankedbw-statistics/handlers"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
)

func main() {
	config.InitDatabase()
	defer config.DB.Close()

	r := gin.Default()
	funcMap := template.FuncMap{
		"formatNumber": func(num int) string {
			return addCommas(strconv.Itoa(num))
		},
		"getStatDisplayName": func(statType string) string {
			return config.GetStatDisplayName(statType)
		},
		"calculateWinRate": func(wins, games int) int {
			if games == 0 {
				return 0
			}
			return (wins * 100) / games
		},
		"calculateLossRate": func(losses, games int) int {
			if games == 0 {
				return 0
			}
			return (losses * 100) / games
		},
		"calculateMVPRate": func(mvps, games int) int {
			if games == 0 {
				return 0
			}
			return (mvps * 100) / games
		},
		"calculatePercentage": func(value, max int) int {
			if max == 0 {
				return 0
			}
			percentage := (value * 100) / max
			if percentage > 100 {
				return 100
			}
			return percentage
		},
		"getActivityLevel": func(games int) string {
			if games >= 1000 {
				return "Very High"
			} else if games >= 500 {
				return "High"
			} else if games >= 100 {
				return "Medium"
			} else if games >= 10 {
				return "Low"
			}
			return "Very Low"
		},
	}

	r.SetFuncMap(funcMap)
	r.LoadHTMLGlob("templates/*")

	r.Static("/static", "./static")

	r.GET("/leaderboard/:statType/:page", handlers.GetLeaderboardREST)

	r.GET("/", handlers.GetLeaderboard)
	r.GET("/leaderboard", handlers.GetLeaderboard)
	r.GET("/api/leaderboard", handlers.GetLeaderboardAPI)

	r.GET("/player/:name", handlers.GetPlayerProfile)
	r.GET("/api/player/:name", handlers.GetPlayerProfileAPI)

	r.GET("/player", func(c *gin.Context) {
		c.HTML(http.StatusOK, "player.html", gin.H{
			"Title": "Player Search",
		})
	})

	r.NoRoute(func(c *gin.Context) {
		c.HTML(http.StatusNotFound, "404.html", gin.H{})
	})

	log.Println("server starting on", config.DefaultPort)
	log.Fatal(r.Run(config.DefaultPort))
}

func addCommas(s string) string {
	if len(s) <= 3 {
		return s
	}

	var result strings.Builder
	for i, char := range s {
		if i > 0 && (len(s)-i)%3 == 0 {
			result.WriteString(",")
		}
		result.WriteRune(char)
	}
	return result.String()
}
