"use client";

import { motion } from "framer-motion";
import { XCircle, ArrowLeft, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";

export default function CheckoutCancelPage() {
  return (
    <div className="min-h-screen py-24 flex items-center justify-center">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="max-w-2xl mx-auto"
        >
          <Card className="border-yellow-500/30 bg-yellow-500/5">
            <CardContent className="p-12 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              >
                <XCircle className="w-24 h-24 mx-auto mb-6 text-yellow-500" />
              </motion.div>

              <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-yellow-400 to-orange-600 bg-clip-text text-transparent">
                Checkout Cancelled
              </h1>
              
              <p className="text-xl text-foreground/80 mb-2">
                Your payment was not completed
              </p>
              
              <p className="text-foreground/70 mb-8">
                No charges were made to your account. You can try again whenever you're ready.
              </p>

              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-6 mb-8">
                <h3 className="font-semibold mb-2">Why might this have happened?</h3>
                <ul className="text-sm text-foreground/80 space-y-2 text-left max-w-md mx-auto">
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5">•</span>
                    <span>You clicked the back button or closed the payment window</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5">•</span>
                    <span>The payment session timed out</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5">•</span>
                    <span>You decided not to complete the purchase at this time</span>
                  </li>
                </ul>
              </div>

              <div className="flex gap-4 justify-center flex-wrap">
                <Button asChild size="lg">
                  <Link href="/store">
                    <ArrowLeft className="w-5 h-5 mr-2" />
                    Back to Store
                  </Link>
                </Button>
                <Button asChild variant="secondary" size="lg" onClick={() => window.history.back()}>
                  <span>
                    <RefreshCw className="w-5 h-5 mr-2" />
                    Try Again
                  </span>
                </Button>
              </div>

              <div className="mt-8 pt-8 border-t border-border/50">
                <p className="text-sm text-foreground/60 mb-4">
                  Having trouble completing your purchase?
                </p>
                <div className="flex gap-3 justify-center">
                  <Button asChild variant="ghost" size="sm">
                    <Link href="https://discord.gg/rankedbw" target="_blank">
                      Contact Support
                    </Link>
                  </Button>
                  <Button asChild variant="ghost" size="sm">
                    <Link href="/store/faq">
                      View FAQ
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}

