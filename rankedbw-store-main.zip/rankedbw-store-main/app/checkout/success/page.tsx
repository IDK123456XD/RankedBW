"use client";

import { motion } from "framer-motion";
import { CheckCircle, ArrowRight, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

export default function CheckoutSuccessPage() {
  const searchParams = useSearchParams();
  const [transactionId, setTransactionId] = useState<string | null>(null);

  useEffect(() => {
    // Get transaction ID from URL params if provided by Tebex
    const txnId = searchParams.get('txn_id') || searchParams.get('transaction');
    setTransactionId(txnId);
  }, [searchParams]);

  return (
    <div className="min-h-screen py-24 flex items-center justify-center">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="max-w-2xl mx-auto"
        >
          <Card className="border-green-500/30 bg-green-500/5">
            <CardContent className="p-12 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              >
                <CheckCircle className="w-24 h-24 mx-auto mb-6 text-green-500" />
              </motion.div>

              <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-green-400 to-emerald-600 bg-clip-text text-transparent">
                Payment Successful!
              </h1>
              
              <p className="text-xl text-foreground/80 mb-2">
                Thank you for your purchase!
              </p>
              
              <p className="text-foreground/70 mb-8">
                Your order has been processed and you should receive your items shortly.
                {transactionId && (
                  <span className="block mt-2 text-sm">
                    Transaction ID: <code className="bg-secondary/50 px-2 py-1 rounded">{transactionId}</code>
                  </span>
                )}
              </p>

              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-6 mb-8">
                <h3 className="font-semibold mb-2">What happens next?</h3>
                <ul className="text-sm text-foreground/80 space-y-2 text-left max-w-md mx-auto">
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-0.5">✓</span>
                    <span>Your purchase will be automatically delivered to your account</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-0.5">✓</span>
                    <span>You may need to reconnect to the server for changes to take effect</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-0.5">✓</span>
                    <span>Check your email for a receipt and confirmation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-0.5">✓</span>
                    <span>If you don't receive your items within 10 minutes, contact support</span>
                  </li>
                </ul>
              </div>

              <div className="flex gap-4 justify-center flex-wrap">
                <Button asChild size="lg">
                  <Link href="/">
                    <Home className="w-5 h-5 mr-2" />
                    Go Home
                  </Link>
                </Button>
                <Button asChild variant="secondary" size="lg">
                  <Link href="/store">
                    Continue Shopping
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Link>
                </Button>
              </div>

              <div className="mt-8 pt-8 border-t border-border/50">
                <p className="text-sm text-foreground/60 mb-4">
                  Need help with your order?
                </p>
                <Button asChild variant="ghost" size="sm">
                  <Link href="https://discord.gg/rankedbw" target="_blank">
                    Contact Support on Discord
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}

