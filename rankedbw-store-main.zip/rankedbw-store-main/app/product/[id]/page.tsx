"use client";

import { motion } from "framer-motion";
import { ShoppingCart, Check, ArrowLeft, AlertCircle, Loader2, Plus, Crown, Shield, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { useState, useEffect, useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Image from "next/image";
import { useCart } from "@/lib/cart-context";
import { authManager } from "@/lib/auth-manager";
import DiscordAuthModal from "@/components/discord-auth-modal";
import { TebexPackage } from "@/lib/tebex";

// Helper function to extract first sentence from HTML description
const getFirstSentence = (htmlDescription: string): string => {
  // Remove HTML tags
  const text = htmlDescription.replace(/<[^>]*>/g, '');
  // Get first sentence (up to first period, exclamation, or question mark)
  const match = text.match(/^[^.!?]+[.!?]/);
  return match ? match[0].trim() : text.split('\n')[0].trim();
};

export default function ProductPage({ params }: { params: { id: string } }) {
  const [product, setProduct] = useState<TebexPackage | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();
  const searchParams = useSearchParams();
  const { items, addItem } = useCart();
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [discordAuthUrl, setDiscordAuthUrl] = useState("");
  const [pendingAction, setPendingAction] = useState<'buy' | 'add' | null>(null);

  const isSubscription = product?.type === 'subscription';

  const completeBuyNow = useCallback(async () => {
    if (!product) return;
    
    setIsProcessing(true);
    setError(null);

    try {
      const finalQuantity = isSubscription ? 1 : quantity;
      const webstoreToken = process.env.TEBEX_PUBLIC_TOKEN!;
      const baseUrl = window.location.origin;
      
      console.log('Creating authenticated basket...');
      
      // Step 1: Create basket directly with Tebex (includes auth cookies from Discord OAuth)
      const createResponse = await fetch(
        `https://headless.tebex.io/api/accounts/${webstoreToken}/baskets`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include', // CRITICAL: includes Discord auth cookies
          body: JSON.stringify({
            complete_url: `${baseUrl}/store/checkout/success`,
            cancel_url: `${baseUrl}/store/checkout/cancel`,
            complete_auto_redirect: true,
          }),
        }
      );

      if (!createResponse.ok) {
        const errorText = await createResponse.text();
        console.error('Basket creation failed:', errorText);
        throw new Error(`Failed to create basket (${createResponse.status})`);
      }

      const createData = await createResponse.json();
      const basketIdent = createData.data.ident;
      console.log('Basket created:', basketIdent);

      // Step 2: Add product to basket directly with Tebex
      console.log('Adding product to basket...');
      const addResponse = await fetch(
        `https://headless.tebex.io/api/baskets/${basketIdent}/packages`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include', // CRITICAL: includes Discord auth cookies
          body: JSON.stringify({
            package_id: product.id,
            quantity: finalQuantity,
          }),
        }
      );

      if (!addResponse.ok) {
        const errorText = await addResponse.text();
        console.error('Add to basket failed:', errorText);
        throw new Error(`Failed to add product (${addResponse.status})`);
      }

      const addData = await addResponse.json();
      console.log('Product added to basket');

      // Step 3: Get basket to retrieve checkout URL
      const basketResponse = await fetch(
        `https://headless.tebex.io/api/accounts/${webstoreToken}/baskets/${basketIdent}`,
        {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
        }
      );

      if (!basketResponse.ok) {
        throw new Error('Failed to get basket details');
      }

      const basketData = await basketResponse.json();
      const checkoutUrl = basketData.data?.links?.checkout;

      if (checkoutUrl) {
        console.log('Redirecting to Tebex checkout:', checkoutUrl);
        window.location.href = checkoutUrl;
      } else {
        throw new Error('No checkout URL available');
      }
    } catch (err) {
      console.error('Checkout error:', err);
      setError(err instanceof Error ? err.message : 'Failed to complete checkout. Please try again.');
      setIsProcessing(false);
    }
  }, [product, isSubscription, quantity]);

  // Fetch product data from Tebex categories API
  useEffect(() => {
    const loadProduct = async () => {
      setIsLoading(true);
      try {
        const response = await fetch('/api/tebex/categories');
        const data = await response.json();
        
        if (data.success && data.data) {
          // Find the package with matching ID across all categories
          let foundPackage: TebexPackage | null = null;
          for (const category of data.data) {
            const pkg = category.packages?.find((p: TebexPackage) => p.id.toString() === params.id);
            if (pkg) {
              foundPackage = pkg;
              break;
            }
          }
          setProduct(foundPackage);
        }
      } catch (error) {
        console.error('Failed to load product:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadProduct();
  }, [params.id]);

  // Check for auth tokens in URL on mount (after Discord OAuth callback)
  useEffect(() => {
    const authResult = authManager.parseAuthFromUrl();
    if (authResult) {
      console.log('Discord auth detected:', authResult);
      authManager.setAuth(authResult.token, authResult.user);
      
      // Get the action from URL params (was set before redirecting to Discord)
      const action = searchParams.get('action') || 'buy';
      
      console.log('Redirecting to authenticated flow with action:', action);
      // Clean URL and mark as authenticated
      router.replace(`/store/product/${params.id}?authenticated=true&action=${action}`);
    }
  }, [router, params.id, searchParams]);

  // Handle post-authentication action
  useEffect(() => {
    const authenticated = searchParams.get('authenticated');
    const action = searchParams.get('action');
    
    console.log('Auth check:', { authenticated, action, isAuth: authManager.isAuthenticated(), hasProduct: !!product });
    
    if (authenticated === 'true' && authManager.isAuthenticated() && product) {
      console.log('Executing post-auth action:', action);
      
      if (action === 'buy') {
        completeBuyNow();
      } else if (action === 'add') {
        // Add to cart after auth
        handleAddToCart();
      }
      
      // Clear params after executing
      setTimeout(() => {
        router.replace(`/store/product/${params.id}`);
      }, 500);
    }
  }, [searchParams, product, params.id, router, completeBuyNow]);

  if (isLoading) {
    return (
      <div className="min-h-screen py-24 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-foreground/60">Loading product...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen py-24 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <AlertCircle className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-2xl font-bold mb-2">Product Not Found</h2>
            <p className="text-foreground/70 mb-6">
              The product you're looking for doesn't exist.
            </p>
            <Button asChild>
              <Link href="/store">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Store
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isInCart = items.some(item => item.productId === product?.id.toString());

  // Get icon based on category name
  const getCategoryIcon = (categoryName: string) => {
    const lowerName = categoryName.toLowerCase();
    if (lowerName.includes('unbans')) return Shield;
    if (lowerName.includes('unmutes')) return MessageSquare;
    return Crown; // Default icon
  };

  const handleAddToCart = () => {
    if (!product) return;

    // // Check if user is authenticated with Discord
    // if (!authManager.isAuthenticated()) {
    //   // Show auth modal - user must authenticate before adding to cart
    //   setPendingAction('add');
    //   const returnUrl = `${window.location.origin}/store/product/${product.id}?action=add`;
    //   setDiscordAuthUrl(authUrl);
    //   setShowAuthModal(true);
    //   return;
    // }
    
    // User is authenticated, add to cart
    const cartProduct = {
      id: product.id.toString(),
      name: product.name,
      price: product.total_price,
      description: product.description,
      longDescription: product.description,
      features: [],
      image: product.image || product.media?.find(m => m.type === 'image')?.url,
      icon: getCategoryIcon(product.category.name),
      gradient: "from-blue-500 to-purple-500",
      category: product.category.name.toLowerCase(),
      type: product.type,
      disable_quantity: product.disable_quantity,
    };
    
    // Subscriptions can only have quantity of 1
    const finalQuantity = isSubscription ? 1 : quantity;
    addItem(cartProduct.id, finalQuantity, cartProduct);
    setError(null);
    
    // Show success message or redirect
    setTimeout(() => {
      router.push('/store/cart');
    }, 500);
  };

  // Handle buy now button click
  const handleBuyNow = () => {
    if (!product) return;

    // // Check if user is authenticated
    // if (!authManager.isAuthenticated()) {
    //   // Show auth modal
    //   setPendingAction('buy');
    //   const returnUrl = `${window.location.origin}/store/product/${product.id}?action=buy`;
    //   const authUrl = tebexClient.buildDiscordAuthUrl(returnUrl);
    //   setDiscordAuthUrl(authUrl);
    //   setShowAuthModal(true);
    // } else {
    //   // Already authenticated, proceed to checkout
    //   completeBuyNow();
    // }
  };

  return (
    <div className="min-h-screen py-24">
      <div className="container mx-auto px-6">
        {/* Back Button */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-8"
        >
          <Button variant="ghost" asChild>
            <Link href="/store">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Store
            </Link>
          </Button>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Product Image/Icon Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="sticky top-24">
              <CardContent className="p-12">
                {product.image || product.media?.[0]?.url ? (
                  <div className="w-64 h-64 mx-auto mb-8 relative">
                    <Image
                      src={product.image || product.media[0].url}
                      alt={product.name}
                      width={256}
                      height={256}
                      className="object-contain w-full h-full"
                      priority
                    />
                  </div>
                ) : (
                  <div className="w-48 h-48 mx-auto mb-8 rounded-3xl bg-gradient-to-br from-blue-500 to-purple-500 p-1 shadow-2xl relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent" />
                    <div className="w-full h-full rounded-3xl bg-background flex items-center justify-center relative z-10">
                      {(() => {
                        const IconComponent = getCategoryIcon(product.category.name);
                        return <IconComponent className="w-24 h-24 text-purple-400 drop-shadow-lg" />;
                      })()}
                    </div>
                  </div>
                )}

                <div className="text-center mb-8">
                  <div className="text-sm text-foreground/60 uppercase tracking-wider mb-2">Price</div>
                  <div className="text-6xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent mb-2">
                    ${product.total_price.toFixed(2)}
                  </div>
                  <div className="text-xs text-foreground/50">{product.currency}</div>
                </div>

                {error && (
                  <div className="mb-4 p-4 rounded-lg bg-red-500/10 border border-red-500/30">
                    <p className="text-sm text-center text-red-400">
                      {error}
                    </p>
                  </div>
                )}

                {/* Quantity Selector (if applicable) */}
                {!product.disable_quantity && !isSubscription && (
                  <div className="mb-4 flex items-center justify-center gap-3">
                    <span className="text-sm text-foreground/60">Quantity:</span>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        disabled={quantity <= 1}
                        className="h-9 w-9 p-0"
                      >
                        -
                      </Button>
                      <span className="text-lg font-semibold w-10 text-center">
                        {quantity}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setQuantity(quantity + 1)}
                        className="h-9 w-9 p-0"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  {isInCart ? (
                    <Button
                      className="w-full"
                      size="lg"
                      variant="secondary"
                      asChild
                    >
                      <Link href="/store/cart">
                        <Check className="w-5 h-5 mr-2" />
                        View in Cart
                        <ArrowLeft className="w-4 h-4 ml-2 rotate-180" />
                      </Link>
                    </Button>
                  ) : (
                    <>
                      <Button
                        className="w-full group"
                        size="lg"
                        onClick={handleBuyNow}
                        disabled={isProcessing}
                      >
                        {isProcessing ? (
                          <>
                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <ShoppingCart className="w-5 h-5 mr-2" />
                            {isSubscription ? 'Subscribe' : 'Buy Now'}
                            <ArrowLeft className="w-4 h-4 ml-2 rotate-180" />
                          </>
                        )}
                      </Button>
                      <Button
                        className="w-full group"
                        size="lg"
                        variant="outline"
                        onClick={handleAddToCart}
                      >
                        <Plus className="w-5 h-5 mr-2" />
                        Add to Cart
                      </Button>
                    </>
                  )}
                </div>

                <div className="space-y-2 text-xs text-center text-foreground/60 pt-8">
                  <p className="flex items-center justify-center gap-2">
                    <Check className="w-3 h-3 text-green-500" />
                    Secure payment via Tebex
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Product Details Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            <div>
              <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
                {product.name}
              </h1>
              <p className="text-xl text-foreground/80">
                {getFirstSentence(product.description)}
              </p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>About This Product</CardTitle>
              </CardHeader>
              <CardContent>
                <div 
                  className="tebex-description text-foreground/80"
                  dangerouslySetInnerHTML={{ __html: product.description }}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Product Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-foreground/60 mb-1">Category</p>
                    <p className="font-semibold">{product.category.name}</p>
                  </div>
                  <div>
                    <p className="text-foreground/60 mb-1">Type</p>
                    <p className="font-semibold capitalize">{product.type}</p>
                  </div>
                  <div>
                    <p className="text-foreground/60 mb-1">Base Price</p>
                    <p className="font-semibold">${product.base_price.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-foreground/60 mb-1">Total Price</p>
                    <p className="font-semibold">${product.total_price.toFixed(2)} {product.currency}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-primary/10 to-purple-500/10 border-primary/30">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Need Help?
                </h3>
                <p className="text-sm text-foreground/70 mb-4">
                  Have questions about this product? Our support team is here to help!
                </p>
                <div className="flex gap-3">
                  <Button asChild variant="secondary" size="sm">
                    <Link href="https://discord.gg/rankedbw" target="_blank">
                      Contact Support
                    </Link>
                  </Button>
                  <Button asChild variant="ghost" size="sm">
                    <Link href="/store/faq">
                      View FAQ
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Alternative Payment Methods */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 max-w-4xl mx-auto"
        >
          <Card className="bg-blue-500/10 border-blue-500/30">
            <CardContent className="p-6 text-center">
              <h3 className="text-lg font-semibold mb-2">Want to pay with cryptocurrency?</h3>
              <p className="text-foreground/70 text-sm mb-4">
                We accept Bitcoin, Ethereum, and other cryptocurrencies. Contact us on Discord to arrange payment.
              </p>
              <Button asChild variant="secondary">
                <Link href="https://discord.gg/rankedbw" target="_blank">
                  <svg className="w-5 h-5 mr-2 fill-current" viewBox="0 0 24 24">
                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
                  </svg>
                  Contact on Discord
                </Link>
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Discord Authentication Modal */}
      <DiscordAuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        authUrl={discordAuthUrl}
        productName={product?.name}
      />
    </div>
  );
}
