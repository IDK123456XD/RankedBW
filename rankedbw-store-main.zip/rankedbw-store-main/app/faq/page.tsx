"use client";

import { motion } from "framer-motion";
import { HelpCircle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

const faqs = [
  {
    category: "General",
    questions: [
      {
        q: "How do I make a purchase?",
        a: "Browse our store, add items to your cart, and proceed to checkout. You can pay with credit/debit cards or contact us on Discord for alternative payment methods like cryptocurrency.",
      },
      {
        q: "When will I receive my purchase?",
        a: "All digital products are delivered instantly to your account upon successful payment. You may need to reconnect to the server for changes to take effect.",
      },
      {
        q: "Can I get a refund?",
        a: "Due to the digital nature of our products, all sales are final. However, if you experience technical issues, please contact our support team on Discord.",
      },
    ],
  },
  {
    category: "Prime Membership",
    questions: [
      {
        q: "What is Prime Membership?",
        a: "Prime is our premium membership that gives you access to exclusive features, cosmetics, priority support, and special events. It's the best way to enhance your Ranked Bedwars experience.",
      },
      {
        q: "How long does Prime last?",
        a: "Prime membership is valid for 30 days from the date of purchase. You can renew it at any time.",
      },
      {
        q: "Do Prime benefits stack with other purchases?",
        a: "Yes! Prime benefits stack with all other purchases including coin boosters and cosmetics.",
      },
    ],
  },
  {
    category: "Custom Roles",
    questions: [
      {
        q: "How do custom Discord roles work?",
        a: "After purchasing a custom role, you can choose a name and color (hex code). Submit your choices through our Discord and staff will create your role within 24-48 hours.",
      },
      {
        q: "Can I change my custom role?",
        a: "You can change your role's color once per month. Name changes require a new purchase.",
      },
      {
        q: "Are there any restrictions on role names?",
        a: "Yes, role names must follow Discord's guidelines and our server rules. No inappropriate content, impersonation, or misleading names.",
      },
    ],
  },
  {
    category: "Appeals (Unbans/Unmutes)",
    questions: [
      {
        q: "Does purchasing an unban guarantee I'll be unbanned?",
        a: "No. Purchasing an unban gives you an appeal review by our staff team. The final decision is based on the severity of your offense and your appeal reasoning.",
      },
      {
        q: "What if my appeal is denied?",
        a: "If your appeal is denied, the purchase is non-refundable as you're paying for the review process, not the guaranteed outcome.",
      },
      {
        q: "How long does the appeal process take?",
        a: "Unbans typically take 48-72 hours to review. Unmutes are usually reviewed within 24-48 hours. You'll be contacted via Discord.",
      },
      {
        q: "Can I appeal a permanent ban?",
        a: "Permanent bans for severe offenses (hacking, severe toxicity, etc.) may not be eligible for appeals. Contact staff on Discord first to check eligibility.",
      },
    ],
  },
  {
    category: "Coins & Boosters",
    questions: [
      {
        q: "How do I use my coins?",
        a: "Coins can be used in the in-game cosmetics shop to purchase items, effects, and other cosmetic upgrades.",
      },
      {
        q: "Do coins expire?",
        a: "No, coins never expire and will remain on your account indefinitely.",
      },
      {
        q: "Do boosters stack?",
        a: "Yes! ELO boosters and coin boosters stack with each other and with Prime membership bonuses.",
      },
    ],
  },
  {
    category: "Payment & Security",
    questions: [
      {
        q: "Is it safe to make purchases?",
        a: "Yes! All transactions are processed through secure payment providers. We never store your payment information.",
      },
      {
        q: "Can I pay with cryptocurrency?",
        a: "Yes! Create a ticket in our Discord server and our staff will help you complete your purchase with crypto.",
      },
      {
        q: "What payment methods do you accept?",
        a: "We accept credit/debit cards, PayPal, and cryptocurrency (via Discord ticket).",
      },
    ],
  },
];

export default function FAQPage() {
  return (
    <div className="min-h-screen py-24">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-8"
          >
            <Button variant="ghost" asChild>
              <Link href="/store">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Store
              </Link>
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <HelpCircle className="w-16 h-16 mx-auto mb-4 text-blue-500" />
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
              Frequently Asked Questions
            </h1>
            <p className="text-lg text-foreground/70">
              Find answers to common questions about our store and products
            </p>
          </motion.div>

          <div className="space-y-12">
            {faqs.map((category, catIndex) => (
              <motion.div
                key={category.category}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: catIndex * 0.1 }}
              >
                <h2 className="text-3xl font-bold mb-6 text-blue-400">
                  {category.category}
                </h2>
                <div className="space-y-4">
                  {category.questions.map((faq, qIndex) => (
                    <Card key={qIndex}>
                      <CardHeader>
                        <CardTitle className="text-xl">{faq.q}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-foreground/80 leading-relaxed">{faq.a}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16"
          >
            <Card className="bg-gradient-to-br from-primary/10 to-purple-500/10 border-primary/30">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-4">Still Have Questions?</h3>
                <p className="text-foreground/70 mb-6">
                  Can't find what you're looking for? Join our Discord and ask our support team!
                </p>
                <Button asChild size="lg">
                  <Link href="https://discord.gg/rankedbw" target="_blank">
                    <span className="mr-2">💬</span>
                    Join Discord
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

