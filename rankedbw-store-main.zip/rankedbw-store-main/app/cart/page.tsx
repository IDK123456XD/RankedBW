"use client";

import { motion } from "framer-motion";
import { ShoppingCart, Trash2, ArrowLeft, AlertCircle, Plus, Minus, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { useCart } from "@/lib/cart-context";
import Image from "next/image";
import { useState, useEffect, useCallback } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { authManager } from "@/lib/auth-manager";
import DiscordAuthModal from "@/components/discord-auth-modal";

// Helper function to extract first sentence from HTML description
const getFirstSentence = (htmlDescription: string): string => {
  // Remove HTML tags
  const text = htmlDescription.replace(/<[^>]*>/g, '');
  // Get first sentence (up to first period, exclamation, or question mark)
  const match = text.match(/^[^.!?]+[.!?]/);
  return match ? match[0].trim() : text.split('\n')[0].trim();
};

export default function CartPage() {
  const { items, removeItem, updateQuantity, getTotal, clearCart } = useCart();
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [discordAuthUrl, setDiscordAuthUrl] = useState("");
  const searchParams = useSearchParams();
  const router = useRouter();

  // Check for auth tokens in URL on mount (after Discord OAuth callback)
  useEffect(() => {
    const authResult = authManager.parseAuthFromUrl();
    if (authResult) {
      console.log('✅ Discord auth detected in cart:', authResult);
      authManager.setAuth(authResult.token, authResult.user);
      // Clean URL (remove auth params)
      console.log('🔄 Redirecting to authenticated flow');
      router.replace('/store/cart?authenticated=true');
    }
  }, [router]);

  // Handle post-authentication checkout
  useEffect(() => {
    const authenticated = searchParams.get('authenticated');
    
    console.log('Cart auth check:', { authenticated, isAuth: authManager.isAuthenticated(), itemCount: items.length });
    
    if (authenticated === 'true' && authManager.isAuthenticated() && items.length > 0) {
      console.log('Executing post-auth checkout');
      completeCheckout();
    }
  }, [searchParams, items]);

  // Complete checkout after authentication
  // Makes DIRECT calls to Tebex API (not through our server) to include auth cookies
  const completeCheckout = async () => {
    if (items.length === 0) return;
    
    setIsProcessing(true);
    setError(null);

    try {
      const webstoreToken = process.env.TEBEX_PUBLIC_TOKEN!;
      const baseUrl = window.location.origin;
      
      console.log('Creating authenticated basket for cart...');
      
      // Step 1: Create basket directly with Tebex (includes auth cookies from Discord OAuth)
      const createResponse = await fetch(
        `https://headless.tebex.io/api/accounts/${webstoreToken}/baskets`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include', // CRITICAL: includes Discord auth cookies
          body: JSON.stringify({
            complete_url: `${baseUrl}/store/checkout/success`,
            cancel_url: `${baseUrl}/store/checkout/cancel`,
            complete_auto_redirect: true,
          }),
        }
      );

      if (!createResponse.ok) {
        const errorText = await createResponse.text();
        console.error('Basket creation failed:', errorText);
        throw new Error(`Failed to create basket (${createResponse.status})`);
      }

      const createData = await createResponse.json();
      const basketIdent = createData.data.ident;
      console.log('Basket created:', basketIdent);

      // Step 2: Add all cart items to basket
      console.log('Adding items to basket...');
      for (const item of items) {
        const addResponse = await fetch(
          `https://headless.tebex.io/api/baskets/${basketIdent}/packages`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
              package_id: parseInt(item.productId),
              quantity: item.quantity,
            }),
          }
        );

        if (!addResponse.ok) {
          const errorText = await addResponse.text();
          console.error(`Failed to add ${item.product?.name}:`, errorText);
          throw new Error(`Failed to add ${item.product?.name} to basket`);
        }
        
        console.log(`Added ${item.product?.name}`);
      }

      // Step 3: Get basket to retrieve checkout URL
      const basketResponse = await fetch(
        `https://headless.tebex.io/api/accounts/${webstoreToken}/baskets/${basketIdent}`,
        {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
        }
      );

      if (!basketResponse.ok) {
        throw new Error('Failed to get basket details');
      }

      const basketData = await basketResponse.json();
      const checkoutUrl = basketData.data?.links?.checkout;

      if (checkoutUrl) {
        console.log('🔄 Redirecting to Tebex checkout:', checkoutUrl);
        clearCart();
        window.location.href = checkoutUrl;
      } else {
        throw new Error('No checkout URL available');
      }
    } catch (err) {
      console.error('❌ Checkout error:', err);
      setError(err instanceof Error ? err.message : 'Failed to complete checkout. Please try again.');
      setIsProcessing(false);
    }
  };

  // Handle checkout button click
  const handleCheckout = () => {
    if (items.length === 0) return;

    // // Check if user is authenticated
    // if (!authManager.isAuthenticated()) {
    //   // Show auth modal
    //   const returnUrl = `${window.location.origin}/store/cart`;
    //   const authUrl = tebexClient.buildDiscordAuthUrl(returnUrl);
    //   setDiscordAuthUrl(authUrl);
    //   setShowAuthModal(true);
    // } else {
    //   // Already authenticated, proceed to checkout
    //   completeCheckout();
    // }
  };

  const handleUpdateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) {
      removeItem(productId);
      return;
    }
    updateQuantity(productId, newQuantity);
  };

  const totalPrice = getTotal();

  if (items.length === 0 && !isProcessing) {
    return (
      <div className="min-h-screen py-24">
        <div className="starfield" />
        <div className="container mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl mx-auto"
          >
            <Card className="border-2 border-primary/30">
              <CardContent className="p-12 text-center">
                <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center">
                  <ShoppingCart className="w-16 h-16 text-primary" />
                </div>
                <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
                  Your Cart is Empty
                </h2>
                <p className="text-foreground/70 mb-8 text-lg">
                  Start shopping to add items to your cart!
                </p>
                <Button asChild size="lg" className="group">
                  <Link href="/store">
                    <ArrowLeft className="w-5 h-5 mr-2 transition-transform group-hover:-translate-x-1" />
                    Continue Shopping
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-24">
      <div className="starfield" />
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-6xl mx-auto"
        >
          {/* Header */}
          <div className="mb-8 flex items-center justify-between">
            <Button variant="ghost" asChild>
              <Link href="/store">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Continue Shopping
              </Link>
            </Button>
            
            {isProcessing && (
              <div className="flex items-center gap-2 text-sm text-foreground/60">
                <Loader2 className="w-4 h-4 animate-spin" />
                {authManager.isAuthenticated() ? 'Completing checkout...' : 'Processing...'}
              </div>
            )}
          </div>

          <div className="flex items-center gap-3 mb-8">
            <ShoppingCart className="w-10 h-10 text-blue-500" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
              Shopping Cart
            </h1>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-6"
            >
              <Card className="border-red-500/30 bg-red-500/10">
                <CardContent className="p-4 flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                  <p className="text-sm text-red-400">{error}</p>
                </CardContent>
              </Card>
            </motion.div>
          )}

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {items.map((item, index) => {
                const product = item.product;
                if (!product) return null;

                return (
                  <motion.div
                    key={item.productId}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Card className="overflow-hidden hover:border-primary/50 transition-colors">
                      <CardContent className="p-6">
                        <div className="flex gap-6">
                          {/* Product Image */}
                          <div className="flex-shrink-0">
                            {product.image ? (
                              <div className="w-24 h-24 relative rounded-lg overflow-hidden bg-gradient-to-br from-primary/10 to-purple-500/10">
                                <Image
                                  src={product.image}
                                  alt={product.name}
                                  width={96}
                                  height={96}
                                  className="object-contain"
                                />
                              </div>
                            ) : (
                              <div className={`w-24 h-24 rounded-lg bg-gradient-to-br ${product.gradient} p-0.5`}>
                                <div className="w-full h-full rounded-lg bg-background flex items-center justify-center">
                                  <product.icon className="w-12 h-12 text-white" />
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Product Info */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-4 mb-2">
                              <div>
                                <h3 className="text-xl font-bold text-foreground mb-1">
                                  {product.name}
                                </h3>
                                <p className="text-sm text-foreground/60 line-clamp-2">
                                  {getFirstSentence(product.description)}
                                </p>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeItem(item.productId)}
                                className="text-red-500 hover:text-red-400 hover:bg-red-500/10"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>

                            <div className="flex items-center justify-between mt-4">
                              {/* Quantity Controls */}
                              {product.type === 'subscription' || product.disable_quantity ? (
                                <div className="flex items-center gap-3">
                                  <span className="text-sm text-foreground/60">Quantity:</span>
                                  <span className="text-lg font-semibold">1</span>
                                  {product.type === 'subscription' && (
                                    <span className="text-xs text-foreground/50 bg-primary/10 px-2 py-1 rounded">Subscription</span>
                                  )}
                                </div>
                              ) : (
                                <div className="flex items-center gap-3">
                                  <span className="text-sm text-foreground/60">Quantity:</span>
                                  <div className="flex items-center gap-2">
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleUpdateQuantity(item.productId, item.quantity - 1)}
                                      disabled={item.quantity <= 1}
                                      className="h-8 w-8 p-0"
                                    >
                                      <Minus className="w-3 h-3" />
                                    </Button>
                                    <span className="text-lg font-semibold w-8 text-center">
                                      {item.quantity}
                                    </span>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleUpdateQuantity(item.productId, item.quantity + 1)}
                                      className="h-8 w-8 p-0"
                                    >
                                      <Plus className="w-3 h-3" />
                                    </Button>
                                  </div>
                                </div>
                              )}

                              {/* Price */}
                              <div className="text-right">
                                <div className="text-xs text-foreground/60 mb-1">
                                  ${product.price.toFixed(2)} {product.type === 'subscription' ? '/ month' : 'each'}
                                </div>
                                <div className={`text-2xl font-bold bg-gradient-to-r ${product.gradient} bg-clip-text text-transparent`}>
                                  ${(product.price * item.quantity).toFixed(2)}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>

            {/* Order Summary */}
            <div>
              <Card className="sticky top-24 border-2 border-primary/30">
                <CardHeader>
                  <CardTitle className="text-2xl">Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-foreground/70">Items ({items.reduce((sum, item) => sum + item.quantity, 0)})</span>
                      <span className="font-medium">${totalPrice.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-foreground/70">Subtotal</span>
                      <span className="font-medium">${totalPrice.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-foreground/70">Processing Fee</span>
                      <span className="font-medium">Calculated at checkout</span>
                    </div>
                    <div className="border-t border-border pt-3 flex justify-between items-center">
                      <span className="font-semibold text-lg">Total</span>
                      <div className="text-right">
                        <div className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
                          ${totalPrice.toFixed(2)}
                        </div>
                        <div className="text-xs text-foreground/60">+ fees</div>
                      </div>
                    </div>
                  </div>

                  <Button 
                    className="w-full group" 
                    size="lg"
                    onClick={handleCheckout}
                    disabled={isProcessing || items.length === 0}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      'Proceed to Checkout'
                    )}
                  </Button>

                  <div className="space-y-3 pt-4 border-t border-border">
                    <div className="flex items-center gap-2 text-xs text-foreground/60">
                      <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <svg className="w-3 h-3 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span>Discord authentication required</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-foreground/60">
                      <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <svg className="w-3 h-3 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span>Secure payment via Tebex</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-foreground/60">
                      <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                        <svg className="w-3 h-3 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                      </div>
                      <span>Instant delivery via Discord</span>
                    </div>
                  </div>

                  <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                    <div className="flex gap-3">
                      <AlertCircle className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                      <div className="text-sm">
                        <p className="font-medium mb-1 text-blue-400">Authentication Required</p>
                        <p className="text-foreground/70 text-xs">
                          You'll be redirected to Discord to authenticate before checkout. This ensures secure delivery to your Discord account.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Discord Authentication Modal */}
      <DiscordAuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        authUrl={discordAuthUrl}
        productName="Cart Items"
      />
    </div>
  );
}
