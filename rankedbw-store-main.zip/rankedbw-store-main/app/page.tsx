"use client";

import { motion } from "framer-motion";
import { ShoppingCart, Check, ArrowRight, Shield, Zap, Loader2, Crown, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import Link from "next/link";
import Image from "next/image";
import { useState, useEffect } from "react";
import { useCart } from "@/lib/cart-context";
import { TebexCategory, TebexPackage } from "@/lib/tebex";

// Helper function to extract first sentence from HTML description
const getFirstSentence = (htmlDescription: string): string => {
  // Remove HTML tags
  const text = htmlDescription.replace(/<[^>]*>/g, '');
  // Get first sentence (up to first period, exclamation, or question mark)
  const match = text.match(/^[^.!?]+[.!?]/);
  return match ? match[0].trim() : text.split('\n')[0].trim();
};



export default function StorePage() {
  const [categories, setCategories] = useState<TebexCategory[]>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const [packages, setPackages] = useState<TebexPackage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { items, addItem, getItemCount, getTotal } = useCart();

  // Fetch categories and packages on mount
  useEffect(() => {
    const loadCategories = async () => {
      setIsLoading(true);
      try {
        const response = await fetch('/api/tebex/categories');
        const data = await response.json();
        
        if (data.success && data.data) {
          setCategories(data.data);
          // Select first category by default
          if (data.data.length > 0) {
            setSelectedCategoryId(data.data[0].id);
          }
        }
      } catch (error) {
        console.error('Failed to load categories:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadCategories();
  }, []);

  // Update packages when category changes
  useEffect(() => {
    if (selectedCategoryId !== null) {
      const category = categories.find(c => c.id === selectedCategoryId);
      setPackages(category?.packages || []);
    }
  }, [selectedCategoryId, categories]);

  // Find Prime++ as the featured product (search across all categories)
  const featuredPackage = categories
    .flatMap(cat => cat.packages || [])
    .find(pkg => pkg.name.toLowerCase().includes('prime++') || pkg.name.toLowerCase().includes('prime ++'))
  
  // Get icon based on category name
  const getCategoryIcon = (categoryName: string) => {
    const lowerName = categoryName.toLowerCase();
    if (lowerName.includes('unbans')) return Shield;
    if (lowerName.includes('unmutes')) return MessageSquare;
    return Crown; // Default icon
  };

  const handleAddToCart = (pkg: TebexPackage) => {
    // Convert Tebex package to cart-compatible format
    const product = {
      id: pkg.id.toString(),
      name: pkg.name,
      price: pkg.total_price,
      description: pkg.description,
      longDescription: pkg.description,
      features: [],
      image: pkg.image || pkg.media?.find(m => m.type === 'image')?.url,
      icon: getCategoryIcon(pkg.category.name),
      gradient: "from-blue-500 to-purple-500",
      category: pkg.category.name.toLowerCase(),
      type: pkg.type,
      disable_quantity: pkg.disable_quantity,
    };
    // Subscriptions can only have quantity of 1
    addItem(product.id, 1, product);
  };

  const isInCart = (productId: string) => items.some(item => item.productId === productId);

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen py-24 relative">
        <div className="starfield" />
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <Loader2 className="w-12 h-12 animate-spin text-primary mb-4" />
            <p className="text-lg text-foreground/60">Loading store...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-24 relative">
      {/* Starfield Background */}
      <div className="starfield" />
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <ShoppingCart className="w-12 h-12 text-blue-500" />
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
              Store
            </h1>
          </div>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto mb-6">
            Enhance your Ranked Bedwars experience with memberships, custom roles, and more
          </p>
          <div className="flex items-center justify-center gap-6 text-sm text-foreground/60 flex-wrap">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-green-500" />
              <span>Secure Payments</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-500" />
              <span>Instant Delivery</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-blue-500" />
              <span>24/7 Support</span>
            </div>
          </div>
        </motion.div>

        {/* Featured Product Hero */}
        {featuredPackage && (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="mb-16 perspective-1000"
          >
            <div className="relative max-w-6xl mx-auto group">
              {/* Background Glow */}
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 rounded-3xl blur-2xl opacity-30 group-hover:opacity-50 transition-opacity duration-500 animate-pulse" />
              
              {/* Main Card */}
              <Card className="relative overflow-hidden border-2 border-primary/30 shadow-2xl backdrop-blur-xl bg-gradient-to-br from-background/80 via-background/60 to-background/80 transform transition-all duration-500 hover:scale-[1.02]">
                {/* Featured Badge */}
                <div className="absolute top-4 right-4 z-20">
                  <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-4 py-2 rounded-full text-xs font-bold uppercase shadow-lg flex items-center gap-2">
                    <span className="text-lg">⭐</span>
                    Featured
                  </div>
                </div>

                <CardContent className="p-8 md:p-12">
                  <div className="grid md:grid-cols-2 gap-8 items-center">
                    {/* Left Side - Product Image */}
                    <motion.div
                      className="relative"
                      whileHover={{ scale: 1.05 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="relative bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-3xl p-8 backdrop-blur-sm border border-purple-500/30 shadow-2xl">
                        {featuredPackage.image || featuredPackage.media?.[0]?.url ? (
                          <Image
                            src={featuredPackage.image || featuredPackage.media[0].url}
                            alt={featuredPackage.name}
                            width={400}
                            height={400}
                            className="object-contain w-full h-auto drop-shadow-2xl"
                          />
                        ) : (
                          <div className="w-full h-64 flex items-center justify-center">
                            <Crown className="w-32 h-32 text-purple-400 drop-shadow-2xl" />
                          </div>
                        )}
                      </div>
                    </motion.div>

                    {/* Right Side - Product Details */}
                    <div className="space-y-6 relative z-10">
                      {/* Product Name */}
                      <div>
                        <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent mb-3 leading-tight">
                          {featuredPackage.name}
                        </h2>
                        <p className="text-xl text-foreground/80 leading-relaxed">
                          {getFirstSentence(featuredPackage.description)}
                        </p>
                      </div>

                      {/* Price & CTA */}
                      <div className="flex items-center gap-6 pt-4">
                        <div>
                          <div className="text-sm text-foreground/60 uppercase tracking-wider mb-1">
                            Only
                          </div>
                          <div className="text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                            ${featuredPackage.total_price.toFixed(2)}
                          </div>
                          <div className="text-xs text-foreground/50 mt-1">{featuredPackage.currency}</div>
                        </div>
                        
                        <Link href={`/store/product/${featuredPackage.id}`} className="flex-1">
                          <Button 
                            size="lg" 
                            className="w-full bg-gradient-to-r from-purple-500 via-pink-500 to-purple-500 hover:from-purple-600 hover:via-pink-600 hover:to-purple-600 text-white font-bold text-lg py-6 shadow-xl shadow-purple-500/30 hover:shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 group/btn"
                          >
                            Get {featuredPackage.name} Now
                            <ArrowRight className="ml-2 w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        )}

        {/* Shopping Cart Floating Button */}
        {getItemCount() > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="fixed bottom-8 right-8 z-50"
          >
            <Link href="/store/cart">
              <Card className="bg-primary hover:bg-primary/90 transition-all cursor-pointer shadow-2xl shadow-primary/50 border-0">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="relative">
                    <ShoppingCart className="w-6 h-6 text-white" />
                    <div className="absolute -top-2 -right-2 bg-white text-primary rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                      {getItemCount()}
                    </div>
                  </div>
                  <div className="text-white">
                    <div className="text-xs font-medium">Cart Total</div>
                    <div className="text-lg font-bold">${getTotal().toFixed(2)}</div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-white" />
                </CardContent>
              </Card>
            </Link>
          </motion.div>
        )}

        {/* Category Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-12"
        >
          <div className="flex items-center justify-center mb-6">
            <h2 className="text-2xl font-bold text-foreground/90">
              Browse by Category
            </h2>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => {
              return (
                <Button
                  key={category.id}
                  variant={selectedCategoryId === category.id ? "default" : "outline"}
                  onClick={() => setSelectedCategoryId(category.id)}
                  className={`gap-2 transition-all ${
                    selectedCategoryId === category.id 
                      ? 'shadow-lg shadow-primary/30 scale-105' 
                      : 'hover:scale-105'
                  }`}
                  size="lg"
                >
                  <Crown className="w-5 h-5" />
                  {category.name}
                  <span className="ml-1 px-2 py-0.5 rounded-full text-xs bg-background/50">
                    {category.packages?.length || 0}
                  </span>
                </Button>
              );
            })}
          </div>
        </motion.div>

        {/* Current Category Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between max-w-6xl mx-auto">
            <div className="flex items-center gap-3">
              <Crown className="w-8 h-8 text-primary" />
              <div>
                <h2 className="text-3xl font-bold text-foreground">
                  {categories.find(c => c.id === selectedCategoryId)?.name || 'Products'}
                </h2>
                <p className="text-sm text-foreground/60 mt-1">
                  {packages.length} {packages.length === 1 ? 'product' : 'products'} available
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
            >
              <Link href={`/store/product/${pkg.id}`} className="block h-full">
                <Card className="h-full relative overflow-hidden group hover:scale-[1.02] transition-transform cursor-pointer">
                  <CardHeader>
                    {/* Product Image */}
                    {pkg.image || pkg.media?.[0]?.url ? (
                      <div className="w-32 h-32 mx-auto mb-4 relative">
                        <Image
                          src={pkg.image || pkg.media[0].url}
                          alt={pkg.name}
                          width={128}
                          height={128}
                          className="object-contain w-full h-full"
                        />
                      </div>
                    ) : (
                      <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-500 p-0.5 shadow-xl">
                        <div className="w-full h-full rounded-2xl bg-background flex items-center justify-center">
                          {(() => {
                            const IconComponent = getCategoryIcon(pkg.category.name);
                            return <IconComponent className="w-10 h-10 text-purple-400" />;
                          })()}
                        </div>
                      </div>
                    )}
                    
                    <CardTitle className="text-2xl text-center mb-2">{pkg.name}</CardTitle>
                    <CardDescription className="text-center text-base line-clamp-2">
                      {getFirstSentence(pkg.description)}
                    </CardDescription>
                  </CardHeader>

                  <CardContent className="space-y-6">
                    {/* Price and CTA */}
                    <div className="pt-4 border-t border-border/50 space-y-4">
                      <div className="text-center">
                        <div className="text-xs text-foreground/50 uppercase tracking-wider mb-1">Price</div>
                        <div className="text-4xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
                          ${pkg.total_price.toFixed(2)}
                        </div>
                        <div className="text-xs text-foreground/50 mt-1">{pkg.currency}</div>
                      </div>

                      <Button
                        className="w-full group"
                        variant={isInCart(pkg.id.toString()) ? "secondary" : "default"}
                        size="lg"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          handleAddToCart(pkg);
                        }}
                        disabled={isInCart(pkg.id.toString())}
                      >
                        {isInCart(pkg.id.toString()) ? (
                          <>
                            <Check className="w-5 h-5 mr-2" />
                            Added to Cart
                          </>
                        ) : (
                          <>
                            <ShoppingCart className="w-5 h-5 mr-2" />
                            Add to Cart
                            <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                          </>
                        )}
                      </Button>

                      <div className="text-center text-xs text-foreground/60 mt-2">
                        Click anywhere to view details
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Info Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mt-24"
        >
          <Card className="bg-gradient-to-br from-primary/10 to-purple-500/10 border-primary/30">
            <CardContent className="p-8 md:p-12 text-center">
              <h3 className="text-3xl font-bold mb-4">Need Help?</h3>
              <p className="text-foreground/70 mb-8 max-w-2xl mx-auto text-lg">
                Have questions about our products or need support? Our community is here to help!
              </p>
              <div className="flex gap-4 justify-center flex-wrap">
                <Button asChild size="lg">
                  <Link href="https://discord.gg/rankedbw" target="_blank">
                    <span className="mr-2">💬</span>
                    Join Discord
                  </Link>
                </Button>
                <Button asChild variant="secondary" size="lg">
                  <Link href="/store/faq">
                    View FAQ
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
