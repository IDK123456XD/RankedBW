import { NextResponse } from 'next/server';
import { getTebexCategoriesWithPackages, getPublicTebexToken } from '@/lib/tebex';

export async function GET() {
  try {
    const token = getPublicTebexToken();
    const categories = await getTebexCategoriesWithPackages(token);
    
    return NextResponse.json({
      success: true,
      data: categories.data
    });
  } catch (error) {
    console.error('Error fetching Tebex categories:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to fetch categories' 
      },
      { status: 500 }
    );
  }
}

