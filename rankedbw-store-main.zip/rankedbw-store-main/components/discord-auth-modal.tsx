"use client";

import { motion, AnimatePresence } from "framer-motion";
import { X, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Image from "next/image";

interface DiscordAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  authUrl: string;
  productName?: string;
}

export default function DiscordAuthModal({ isOpen, onClose, authUrl, productName }: DiscordAuthModalProps) {
  const handleAuthenticate = () => {
    // Open Discord auth in same window (will redirect back)
    window.location.href = authUrl;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: "spring", duration: 0.3 }}
              className="w-full max-w-md"
            >
              <Card className="border-purple-500/20 bg-background/95 backdrop-blur">
                <CardHeader className="space-y-1 pb-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1 flex-1">
                      <CardTitle className="text-2xl font-bold">
                        Discord Authentication Required
                      </CardTitle>
                      <CardDescription className="text-base">
                        {productName 
                          ? `To purchase "${productName}", please authenticate with Discord.`
                          : "Please authenticate with Discord to continue."}
                      </CardDescription>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={onClose}
                      className="h-8 w-8 p-0 ml-2"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  {/* Discord Logo */}
                  <div className="flex justify-center py-4">
                    <div className="w-20 h-20 rounded-full bg-[#5865F2] flex items-center justify-center">
                      <svg className="w-12 h-12 text-white" viewBox="0 0 127.14 96.36" fill="currentColor">
                        <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/>
                      </svg>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="space-y-2 text-sm text-foreground/60">
                    <p>
                      We use Discord to verify your identity and deliver your purchase. Your Discord username will be linked to your order.
                    </p>
                    <p className="text-xs text-foreground/50">
                      You'll be redirected to Discord to authorize access, then returned to complete your purchase.
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-3 pt-2">
                    <Button
                      onClick={handleAuthenticate}
                      size="lg"
                      className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white"
                    >
                      Authenticate with Discord
                      <ExternalLink className="ml-2 h-4 w-4" />
                    </Button>
                    <Button
                      onClick={onClose}
                      variant="outline"
                      size="lg"
                      className="w-full"
                    >
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}

