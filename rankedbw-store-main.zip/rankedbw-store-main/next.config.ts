import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'dunb17ur4ymx4.cloudfront.net',
        pathname: '/**',
      },
    ],
  },
};

export default nextConfig;
