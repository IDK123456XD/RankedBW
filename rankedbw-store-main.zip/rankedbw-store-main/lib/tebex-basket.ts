/**
 * Tebex Basket Operations (Client-side only)
 * These functions make direct calls to Tebex API and include authentication cookies
 */

const TEBEX_BASE_URL = 'https://headless.tebex.io/api';

/**
 * Create an authenticated basket
 * Must be called AFTER Discord authentication (cookies are required)
 */
export async function createBasket(completeUrl: string, cancelUrl: string) {
  const token = process.env.TEBEX_PUBLIC_TOKEN;

  const response = await fetch(`${TEBEX_BASE_URL}/accounts/${token}/baskets`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include', // Critical: includes Discord auth cookies
    body: JSON.stringify({
      complete_url: completeUrl,
      cancel_url: cancelUrl,
      complete_auto_redirect: true,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Failed to create basket: ${error}`);
  }

  const data = await response.json();
  return data.data;
}

/**
 * Add a package to the basket
 */
export async function addPackageToBasket(
  basketIdent: string,
  packageId: number,
  quantity: number = 1
) {
  const response = await fetch(`${TEBEX_BASE_URL}/baskets/${basketIdent}/packages`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include', // Critical: includes Discord auth cookies
    body: JSON.stringify({
      package_id: packageId,
      quantity: quantity,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Failed to add package: ${error}`);
  }

  return await response.json();
}

/**
 * Get basket details (including checkout URL)
 */
export async function getBasket(basketIdent: string) {
  const token = process.env.TEBEX_PUBLIC_TOKEN;

  const response = await fetch(
    `${TEBEX_BASE_URL}/accounts/${token}/baskets/${basketIdent}`,
    {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    }
  );

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Failed to get basket: ${error}`);
  }

  const data = await response.json();
  return data.data;
}



