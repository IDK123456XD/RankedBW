export interface PackageMedia {
  type: 'video' | 'image';
  name: string | null;
  url: string;
  featured: boolean;
}

export interface TebexPackage {
  id: number;
  name: string;
  description: string;
  image: string | null;
  type: string;
  category: {
    id: number;
    name: string;
  };
  base_price: number;
  sales_tax: number;
  total_price: number;
  currency: string;
  prorate_price?: number | null;
  discount: number;
  disable_quantity: boolean;
  disable_gifting: boolean;
  expiration_date: string | null;
  media: PackageMedia[];
  created_at: string;
  updated_at: string;
}

export interface TebexCategory {
  id: number;
  name: string;
  slug: string | null;
  parent: TebexCategory | null;
  tiered: boolean;
  active_tier?: any | null;
  description: string;
  packages?: TebexPackage[] | null;
  order: number;
  display_type: 'list' | 'grid';
}

export interface TebexCategoriesResponse {
  data: TebexCategory[];
}

export interface TebexPackagesResponse {
  data: TebexPackage[];
}

export interface TebexPackageResponse {
  data: TebexPackage;
}

const TEBEX_BASE_URL = 'https://headless.tebex.io/api';

// Get all categories (without packages)
export async function getTebexCategories(token: string): Promise<TebexCategoriesResponse> {
  const response = await fetch(`${TEBEX_BASE_URL}/accounts/${token}/categories`, {
    method: 'GET',
    headers: {
      "Accept": "*/*"
    },
    cache: 'no-store'
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch categories: ${response.statusText}`);
  }

  return await response.json();
}

// Get all categories with packages included
export async function getTebexCategoriesWithPackages(token: string): Promise<TebexCategoriesResponse> {
  const response = await fetch(`${TEBEX_BASE_URL}/accounts/${token}/categories?includePackages=1`, {
    method: 'GET',
    headers: {
      "Accept": "*/*"
    },
    cache: 'no-store'
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch categories with packages: ${response.statusText}`);
  }

  return await response.json();
}

// Get specific category by ID (without packages)
export async function getTebexCategory(token: string, categoryId: number): Promise<TebexCategoriesResponse> {
  const response = await fetch(`${TEBEX_BASE_URL}/accounts/${token}/categories/${categoryId}`, {
    method: 'GET',
    headers: {
      "Accept": "*/*"
    },
    cache: 'no-store'
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch category ${categoryId}: ${response.statusText}`);
  }

  return await response.json();
}

// Get specific category by ID with packages included
export async function getTebexCategoryWithPackages(token: string, categoryId: number): Promise<TebexCategoriesResponse> {
  const response = await fetch(`${TEBEX_BASE_URL}/accounts/${token}/categories/${categoryId}?includePackages=1`, {
    method: 'GET',
    headers: {
      "Accept": "*/*"
    },
    cache: 'no-store'
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch category ${categoryId} with packages: ${response.statusText}`);
  }

  return await response.json();
}

// Get all packages
export async function getTebexPackages(token: string): Promise<TebexPackagesResponse> {
  const response = await fetch(`${TEBEX_BASE_URL}/accounts/${token}/packages`, {
    method: 'GET',
    headers: {
      "Accept": "*/*"
    },
    cache: 'no-store'
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch packages: ${response.statusText}`);
  }

  return await response.json();
}

// Get specific package by ID
export async function getTebexPackage(token: string, packageId: number): Promise<TebexPackageResponse> {
  const response = await fetch(`${TEBEX_BASE_URL}/accounts/${token}/packages/${packageId}`, {
    method: 'GET',
    headers: {
      "Accept": "*/*"
    },
    cache: 'no-store'
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch package ${packageId}: ${response.statusText}`);
  }

  return await response.json();
}

// Get packages with authenticated IP address
export async function getTebexPackagesWithIP(token: string, ipAddress: string): Promise<TebexPackagesResponse> {
  const response = await fetch(`${TEBEX_BASE_URL}/accounts/${token}/packages?ipAddress=${encodeURIComponent(ipAddress)}`, {
    method: 'GET',
    headers: {
      "Accept": "*/*"
    },
    cache: 'no-store'
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch packages with IP: ${response.statusText}`);
  }

  return await response.json();
}

// Get packages with authenticated IP address and basket identifier
export async function getTebexPackagesWithIPAndBasket(
  token: string, 
  ipAddress: string, 
  basketIdent: string
): Promise<TebexPackagesResponse> {
  const response = await fetch(
    `${TEBEX_BASE_URL}/accounts/${token}/packages?ipAddress=${encodeURIComponent(ipAddress)}&basketIdent=${encodeURIComponent(basketIdent)}`,
    {
      method: 'GET',
      headers: {
        "Accept": "*/*"
      },
      cache: 'no-store'
    }
  );

  if (!response.ok) {
    throw new Error(`Failed to fetch packages with IP and basket: ${response.statusText}`);
  }

  return await response.json();
}

// Get packages with basket identifier only
export async function getTebexPackagesWithBasket(token: string, basketIdent: string): Promise<TebexPackagesResponse> {
  const response = await fetch(
    `${TEBEX_BASE_URL}/accounts/${token}/packages?basketIdent=${encodeURIComponent(basketIdent)}`,
    {
      method: 'GET',
      headers: {
        "Accept": "*/*"
      },
      cache: 'no-store'
    }
  );

  if (!response.ok) {
    throw new Error(`Failed to fetch packages with basket: ${response.statusText}`);
  }

  return await response.json();
}

// Get tebex public token from .env
export function getPublicTebexToken(): string {
  const token = process.env.TEBEX_PUBLIC_TOKEN;
  if (!token) {
    throw new Error('TEBEX_PUBLIC_TOKEN is not set');
  }
  return token;
}