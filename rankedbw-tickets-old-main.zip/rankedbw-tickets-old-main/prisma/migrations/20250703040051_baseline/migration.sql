-- CreateEnum
CREATE TYPE "TicketStatus" AS ENUM ('ACTIVE', 'ARCHIVED', 'CLOSED');

-- CreateTable
CREATE TABLE "Ticket" (
    "id" SERIAL NOT NULL,
    "threadId" TEXT NOT NULL,
    "creatorId" TEXT NOT NULL,
    "ticketType" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "isLocked" BOOLEAN NOT NULL DEFAULT false,
    "lockRole" TEXT,
    "lockedBy" TEXT,
    "lockTimestamp" TIMESTAMP(3),
    "activeMessageId" TEXT,
    "status" "TicketStatus" NOT NULL DEFAULT 'ACTIVE',
    "closedAt" TIMESTAMP(3),
    "archivedAt" TIMESTAMP(3),
    "manuallyAdded" TEXT[] DEFAULT ARRAY[]::TEXT[],

    CONSTRAINT "Ticket_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Leaderboard" (
    "id" SERIAL NOT NULL,
    "userId" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "ticketsClosed" INTEGER NOT NULL DEFAULT 0,
    "lastClosure" TIMESTAMP(3),

    CONSTRAINT "Leaderboard_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Ticket_threadId_key" ON "Ticket"("threadId");

-- CreateIndex
CREATE INDEX "Ticket_status_idx" ON "Ticket"("status");

-- CreateIndex
CREATE INDEX "Ticket_creatorId_idx" ON "Ticket"("creatorId");

-- CreateIndex
CREATE INDEX "Ticket_threadId_idx" ON "Ticket"("threadId");

-- CreateIndex
CREATE UNIQUE INDEX "Leaderboard_userId_key" ON "Leaderboard"("userId");

-- CreateIndex
CREATE INDEX "Leaderboard_ticketsClosed_idx" ON "Leaderboard"("ticketsClosed");

-- CreateIndex
CREATE INDEX "Leaderboard_userId_idx" ON "Leaderboard"("userId");
