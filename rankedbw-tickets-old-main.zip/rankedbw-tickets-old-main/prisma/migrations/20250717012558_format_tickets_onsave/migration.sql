-- AlterTable
ALTER TABLE "Leaderboard" ADD COLUMN     "ticketsClaimed" INTEGER NOT NULL DEFAULT 0;
