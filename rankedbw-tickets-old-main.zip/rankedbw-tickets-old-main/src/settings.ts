export default {
    guild: '1020646109992992828',
    channels: {
        support: '1382406554501906576',
        ticketLogs: '1382406640262975508',
        activeTickets: '1387845861018697838'
    },
    roles: {
        helper: '1382406419487129620',
        moderator: '1383922684353843351',
        seniorModerator: '1384636930364280923',
        developer: '1382406418203807835',
        administrator: '1383922459841134662',
        owner: '1383578911933202586',
        staff: '1382406422322741278',
        ticketBanned: '1382406474323726409',
    },
}
