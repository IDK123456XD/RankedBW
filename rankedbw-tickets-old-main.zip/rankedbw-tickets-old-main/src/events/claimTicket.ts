import { Interaction, ClientEvents, Events, Message, ThreadChannel, ButtonBuilder, ButtonStyle, ActionRowBuilder } from 'discord.js';
import settings from '../settings';
import embeds from '../utils/discord/embeds';
import ticketStorage from '../utils/ticketStorage';
import TicketLockCommand, { ROLE_HIERARCHY } from '../commands/ticket/lock';
import Event from '.';
import leaderboardStorage from '../utils/leaderboardStorage';

export default class ClaimTicketHandler extends Event {
    eventNames: (keyof ClientEvents)[] = [Events.InteractionCreate];

    async handle(interaction: Interaction) {
        if (!interaction.isButton() || interaction.customId !== 'claim_ticket') return;

        try {
            // Check if user has staff permissions
            const member = await interaction.guild?.members.fetch(interaction.user.id);
            if (!member?.roles.cache.has(settings.roles.staff)) {
                return interaction.reply({
                    embeds: [embeds.error('You must be a staff member to claim tickets.', ``, false)],
                    ephemeral: true
                });
            }

            // Get the thread from the channel this interaction is in
            const thread = interaction.channel;
            if (!thread || !(thread instanceof ThreadChannel)) {
                return interaction.reply({
                    embeds: [embeds.error('This command can only be used in ticket threads.', ``, false)],
                    ephemeral: true
                });
            }

            // Check if ticket is locked using the new storage system
            const canAccess = await TicketLockCommand.canAccessLockedTicket(member.roles.cache, thread.id, interaction.user.id);
            if (!canAccess) {
                const lockInfo = await ticketStorage.getTicketLockInfo(thread.id);
                // Find the role name for the error message
                const roleData = ROLE_HIERARCHY?.find((role: any) => role.key === lockInfo?.role);
                const roleName = roleData ? `<@&${roleData.id}>` : (lockInfo?.role || 'Unknown');

                return interaction.reply({
                    embeds: [embeds.error(`This ticket is locked to ${roleName} and above. You don't have permission to claim it.`, ``, false)],
                    ephemeral: true
                });
            }

            await interaction.deferReply();

            // Add the user to the ticket storage (this serves as claiming)
            const ticketData = await ticketStorage.getTicket(thread.id);
            await ticketStorage.addUserToTicket(thread.id, interaction.user.id);

            const ticketRequestChannel = await interaction.guild.channels.fetch(settings.channels.activeTickets);
            if (ticketRequestChannel?.isTextBased()) {
                const ticketMessage = await ticketRequestChannel.messages.fetch(ticketData.activeMessageId);
                if (ticketMessage) {
                    const staffEmbed = embeds.normal(
                        `Press the button below to join this ticket.\n\n` +
                        `**User**\n<@${ticketData.creatorId}>\n` +
                        `**Type**\n${ticketData.ticketType.charAt(0).toUpperCase() + ticketData.ticketType.slice(1)}\n` +
                        `**Level**\n<@&${settings.roles.staff}>\n` +
                        `**Claimed by**\n${interaction.user.toString()}`,
                        'Join Ticket',
                        false
                      );
                
                      const actionButtons = new ActionRowBuilder<ButtonBuilder>()
                        .addComponents(
                          new ButtonBuilder()
                            .setCustomId(`join_ticket_${thread.id}`)
                            .setLabel('Join Ticket')
                            .setEmoji('👥')
                            .setStyle(ButtonStyle.Primary)
                        );
                
                    await ticketMessage.edit({
                        embeds: [staffEmbed],
                        components: [actionButtons]
                    });
                }
            }

            await leaderboardStorage.recordTicketClaim(
                interaction.user.id,
                interaction.user.displayName || interaction.user.username
            );

            await interaction.editReply({
                content: `${interaction.user}`,
                embeds: [embeds.normal(
                    `<@${interaction.user.id}> has claimed this ticket.`,
                    undefined,
                    false
                )]
            });
        } catch (error) {
            console.error('Error claiming ticket:', error);
            await interaction.reply({
                embeds: [embeds.error('Failed to claim the ticket. Please try again or contact an administrator.', ``, false)],
                ephemeral: true
            });
        }
    }
}