import { Interaction, Events, ClientEvents } from 'discord.js';
import settings from '../settings';
import embeds from '../utils/discord/embeds';
import ticketStorage from '../utils/ticketStorage';
import TicketLockCommand, { ROLE_HIERARCHY } from '../commands/ticket/lock';
import Event from '.';

export default class JoinTicketHandler extends Event {
    eventNames: (keyof ClientEvents)[] = [Events.InteractionCreate];

    async handle(interaction: Interaction) {
        if (!interaction.isButton() || !interaction.customId.startsWith('join_ticket_')) return;

        // Extract thread ID from button custom ID
        const threadId = interaction.customId.replace('join_ticket_', '');

        try {
            // Fetch the thread
            const thread = await interaction.guild.channels.fetch(threadId);

            if (!thread || !thread.isThread()) {
                return interaction.reply({
                    embeds: [embeds.error('This ticket thread no longer exists or is invalid.', ``, false)],
                    ephemeral: true
                });
            }

            // Check if user has staff permissions
            const member = await interaction.guild?.members.fetch(interaction.user.id);
            if (!member?.roles.cache.has(settings.roles.staff)) {
                return interaction.reply({
                    embeds: [embeds.error('You must be a staff member to join tickets.', ``, false)],
                    ephemeral: true
                });
            }

            // Check if ticket is locked using the new storage system
            const canAccess = await TicketLockCommand.canAccessLockedTicket(member.roles.cache, thread.id, interaction.user.id);
            if (!canAccess) {
                const lockInfo = await ticketStorage.getTicketLockInfo(thread.id);
                // Find the role name for the error message
                const roleData = ROLE_HIERARCHY?.find((role: any) => role.key === lockInfo?.role);
                const roleName = roleData ? `<@&${roleData.id}>` : (lockInfo?.role || 'Unknown');

                return interaction.reply({
                    embeds: [embeds.error(`This ticket is locked to ${roleName} and above. You don't have permission to join.`, ``, false)],
                    ephemeral: true
                });
            }

            // Add the user to the ticket storage as manually added
            await ticketStorage.addUserToTicket(thread.id, interaction.user.id);

            // Send a notification in the thread with staff member ping
            const joinMessage = await thread.send({
                content: `${interaction.user}`,
                embeds: [embeds.normal(
                    `A staff member has joined this ticket to assist you.`,
                    'Staff Member Joined',
                    false
                )]
            });

            setTimeout(async () => {
                await joinMessage.delete();
            }, 3000);

            // Reply to the button click
            await interaction.reply({
                embeds: [embeds.success(`You have successfully joined the ticket: ${thread}`, ``, false)],
                ephemeral: true
            });
        } catch (error) {
            console.error('Error joining ticket:', error);
            await interaction.reply({
                embeds: [embeds.error('Failed to join the ticket. Please try again or contact an administrator.', ``, false)],
                ephemeral: true
            });
        }
    }
}