import { ChatInputCommandInteraction, ClientEvents, Events, Interaction } from 'discord.js';
import Event from '.';
import App from '..';
import { ChildCommand, Command, ParentCommand } from '../commands';
import settings from '../settings';
import embeds from '../utils/discord/embeds';
import Logger from '../utils/logger';

export default class InteractionHandler extends Event {
  eventNames: (keyof ClientEvents)[] = [Events.InteractionCreate];
  
  async handle(interaction: Interaction) {
    // Handle command interactions
    if (!interaction.isChatInputCommand()) return;

    const command = getCommand(interaction);
    if (!command) return;

    // * All commands are guild only
    if (!interaction.guild || interaction.guildId !== settings.guild) {
      await interaction.reply({ embeds: [embeds.error('You can only run commands in the Ranked Bedwars discord server!')] });
      return;
    }

    // * Check if command is disabled
    if (command.maintenance) {
      await interaction.reply({
        embeds: [embeds.error(`**${command.slashCommand.name}** is currently under maintenance!`)],
        ephemeral: true,
      });
      return;
    }

    // * Check if user can use command
    const canRunCommand = await command.canRun(interaction);
    if (!canRunCommand) {
      if (!interaction.replied) {
        await interaction.reply({
          embeds: [embeds.error(`You don't have permission to use **${command.slashCommand.name}**!`)],
          ephemeral: true,
        });
      } else return;
    }

    await command.execute(interaction)
      .catch((e) => Logger.error('COMMAND_HANDLER', e));
  }
}

function getCommand(interaction: ChatInputCommandInteraction) {
  const subCommandName = interaction.options.getSubcommand(false);
  const { commandName } = interaction;

  let command: Command | ChildCommand;
  if (subCommandName) {
    const parentCommands = App.commands
      .filter((x) => x instanceof ParentCommand
        && x.childCommands.length > 0) as ParentCommand[];

    const parentCommand = parentCommands.find((x) => x.slashCommand.name === commandName
      && x.childCommands
        .find((y) => y.slashCommand.name === subCommandName)) as ParentCommand;
    if (!parentCommand) return;

    command = parentCommand.childCommands.find((x) => x.slashCommand.name === subCommandName);
  } else {
    command = App.commands
      .filter((x) => x instanceof Command)
      .find((x) => x.slashCommand.name === commandName) as Command;
  }

  return command;
}