import { ClientEvents, Events, Interaction, Message, PermissionFlagsBits, ThreadChannel } from 'discord.js';
import settings from '../settings';
import embeds from '../utils/discord/embeds';
import ticketStorage from '../utils/ticketStorage';
import leaderboardStorage from '../utils/leaderboardStorage';
import { createTranscript } from 'discord-html-transcripts';
import Event from '.';

export default class CloseTicketHandler extends Event {
    eventNames: (keyof ClientEvents)[] = [Events.InteractionCreate];

    async handle(interaction: Interaction) {
        if (!interaction.isButton() || interaction.customId !== 'close_ticket') return;

        try {
            // Get the thread from the channel this interaction is in
            const thread = interaction.channel;
            if (!thread || !(thread instanceof ThreadChannel)) {
                return interaction.reply({
                    embeds: [embeds.error('This command can only be used in ticket threads.', ``, false)],
                    ephemeral: true
                });
            }

            await interaction.deferReply();

            // Check if user has permission to close tickets
            const member = await interaction.guild?.members.fetch(interaction.user.id);
            const ticketData = await ticketStorage.getTicket(thread.id);

            const isCreator = ticketData?.creatorId === interaction.user.id;
            const isStaff = member?.roles.cache.has(settings.roles.staff);
            const hasAdminPerms = member?.permissions.has(PermissionFlagsBits.Administrator);

            if (!isCreator && !isStaff && !hasAdminPerms) {
                return interaction.editReply({
                    embeds: [embeds.error('You can only close tickets that you created, or you must be a staff member.', ``, false)],
                });
            }

            if (!ticketData) {
                return interaction.editReply({
                    embeds: [embeds.error('This ticket is not found in the database.', ``, false)],
                });
            }

            // Check if ticket is already closed
            if (ticketData.status === 'closed') {
                return interaction.editReply({
                    embeds: [embeds.warning('This ticket is already closed.', ``, false)],
                });
            }

            // Generate HTML transcript
            const ticketCreator = await interaction.guild?.members.fetch(ticketData.creatorId);

            const transcript = await createTranscript(interaction.channel, {
                limit: -1, // Get all messages
                filename: `ticket_${ticketCreator.user.username}.html`,
                saveImages: true,
                poweredBy: false,
                footerText: `Ticket closed by ${interaction.user.tag} | ${new Date().toLocaleString()}`
            });

            // Get the ticket logs channel
            const ticketLogsChannel = await interaction.guild?.channels.fetch(settings.channels.ticketLogs);
            
            // Send transcript to ticket logs channel
            let ticketLogMessage: Message;
            if (ticketLogsChannel?.isTextBased()) {
                ticketLogMessage = await ticketLogsChannel.send({
                    embeds: [embeds.normal(
                        `**Ticket:** <#${interaction.channel.id}>\n` +
                        `**Closed by:** ${interaction.user} (${interaction.user.tag})\n` +
                        `**Reason:** None\n` +
                        `**Closed at:** <t:${Math.floor(Date.now() / 1000)}:F>`,
                        'Ticket Closed - Transcript'
                    )],
                    files: [transcript]
                });
            }

            // Send closing message in the ticket (without attachment)
            await interaction.editReply({
                embeds: [embeds.normal(
                    `🔒 This ticket has been closed by ${interaction.user}.`,
                    '',
                    false
                )]
            });

            // Store thread reference for deletion
            const threadToDelete = interaction.channel;

            // Delete the thread after 10 seconds
            setTimeout(async () => {
                if (threadToDelete?.isThread()) {
                    // Try to delete the thread directly
                    await threadToDelete.setArchived(true, 'Ticket closed by staff');
                    console.log(`Successfully deleted ticket thread: ${threadToDelete.id}`);
                }
            }, 10000);

            // Send DM to ticket creator
            if (ticketCreator) {
                // Extract ticket type from thread name (format: @username: TicketType)
                const ticketTypeMatch = interaction.channel.name.match(/@[^:]+:\s*(.+?)(?:\s*\[LOCKED|$)/);
                const ticketType = ticketTypeMatch ? ticketTypeMatch[1] : 'General';
                
                const dmEmbed = embeds.normal(
                    interaction.channel.toString(),
                    'Ticket Closed',
                    false
                ).addFields([
                    {
                        name: 'Type',
                        value: ticketType,
                        inline: true
                    },
                    {
                        name: 'Reason',
                        value: 'None',
                        inline: true
                    },
                    {
                        name: 'Transcript',
                        value: ticketLogMessage?.attachments.first()?.url,
                        inline: false
                    }
                ])

                await ticketCreator.send({
                    embeds: [dmEmbed],
                }).catch(() => {
                    // Do nothing
                });
            }

            // Lock the thread immediately
            if (interaction.channel?.isThread()) {
                // Lock the thread (prevent new messages)
                await interaction.channel.setLocked(true)
            }

            // Mark ticket as closed in storage (preserves data for records)
            await ticketStorage.closeTicket(interaction.channel.id);

            // Record the ticket closure in the leaderboard
            await leaderboardStorage.recordTicketClosure(
                interaction.user.id,
                interaction.user.displayName || interaction.user.username
            );

            const ticketRequestChannel = await interaction.guild.channels.fetch(settings.channels.activeTickets);
            if (ticketRequestChannel?.isTextBased()) {
                const ticketMessage = await ticketRequestChannel.messages.fetch(ticketData.activeMessageId);
                if (ticketMessage?.deletable) {
                    await ticketMessage.delete();
                }
            }

            await interaction.editReply({
                embeds: [embeds.success(`This ticket has been successfully closed.`, ``, false)],
            });
        } catch (error) {
            console.error('Error closing ticket:', error);
            await interaction.editReply({
                embeds: [embeds.error('Failed to close the ticket. Please try again or contact an administrator.', ``, false)],
            });
        }
    }
}
