import { TextChannel, ChannelType, ThreadAutoArchiveDuration, ButtonStyle, ButtonBuilder, ActionRowBuilder, Interaction, Events, ClientEvents } from 'discord.js';
import settings from '../settings';
import embeds from '../utils/discord/embeds';
import ticketStorage from '../utils/ticketStorage';
import Event from '.';

export default class OpenTicketHandler extends Event {
  eventNames: (keyof ClientEvents)[] = [Events.InteractionCreate];

  async handle(interaction: Interaction) {
    if (!interaction.isButton() && !interaction.isStringSelectMenu()) return;
    if (interaction.isButton() && !interaction.customId.startsWith('support_')) return;
    if (interaction.isStringSelectMenu() && interaction.customId !== 'ticket_type_select') return;

    const ticketType = interaction.isStringSelectMenu() ? interaction.values[0] : interaction.customId.replace('support_', '');

    try {
      await interaction.deferReply({ ephemeral: true });

      // Check if user is ticket banned
      const member = await interaction.guild?.members.fetch(interaction.user.id);
      if (member?.roles.cache.has(settings.roles.ticketBanned)) {
        return interaction.editReply({
          embeds: [embeds.error('You are currently banned from creating tickets. Please contact an administrator if you believe this is an error.')],
        });
      }

      // Get support channel
      const supportChannel = await interaction.guild.channels.fetch(settings.channels.support);
      if (!supportChannel || !(supportChannel instanceof TextChannel)) {
        return interaction.editReply({
          embeds: [embeds.error('Support channel not found.')],
        });
      }

      // Check for existing tickets by this user
      const existingTickets = supportChannel.threads?.cache.filter((thread) =>
        thread.name.includes(interaction.user.username) && !thread.archived
      );

      if (existingTickets && existingTickets.size >= 3) {
        return interaction.editReply({
          embeds: [embeds.error('You already have 3 open tickets. Please close one of your existing tickets before creating a new one.')],
        });
      }

      // Create the ticket thread
      const formattedTicketType = ticketType.charAt(0).toUpperCase() + ticketType.slice(1);
      const ticketName = `@${interaction.user.username}: ${formattedTicketType}`;
      const thread = await supportChannel.threads.create({
        name: ticketName,
        type: ChannelType.PrivateThread,
        autoArchiveDuration: ThreadAutoArchiveDuration.OneWeek,
        invitable: false,
        reason: `Ticket created by ${interaction.user.tag} for ${ticketType} support`
      });

      // Get emoji for ticket type
      const typeEmojis: { [key: string]: string } = {
        'general': '🖥️',
        'report': '👤',
        'appeals': '⚖️',
        'scoring': '🎯',
        'store': '🛒'
      };

      // Send initial message in the ticket
      await thread.send({
        content: `${interaction.user}`,
        embeds: [embeds.normal(
          `Thank you for opening a ticket.\nLet us know how we can help you and we'll get back to you right away.`,
          'Support',
          false
        )],
        components: [
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder()
              .setCustomId(`close_ticket`)
              .setLabel('Close Ticket')
              .setEmoji('🔒')
              .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
              .setCustomId(`claim_ticket`)
              .setLabel('Claim Ticket')
              .setEmoji('👤')
              .setStyle(ButtonStyle.Primary)
          )
        ]
      });

      // Send ticket type specific message
      const ticketTypeMessages: { [key: string]: string } = {
        'general': `Thank you for opening a general ticket with Ranked Bedwars. Please make sure you have read the FAQ as your question may have already been answered there. If you still have any questions, feel free to write it here and we will get back to you soon!`,
        'report': `Thank you for opening a report ticket with Ranked Bedwars. Please provide detailed information about the player you're reporting, including their username, what they did, and any evidence you have. We will investigate this matter promptly.`,
        'appeals': `Thank you for opening an appeals ticket with Ranked Bedwars. Please explain why you believe your punishment was incorrect and provide any relevant evidence. Our staff will review your appeal carefully.`,
        'scoring': `Thank you for opening a scoring dispute ticket with Ranked Bedwars. Please provide details about the game in question, including the game ID if available, and explain what went wrong with the scoring. We will investigate this issue.`,
        'store': `Thank you for opening a store ticket with Ranked Bedwars. Please provide details about your purchase issue, including transaction IDs, payment method, and what problems you're experiencing. We will resolve this as quickly as possible.`
      };

      await thread.send({
        content: `# ${typeEmojis[ticketType] || '🎫'} ${ticketType.charAt(0).toUpperCase() + ticketType.slice(1)} Ticket\n${ticketTypeMessages[ticketType]}`,
      });

      const activeTickets = await interaction.guild.channels.fetch(settings.channels.activeTickets);
      if (!activeTickets || !activeTickets.isTextBased()) {
        return interaction.editReply({
          embeds: [embeds.error('Staff tickets channel not found.', ``, false)],
        });
      }

      const staffEmbed = embeds.normal(
        `Press the button below to join this ticket.\n\n` +
        `**User**\n${interaction.user} (${interaction.user.tag})\n` +
        `**Type**\n${ticketType.charAt(0).toUpperCase() + ticketType.slice(1)}\n` +
        `**Level**\n<@&${settings.roles.staff}>`,
        'Join Ticket',
        false
      );

      const actionButtons = new ActionRowBuilder<ButtonBuilder>()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`join_ticket_${thread.id}`)
            .setLabel('Join Ticket')
            .setEmoji('👥')
            .setStyle(ButtonStyle.Primary)
        );

      const staffMessage = await activeTickets.send({
        embeds: [staffEmbed],
        components: [actionButtons]
      });

      // Create ticket data in storage
      await ticketStorage.createTicket(thread.id, interaction.user.id, ticketType, staffMessage.id);

      await interaction.editReply({
        embeds: [embeds.success(`Your ${ticketType} support ticket has been created! Check ${thread}.`, ``, false)],
      });
    } catch (error) {
      console.error('Error creating ticket:', error);
      await interaction.editReply({
        embeds: [embeds.error('Failed to create ticket. Please try again or contact an administrator.', ``, false)],
      });
    }
  }
}