import { ChatInputCommandInteraction, SlashCommandBuilder, TextChannel } from "discord.js";
import { Command } from ".";
import settings from "../settings";
import prisma from "../utils/database";

export default class ResetTicketsCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName("resettickets")
        .setDescription("Refresh all tickets that weren't archived.");

    requiredRoles: string[] = [settings.roles.developer];

    async execute(interaction: ChatInputCommandInteraction) {
        const supportChannel = await interaction.guild.channels.fetch(settings.channels.support);
        if (!supportChannel || !(supportChannel instanceof TextChannel)) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> Support channel not found.`,
            });
            return;
        }

        const threads = await supportChannel.threads.fetchActive();
        for (const thread of threads.threads.values()) {
            if (thread.archived) {
                console.log(`Ticket ${thread.id} is archived, skipping.`);
                continue;
            }

            const dbExists = await prisma.ticket.findUnique({
                where: {
                    threadId: thread.id,
                },
            });

            if (dbExists && dbExists.status === 'ACTIVE') {
                console.log(`Ticket ${thread.id} is already active, skipping.`);
                continue;
            }

            await thread.setArchived(true, 'Ticket reset by developer.');
            console.log(`Ticket ${thread.id} has been reset.`);
        }
    }
}
