import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '.';
import embeds from '../utils/discord/embeds';
import settings from '../settings';

export default class SupportCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('support')
        .setDescription('Generate the support panel with categories and buttons.')

    requiredRoles = [
        settings.roles.owner,
        settings.roles.administrator,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        // Create the support embed
        const supportEmbed = embeds.normal(
            '🖥️ **General** → Ask a question and get help\n' +
            '👤 **Report** → Report a player for a violation\n' +
            '⚖️ **Appeals** → Appeal a strike, mute, or ban\n' +
            '🎯 **Scoring** → Dispute the outcome of a Ranked game\n\n' +
            '🛒 **Store** → For store-related or payment issues',
            'Support', false
        );

        // Create action buttons
        const row = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('support_general')
                    .setEmoji('🖥️')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('support_report')
                    .setEmoji('👤')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('support_appeals')
                    .setEmoji('⚖️')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('support_scoring')
                    .setEmoji('🎯')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('support_store')
                    .setEmoji('🛒')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.channel.send({
            embeds: [supportEmbed],
            components: [row]
        });

        await interaction.reply({
            embeds: [
                embeds.success(
                    'Successfully generated the support panel.'
                ),
            ],
            ephemeral: true,
        });
    }
} 