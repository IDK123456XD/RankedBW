import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder, EmbedBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import leaderboardStorage from '../../utils/leaderboardStorage';

export default class TicketLeaderboardCommand extends ChildCommand {
    requiredRoles = [
        settings.roles.staff
    ];

    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('leaderboard')
        .setDescription('View the ticket closure leaderboard for staff members')
        .addIntegerOption(option =>
            option.setName('limit')
                .setDescription('Number of top staff to display (default: 10, max: 25)')
                .setMinValue(1)
                .setMaxValue(25)
                .setRequired(false)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        try {
            const limit = interaction.options.getInteger('limit') || 10;
            const leaderboard = await leaderboardStorage.getLeaderboard();
            const totalTickets = await leaderboardStorage.getTotalTicketsClosed();

            if (leaderboard.length === 0) {
                return interaction.reply({
                    embeds: [embeds.error('No ticket closure data found yet.')],
                    ephemeral: true
                });
            }

            // Get top entries based on limit
            const topEntries = leaderboard.slice(0, limit);
            
            // Build the leaderboard description
            let description = `**📊 Total Tickets Closed: ${totalTickets}**\n\n`;

            for (let i = 0; i < topEntries.length; i++) {
                const entry = topEntries[i];
                const position = i + 1;
                
                // Add rank emojis for top 3
                let rankEmoji = '';
                if (position === 1) rankEmoji = '🥇';
                else if (position === 2) rankEmoji = '🥈';
                else if (position === 3) rankEmoji = '🥉';
                else rankEmoji = '📍';

                // Try to fetch the user from Discord to get their current username
                let displayName = entry.username;
                try {
                    const user = await interaction.client.users.fetch(entry.userId);
                    displayName = user.displayName || user.username;
                } catch {
                    // If user can't be fetched, use stored username
                    displayName = entry.username;
                }

                // Calculate percentage of total tickets
                const percentage = totalTickets > 0 ? ((entry.ticketsClosed / totalTickets) * 100).toFixed(1) : '0.0';

                description += `${rankEmoji} **#${position}** • **${displayName}**\n`;
                description += `   🎫 ${entry.ticketsClosed} tickets (${percentage}%)\n`;
                
                if (entry.lastClosure) {
                    description += `   🕒 Last closure: <t:${Math.floor(entry.lastClosure / 1000)}:R>\n`;
                }
                description += '\n';
            }

            // Show user's own stats if they're not in the top list
            const userStats = await leaderboardStorage.getUserStats(interaction.user.id);
            if (userStats && !topEntries.some(entry => entry.userId === interaction.user.id)) {
                const userRank = leaderboard.findIndex(entry => entry.userId === interaction.user.id) + 1;
                description += `**📍 Your Stats:**\n`;
                description += `#${userRank} • ${userStats.ticketsClosed} tickets closed\n`;
                if (userStats.lastClosure) {
                    description += `Last closure: <t:${Math.floor(userStats.lastClosure / 1000)}:R>\n`;
                }
            }

            const embed = new EmbedBuilder()
                .setTitle('🏆 Ticket Closure Leaderboard')
                .setDescription(description)
                .setColor(0x5865F2)
                .setTimestamp()
                .setFooter({ 
                    text: `Showing top ${Math.min(limit, leaderboard.length)} staff members`,
                    iconURL: interaction.guild?.iconURL() || undefined
                });

            await interaction.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error displaying leaderboard:', error);
            await interaction.reply({
                embeds: [embeds.error('Failed to display the leaderboard.')],
                ephemeral: true
            });
        }
    }
} 