import { SlashCommandBuilder } from 'discord.js';
import { ParentCommand, ChildCommand } from '..';
import TicketAddCommand from './add';
import TicketCloseCommand from './close';
import TicketCreateCommand from './create';
import TicketLeaderboardCommand from './leaderboard';
import TicketLockCommand from './lock';
import TicketRemoveCommand from './remove';
import TicketRenameCommand from './rename';
import TicketStatsCommand from './stats';

export default class TicketCommand extends ParentCommand {
    childCommands: ChildCommand[] = [
        new TicketAddCommand(),
        new TicketCloseCommand(),
        new TicketCreateCommand(),
        new TicketLeaderboardCommand(),
        new TicketLockCommand(),
        new TicketRemoveCommand(),
        new TicketRenameCommand(),
        new TicketStatsCommand()
    ];

    slashCommand = new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Ticket management commands');
}