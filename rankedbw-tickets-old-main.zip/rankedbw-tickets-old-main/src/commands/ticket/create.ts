import { 
    ActionRowBuilder, 
    ChatInputCommandInteraction, 
    SlashCommandSubcommandBuilder, 
    StringSelectMenuBuilder, 
    StringSelectMenuOptionBuilder,
} from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';

export default class TicketCreateCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('create')
        .setDescription('Create a new support ticket');

    async execute(interaction: ChatInputCommandInteraction) {
        // Check if user is ticket banned
        const member = await interaction.guild?.members.fetch(interaction.user.id);
        if (member?.roles.cache.has(settings.roles.ticketBanned)) {
            return interaction.reply({
                embeds: [embeds.error('You are currently banned from creating tickets. Please contact an administrator if you believe this is an error.')],
                ephemeral: true
            });
        }

        // Check if user already has an open ticket
        const supportChannel = await interaction.guild.channels.fetch(settings.channels.support);
        if (!supportChannel || !supportChannel.isTextBased()) {
            return interaction.reply({
                embeds: [embeds.error('Support channel not found.')],
                ephemeral: true
            });
        }

        // Check for existing tickets by this user
        const existingTickets = (supportChannel as any).threads?.cache.filter((thread: any) => 
            thread.name.includes(interaction.user.username) && !thread.archived
        );

        if (existingTickets && existingTickets.size >= 3) {
            return interaction.reply({
                embeds: [embeds.error('You already have 3 open tickets. Please close one of your existing tickets before creating a new one.')],
                ephemeral: true
            });
        }

        // Create ticket type selection menu
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('ticket_type_select')
            .setPlaceholder('Select the type of support you need')
            .addOptions(
                new StringSelectMenuOptionBuilder()
                    .setLabel('General')
                    .setDescription('Ask a question and get help')
                    .setValue('general')
                    .setEmoji('🖥️'),
                new StringSelectMenuOptionBuilder()
                    .setLabel('Report')
                    .setDescription('Report a player for a violation')
                    .setValue('report')
                    .setEmoji('👤'),
                new StringSelectMenuOptionBuilder()
                    .setLabel('Appeals')
                    .setDescription('Appeal a strike, mute, or ban')
                    .setValue('appeals')
                    .setEmoji('⚖️'),
                new StringSelectMenuOptionBuilder()
                    .setLabel('Scoring')
                    .setDescription('Dispute the outcome of a Ranked game')
                    .setValue('scoring')
                    .setEmoji('🎯'),
                new StringSelectMenuOptionBuilder()
                    .setLabel('Store')
                    .setDescription('For store-related or payment issues')
                    .setValue('store')
                    .setEmoji('🛒')
            );

        const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(selectMenu);

        await interaction.reply({
            embeds: [embeds.normal('Please select the type of support you need:', 'Create Ticket', false)],
            components: [row],
            ephemeral: true
        });
    }
} 