import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import ticketStorage from '../../utils/ticketStorage';

export default class TicketAddCommand extends ChildCommand {
    requiredRoles = [
        settings.roles.staff
    ];

    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Add a member to the current ticket')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to add to the ticket')
                .setRequired(true)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const user = interaction.options.getUser('user', true);
        
        // Check if this is a ticket thread
        if (!interaction.channel?.isThread()) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in ticket threads.', '', false)],
                ephemeral: true
            });
        }

        // Check if this is a support ticket (in the support channel)
        if (interaction.channel.parentId !== settings.channels.support) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in support tickets.', '', false)],
                ephemeral: true
            });
        }

        try {
            // Add the user to the manually added list in ticket storage
            await ticketStorage.addUserToTicket(interaction.channel.id, user.id);

            // Send a message pinging the user and adding them to the thread
            await interaction.reply({
                content: `${user}`,
                embeds: [embeds.normal(`${user} has been added to this ticket by ${interaction.user}.`, 'User Added', false)]
            });

        } catch (error) {
            console.error('Error adding user to ticket:', error);
            await interaction.reply({
                embeds: [embeds.error('Failed to add user to the ticket. Please try again or contact an administrator.', '', false)],
                ephemeral: true
            });
        }
    }
} 