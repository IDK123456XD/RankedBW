import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import ticketStorage from '../../utils/ticketStorage';

export default class TicketRemoveCommand extends ChildCommand {
    requiredRoles = [
        settings.roles.staff
    ];

    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Remove a member from the current ticket')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to remove from the ticket')
                .setRequired(true)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const user = interaction.options.getUser('user', true);
        
        // Check if this is a ticket thread
        if (!interaction.channel?.isThread()) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in ticket threads.', '', false)],
                ephemeral: true
            });
        }

        // Check if this is a support ticket (in the support channel)
        if (interaction.channel.parentId !== settings.channels.support) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in support tickets.', '', false)],
                ephemeral: true
            });
        }

        // Prevent removing the ticket creator
        if (user.id === interaction.channel.ownerId) {
            return interaction.reply({
                embeds: [embeds.error('You cannot remove the ticket creator from their own ticket.', '', false)],
                ephemeral: true
            });
        }

        // Prevent removing yourself if you're the only staff member
        if (user.id === interaction.user.id) {
            return interaction.reply({
                embeds: [embeds.error('You cannot remove yourself from the ticket.', '', false)],
                ephemeral: true
            });
        }

        try {
            // Check if the user is actually in the thread
            const threadMembers = await interaction.channel.members.fetch();
            if (!threadMembers.has(user.id)) {
                return interaction.reply({
                    embeds: [embeds.warning('That user is not in this ticket thread.', '', false)],
                    ephemeral: true
                });
            }

            // Remove the user from the manually added list in ticket storage
            await ticketStorage.removeUserFromTicket(interaction.channel.id, user.id);

            // Remove the user from the thread
            await interaction.channel.members.remove(user.id);
            
            // Send a message in the ticket about the removal
            await interaction.reply({
                embeds: [embeds.normal(
                    `${user} has been removed from this ticket by ${interaction.user}.`, 
                    'Member Removed',
                    false
                )]
            });

        } catch (error) {
            console.error('Error removing user from ticket:', error);
            await interaction.reply({
                embeds: [embeds.error('Failed to remove user from the ticket. They may not be in the ticket or there was an error.', '', false)],
                ephemeral: true
            });
        }
    }
} 