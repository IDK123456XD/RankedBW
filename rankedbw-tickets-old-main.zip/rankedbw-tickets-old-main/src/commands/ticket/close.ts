import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder, MessageFlags, Message } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import ticketStorage from '../../utils/ticketStorage';
import leaderboardStorage from '../../utils/leaderboardStorage';
import { createTranscript } from 'discord-html-transcripts';

export default class TicketCloseCommand extends ChildCommand {
    requiredRoles = [
        settings.roles.staff
    ];

    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('close')
        .setDescription('Close the current ticket and create a message log')
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for closing the ticket')
                .setRequired(false)
        );

    async canRun(interaction: ChatInputCommandInteraction) {
        // Allow staff members to close any ticket
        if (this.requiredRoles.length > 0) {
            const member = await interaction.guild.members.fetch(interaction.user.id);
            if (!member) return false;

            if (this.requiredRoles.some((x) => member.roles.cache.has(x))) return true;
        }

        // Allow the ticket creator to close their own ticket
        if (interaction.channel?.isThread()) {
            if (interaction.channel.ownerId === interaction.user.id) {
                return true;
            }
        }

        // If neither staff nor ticket creator, show error
        await interaction.reply({
            embeds: [
                embeds.error(
                    `You must have one of the following roles to run this command:\n${this.requiredRoles.map((x) => `- <@&${x}>`).join('\n')}\n\nOr be the creator of this ticket.`
                )
            ],
            flags: [MessageFlags.Ephemeral]
        });

        return false;
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const reason = interaction.options.getString('reason') || 'None';

        // Check if this is a ticket thread
        if (!interaction.channel?.isThread()) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in ticket threads.')],
                ephemeral: true
            });
        }

        // Check if this is a support ticket (in the support channel)
        if (interaction.channel.parentId !== settings.channels.support) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in support tickets.')],
                ephemeral: true
            });
        }

        try {
            const ticketData = await ticketStorage.getTicket(interaction.channel.id);

            if (!ticketData) {
                await interaction.reply({
                    embeds: [embeds.error('This thread has been archived, but no ticket data was found.')],
                    ephemeral: true
                });

                if (interaction.channel.isThread() && !interaction.channel.archived) {
                    await interaction.channel.setArchived(true, 'Ticket closed by staff').catch(() => {
                        console.log(`Failed to archive ticket thread 1: ${interaction.channel.id}`);
                    });
                    console.log(`Successfully archived ticket thread: ${interaction.channel.id}`);
                }

                return;
            }

            const ticketCreator = await interaction.guild?.members.fetch(interaction.channel.ownerId!);

            const transcript = await createTranscript(interaction.channel, {
                limit: -1,
                filename: `ticket_${ticketCreator.user.username}.html`,
                saveImages: true,
                poweredBy: false,
                footerText: `Ticket closed by ${interaction.user.tag} | ${new Date().toLocaleString()}`
            });

            const ticketLogsChannel = await interaction.guild?.channels.fetch(settings.channels.ticketLogs);

            let ticketLogMessage: Message;
            if (ticketLogsChannel?.isTextBased()) {
                ticketLogMessage = await ticketLogsChannel.send({
                    embeds: [embeds.normal(
                        `**Ticket:** <#${interaction.channel.id}>\n` +
                        `**Closed by:** ${interaction.user} (${interaction.user.tag})\n` +
                        `**Reason:** ${reason}\n` +
                        `**Closed at:** <t:${Math.floor(Date.now() / 1000)}:F>`,
                        'Ticket Closed - Transcript'
                    )],
                    files: [transcript]
                });
            }

            await interaction.reply({
                embeds: [embeds.normal(
                    `🔒 This ticket has been closed by ${interaction.user}.`,
                    '',
                    false
                )]
            });

            const activeTicketsChannel = await interaction.guild.channels.fetch(settings.channels.activeTickets);
            if (activeTicketsChannel?.isTextBased()) {
                const ticketMessage = await activeTicketsChannel.messages.fetch(ticketData.activeMessageId);
                await ticketMessage.delete().catch(() => {
                    // Do nothing
                });
            }

            if (interaction.channel.isThread() && !interaction.channel.archived) {
                await interaction.channel.setArchived(true, 'Ticket closed by staff').catch(() => {
                    console.log(`Failed to archive ticket thread 2: ${interaction.channel.id}`);
                });
                console.log(`Successfully archived ticket thread: ${interaction.channel.id}`);
            }

            if (ticketCreator) {
                const ticketTypeMatch = interaction.channel.name.match(/@[^:]+:\s*(.+?)(?:\s*\[LOCKED|$)/);
                const ticketType = ticketTypeMatch ? ticketTypeMatch[1] : 'General';

                const dmEmbed = embeds.normal(
                    interaction.channel.toString(),
                    'Ticket Closed',
                    false
                ).addFields([
                    {
                        name: 'Type',
                        value: ticketType,
                        inline: true
                    },
                    {
                        name: 'Reason',
                        value: reason,
                        inline: true
                    },
                    {
                        name: 'Transcript',
                        value: ticketLogMessage?.attachments.first()?.url,
                        inline: false
                    }
                ])

                await ticketCreator.send({
                    embeds: [dmEmbed],
                }).catch(() => {
                    // Do nothing
                });
            }

            // Mark ticket as closed in storage (preserves data for records)
            await ticketStorage.closeTicket(interaction.channel.id);

            // Record the ticket closure in the leaderboard
            await leaderboardStorage.recordTicketClosure(
                interaction.user.id,
                interaction.user.displayName || interaction.user.username
            );
        } catch (error) {
            console.error('Error closing ticket:', error);
            await interaction.reply({
                embeds: [embeds.error('Failed to close the ticket. There was an error creating the log.')],
                ephemeral: true
            });
        }
    }
} 