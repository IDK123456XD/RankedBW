import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder, Message, Collection, Role, Guild } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import ticketStorage from '../../utils/ticketStorage';

// Role hierarchy configuration
const ROLE_HIERARCHY = [
    { key: 'allstaff', name: 'All Staff', id: settings.roles.staff },
    { key: 'helper', name: 'Helper', id: settings.roles.helper },
    { key: 'moderator', name: 'Moderator', id: settings.roles.moderator },
    { key: 'seniorModerator', name: 'Senior Moderator', id: settings.roles.seniorModerator },
    { key: 'developer', name: 'Developer', id: settings.roles.developer },
    { key: 'administrator', name: 'Administrator', id: settings.roles.administrator },
    { key: 'owner', name: 'Owner', id: settings.roles.owner }
];

export default class TicketLockCommand extends ChildCommand {
    requiredRoles = [
        settings.roles.moderator,
        settings.roles.seniorModerator,
        settings.roles.developer,
        settings.roles.administrator,
        settings.roles.owner
    ];

    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('lock')
        .setDescription('Lock the ticket to specific staff roles and above (or All Staff to unlock)')
        .addStringOption(option =>
            option.setName('role')
                .setDescription('Minimum role required to access the ticket')
                .setRequired(true)
                .addChoices(
                    { name: 'All Staff (Unlocked)', value: 'allstaff' },
                    { name: 'Helper', value: 'helper' },
                    { name: 'Moderator', value: 'moderator' },
                    { name: 'Senior Moderator', value: 'seniorModerator' },
                    { name: 'Developer', value: 'developer' },
                    { name: 'Administrator', value: 'administrator' },
                    { name: 'Owner', value: 'owner' }
                )
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const selectedRole = interaction.options.getString('role', true);
        
        // Check if this is a ticket thread
        if (!interaction.channel?.isThread()) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in ticket threads.')],
                ephemeral: true
            });
        }

        // Check if this is a support ticket (in the support channel)
        if (interaction.channel.parentId !== settings.channels.support) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in support tickets.')],
                ephemeral: true
            });
        }

        // Find the selected role in hierarchy
        const selectedRoleData = ROLE_HIERARCHY.find(role => role.key === selectedRole);
        if (!selectedRoleData) {
            return interaction.reply({
                embeds: [embeds.error('Invalid role selected.')],
                ephemeral: true
            });
        }

        try {
            // Get or create ticket data
            let ticket = await ticketStorage.getTicket(interaction.channel.id);
            if (!ticket) {
                // Create ticket data if it doesn't exist
                // ticket = await ticketStorage.createTicket(
                //     interaction.channel.id, 
                //     interaction.channel.ownerId || '', 
                //     'unknown',
                //     'unknown'
                // );

                return interaction.reply({
                    embeds: [embeds.error('Ticket not found. Please close the ticket and try again.')],
                    ephemeral: true
                });
            }

            const isUnlocking = selectedRole === 'allstaff';

            if (isUnlocking) {
                // Unlock the ticket
                await ticketStorage.unlockTicket(interaction.channel.id);
            } else {
                // Lock the ticket to specific role
                await ticketStorage.lockTicket(interaction.channel.id, selectedRole, interaction.user.id);
                
                // Remove staff members who don't have the required role
                await this.removeInsufficientStaff(interaction, selectedRole);
            }

            // Update the staff notification message in the active tickets channel
            await this.updateActiveTicketMessage(interaction.channel.id, selectedRoleData, interaction.guild);

            // Send appropriate message in the ticket
            const message = isUnlocking 
                ? `This ticket has been unlocked by ${interaction.user}. All staff members can now join.`
                : `This ticket has been locked to <@&${selectedRoleData.id}> and above by ${interaction.user}.`;

            const title = isUnlocking ? 'Ticket Unlocked' : 'Ticket Locked';

            await interaction.reply({
                embeds: [embeds.normal(message, title, false)]
            });

        } catch (error) {
            console.error('Error managing ticket lock:', error);
            await interaction.reply({
                embeds: [embeds.error('Failed to manage the ticket lock. There was an error.')],
                ephemeral: true
            });
        }
    }

    /**
     * Remove staff members who don't have the required role or higher
     * but preserve manually added members
     */
    private async removeInsufficientStaff(interaction: ChatInputCommandInteraction, selectedRole: string) {
        const selectedRoleIndex = ROLE_HIERARCHY.findIndex(role => role.key === selectedRole);
        if (selectedRoleIndex === -1) return;

        try {
            // Get ticket data to check manually added members
            const ticket = await ticketStorage.getTicket(interaction.channel!.id);
            const manuallyAddedMembers = ticket?.manuallyAdded || [];

            // Get all members in the thread
            if (!interaction.channel!.isThread()) return;
            const threadMembers = await interaction.channel!.members.fetch();
            
            for (const [memberId, threadMember] of threadMembers) {
                // Skip bots and the thread creator
                if (!threadMember || !threadMember.user || threadMember.user.bot) continue;
                if (memberId === ticket.creatorId) continue;
                
                // Skip manually added members - they should always stay
                if (manuallyAddedMembers.includes(memberId)) continue;
                
                const guildMember = await interaction.guild?.members.fetch(memberId);
                if (!guildMember) continue;

                // Only check staff members - regular users can stay regardless of role
                const isStaff = guildMember.roles.cache.has(settings.roles.staff);
                if (!isStaff) continue; // Skip non-staff members, they can stay

                // Check if staff member has required role or higher
                const hasPermission = this.checkRolePermission(guildMember.roles.cache, selectedRoleIndex);

                // If staff member doesn't have permission, remove them from the ticket
                if (!hasPermission) {
                    try {
                        if (interaction.channel!.isThread()) {
                            await interaction.channel!.members.remove(memberId);
                        }
                    } catch (error) {
                        console.error(`Failed to remove member ${memberId}:`, error);
                    }
                }
            }
        } catch (error) {
            console.error('Error removing insufficient staff:', error);
        }
    }

    /**
     * Check if a user has the required role permission or higher
     */
    private checkRolePermission(userRoles: Collection<string, Role>, requiredRoleIndex: number): boolean {
        // Skip the 'allstaff' option (index 0) for permission checking
        for (let i = Math.max(1, requiredRoleIndex); i < ROLE_HIERARCHY.length; i++) {
            if (userRoles.has(ROLE_HIERARCHY[i].id)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Update the active ticket message to show the new lock level
     */
    private async updateActiveTicketMessage(threadId: string, lockRole: typeof ROLE_HIERARCHY[0], guild: Guild) {
        try {
            const ticket = await ticketStorage.getTicket(threadId);
            if (!ticket) return;

            const activeTicketsChannel = await guild?.channels.fetch(settings.channels.activeTickets);
            if (!activeTicketsChannel?.isTextBased()) return;
            
            const staffMessage = await activeTicketsChannel.messages.fetch(ticket.activeMessageId);

            if (staffMessage?.editable) {
                const creator = await guild.members.fetch(ticket.creatorId);
                
                const updatedEmbed = embeds.normal(
                    `Press the button below to join this ticket.\n\n` +
                    `**User**\n${creator} (${creator.user.tag})\n` +
                    `**Type**\n${ticket.ticketType.charAt(0).toUpperCase() + ticket.ticketType.slice(1)}\n` +
                    `**Level**\n<@&${lockRole.id}>`,
                    'Join Ticket',
                    false
                  );

                await staffMessage.edit({
                    embeds: [updatedEmbed],
                    components: staffMessage.components
                });
            }
        } catch (error) {
            console.error('Error updating staff message:', error);
        }
    }

    /**
     * Check if a user can access a locked ticket
     */
    static async canAccessLockedTicket(userRoles: any, threadId: string, userId?: string): Promise<boolean> {
        const lockInfo = await ticketStorage.getTicketLockInfo(threadId);
        if (!lockInfo) return true; // Not locked

        // Check if user was manually added to the ticket
        if (userId) {
            const ticket = await ticketStorage.getTicket(threadId);
            if (ticket?.manuallyAdded.includes(userId)) {
                return true; // Manually added users can always access
            }
        }

        const requiredRoleIndex = ROLE_HIERARCHY.findIndex(role => role.key === lockInfo.role);
        if (requiredRoleIndex === -1 || requiredRoleIndex === 0) return true; // Invalid lock info or unlocked

        // Check if user has required role or higher (skip index 0 which is 'allstaff')
        for (let i = Math.max(1, requiredRoleIndex); i < ROLE_HIERARCHY.length; i++) {
            if (userRoles.has(ROLE_HIERARCHY[i].id)) {
                return true;
            }
        }
        return false;
    }
}

// Export the role hierarchy for use in other files
export { ROLE_HIERARCHY }; 