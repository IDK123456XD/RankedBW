import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';

export default class TicketRenameCommand extends ChildCommand {
    requiredRoles = [
        settings.roles.staff
    ];

    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('rename')
        .setDescription('Rename the current ticket')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('The new name for the ticket')
                .setRequired(true)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const newName = interaction.options.getString('name', true);
        
        // Check if this is a ticket thread
        if (!interaction.channel?.isThread()) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in ticket threads.', '', false)],
                ephemeral: true
            });
        }

        // Check if this is a support ticket (in the support channel)
        if (interaction.channel.parentId !== settings.channels.support) {
            return interaction.reply({
                embeds: [embeds.error('This command can only be used in support tickets.', '', false)],
                ephemeral: true
            });
        }

        try {
            // Get the current ticket name
            const currentName = interaction.channel.name;
            
            // Extract the username from the current ticket name (format: @username: TicketType)
            const usernameMatch = currentName.match(/^@([^:]+):/);
            if (!usernameMatch) {
                return interaction.reply({
                    embeds: [embeds.error('Unable to determine the original ticket creator from the ticket name.', '', false)],
                    ephemeral: true
                });
            }

            const username = usernameMatch[1];
            const newTicketName = `@${username}: ${newName}`;

            // Rename the thread
            await interaction.channel.setName(newTicketName);
            
            // Send a message in the ticket about the rename
            await interaction.reply({
                embeds: [embeds.normal(
                    `This ticket has been renamed to "${newName}" by ${interaction.user}.`, 
                    'Ticket Renamed',
                    false
                )]
            });

        } catch (error) {
            console.error('Error renaming ticket:', error);
            await interaction.reply({
                embeds: [embeds.error('Failed to rename the ticket. Please try again or contact an administrator.', '', false)],
                ephemeral: true
            });
        }
    }
} 