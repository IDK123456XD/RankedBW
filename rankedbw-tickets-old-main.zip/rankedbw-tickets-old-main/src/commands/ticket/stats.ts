import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder, EmbedBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import ticketStorage from '../../utils/ticketStorage';
import App from '../..';

export default class TicketStatsCommand extends ChildCommand {
    requiredRoles = [
        settings.roles.moderator,
        settings.roles.seniorModerator,
        settings.roles.developer,
        settings.roles.administrator,
        settings.roles.owner
    ];

    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('stats')
        .setDescription('View ticket statistics and manage cleanup')
        .addStringOption(option =>
            option.setName('action')
                .setDescription('Action to perform')
                .setRequired(false)
                .addChoices(
                    { name: 'View Stats', value: 'stats' },
                    { name: 'Manual Cleanup', value: 'cleanup' },
                    { name: 'Force Cleanup Old Tickets', value: 'force' }
                )
        )
        .addIntegerOption(option =>
            option.setName('days')
                .setDescription('Days old for force cleanup (default: 30)')
                .setRequired(false)
                .setMinValue(1)
                .setMaxValue(365)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const action = interaction.options.getString('action') || 'stats';
        const days = interaction.options.getInteger('days') || 30;

        try {
            if (action === 'stats') {
                await this.showStats(interaction);
            } else if (action === 'cleanup') {
                await this.runManualCleanup(interaction);
            } else if (action === 'force') {
                await this.runForceCleanup(interaction, days);
            }
        } catch (error) {
            console.error('Error in ticket stats command:', error);
            await interaction.reply({
                embeds: [embeds.error('Failed to execute ticket stats command.')],
                ephemeral: true
            });
        }
    }

    private async showStats(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply({ ephemeral: true });

        const stats = await App.ticketCleanup.getTicketStats();
        
        // Format average age
        const avgAgeDays = Math.floor(stats.averageAge / (1000 * 60 * 60 * 24));
        const avgAgeHours = Math.floor((stats.averageAge % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

        // Format ticket types
        const typesList = Object.entries(stats.byType)
            .map(([type, count]) => `**${type.charAt(0).toUpperCase() + type.slice(1)}:** ${count}`)
            .join('\n') || 'No tickets';

        // Format accessibility
        const accessibility = stats.accessibility;
        const accessibilityText = `**Accessible:** ${accessibility.accessible}\n` +
            `**Archived:** ${accessibility.archived.length}\n` +
            `**Inaccessible:** ${accessibility.inaccessible.length}`;

        const embed = new EmbedBuilder()
            .setTitle('🎫 Ticket Statistics')
            .setColor(0x3498db)
            .addFields(
                {
                    name: '📊 Overview',
                    value: `**Total:** ${stats.total}\n` +
                           `**Active:** ${stats.active}\n` +
                           `**Archived:** ${stats.archived}\n` +
                           `**Closed:** ${stats.closed}\n` +
                           `**Locked:** ${stats.locked}`,
                    inline: true
                },
                {
                    name: '📋 By Type',
                    value: typesList,
                    inline: true
                },
                {
                    name: '🔍 Thread Accessibility',
                    value: accessibilityText,
                    inline: true
                },
                {
                    name: '⏰ Average Age',
                    value: `${avgAgeDays} days, ${avgAgeHours} hours`,
                    inline: false
                }
            )
            .setFooter({ text: 'Stats updated in real-time' })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    }

    private async runManualCleanup(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply({ ephemeral: true });

        try {
            await App.ticketCleanup.runCleanup();
            
            await interaction.editReply({
                embeds: [embeds.success('Manual cleanup completed successfully. Check console for details.')]
            });
        } catch (error) {
            console.error('Manual cleanup error:', error);
            await interaction.editReply({
                embeds: [embeds.error('Manual cleanup failed. Check console for details.')]
            });
        }
    }

    private async runForceCleanup(interaction: ChatInputCommandInteraction, days: number) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const removed = await App.ticketCleanup.forceCleanupOldTickets(days);
            
            await interaction.editReply({
                embeds: [embeds.success(`Force cleanup completed. Removed ${removed} tickets older than ${days} days.`)]
            });
        } catch (error) {
            console.error('Force cleanup error:', error);
            await interaction.editReply({
                embeds: [embeds.error('Force cleanup failed. Check console for details.')]
            });
        }
    }
} 