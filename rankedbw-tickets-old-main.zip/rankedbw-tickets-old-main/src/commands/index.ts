/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-unused-vars */
import {
  ChatInputCommandInteraction,
  InteractionResponse,
  Message,
  MessageFlags,
  SlashCommandBuilder,
  SlashCommandOptionsOnlyBuilder,
  SlashCommandSubcommandBuilder,
  SlashCommandSubcommandsOnlyBuilder,
} from 'discord.js';
import embeds from '../utils/discord/embeds';

export abstract class BaseCommand {
  maintenance = false;
  requiredRoles = [] as string[];

  async canRun(interaction: ChatInputCommandInteraction) {
    if (this.requiredRoles.length > 0) {
      const member = await interaction.guild.members.fetch(interaction.user.id);
      if (!member) return false;

      if (this.requiredRoles.some((x) => member.roles.cache.has(x))) return true;

      await interaction.reply({
        embeds: [
          embeds.error(
            `You must have one of the following roles to run this command:\n${this.requiredRoles.map((x) => `- <@&${x}>`).join('\n')}`
          )
        ],
        flags: [MessageFlags.Ephemeral]
      });

      return false;
    }

    return true;
  }

  async shutdown() {
    return;
  }
}

export abstract class ChildCommand extends BaseCommand {
  abstract slashCommand: SlashCommandSubcommandBuilder;

  abstract execute(_interaction: ChatInputCommandInteraction): Promise<void | InteractionResponse | Message<boolean>>;
}

export abstract class ParentCommand extends BaseCommand {
  abstract slashCommand: SlashCommandBuilder;

  abstract childCommands: ChildCommand[];
}

export abstract class Command extends BaseCommand {
  abstract slashCommand: SlashCommandBuilder | SlashCommandSubcommandsOnlyBuilder | Omit<SlashCommandBuilder, 'addSubcommand' | 'addSubcommandGroup'> | SlashCommandOptionsOnlyBuilder;

  abstract execute(_interaction: ChatInputCommandInteraction): Promise<void | InteractionResponse | Message<boolean>>;
}

export type AllCommandTypes = Command | ParentCommand | ChildCommand;