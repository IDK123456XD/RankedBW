import { ButtonInteraction, ChannelSelectMenuInteraction, InteractionCollector, MentionableSelectMenuInteraction, ModalSubmitInteraction, RoleSelectMenuInteraction, StringSelectMenuInteraction, UserSelectMenuInteraction } from 'discord.js';
import Paginator from './discord/paginator';

export function sleep(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

export function awaitCollectorEnd(collector: InteractionCollector<
    | StringSelectMenuInteraction
    | UserSelectMenuInteraction
    | RoleSelectMenuInteraction
    | MentionableSelectMenuInteraction
    | ChannelSelectMenuInteraction
    | ButtonInteraction
    | ModalSubmitInteraction> | Paginator
) {
    if (collector instanceof Paginator) {
        return new Promise((resolve) => collector.on('stop', () => resolve(null)));
    }

    return new Promise((resolve) => collector.on('end', () => resolve(null)));
}