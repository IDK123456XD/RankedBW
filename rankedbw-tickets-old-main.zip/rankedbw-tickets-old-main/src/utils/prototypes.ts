/* eslint-disable @typescript-eslint/no-unused-vars */
export { };

declare global {
  interface String {
    capitalize(): string;
    toProperCase(): string;
    convertDurationToMillis(): number;
  }

  interface Number {
    periodicFormat(): string;
    postFormatter(
      k?: boolean,
      m?: boolean,
      b?: boolean,
      t?: boolean
    ): string;
    timeFormat(
      showSeconds?: boolean,
      showMinutes?: boolean,
      showHours?: boolean,
      showDays?: boolean,
      showWeeks?: boolean,
      showMonths?: boolean,
      showYears?: boolean
    ): string;
  }

  interface Array<T> {
    random(): T;
    shuffle(): Array<T>;
  }

  interface Date {
    earlierThanDuration(
      minutes?: number,
      hours?: number,
      days?: number
    ): boolean;
    timeDifference(minutes?: number, hours?: number, days?: number): number;
  }
}

Object.defineProperty(String.prototype, 'capitalize', {
  value() {
    return this.charAt(0).toUpperCase() + this.slice(1).toLowerCase();
  },
});

Object.defineProperty(String.prototype, 'toProperCase', {
  value() {
    return this
      .replace(/([A-Z])/g, ' $1')
      .split(/_| /)
      .map((word: string) => word.charAt(0).toUpperCase() + word.substring(1).toLowerCase())
      .join(' ');
  },
});

Object.defineProperty(String.prototype, 'convertDurationToMillis', {
  value() {
    const parts = this.split(' ');
    let totalTime = 0;

    for (const part of parts) {
      const value = parseInt(part.slice(0, -1), 10);
      const unit = part.slice(-1);

      switch (unit) {
        case 'd':
          totalTime += value * 24 * 60 * 60 * 1000;
          break;
        case 'h':
          totalTime += value * 60 * 60 * 1000;
          break;
        case 'm':
          totalTime += value * 60 * 1000;
          break;
        case 's':
          totalTime += value * 1000;
          break;
        default:
          return 0;
      }
    }

    return totalTime;
  },
});

Object.defineProperty(Number.prototype, 'periodicFormat', {
  value() {
    return this.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  },
});

Object.defineProperty(Number.prototype, 'postFormatter', {
  value(k = true, m = true, b = true, t = true) {
    const num = this.valueOf();
    if (Math.abs(num) >= 1000000000000 && t)
      return `${(
        Math.sign(num) *
        (Math.abs(num) / 1000000000000)
      ).toFixed(0)}T`;
    if (Math.abs(num) >= 1000000000 && b)
      return `${(Math.sign(num) * (Math.abs(num) / 1000000000)).toFixed(
        0
      )}B`;
    if (Math.abs(num) >= 1000000 && m)
      return `${(Math.sign(num) * (Math.abs(num) / 1000000)).toFixed(
        0
      )}M`;
    if (Math.abs(num) >= 1000 && k)
      return `${(Math.sign(num) * (Math.abs(num) / 1000)).toFixed(0)}K`;
    return (Math.sign(num) * Math.abs(num)).toFixed(0);
  },
});

Object.defineProperty(Number.prototype, 'timeFormat', {
  value(
    showSeconds = true,
    showMinutes = true,
    showHours = true,
    showDays = true,
    showWeeks = true,
    showMonths = true,
    showYears = true
  ) {
    const num = this.valueOf() / 1000;

    const years = Math.floor(num / 31536000);
    const months = Math.floor(num / 2592000);
    const weeks = Math.floor(num / 604800);
    const days = Math.floor(num / 86400);
    const hours = Math.floor(num / 3600) % 24;
    const minutes = Math.floor(num / 60) % 60;
    const seconds = Math.floor(num % 60);

    let time = '';

    if (showYears && years > 0) time += `${years}y `;
    if (showMonths && months > 0) time += `${months}mo `;
    if (showWeeks && weeks > 0) time += `${weeks}w `;
    if (showDays && days > 0) time += `${days}d `;
    if (showHours && hours > 0) time += `${hours}h `;
    if (showMinutes && minutes > 0) time += `${minutes}m `;
    if (showSeconds && seconds > 0) time += `${seconds}s`;

    return time.trim();
  },
});

Object.defineProperty(Array.prototype, 'random', {
  value() {
    return this[Math.floor(Math.random() * this.length)];
  },
});

Object.defineProperty(Array.prototype, 'shuffle', {
  value() {
    for (let i = this.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this[i], this[j]] = [this[j], this[i]];
    }
    return this;
  },
});

Object.defineProperty(Date.prototype, 'earlierThanDuration', {
  value(minutes = 0, hours = 0, days = 0) {
    const totalMilliseconds =
      minutes * 60000 + hours * 3600000 + days * 86400000;
    return this.getTime() - totalMilliseconds > Date.now();
  },
});

Object.defineProperty(Date.prototype, 'timeDifference', {
  value(minutes = 0, hours = 0, days = 0) {
    const totalMilliseconds =
      minutes * 60000 + hours * 3600000 + days * 86400000;
    return this.getTime() - totalMilliseconds - Date.now();
  },
});