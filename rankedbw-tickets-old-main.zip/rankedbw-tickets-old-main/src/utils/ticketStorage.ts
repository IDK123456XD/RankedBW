import { TicketStatus } from '../generated/prisma';
import prisma from './database';

export interface TicketLockInfo {
    role: string;
    lockedBy: string;
    timestamp: number;
    threadId: string;
}

export interface TicketData {
    threadId: string;
    creatorId: string;
    ticketType: string;
    createdAt: number;
    isLocked: boolean;
    lockInfo?: TicketLockInfo;
    activeMessageId?: string; // ID of the message in activeTickets channel
    status: 'active' | 'archived' | 'closed'; // Track ticket status
    closedAt?: number; // When ticket was manually closed
    archivedAt?: number; // When thread was archived (not manually closed)
    manuallyAdded: string[]; // Array of user IDs who were manually added to the ticket
}

class TicketStorage {
    constructor() {
        // No initialization needed for Prisma
    }

    /**
     * Create a new ticket record
     */
    async createTicket(threadId: string, creatorId: string, ticketType: string, activeMessageId: string): Promise<TicketData> {
        const ticket = await prisma.ticket.create({
            data: {
                threadId,
                creatorId,
                ticketType,
                activeMessageId,
                status: TicketStatus.ACTIVE
            }
        });

        return this.convertToTicketData(ticket);
    }

    /**
     * Get ticket data by thread ID
     */
    async getTicket(threadId: string): Promise<TicketData | null> {
        const ticket = await prisma.ticket.findUnique({
            where: { threadId }
        });

        return ticket ? this.convertToTicketData(ticket) : null;
    }

    /**
     * Lock a ticket
     */
    async lockTicket(threadId: string, role: string, lockedBy: string): Promise<boolean> {
        try {
            await prisma.ticket.update({
                where: { threadId },
                data: {
                    isLocked: true,
                    lockRole: role,
                    lockedBy,
                    lockTimestamp: new Date()
                }
            });
            return true;
        } catch (error) {
            console.error('Error locking ticket:', error);
            return false;
        }
    }

    /**
     * Unlock a ticket (set to "All Staff")
     */
    async unlockTicket(threadId: string): Promise<boolean> {
        try {
            await prisma.ticket.update({
                where: { threadId },
                data: {
                    isLocked: false,
                    lockRole: null,
                    lockedBy: null,
                    lockTimestamp: null
                }
            });
            return true;
        } catch (error) {
            console.error('Error unlocking ticket:', error);
            return false;
        }
    }

    /**
     * Update the active message ID for a ticket
     */
    async updateActiveMessageId(threadId: string, messageId: string): Promise<boolean> {
        try {
            await prisma.ticket.update({
                where: { threadId },
                data: { activeMessageId: messageId }
            });
            return true;
        } catch (error) {
            console.error('Error updating active message ID:', error);
            return false;
        }
    }

    /**
     * Mark a ticket as closed (when using /ticket close)
     */
    async closeTicket(threadId: string): Promise<boolean> {
        try {
            await prisma.ticket.update({
                where: { threadId },
                data: {
                    status: TicketStatus.CLOSED,
                    closedAt: new Date(),
                    isLocked: false,
                    lockRole: null,
                    lockedBy: null,
                    lockTimestamp: null
                }
            });
            return true;
        } catch (error) {
            console.error('Error closing ticket:', error);
            return false;
        }
    }

    /**
     * Mark a ticket as archived (when thread is archived but not manually closed)
     */
    async archiveTicket(threadId: string): Promise<boolean> {
        try {
            const ticket = await prisma.ticket.findUnique({
                where: { threadId }
            });

            if (!ticket || ticket.status === TicketStatus.CLOSED) return false;

            await prisma.ticket.update({
                where: { threadId },
                data: {
                    status: TicketStatus.ARCHIVED,
                    archivedAt: new Date()
                }
            });
            return true;
        } catch (error) {
            console.error('Error archiving ticket:', error);
            return false;
        }
    }

    /**
     * Reactivate an archived ticket
     */
    async reactivateTicket(threadId: string): Promise<boolean> {
        try {
            const ticket = await prisma.ticket.findUnique({
                where: { threadId }
            });

            if (!ticket || ticket.status !== TicketStatus.ARCHIVED) return false;

            await prisma.ticket.update({
                where: { threadId },
                data: {
                    status: TicketStatus.ACTIVE,
                    archivedAt: null
                }
            });
            return true;
        } catch (error) {
            console.error('Error reactivating ticket:', error);
            return false;
        }
    }

    /**
     * Remove a ticket completely (only for closed tickets or very old archived ones)
     */
    async removeTicket(threadId: string, force: boolean = false): Promise<boolean> {
        try {
            if (!force) {
                const ticket = await prisma.ticket.findUnique({
                    where: { threadId }
                });

                if (ticket && ticket.status !== TicketStatus.CLOSED) {
                    return false;
                }
            }

            await prisma.ticket.delete({
                where: { threadId }
            });
            return true;
        } catch (error) {
            console.error('Error removing ticket:', error);
            return false;
        }
    }

    /**
     * Get all tickets
     */
    async getAllTickets(): Promise<TicketData[]> {
        const tickets = await prisma.ticket.findMany();
        return tickets.map(ticket => this.convertToTicketData(ticket));
    }

    /**
     * Get only active tickets
     */
    async getActiveTickets(): Promise<TicketData[]> {
        const tickets = await prisma.ticket.findMany({
            where: { status: TicketStatus.ACTIVE }
        });
        return tickets.map(ticket => this.convertToTicketData(ticket));
    }

    /**
     * Get only archived tickets
     */
    async getArchivedTickets(): Promise<TicketData[]> {
        const tickets = await prisma.ticket.findMany({
            where: { status: TicketStatus.ARCHIVED }
        });
        return tickets.map(ticket => this.convertToTicketData(ticket));
    }

    /**
     * Get only closed tickets
     */
    async getClosedTickets(): Promise<TicketData[]> {
        const tickets = await prisma.ticket.findMany({
            where: { status: TicketStatus.CLOSED }
        });
        return tickets.map(ticket => this.convertToTicketData(ticket));
    }

    /**
     * Get all locked tickets (active or archived)
     */
    async getLockedTickets(): Promise<TicketData[]> {
        const tickets = await prisma.ticket.findMany({
            where: {
                isLocked: true,
                status: { in: [TicketStatus.ACTIVE, TicketStatus.ARCHIVED] }
            }
        });
        return tickets.map(ticket => this.convertToTicketData(ticket));
    }

    /**
     * Check if a ticket is locked and get lock info
     */
    async getTicketLockInfo(threadId: string): Promise<TicketLockInfo | null> {
        const ticket = await prisma.ticket.findUnique({
            where: { threadId }
        });

        if (!ticket || !ticket.isLocked || !ticket.lockRole || !ticket.lockedBy || !ticket.lockTimestamp) {
            return null;
        }

        return {
            role: ticket.lockRole,
            lockedBy: ticket.lockedBy,
            timestamp: ticket.lockTimestamp.getTime(),
            threadId: ticket.threadId
        };
    }

    /**
     * Get tickets by creator
     */
    async getTicketsByCreator(creatorId: string): Promise<TicketData[]> {
        const tickets = await prisma.ticket.findMany({
            where: { creatorId }
        });
        return tickets.map(ticket => this.convertToTicketData(ticket));
    }

    /**
     * Add a user to the manually added list
     */
    async addUserToTicket(threadId: string, userId: string): Promise<boolean> {
        try {
            const ticket = await prisma.ticket.findUnique({
                where: { threadId }
            });

            if (!ticket) return false;

            // Add user to manuallyAdded array if not already present
            const currentManuallyAdded = ticket.manuallyAdded || [];
            if (!currentManuallyAdded.includes(userId)) {
                await prisma.ticket.update({
                    where: { threadId },
                    data: {
                        manuallyAdded: [...currentManuallyAdded, userId]
                    }
                });
            }
            return true;
        } catch (error) {
            console.error('Error adding user to ticket:', error);
            return false;
        }
    }

    /**
     * Remove a user from the manually added list
     */
    async removeUserFromTicket(threadId: string, userId: string): Promise<boolean> {
        try {
            const ticket = await prisma.ticket.findUnique({
                where: { threadId }
            });

            if (!ticket) return false;

            // Remove user from manuallyAdded array
            const currentManuallyAdded = ticket.manuallyAdded || [];
            const updatedManuallyAdded = currentManuallyAdded.filter(id => id !== userId);

            await prisma.ticket.update({
                where: { threadId },
                data: {
                    manuallyAdded: updatedManuallyAdded
                }
            });
            return true;
        } catch (error) {
            console.error('Error removing user from ticket:', error);
            return false;
        }
    }

    /**
     * Convert Prisma ticket to TicketData interface
     */
    private convertToTicketData(ticket: any): TicketData {
        const lockInfo = ticket.isLocked && ticket.lockRole && ticket.lockedBy && ticket.lockTimestamp ? {
            role: ticket.lockRole,
            lockedBy: ticket.lockedBy,
            timestamp: ticket.lockTimestamp.getTime(),
            threadId: ticket.threadId
        } : undefined;

        return {
            threadId: ticket.threadId,
            creatorId: ticket.creatorId,
            ticketType: ticket.ticketType,
            createdAt: ticket.createdAt.getTime(),
            isLocked: ticket.isLocked,
            lockInfo,
            activeMessageId: ticket.activeMessageId || undefined,
            status: ticket.status.toLowerCase() as 'active' | 'archived' | 'closed',
            closedAt: ticket.closedAt?.getTime(),
            archivedAt: ticket.archivedAt?.getTime(),
            manuallyAdded: ticket.manuallyAdded || []
        };
    }
}

// Export a singleton instance
export const ticketStorage = new TicketStorage();
export default ticketStorage; 