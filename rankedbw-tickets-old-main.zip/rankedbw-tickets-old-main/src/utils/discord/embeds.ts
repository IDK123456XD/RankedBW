import { Colors, EmbedBuilder } from 'discord.js';

const color = '#ffffff';
const iconURL = 'https://i.imgur.com/NQo8MIm.png';
export const footerText = 'Ranked Bedwars';

function normal(description: string, title?: string, footer = true) {
    const embed = new EmbedBuilder()
        .setColor(color)
        .setDescription(description)

    if (footer) embed.setTimestamp();
    if (title) embed.setTitle(title);
    if (footer) embed.setFooter({
        text: footerText,
        iconURL
    });

    return embed;
}

function error(text: string, title?: string, footer = true) {
    const embed = new EmbedBuilder()
        .setTitle('Error Detected')
        .setDescription(text)
        .setColor(Colors.Red)

    if (footer) embed.setFooter({
        text: footerText,
        iconURL
    });

    if (title) embed.setTitle(title);
    return embed.setTimestamp();
}

function warning(text: string, title?: string, footer = true) {
    const embed = new EmbedBuilder()
        .setDescription(text)
        .setColor(Colors.Yellow)

    if (footer) embed.setFooter({
        text: footerText,
        iconURL
    });

    if (title) embed.setTitle(title);
    return embed.setTimestamp();
}

function success(text: string, title?: string, footer = true) {
    const embed = new EmbedBuilder()
        .setDescription(text)
        .setColor(Colors.Green)

    if (footer) embed.setFooter({
        text: footerText,
        iconURL
    });

    if (title) embed.setTitle(title);
    return embed.setTimestamp();
}

function question(description: string, title = 'Automated Question') {
    return new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color)
        .setFooter({
            text: footerText,
            iconURL
        })
        .setTimestamp();
}

function empty() {
    return new EmbedBuilder()
        .setColor(color)
        .setFooter({
            text: footerText,
            iconURL,
        })
        .setTimestamp();
}

export default {
    normal,
    error,
    question,
    empty,
    success,
    warning,
};