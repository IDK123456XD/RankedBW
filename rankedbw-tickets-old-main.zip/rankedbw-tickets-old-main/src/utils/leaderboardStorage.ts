import prisma from './database';

interface LeaderboardEntry {
    userId: string;
    username: string;
    ticketsClosed: number;
    lastClosure?: number; // timestamp
}

class LeaderboardStorage {
    constructor() {
        // No initialization needed for Prisma
    }

    /**
     * Record a ticket closure for a staff member
     */
    async recordTicketClosure(userId: string, username: string): Promise<void> {
        try {
            await prisma.leaderboard.upsert({
                where: { userId },
                update: {
                    username, // Update username in case it changed
                    ticketsClosed: { increment: 1 },
                    lastClosure: new Date()
                },
                create: {
                    userId,
                    username,
                    ticketsClosed: 1,
                    lastClosure: new Date()
                }
            });
        } catch (error) {
            console.error('Error recording ticket closure:', error);
        }
    }

    async recordTicketClaim(userId: string, username: string): Promise<void> {
        await prisma.leaderboard.upsert({
            where: { userId },
            update: { ticketsClaimed: { increment: 1 }, username: username },
            create: { userId, username, ticketsClaimed: 1 }
        });
    }

    /**
     * Get leaderboard data sorted by tickets closed (descending)
     */
    async getLeaderboard(): Promise<LeaderboardEntry[]> {
        const entries = await prisma.leaderboard.findMany({
            orderBy: { ticketsClosed: 'desc' }
        });

        return entries.map(entry => ({
            userId: entry.userId,
            username: entry.username,
            ticketsClosed: entry.ticketsClosed,
            lastClosure: entry.lastClosure?.getTime()
        }));
    }

    /**
     * Get a specific user's stats
     */
    async getUserStats(userId: string): Promise<LeaderboardEntry | null> {
        const entry = await prisma.leaderboard.findUnique({
            where: { userId }
        });

        if (!entry) return null;

        return {
            userId: entry.userId,
            username: entry.username,
            ticketsClosed: entry.ticketsClosed,
            lastClosure: entry.lastClosure?.getTime()
        };
    }

    /**
     * Get total tickets closed by all staff
     */
    async getTotalTicketsClosed(): Promise<number> {
        const result = await prisma.leaderboard.aggregate({
            _sum: { ticketsClosed: true }
        });

        return result._sum.ticketsClosed || 0;
    }
}

export default new LeaderboardStorage(); 