import ticketStorage from './ticketStorage';
import settings from '../settings';
import { Client, TextChannel } from 'discord.js';

export class TicketCleanup {
    private client: Client;

    constructor(client: Client) {
        this.client = client;
    }

        /**
     * Run periodic cleanup tasks
     */
    async runCleanup(): Promise<void> {
        console.log('Starting ticket cleanup...');
        
        try {
            // Remove all closed tickets immediately
            const closedTicketsRemoved = await this.cleanupClosedTickets();
            
            // Clean up tickets with invalid active messages (but keep ticket data)
            const invalidMessagesRemoved = await this.cleanupInvalidActiveMessages();
            
            // Update ticket statuses based on thread state
            const statusUpdates = await this.updateTicketStatuses();
            
            console.log(`Ticket cleanup completed:
- Closed tickets removed: ${closedTicketsRemoved}
- Invalid messages cleaned: ${invalidMessagesRemoved}
- Status updates: ${statusUpdates.archived} archived, ${statusUpdates.reactivated} reactivated`);
            
        } catch (error) {
            console.error('Error during ticket cleanup:', error);
        }
    }

    /**
     * Clean up tickets with active messages that no longer exist
     * This only clears the message ID, preserving ticket data
     */
    private async cleanupInvalidActiveMessages(): Promise<number> {
        const allTickets = await ticketStorage.getAllTickets();
        let cleanedCount = 0;

        try {
            const guild = await this.client.guilds.fetch(settings.guild);
            const activeTicketsChannel = await guild.channels.fetch(settings.channels.activeTickets) as TextChannel;
            
            if (!activeTicketsChannel?.isTextBased()) {
                console.log('Active tickets channel not found');
                return 0;
            }

            for (const ticket of allTickets) {
                if (ticket.activeMessageId) {
                    try {
                        await activeTicketsChannel.messages.fetch(ticket.activeMessageId);
                        // Message exists, no action needed
                    } catch (error) {
                        // Message doesn't exist, clear the ID but keep ticket data
                        await ticketStorage.updateActiveMessageId(ticket.threadId, '');
                        cleanedCount++;
                        console.log(`Cleared invalid active message ID for ticket: ${ticket.threadId}`);
                    }
                }
            }
        } catch (error) {
            console.error('Error cleaning up invalid active messages:', error);
        }

        return cleanedCount;
    }

    /**
     * Clean up all closed tickets immediately
     * Removes data for any ticket marked as closed
     */
    private async cleanupClosedTickets(): Promise<number> {
        const closedTickets = await ticketStorage.getClosedTickets();
        let removed = 0;

        for (const ticket of closedTickets) {
            await ticketStorage.removeTicket(ticket.threadId, true); // Force remove closed tickets
            removed++;
            console.log(`Removed closed ticket: ${ticket.threadId}`);
        }

        return removed;
    }

    /**
     * Update ticket statuses based on actual thread state
     * Archives active tickets if threads are archived, reactivates if threads are unarchived
     */
    private async updateTicketStatuses(): Promise<{ archived: number; reactivated: number }> {
        const activeTickets = await ticketStorage.getActiveTickets();
        const archivedTickets = await ticketStorage.getArchivedTickets();
        let archived = 0;
        let reactivated = 0;

        try {
            const guild = await this.client.guilds.fetch(settings.guild);

            // Check active tickets to see if they should be archived
            for (const ticket of activeTickets) {
                try {
                    const thread = await guild.channels.fetch(ticket.threadId);
                    if (thread?.isThread() && thread.archived) {
                        await ticketStorage.archiveTicket(ticket.threadId);
                        archived++;
                        console.log(`Archived ticket: ${ticket.threadId}`);
                    }
                } catch (error) {
                    // Thread doesn't exist, but we don't remove the ticket data
                    console.log(`Cannot access thread for ticket: ${ticket.threadId}`);
                }
            }

            // Check archived tickets to see if they should be reactivated
            for (const ticket of archivedTickets) {
                try {
                    const thread = await guild.channels.fetch(ticket.threadId);
                    if (thread?.isThread() && !thread.archived) {
                        await ticketStorage.reactivateTicket(ticket.threadId);
                        reactivated++;
                        console.log(`Reactivated ticket: ${ticket.threadId}`);
                    }
                } catch (error) {
                    // Thread doesn't exist, but we don't remove the ticket data
                    console.log(`Cannot access thread for archived ticket: ${ticket.threadId}`);
                }
            }
        } catch (error) {
            console.error('Error updating ticket statuses:', error);
        }

        return { archived, reactivated };
    }

    /**
     * Check thread accessibility without removing ticket data
     * This is for monitoring purposes only
     */
    async checkThreadAccessibility(): Promise<{
        accessible: number;
        inaccessible: string[];
        archived: string[];
    }> {
        const allTickets = await ticketStorage.getAllTickets();
        const inaccessible: string[] = [];
        const archived: string[] = [];
        let accessible = 0;

        for (const ticket of allTickets) {
            try {
                const guild = await this.client.guilds.fetch(settings.guild);
                const thread = await guild.channels.fetch(ticket.threadId);
                
                if (!thread || !thread.isThread()) {
                    inaccessible.push(ticket.threadId);
                } else if (thread.archived) {
                    archived.push(ticket.threadId);
                } else {
                    accessible++;
                }
            } catch (error) {
                inaccessible.push(ticket.threadId);
            }
        }

        return { accessible, inaccessible, archived };
    }

    /**
     * Start periodic cleanup (runs every hour)
     */
    startPeriodicCleanup(): void {
        // Run initial cleanup after 1 minute
        setTimeout(() => {
            this.runCleanup();
        }, 60 * 1000);

        // Then run every hour
        setInterval(() => {
            this.runCleanup();
        }, 60 * 60 * 1000);

        console.log('Periodic ticket cleanup started (runs every hour)');
    }

    /**
     * Get comprehensive ticket statistics
     */
    async getTicketStats(): Promise<{
        total: number;
        active: number;
        archived: number;
        closed: number;
        locked: number;
        byType: Record<string, number>;
        byStatus: Record<string, number>;
        averageAge: number;
        accessibility: {
            accessible: number;
            inaccessible: string[];
            archived: string[];
        };
    }> {
        const allTickets = await ticketStorage.getAllTickets();
        const activeTickets = await ticketStorage.getActiveTickets();
        const archivedTickets = await ticketStorage.getArchivedTickets();
        const closedTickets = await ticketStorage.getClosedTickets();
        const lockedTickets = await ticketStorage.getLockedTickets();
        
        const byType: Record<string, number> = {};
        const byStatus: Record<string, number> = {
            active: activeTickets.length,
            archived: archivedTickets.length,
            closed: closedTickets.length
        };
        let totalAge = 0;
        
        for (const ticket of allTickets) {
            byType[ticket.ticketType] = (byType[ticket.ticketType] || 0) + 1;
            totalAge += Date.now() - ticket.createdAt;
        }

        const accessibility = await this.checkThreadAccessibility();
        
        return {
            total: allTickets.length,
            active: activeTickets.length,
            archived: archivedTickets.length,
            closed: closedTickets.length,
            locked: lockedTickets.length,
            byType,
            byStatus,
            averageAge: allTickets.length > 0 ? totalAge / allTickets.length : 0,
            accessibility
        };
    }

    /**
     * Manual cleanup for old active/archived tickets
     * Only use this if you need to clean up tickets that aren't properly closed
     */
    async forceCleanupOldTickets(daysOld: number = 30): Promise<number> {
        const cutoffTime = Date.now() - (daysOld * 24 * 60 * 60 * 1000);
        const allTickets = (await ticketStorage.getAllTickets()).filter(ticket => ticket.status !== 'closed');
        let removed = 0;

        for (const ticket of allTickets) {
            if (ticket.createdAt < cutoffTime) {
                await ticketStorage.removeTicket(ticket.threadId, true);
                removed++;
                console.log(`Force removed old ticket (${daysOld}+ days): ${ticket.threadId}`);
            }
        }

        return removed;
    }
} 