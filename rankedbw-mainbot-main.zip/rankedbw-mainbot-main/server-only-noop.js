// server-only-noop.js
module.exports = {};