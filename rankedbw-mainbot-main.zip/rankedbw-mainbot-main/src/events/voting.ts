import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ClientEvents, Events, Interaction } from 'discord.js';
import Event from '.';
import settings from '../settings';
import embeds from '../utils/discord/embeds';
import { VotingTypes } from '@common/database/generated';
import { prisma } from '@common/database/connectors/prisma';
import App from '..';

export default class InteractionHandler extends Event {
    eventNames: (keyof ClientEvents)[] = [Events.InteractionCreate];

    async handle(interaction: Interaction) {
        if (
            !interaction.isButton() ||
            (!interaction.customId.includes('-upvote') &&
                !interaction.customId.includes('-downvote') &&
                !interaction.customId.includes('-endvote'))
        ) return;

        const type = interaction.customId.split('-')[0] as VotingTypes;
        const action = interaction.customId.split('-')[1];
        const messageId = interaction.message.id;

        const message = await interaction.channel.messages.fetch(messageId);
        if (!message) {
            await interaction.reply({
                embeds: [
                    embeds.error(
                        'Message not found. Please contact a developer if this issue persists.'
                    ),
                ],
                ephemeral: true,
            });
            return;
        }

        const votingData = await prisma.voting.findFirst({
            where: {
                messageId,
                type
            }
        });
        if (!votingData) {
            await interaction.reply({
                embeds: [
                    embeds.error(
                        'Voting data not found. Please contact a developer if this issue persists.'
                    ),
                ],
                ephemeral: true,
            });
            return;
        }

        if (action === 'upvote' || action === 'downvote') {
            let hasVoted = false;

            // Check if user has already voted
            const hasUpvoted = votingData.upvoteVoters.includes(interaction.user.id);
            const hasDownvoted = votingData.downvoteVoters.includes(interaction.user.id);

            // Remove previous vote if exists
            if (hasUpvoted || hasDownvoted) {
                hasVoted = true;
                let upvoteVoters = [...votingData.upvoteVoters];
                let downvoteVoters = [...votingData.downvoteVoters];

                if (hasUpvoted) {
                    upvoteVoters = upvoteVoters.filter(id => id !== interaction.user.id);
                } else if (hasDownvoted) {
                    downvoteVoters = downvoteVoters.filter(id => id !== interaction.user.id);
                }

                // Add new vote
                if (action === 'upvote') {
                    upvoteVoters.push(interaction.user.id);
                } else {
                    downvoteVoters.push(interaction.user.id);
                }

                // Update in database
                await prisma.voting.update({
                    where: {
                        id: votingData.id
                    },
                    data: {
                        upvoteVoters,
                        downvoteVoters
                    }
                });
            } else {
                // Add new vote directly
                await prisma.voting.update({
                    where: {
                        id: votingData.id
                    },
                    data: {
                        [action === 'upvote' ? 'upvoteVoters' : 'downvoteVoters']: {
                            push: interaction.user.id
                        }
                    }
                });
            }

            // Get updated voting data
            const updatedVotingData = await prisma.voting.findUnique({
                where: {
                    id: votingData.id
                }
            });

            await interaction.reply({
                embeds: [embeds.success(
                    hasVoted
                        ? `Your vote has been changed to ${action === 'upvote' ? 'upvote' : 'downvote'}.`
                        : `You have voted to ${action === 'upvote' ? 'upvote' : 'downvote'} <@${votingData.candidateId}>.`,
                )],
                ephemeral: true,
            });

            await message.edit({
                content: `<@${votingData.candidateId}>`,
                embeds: [
                    embeds.success(
                        `A vote has been started for <@${votingData.candidateId}> to join ${type.toUpperCase()}.`,
                        `${type.toUpperCase()}`
                    ).addFields([
                        {
                            name: 'Upvotes',
                            value: updatedVotingData.upvoteVoters.length.toString(),
                            inline: true,
                        },
                        {
                            name: 'Downvotes',
                            value: updatedVotingData.downvoteVoters.length.toString(),
                            inline: true,
                        },
                        {
                            name: 'Total Votes',
                            value: (updatedVotingData.upvoteVoters.length + updatedVotingData.downvoteVoters.length).toString(),
                            inline: true,
                        },
                    ])
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId(`${type}-upvote`)
                            .setLabel('Upvote')
                            .setStyle(ButtonStyle.Success),
                        new ButtonBuilder()
                            .setCustomId(`${type}-downvote`)
                            .setLabel('Downvote')
                            .setStyle(ButtonStyle.Danger),
                        new ButtonBuilder()
                            .setCustomId(`${type}-endvote`)
                            .setLabel('End Vote')
                            .setStyle(ButtonStyle.Secondary),
                    ) as ActionRowBuilder<ButtonBuilder>
                ]
            });
        } else if (action === 'endvote') {
            const member = await interaction.guild.members.fetch(interaction.user.id);
            if (!member) return;

            if (
                type === 'pups' && !member.roles.cache.has(settings.roles.pupsManager) ||
                type === 'pugs' && !member.roles.cache.has(settings.roles.pugsManager)
            ) {
                await interaction.reply({
                    embeds: [embeds.error('You do not have permission to end this vote.')],
                    ephemeral: true,
                });
                return;
            }

            if (
                type === 'pups' && votingData.upvoteVoters.length > votingData.downvoteVoters.length ||
                type === 'pugs' && votingData.upvoteVoters.length > (votingData.downvoteVoters.length * 2)
            ) {
                const role = await interaction.guild.roles.fetch(settings.roles[type]);
                if (!role) {
                    await interaction.reply({
                        embeds: [embeds.error(`${type.toUpperCase()} role not found.`)],
                        ephemeral: true,
                    });
                    return;
                }

                const candidateMember = await interaction.guild.members.fetch(votingData.candidateId);
                if (!candidateMember) {
                    await interaction.reply({
                        embeds: [embeds.error(`${votingData.candidateId} is not found as a member in this guild.`)],
                        ephemeral: true,
                    });
                    return;
                }

                if (candidateMember.roles.cache.has(role.id)) {
                    await interaction.reply({
                        embeds: [embeds.error(`${votingData.candidateId} is already in the ${type.toUpperCase()} role.`)],
                        ephemeral: true,
                    });
                    return;
                }

                await App.Redis.publish('change:role', JSON.stringify({
                    memberId: candidateMember.id,
                    roleId: role.id,
                    guildId: interaction.guild.id,
                    action: 'add'
                }));

                await message.edit({
                    content: `<@${votingData.candidateId}>`,
                    embeds: [
                        embeds.success(
                            `<@${votingData.candidateId}> has been accepted into ${type.toUpperCase()}.`,
                            `${type.toUpperCase()} Voting Complete`
                        )
                    ],
                    components: []
                });
                await interaction.reply({
                    embeds: [
                        embeds.success(
                            `<@${votingData.candidateId}> has been accepted into ${type.toUpperCase()}.`
                        ),
                    ],
                    ephemeral: true,
                });

                const announcementsChannel = await interaction.guild.channels.fetch(settings.channels[`${type}Announcements`]);
                if (announcementsChannel?.isTextBased()) {
                    await announcementsChannel.send({
                        content: `<@${votingData.candidateId}>`,
                        embeds: [
                            embeds.success(
                                `Congratulations <@${votingData.candidateId}>! You have been accepted into ${type.toUpperCase()}.`,
                                `${type.toUpperCase()} Role Added`
                            )
                        ],
                    });
                }
            } else {
                await message.edit({
                    content: `<@${votingData.candidateId}>`,
                    embeds: [
                        embeds.error(
                            `<@${votingData.candidateId}> has been denied into ${type.toUpperCase()}.`,
                            `${type.toUpperCase()} Voting Complete`
                        )
                    ],
                    components: []
                });
                await interaction.reply({
                    embeds: [
                        embeds.success(
                            `<@${votingData.candidateId}> has been denied into ${type.toUpperCase()}.`
                        ),
                    ],
                    ephemeral: true,
                });
            }

            await prisma.voting.delete({
                where: {
                    id: votingData.id
                }
            });
        }
    }
}