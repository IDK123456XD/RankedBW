import { AutocompleteInteraction, ChatInputCommandInteraction, ClientEvents, Events, Interaction, MessageFlags } from 'discord.js';
import Event from '.';
import App from '..';
import { ChildCommand, Command, ParentCommand } from '../commands';
import embeds from '../utils/discord/embeds';
import Logger from '../utils/logger';

export default class InteractionHandler extends Event {
  eventNames: (keyof ClientEvents)[] = [Events.InteractionCreate];

  async handle(interaction: Interaction) {
    if (!interaction.isAutocomplete() && !interaction.isChatInputCommand())
      return;

    if (interaction.isAutocomplete()) return this.handleAutocomplete(interaction);
    if (interaction.isChatInputCommand()) return this.handleChatInput(interaction);
  }

  async handleAutocomplete(interaction: AutocompleteInteraction) {
    const commandName = interaction.commandName;
    const subCommmandName = interaction.options.getSubcommand(false);

    let command: Command | ChildCommand;
    if (subCommmandName) {
      const parentCommand = App.commands.find(
        (x) =>
          x instanceof ParentCommand &&
          x.slashCommand.name == commandName &&
          x.childCommands.find((y) => y.slashCommand.name == subCommmandName)
      ) as ParentCommand;
      
      const childCommand = parentCommand?.childCommands.find(
        (x) => x.slashCommand.name == subCommmandName
      ) as ChildCommand;

      if (!parentCommand || !childCommand) return;

      command = childCommand;
    } else {
      command = App.commands.find(
        (x) => x instanceof Command && x.slashCommand.name == commandName
      ) as Command;
    }
    if (!command) return;

    if (command.maintenance) return interaction.respond([]);

    if (!command.canRun(interaction)) return interaction.respond([]);

    command
      .autocomplete(interaction)
      .catch((e) => Logger.error("COMMAND_HANDLER", e));
  }

  async handleChatInput(interaction: ChatInputCommandInteraction) {
    const commandName = interaction.commandName;
    const subCommmandName = interaction.options.getSubcommand(false);

    let command: Command | ChildCommand;
    if (subCommmandName) {
      const parentCommand = App.commands.find(
        (x) =>
          x instanceof ParentCommand &&
          x.slashCommand.name == commandName &&
          x.childCommands.find((y) => y.slashCommand.name == subCommmandName)
      ) as ParentCommand;
      const childCommand = parentCommand?.childCommands.find(
        (x) => x.slashCommand.name == subCommmandName
      ) as ChildCommand;

      if (!parentCommand || !childCommand) return;

      command = childCommand;
    } else {
      command = App.commands.find(
        (x) => x instanceof Command && x.slashCommand.name == commandName
      ) as Command;
    }
    if (!command) return;

    if (command.maintenance)
      return interaction.reply({
        embeds: [embeds.error("This command is currently under maintenance!")],
      });

    const canRun = await command.canRun(interaction);

    if (!canRun) return;

    await command
      .execute(interaction)
      .catch((e) => Logger.error("COMMAND_HANDLER", e));
  }
}