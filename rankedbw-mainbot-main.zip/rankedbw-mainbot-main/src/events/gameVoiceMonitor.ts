import { ClientEvents, Events, VoiceState, ThreadChannel } from 'discord.js';
import Event from '.';
import settings from '../settings';
import App from '..';
import { prisma } from '@common/database/connectors/prisma';
import { GameStatus } from '@common/database/generated';
import { GameHandler } from '../utils/gameHandler';

const GRACE_PERIOD_MS = 30_000;

interface ParticipantTracking {
  playerIds: string[];
  warnings: Record<string, { timeoutAt: number; timer?: NodeJS.Timeout }>;
}

export default class GameVoiceMonitorEvent extends Event {
  eventNames: (keyof ClientEvents)[] = [Events.VoiceStateUpdate];

  async handle(oldState: VoiceState, newState: VoiceState) {
    if (oldState.guild.id !== settings.guild) return;

    const memberId = oldState.member?.id || newState.member?.id;
    if (!memberId) return;

    const leftChannel = !!oldState.channelId && !newState.channelId;
    const switchedChannel = !!oldState.channelId && !!newState.channelId && oldState.channelId !== newState.channelId;
    if (!leftChannel && !switchedChannel) return;

    const pendingGame = await prisma.game.findFirst({
      where: { status: GameStatus.PENDING, OR: [ { team1Voice: oldState.channelId }, { team2Voice: oldState.channelId } ] }
    });

    if (!pendingGame) return;

  const scoringFlag = await App.Redis.get(`scoringInProgress:${pendingGame.gameId}`);
  if (scoringFlag) return;

  const trackingRaw = await App.Redis.get(`gameParticipants:${pendingGame.gameId}`);
    if (!trackingRaw) return; 

    let tracking: ParticipantTracking;
    try { tracking = JSON.parse(trackingRaw); } catch { return; }

    if (!tracking.playerIds.includes(memberId)) return;

    const stillInEitherChannel = newState.channelId === pendingGame.team1Voice || newState.channelId === pendingGame.team2Voice;
    if (stillInEitherChannel) {
      if (tracking.warnings[memberId]?.timer) {
        clearTimeout(tracking.warnings[memberId].timer);
        delete tracking.warnings[memberId];
        await App.Redis.set(`gameParticipants:${pendingGame.gameId}`, JSON.stringify(tracking));
      }
      return;
    }

    if (tracking.warnings[memberId]) return; 

    const thread = await oldState.guild.channels.fetch(pendingGame.queueThreadChannelId);
    if (!thread || !(thread instanceof ThreadChannel)) return;

    if (settings.features && settings.features.voidOnLeaveDuringPicking === false) {
      return; 
    }

    const deadline = Date.now() + GRACE_PERIOD_MS;

    await thread.send({
      content: `<@${memberId}> You left the game voice channel. You have 30 seconds to rejoin or the game will be voided.`
    }).catch(() => {});

    const timer = setTimeout(async () => {
      try {
        const latestGame = await prisma.game.findFirst({ where: { gameId: pendingGame.gameId } });
        if (!latestGame || latestGame.status !== GameStatus.PENDING) {
          return; 
        }
  const latest = await oldState.guild.channels.fetch(pendingGame.team1Voice).catch((): any => null);
  const latest2 = await oldState.guild.channels.fetch(pendingGame.team2Voice).catch((): any => null);
  const member = await oldState.guild.members.fetch(memberId).catch((): any => null);
        const inChan = member?.voice?.channelId === pendingGame.team1Voice || member?.voice?.channelId === pendingGame.team2Voice;
        if (inChan) {
          return;
        }
        await thread.send({ content: `<@${memberId}> did not return. Voiding game.` }).catch(() => {});
        await GameHandler.voidGame(pendingGame.gameId, oldState.guild, true, memberId, 'Player failed to rejoin within 30s');
      } catch (e) {
        console.error('Failed to auto-void after leave timeout', e);
      } finally {
        const currentRaw = await App.Redis.get(`gameParticipants:${pendingGame.gameId}`);
        if (currentRaw) {
          try {
            const cur: ParticipantTracking = JSON.parse(currentRaw);
            delete cur.warnings[memberId];
            await App.Redis.set(`gameParticipants:${pendingGame.gameId}`, JSON.stringify(cur));
          } catch {}
        }
      }
    }, GRACE_PERIOD_MS);

    tracking.warnings[memberId] = { timeoutAt: deadline };
    await App.Redis.set(`gameParticipants:${pendingGame.gameId}`, JSON.stringify(tracking));
    (global as any).__gameLeaveTimers = (global as any).__gameLeaveTimers || new Map<string, NodeJS.Timeout>();
    (global as any).__gameLeaveTimers.set(`${pendingGame.gameId}:${memberId}`, timer);
  }
}
