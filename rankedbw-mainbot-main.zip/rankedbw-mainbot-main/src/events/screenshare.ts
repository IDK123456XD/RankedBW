import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ClientEvents,
  Events,
  Interaction,
  GuildMember,
  ThreadChannel,
  ButtonInteraction,
  Message,
  Guild,
  Colors,
} from "discord.js";
import Event from ".";
import settings from "../settings";
import embeds from "../utils/discord/embeds";
import { prisma } from "@common/database/connectors/prisma";
import { Screenshare } from "@common/database/generated";

export default class ScreenshareInteractionHandler extends Event {
  eventNames: (keyof ClientEvents)[] = [Events.InteractionCreate];

  async handle(interaction: Interaction) {
    if (
      !interaction.isButton() ||
      !interaction.customId.startsWith("screenshare_")
    )
      return;

    const [action, actionType, threadId] = interaction.customId.split("_");

    if (action !== "screenshare") return;

    // Defer reply immediately since button operations can take time
    await interaction.deferReply({ ephemeral: true });

    // Check if user has screenshare permissions
    const member = (await interaction.guild?.members.fetch(
      interaction.user.id
    )) as GuildMember;
    const hasPermission =
      member?.roles.cache.has(settings.roles.screenshare) ||
      member?.roles.cache.has(settings.roles.owner) ||
      member?.roles.cache.has(settings.roles.administrator);

    if (!hasPermission) {
      await interaction.editReply({
        embeds: [
          embeds.error(
            "You must have the screenshare role to use this button."
          ),
        ],
      });
      return;
    }

    switch (actionType) {
      case "claim":
        await this.handleClaim(interaction, threadId, member);
        break;
      case "close":
        await this.handleClose(interaction, threadId, member);
        break;
      case "view":
        await this.handleView(interaction, threadId, member);
        break;
      case "freeze":
        await this.handleFreeze(interaction, threadId, member);
        break;
      case "unfreeze":
        await this.handleUnfreeze(interaction, threadId, member);
        break;
    }
  }

  private async handleClaim(
    interaction: ButtonInteraction,
    threadId: string,
    member: GuildMember
  ) {
    try {
      const screenshare = await prisma.screenshare.findFirst({
        where: { threadId },
      });

      if (!screenshare) {
        await interaction.editReply({
          embeds: [embeds.error("Screenshare request not found.")],
        });
        return;
      }

      if (screenshare.status !== "OPEN") {
        await interaction.editReply({
          embeds: [
            embeds.error(
              "This screenshare has already been claimed or closed."
            ),
          ],
        });
        return;
      }

      // Update screenshare status
      await prisma.screenshare.update({
        where: { id: screenshare.id },
        data: {
          status: "CLAIMED",
          claimedByUserId: member.id,
        },
      });

      const activeSeason = await prisma.season.findFirst({
        where: {
          active: true,
        },
      });

      if (!activeSeason) {
        await interaction.editReply({
          embeds: [embeds.error("No active season found.")],
        });
        return;
      }

      const playerData = await prisma.player.findFirst({
        where: {
          userId: member.id,
        },
      });

      if (!playerData) {
        await interaction.editReply({
          embeds: [embeds.error("Player not found.")],
        });
        return;
      }

      // Increment the staff member's claimedScreenshares count
      await prisma.playerStatistics.update({
        where: {
          playerId_seasonId: {
            playerId: playerData.id,
            seasonId: activeSeason.id,
          },
        },
        data: {
          claimedScreenshares: {
            increment: 1,
          },
        },
      });

      // Get the thread and send claim message
      const thread = (await interaction.guild.channels.fetch(
        threadId
      ));
      
      if (thread?.isThread()) {
        // Send embed pinging the target player with freeze/unfreeze buttons
        const targetMember = await interaction.guild.members.fetch(
          screenshare.targetUserId
        );
        if (targetMember) {
          const freezeButtons =
            new ActionRowBuilder<ButtonBuilder>().addComponents(
              new ButtonBuilder()
                .setCustomId(`screenshare_freeze_${threadId}`)
                .setLabel("Freeze Player")
                .setStyle(ButtonStyle.Danger),
              new ButtonBuilder()
                .setCustomId(`screenshare_unfreeze_${threadId}`)
                .setLabel("Unfreeze Player")
                .setStyle(ButtonStyle.Success)
            );

          await thread.send({
            content: `${targetMember}`,
            embeds: [
              embeds.normal(
                `${targetMember}, your screenshare has been claimed!\n` +
                  `Please wait for further instructions.\n\n` +
                  `**Staff Member:** ${member}\n` +
                  `**Reason:** ${screenshare.reason}`,
                "Screenshare Notice"
              ),
            ],
            components: [freezeButtons],
          });
        }
      }

      // Update active screenshares message
      await this.updateActiveScreenshareMessage(screenshare, member, "claim");

      // Update requests channel message
      await this.updateRequestsChannelMessage(
        screenshare,
        interaction.guild,
        "CLAIMED",
        member
      );

      await interaction.editReply({
        embeds: [
          embeds.success(
            "You have successfully claimed this screenshare request."
          ),
        ],
      });
    } catch (error) {
      console.error("Error claiming screenshare:", error);
      await interaction.editReply({
        embeds: [embeds.error("Failed to claim screenshare request.")],
      });
    }
  }

  private async handleClose(
    interaction: ButtonInteraction,
    threadId: string,
    member: GuildMember
  ) {
    try {
      const screenshare = await prisma.screenshare.findFirst({
        where: { threadId },
      });

      if (!screenshare) {
        await interaction.editReply({
          embeds: [embeds.error("Screenshare request not found.")],
        });
        return;
      }

      if (
        screenshare.status === "CLOSED" ||
        screenshare.status === "EXPIRED"
      ) {
        await interaction.editReply({
          embeds: [embeds.error("This screenshare is already closed.")],
        });
        return;
      }

      // Update screenshare status
      await prisma.screenshare.update({
        where: { id: screenshare.id },
        data: {
          status: "CLOSED",
          closedAt: new Date(),
        },
      });

      // Get the thread and create message log before closing
      const thread = (await interaction.guild.channels.fetch(
        threadId
      )) as ThreadChannel;

      if (thread?.isThread()) {
        await thread.send({
          embeds: [
            embeds.normal(
              `This screenshare request has been closed by ${member}.`,
              "Screenshare Closed"
            ),
          ],
        });

        // Unfreeze the target player if they were frozen
        const targetMember = await interaction.guild.members.fetch(
          screenshare.targetUserId
        );
        // Check if player is frozen using fresh member data
        if (targetMember?.roles.cache.has(settings.roles.frozen)) {
          await targetMember.roles.remove(settings.roles.frozen);
          await thread.send({
            embeds: [
              embeds.normal(
                `${targetMember} has been unfrozen.`,
                "Player Unfrozen"
              ),
            ],
          });
        }

        await thread.setLocked(true);
        await thread.setArchived(true);
      }

      // Remove from active screenshares
      await this.updateActiveScreenshareMessage(screenshare, member, "close");

      // Update requests channel message
      await this.updateRequestsChannelMessage(
        screenshare,
        interaction.guild,
        "CLOSED",
        member
      );

      // Log to screenshareLogs
      await this.logScreenshareClose(
        screenshare,
        member.id,
        "Manually closed by staff",
        interaction.guild,
      );

      await interaction.editReply({
        embeds: [
          embeds.success("Screenshare request has been closed successfully."),
        ],
      });
    } catch (error) {
      console.error("Error closing screenshare:", error);
      await interaction.editReply({
        embeds: [embeds.error("Failed to close screenshare request.")],
      });
    }
  }

  private async handleView(
    interaction: ButtonInteraction,
    threadId: string,
    member: GuildMember
  ) {
    try {
      const thread = (await interaction.guild.channels.fetch(
        threadId
      )) as ThreadChannel;
      if (!thread?.isThread()) {
        await interaction.editReply({
          embeds: [embeds.error("Screenshare thread not found.")],
        });
        return;
      }

      const tempMessage = await thread.send({
        content: `${member}`,
        embeds: [
          embeds.success(
            `Staff member ${member} has joined the screenshare request.`,
            ``,
            false
          ),
        ],
      });

      // Reply with ping and thread link
      const reply = await interaction.editReply({
        content: `${member}`,
        embeds: [
          embeds.success(`You can view the screenshare here: ${thread}`),
        ],
      });

      // Delete the reply after 3 seconds with error handling
      setTimeout(async () => {
        try {
          if (tempMessage && tempMessage.deletable) {
            await tempMessage.delete();
          }

          if (reply && reply.deletable) {
            await reply.delete();
          } else {
            // If not deletable, try editing to empty content
            await interaction.editReply({
              content: "",
              embeds: [],
            });
          }
        } catch (error) {}
      }, 3000);
    } catch (error) {
      console.error("Error viewing screenshare:", error);
      await interaction.editReply({
        embeds: [embeds.error("Failed to access screenshare thread.")],
      });
    }
  }

  private async handleFreeze(
    interaction: ButtonInteraction,
    threadId: string,
    member: GuildMember
  ) {
    try {
      const screenshare = await prisma.screenshare.findFirst({
        where: { threadId },
      });

      if (!screenshare) {
        await interaction.editReply({
          embeds: [embeds.error("Screenshare request not found.")],
        });
        return;
      }

      const targetMember = await interaction.guild.members.fetch(
        screenshare.targetUserId
      );
      if (!targetMember) {
        await interaction.editReply({
          embeds: [embeds.error("Target player not found in server.")],
        });
        return;
      }

      // Check if already frozen (using fresh member data)
      if (targetMember.roles.cache.has(settings.roles.frozen)) {
        await interaction.editReply({
          embeds: [embeds.error("Player is already frozen.")],
        });
        return;
      }

      await targetMember.roles.add(settings.roles.frozen);

      const thread = (await interaction.guild.channels.fetch(
        threadId
      )) as ThreadChannel;
      if (thread?.isThread()) {
        await thread.send({
          embeds: [
            embeds.normal(
              `${targetMember} has been frozen by ${member}, please wait for further instructions!`,
              "Player Frozen"
            ),
          ],
        });
      }

      await interaction.editReply({
        embeds: [embeds.success(`Successfully frozen ${targetMember}.`)],
      });
    } catch (error) {
      console.error("Error freezing player:", error);
      await interaction.editReply({
        embeds: [embeds.error("Failed to freeze player.")],
      });
    }
  }

  private async handleUnfreeze(
    interaction: ButtonInteraction,
    threadId: string,
    member: GuildMember
  ) {
    try {
      const screenshare = await prisma.screenshare.findFirst({
        where: { threadId },
      });

      if (!screenshare) {
        await interaction.editReply({
          embeds: [embeds.error("Screenshare request not found.")],
        });
        return;
      }

      const targetMember = await interaction.guild.members.fetch(
        screenshare.targetUserId
      );
      if (!targetMember) {
        await interaction.editReply({
          embeds: [embeds.error("Target player not found in server.")],
        });
        return;
      }

      await targetMember.roles.remove(settings.roles.frozen);

      const thread = (await interaction.guild.channels.fetch(
        threadId
      )) as ThreadChannel;
      if (thread?.isThread()) {
        await thread.send({
          embeds: [
            embeds.success(
              `${targetMember} has been unfrozen by ${member}, you are free to go!`,
              "Player Unfrozen"
            ),
          ],
        });
      }

      await interaction.editReply({
        embeds: [embeds.success(`Successfully unfrozen ${targetMember}.`)],
      });
    } catch (error) {
      console.error("Error unfreezing player:", error);
      await interaction.editReply({
        embeds: [embeds.error("Failed to unfreeze player.")],
      });
    }
  }

  private async updateActiveScreenshareMessage(
    screenshare: Screenshare,
    person: GuildMember,
    action: "claim" | "close"
  ) {
    try {
      const activeScreensharesChannel = await person.guild.channels.fetch(
        settings.channels.activeScreenshares
      );
      if (!activeScreensharesChannel?.isTextBased()) return;

      const messages = await activeScreensharesChannel.messages.fetch({
        limit: 100,
      });
      const activeMessage = messages.find(
        (msg: Message) =>
          msg.embeds.length > 0 &&
          msg.embeds[0].description?.includes(`<#${screenshare.threadId}>`)
      );

      if (activeMessage) {
        const targetUser = await person.guild.members
          .fetch(screenshare.targetUserId)
          .catch((): null => null);
        const requesterUser = await person.guild.members
          .fetch(screenshare.requesterUserId)
          .catch((): null => null);

        const updatedEmbed = embeds.normal(
          `User ${requesterUser || screenshare.requesterUserId} has requested a screenshare for ${targetUser || screenshare.targetUserId} <#${screenshare.threadId}>.\n\n` +
          `Reason: \`${screenshare.reason}\`\n` +
          `Status: \`${action === "claim" ? "CLAIMED" : "CLOSED"}\``,
          "Screenshare Request",
          false
        )
        .setColor(Colors.Green)
        .setFooter({ text: `Claimed by: ${person.user.username}` });

        const viewButton = new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder()
            .setCustomId(`screenshare_view_${screenshare.threadId}`)
            .setLabel("View Screenshare")
            .setStyle(ButtonStyle.Primary)
            .setEmoji("👁️")
        );

        await activeMessage.edit({
          embeds: [updatedEmbed],
          components: action === "claim" ? [viewButton] : [],
        });
      }
    } catch (error) {
      console.error("Error updating active screenshare message:", error);
    }
  }

  private async logScreenshareClose(
    screenshare: Screenshare,
    closedBy: string,
    reason: string,
    guild: Guild
  ) {
    try {
      const screenshareLogsChannel = await guild.channels.fetch(
        settings.channels.screenshareLogs
      );
      if (!screenshareLogsChannel?.isTextBased()) return;

      const targetUser = await guild.members
        .fetch(screenshare.targetUserId)
        .catch((): null => null);
      const requesterUser = await guild.members
        .fetch(screenshare.requesterUserId)
        .catch((): null => null);
      const closedByUser = await guild.members
        .fetch(closedBy)
        .catch((): null => null);

      const logEmbed = embeds.normal(
        `**Target:** ${targetUser || screenshare.targetUserId}\n` +
          `**Requester:** ${requesterUser || screenshare.requesterUserId}\n` +
          `**Thread:** <#${screenshare.threadId}>\n` +
          `**Reason:** ${screenshare.reason}\n` +
          `**Claimed by:** ${
            screenshare.claimedByUserId
              ? `<@${screenshare.claimedByUserId}>`
              : "None"
          }\n` +
          `**Closed by:** ${closedByUser || closedBy}\n` +
          `**Closed at:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
          `**Close reason:** ${reason}`,
        "Screenshare Closed"
      );

      await screenshareLogsChannel.send({
        embeds: [logEmbed],
      });
    } catch (error) {
      console.error("Error logging screenshare close:", error);
    }
  }

  private async updateRequestsChannelMessage(
    screenshare: Screenshare,
    guild: Guild,
    status: string,
    member?: GuildMember
  ) {
    try {
      const requestsChannel = await guild.channels.fetch(
        settings.channels.screenshareRequests
      );
      if (!requestsChannel?.isTextBased()) return;

      const requestMessage = await requestsChannel.messages.fetch(screenshare.requestMessageId);

      if (requestMessage) {
        const targetUser = await guild.members
          .fetch(screenshare.targetUserId)
          .catch((): null => null);
        const requesterUser = await guild.members
          .fetch(screenshare.requesterUserId)
          .catch((): null => null);

        const requestUser = requesterUser || screenshare.requesterUserId;
        const lastTargetUser = targetUser || screenshare.targetUserId;

        const updatedEmbed = embeds.normal(
          `User ${requestUser} has requested a screenshare for ${lastTargetUser}.\n\n` +
            `Reason: \`${screenshare.reason}\`\n` +
            `Status: \`${status}\``,
          "Screenshare Request",
          false
        )
        .setColor(Colors.Green)
        .setFooter({ text: `Claimed by: ${member?.user.username}` });

        await requestMessage.edit({
          embeds: [updatedEmbed],
        });
      }
    } catch (error) {
      console.error(
        "Error updating screenshare requests channel message:",
        error
      );
    }
  }
}
