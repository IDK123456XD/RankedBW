import { ClientEvents, Events, GuildMember, VoiceState } from "discord.js";
import Event from "..";
import App from "../..";
import settings from "../../settings";
import { checkQueueOpen } from "../../utils/queues";
import { prisma } from "@common/database/connectors/prisma";
import { IncludeCurrentSeasonStatistics, PlayerIncludingSeasonStatistics } from "@common/database/types/season";
import { Player, Season } from "@common/database/generated";

interface QueueRestrictions {
  queueChannelId: string;
  channelName: string;
  minElo: number;
  maxElo: number;
  requiredRoles: string[];
  specialRoles: string[];
}

const queueChannelIds = [
  settings.voiceChannels.queue1,
  settings.voiceChannels.queue2,
  settings.voiceChannels.queue3,
  settings.voiceChannels.queue4,
  settings.voiceChannels.queue5,
  settings.voiceChannels.queue6
];

export default class QueueJoiningEvent extends Event {
  eventNames: (keyof ClientEvents)[] = [Events.VoiceStateUpdate];

  async handle(oldState: VoiceState, newState: VoiceState) {
    // Only happen when a channel is joined or a member moved to a queue channel
    const joinedChannel = !oldState?.channelId && newState.channelId;
    const movedChannel = oldState?.channelId && newState.channelId && oldState.channelId !== newState.channelId;
    if (newState.guild.id !== settings.guild) return;

    // If user left a channel, or joined a non-queue channel, this event should not be handled by QueueJoiningEvent
    if ((!joinedChannel && !movedChannel) || !queueChannelIds.includes(newState.channelId))
      return;

    const season = await prisma.season.findFirst({
      where: {
        active: true,
      },
    });

    if (!season) {
      await App.Redis.publish(
        "queue:move",
        JSON.stringify({
          memberId: newState.member.id,
          channelId: settings.voiceChannels.waitingRoom,
          guildId: settings.guild,
        })
      );

      return;
    }

    const settingsDoc = await prisma.settings.findFirst();
    if (!(await checkQueueOpen(settingsDoc))) {
      await App.Redis.publish(
        "queue:move",
        JSON.stringify({
          memberId: newState.member.id,
          channelId: settings.voiceChannels.waitingRoom,
          guildId: settings.guild,
        })
      );

      return;
    }

    const playerData = await prisma.player.findFirst({
      where: {
        userId: newState.member.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });

    if (!playerData) {
      await App.Redis.publish(
        "queue:move",
        JSON.stringify({
          memberId: newState.member.id,
          channelId: settings.voiceChannels.waitingRoom,
          guildId: settings.guild,
        })
      );

      return;
    }

    if (!playerData.PlayerStatistics.find((x: any) => x.season.active)) {
      await prisma.playerStatistics.create({
        data: {
          playerId: playerData.id,
          seasonId: season.id,
        }
      });
    }

  const currentStats = playerData.PlayerStatistics.find((s: any) => s.season.active);
    // this is so bad but i don't know typescript lol
    try {
      if (currentStats) {
        let skipBracket = false;
        try {
          const inUseData = await App.Redis.get('teamVoiceChannelsInUse');
          if (inUseData && oldState?.channelId) {
            const inUseChannels: string[] = JSON.parse(inUseData);
            if (inUseChannels.includes(oldState.channelId)) skipBracket = true;
          }
          const activePicking = await App.Redis.get(`activePickingGameForUser:${newState.member.id}`);
          if (activePicking) skipBracket = true;
          
          const partyWarp = await App.Redis.get(`partyWarp:${newState.member.id}`);
          if (partyWarp) {
            skipBracket = true;
            await App.Redis.del(`partyWarp:${newState.member.id}`);
          }
        } catch (e) {
          console.warn('Bracket skip check failed', e);
        }

        if (!skipBracket) {
          const elo = currentStats.elo ?? 0;
          const srcChannel = newState.channelId;

          // Load dynamic queue restrictions from Redis
          const restrictionsData = await App.Redis.get('queueRestrictions');
          if (!restrictionsData) {
            console.warn('[QueueEloCheck] No queue restrictions found in Redis. Run /queue reload');
            return;
          }

          interface QueueRestriction {
            queueChannelId: string;
            channelName: string;
            minElo: number;
            maxElo: number;
            requiredRoles: string[];
            specialRoles: string[];
          }

          const restrictions: QueueRestriction[] = JSON.parse(restrictionsData);
          
          // Filter to only ELO-based queues (those with actual ELO restrictions)
          const eloQueues = restrictions.filter(r => r.minElo !== -1 && r.maxElo !== -1);
          
          // Check if we're in an ELO-based queue
          const currentQueue = eloQueues.find(q => q.queueChannelId === srcChannel);
          if (!currentQueue) {
            return; // Not in an ELO queue, don't check
          }

          // Check if player's ELO fits this queue's range
          const eloFitsQueue = elo >= currentQueue.minElo && (currentQueue.maxElo === 9999 || elo <= currentQueue.maxElo);
          
          // Check if user is an admin (staff, moderator, senior mod, admin, owner, or developer)
          const isAdmin = newState.member.roles.cache.hasAny(
            settings.roles.administrator,
            settings.roles.owner,
            settings.roles.developer
          );
          
          // If they don't fit the queue and are not an admin, move them to waiting room
          if (!eloFitsQueue && !isAdmin) {
            console.log(`[QueueEloCheck] ${newState.member.user.tag} does not meet ELO requirements for ${currentQueue.channelName} [${currentQueue.minElo}-${currentQueue.maxElo === 9999 ? '∞' : currentQueue.maxElo}] (has ${elo} ELO)`);
            
            await App.Redis.publish('queue:move', JSON.stringify({
              memberId: newState.member.id,
              channelId: settings.voiceChannels.waitingRoom,
              guildId: settings.guild,
            }));

            await sendAlert(
              newState.member,
              'You do not meet the requirements for this queue. (run `/update` to update your elo)'
            );
            
            return;
          }
        }
      }
    } catch (err) {
      console.error('auto move error:', err);
    }

    // Check if user is ranked banned
    if (newState.member.roles.cache.has(settings.roles.rankedBan)) {
      await App.Redis.publish(
        "queue:move",
        JSON.stringify({
          memberId: newState.member.id,
          channelId: settings.voiceChannels.waitingRoom,
          guildId: settings.guild,
        })
      );

      return await sendAlert(newState.member, "You cannot queue while ranked banned.");
    }

    // Only apply limit if active season exists and maxGames is set and greater than 0
    const limitCheckResult = await checkGameLimit(newState, playerData, season);
    if (limitCheckResult) return;

    await App.Redis.set(
      `queueJoined:${newState.member.id}`,
      new Date().getTime().toString()
    );
  }
}

async function sendAlert(member: GuildMember, reason: string) {
  const alertsChannel = await member.guild.channels.fetch(
    settings.channels.alerts
  );
  if (alertsChannel && alertsChannel.isTextBased()) {
    await alertsChannel.send({
      content: `${member.toString()} ${reason}`,
    });
  }
}

async function checkGameLimit(newState: VoiceState, playerData: Player, season: Season) {
  if (!season?.maxGames) return false;
  const limit = season.maxGames;

  // 1) Collect joining player + any party members
  const userIds = new Set<string>([playerData.userId]);
  const party = await prisma.party.findFirst({
    where: {
      OR: [
        { leader: newState.member.id },
        { members: { has: newState.member.id } }
      ]
    }
  });
  if (party) {
    [party.leader, ...party.members].forEach(id => userIds.add(id));
  }

  // 2) Load all their stats in one go
  const players = await prisma.player.findMany({
    where: { userId: { in: Array.from(userIds) } },
    include: IncludeCurrentSeasonStatistics,
  });

  // 3) Find who’s over the limit
  const overLimit = players.filter((p: any) => {
    const stats = p.PlayerStatistics.find((s: any) => s.season.active);
    return stats?.scoredGames >= limit;
  });

  if (overLimit.length === 0) return false;

  // 4) Move everyone in the set
  await Promise.all(
    Array.from(userIds).map(uid =>
      App.Redis.publish(
        "queue:move",
        JSON.stringify({
          memberId: uid,
          channelId: settings.voiceChannels.waitingRoom,
          guildId: settings.guild,
        })
      )
    )
  );

  // 5) Send alert
  const names = overLimit.map((p: any) => p.minecraftName);
  const reason =
    names.length > 1
      ? `**${names.join(", ")}** have`
      : `**${names[0]}** has`;

  const alerts = await newState.guild.channels.fetch(
    settings.channels.alerts
  );
  if (alerts?.isTextBased()) {
    await alerts.send({
      content: `<@${newState.member.id}>: You or your party members cannot join the queue because ${reason} reached the maximum of \`${limit}\` scored games for the current season.`,
    });
  }

  return true;
}