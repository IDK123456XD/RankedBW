import { ClientEvents, Events, GuildMember } from 'discord.js';
import Event from '..';
import { prisma } from '@common/database/connectors/prisma';
import App from '../..';
import settings from '../../settings';

export default class QueueJoiningEvent extends Event {
    eventNames: (keyof ClientEvents)[] = [Events.GuildMemberAdd];

    async handle(member: GuildMember) {
        const playerData = await prisma.player.findFirst({
            where: {
                userId: member.id
            }
        });

        const allowedReroles = [
            settings.roles.rankedBan,
            settings.roles.muted,
            settings.roles.tourneyBan,
            settings.roles.ticketBan
        ];

        if (playerData && playerData.leftRoleIds.length > 0) {
            for (const roleId of playerData.leftRoleIds) {
                if (!allowedReroles.includes(roleId)) continue;

                await App.Redis.publish('change:role', JSON.stringify({
                    memberId: member.id,
                    roleId: roleId,
                    guildId: member.guild.id,
                    action: 'add'
                }));
            }
        }
    }
}