import { ClientEvents, Events, GuildMember } from 'discord.js';
import Event from '..';
import settings from '../../settings';
import { prisma } from '@common/database/connectors/prisma';

const excludedRoles = [
    settings.roles.supporter,
    settings.roles.staff,
    settings.roles.helper,
    settings.roles.screenshare,
    settings.roles.moderator,
    settings.roles.seniorModerator,
    settings.roles.developer,
    settings.roles.administrator,
    settings.roles.owner,
];

export default class QueueJoiningEvent extends Event {
    eventNames: (keyof ClientEvents)[] = [Events.GuildMemberRemove];

    async handle(member: GuildMember) {
        const playerData = await prisma.player.findFirst({
            where: {
                userId: member.id
            }
        });
        if (!playerData) return;

        const roles = Array.from(member.guild.roles.cache.values()).filter((role) => {
            return !excludedRoles.includes(role.id) && member.roles.cache.has(role.id);
        });

        await prisma.player.update({
            where: {
                id: playerData.id
            },
            data: {
                leftRoleIds: roles.map((role) => role.id)
            }
        });
    }
}