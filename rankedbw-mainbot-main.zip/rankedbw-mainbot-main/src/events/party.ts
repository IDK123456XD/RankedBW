import { ClientEvents, Events, GuildMember, VoiceState } from 'discord.js';
import Event from '.';
import settings from '../settings';
import App from '..';
import { prisma } from '@common/database/connectors/prisma';

export default class QueueJoiningEvent extends Event {
    eventNames: (keyof ClientEvents)[] = [Events.VoiceStateUpdate];

    async handle(oldState: VoiceState, newState: VoiceState) {
        const joinedNewChannel = !oldState.channel && newState.channel;
        const movedToNewChannel = oldState.channel && newState.channel && oldState.channel.id !== newState.channel.id;
        if ((!joinedNewChannel && !movedToNewChannel) || newState.guild.id !== settings.guild) return;

        const party = await prisma.party.findFirst({
            where: {
                OR: [
                    {
                        leader: newState.member.id
                    },
                    {
                        members: {
                            has: newState.member.id
                        }
                    }
                ]
            }
        });

        if (party) {
            await prisma.party.update({
                where: {
                    id: party.id
                },
                data: {
                    lastVcJoin: new Date()
                }
            });
        }

        if (!party || !party.autoWarp || party.leader !== newState.member.id) return;

        const membersToWarp: GuildMember[] = [];
        for (const userId of party.members) {
            const member = await newState.guild.members.fetch(userId);
            if (!member || !member.voice.channel) continue;

            membersToWarp.push(member);
        }

        for (const member of membersToWarp) {
            await App.Redis.setex(`partyWarp:${member.id}`, 10, 'true');
            
            await App.Redis.publish(
                "queue:move",
                JSON.stringify({
                    memberId: member.id,
                    channelId: newState.channel.id,
                    guildId: newState.guild.id,
                })
            );
        }
    }
}