import {
  ClientEvents,
  Events,
  Interaction,
  GuildMember,
  StringSelectMenuInteraction,
  ButtonInteraction,
} from "discord.js";
import Event from ".";
import settings from "../settings";
import embeds from "../utils/discord/embeds";
import App from "..";
import { GameHandler } from "../utils/gameHandler";

type GamePlayerRedisData = {
  userId: string;
  minecraftName: string;
  nickname: string | null;
  discordTeam: number;
  gamePlayerId: string;
};

type RedisGameData = {
  gameId: string;
  gameDatabaseId: string;
  threadId: string;
  submittedBy: string;
  players: GamePlayerRedisData[];
  selectedMvps: string[];
  winningTeam: number | null;
  messageId: string | null;
}

export default class ManualScoringHandler extends Event {
  eventNames: (keyof ClientEvents)[] = [Events.InteractionCreate];

  async handle(interaction: Interaction) {
    if (
      (!interaction.isStringSelectMenu() && !interaction.isButton()) ||
      !interaction.customId.startsWith("manual_score_")
    )
      return;

    // Check if user has staff permissions
    const member = (await interaction.guild?.members.fetch(interaction.user.id)) as GuildMember;
    const hasPermission =
      member?.roles.cache.has(settings.roles.staff) ||
      member?.roles.cache.has(settings.roles.owner) ||
      member?.roles.cache.has(settings.roles.administrator);

    if (!hasPermission) {
      await interaction.reply({
        embeds: [embeds.error("You must be a staff member to use this.")],
        ephemeral: true,
      });
      return;
    }

    const customIdParts = interaction.customId.split("_");
    const gameId = customIdParts[customIdParts.length - 1];
    const actionType = customIdParts[2];

    const gameDataStr = await App.Redis.get(`manualScore:${gameId}`);

    if (!gameDataStr) {
      await interaction.reply({
        embeds: [
          embeds.error(
            "There doesn't seem to be a manual scoring session for this game. Please use `/score` command instead."
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    const gameData = JSON.parse(gameDataStr) as RedisGameData;

    if (interaction.isStringSelectMenu() && actionType === "mvp") {
      await this.handleMVPSelection(interaction, gameData, gameId);
    } else if (interaction.isButton()) {
      await this.handleTeamWinButton(interaction, gameData, gameId, actionType);
    }
  }

  private async handleMVPSelection(
    interaction: StringSelectMenuInteraction,
    gameData: RedisGameData,
    gameId: string
  ) {
    await interaction.deferReply({ ephemeral: true });

    try {
      gameData.selectedMvps = interaction.values;
      await App.Redis.set(`manualScore:${gameId}`, JSON.stringify(gameData));

      // Get selected player names for display
      const selectedPlayers = gameData.players
        .filter((p: GamePlayerRedisData) => interaction.values.includes(p.userId))
        .map((p: GamePlayerRedisData) => {
          const displayName = p.nickname
            ? `${p.minecraftName} | ${p.nickname}`
            : p.minecraftName;
          return displayName;
        });

      await interaction.editReply({
        embeds: [
          embeds.success(
            `Selected MVPs: ${selectedPlayers.join(", ")}\n\n` +
            `Now click a team win button or void game button to complete the scoring.`,
            "MVPs Updated"
          ),
        ],
      });
    } catch (error) {
      console.error("Error handling MVP selection:", error);
      await interaction.editReply({
        embeds: [embeds.error("Failed to update MVP selection.")],
      });
    }
  }

  private async handleTeamWinButton(
    interaction: ButtonInteraction,
    gameData: RedisGameData,
    gameId: string,
    actionType: string
  ) {
    await interaction.deferReply({ ephemeral: true });

    try {
      // Check if MVPs are selected (unless voiding)
      if (
        actionType !== "void" &&
        (!gameData.selectedMvps || gameData.selectedMvps.length === 0)
      ) {
        await interaction.editReply({
          embeds: [
            embeds.error(
              "You must select at least 1 MVP before scoring the game."
            ),
          ],
        });
        return;
      }

      if (actionType === "void") {
        await this.voidGame(interaction, gameData, gameId);
      } else {
        await this.scoreGame(interaction, gameData, gameId, actionType === "team1" ? 1 : 2);
      }
    } catch (error) {
      console.error("Error handling team win button:", error);
      await interaction.editReply({
        embeds: [embeds.error("Failed to process game scoring.")],
      });
    }
  }

  private async voidGame(
    interaction: ButtonInteraction,
    gameData: RedisGameData,
    gameId: string
  ) {
    try {
      await App.Redis.del(`manualScore:${gameId}`);

      const result = await GameHandler.voidGame(gameId, interaction.guild, false, interaction.user.id);

      await interaction.editReply({
        embeds: [
          embeds.success(result, "Game Voided"),
        ],
      });

      // Edit the original failed game embed
      if (gameData.messageId) {
        const failedGamesChannel = await interaction.guild.channels.fetch(settings.channels.failedGames);
        if (failedGamesChannel && failedGamesChannel.isTextBased()) {
          const originalMessage = await failedGamesChannel.messages.fetch(gameData.messageId);
          if (originalMessage) {
            await originalMessage.edit({
              embeds: [embeds.success(
                `Game **${gameId}** has been voided by ${interaction.user}.`,
                "Game Voided"
              )], components: []
            });
          }
        }
      }
    } catch (error) {
      console.error("Error voiding game:", error);
      throw error;
    }
  }

  private async scoreGame(
    interaction: ButtonInteraction,
    gameData: RedisGameData,
    gameId: string,
    winningTeam: number
  ) {
    try {
      const result = await GameHandler.scoreGame(gameId, interaction.guild, winningTeam, gameData.selectedMvps, interaction.user.id, true);

      await interaction.editReply({
        embeds: [
          embeds.success(result, "Game Scored"),
        ],
      });

      // Edit the original failed game embed
      if (gameData.messageId) {
        const failedGamesChannel = await interaction.guild.channels.fetch(settings.channels.failedGames);
        if (failedGamesChannel && failedGamesChannel.isTextBased()) {
          const originalMessage = await failedGamesChannel.messages.fetch(gameData.messageId);
          if (originalMessage) {
            const scoredEmbed = embeds.success(
              `Game **${gameId}** has been successfully scored by ${interaction.user}!` +
              `\n**Winning Team:** Team ${winningTeam}` +
              `\n**MVPs:** ${gameData.selectedMvps.map(id => `<@${id}>`).join(", ")}`,
              "Game Scored"
            );
            await originalMessage.edit({ embeds: [scoredEmbed], components: [] });
          }
        }
      }
      try { await App.Redis.del(`manualScore:${gameId}`); } catch {}
    } catch (error) {
      console.error("Error scoring game manually:", error);
      throw error;
    }
  }
}
