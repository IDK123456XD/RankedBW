import { ChannelType, Guild, GuildMember, TextChannel } from "discord.js";
import App from "../..";
import _ from "lodash";
import { prisma } from "@common/database/connectors/prisma";
import { TeamVoiceManager } from "../../utils";
import settings, { ALLOWED_MAPS } from "../../settings";
import sendLogs from "../../utils/logs";
import { Season, Settings } from "@common/database/generated";
import { safeVoiceMove, generateGameId, sendGameStartEmbeds } from "./game";

type TimedMember = {
    member: GuildMember;
    joinedAt: number;
}

export default async function handleRandomPicking(members: GuildMember[], teamSize: number) {
    const membersJoinedQueue = (await Promise.all(members.map(async (member) => {
        const joinedAt = await App.Redis.get(`queueJoined:${member.id}`);
        return {
            member,
            joinedAt: joinedAt ? Number(joinedAt) : Date.now()
        };
    }))).sort((a, b) => a.joinedAt - b.joinedAt);

    // Party filtering is now done before this function is called
    // We only need to group the members that are passed in
    const groupedPeople: TimedMember[][] = [];
    const processedMemberIds = new Set<string>();
    
    for (const tm of membersJoinedQueue) {
        // Skip if already processed as part of a party
        if (processedMemberIds.has(tm.member.id)) {
            continue;
        }
        
        const party = await prisma.party.findFirst({
            where: {
                OR: [
                    {
                        leader: tm.member.id
                    },
                    {
                        members: {
                            has: tm.member.id
                        }
                    }
                ]
            }
        });
        
        if (!party) {
            // Solo player
            groupedPeople.push([tm]);
            processedMemberIds.add(tm.member.id);
        } else {
            // Full party (we know it's complete because filtering already happened)
            const partyIds = _.uniq([party.leader, ...party.members]);
            const pm = membersJoinedQueue.filter((x) =>
                partyIds.includes(x.member.id)
            );
            groupedPeople.push(pm);
            // Mark all party members as processed
            pm.forEach(member => processedMemberIds.add(member.member.id));
        }
    }

    const slots = teamSize * 2;
    const groups = groupedPeople.map((group) => {
        const times = group.map((x) => Number(x.joinedAt));
        return {
            size: group.length,
            effectiveTime: Math.min(...times),
            members: group,
        };
    });

    const dp: ({ maxTime: number; indices: number[] } | null)[] = Array(
        slots + 1
    ).fill(null);
    dp[0] = { maxTime: 0, indices: [] };

    for (let i = 0; i < groups.length; i++) {
        const { size, effectiveTime } = groups[i];
        for (let s = slots; s >= size; s--) {
            const prev = dp[s - size];
            if (!prev) continue;
            const newMax = Math.max(prev.maxTime, effectiveTime);
            const cur = dp[s];
            if (!cur || newMax < cur.maxTime) {
                dp[s] = { maxTime: newMax, indices: [...prev.indices, i] };
            }
        }
    }

    if (!dp[slots]) return null;

    const selectedGroups = dp[slots]!.indices.map((i) => groups[i]);

    function splitIntoRandomTeams() {
        const shuffledGroups = shuffleArray(selectedGroups);
        const team1: TimedMember[] = [];
        let success = false;

        function dfs(idx: number, count: number) {
            if (count === teamSize) {
                success = true;
                return;
            }
            if (count > teamSize || idx === shuffledGroups.length) return;

            // randomize include/exclude order
            const tryIncludeFirst = Math.random() < 0.5;
            const opts: ("include" | "exclude")[] = tryIncludeFirst
                ? ["include", "exclude"]
                : ["exclude", "include"];

            for (const opt of opts) {
                if (opt === "include") {
                    const grp = shuffledGroups[idx];
                    if (count + grp.members.length <= teamSize) {
                        team1.push(...grp.members);
                        dfs(idx + 1, count + grp.members.length);
                        if (success) return;
                        team1.splice(team1.length - grp.members.length, grp.members.length);
                    }
                } else {
                    dfs(idx + 1, count);
                    if (success) return;
                }
            }
        }

        dfs(0, 0);
        if (!success) {
            throw new Error("Unable to split selected groups into equal teams");
        }

        const team2Members = shuffledGroups
            .flatMap((g) => g.members)
            .filter((tm) => !team1.includes(tm));

        return { team1, team2: team2Members };
    }

    const { team1, team2 } = splitIntoRandomTeams();

    for (const member of team1) {
        await App.Redis.del(`queueJoined:${member.member.id}`);
    }
    for (const member of team2) {
        await App.Redis.del(`queueJoined:${member.member.id}`);
    }

    return {
        team1: team1.map((tm) => tm.member),
        team2: team2.map((tm) => tm.member),
    };
}

function shuffleArray<T>(arr: T[]): T[] {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

/**
 * Create game data for a random team game and start the game
 */
export async function createRandomTeamGame(guild: Guild, team1: GuildMember[], team2: GuildMember[], dbSettings: Settings, season: Season, originQueueChannelId?: string) {
    const membersQueued = team1.concat(team2);

    // FIRST: Check if voice channels are available BEFORE creating anything
    await TeamVoiceManager.optionallyCreateChannelPair(guild);

    const availableChannelPair = await TeamVoiceManager.findAvailableChannelPair(guild);
    if (!availableChannelPair) {
        console.log(`No available voice channel pair found for game, aborting game creation`);
        return;
    }
    
    // ONLY create gameId after confirming channels are available
    const nanoid = await generateGameId();

    // Reserve the channel pair
    await TeamVoiceManager.reserveChannelPair(availableChannelPair, nanoid);
    
    // Store game creation timestamp for grace period checks
    await App.Redis.set(`gameCreatedAt:${nanoid}`, Date.now().toString());

    const queueGamesTextChannel = await guild.channels.fetch(settings.channels.games);
    if (!(queueGamesTextChannel instanceof TextChannel)) return;

    // Double-check that we still have valid voice channels before creating thread
    const team1Channel = guild.channels.cache.get(availableChannelPair.team1.id);
    const team2Channel = guild.channels.cache.get(availableChannelPair.team2.id);
    if (!team1Channel?.isVoiceBased() || !team2Channel?.isVoiceBased()) {
        console.error(`Voice channels became invalid for game ${nanoid}, aborting`);
        await sendLogs(`Game creation aborted for Game **#${nanoid}** - voice channels became invalid`, "Game Creation Error");
        return;
    }

    const queueThreadChannel = await queueGamesTextChannel.threads.create({
        name: `Game ${nanoid}`,
        type: ChannelType.PrivateThread,
        invitable: false,
    });

    await queueThreadChannel.send({
        content: membersQueued.map((x) => x.toString()).join(" "),
    });

    await sendLogs(`Queue created for Game **#${nanoid}**!`, "Queue Created");

    // Set up the team channels using the TeamVoiceManager
    await TeamVoiceManager.setupChannelsForGame(
        guild,
        { gameId: nanoid, team1: availableChannelPair.team1.id, team2: availableChannelPair.team2.id },
        nanoid,
        team1.map(x => x.id),
        team2.map(x => x.id)
    );

    // Create game players data for database
    const team1Ids = team1.map(x => x.id);
    const team2Ids = team2.map(x => x.id);

    const [team1Stats, team2Stats] = await Promise.all([
        Promise.all(team1Ids.map(userId => prisma.playerStatistics.findFirst({
            where: { player: { userId }, seasonId: season.id },
            include: { player: true }
        }).then(stat => ({ stat, userId })))),
        Promise.all(team2Ids.map(userId => prisma.playerStatistics.findFirst({
            where: { player: { userId }, seasonId: season.id },
            include: { player: true }
        }).then(stat => ({ stat, userId }))))
    ]);

    const gamePlayers: { statistics: any; team: number }[] = [];
    for (const { stat } of team1Stats) {
        if (stat) gamePlayers.push({ statistics: stat, team: 1 });
    }
    for (const { stat } of team2Stats) {
        if (stat) gamePlayers.push({ statistics: stat, team: 2 });
    }

    // Move players to team voice channels with proper error handling and retries
    const moveResults = await Promise.all([
        ...team1.map(member => safeVoiceMove(member, availableChannelPair.team1.id, nanoid)),
        ...team2.map(member => safeVoiceMove(member, availableChannelPair.team2.id, nanoid))
    ]);

    const successfulMoves = moveResults.filter(result => result === true).length;
    const totalPlayers = team1.length + team2.length;

    // Retry failed moves after a short delay
    if (successfulMoves < totalPlayers) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        await Promise.all([
            ...team1.map(member => safeVoiceMove(member, availableChannelPair.team1.id, nanoid)),
            ...team2.map(member => safeVoiceMove(member, availableChannelPair.team2.id, nanoid))
        ]);
    }

    // Final retry after additional delay for any stragglers
    setTimeout(async () => {
        await Promise.all([
            ...team1.map(member => safeVoiceMove(member, availableChannelPair.team1.id, nanoid)),
            ...team2.map(member => safeVoiceMove(member, availableChannelPair.team2.id, nanoid))
        ]);
    }, 3000);

    await sendLogs(
        `Game **#${nanoid}** created - attempting to move players to team channels`,
        "Team Channels Created"
    );

    const enabledMaps = ALLOWED_MAPS.filter(x => x.gameStyle.some(y => y === dbSettings.gameStyle) && x.in_rotation);
    
    if (enabledMaps.length === 0) {
        console.error(`[GAME-CREATE] No enabled maps found for game style ${dbSettings.gameStyle} in game ${nanoid}`);
        await sendLogs(
            `⚠️ Game **#${nanoid}** creation failed - no maps available for game style ${dbSettings.gameStyle}`,
            "Map Selection Error"
        );
        // Cleanup: release channels and close thread
        await TeamVoiceManager.resetChannelsAfterGame(guild, nanoid, true);
        await queueThreadChannel.setArchived(true).catch(() => {});
        return;
    }
    
    const randomMap = enabledMaps[Math.floor(Math.random() * enabledMaps.length)];

    await prisma.game.create({
        data: {
            players: {
                create: gamePlayers.map((x) => ({
                    userId: x.statistics.playerId,
                    discordTeam: x.team,
                    preElo: x.statistics.elo,
                })),
            },
            gameId: nanoid,
            queueThreadChannelId: queueThreadChannel.id,
            team1Voice: availableChannelPair.team1.id,
            mapPlaying: randomMap.name,
            team2Voice: availableChannelPair.team2.id,
            gameStyle: dbSettings.gameStyle,
            season: {
                connect: {
                    id: season.id,
                },
            },
        },
    });

    if (originQueueChannelId) {
        try { await App.Redis.setex(`queueOrigin:${nanoid}`, 3600, originQueueChannelId); } catch {}
    }

    // Send all game start embeds and instructions
    await sendGameStartEmbeds(
        queueThreadChannel,
        nanoid,
        season,
        dbSettings,
        team1,
        team2,
        availableChannelPair.team1,
        availableChannelPair.team2,
        randomMap.name,
        randomMap.height_limit,
        gamePlayers
    );
}