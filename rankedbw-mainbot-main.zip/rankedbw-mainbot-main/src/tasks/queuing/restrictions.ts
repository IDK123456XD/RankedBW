import { Guild, GuildMember, TextChannel } from "discord.js";
import App from "../..";
import { prisma } from "@common/database/connectors/prisma";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import settings from "../../settings";
import { QueueRestrictions } from "@common/database/redis/schemas/QueueRestrictions";

type Removal = { member: GuildMember; reason: string };

async function fetchAlertsChannel(guild: Guild): Promise<TextChannel | null> {
  const channel = await guild.channels.fetch(settings.channels.alerts);
  return channel?.isTextBased() ? (channel as TextChannel) : null;
}

async function fetchQueueRestrictions(queueChannelId: string): Promise<QueueRestrictions | null> {
  const data = await App.Redis.get("queueRestrictions");
  const list = data ? JSON.parse(data) : [];
  return list.find((r: QueueRestrictions) => r.queueChannelId === queueChannelId) || null;
}

function isRankBanned(member: GuildMember) {
  return member.roles.cache.has(settings.roles.rankedBan);
}

async function checkElo(finalElo: number, restriction: QueueRestrictions): Promise<string | null> {
  if (restriction.minElo !== -1 && finalElo < restriction.minElo) {
    return `You need ${restriction.minElo} Elo (run \`/update\` to update your elo)`;
  }
  if (restriction.maxElo !== -1 && restriction.maxElo !== 9999 && finalElo > restriction.maxElo) {
    return `Queue capped at ${restriction.maxElo} Elo.`;
  }
  return null;
}

async function moveToWaiting(member: GuildMember) {
  await App.Redis.publish(
    "queue:move",
    JSON.stringify({
      memberId: member.id,
      channelId: settings.voiceChannels.waitingRoom,
      guildId: settings.guild,
    })
  );
}

async function notifyAlerts(channel: TextChannel, removals: Removal[]) {
  for (const { member, reason } of removals) {
    await channel.send(`${member}: ${reason}`);
  }
}

export default async function checkQueueRestrictions(
  guild: Guild,
  queueChannelId: string,
  members: GuildMember[]
): Promise<GuildMember[]> {
  if (!members.length) return [];

  const alerts = await fetchAlertsChannel(guild);
  const restriction = await fetchQueueRestrictions(queueChannelId);

  // Validation phase
  const validMembers: GuildMember[] = [];
  const validationRemovals: Removal[] = [];

  for (const member of members) {
    if (isRankBanned(member)) {
      await moveToWaiting(member);
      validationRemovals.push({ member, reason: "You cannot queue while ranked banned." });
      console.log(`[Restrict][${queueChannelId}] remove ${member.id} reason=rank_banned`);
      continue;
    }

    const party = await prisma.party.findFirst({
      where: {
        OR: [
          { leader: member.id },
          { members: { has: member.id } }
        ]
      }
    });

    const isLeader = !party || party.leader === member.id;
    const targetUserId = isLeader ? member.id : party?.leader;

    const targetStats = await prisma.player.findFirst({
      where: { userId: targetUserId },
      include: IncludeCurrentSeasonStatistics
    });
    const targetGuildMember = await guild.members.fetch(targetUserId);

  const activeStat = targetStats?.PlayerStatistics.find((ps: any) => ps.season.active);
    const finalElo = activeStat?.elo ?? 0;
    const hasSpecial = !!restriction?.specialRoles?.find(r => targetGuildMember.roles.cache.has(r));

    // ––– PRIVILEGED BYPASS (Owner/Administrator) –––
    const isPrivileged =
      targetGuildMember.roles.cache.has(settings.roles.owner) ||
      targetGuildMember.roles.cache.has(settings.roles.administrator);
    if (isPrivileged) {
      validMembers.push(member);
      continue;
    }

    if (hasSpecial && (restriction.maxElo === -1 || finalElo <= restriction.maxElo)) {
      validMembers.push(member);
      continue;
    }

    // ––– NORMAL ELO CHECK –––
    const eloReason = restriction ? await checkElo(finalElo, restriction) : null;
    if (eloReason) {
      await moveToWaiting(member);
      validationRemovals.push({ member, reason: eloReason });
      console.log(`[Restrict][${queueChannelId}] remove ${member.id} reason=elo '${eloReason}' finalElo=${finalElo}`);
      continue;
    }

    // ––– NORMAL ROLE CHECK –––
    if (restriction?.requiredRoles?.length) {
      const hasRequired = restriction.requiredRoles.some(r => targetGuildMember.roles.cache.has(r));
      if (!hasRequired) {
        await moveToWaiting(member);
        validationRemovals.push({
          member,
          reason: "You do not have the required role to access this queue (run \``/update`\` to update your roles)."
        });
        console.log(`[Restrict][${queueChannelId}] remove ${member.id} reason=missing_required_role rolesNeeded=${restriction.requiredRoles.join(',')}`);
        continue;
      }
    }

    if (!restriction) {
      console.log(`[Restrict][${queueChannelId}] allow ${member.id} reason=no_restriction`);
    }
    else {
      console.log(`[Restrict][${queueChannelId}] allow ${member.id} finalElo=${finalElo}`);
    }

    validMembers.push(member);
  }

  // Notify via alerts channel
  if (alerts && validationRemovals.length) {
    await notifyAlerts(alerts, validationRemovals);
  }

  return validMembers;
}