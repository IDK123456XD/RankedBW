import { GuildMember, ThreadChannel, VoiceBasedChannel } from "discord.js";
import { customAlphabet } from "nanoid";
import settings from "../../settings";
import App from "../..";
import { prisma } from "@common/database/connectors/prisma";
import _ from "lodash";
import embeds from "../../utils/discord/embeds";
import { Season, Settings } from "@common/database/generated";

/**
 * Safe voice move function to move a member to a target channel
 * Makes sure the member is not in a queue channel and that the target channel is available
 * Now performs synchronous moves with proper error handling and validation
 */
export async function safeVoiceMove(member: GuildMember, targetChannelId: string, gameId: string): Promise<boolean> {
    try {
        // Check if member is in a voice channel
        if (!member.voice?.channelId) {
            return false;
        }

        const currentChannelId = member.voice.channelId;
        const queueChannelIds = [
            settings.voiceChannels.queue1,
            settings.voiceChannels.queue2, 
            settings.voiceChannels.queue3,
            settings.voiceChannels.queue4,
            settings.voiceChannels.queue5,
            settings.voiceChannels.queue6,
            settings.voiceChannels.waitingRoom
        ];
        
        // Check if user is in another game's voice channel (not queue/waiting room)
        if (!queueChannelIds.includes(currentChannelId)) {
            const inUseData = await App.Redis.get('teamVoiceChannelsInUse');
            if (inUseData) {
                const inUseChannels: string[] = JSON.parse(inUseData);
                if (inUseChannels.includes(currentChannelId)) {
                    const allGameKeys = await App.Redis.keys('teamVoiceGame:*');
                    for (const key of allGameKeys) {
                        const keyGameId = key.replace('teamVoiceGame:', '');
                        if (keyGameId === gameId) continue;
                        
                        const gameChannelsData = await App.Redis.get(key);
                        if (gameChannelsData) {
                            const gameChannels = JSON.parse(gameChannelsData);
                            if (gameChannels.team1 === currentChannelId || gameChannels.team2 === currentChannelId) {
                                return false;
                            }
                        }
                    }
                }
            }
        }

        // Perform the actual voice channel move with proper error handling
        try {
            await member.voice.setChannel(targetChannelId);
            return true;
        } catch (moveError: any) {
            // Log specific error details
            if (moveError.code === 10003) {
                console.error(`[VOICE-MOVE] Unknown channel ${targetChannelId} for ${member.displayName}`);
            } else if (moveError.code === 50013) {
                console.error(`[VOICE-MOVE] Missing permissions to move ${member.displayName} to ${targetChannelId}`);
            } else if (moveError.code === 40032) {
                console.error(`[VOICE-MOVE] Target voice channel ${targetChannelId} is full for ${member.displayName}`);
            } else {
                console.error(`[VOICE-MOVE] Failed to move ${member.displayName} to ${targetChannelId}:`, moveError.message || moveError);
            }
            return false;
        }
    } catch (error) {
        console.error(`[VOICE-MOVE] Unexpected error during voice move for ${member.displayName}:`, error);
        return false;
    }
}

/**
 * Generates a unique game id for a game
 */
export async function generateGameId(): Promise<string> {
    // Keep generating a random game id until it is unique
    const nanoid = customAlphabet("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", 4)();
    const game = await prisma.game.findFirst({
        where: {
            gameId: nanoid,
        },
    });
    if (game) return generateGameId();
    return nanoid;
}

/**
 * Sends the game start embeds and instructions to the thread channel.
 * This includes the team roster, ruleset, map info, party commands, and final instructions.
 */
export async function sendGameStartEmbeds(
    threadChannel: ThreadChannel,
    gameId: string,
    season: Season,
    dbSettings: Settings,
    team1: GuildMember[],
    team2: GuildMember[],
    team1VoiceChannel: VoiceBasedChannel | string,
    team2VoiceChannel: VoiceBasedChannel | string,
    mapName: string,
    mapHeightLimit: string | number,
    gamePlayers: { statistics: any; team: number }[],
    team1Captain?: GuildMember,
    team2Captain?: GuildMember
): Promise<void> {
    // Use provided captains (for captain picking) or select random ones (for random teams)
    const captain1 = team1Captain || _.sample(team1);
    const captain2 = team2Captain || _.sample(team2);

    // Format voice channel display (handle both VoiceBasedChannel objects and string IDs)
    const team1VoiceDisplay = typeof team1VoiceChannel === 'string' 
        ? `<#${team1VoiceChannel}>` 
        : team1VoiceChannel.toString();
    const team2VoiceDisplay = typeof team2VoiceChannel === 'string' 
        ? `<#${team2VoiceChannel}>` 
        : team2VoiceChannel.toString();

    // Send team roster embed
    await threadChannel.send({
        embeds: [
            embeds
                .normal(
                    undefined,
                    `Game ${gameId} | ${season?.name || "Unknown Season"}`,
                    false
                )
                .addFields([
                    {
                        name: "Team 1",
                        value: team1VoiceDisplay,
                        inline: true,
                    },
                    {
                        name: "Team 2",
                        value: team2VoiceDisplay,
                        inline: true,
                    },
                    {
                        name: "\t",
                        value: "\t",
                        inline: true,
                    },
                    {
                        name: "\t",
                        value: captain1.toString() + '\n' + team1.filter(x => x.id !== captain1.id).map(x => x.toString()).join('\n'),
                        inline: true,
                    },
                    {
                        name: "\t",
                        value: captain2.toString() + '\n' + team2.filter(x => x.id !== captain2.id).map(x => x.toString()).join('\n'),
                        inline: true,
                    },
                    {
                        name: "\t",
                        value: "\t",
                        inline: true,
                    },
                ]),
        ],
        components: [],
    });

    // Send game info embeds (ruleset, map, party commands)
    const embedsToSend = [
        embeds.normal(dbSettings.ruleset, season.name, false),
        embeds.normal(
            `**${mapName}**: \`${mapHeightLimit}\``,
            `Chosen Map`,
            false
        ),
        embeds.normal(
            `\`\`\`/p ${gamePlayers.filter((x) => x.team === 1)
                .map((x) => x.statistics.player.minecraftName)
                .join(" ")}\`\`\`\n` +
            `\`\`\`/p ${gamePlayers.filter((x) => x.team === 2)
                .map((x) => x.statistics.player.minecraftName)
                .join(" ")}\`\`\``,
            `Party Commands`,
            false
        )
    ];

    for (const embed of embedsToSend) {
        await threadChannel.send({
            embeds: [embed],
        });
    }

    // Send final instructions
    await threadChannel.send({
        content: `Once the game is finished, use \`/submit <screenshot>\`. Use \`/cancel\` to cancel (void) the game.`,
        embeds: [
            embeds.normal(
                `If you are playing on a different Minecraft account, use \`/rename <username>\`. If you are nicked on Hypixel, use \`/nick <nickname>\`.\nFailure to do so could lead to delays in the scoring process.`,
                null,
                false
            ),
        ],
    });
}