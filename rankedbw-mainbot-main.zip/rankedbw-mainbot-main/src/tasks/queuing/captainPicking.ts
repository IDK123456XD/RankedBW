import { Guild, GuildMember, TextChannel, ThreadChannel, ActionRowBuilder, StringSelectMenuBuilder, ComponentType, InteractionCollector, ChannelType, PermissionsBitField, VoiceChannel } from "discord.js";
import { customAlphabet } from "nanoid";
import { TeamVoiceManager } from "../../utils";
import settings, { ALLOWED_MAPS } from "../../settings";
import sendLogs from "../../utils/logs";
import App from "../..";
import { prisma } from "@common/database/connectors/prisma";
import _ from "lodash";
import embeds from "../../utils/discord/embeds";
import { Season, Settings, PickingTypes, GameStatus } from "@common/database/generated";
import { safeVoiceMove, generateGameId, sendGameStartEmbeds } from "./game";

type PickingOrder = {
    team1Picks: number[];
    team2Picks: number[];
};

const PICKING_ORDERS: Record<PickingTypes, PickingOrder> = {
    [PickingTypes.one]: {
        team1Picks: [1, 3, 5],
        team2Picks: [2, 4, 6]
    },
    [PickingTypes.two]: {
        team1Picks: [1, 4, 5],
        team2Picks: [2, 3, 6]
    },
    [PickingTypes.random]: {
        team1Picks: [],
        team2Picks: []
    }
};

interface CaptainPickingSession {
    gameId: string;
    sessionId: string; 
    guild: Guild;
    threadChannel: ThreadChannel;
    team1VoiceChannel: string;
    team2VoiceChannel: string;
    allPlayers: GuildMember[];
    team1Players: GuildMember[];
    team2Players: GuildMember[];
    unpickedPlayers: GuildMember[];
    currentPickNumber: number;
    pickingOrder: PickingOrder;
    team1Captain: GuildMember;
    team2Captain: GuildMember;
    dbSettings: Settings;
    season: Season;
    collector?: InteractionCollector<any>;
    pickTimeout?: NodeJS.Timeout;
    currentPickMessage?: any;
    completed?: boolean;
    completePickingRan?: boolean; 
    completionWatchdog?: NodeJS.Timeout;
    aborted?: boolean;
}

// Store active sessions in memory so we can clean them up with the close command
const activePickingSessions = new Map<string, CaptainPickingSession>();

// Function to abort a picking session (called when /close is used)
async function abortPickingSession(gameId: string): Promise<void> {
    const session = activePickingSessions.get(gameId);
    if (!session) {
        console.log(`No active picking session found for game ${gameId}`);
        return;
    }

    console.log(`Aborting picking session for game ${gameId}`);
    session.aborted = true;
    session.completed = true;

    // Clear all timeouts
    if (session.pickTimeout) {
        clearTimeout(session.pickTimeout);
        session.pickTimeout = undefined;
    }
    if (session.completionWatchdog) {
        clearTimeout(session.completionWatchdog);
        session.completionWatchdog = undefined;
    }

    // Stop the collector
    if (session.collector) {
        try {
            session.collector.stop('aborted');
        } catch (e) {
            console.error(`Error stopping collector for game ${gameId}:`, e);
        }
    }

    // Disable current pick message
    if (session.currentPickMessage) {
        try {
            await session.currentPickMessage.edit({ components: [] }).catch(() => {});
        } catch (e) {
            console.error(`Error disabling pick message for game ${gameId}:`, e);
        }
    }

    // Clean up Redis
    try {
        await App.Redis.del(`activePicking:${gameId}`);
        await App.Redis.del(`pickLock:${gameId}`);
    } catch (e) {
        console.error(`Error cleaning up Redis for aborted picking ${gameId}:`, e);
    }

    // Remove from active sessions
    activePickingSessions.delete(gameId);
    console.log(`Successfully aborted picking session for game ${gameId}`);
}

// Export the abort function so close.ts can use it
export { abortPickingSession };

// Function to clean up picking session resources
async function cleanupPickingSession(session: CaptainPickingSession): Promise<void> {
    console.log(`Cleaning up picking session for game ${session.gameId}`);

    // Clear all timeouts
    if (session.pickTimeout) {
        clearTimeout(session.pickTimeout);
        session.pickTimeout = undefined;
    }
    if (session.completionWatchdog) {
        clearTimeout(session.completionWatchdog);
        session.completionWatchdog = undefined;
    }

    // Stop the collector
    if (session.collector) {
        try {
            session.collector.stop('cleanup');
        } catch (e) {
            console.error(`Error stopping collector during cleanup for ${session.gameId}:`, e);
        }
    }

    // Clean up Redis keys
    try {
        await App.Redis.del(`activePicking:${session.gameId}`);
        await App.Redis.del(`pickLock:${session.gameId}`);
    } catch (e) {
        console.error(`Error cleaning up Redis keys for ${session.gameId}:`, e);
    }

    // Remove from active sessions map
    activePickingSessions.delete(session.gameId);
}

function selectCaptains(players: GuildMember[]): { team1Captain: GuildMember; team2Captain: GuildMember } {
    const shuffled = _.shuffle(players);
    return {
        team1Captain: shuffled[0],
        team2Captain: shuffled[1]
    };
}

async function validateCaptainsHaveStats(captains: GuildMember[], season: Season): Promise<{ valid: boolean; missingStats: GuildMember[] }> {
    const missingStats: GuildMember[] = [];
    
    for (const captain of captains) {
        const statistics = await prisma.playerStatistics.findFirst({
            where: {
                player: { userId: captain.id },
                seasonId: season.id
            },
            include: { player: true }
        });
        
        if (!statistics) {
            missingStats.push(captain);
        }
    }
    
    return {
        valid: missingStats.length === 0,
        missingStats
    };
}

function createPickingEmbed(session: CaptainPickingSession) {
    const { team1Captain, team2Captain, team1Players, team2Players, unpickedPlayers, currentPickNumber, pickingOrder } = session;
    
    const isTeam1Turn = pickingOrder.team1Picks.includes(currentPickNumber);
    const currentCaptain = isTeam1Turn ? team1Captain : team2Captain;
    
    const team1Display = team1Players.length > 0 
        ? `${team1Captain.toString()}\n${team1Players.filter(p => p.id !== team1Captain.id).map(p => p.toString()).join('\n')}`
        : `${team1Captain.toString()}\n_Empty slots_`;
    
    const team2Display = team2Players.length > 0 
        ? `${team2Captain.toString()}\n${team2Players.filter(p => p.id !== team2Captain.id).map(p => p.toString()).join('\n')}`
        : `${team2Captain.toString()}\n_Empty slots_`;
    
    const unpickedDisplay = unpickedPlayers.length > 0 
        ? unpickedPlayers.map(p => p.toString()).join('\n')
        : '_No players left_';
    
    return embeds.normal(
        `**Pick ${currentPickNumber} of ${pickingOrder.team1Picks.length + pickingOrder.team2Picks.length}**`,
        `Game ${session.gameId} | ${session.season?.name || "Unknown Season"} | Picking`,
        false
    ).addFields([
        {
            name: "Team 1",
            value: `<#${session.team1VoiceChannel}>\n\n${team1Display}`,
            inline: true,
        },
        {
            name: "Team 2", 
            value: `<#${session.team2VoiceChannel}>\n\n${team2Display}`,
            inline: true,
        },
        {
            name: "Unpicked Players",
            value: unpickedDisplay,
            inline: true,
        },
    ]);
}

function createPlayerSelectMenu(session: CaptainPickingSession): ActionRowBuilder<StringSelectMenuBuilder> {
    const { unpickedPlayers, currentPickNumber, pickingOrder } = session;
    
    const isTeam1Turn = pickingOrder.team1Picks.includes(currentPickNumber);
    const currentCaptain = isTeam1Turn ? session.team1Captain : session.team2Captain;
    
    const options = unpickedPlayers.slice(0, 25).map(player => ({
        label: player.displayName,
        description: `Pick ${player.displayName}`,
        value: player.id
    }));

    return new ActionRowBuilder<StringSelectMenuBuilder>()
        .addComponents(
            new StringSelectMenuBuilder()
                .setCustomId(`captain-pick:${session.gameId}:${session.sessionId}:${currentPickNumber}`)
                .setPlaceholder(`Select a player to pick...`)
                .addOptions(options)
        );
}

async function sendCurrentTeamsStatus(session: CaptainPickingSession) {
    const { currentPickNumber, pickingOrder, team1Captain, team2Captain, team1Players, team2Players, unpickedPlayers } = session;
    const isTeam1Turn = pickingOrder.team1Picks.includes(currentPickNumber);
    const currentCaptain = isTeam1Turn ? team1Captain : team2Captain;
    const teamName = isTeam1Turn ? "Team 1" : "Team 2";
    
    const team1Display = team1Players.length > 0 
        ? `${team1Captain.toString()}\n${team1Players.filter(p => p.id !== team1Captain.id).map(p => p.toString()).join('\n')}`
        : `${team1Captain.toString()}\n_Empty slots_`;
    
    const team2Display = team2Players.length > 0 
        ? `${team2Captain.toString()}\n${team2Players.filter(p => p.id !== team2Captain.id).map(p => p.toString()).join('\n')}`
        : `${team2Captain.toString()}\n_Empty slots_`;
    
    const unpickedDisplay = unpickedPlayers.length > 0 
        ? unpickedPlayers.map(p => p.toString()).join('\n')
        : '_No players left_';
    
    // Create dropdown for this pick
    const components = unpickedPlayers.length > 0 ? [createPlayerSelectMenu(session)] : [];
    
    const message = await session.threadChannel.send({
        content: `${currentCaptain.toString()}, it's your turn to pick for **${teamName}**!`,
        embeds: [
            embeds.normal(
                `**Pick ${currentPickNumber} of ${pickingOrder.team1Picks.length + pickingOrder.team2Picks.length}**`,
                `Current Teams - Game ${session.gameId}`,
                false
            ).addFields([
                {
                    name: "Team 1",
                    value: team1Display,
                    inline: true,
                },
                {
                    name: "Team 2", 
                    value: team2Display,
                    inline: true,
                },
                {
                    name: "Unpicked Players",
                    value: unpickedDisplay,
                    inline: true,
                }
            ])
        ],
        components: components
    });

    return message;
}

async function sendPickConfirmation(session: CaptainPickingSession, pickedPlayer: GuildMember, captain: GuildMember, teamNumber: number) {
    const teamName = `Team ${teamNumber}`;
    
    await session.threadChannel.send({
        content: `${captain.toString()} has picked ${pickedPlayer.toString()} for **${teamName}**!`
    });
}

function startPickTimeout(session: CaptainPickingSession) {
    const pickCfg = (settings as any).features?.picking;
    if (!pickCfg || pickCfg.enableTimeout === false) {
        if (session.pickTimeout) {
            clearTimeout(session.pickTimeout);
            session.pickTimeout = undefined;
        }
        return;
    }
    if (session.pickTimeout) {
        clearTimeout(session.pickTimeout);
    }
    const PICK_TIMEOUT_MS = typeof pickCfg.timeoutMs === 'number' ? pickCfg.timeoutMs : 60000; 
    session.pickTimeout = setTimeout(async () => {
        await handlePickTimeout(session);
    }, PICK_TIMEOUT_MS);
}

async function handlePickTimeout(session: CaptainPickingSession) {
    // Check if session has been aborted
    if (session.aborted || session.completed) {
        console.log(`Picking session ${session.gameId} aborted/completed, skipping timeout handler`);
        return;
    }

    const pickCfg = (settings as any).features?.picking;
    if (!pickCfg || pickCfg.enableTimeout === false) {
        // If timeout is disabled, just continue picking without any timeout
        if (session.unpickedPlayers.length > 0 && session.currentPickNumber <= session.pickingOrder.team1Picks.length + session.pickingOrder.team2Picks.length) {
            session.currentPickMessage = await sendCurrentTeamsStatus(session);
        }
        return; 
    }
    // Check if picking is still active
    if (session.unpickedPlayers.length === 0 || session.currentPickNumber > session.pickingOrder.team1Picks.length + session.pickingOrder.team2Picks.length) {
        return;
    }
    
    const { unpickedPlayers, currentPickNumber, pickingOrder } = session;
    const isTeam1Turn = pickingOrder.team1Picks.includes(currentPickNumber);
    const currentCaptain = isTeam1Turn ? session.team1Captain : session.team2Captain;
    
    if (pickCfg.autoRandomOnTimeout) {
        const redisLockKey = `pickLock:${session.gameId}`;
        const snapshotPickNumber = session.currentPickNumber;
        const acquired = await App.Redis.set(redisLockKey, Date.now().toString(), 'EX', 5, 'NX').catch((_: unknown): null => null);
        if (!acquired || (session as any)._pickLock) {
            return;
        }
        (session as any)._pickLock = true;
        try {
            if (session.completed) return;
            if (snapshotPickNumber !== session.currentPickNumber) return; 
            const stillUnpicked = session.unpickedPlayers;
            if (stillUnpicked.length === 0) return;
            const randomPlayer = _.sample(stillUnpicked);
            if (!randomPlayer) return;
            if (!stillUnpicked.find(p => p.id === randomPlayer.id)) return;
            await session.threadChannel.send({
                embeds: [
                    embeds.warning(
                        `${currentCaptain.displayName} took too long to pick. Randomly assigned **${randomPlayer.displayName}** to their team.`,
                        "Pick Timeout"
                    )
                ]
            });
            const success = await handlePlayerPickInternal(session, randomPlayer.id);
            if (!success) return;
            if (session.currentPickMessage) {
                await session.currentPickMessage.edit({ components: [] }).catch(() => {});
            }
            if (!session.completed && session.unpickedPlayers.length > 0 && session.currentPickNumber <= session.pickingOrder.team1Picks.length + session.pickingOrder.team2Picks.length) {
                session.currentPickMessage = await sendCurrentTeamsStatus(session);
                startPickTimeout(session);
            }
        } finally {
            (session as any)._pickLock = false;
            try { await App.Redis.del(redisLockKey); } catch {}
        }
    } else {
        await session.threadChannel.send({
            embeds: [
                embeds.warning(
                    `${currentCaptain.displayName} took too long to pick. (No auto-pick configured)`,
                    "Pick Timeout"
                )
            ]
        });
        if (session.unpickedPlayers.length > 0) {
            startPickTimeout(session);
        }
        return;
    }
    
    // Update the main picking embed to reflect the pick
    const newEmbed = createPickingEmbed(session);
    
    // Find the main picking message to update
    const messages = await session.threadChannel.messages.fetch({ limit: 10 });
    const mainPickingMessage = messages.find(msg => 
        msg.embeds.length > 0 && 
        msg.embeds[0].title?.includes('Picking') && 
        msg.author.id === session.guild.members.me?.id
    );
    
    if (mainPickingMessage) {
        await mainPickingMessage.edit({
            embeds: [newEmbed],
            components: []
        });
    }

    // Disable the current pick message since timeout occurred
    if (session.currentPickMessage) {
        await session.currentPickMessage.edit({
            components: []
        }).catch(() => {}); // Ignore errors if message is already deleted
    }

    // Check if picking is complete (this might have been completed in handlePlayerPickInternal)
    if (session.currentPickNumber > session.pickingOrder.team1Picks.length + session.pickingOrder.team2Picks.length) {
        // Picking was completed, no need to continue
        return;
    }

    // Start timeout and send teams status if there are still players to pick
    if (session.unpickedPlayers.length > 0 && session.currentPickNumber <= session.pickingOrder.team1Picks.length + session.pickingOrder.team2Picks.length) {
        // Send new pick message and store it
        session.currentPickMessage = await sendCurrentTeamsStatus(session);
        startPickTimeout(session);
    }
}

async function handlePlayerPickInternal(session: CaptainPickingSession, selectedPlayerId: string, sendConfirmation: boolean = true): Promise<boolean> {
    // Check if session has been aborted
    if (session.aborted) {
        console.log(`Picking session ${session.gameId} aborted, rejecting pick`);
        return false;
    }

    const { team1Players, team2Players, unpickedPlayers, currentPickNumber, pickingOrder, team1Captain, team2Captain } = session;
    
    const selectedPlayer = unpickedPlayers.find(p => p.id === selectedPlayerId);
    if (!selectedPlayer) {
        return false;
    }

    // Clear the current pick timeout
    if (session.pickTimeout) {
        clearTimeout(session.pickTimeout);
        session.pickTimeout = undefined;
    }

    const isTeam1Turn = pickingOrder.team1Picks.includes(currentPickNumber);
    const currentCaptain = isTeam1Turn ? team1Captain : team2Captain;
    const teamNumber = isTeam1Turn ? 1 : 2;
    
    // Add player to appropriate team
    if (isTeam1Turn) {
        session.team1Players.push(selectedPlayer);
    } else {
        session.team2Players.push(selectedPlayer);
    }
    
    // Send pick confirmation message
    if (sendConfirmation) {
        await sendPickConfirmation(session, selectedPlayer, currentCaptain, teamNumber);
    }
    
    // Add player to game data in database
    await updateGameWithNewPlayer(session.gameId, selectedPlayer, teamNumber, session.season);
    
    // Remove from unpicked
    session.unpickedPlayers = session.unpickedPlayers.filter(p => p.id !== selectedPlayerId);
    session.currentPickNumber++;

    const totalRequiredPicks = pickingOrder.team1Picks.length + pickingOrder.team2Picks.length;
    if (session.unpickedPlayers.length === 0) {
        console.log(`aaaaaaaaaaaaaaaa ${session.gameId}. currentPickNumber=${session.currentPickNumber}, totalRequired=${totalRequiredPicks}`);
        if (session.pickTimeout) {
            clearTimeout(session.pickTimeout);
            session.pickTimeout = undefined;
        }
        if (session.collector) {
            try { session.collector.stop(); } catch {}
        }
        if (!session.completed) {
            session.completed = true;
            if (session.completionWatchdog) {
                clearTimeout(session.completionWatchdog);
                session.completionWatchdog = undefined;
            }
            await completePicking(session); 
        }
        return true; 
    }

    // Check if there's only one player left and automatically assign them
    if (session.unpickedPlayers.length === 1 && session.currentPickNumber <= pickingOrder.team1Picks.length + pickingOrder.team2Picks.length) {
        const lastPlayer = session.unpickedPlayers[0];
        const nextIsTeam1Turn = pickingOrder.team1Picks.includes(session.currentPickNumber);
        const nextCaptain = nextIsTeam1Turn ? team1Captain : team2Captain;
        const nextTeamNumber = nextIsTeam1Turn ? 1 : 2;
        
        // Assign the last player to the appropriate team
        if (nextIsTeam1Turn) {
            session.team1Players.push(lastPlayer);
        } else {
            session.team2Players.push(lastPlayer);
        }
        
        // Send confirmation for the last player auto-assignment
        await session.threadChannel.send({
            content: `Last player ${lastPlayer.toString()} has been automatically assigned to **Team ${nextTeamNumber}**!`
        });
        const lastPlayerUpdatePromise = updateGameWithNewPlayer(session.gameId, lastPlayer, nextTeamNumber, session.season)
            .catch(() => {});

        session.unpickedPlayers = [];
        session.currentPickNumber++;
        
        // Check if picking is now complete and start the game immediately
        console.log(`Checking completion: currentPickNumber=${session.currentPickNumber}, totalPicks=${pickingOrder.team1Picks.length + pickingOrder.team2Picks.length}, unpickedPlayers=${session.unpickedPlayers.length}`);
        
        if (session.unpickedPlayers.length === 0 || session.currentPickNumber > pickingOrder.team1Picks.length + pickingOrder.team2Picks.length) {
            console.log(`Picking complete ${session.gameId}`);
            
            // Clear any timeouts and stop collectors immediately
            if (session.pickTimeout) {
                clearTimeout(session.pickTimeout);
                session.pickTimeout = undefined;
                console.log(`Cleared pick timeout for ${session.gameId}`);
            }
            if (session.collector) {
                session.collector.stop();
                console.log(`Stopped collector for ${session.gameId}`);
            }
            if (!session.completed) {
                session.completed = true;
                if (session.completionWatchdog) {
                    clearTimeout(session.completionWatchdog);
                    session.completionWatchdog = undefined;
                }
                await completePicking(session); 
            }
            return true; // Return early since picking is complete
        }
    }

    if (!session.completed && session.unpickedPlayers.length === 0) {
        if (session.completionWatchdog) clearTimeout(session.completionWatchdog);
        session.completionWatchdog = setTimeout(async () => {
            if (!session.completed) {
                session.completed = true;
                await completePicking(session);
            }
        }, 5000); 
    }

    return true;
}

async function handlePlayerPick(session: CaptainPickingSession, selectedPlayerId: string, interaction: any) {
    const redisLockKey = `pickLock:${session.gameId}`;
    const acquired = await App.Redis.set(redisLockKey, Date.now().toString(), 'EX', 5, 'NX').catch((_: unknown): null => null);
    if (!acquired) {
        const alreadyDeferred = (interaction as any).deferred || (interaction as any).replied;
        const respond = alreadyDeferred ? interaction.followUp.bind(interaction) : interaction.reply.bind(interaction);
        await respond({ content: "Another pick is currently being processed. Please wait a moment.", ephemeral: true }).catch(() => {});
        return;
    }
    if ((session as any)._pickLock) {
        const alreadyDeferred = (interaction as any).deferred || (interaction as any).replied;
        const respond = alreadyDeferred ? interaction.followUp.bind(interaction) : interaction.reply.bind(interaction);
        await respond({ content: "Another pick is currently being processed. Please wait a moment.", ephemeral: true }).catch(() => {});
        try { await App.Redis.del(redisLockKey); } catch {}
        return;
    }
    (session as any)._pickLock = true;

    let success = false;
    try {
        success = await handlePlayerPickInternal(session, selectedPlayerId);
    } catch (e) {
        console.error("handlePlayerPickInternal threw", e);
        success = false;
    }

    if (!success) {
        const alreadyDeferred = (interaction as any).deferred || (interaction as any).replied;
        const respond = alreadyDeferred ? interaction.followUp.bind(interaction) : interaction.reply.bind(interaction);
        await respond({
            content: "Player not found in unpicked list.",
            ephemeral: true
        }).catch(() => {});
        (session as any)._pickLock = false;
        return;
    }

    const newEmbed = createPickingEmbed(session);

    try {
        if (interaction.message && typeof interaction.message.edit === 'function') {
            await interaction.message.edit({ embeds: [newEmbed], components: [] }).catch((err: any) => {
                if (err?.code === 10062) {
                    console.warn(`Unknown interaction while editing message for game ${session.gameId}, ignoring.`);
                } else {
                    console.warn("Edit after pick failed", err);
                }
            });
        }
    } catch (e) {
        console.warn("Unexpected error editing pick message", e);
    }

    if (session.currentPickNumber > session.pickingOrder.team1Picks.length + session.pickingOrder.team2Picks.length || session.unpickedPlayers.length === 0) {
        (session as any)._pickLock = false;
        return;
    }

    if (session.unpickedPlayers.length > 0 && session.currentPickNumber <= session.pickingOrder.team1Picks.length + session.pickingOrder.team2Picks.length) {
        if (session.currentPickMessage) {
            await session.currentPickMessage.edit({ components: [] }).catch(() => {});
        }
        session.currentPickMessage = await sendCurrentTeamsStatus(session);
        startPickTimeout(session);
    }

    (session as any)._pickLock = false;
    try { await App.Redis.del(redisLockKey); } catch {}
}

async function completePicking(session: CaptainPickingSession) {
    const { team1Players, team2Players, team1VoiceChannel, team2VoiceChannel, gameId, guild, threadChannel, dbSettings, season, team1Captain, team2Captain } = session;

    if (session.completePickingRan) {
        console.log(`completePicking already executed for game ${gameId}, skipping.`);
        return;
    }

    // Check if session has been aborted (e.g., by /close command)
    if (session.aborted) {
        console.log(`Picking session ${gameId} was aborted, skipping completePicking`);
        return;
    }

    // Check if game still exists and hasn't been voided
    try {
        const game = await prisma.game.findFirst({
            where: { gameId },
        });
        
        if (!game) {
            console.log(`Game ${gameId} no longer exists, aborting completePicking`);
            await cleanupPickingSession(session);
            return;
        }

        if (game.status === GameStatus.VOIDED || game.status === GameStatus.AUTO_CLOSED) {
            console.log(`Game ${gameId} has been ${game.status}, aborting completePicking`);
            await cleanupPickingSession(session);
            return;
        }
    } catch (error) {
        console.error(`Error checking game status for ${gameId}:`, error);
        await cleanupPickingSession(session);
        return;
    }

    session.completePickingRan = true;

    if (session.completionWatchdog) {
        clearTimeout(session.completionWatchdog);
        session.completionWatchdog = undefined;
    }

    console.log(`completePicking called for game ${gameId}`);
    console.log(`Team 1 players: ${team1Players.map(p => p.displayName).join(', ')}`);
    console.log(`Team 2 players: ${team2Players.map(p => p.displayName).join(', ')}`);

    // Clear any remaining timeout
    if (session.pickTimeout) {
        clearTimeout(session.pickTimeout);
        session.pickTimeout = undefined;
        console.log(`Cleared remaining timeout in completePicking for ${gameId}`);
    }


    const team1Channel = guild.channels.cache.get(session.team1VoiceChannel) as VoiceChannel;
    if (team1Channel) {
        await team1Channel.lockPermissions(); // This syncs the permissions to the Teams Category permissions (default)
    }

    // Set up the correct permission for all players in the team calls after picking is complete
    await TeamVoiceManager.setupChannelsForGame(
        guild,
        { gameId, team1: session.team1VoiceChannel, team2: session.team2VoiceChannel },
        gameId,
        team1Players.map(x => x.id),
        team2Players.map(x => x.id),
        { restrict: true }
    );
    
    const moveTasks: Promise<any>[] = [
        ...team1Players.map(async p => {
            try {
                await safeVoiceMove(p, team1VoiceChannel, gameId);
            } catch (error) {
                console.error(`Failed to move Team 1 player ${p.displayName}:`, error);
            }
        }),
        ...team2Players.map(async p => {
            try {
                await safeVoiceMove(p, team2VoiceChannel, gameId);
            } catch (error) {
                console.error(`Failed to move Team 2 player ${p.displayName}:`, error);
            }
        })
    ];

    await Promise.allSettled(moveTasks);

    // Update database with final player assignments
    try {
        const gameRecord = await prisma.game.findFirst({
            where: { gameId },
            include: { players: true }
        });
        if (gameRecord) {
            const existingUserIds = new Set(gameRecord.players.map((gp: any) => gp.userId));
            const allPickedPlayers = [
                ...team1Players.map(p => ({ discord: p, team: 1 })),
                ...team2Players.map(p => ({ discord: p, team: 2 }))
            ];
            const backfillTasks: Promise<any>[] = [];
            for (const { discord, team } of allPickedPlayers) {
                const stats = await prisma.playerStatistics.findFirst({
                    where: { player: { userId: discord.id }, seasonId: season.id },
                    include: { player: true }
                });
                if (!stats) continue; 
                if (existingUserIds.has(stats.playerId)) continue; 
                backfillTasks.push(
                    prisma.gamePlayer.create({
                        data: {
                            gameId: gameRecord.id,
                            userId: stats.playerId,
                            discordTeam: team,
                            preElo: stats.elo,
                        }
                    }).then(() => {
                        console.log(`put player ${discord.displayName} into game ${gameId} (team ${team})`);
                    }).catch((err: any) => console.warn(`error doing put ${discord.displayName} in game ${gameId}:`, err))
                );
            }
            if (backfillTasks.length) {
                await Promise.allSettled(backfillTasks);
            }
        } else {
            console.warn(`record not found for put during completePicking ${gameId}`);
        }
    } catch (err) {
        console.error(`err during put in completePicking for game ${gameId}:`, err);
    }

    await finalizeGameAfterPicking(guild, team1Players, team2Players, dbSettings, season, gameId, threadChannel, session.team1VoiceChannel, session.team2VoiceChannel, team1Captain, team2Captain);
    
    // Clean up the picking session
    await cleanupPickingSession(session);
    console.log(`Picking session cleanup completed for game ${gameId}`);
}

export async function createCaptainPickingGame(
    guild: Guild,
    players: GuildMember[],
    dbSettings: Settings,
    season: Season,
    originQueueChannelId?: string
): Promise<void> {
    if (players.length < 8) {
        await sendLogs(`Captain picking aborted little players ${players.length}.`, "Captain Picking Error");
        return;
    }
    
    let gameId: string | null = null;
    try {
    let limitedPlayers = players;
    if (players.length > 8) {
        const shuffled = _.shuffle(players);
        limitedPlayers = shuffled.slice(0, 8);
        const leftover = shuffled.slice(8);
    }
    
    // FIRST: Check if voice channels are available BEFORE creating anything
    await TeamVoiceManager.optionallyCreateChannelPair(guild);
    
    const availableChannelPair = await TeamVoiceManager.findAvailableChannelPair(guild);
    if (!availableChannelPair) {
        console.log(`No available voice channel pair found for captain picking, aborting game creation`);
        return;
    }
    
    // ONLY create gameId after confirming channels are available
    gameId = await generateGameId();
    
    // Reserve the channel pair
    await TeamVoiceManager.reserveChannelPair(availableChannelPair, gameId);
    
    // Store game creation timestamp for grace period checks
    await App.Redis.set(`gameCreatedAt:${gameId}`, Date.now().toString());

    const queueGamesTextChannel = await guild.channels.fetch(settings.channels.games);
    if (!(queueGamesTextChannel instanceof TextChannel)) return;

    // Double-check that we still have valid voice channels before creating thread
    const team1Channel = guild.channels.cache.get(availableChannelPair.team1.id);
    const team2Channel = guild.channels.cache.get(availableChannelPair.team2.id);
    if (!team1Channel?.isVoiceBased() || !team2Channel?.isVoiceBased()) {
        console.error(`Voice channels became invalid for captain picking game ${gameId}, aborting`);
        return;
    }

    const queueThreadChannel = await queueGamesTextChannel.threads.create({
        name: `Game ${gameId}`,
        type: ChannelType.PrivateThread,
        invitable: false,
    });

    await queueThreadChannel.send({
        content: limitedPlayers.map((x) => x.toString()).join(" "),
    });

    try {
        await App.Redis.set(`gameParticipants:${gameId}`, JSON.stringify({
            playerIds: limitedPlayers.map(p => p.id),
            warnings: {}, 
        }));
    } catch (e) {
        console.error(`failed storage gameParticipants for ${gameId}`, e);
    }

    if (originQueueChannelId) {
        try { await App.Redis.setex(`queueOrigin:${gameId}`, 3600, originQueueChannelId); } catch {}
    }

    // Move all players to team 1 voice channel initially (they'll be redistributed after picking)
    await Promise.all(
        limitedPlayers.map(player => safeVoiceMove(player, availableChannelPair.team1.id, gameId))
    );
    
    try {
        if (availableChannelPair.team1?.isVoiceBased()) {
            
            await availableChannelPair.team1.edit({
                permissionOverwrites: [
                    {
                        id: guild.id,
                        allow: [PermissionsBitField.Flags.ViewChannel],
                        deny: [PermissionsBitField.Flags.Connect]
                    },
                    {
                        id: settings.roles.staff,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: settings.roles.creator,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    ...limitedPlayers.map(p => ({
                        id: p.id,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: [] as bigint[]
                    }))
                ]
            });
        }
    } catch (e) {
        console.error('Error setting picking phase permissions:', e);
    }

    // Select captains
    const { team1Captain, team2Captain } = selectCaptains(limitedPlayers);
    
    // Validate that captains have statistics before proceeding
    const captainValidation = await validateCaptainsHaveStats([team1Captain, team2Captain], season);
    if (!captainValidation.valid) {
        const missingNames = captainValidation.missingStats.map(p => p.displayName).join(', ');
        console.error(`Captain picking aborted for game ${gameId} - captains missing statistics: ${missingNames}`);
        await sendLogs(`Captain picking aborted for game ${gameId} - the following captains need to register or claim ELO: ${missingNames}`, "Captain Picking Error");
        
        // Clean up voice channels since game creation failed
        await TeamVoiceManager.resetChannelsAfterGame(guild, gameId, true);
        return;
    }
    
    // Create initial game data with captains
    try {
        await createInitialGameData(guild, [team1Captain], [team2Captain], dbSettings, season, gameId, queueThreadChannel, availableChannelPair.team1.id, availableChannelPair.team2.id);
    } catch (error) {
        console.error(`Failed to create initial game data for captain picking game ${gameId}:`, error);
        
        // Clean up voice channels since game creation failed
        await TeamVoiceManager.resetChannelsAfterGame(guild, gameId, true);
        return;
    }
    
    // Create picking session
    const pickingOrder = PICKING_ORDERS[dbSettings.pickingType];
    const sessionId = customAlphabet('abcdefghijklmnopqrstuvwxyz0123456789', 8)();
    const session: CaptainPickingSession = {
        gameId,
        sessionId,
        guild,
        threadChannel: queueThreadChannel,
        team1VoiceChannel: availableChannelPair.team1.id,
        team2VoiceChannel: availableChannelPair.team2.id,
        allPlayers: limitedPlayers,
        team1Players: [team1Captain],
        team2Players: [team2Captain],
        unpickedPlayers: limitedPlayers.filter(p => p.id !== team1Captain.id && p.id !== team2Captain.id),
        currentPickNumber: 1,
        pickingOrder,
        team1Captain,
        team2Captain,
        dbSettings,
        season
    };

    // Send initial picking embed (without components)
    const initialEmbed = createPickingEmbed(session);

    const pickingMessage = await queueThreadChannel.send({
        embeds: [initialEmbed],
        components: []
    });

    // Store session in memory and Redis
    activePickingSessions.set(gameId, session);
    try {
        // Store in Redis with 10 minute expiry (should be plenty for picking)
        await App.Redis.setex(`activePicking:${gameId}`, 600, JSON.stringify({
            gameId,
            sessionId,
            threadChannelId: queueThreadChannel.id,
            startedAt: Date.now()
        }));
    } catch (e) {
        console.error(`Failed to store picking session in Redis for ${gameId}:`, e);
    }

    // Send initial teams status with pick dropdown and start the timeout for the first pick
    console.log(`Starting captain picking UI for game ${gameId}`);
    session.currentPickMessage = await sendCurrentTeamsStatus(session);
    startPickTimeout(session);
    console.log(`Captain picking initialized successfully for game ${gameId}`);

    // Set up interaction collector for the entire channel
    const collector = queueThreadChannel.createMessageComponentCollector({
        filter: (i) => i.customId.startsWith(`captain-pick:`),
        time: 300000,
    });

    session.collector = collector;

    collector.on('collect', async (interaction) => {
        const recvAt = Date.now();
        if (!(interaction as any).deferred && !(interaction as any).replied) {
            try {
                await interaction.deferUpdate().catch((err: any) => {
                    if (err?.code !== 10062) console.warn("Early deferUpdate failed", err);
                });
            } catch {}
        }

        if (!interaction.isStringSelectMenu()) {
            return;
        }

        const parts = interaction.customId.split(':');
        if (parts.length !== 4) {
            await interaction.followUp?.({ content: "Invalid pick interaction format.", ephemeral: true }).catch(() => {});
            return;
        }
        const [, , sessionIdFromComponent, pickNumStr] = parts;
        if (session.sessionId !== sessionIdFromComponent) {
            await interaction.followUp?.({ content: "This picking session is no longer active.", ephemeral: true }).catch(() => {});
            return;
        }
        const pickNumberFromId = parseInt(pickNumStr, 10);
        const isTeam1Turn = pickingOrder.team1Picks.includes(pickNumberFromId);
        const expectedCaptain = isTeam1Turn ? team1Captain : team2Captain;

        if (interaction.user.id !== expectedCaptain.id) {
            const currentCaptain = isTeam1Turn ? team1Captain : team2Captain;
            await interaction.followUp?.({ content: `It's not your turn to pick. It's currently ${currentCaptain.toString()}'s turn.`, ephemeral: true }).catch(() => {});
            return;
        }

        if (pickNumberFromId !== session.currentPickNumber) {
            const currentCaptain = pickingOrder.team1Picks.includes(session.currentPickNumber) ? team1Captain : team2Captain;
            await interaction.followUp?.({ content: `That pick is no longer active. We're on pick ${session.currentPickNumber} (${currentCaptain.toString()}).`, ephemeral: true }).catch(() => {});
            return;
        }

        const value = interaction.values?.[0];
        if (!value) {
            await interaction.followUp?.({ content: "No player selected (empty selection).", ephemeral: true }).catch(() => {});
            return;
        }

        const ackLatency = Date.now() - recvAt;
        if (ackLatency > 1500) {
            console.warn(`[Picking] High ack latency ${ackLatency}ms for game ${session.gameId}`);
        }

        await handlePlayerPick(session, value, interaction);
    });

    collector.on('end', async (collected, reason) => {
        console.log(`Collector ended for game ${gameId}, reason: ${reason}, currentPickNumber: ${session.currentPickNumber}, totalPicks: ${pickingOrder.team1Picks.length + pickingOrder.team2Picks.length}`);
        
        // Clear any remaining pick timeout
        if (session.pickTimeout) {
            clearTimeout(session.pickTimeout);
            session.pickTimeout = undefined;
        }

        // If session was aborted, ensure cleanup happened
        if (reason === 'aborted' || session.aborted) {
            console.log(`Collector ended due to abort for game ${gameId}, ensuring cleanup`);
            if (!session.completed) {
                await cleanupPickingSession(session);
            }
            return;
        }

        // Only handle timeout if picking is still in progress (not already completed)
        if (!session.completed && !session.aborted && session.unpickedPlayers.length > 0 && session.currentPickNumber <= pickingOrder.team1Picks.length + pickingOrder.team2Picks.length) {
            console.log(`Collector ended for game ${gameId} with remaining players - calling handlePickTimeout to continue picking`);
            
            // Call handlePickTimeout to properly continue the picking process
            await handlePickTimeout(session);
        } else if (reason === 'time' && !session.completed) {
            // Collector timed out and picking isn't complete - clean up
            console.log(`Collector timed out for game ${gameId}, cleaning up session`);
            await cleanupPickingSession(session);
        }
    });

    
    } catch (error) {
        console.error(`Error during captain picking creation for game ${gameId}:`, error);
        
        // This ensures channels don't get stuck if creation fails early
        if (gameId) {
            try {
                // Clean up Redis keys for picking session if they exist
                await App.Redis.del(`activePicking:${gameId}`);
                await App.Redis.del(`pickLock:${gameId}`);
                activePickingSessions.delete(gameId);
                
                // Reset voice channels
                await TeamVoiceManager.resetChannelsAfterGame(guild, gameId, true);
                console.log(`Cleaned up channels after failed captain picking creation for game ${gameId}`);
            } catch (cleanupError) {
                console.error(`Error cleaning up channels after failed captain picking for game ${gameId}:`, cleanupError);
            }
        }
        throw error;
    }
}

// Create initial game data when picking starts
async function createInitialGameData(guild: Guild, team1: GuildMember[], team2: GuildMember[], dbSettings: Settings, season: Season, gameId: string, threadChannel: ThreadChannel, team1ChannelId: string, team2ChannelId: string) {
    try {
        console.log(`Creating initial game data for game ${gameId}`);
        
        // Create game players data for database with initial captains
        const gamePlayers = [];
        
        // Add team 1 captain
        for (const player of team1) {
            const statistics = await prisma.playerStatistics.findFirst({
                where: {
                    player: { userId: player.id },
                    seasonId: season.id
                },
                include: { player: true }
            });
            if (statistics) {
                gamePlayers.push({ statistics, team: 1 });
                console.log(`Added team 1 captain: ${player.displayName}`);
            } else {
                console.warn(`No statistics found for team 1 captain: ${player.displayName}`);
            }
        }

        // Add team 2 captain
        for (const player of team2) {
            const statistics = await prisma.playerStatistics.findFirst({
                where: {
                    player: { userId: player.id },
                    seasonId: season.id
                },
                include: { player: true }
            });
            if (statistics) {
                gamePlayers.push({ statistics, team: 2 });
                console.log(`Added team 2 captain: ${player.displayName}`);
            } else {
                console.warn(`No statistics found for team 2 captain: ${player.displayName}`);
            }
        }

        if (gamePlayers.length === 0) {
            throw new Error("No valid captains found with statistics - captains may need to register or claim their ELO first");
        }
        
        if (gamePlayers.length < 2) {
            const missingCaptain = gamePlayers.length === 1 && gamePlayers[0].team === 1 ? "Team 2 captain" : "Team 1 captain";
            throw new Error(`${missingCaptain} does not have statistics - they may need to register or claim their ELO first`);
        }

    const enabledMaps = ALLOWED_MAPS.filter(x => x.in_rotation && x.gameStyle.some(gs => gs === dbSettings.gameStyle));
    const randomMap = enabledMaps[Math.floor(Math.random() * enabledMaps.length)];

        // Create the game in the database
        const game = await prisma.game.create({
            data: {
                players: {
                    create: gamePlayers.map((x) => ({
                        userId: x.statistics.playerId,
                        discordTeam: x.team,
                        preElo: x.statistics.elo,
                    })),
                },
                gameId: gameId,
                queueThreadChannelId: threadChannel.id,
                team1Voice: team1ChannelId,
                mapPlaying: randomMap.name,
                team2Voice: team2ChannelId,
                gameStyle: dbSettings.gameStyle,
                season: {
                    connect: {
                        id: season.id,
                    },
                },
            },
        });
        
        console.log(`Successfully created game ${gameId} in database`);
        return game;
    } catch (error) {
        console.error(`Error creating initial game data for ${gameId}:`, error);
        throw error; // Re-throw to prevent picking from continuing without a game
    }
}

// Update game data as players are picked
async function updateGameWithNewPlayer(gameId: string, player: GuildMember, team: number, season: Season) {
    try {
        console.log(`Attempting to add player ${player.displayName} to game ${gameId}, team ${team}`);
        
        // First check if the game exists
        const gameExists = await prisma.game.findFirst({
            where: { gameId: gameId }
        });
        
        if (!gameExists) {
            console.error(`Game ${gameId} does not exist in database when trying to add player ${player.displayName}`);
            return;
        }
        
        const statistics = await prisma.playerStatistics.findFirst({
            where: {
                player: { userId: player.id },
                seasonId: season.id
            },
            include: { player: true }
        });
        
        if (statistics) {
            const gamePlayer = await prisma.gamePlayer.create({
                data: {
                    gameId: gameExists.id, // use internal game primary key
                    userId: statistics.playerId,
                    discordTeam: team,
                    preElo: statistics.elo,
                }
            });
            console.log(`Successfully added player ${player.displayName} to game ${gameId} (db id: ${gameExists.id})`);
        } else {
            console.warn(`No statistics found for player ${player.displayName} in season ${season.id}`);
        }
    } catch (error) {
        console.error(`Error adding player ${player.displayName} to game ${gameId}:`, error);
        // Don't throw to prevent picking from stopping completely
    }
}

// Finalize game setup when picking completes (simplified version)
async function finalizeGameAfterPicking(guild: Guild, team1: GuildMember[], team2: GuildMember[], dbSettings: Settings, season: Season, gameId: string, threadChannel: ThreadChannel, team1ChannelId: string, team2ChannelId: string, team1Captain: GuildMember, team2Captain: GuildMember) {
    // Note: TeamVoiceManager.setupChannelsForGame is now called earlier in completePicking()
    // to ensure channels have proper permissions before players are moved

    // Get game data to fetch map and build gamePlayers array
    const game = await prisma.game.findFirst({
        where: { gameId },
        include: {
            players: {
                include: {
                    user: true
                }
            }
        }
    });

    if (!game) return;

    // Build gamePlayers array with statistics (matching createRandomTeamGame format)
    const allPlayers = [...team1, ...team2];
    const gamePlayers: { statistics: any; team: number }[] = [];
    
    for (const member of team1) {
        const stats = await prisma.playerStatistics.findFirst({
            where: { player: { userId: member.id }, seasonId: season.id },
            include: { player: true }
        });
        if (stats) {
            gamePlayers.push({ statistics: stats, team: 1 });
        }
    }
    
    for (const member of team2) {
        const stats = await prisma.playerStatistics.findFirst({
            where: { player: { userId: member.id }, seasonId: season.id },
            include: { player: true }
        });
        if (stats) {
            gamePlayers.push({ statistics: stats, team: 2 });
        }
    }

    // Get map info
    const mapInfo = ALLOWED_MAPS.find(m => m.name === game.mapPlaying);
    const mapHeightLimit = mapInfo?.height_limit || "Unknown";

    // Send all game start embeds and instructions using the shared helper
    // Pass the actual captains so they're displayed in order (captain first, then picked players)
    await sendGameStartEmbeds(
        threadChannel,
        gameId,
        season,
        dbSettings,
        team1,
        team2,
        team1ChannelId,
        team2ChannelId,
        game.mapPlaying,
        mapHeightLimit,
        gamePlayers,
        team1Captain,
        team2Captain
    );
}
