import settings from '../../settings';

import { ChannelType, GuildMember, VoiceChannel } from 'discord.js';

import { prisma } from '@common/database/connectors/prisma';
import { PickingTypes, Season, Settings } from '@common/database/generated';
import Task from '..';
import App from '../..';
import checkQueueRestrictions from './restrictions';
import handleRandomPicking, { createRandomTeamGame } from './randomPicking';
import { createCaptainPickingGame } from './captainPicking';
import _ from 'lodash';
import { getSettingsDocument } from '@/utils/settings';

export default class QueueSystemTask extends Task {
    taskName = 'queueSystem';
    cronTime = '*/5 * * * * *';
    onStart = true;
    timezone = 'UTC';

    async execute() {
        // check prerequisites are met
        const dbSettings = await getSettingsDocument();
        if (!dbSettings) return;

        const guild = await App.client.guilds.fetch(settings.guild);
        const season = await prisma.season.findFirst({
            where: { active: true },
        });

        if (!season) return;

        const queueChannelIds = [
            settings.voiceChannels.queue1,
            settings.voiceChannels.queue2,
            settings.voiceChannels.queue3,
            settings.voiceChannels.queue4,
            settings.voiceChannels.queue5,
            settings.voiceChannels.queue6
        ].filter(Boolean);

        const queueChannels = await Promise.all(queueChannelIds.map(async id => {
            try { return await guild.channels.fetch(id); } catch { return null; }
        }));

        // process each queue channel
        for (const rawChannel of queueChannels) {
            if (!rawChannel) {
                console.warn('Configured queue channel missing or inaccessible');
                continue;
            }
            const channel: any = rawChannel; 
            if (![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)) {
                console.log(`Skipping non-voice channel ${channel.id} (${channel.name}) type=${channel.type}`);
                continue;
            }

            const members = Array.from(channel.members.values()) as any[]; 
            if (!members.length) {
                console.log(`Skipping ${channel.name} - no members`);
                continue;
            }

            // check if the queue is already being processed
            const lockKey = `queuelock:${channel.id}`;
            if (await App.Redis.exists(lockKey)) {
                console.log(`Skip ${channel.name} - processing lock`);
                continue;
            }
            // set a processing lock
            await App.Redis.setex(lockKey, 15, 'processing');

            // evaluate the members in the queue
            console.log(`Evaluating queue ${channel.name} | ${members.length} members`);

            // Step 1: Check if members pass queue restrictions
            const validMembers = await checkQueueRestrictions(guild, channel.id, members as any);
            console.log(`[Queue] ${channel.name} | ${validMembers.length}/${members.length} members passed restrictions`);

            // Step 2: Check party completeness - only include members whose full party is eligible
            const queueableMembers = [];
            const processedMembers = new Set<string>();
            
            for (const member of validMembers) {
                if (processedMembers.has(member.id)) continue;
                
                const party = await prisma.party.findFirst({
                    where: {
                        OR: [
                            { leader: member.id },
                            { members: { has: member.id } }
                        ]
                    }
                });

                if (party) {
                    // Member is in a party - check if entire party is eligible
                    const partyMemberIds = [party.leader, ...party.members];
                    const allPartyEligible = partyMemberIds.every(partyMemberId => 
                        validMembers.some(valid => valid.id === partyMemberId)
                    );
                    
                    if (allPartyEligible) {
                        // Full party is eligible - add all party members
                        const partyMembers = validMembers.filter(m => partyMemberIds.includes(m.id));
                        queueableMembers.push(...partyMembers);
                        partyMembers.forEach(m => processedMembers.add(m.id));
                    } else {
                        // Incomplete party - skip this member
                        processedMembers.add(member.id);
                        const eligibleCount = partyMemberIds.filter(id => validMembers.some(m => m.id === id)).length;
                        console.log(`[Queue] Skipping party member ${member.id} - incomplete party (${eligibleCount}/${partyMemberIds.length} eligible)`);
                    }
                } else {
                    // Solo player - add directly
                    queueableMembers.push(member);
                    processedMembers.add(member.id);
                }
            }

            // Step 3: Check if we have enough players to form a game
            if (queueableMembers.length < dbSettings.teamSize * 2) {
                console.log(`Not enough queueable members in ${channel.name} | have ${queueableMembers.length}, need ${dbSettings.teamSize * 2}`);
                await App.Redis.del(lockKey);
                continue;
            }

            console.log(`Forming game from ${channel.name} | ${queueableMembers.length} queueable members`);

            // Step 4: Select players and create game
            // IMPORTANT: Select players by party groups to avoid splitting parties
            const selectedPlayers: GuildMember[] = [];
            const neededPlayers = dbSettings.teamSize * 2;
            
            // Group members by party
            const memberGroups: GuildMember[][] = [];
            const processedIds = new Set<string>();
            
            for (const member of queueableMembers) {
                if (processedIds.has(member.id)) continue;
                
                const party = await prisma.party.findFirst({
                    where: {
                        OR: [
                            { leader: member.id },
                            { members: { has: member.id } }
                        ]
                    }
                });
                
                if (party) {
                    // Get all party members from queueableMembers
                    const partyMemberIds = [party.leader, ...party.members];
                    const partyMembers = queueableMembers.filter(m => partyMemberIds.includes(m.id));
                    memberGroups.push(partyMembers);
                    partyMembers.forEach(m => processedIds.add(m.id));
                } else {
                    // Solo player
                    memberGroups.push([member]);
                    processedIds.add(member.id);
                }
            }
            
            // Shuffle groups (not individual players) and select until we have enough players
            const shuffledGroups = _.shuffle(memberGroups);
            for (const group of shuffledGroups) {
                if (selectedPlayers.length + group.length <= neededPlayers) {
                    selectedPlayers.push(...group);
                }
                if (selectedPlayers.length >= neededPlayers) {
                    break;
                }
            }
            
            // If we don't have exactly the right number, try to find solo players to fill
            if (selectedPlayers.length < neededPlayers) {
                const soloGroups = shuffledGroups.filter(g => g.length === 1);
                for (const soloGroup of soloGroups) {
                    if (!selectedPlayers.includes(soloGroup[0]) && selectedPlayers.length < neededPlayers) {
                        selectedPlayers.push(soloGroup[0]);
                    }
                }
            }
            
            if (selectedPlayers.length < neededPlayers) {
                await App.Redis.del(lockKey);
                continue;
            }
            
            const selected = selectedPlayers.slice(0, neededPlayers);
            
            if (dbSettings.pickingType === PickingTypes.one || dbSettings.pickingType === PickingTypes.two) {
                console.log(`Starting captain picking for ${channel.name} (${dbSettings.pickingType} mode)`);
                await createCaptainPickingGame(guild, _.uniqBy(selected, 'id'), dbSettings, season, channel.id);
            } else if (dbSettings.pickingType === PickingTypes.random) {
                console.log(`Using random team selection for ${channel.name}`);
                const teamSelection = await handleRandomPicking(_.uniqBy(selected, 'id'), dbSettings.teamSize ?? 4);
                if (!teamSelection) {
                    console.log(`Team selection failed for ${channel.name}`);
                    await App.Redis.del(lockKey);
                    continue;
                }
                await createRandomTeamGame(guild, teamSelection.team1, teamSelection.team2, dbSettings, season, channel.id);
            } else {
                console.log(`Invalid picking type: ${dbSettings.pickingType}`);
                await App.Redis.del(lockKey);
                continue;
            }
            await App.Redis.del(lockKey);
        }
    }
}