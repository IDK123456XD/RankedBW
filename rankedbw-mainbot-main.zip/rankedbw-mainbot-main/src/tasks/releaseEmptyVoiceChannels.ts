import Task from '.';
import { VoiceChannel } from 'discord.js';
import App from '..';
import settings from '../settings';
import { TeamVoiceManager } from '../utils';
import { prisma } from '@common/database/connectors/prisma';
import { GameStatus } from '@common/database/generated';

export default class ReleaseEmptyVoiceChannelsTask extends Task {
    taskName = 'releaseEmptyVoiceChannels';
    cronTime = '*/2 * * * *';
    onStart = true;
    timezone = 'UTC';

    async execute() {
        try {
            const guild = await App.client.guilds.fetch(settings.guild);
            if (!guild) return;

            const inUseData = await App.Redis.get('teamVoiceChannelsInUse');
            if (!inUseData) return;

            const inUseChannels: string[] = JSON.parse(inUseData);
            console.log(`Checking ${inUseChannels.length} in-use channels for emptiness`);

            const channelsToRelease: string[] = [];
            const gameIdsToCleanup: string[] = [];

            for (const channelId of inUseChannels) {
                // Fetch channel with force: true to get fresh data from API, not stale cache
                let channel: VoiceChannel | null = null;
                try {
                    channel = await guild.channels.fetch(channelId, { force: true }) as VoiceChannel;
                } catch (error) {
                    console.log(`Channel ${channelId} no longer exists or failed to fetch, marking for release`);
                    channelsToRelease.push(channelId);
                    continue;
                }
                
                if (!channel) {
                    console.log(`Channel ${channelId} no longer exists, marking for release`);
                    channelsToRelease.push(channelId);
                    continue;
                }

                if (channel.members.size === 0) {
                    console.log(`Channel ${channel.name} (${channelId}) is empty, marking for release`);
                    channelsToRelease.push(channelId);
                }
            }

            if (channelsToRelease.length === 0) {
                console.log(`No empty channels found`);
                return;
            }

            console.log(`Releasing ${channelsToRelease.length} empty channels`);

            const teamChannelsData = await App.Redis.get('teamVoiceChannels');
            if (teamChannelsData) {
                const teamChannels = JSON.parse(teamChannelsData);
                
                for (const channelPair of teamChannels) {
                    const bothEmpty = channelsToRelease.includes(channelPair.team1) && 
                                     channelsToRelease.includes(channelPair.team2);
                    
                    if (bothEmpty) {
                        console.log(`Both channels empty for game ${channelPair.gameId}, cleaning up game data`);
                        gameIdsToCleanup.push(channelPair.gameId);
                    }
                }
            }

            const updatedInUse = inUseChannels.filter(channelId => !channelsToRelease.includes(channelId));
            await App.Redis.set('teamVoiceChannelsInUse', JSON.stringify(updatedInUse));

            // Note: Game closing is handled by emptyGameVoice.ts with a 5-minute grace period
            // This task only releases empty channels from the pool
            for (const gameId of gameIdsToCleanup) {
                await App.Redis.del(`teamVoiceGame:${gameId}`);
                console.log(`Cleaned up Redis data for game ${gameId}`);
            }

            console.log(`Released ${channelsToRelease.length} channels, ${updatedInUse.length} still in use`);

        } catch (error) {
            console.error('Error in releaseEmptyVoiceChannels task:', error);
        }
    }
}