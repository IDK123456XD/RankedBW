import Task from '.';
import { spawn } from 'child_process';
import path from 'path';

export default class CleanupOrphanedThreadsTask extends Task {
    taskName = 'cleanupOrphanedThreads';
    // Run every 12 hours at minute 0 (00:00 and 12:00)
    cronTime = '0 */12 * * *';
    onStart = false;
    timezone = 'UTC';

    async execute() {
        console.log('[cleanupOrphanedThreads] Starting scheduled cleanup task...');

        return new Promise<void>((resolve, reject) => {
            // Path to the cleanup script (relative to project root)
            const scriptPath = path.join(__dirname, '..', '..', 'cleanup-orphaned-threads.js');

            console.log(`[cleanupOrphanedThreads] Executing script: ${scriptPath}`);

            // Spawn the cleanup script as a child process
            const child = spawn('node', [scriptPath], {
                cwd: path.join(__dirname, '..', '..'),
                stdio: 'inherit' // This will pipe all output directly to the console
            });

            // Set a timeout to prevent the script from running indefinitely
            const timeout = setTimeout(() => {
                console.error('[cleanupOrphanedThreads] ⏰ Script timeout - killing process');
                child.kill('SIGTERM');
                reject(new Error('Cleanup script timeout after 10 minutes'));
            }, 10 * 60 * 1000); // 10 minute timeout

            child.on('error', (error) => {
                clearTimeout(timeout);
                console.error('[cleanupOrphanedThreads] ❌ Failed to start cleanup script:', error);
                reject(error);
            });

            child.on('exit', (code) => {
                clearTimeout(timeout);
                if (code === 0) {
                    console.log('[cleanupOrphanedThreads] ✅ Cleanup script completed successfully');
                    resolve();
                } else {
                    console.error(`[cleanupOrphanedThreads] ❌ Cleanup script exited with code ${code}`);
                    // Don't reject - just log the error so the task system continues
                    resolve();
                }
            });
        });
    }
}

