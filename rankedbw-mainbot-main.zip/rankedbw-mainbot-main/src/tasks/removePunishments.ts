import { Guild, TextChannel } from 'discord.js';
import Task from '.';
import App from '..';
import settings from '../settings';
import embeds from '../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class RemovePunishments extends Task {
    taskName = 'RemovePunishments';

    timezone = 'America/New_York';
    cronTime = '*/2 * * * *';

    async execute() {
        let guild: Guild;

        const completePunishments = await prisma.punishment.findMany({
            where: {
                expiresAt: {
                    lt: new Date()
                },
                expired: false
            },
            include: {
                Player: true
            }
        });

        let punishments: TextChannel;
        let punishmentLogs: TextChannel;

        for (const punishment of completePunishments) {
            guild = await App.client.guilds.fetch(settings.guild);
            if (!guild) return;

            let member;
            try {
                member = await guild.members.fetch(punishment.Player.userId);
            } catch (error) {
                // Member is not in the server, but we still need to process the punishment
                member = null;
            }

            if (punishment.type === 'rankedban') {
                // Only try to remove role if member exists and is in the server
                if (member && member.roles.cache.has(settings.roles.rankedBan)) {
                    await member.roles.remove(settings.roles.rankedBan);
                }

                punishments = await guild.channels.fetch(settings.channels.punishments) as TextChannel;
                if (!punishments) continue;

                await punishments.send({
                    content: member ? `<@${member.id}>` : `<@${punishment.Player.userId}>`,
                    embeds: [
                        embeds.success(
                            `**User:** ${member || `<@${punishment.Player.userId}>`}\n**Reason:** Expired.\n\nIn the future if you face another punishment, it will likely increase due to your punishment history.`,
                            '`✅` Ranked Ban Expired',
                            false
                        ).setColor('#40ff56')
                            .setThumbnail('https://images-ext-1.discordapp.net/external/DF9hM2A0XmdL2Q5anEZqyom9XlPGhK8DO5TCymCmfwA/https/i.imgur.com/yka7bke.png?format=webp&quality=lossless&width=200&height=200')
                    ]
                });

                punishmentLogs = await guild.channels.fetch(settings.channels.punishmentLogs) as TextChannel;
                if (!punishmentLogs) continue;

                await punishmentLogs.send({
                    embeds: [
                        embeds.normal(
                            `${member || `<@${punishment.Player.userId}>`} has been unbanned from ranked for **${punishment.reason}**.`,
                            'Ranked Unban Removed',
                            false
                        ).addFields([
                            { name: 'User', value: `${member || `<@${punishment.Player.userId}>`}`, inline: true },
                            { name: 'Moderator', value: `<@${punishment.staff}>`, inline: true },
                            { name: 'Reason', value: `\`${punishment.reason}\``, inline: true },
                        ])
                    ]
                });
            } else if (punishment.type === 'mute') {
                // Only try to remove role if member exists and is in the server
                if (member && member.roles.cache.has(settings.roles.muted)) {
                    await member.roles.remove(settings.roles.muted);
                }

                punishments = await guild.channels.fetch(settings.channels.punishments) as TextChannel;
                if (!punishments) continue;

                await punishments.send({
                    content: member ? `<@${member.id}>` : `<@${punishment.Player.userId}>`,
                    embeds: [
                        embeds.normal(
                            `**User:** ${member || `<@${punishment.Player.userId}>`}\n**Reason:** Expired.\n\nIn the future if you face another punishment, it will likely increase due to your punishment history.`,
                            '`✅` Mute Expired',
                            false
                        ).setColor('#40ff56')
                            .setThumbnail('https://images-ext-1.discordapp.net/external/DF9hM2A0XmdL2Q5anEZqyom9XlPGhK8DO5TCymCmfwA/https/i.imgur.com/yka7bke.png?format=webp&quality=lossless&width=200&height=200')
                    ]
                });

                punishmentLogs = await guild.channels.fetch(settings.channels.punishmentLogs) as TextChannel;
                if (!punishmentLogs) continue;

                await punishmentLogs.send({
                    embeds: [
                        embeds.normal(
                            `${member || `<@${punishment.Player.userId}>`} has been unmuted for **${punishment.reason}**.`,
                            'Mute Removed',
                            false
                        ).addFields([
                            { name: 'User', value: `${member || `<@${punishment.Player.userId}>`}`, inline: true },
                            { name: 'Moderator', value: `<@${punishment.staff}>`, inline: true },
                            { name: 'Reason', value: `\`${punishment.reason}\``, inline: true },
                        ])
                    ]
                });
            }

            await prisma.punishment.update({
                where: {
                    id: punishment.id
                },
                data: {
                    expired: true
                }
            });
        }
    }
}
