export default abstract class Task {
  abstract taskName: string;

  onStart = false;
  cronTime: string | Date;
  timezone: string;

  abstract execute(...args: unknown[]): Promise<void>;
}
