import Task from '.';
import App from '..';
import { prisma } from '@common/database/connectors/prisma';
import settings from '../settings';

export default class CheckPartyIdleTime extends Task {
    taskName = 'CheckPartyIdleTime';
    timezone = 'America/New_York';
    cronTime = '*/5 * * * *';

    async execute() {
        const parties = await prisma.party.findMany({
            where: {
                lastVcJoin: {
                    lt: new Date(Date.now() - settings.partyDeleteIdleTime)
                }
            }
        });

        for (const party of parties) {
            const alerts = await App.client.guilds.cache.get(settings.guild)?.channels.fetch(settings.channels.alerts);
            if (alerts && alerts.isTextBased()) {
                await alerts.send({
                    content: `<@${party.leader}> Your party has been disbanded due to inactivity.`,
                });

                await prisma.party.delete({
                    where: {
                        id: party.id
                    }
                });
            }
        }
    }
}
