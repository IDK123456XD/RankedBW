import Task from '.';
import _ from 'lodash';
import { prisma } from '@common/database/connectors/prisma';
import { TeamVoiceManager } from '../utils';
import App from '..';
import settings from '../settings';
import { Game, GameStatus } from '@common/database/generated';
import { Guild } from 'discord.js';

export default class EmptyGameVoiceTask extends Task {
    taskName = 'emptyGameVoice';
    cronTime = '*/1 * * * *';
    onStart = true;
    timezone = 'UTC';

    async execute() {
        const guild = await App.client.guilds.fetch(settings.guild);
        if (!guild) return;

        // Check all games that are not yet scored/closed (PENDING, SUBMITTED, MANUAL_REVIEW)
        // This ensures channels are released even if game is waiting for staff review
        const pendingGames = await prisma.game.findMany({
            where: {
                status: {
                    in: [GameStatus.PENDING, GameStatus.SUBMITTED, GameStatus.MANUAL_REVIEW],
                },
            },
        });

        for (const game of pendingGames) {
            let team1Voice: any = null;
            let team2Voice: any = null;
            
            // Fetch channels with force: true to bypass cache and get fresh data
            try { 
                team1Voice = await guild.channels.fetch(game.team1Voice, { force: true }); 
            } catch (e: any) {
                if (e?.code === 10003) {
                    console.warn(`[emptyGameVoice] team1Voice missing for game ${game.gameId} (Unknown Channel)`);
                } else {
                    console.error('Fetch team1Voice error', e);
                }
            }
            try { 
                team2Voice = await guild.channels.fetch(game.team2Voice, { force: true }); 
            } catch (e: any) {
                if (e?.code === 10003) {
                    console.warn(`[emptyGameVoice] team2Voice missing for game ${game.gameId} (Unknown Channel)`);
                } else {
                    console.error('Fetch team2Voice error', e);
                }
            }

            if (!team1Voice?.isVoiceBased() || !team2Voice?.isVoiceBased()) continue;

            const existingEmptyGameVoice = await App.Redis.get(`emptyGameVoice:${game.id}`);

            // Check member count - with fresh data from API, this should be accurate
            const team1MemberCount = team1Voice.members.size;
            const team2MemberCount = team2Voice.members.size;
            
            if (team1MemberCount !== 0 || team2MemberCount !== 0) {
                // At least one channel has members, so game is still active
                await App.Redis.del(`emptyGameVoice:${game.id}`);
                continue;
            }

            if (existingEmptyGameVoice) {
                const parsedData = JSON.parse(existingEmptyGameVoice);
                const emptyDuration = Date.now() - parseInt(parsedData.startTime);
                
                // Check if game is too new to close (grace period)
                const gameAge = await App.Redis.get(`gameCreatedAt:${game.gameId}`);
                if (gameAge) {
                    const ageMs = Date.now() - parseInt(gameAge);
                    const ageMinutes = ageMs / (1000 * 60);
                    
                    // Don't auto-close games less than 3 minutes old
                    if (ageMinutes < 3) {
                        await App.Redis.del(`emptyGameVoice:${game.id}`);
                        continue;
                    }
                }
                
                // Auto-close after 5 minutes of emptiness
                if (emptyDuration > 5 * 60 * 1000) {
                    await this.autoCloseGame(guild, game);
                    await App.Redis.del(`emptyGameVoice:${game.id}`);
                }
            } else {
                await App.Redis.set(`emptyGameVoice:${game.id}`, JSON.stringify({
                    startTime: Date.now().toString(),
                    updateMessageSent: false,
                }));
            }
        }
    }

    async autoCloseGame(guild: Guild, game: Game) {
        try {
            // Safety check: Only reset channels if they still belong to this game
            const gameChannelsData = await App.Redis.get(`teamVoiceGame:${game.gameId}`);
            let resetChannelsPromise = Promise.resolve();
            
            if (gameChannelsData) {
                resetChannelsPromise = TeamVoiceManager.resetChannelsAfterGame(
                    guild,
                    game.gameId
                );
            }

            let thread: any = null;
            try { thread = await App.client.channels.fetch(game.queueThreadChannelId); } catch (e: any) {
                if (e?.code === 10003) {
                    console.warn(`[emptyGameVoice.autoCloseGame] Missing thread channel for game ${game.gameId} (Unknown Channel)`);
                } else {
                    console.error('Fetch thread channel error', e);
                }
            }
            if (!thread || !thread.isThread()) {
                // Still mark auto closed if appropriate
                try {
                    await prisma.game.update({ where: { gameId: game.gameId }, data: { status: GameStatus.AUTO_CLOSED } });
                } catch (e) { console.warn('Failed to mark AUTO_CLOSED for missing thread', e); }
                return;
            }

            // Send closure message before archiving
            await thread.send({ 
                content: `⏰ The game has been closed due to empty voice channels for 5 minutes.` 
            }).catch((err: any) => {
                console.error(`Failed to send closure message for game ${game.gameId}:`, err);
            });

            const archivePromise = Promise.all([
                thread.setArchived(true),
                thread.setLocked(true)
            ])
                .catch((error: unknown) => {
                    console.error(
                        `Error archiving/locking channel for game ${game.gameId} in submit.ts:`,
                        error
                    );
                    throw error;
                });

            await prisma.game.update({
                where: {
                    gameId: game.gameId
                },
                data: {
                    status: GameStatus.AUTO_CLOSED
                }
            });

            await Promise.all([resetChannelsPromise, archivePromise]);
        } catch (error: unknown) {
            console.error("Error closing game:", error);
        }
    }
}
