import Task from '.';
import _ from 'lodash';
import { prisma } from '@common/database/connectors/prisma';
import App from '..';
import settings from '../settings';
import { ScreenshareStatus } from '@common/database/generated';
import { Colors, Message } from 'discord.js';
import embeds from '../utils/discord/embeds';

export default class AutoCloseScreensharesTask extends Task {
    taskName = 'autoCloseScreenshares';
    cronTime = '*/1 * * * *';
    onStart = true;
    timezone = 'UTC';

    async execute() {
        const guild = await App.client.guilds.fetch(settings.guild);
        if (!guild) return;

        const oldScreenshares = await prisma.screenshare.findMany({
            where: {
                status: ScreenshareStatus.OPEN,
                createdAt: {
                    lte: new Date(Date.now() - 10 * 60 * 1000),
                },
            },
        });

        if (oldScreenshares.length === 0) return;

        const screenshareRequestsChannel = await guild.channels.fetch(settings.channels.screenshareRequests);
        if (!screenshareRequestsChannel?.isTextBased()) return;

        const activeScreensharesChannel = await guild.channels.fetch(settings.channels.activeScreenshares);
        if (!activeScreensharesChannel?.isTextBased()) return;

        for (const ss of oldScreenshares) {
            // Add a redis lock to prevent multiple instances of the task from running at the same time
            const lock = await App.Redis.get(`screenshare:lock:${ss.id}`);
            if (lock) {
                console.log(`[Screenshare] Skipping ${ss.id} - already locked`);
                continue;
            }

            // Set lock with 60 second expiry (enough time to complete the operation)
            await App.Redis.set(`screenshare:lock:${ss.id}`, "true", "EX", 60);

            try {
                const thread = await App.client.channels.fetch(ss.threadId).catch((): null => null);
                if (!thread || !thread.isThread()) {
                    console.log(`[Screenshare] Thread not found for screenshare ${ss.id}`);
                    continue;
                }

                // Check if thread is already archived
                if (thread.archived) {
                    console.log(`[Screenshare] Thread already archived for screenshare ${ss.id}`);
                    // Update database to reflect reality
                    await prisma.screenshare.update({
                        where: { id: ss.id },
                        data: { status: ScreenshareStatus.EXPIRED }
                    });
                    continue;
                }

                // Check if we already sent the timeout warning
                const timeoutSent = await App.Redis.get(`screenshare:timeout-sent:${ss.id}`);
                
                if (!timeoutSent) {
                    // First run: send warning and mark as processing
                    await App.Redis.setex(`screenshare:timeout-sent:${ss.id}`, 60, "true");
                    
                    await thread.send({
                        content: `⏰ <@${ss.targetUserId}> The screenshare request will be timed out in 30 seconds.`,
                    });
                    
                    console.log(`[Screenshare] Sent timeout warning for screenshare ${ss.id}`);
                    continue; // Exit this iteration, let the next task run handle the actual closing
                }

                // Second run (after 30+ seconds): actually close the screenshare
                console.log(`[Screenshare] Closing screenshare ${ss.id}`);

                // Update database status FIRST before any Discord operations
                await prisma.screenshare.update({
                    where: { id: ss.id },
                    data: { status: ScreenshareStatus.EXPIRED }
                });

                // Now archive and lock the thread
                await Promise.all([
                    thread.setArchived(true),
                    thread.setLocked(true)
                ]).catch(error => {
                    console.error(`[Screenshare] Error archiving thread for ${ss.id}:`, error);
                });

                // Update the request message
                const screenshareRequestsMessage = await screenshareRequestsChannel.messages.fetch(ss.requestMessageId).catch((): null => null);
                if (screenshareRequestsMessage) {
                    await screenshareRequestsMessage.edit({
                        embeds: [embeds.normal(
                            `User <@${ss.requesterUserId}> has requested a screenshare for <@${ss.targetUserId}>.\n\n` +
                            `Reason: \`${ss.reason}\`\n` +
                            `Status: \`EXPIRED\``,
                            "Screenshare Request",
                            false
                        ).setColor(Colors.Red)],
                    });
                }

                // Update the active screenshares message
                const messages = await activeScreensharesChannel.messages.fetch({
                    limit: 100,
                }).catch((): null => null);
                
                if (messages) {
                    const activeMessage = messages.find(
                        (msg: Message) => msg.embeds.length > 0 && msg.embeds[0].description?.includes(`<#${ss.threadId}>`)
                    );

                    if (activeMessage) {
                        await activeMessage.edit({
                            embeds: [embeds.normal(
                                `User <@${ss.requesterUserId}> has requested a screenshare for <@${ss.targetUserId}>.\n\n` +
                                `Reason: \`${ss.reason}\`\n` +
                                `Status: \`EXPIRED\``,
                                "Screenshare Request",
                                false
                            ).setColor(Colors.Red)],
                            components: [],
                        }).catch((error: unknown) => {
                            console.error(`[Screenshare] Error updating active message for ${ss.id}:`, error);
                        });
                    }
                }

                // Log to screenshare logs channel
                const screenshareLogsChannel = await guild.channels.fetch(
                    settings.channels.screenshareLogs
                ).catch((): null => null);
                
                if (screenshareLogsChannel?.isTextBased()) {
                    const targetUser = await guild.members
                        .fetch(ss.targetUserId)
                        .catch((): null => null);
                    const requesterUser = await guild.members
                        .fetch(ss.requesterUserId)
                        .catch((): null => null);

                    const logEmbed = embeds.normal(
                        `**Target:** ${targetUser || ss.targetUserId}\n` +
                        `**Requester:** ${requesterUser || ss.requesterUserId}\n` +
                        `**Thread:** <#${ss.threadId}>\n` +
                        `**Reason:** ${ss.reason}\n` +
                        `**Claimed by:** ${ss.claimedByUserId
                            ? `<@${ss.claimedByUserId}>`
                            : "None"
                        }\n` +
                        `**Closed by:** System (Auto-timeout)\n` +
                        `**Closed at:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
                        `**Close reason:** Auto-closed due to inactivity (10 minutes)`,
                        "Screenshare Closed"
                    );

                    await screenshareLogsChannel.send({
                        embeds: [logEmbed],
                    }).catch((error: unknown) => {
                        console.error(`[Screenshare] Error sending log for ${ss.id}:`, error);
                    });
                }

                // Clean up Redis keys after successful closure
                await Promise.all([
                    App.Redis.del(`screenshare:lock:${ss.id}`),
                    App.Redis.del(`screenshare:timeout-sent:${ss.id}`)
                ]);

                console.log(`[Screenshare] Successfully closed screenshare ${ss.id}`);
                
            } catch (error) {
                console.error(`[Screenshare] Error processing screenshare ${ss.id}:`, error);
            } finally {
                // Always clean up the lock
                await App.Redis.del(`screenshare:lock:${ss.id}`);
            }
        }
    }
}
