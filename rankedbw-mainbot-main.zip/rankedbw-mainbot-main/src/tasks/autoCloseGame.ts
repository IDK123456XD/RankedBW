import Task from '.';
import _ from 'lodash';
import { prisma } from '@common/database/connectors/prisma';
import { TeamVoiceManager } from '../utils';
import App from '..';
import settings from '../settings';
import { GameStatus } from '@common/database/generated';

export default class AutoCloseGameTask extends Task {
    taskName = 'autoCloseGame';
    cronTime = '*/1 * * * *';
    onStart = true;
    timezone = 'UTC';

    async execute() {
        const guild = await App.client.guilds.fetch(settings.guild);
        if (!guild) return;

        // Check all games that are not yet scored/closed and are older than 59 minutes
        // This includes PENDING, SUBMITTED, and MANUAL_REVIEW games
        const oldGames = await prisma.game.findMany({
            where: {
                status: {
                    in: [GameStatus.PENDING, GameStatus.SUBMITTED, GameStatus.MANUAL_REVIEW],
                },
                createdAt: {
                    lte: new Date(Date.now() - 59 * 60 * 1000),
                },
            },
        });

        for (const game of oldGames) {
            let thread: any = null;
            try {
                thread = await App.client.channels.fetch(game.queueThreadChannelId);
            } catch (e: any) {
                if (e?.code === 10003) {
                    console.warn(`[autoCloseGame] Thread channel missing (Unknown Channel 10003) for game ${game.gameId}; marking AUTO_CLOSED and skipping channel ops.`);
                    try {
                        await prisma.game.update({ where: { id: game.id }, data: { status: GameStatus.AUTO_CLOSED } });
                    } catch (err) { console.warn('Failed to mark AUTO_CLOSED for missing channel game', err); }
                    continue;
                }
                console.error('Error fetching thread channel for autoCloseGame:', e);
                continue;
            }
            if (!thread || !thread.isThread()) continue;

            if (game.createdAt.getTime() + 60 * 60 * 1000 > Date.now()) {
                await thread.send({ content: `⏰ The game will be closed in 30 seconds due to longevity of the game.` });
                continue;
            }

            try {
                // Safety check: Only reset channels if they still belong to this game
                const gameChannelsData = await App.Redis.get(`teamVoiceGame:${game.gameId}`);
                let resetChannelsPromise = Promise.resolve();
                
                if (gameChannelsData) {
                    resetChannelsPromise = TeamVoiceManager.resetChannelsAfterGame(
                        guild,
                        game.gameId
                    ).catch((error: unknown) => {
                        console.error(`Error resetting channels for game ${game.gameId}:`, error);
                    });
                }

                // Update game status to AUTO_CLOSED first
                await prisma.game.update({
                    where: {
                        id: game.id
                    },
                    data: {
                        status: GameStatus.AUTO_CLOSED
                    }
                });

                // Then try to archive the thread (separately to avoid blocking other operations)
                const archivePromise = Promise.all([
                    thread.setArchived(true),
                    thread.setLocked(true)
                ])
                    .then(() => {
                    })
                    .catch((error: unknown) => {
                        console.error(`Error archiving/locking thread for game ${game.gameId} (thread ID: ${thread.id}):`, error);
                        // Check if it's a permissions issue
                        if ((error as any)?.code === 50013) {
                            console.error(`Missing permissions to archive thread for game ${game.gameId}`);
                        }
                        // Don't re-throw - we still want voice channel cleanup to proceed
                    });

                // Wait for both operations but don't let archiving failure block voice cleanup
                await Promise.allSettled([resetChannelsPromise, archivePromise]);
            } catch (error: unknown) {
                console.error(`Error closing game ${game.gameId}:`, error);
            }
        }
    }
}
