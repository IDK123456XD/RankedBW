import { Guild, ThreadChannel } from "discord.js";
import { prisma } from "@common/database/connectors/prisma";
import { GameStatus } from "@common/database/generated";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import { TeamVoiceManager } from "./teamVoiceManager";
import { calculateXpReward } from "./leveling";
import { changePlayerElo } from "./elo";
import { EloHistoryReason } from "@common/database/generated";
import { sendScoringCard, sendVoidGameCard } from "./scoring";
import sendLogs from "./logs";
import settings from "../settings";
import { calculateEloChange } from "./eloChecker";
import App from "..";

export class GameHandler {
  static async voidGame(gameId: string, guild: Guild, resetGameChannels = false, voidedBy?: string, reason?: string) {
    const game = await prisma.game.findFirst({
      where: {
        gameId,
      },
      include: {
        players: {
          include: {
            user: {
              include: IncludeCurrentSeasonStatistics,
            },
          },
        },
      },
    });

    if (!game) return '<:rbw_cross:1387585103563063387> Game with ID \`${gameId}\` not found.';
    if (game.status === GameStatus.VOIDED) return '<:rbw_cross:1387585103563063387> This game has already been voided.';

    await prisma.game.update({
      where: {
        id: game.id,
      },
      data: {
        status: GameStatus.VOIDED,
        reason: reason || null,
      },
    });

    try { await App.Redis.del(`gameParticipants:${game.gameId}`); } catch {}
    try {
      let originQueue = null;
      try { originQueue = await App.Redis.get(`queueOrigin:${game.gameId}`); } catch {}
      const channelActiveKey = originQueue ? `activeQueueGame:${originQueue}` : `activeQueueGame:${game.team1Voice}`;
      await App.Redis.del(channelActiveKey);
      if (originQueue) { try { await App.Redis.del(`queueOrigin:${game.gameId}`); } catch {} }
      for (const gp of game.players) {
        await App.Redis.del(`activePickingGameForUser:${gp.user.userId}`).catch(()=>{});
      }
    } catch (e) { console.warn('Cleanup flags (void) failed', e); }

    if (game.status === GameStatus.SCORED) {
      for (const player of game.players) {
        const currentSeasonStats = player.user.PlayerStatistics.find((x: any) => x.season.active);
        if (!currentSeasonStats) {
          console.error("No active season stats found when voiding game");
          continue;
        }

        // Check if this game was played before the player reset their stats
        if (currentSeasonStats.lastStatResetAt && game.createdAt < currentSeasonStats.lastStatResetAt) {
          console.log(`Skipping stat reversal for player ${player.user.userId} in game ${gameId} - game was played before stats were reset`);
          continue;
        }

        // Additional validation: check if reversing would make sense
        const wouldBeNegative = 
          (player.win && currentSeasonStats.wins === 0) ||
          (!player.win && currentSeasonStats.losses === 0) ||
          (player.mvp && currentSeasonStats.mvps === 0) ||
          currentSeasonStats.gamesPlayed === 0;
        
        if (wouldBeNegative) {
          console.log(`Skipping stat reversal for player ${player.user.userId} in game ${gameId} - would result in negative stats`);
          continue;
        }

        const xpToRemove = calculateXpReward(
          player.preElo,
          player.win,
          player.mvp
        );

        if (player.eloDiff !== 0) {
          await changePlayerElo(
            player.user,
            currentSeasonStats.elo - player.eloDiff,
            EloHistoryReason.ManualAdjustment,
            reason || "Game Voided: " + gameId
          );
        }

        await prisma.gamePlayer.update({
          where: {
            id: player.id,
          },
          data: {
            win: false,
            mvp: false,
            postElo: 0,
          },
        });

        await prisma.playerStatistics.update({
          where: {
            playerId_seasonId: {
              playerId: player.userId,
              seasonId: currentSeasonStats.seasonId,
            },
          },
          data: {
            gamesPlayed: {
              decrement: currentSeasonStats.gamesPlayed > 0 ? 1 : 0,
            },
            wins: {
              decrement: player.win ? currentSeasonStats.wins > 0 ? 1 : 0 : 0,
            },
            mvps: {
              decrement: player.mvp ? currentSeasonStats.mvps > 0 ? 1 : 0 : 0,
            },
            losses: {
              decrement: player.win ? 0 : currentSeasonStats.losses > 0 ? 1 : 0,
            },
            scoredGames: {
              decrement: currentSeasonStats.scoredGames > 0 ? 1 : 0,
            },
            player: {
              update: {
                totalXp: {
                  decrement: xpToRemove > 0 ? xpToRemove : 0,
                },
              },
            },
          },
        });
        
        // When voiding a game, we reverse the streak change if the game was scored
        if (game.status === GameStatus.SCORED) {
          await this.reversePlayerStreak(player.userId, currentSeasonStats.seasonId, player.win);
        }
      }
    }

    // Reset team voice channels if they're still active
    if (resetGameChannels) {
      // Safety check: Only reset channels if the Redis key still exists for THIS game
      const gameChannelsData = await App.Redis.get(`teamVoiceGame:${game.gameId}`);
      if (gameChannelsData) {
        await TeamVoiceManager.resetChannelsAfterGame(
          guild,
          game.gameId
        ).catch((error) => {
          console.error("Error resetting channels after void:", error);
        });
      }

      const threadChannel = await guild.channels.fetch(game.queueThreadChannelId);
      if (threadChannel && threadChannel instanceof ThreadChannel) {
        await Promise.all([
          threadChannel.setArchived(true),
          threadChannel.setLocked(true)
        ]);
      }
    }

    // Send void game card to games channel
    await sendVoidGameCard(guild, game.gameId);

    await sendLogs(
      `The game **#${game.gameId}** has been voided by ${voidedBy ? `<@${voidedBy}>` : "player votes"}.\n\n` + (game.status === GameStatus.SCORED
        ? "All stat changes have been reversed."
        : "Game was not yet scored.") + (reason ? `\n\n**Reason:** ${reason}` : ""),
      "Game Voided",
      undefined,
      settings.channels.scoring
    );

    return `<:rbw_check:1387585062530322443> Game **${gameId}** has been voided${game.status === GameStatus.SCORED ? " and all stat changes have been reversed" : ""}.`;
  }

  static async scoreGame(gameId: string, guild: Guild, winningTeam: number, mvpIds: string[], scoredBy?: string, resetGameChannels = false, reason?: string) {
    let game = await prisma.game.findFirst({
      where: {
        gameId,
      },
      include: {
        players: {
          include: {
            user: {
              include: IncludeCurrentSeasonStatistics,
            },
          },
        },
      },
    });

    if (!game) return 'Please provide a valid game id.';

    if (game.status == GameStatus.SCORED) return 'This game has already been scored.';

    // Fetch active season and its maxGames setting
    const activeSeason = await prisma.season.findFirst({
      where: { active: true },
    });

    try {
      const manualStr = await App.Redis.get(`manualScore:${gameId}`).catch(() => null as any);
      if (manualStr) {
        const manual = JSON.parse(manualStr as any) as { players?: Array<{ userId: string; discordTeam: number }>; };
        const expected = Array.isArray(manual.players) ? manual.players : [];
        if (expected.length > 0) {
          const existingDiscordIds = new Set(game.players.map((gp: any) => gp.user.userId));
          const missing = expected.filter(p => !existingDiscordIds.has(p.userId));
          if (missing.length > 0) {
            for (const m of missing) {
              try {
                const stats = await prisma.playerStatistics.findFirst({
                  where: { seasonId: activeSeason?.id as any, player: { userId: m.userId } },
                  include: { player: true },
                });
                if (!stats) {
                  console.warn(`no stats ${m.userId} in season ${activeSeason?.id}`);
                  continue;
                }
                await prisma.gamePlayer.create({
                  data: {
                    gameId: game.id,
                    userId: stats.playerId,
                    discordTeam: m.discordTeam,
                    preElo: stats.elo,
                  },
                });
              } catch (e) {
                console.warn(`add failed ${m.userId} to game ${gameId}`, e);
              }
            }
            game = await prisma.game.findFirst({
              where: { gameId },
              include: {
                players: { include: { user: { include: IncludeCurrentSeasonStatistics } } },
              },
            }) as any;
          }
        }
      }
    } catch (e) {
      console.warn(`error backfill for ${gameId}`, e);
    }

    await prisma.game.update({
      where: {
        id: game.id,
      },
      data: {
        status: GameStatus.SCORED,
        reason: reason || null,
      },
    });

    try { await App.Redis.del(`gameParticipants:${game.gameId}`); } catch {}
    try {
      let originQueue = null;
      try { originQueue = await App.Redis.get(`queueOrigin:${game.gameId}`); } catch {}
      const channelActiveKey = originQueue ? `activeQueueGame:${originQueue}` : `activeQueueGame:${game.team1Voice}`;
      await App.Redis.del(channelActiveKey);
      if (originQueue) { try { await App.Redis.del(`queueOrigin:${game.gameId}`); } catch {} }
      for (const gp of game.players) {
        await App.Redis.del(`activePickingGameForUser:${gp.user.userId}`).catch(()=>{});
      }
    } catch (e) { console.warn('Cleanup flags (score) failed', e); }

    for (const player of game.players) {
      const isWinner =
        (winningTeam === 1 && player.discordTeam === 1) ||
        (winningTeam === 2 && player.discordTeam === 2);
      const isMvp = mvpIds.includes(player.user.userId);

  const currentSeasonStats = player.user.PlayerStatistics.find((x: any) => x.season.active);
      if (!currentSeasonStats) {
        console.error("No active season stats found when scoring game");
        continue;
      }

      const eloChange = calculateEloChange(isWinner, isMvp, player.preElo, currentSeasonStats.streak);
      const xpReward = calculateXpReward(
        player.preElo,
        isWinner,
        isMvp
      );
      const newElo = currentSeasonStats.elo + eloChange > 0 ? currentSeasonStats.elo + eloChange : 0;

      await prisma.gamePlayer.update({
        where: { id: player.id },
        data: {
          win: isWinner,
          mvp: isMvp,
          postElo: newElo,
          eloDiff: eloChange,
        },
      });

      const extraReason = reason || "Game Scored: " + gameId + (isWinner ? " (WIN) " : " (LOSS) ") + (isMvp ? "(MVP)" : "");
      await changePlayerElo(
        player.user,
        newElo,
        isMvp ? EloHistoryReason.MVP : isWinner ? EloHistoryReason.GameWin : EloHistoryReason.GameLoss,
        extraReason
      );

      await prisma.playerStatistics.update({
        where: {
          playerId_seasonId: {
            playerId: player.userId,
            seasonId: activeSeason.id,
          },
        },
        data: {
          gamesPlayed: { increment: 1 },
          scoredGames: { increment: 1 },
          wins: isWinner ? { increment: 1 } : undefined,
          losses: !isWinner ? { increment: 1 } : undefined,
          mvps: isMvp ? { increment: 1 } : undefined,
          player: {
            update: {
              totalXp: { increment: xpReward },
            },
          },
        },
      });

      await this.updatePlayerStreak(player.userId, activeSeason.id, isWinner);
    }

    // Reset team voice channels
    if (game.queueThreadChannelId && resetGameChannels) {
      const gameThread = await guild.channels.fetch(
        game.queueThreadChannelId
      );

      // Safety check: Only reset channels if the Redis key still exists for THIS game
      const gameChannelsData = await App.Redis.get(`teamVoiceGame:${game.gameId}`);
      if (gameChannelsData) {
        await TeamVoiceManager.resetChannelsAfterGame(
          guild,
          game.gameId
        );
      }

      if (gameThread?.isThread()) {
        await gameThread.setArchived(true);
        await gameThread.setLocked(true);
      }
    }

    // Send scoring card to games channel
    await sendScoringCard(guild, gameId, scoredBy ? "Staff" : "AI", scoredBy);

    await sendLogs(
      `Game **#${gameId}** has been manually scored by ${scoredBy ? `<@${scoredBy}>` : "AI"}.\n` +
      `**Winning Team:** Team ${winningTeam}\n` +
      `**MVPs:** ${mvpIds.map((id) => `<@${id}>`).join(", ")}`,
      `Game Scored ${scoredBy ? "(Manual)" : "(AI)"}`
      + (reason ? `\n\n**Reason:** ${reason}` : ""),
      undefined,
      settings.channels.scoring
    );

    return `<:rbw_check:1387585062530322443> Game **${gameId}** has been scored successfully.`;
  }

  static async unscoreGame(gameId: string) {
    const game = await prisma.game.findFirst({
      where: {
        gameId,
      },
      include: {
        players: {
          include: {
            user: {
              include: IncludeCurrentSeasonStatistics,
            },
          },
        },
      },
    });

    if (!game) return `<:rbw_cross:1387585103563063387> Please provide a valid game id.`;
    if (game.status !== GameStatus.SCORED) return `<:rbw_cross:1387585103563063387> This game has not been finished/scored yet.`;

    await prisma.game.update({
      where: {
        gameId,
      },
      data: {
        status: GameStatus.PENDING
      },
    });

    for (const player of game.players) {
      const currentSeasonStats = player.user.PlayerStatistics.find((x: any) => x.season.active);
      if (!currentSeasonStats) {
        console.error("No active season stats found when unscoring game");
        continue;
      }

      // Check if this game was played before the player reset their stats
      if (currentSeasonStats.lastStatResetAt && game.createdAt < currentSeasonStats.lastStatResetAt) {
        console.log(`Skipping stat reversal for player ${player.user.userId} in game ${gameId} - game was played before stats were reset (game: ${game.createdAt.toISOString()}, reset: ${currentSeasonStats.lastStatResetAt.toISOString()})`);
        continue;
      }

      // Additional validation: check if reversing would make sense
      const wouldBeNegative = 
        (player.win && currentSeasonStats.wins === 0) ||
        (!player.win && currentSeasonStats.losses === 0) ||
        (player.mvp && currentSeasonStats.mvps === 0) ||
        currentSeasonStats.gamesPlayed === 0;
      
      if (wouldBeNegative) {
        console.log(`Skipping stat reversal for player ${player.user.userId} in game ${gameId} - would result in negative stats`);
        continue;
      }

      const xpToRemove = calculateXpReward(
        player.preElo,
        player.win,
        player.mvp
      );

      await changePlayerElo(
        player.user,
        currentSeasonStats.elo - player.eloDiff,
        EloHistoryReason.ManualAdjustment,
        "Game Unscored: " + gameId
      );

      await prisma.gamePlayer.update({
        where: {
          id: player.id,
        },
        data: {
          win: false,
          mvp: false,
          postElo: 0,
        },
      });

      // Update other player stats (excluding ELO since it's handled by the helper)
      await prisma.playerStatistics.update({
        where: {
          playerId_seasonId: {
            playerId: player.userId,
            seasonId: currentSeasonStats.seasonId,
          },
        },
        data: {
          gamesPlayed: {
            decrement: currentSeasonStats.gamesPlayed > 0 ? 1 : 0,
          },
          wins: {
            decrement: player.win ? currentSeasonStats.wins > 0 ? 1 : 0 : 0,
          },
          mvps: {
            decrement: player.mvp ? currentSeasonStats.mvps > 0 ? 1 : 0 : 0,
          },
          losses: {
            decrement: player.win ? 0 : currentSeasonStats.losses > 0 ? 1 : 0,
          },
          scoredGames: {
            decrement: currentSeasonStats.scoredGames > 0 ? 1 : 0,
          },
          player: {
            update: {
              totalXp: {
                decrement: xpToRemove > 0 ? xpToRemove : 0,
              },
            },
          },
        },
      });

      // Reverse the streak change that was made when scoring
      // If they won, we need to decrement their streak by 1
      // If they lost, we need to reverse the loss logic
      await this.reversePlayerStreak(player.userId, currentSeasonStats.seasonId, player.win);
    }

    return `<:rbw_check:1387585062530322443> Game **${gameId}** has been unscored.`;
  }

  static async updatePlayerStreak(playerId: string, seasonId: string, isWin: boolean) {
    const currentStats = await prisma.playerStatistics.findUnique({
      where: {
        playerId_seasonId: {
          playerId,
          seasonId,
        },
      },
    });

    let newStreak: number;
    
    if (isWin) {
      // Win: always increment streak by 1
      newStreak = (currentStats?.streak || 0) + 1;
    } else {
      // Loss: reset to 0 if positive, or decrement if 0 or negative
      const currentStreak = currentStats?.streak || 0;
      if (currentStreak > 0) {
        newStreak = 0;
      } else {
        newStreak = currentStreak - 1;
      }
    }

    await prisma.playerStatistics.upsert({
      where: {
        playerId_seasonId: {
          playerId,
          seasonId,
        },
      },
      update: {
        streak: newStreak,
      },
      create: {
        playerId,
        seasonId,
        streak: newStreak,
      },
    });
  }

  static async reversePlayerStreak(playerId: string, seasonId: string, wasWin: boolean) {
    const currentStats = await prisma.playerStatistics.findUnique({
      where: {
        playerId_seasonId: {
          playerId,
          seasonId,
        },
      },
    });

    if (!currentStats) return; // Nothing to reverse if no stats exist

    let newStreak: number;
    
    if (wasWin) {
      // Reverse a win: decrement streak by 1
      newStreak = currentStats.streak - 1;
    } else {
      // Reverse a loss: this is more complex because we need to figure out what the streak was before
      // If current streak is 0, it means they had a positive streak that was reset
      // If current streak is negative, it means they had 0 or negative that was decremented
      const currentStreak = currentStats.streak;
      if (currentStreak === 0) {
        // We can't know what the previous positive streak was, so we'll leave it at 0
        // This is a limitation but better than complex recalculation
        newStreak = 0;
      } else if (currentStreak < 0) {
        // Reverse the decrement: add 1 back
        newStreak = currentStreak + 1;
      } else {
        // This shouldn't happen if logic is correct, but handle gracefully
        newStreak = currentStreak;
      }
    }

    await prisma.playerStatistics.update({
      where: {
        playerId_seasonId: {
          playerId,
          seasonId,
        },
      },
      data: {
        streak: newStreak,
      },
    });
  }
} 