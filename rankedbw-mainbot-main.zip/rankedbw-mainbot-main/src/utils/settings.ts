import { prisma } from "@common/database/connectors/prisma";

export async function getSettingsDocument() {
    const settings = await prisma.settings.findFirst();

    if (!settings) {
        return prisma.settings.create({
            data: {
                hypixelAPIKey: 'ddd',
            }
        });
    }

    return settings;
}