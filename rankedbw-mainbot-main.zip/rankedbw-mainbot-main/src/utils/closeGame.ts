import { ChatInputCommandInteraction } from "discord.js";
import { Game } from "@common/database/generated";
import { TeamVoiceManager } from "./teamVoiceManager";
import App from "..";

export async function closeGame(
  interaction: ChatInputCommandInteraction,
  game: Game
): Promise<void> {
  try {
    // Safety check: Only reset channels if they still belong to this game
    const gameChannelsData = await App.Redis.get(`teamVoiceGame:${game.gameId}`);
    let resetChannelsPromise = Promise.resolve();
    
    if (gameChannelsData) {
      resetChannelsPromise = TeamVoiceManager.resetChannelsAfterGame(
        interaction.guild,
        game.gameId
      ).catch((error) => {
        console.error("Error resetting channels after game completion:", error);
      });
    }

    // Archive and lock the channel in parallel with sending response
    const archivePromise = interaction.channel?.isThread()
      ? Promise.all([
          interaction.channel.setArchived(true),
          interaction.channel.setLocked(true)
        ])
          .catch((error) => {
            console.error(
              "Error archiving/locking channel for game ${game.gameId} in submit.ts:",
              error
            );
            throw error; // Re-throw to propagate the error
          })
      : Promise.resolve();

    // Let other operations complete in background
    await Promise.all([resetChannelsPromise, archivePromise]); // Await both promises to ensure completion
  } catch (error) {
    console.error("Error closing game:", error);
    // Don't throw - we want to complete the scoring even if cleanup partially fails
  }
}