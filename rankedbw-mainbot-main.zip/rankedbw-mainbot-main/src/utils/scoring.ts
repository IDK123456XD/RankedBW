import { Guild, AttachmentBuilder } from 'discord.js';
import { prisma } from '@common/database/connectors/prisma';
import settings from '../settings';
import { generateScoringCard } from '../images/scorecard';
import embeds from './discord/embeds';
import App from '..';

export async function sendScoringCard(guild: Guild, gameId: string, scoringMethod: 'AI' | 'Manual' | 'Staff', scoredBy?: string): Promise<void> {
    try {
        try { await App.Redis.setex(`scoringInProgress:${gameId}`, 120, '1'); } catch {}
        // Get the games channel
        const gamesChannel = await guild.channels.fetch(settings.channels.games);
        if (!gamesChannel?.isTextBased()) {
            console.error('Games channel not found or not text-based');
            return;
        }

        // Get complete game data
        const game = await prisma.game.findFirst({
            where: { gameId },
            include: {
                players: {
                    include: {
                        user: true
                    }
                },
                season: true
            }
        });

        if (!game) {
            console.error(`Game ${gameId} not found for scoring card`);
            return;
        }

        // Prepare data for the scoring card image
    const scoringCardPlayers = game.players.map((player: any) => ({
            userId: player.user.userId,
            uuid: player.user.uuid,
            minecraftName: player.user.minecraftName,
            nickname: player.user.nickname || undefined,
            preElo: player.preElo,
            eloDiff: player.eloDiff,
            postElo: player.postElo,
            isMvp: player.mvp,
            isWinner: player.win,
            headSkin: player.user.headSkin,
            discordTeam: player.discordTeam
        }));

        // Get display name for scoredBy if provided
        let scoredByName = undefined;
        if (scoredBy) {
            try {
                const member = await guild.members.fetch(scoredBy);
                scoredByName = member.displayName || member.user.username;
            } catch (error) {
                console.error('Could not fetch user who scored:', error);
            }
        }

        // Generate the scoring card image
        const scoringCardImage = await generateScoringCard({
            gameId,
            players: scoringCardPlayers,
            mapName: game.mapPlaying,
            seasonName: game.season.name,
            scoringMethod,
            scoredBy: scoredByName
        });

        if (!scoringCardImage) {
            console.error('Failed to generate scoring card image');
            return;
        }

        // Create attachment and send
        const attachment = new AttachmentBuilder(scoringCardImage, {
            name: `game_${gameId}_results.png`
        });

        await gamesChannel.send({
            content: game.players.map((p: any) => `<@${p.user.userId}>`).join(' '),
            files: [attachment]
        });

        try {
            const latest = await prisma.game.findFirst({ where: { gameId } });
            if (latest && latest.status !== 'VOIDED') {
                await prisma.game.update({ where: { id: latest.id }, data: { status: 'SCORED' as any } });
                console.log(`Game ${gameId} marked SCORED`);
            }
        } catch (e) {
            console.warn(`Failed to update game ${gameId} to SCORED`, e);
        }
    } catch (error) {
        console.error('Error sending scoring card:', error);
    } finally {
        try { await App.Redis.del(`scoringInProgress:${gameId}`); } catch {}
    }
}

// Fallback embed-based scoring card (in case image generation fails)
// async function sendScoringCardEmbed(guild: Guild, gameId: string, winningTeam: number, mvpPlayerIds: string[], scoringMethod: 'AI' | 'Manual' | 'Staff', scoredBy?: string): Promise<void> {
//     try {
//         // Get the games channel
//         const gamesChannel = await guild.channels.fetch(settings.channels.games);
//         if (!gamesChannel?.isTextBased()) {
//             return;
//         }

//         // Get complete game data
//         const game = await prisma.game.findFirst({
//             where: { gameId: data.gameId },
//             include: {
//                 players: {
//                     include: {
//                         user: true
//                     }
//                 },
//                 season: true
//             }
//         });

//         if (!game) {
//             return;
//         }

//         // Separate winners and losers
//         const winners = game.players.filter(p => p.discordTeam === data.winningTeam);
//         const losers = game.players.filter(p => p.discordTeam !== data.winningTeam);
//         const mvps = game.players.filter(p => data.mvpPlayerIds.includes(p.user.userId));

//         // Calculate ELO changes
//         const eloChanges = game.players.map(p => ({
//             player: p,
//             change: p.postElo - p.preElo
//         }));

//         // Format player lists with ELO changes
//         const formatPlayerList = (players: typeof game.players) => {
//             return players.map(p => {
//                 const eloChange = eloChanges.find(e => e.player.id === p.id)?.change || 0;
//                 const eloChangeStr = eloChange >= 0 ? `+${eloChange}` : `${eloChange}`;
//                 const mvpIndicator = mvps.some(mvp => mvp.id === p.id) ? ' 👑' : '';
//                 const displayName = p.user.nickname
//                     ? `${p.user.minecraftName} | ${p.user.nickname}`
//                     : p.user.minecraftName;

//                 return `<@${p.user.userId}> (${displayName}) [${eloChangeStr}]${mvpIndicator}`;
//             }).join('\n');
//         };

//         // Create the scoring card embed
//         const scoringEmbed = new EmbedBuilder()
//             .setTitle(`🏆 Game #${game.gameId} Results`)
//             .setColor(0x00ff00) // Green for completed games
//             .addFields([
//                 {
//                     name: `🥇 Team ${data.winningTeam} (Winners)`,
//                     value: formatPlayerList(winners) || 'No players',
//                     inline: false
//                 },
//                 {
//                     name: `❌ Team ${data.winningTeam === 1 ? 2 : 1} (Losers)`,
//                     value: formatPlayerList(losers) || 'No players',
//                     inline: false
//                 },
//                 {
//                     name: '📊 Game Details',
//                     value:
//                         `**Map:** ${game.mapPlaying || 'Unknown'}\n` +
//                         `**Season:** ${game.season?.name || 'Unknown'}\n` +
//                         `**Game Style:** ${game.gameStyle || 'Unknown'}\n` +
//                         `**Scoring Method:** ${data.scoringMethod}` +
//                         (data.scoredBy ? ` by <@${data.scoredBy}>` : ''),
//                     inline: false
//                 }
//             ])
//             .setFooter({
//                 text: `Completed at ${new Date().toLocaleString()}`,
//             })
//             .setTimestamp();

//         // Add MVP field if there are any MVPs
//         if (mvps.length > 0) {
//             const mvpNames = mvps.map(p => {
//                 const displayName = p.user.nickname
//                     ? `${p.user.minecraftName} | ${p.user.nickname}`
//                     : p.user.minecraftName;
//                 return `<@${p.user.userId}> (${displayName})`;
//             }).join('\n');

//             scoringEmbed.addFields([
//                 {
//                     name: '👑 MVPs',
//                     value: mvpNames,
//                     inline: false
//                 }
//             ]);
//         }

//         // Send the scoring card
//         await gamesChannel.send({
//             embeds: [scoringEmbed]
//         });
//     } catch (error) {
//         console.error('Error sending fallback scoring card embed:', error);
//     }
// }

export async function sendVoidGameCard(guild: Guild, gameId: string): Promise<void> {
    try {
        // Get the games channel
        const gamesChannel = await guild.channels.fetch(settings.channels.games);
        if (!gamesChannel?.isTextBased()) {
            console.error('Games channel not found or not text-based');
            return;
        }

        // Get complete game data
        const game = await prisma.game.findFirst({
            where: { gameId },
            include: {
                players: {
                    include: {
                        user: true
                    }
                },
                season: true
            }
        });

        if (!game) {
            console.error(`Game ${gameId} not found for void card`);
            return;
        }

        const playerMentions = game.players
            .map((p) => `<@${p.user.userId}>`)
            .join(" ");
        await gamesChannel
            .send({
                content: playerMentions,
                embeds: [
                    embeds.normal(
                        `Game ID **${gameId}** has been voided.`,
                        "Game Voided"
                    ),
                ],
            });
    } catch (error) {
        console.error('Error sending void game card:', error);
        // Don't throw - this shouldn't break the voiding process
    }
} 