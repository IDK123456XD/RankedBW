import { prisma } from "@common/database/connectors/prisma";
import { PlayerIncludingSeasonStatistics } from "@common/database/types/season";

export async function getRankPlace(
  playerData: PlayerIncludingSeasonStatistics
) {
  // Get the current active season
  const activeSeason = await prisma.season.findFirst({
    where: {
      active: true,
    },
  });

  // If no active season, return 0 (unranked)
  if (!activeSeason) {
    return 0;
  }

  // Get all player statistics for the current active season, ordered by ELO
  const players = await prisma.playerStatistics.findMany({
    where: {
      seasonId: activeSeason.id,
    },
    orderBy: { elo: "desc" },
  });

  return players.findIndex((x) => x.playerId === playerData.id) + 1;
}