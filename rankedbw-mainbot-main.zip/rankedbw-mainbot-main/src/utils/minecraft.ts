import axios from 'axios';
import { Player } from '@common/database/generated';
import { prisma } from '@common/database/connectors/prisma';

export const getUUID = async (username: string) => {
    try {
        const request = await axios.get(`https://api.mojang.com/users/profiles/minecraft/${username}`);
        return request.data?.id;
    } catch (err) {
        return null;
    }
}

export const fetchMojangProfile = async (uuid: string) => {
    try {
        const request = await axios.get(`https://sessionserver.mojang.com/session/minecraft/profile/${uuid}`);
        return request.data;
    } catch (err) {
        return null;
    }
}

export const fetchFullBodySkin = async (uuid: string) => {
    try {
        const fullSkinRes = await axios.get(`https://starlightskins.lunareclipse.studio/render/ultimate/${uuid}/full`, {
            responseType: 'arraybuffer'
        });

        return Buffer.from(fullSkinRes.data, 'binary').toString('base64');
    } catch (err) {
        console.log(err);
        return null;
    }
}

export const fetchHeadSkin = async (uuid: string) => {
    try {
        const fullSkinRes = await axios.get(`https://starlightskins.lunareclipse.studio/render/head/${uuid}/full`, {
            responseType: 'arraybuffer'
        });

        return Buffer.from(fullSkinRes.data, 'binary').toString('base64');
    } catch (err) {
        console.log(err);
        return null;
    }
}

export const updatePlayerProfile = async (player: Player) => {
    if (player.lastMojangFetch.getTime() >= Date.now() - 1000 * 60 * 30) {
        const mojangProfile = await fetchMojangProfile(player.uuid);

        await prisma.player.update({
            where: {
                id: player.id
            },
            data: {
                minecraftName: mojangProfile?.name,
                uuid: player.uuid,
            }
        });
    }
}