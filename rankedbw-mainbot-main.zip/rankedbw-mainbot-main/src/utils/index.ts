import { ButtonInteraction, ChannelSelectMenuInteraction, InteractionCollector, MentionableSelectMenuInteraction, ModalSubmitInteraction, RoleSelectMenuInteraction, StringSelectMenuInteraction, UserSelectMenuInteraction } from 'discord.js';
import Paginator from './discord/paginator';
import { prisma } from "@common/database/connectors/prisma";
import { PunishmentType } from "@common/database/generated/client";
import settings from "../settings";
import App from "../index";
import sendLogs from "./logs";

export function sleep(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

export function awaitCollectorEnd(collector: InteractionCollector<
    | StringSelectMenuInteraction
    | UserSelectMenuInteraction
    | RoleSelectMenuInteraction
    | MentionableSelectMenuInteraction
    | ChannelSelectMenuInteraction
    | ButtonInteraction
    | ModalSubmitInteraction> | Paginator
) {
    if (collector instanceof Paginator) {
        return new Promise((resolve) => collector.on('stop', () => resolve(null)));
    }

    return new Promise((resolve) => collector.on('end', () => resolve(null)));
}

export { TeamVoiceManager } from './teamVoiceManager';

/**
 * Checks for alting scenarios and applies ranked ban if needed
 * @param discordUserId - The Discord user ID attempting to register
 * @param minecraftUuid - The Minecraft UUID being registered to
 * @param minecraftName - The Minecraft name for logging purposes
 * @returns Object indicating if a ranked ban was applied and any error messages
 */
export async function checkAndHandleAlting(
    discordUserId: string,
    minecraftUuid: string,
    minecraftName: string
): Promise<{ rankedBanApplied: boolean; reason?: string; error?: string }> {
    try {
        // Check if the Minecraft account is associated with any ranked banned players
        const minecraftAccountCheck = await prisma.player.findFirst({
            where: {
                uuid: minecraftUuid,
                punishments: {
                    some: {
                        type: PunishmentType.rankedban,
                        expired: false
                    }
                }
            },
            include: {
                punishments: {
                    where: {
                        type: PunishmentType.rankedban,
                        expired: false
                    }
                }
            }
        });

        // Check if the Discord user has any ranked banned accounts
        const discordUserCheck = await prisma.player.findFirst({
            where: {
                userId: discordUserId,
                punishments: {
                    some: {
                        type: PunishmentType.rankedban,
                        expired: false
                    }
                }
            },
            include: {
                punishments: {
                    where: {
                        type: PunishmentType.rankedban,
                        expired: false
                    }
                }
            }
        });

        let shouldApplyBan = false;
        let banReason = '';

        if (minecraftAccountCheck) {
            shouldApplyBan = true;
            banReason = `Alting detection: Minecraft account ${minecraftName} is ranked banned on another Discord account`;
        } else if (discordUserCheck) {
            shouldApplyBan = true;
            banReason = `Alting detection: Discord user is ranked banned on Minecraft account ${discordUserCheck.minecraftName}`;
        }

        if (shouldApplyBan) {
            // Get the guild and member
            const guild = await App.client.guilds.fetch(settings.guild);
            if (!guild) {
                return { rankedBanApplied: false, error: 'Guild not found' };
            }

            const member = await guild.members.fetch(discordUserId).catch((): null => null);
            if (!member) {
                return { rankedBanApplied: false, error: 'Member not found' };
            }

            // Add the ranked ban role
            if (!member.roles.cache.has(settings.roles.rankedBan)) {
                await App.Redis.publish('change:role', JSON.stringify({
                    memberId: member.id,
                    roleId: settings.roles.rankedBan,
                    guildId: settings.guild,
                    action: 'add'
                }));
            }

            // Get or create the player record
            let player = await prisma.player.findFirst({
                where: { userId: discordUserId }
            });

            if (player) {
                // Create a new ranked ban punishment record
                await prisma.punishment.create({
                    data: {
                        type: PunishmentType.rankedban,
                        reason: banReason,
                        staff: 'System',
                        expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 999), // 999 days
                        expired: false,
                        Player: {
                            connect: { id: player.id }
                        }
                    }
                });
            }

            // Send logs
            await sendLogs(
                `**Alting detected:** <@${discordUserId}> (${minecraftName}) has been automatically ranked banned.\n**Reason:** ${banReason}`,
                'Automatic Ranked Ban - Alting Detection'
            );

            return { rankedBanApplied: true, reason: banReason };
        }

        return { rankedBanApplied: false };

    } catch (error) {
        console.error('Error in checkAndHandleAlting:', error);
        return { rankedBanApplied: false, error: 'System error during alting check' };
    }
}