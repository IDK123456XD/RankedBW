import { prisma } from "@common/database/connectors/prisma";
import { EloHistoryReason } from "@common/database/generated/client";
import App from "../index";
import settings from "../settings";
import { refreshEloData } from "./eloChecker";
import { PlayerIncludingSeasonStatistics } from "@common/database/types/season";

/**
 * Calculate how much elo should be restored when removing a strike
 * This prevents the "elo floor" bug where players gain free elo
 */
export async function calculateStrikeRemovalAmount(
  playerId: string
): Promise<number> {
  try {
    // Get the most recent strike elo history entry
    const recentStrike = await prisma.eloHistory.findFirst({
      where: {
        userId: playerId,
        reason: EloHistoryReason.Strike,
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    if (!recentStrike) {
      return 0; // No strike found
    }

    // Get the elo history entry right before this strike to see what the elo was
    const beforeStrike = await prisma.eloHistory.findFirst({
      where: {
        userId: playerId,
        createdAt: {
          lt: recentStrike.createdAt,
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    const eloBeforeStrike = beforeStrike?.elo || 0;
    const eloAfterStrike = recentStrike.elo;

    // The actual amount deducted is the difference
    // If they had 10 elo and got a strike, they went from 10 -> 0, so we only restore 10
    const actualDeduction = eloBeforeStrike - eloAfterStrike;

    return Math.max(0, actualDeduction); // Ensure we don't return negative values
  } catch (error) {
    console.error("Error calculating strike removal amount:", error);
    return 30; // Fallback to default strike amount
  }
}

const defaultChangeEloReturn: {
  success: boolean;
  prevElo: number | null;
  newElo: number | null;
} = {
  success: false,
  prevElo: null,
  newElo: null,
};

export async function changePlayerElo(
  player: PlayerIncludingSeasonStatistics,
  newElo: number,
  reason: EloHistoryReason,
  extraReason: string
) {
  try {
    const guild = await App.client.guilds.fetch(settings.guild);
    if (!guild) {
      console.error("No guild found when changing player ELO");
      return defaultChangeEloReturn;
    }

    const member = await guild.members.fetch(player.userId);
    if (!member) {
      console.error("No member found when changing player ELO");
      return defaultChangeEloReturn;
    }

    const activeSeason = await prisma.season.findFirst({
      where: { active: true },
    });
    if (!activeSeason) {
      console.error("No active season found when changing player ELO");
      return defaultChangeEloReturn;
    }

    const activeSeasonStats = player.PlayerStatistics.find(x => x.seasonId === activeSeason.id);
    if (!activeSeasonStats) {
      console.error("No active season stats found when changing player ELO");
      return defaultChangeEloReturn;
    }

    // Apply the elo floor
    const clampedElo = Math.max(0, newElo);

    // Update the player's ELO in the database
    await prisma.playerStatistics.update({
      where: { id: activeSeasonStats.id },
      data: {
        elo: clampedElo,
      },
    });

    // Log the ELO change for audit purposes
    await prisma.eloHistory.create({
      data: {
        userId: player.id,
        elo: clampedElo,
        reason,
        extraReason: extraReason,
        seasonId: activeSeason.id,
      },
    });

    await refreshEloData(member, player);

    if (clampedElo > activeSeasonStats.peakElo) {
      await prisma.playerStatistics.update({
        where: { id: activeSeasonStats.id },
        data: { peakElo: clampedElo },
      });
    }

    return {
      success: true,
      prevElo: activeSeasonStats.elo,
      newElo: clampedElo,
    };
  } catch (error) {
    console.error("Error changing player ELO:", error);
    return {
      success: false,
      prevElo: null,
      newElo: null,
    };
  }
}
