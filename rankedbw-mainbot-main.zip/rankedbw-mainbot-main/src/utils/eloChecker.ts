import { GuildMember } from "discord.js";
import settings, { ELO_DATA } from "../settings";
import App from "..";
import { IncludeCurrentSeasonStatistics, PlayerIncludingSeasonStatistics } from "@common/database/types/season";
import { prisma } from "@common/database/connectors/prisma";

export function eloHigharchy(elo: number) {
  if (elo < 600) return 0;
  if (elo < 800) return 1;
  return 2;
}

export function eloToRole(elo: number) {
  return (
    ELO_DATA.find((x) => x.min <= elo && x.max >= elo)?.roleId ||
    ELO_DATA[0].roleId
  );
}

export function eloToRank(elo: number) {
  return ELO_DATA.find((x) => x.min <= elo && x.max >= elo)?.name;
}

export function checkMiddleRoleElo(
  lowEloRoleId: string,
  highEloRoleId: string,
  eloRoleId: string
) {
  const roleArray = ELO_DATA.map((x) => x.roleId);

  const lowIndex = roleArray.indexOf(lowEloRoleId);
  const highIndex = roleArray.indexOf(highEloRoleId);
  const middleIndex = roleArray.indexOf(eloRoleId);

  return middleIndex >= lowIndex && middleIndex <= highIndex;
}

export function calculateEloChange(
  winner: boolean,
  mvp: boolean,
  currentElo: number,
  winstreak: number
) {
  const eloData = ELO_DATA.find((x) => x.min <= currentElo && x.max >= currentElo);

  if (!eloData) return 0;

  let totalElo = 0;
  if (winner) totalElo += eloData.gain;
  if (!winner) totalElo -= eloData.loss;
  if (mvp) totalElo += eloData.mvp;
  if (winstreak >= 10) totalElo += 10;

  return totalElo;
}

export async function refreshEloData(
  member: GuildMember,
  player: PlayerIncludingSeasonStatistics
) {
  const latestPlayer = await prisma.player.findUnique({
    where: {
      id: player.id
    },
    include: IncludeCurrentSeasonStatistics
  });

  try {
    const activeSeasonStats = latestPlayer.PlayerStatistics.find(x => x.season.active);

    const eloRole = eloToRole(activeSeasonStats.elo);
    const eloRoles = Array.from(member.roles.cache.values()).filter((x) =>
      ELO_DATA.some((e) => e.roleId === x.id)
    );

    for (const role of eloRoles) {
      if (member.roles.cache.has(role.id) && eloRole !== role.id) {
        await App.Redis.publish(
          "change:role",
          JSON.stringify({
            memberId: member.id,
            roleId: role.id,
            guildId: settings.guild,
            action: "remove",
          })
        );
      }
    }

    if (!member.roles.cache.has(eloRole)) {
      await App.Redis.publish(
        "change:role",
        JSON.stringify({
          memberId: member.id,
          roleId: eloRole,
          guildId: settings.guild,
          action: "add",
        })
      );
    }

    // Update nickname only if player has ELO prefix enabled
    if (latestPlayer.eloPrefix) {
      try {
        // Build the nickname with ELO prefix
        let newNickname = player.minecraftName;
        if (latestPlayer.nickname) newNickname += ` | ${latestPlayer.nickname}`;

        newNickname = `[${activeSeasonStats.elo}] ${newNickname}`;

        await App.Redis.publish(
          "change:nickname",
          JSON.stringify({
            memberId: member.id,
            nickname: newNickname,
            guildId: settings.guild,
          })
        );
      } catch (error) {
        console.error("Failed to set nickname:", error);
      }
    }
  } catch (err) {
    void err;
  }
}
