import { APIEmbedField, MessageCreateOptions } from 'discord.js';
import settings from '../settings';
import embeds from './discord/embeds';
import App from '..';

export default async function sendLogs(
    description: string,
    title: string,
    content?: string,
    channelId?: string,
    fields?: APIEmbedField[]
) {
    try {
        const sendData: MessageCreateOptions = {
            embeds: [embeds.normal(description, title).addFields(fields?.length ? fields : [])]
        };
        if (content) sendData.content = content;

        const targetChannelId = channelId || settings.channels.botLogs;
        const channel = await App.client.channels.fetch(targetChannelId);

        if (channel && channel.isTextBased() && 'send' in channel) {
            await channel.send(sendData);
        } else {
            console.warn(`[SEND_LOGS] Channel ${targetChannelId} not found or not text-based`);
        }
    } catch (error) {
        console.error(`[SEND_LOGS] Failed to send log message:`, error);
    }
}