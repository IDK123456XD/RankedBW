import { Colors, EmbedBuilder } from 'discord.js';

const color = Colors.White;
export const footerText = 'Ranked Bedwars';

function normal(description?: string, title?: string, footer = true, timestamp = false) {
    const embed = new EmbedBuilder().setColor(color);

    if (description) embed.setDescription(description);
    if (title) embed.setTitle(title);
    if (footer) {
        if (timestamp) embed.setTimestamp();
        embed.setFooter({
            text: footerText,
        });
    }

    return embed;
}

function error(text: string, title?: string, footer = true) {
    const embed = new EmbedBuilder()
        .setTitle('Error Detected')
        .setDescription(text)
        .setColor(Colors.Red)

    if (title) embed.setTitle(title);

    if (footer) {
        embed.setTimestamp();
        embed.setFooter({
            text: footerText,
        });
    }

    return embed;
}

function warning(text: string, title?: string, footer = true) {
    const embed = new EmbedBuilder()
        .setDescription(text)
        .setColor(Colors.Yellow)

    if (title) embed.setTitle(title);

    if (footer) {
        embed.setTimestamp();
        embed.setFooter({
            text: footerText,
        });
    }

    return embed;
}

function success(text: string, title?: string, footer = true) {
    const embed = new EmbedBuilder()
        .setDescription(text)
        .setColor(Colors.Green)

    if (title) embed.setTitle(title);

    if (footer) {
        embed.setTimestamp();
        embed.setFooter({
            text: footerText,
        });
    }

    return embed;
}

function question(description: string, title = 'Automated Question') {
    return new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color)
        .setFooter({
            text: footerText,
        })
        .setTimestamp();
}

function empty() {
    return new EmbedBuilder()
        .setColor(color)
        .setFooter({
            text: footerText,
        })
        .setTimestamp();
}

export default {
    normal,
    error,
    question,
    empty,
    success,
    warning,
};