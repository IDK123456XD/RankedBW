import { ChannelType, Guild, PermissionsBitField, VoiceBasedChannel, VoiceChannel } from 'discord.js';
import App from '../index';
import settings from '../settings';

interface TeamChannelPair {
    gameId: string;
    team1: string;
    team2: string;
    inUse?: boolean;
    actualGameId?: string;
}

interface VoiceChannelPair {
    gameId: string;
    team1: VoiceBasedChannel;
    team2: VoiceBasedChannel;
    inUse?: boolean;
    actualGameId?: string;
}

export class TeamVoiceManager {
    static async findAvailableChannelPair(guild: Guild): Promise<VoiceChannelPair | null> {
        try {
            const teamChannelsData = await App.Redis.get('teamVoiceChannels');
            if (!teamChannelsData) {
                console.log('No team voice channels found in Redis');
                return null;
            }

            const teamChannels: TeamChannelPair[] = JSON.parse(teamChannelsData);
            console.log(`Looking for available channel pair among ${teamChannels.length} pairs`);

            // Get currently in-use channels
            const inUseData = await App.Redis.get('teamVoiceChannelsInUse');
            const inUseChannels: string[] = inUseData ? JSON.parse(inUseData) : [];
            console.log(`Currently in use: ${inUseChannels.length} channels`);

            // Sort channel pairs by the actual position of their first channel to ensure chronological order
            const sortedChannels = teamChannels.sort((a, b) => {
                const channelA = guild.channels.cache.get(a.team1);
                const channelB = guild.channels.cache.get(b.team1);
                if (!channelA || !channelB || !('position' in channelA) || !('position' in channelB)) return 0;
                return channelA.position - channelB.position;
            });

            // Find first available pair
            for (const channelPair of sortedChannels) {
                if (!inUseChannels.includes(channelPair.team1) && !inUseChannels.includes(channelPair.team2)) {
                    // Verify channels still exist
                    const team1Channel = guild.channels.cache.get(channelPair.team1);
                    const team2Channel = guild.channels.cache.get(channelPair.team2);

                    if (team1Channel?.isVoiceBased() && team2Channel?.isVoiceBased()) {
                        console.log(`Found available channel pair: ${channelPair.gameId} (${team1Channel.name}, ${team2Channel.name})`);
                        return {
                            gameId: channelPair.gameId,
                            team1: team1Channel,
                            team2: team2Channel,
                        };
                    } else {
                        console.log(`Channel pair ${channelPair.gameId} has invalid channels, skipping`);
                    }
                } else {
                    console.log(`Channel pair ${channelPair.gameId} is in use, skipping`);
                }
            }

            console.log('No available channel pairs found');
            
            await this.forceReleaseEmptyChannels(guild);
            
            const updatedInUseData = await App.Redis.get('teamVoiceChannelsInUse');
            const updatedInUseChannels: string[] = updatedInUseData ? JSON.parse(updatedInUseData) : [];
            
            // Re-sort after cleanup to maintain chronological order
            const reSortedChannels = teamChannels.sort((a, b) => {
                const channelA = guild.channels.cache.get(a.team1);
                const channelB = guild.channels.cache.get(b.team1);
                if (!channelA || !channelB || !('position' in channelA) || !('position' in channelB)) return 0;
                return channelA.position - channelB.position;
            });
            
            for (const channelPair of reSortedChannels) {
                if (!updatedInUseChannels.includes(channelPair.team1) && !updatedInUseChannels.includes(channelPair.team2)) {
                    const team1Channel = guild.channels.cache.get(channelPair.team1);
                    const team2Channel = guild.channels.cache.get(channelPair.team2);

                    if (team1Channel?.isVoiceBased() && team2Channel?.isVoiceBased()) {
                        console.log(`Found available channel pair after cleanup: ${channelPair.gameId} (${team1Channel.name}, ${team2Channel.name})`);
                        return {
                            gameId: channelPair.gameId,
                            team1: team1Channel,
                            team2: team2Channel,
                            actualGameId: channelPair.actualGameId,
                            inUse: channelPair.inUse
                        };
                    }
                }
            }
            
            console.log('No available channel pairs found even after cleanup');
            return null;
        } catch (error) {
            console.error('Error finding available channel pair:', error);
            return null;
        }
    }

    static async optionallyCreateChannelPair(guild: Guild): Promise<TeamChannelPair | null> {
        try {
            const existingChannels = await App.Redis.get('teamVoiceChannels');
            if (existingChannels) return;

            // Get the teams category
            const teamsCategory = await guild.channels.fetch(settings.categories.teams);
            if (!teamsCategory || teamsCategory.type !== ChannelType.GuildCategory) {
                return;
            }

            // Get all voice channels in the teams category, sorted by position for chronological order
            const voiceChannels = teamsCategory.children.cache
                .filter(channel => channel.type === ChannelType.GuildVoice)
                .sort((a, b) => a.position - b.position)
                .map(channel => channel);

            if (voiceChannels.length < 2) return;

            // Create team pairs
            const teamPairs = [];
            for (let i = 0; i < voiceChannels.length - 1; i += 2) {
                const team1Channel = voiceChannels[i];
                const team2Channel = voiceChannels[i + 1];

                if (team1Channel && team2Channel) {
                    teamPairs.push({
                        gameId: `PAIR_${i / 2 + 1}`,
                        team1: team1Channel.id,
                        team2: team2Channel.id
                    });
                }
            }

            // Store in Redis
            await App.Redis.set('teamVoiceChannels', JSON.stringify(teamPairs));

            // Initialize empty in-use list
            await App.Redis.set('teamVoiceChannelsInUse', JSON.stringify([]));
        } catch (error) {
            console.error('Error setting up team voice channels:', error);
        }
    }

    static async reserveChannelPair(channelPair: VoiceChannelPair, actualGameId: string): Promise<void> {
        try {
            const inUseData = await App.Redis.get('teamVoiceChannelsInUse');
            const inUseChannels: string[] = inUseData ? JSON.parse(inUseData) : [];

            inUseChannels.push(channelPair.team1.id, channelPair.team2.id);
            await App.Redis.set('teamVoiceChannelsInUse', JSON.stringify(inUseChannels));

            // Store the mapping for cleanup later
            await App.Redis.set(`teamVoiceGame:${actualGameId}`, JSON.stringify({
                team1: channelPair.team1.id,
                team2: channelPair.team2.id,
                originalGameId: channelPair.gameId
            }));
        } catch (error) {
            console.error('Error reserving channel pair:', error);
        }
    }

    static async setupChannelsForGame(
        guild: Guild,
        channelPair: TeamChannelPair,
        actualGameId: string,
        team1Players: string[],
        team2Players: string[],
        options?: { restrict?: boolean }
    ): Promise<{ team1Channel: VoiceChannel; team2Channel: VoiceChannel } | null> {
        try {
            const team1Channel = guild.channels.cache.get(channelPair.team1) as VoiceChannel;
            const team2Channel = guild.channels.cache.get(channelPair.team2) as VoiceChannel;

            if (!team1Channel || !team2Channel) {
                console.error('Team channels not found');
                return null;
            }

            const restrict = options?.restrict ?? true;

            const existingPermCacheTeam1 = await App.Redis.get(`teamVoicePerms:${actualGameId}:team1`);
            const existingPermCacheTeam2 = await App.Redis.get(`teamVoicePerms:${actualGameId}:team2`);

            if (!existingPermCacheTeam1 || !existingPermCacheTeam2) {
                const team1OriginalPerms = team1Channel.permissionOverwrites.cache.map(overwrite => ({
                    id: overwrite.id,
                    allow: overwrite.allow,
                    deny: overwrite.deny,
                    type: overwrite.type
                }));

                const team2OriginalPerms = team2Channel.permissionOverwrites.cache.map(overwrite => ({
                    id: overwrite.id,
                    allow: overwrite.allow,
                    deny: overwrite.deny,
                    type: overwrite.type
                }));

                await App.Redis.set(`teamVoicePerms:${actualGameId}:team1`, JSON.stringify({
                    channelId: team1Channel.id,
                    originalPermissions: team1OriginalPerms,
                    calledUsers: []
                }));

                await App.Redis.set(`teamVoicePerms:${actualGameId}:team2`, JSON.stringify({
                    channelId: team2Channel.id,
                    originalPermissions: team2OriginalPerms,
                    calledUsers: []
                }));
            }

            if (!restrict) {
                const staffRoleId = '1382406422322741278';
                const creatorRoleId = '1382406424356720681';
                const primeRoleId = '1382406425397035159';
                const primePlusRoleId = '1387380487299006605';
                const primePlusPlusRoleId = '1387380506953384087';
                
                await Promise.all([
                    team1Channel.edit({
                        name: `Game ${actualGameId} | Team 1`,
                        permissionOverwrites: [
                            {
                                id: guild.id,
                                allow: [PermissionsBitField.Flags.ViewChannel],
                                deny: [PermissionsBitField.Flags.Connect]
                            },
                            {
                                id: staffRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: []
                            },
                            {
                                id: creatorRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: []
                            },
                            {
                                id: primeRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: []
                            },
                            {
                                id: primePlusRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: []
                            },
                            {
                                id: primePlusPlusRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: [] as bigint[]
                            },
                            ...team1Players.map(playerId => ({
                                id: playerId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: [] as bigint[]
                            }))
                        ]
                    }),
                    team2Channel.edit({
                        name: `Game ${actualGameId} | Team 2`,
                        permissionOverwrites: [
                            {
                                id: guild.id,
                                allow: [PermissionsBitField.Flags.ViewChannel],
                                deny: [PermissionsBitField.Flags.Connect]
                            },
                            {
                                id: staffRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: []
                            },
                            {
                                id: creatorRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: []
                            },
                            {
                                id: primeRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: []
                            },
                            {
                                id: primePlusRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: []
                            },
                            {
                                id: primePlusPlusRoleId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: [] as bigint[]
                            },
                            ...team2Players.map(playerId => ({
                                id: playerId,
                                allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                                deny: [] as bigint[]
                            }))
                        ]
                    })
                ]);
                return { team1Channel, team2Channel };
            }

            const team1OriginalPerms = team1Channel.permissionOverwrites.cache.map(overwrite => ({
                id: overwrite.id,
                allow: overwrite.allow,
                deny: overwrite.deny,
                type: overwrite.type
            }));
            const team2OriginalPerms = team2Channel.permissionOverwrites.cache.map(overwrite => ({
                id: overwrite.id,
                allow: overwrite.allow,
                deny: overwrite.deny,
                type: overwrite.type
            }));

            const staffRoleId = '1382406422322741278';
            const creatorRoleId = '1382406424356720681';
            const primeRoleId = '1382406425397035159';
            const primePlusRoleId = '1387380487299006605';
            const primePlusPlusRoleId = '1387380506953384087';

            await team1Channel.edit({
                name: `Game ${actualGameId} | Team 1`,
                permissionOverwrites: [
                    // Base guild: can view but cannot connect; prevents opposite team / outsiders joining
                    {
                        id: guild.id,
                        allow: [PermissionsBitField.Flags.ViewChannel],
                        deny: [PermissionsBitField.Flags.Connect],
                    },
                    {
                        id: creatorRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: primeRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: primePlusRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: primePlusPlusRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: staffRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    ...team1Players.map(playerId => ({
                        id: playerId,
                        allow: [
                            PermissionsBitField.Flags.ViewChannel,
                            PermissionsBitField.Flags.Connect,
                            PermissionsBitField.Flags.Speak,
                            PermissionsBitField.Flags.SendMessages,
                            PermissionsBitField.Flags.ReadMessageHistory
                        ],
                    }))
                ]
            });

            await team2Channel.edit({
                name: `Game ${actualGameId} | Team 2`,
                permissionOverwrites: [
                    {
                        id: guild.id,
                        allow: [PermissionsBitField.Flags.ViewChannel],
                        deny: [PermissionsBitField.Flags.Connect],
                    },
                    {
                        id: creatorRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: primeRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: primePlusRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: primePlusPlusRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: staffRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    {
                        id: staffRoleId,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak],
                        deny: []
                    },
                    ...team2Players.map(playerId => ({
                        id: playerId,
                        allow: [
                            PermissionsBitField.Flags.ViewChannel,
                            PermissionsBitField.Flags.Connect,
                            PermissionsBitField.Flags.Speak,
                            PermissionsBitField.Flags.SendMessages,
                            PermissionsBitField.Flags.ReadMessageHistory
                        ],
                    }))
                ]
            });

            return { team1Channel, team2Channel };
        } catch (error) {
            console.error('Error setting up channels for game:', error);
            return null;
        }
    }

    static async addCalledUser(channelId: string, userId: string, guild: Guild): Promise<void> {
        try {
            const channel = guild.channels.cache.get(channelId) as VoiceChannel;

            if (!channel) return;

            // Give user permissions
            await channel.permissionOverwrites.create(userId, {
                ViewChannel: true,
                Connect: true,
                Speak: false,
                UseSoundboard: false,
            });
        } catch (error) {
            console.error('Error adding called user:', error);
        }
    }

    // static async resetAllEmptyChannels(guild: Guild): Promise<void> {
    //     const teamChannelsData = await App.Redis.get('teamVoiceChannels');
    //     if (!teamChannelsData) return;

    //     const teamChannels: TeamChannelPair[] = JSON.parse(teamChannelsData);

    //     for (const channelPair of teamChannels) {
    //         const team1Channel = guild.channels.cache.get(channelPair.team1) as VoiceChannel;
    //         const team2Channel = guild.channels.cache.get(channelPair.team2) as VoiceChannel;

    //         if (team1Channel.members.size === 0 && team2Channel.members.size === 0) {
    //             await this.resetSingleChannel(team1Channel);
    //             await this.resetSingleChannel(team2Channel);
    //             await this.releaseChannelsFromInUse(team1Channel.id, team2Channel.id);
    //             await App.Redis.del(`teamVoiceGame:${channelPair.gameId}`);
    //         }
    //     }
    // }

    static async resetChannelsAfterGame(guild: Guild, gameId: string, moveMembers = true, forceReset = false): Promise<void> {
        try {
            const gameChannelsData = await App.Redis.get(`teamVoiceGame:${gameId}`);
            if (!gameChannelsData) {
                return;
            }

            const { team1: team1ChannelId, team2: team2ChannelId } = JSON.parse(gameChannelsData);

            // Fetch channels with fresh data to avoid stale cache
            let team1Channel: VoiceChannel | null = null;
            let team2Channel: VoiceChannel | null = null;
            
            try {
                team1Channel = await guild.channels.fetch(team1ChannelId, { force: true }) as VoiceChannel;
            } catch (e: any) {
                // Channel not found
            }
            
            try {
                team2Channel = await guild.channels.fetch(team2ChannelId, { force: true }) as VoiceChannel;
            } catch (e: any) {
                // Channel not found
            }
            
            // CRITICAL SAFETY CHECK: Verify channel names contain the gameId
            // This prevents resetting channels that have been reassigned to a different game
            const team1NameMatches = team1Channel?.name.includes(gameId);
            const team2NameMatches = team2Channel?.name.includes(gameId);
            
            if (!forceReset) {
                if (team1Channel && !team1NameMatches) {
                    console.warn(`[VOICE-RESET] SAFETY ABORT: Team 1 channel "${team1Channel.name}" does not contain gameId ${gameId}`);
                    team1Channel = null;
                }
                if (team2Channel && !team2NameMatches) {
                    console.warn(`[VOICE-RESET] SAFETY ABORT: Team 2 channel "${team2Channel.name}" does not contain gameId ${gameId}`);
                    team2Channel = null;
                }
                
                if (!team1Channel && !team2Channel) {
                    await App.Redis.del(`teamVoiceGame:${gameId}`);
                    await App.Redis.del(`gameCreatedAt:${gameId}`);
                    return;
                }
            }

            if (moveMembers && !forceReset) {
                // Check if game is still active before moving members
                const hasMembers = (team1Channel?.members.size ?? 0) > 0 || (team2Channel?.members.size ?? 0) > 0;
                
                if (hasMembers) {
                    // Check if this is a premature reset (game created recently)
                    const gameAge = await App.Redis.get(`gameCreatedAt:${gameId}`);
                    if (gameAge) {
                        const ageMs = Date.now() - parseInt(gameAge);
                        const ageMinutes = ageMs / (1000 * 60);
                        
                        // Don't move members if game is less than 10 minutes old (likely still setting up/playing)
                        if (ageMinutes < 10) {
                            return;
                        }
                    }
                }
                
                // Move users currently in the game channels to the waiting room
                if (team1Channel) {
                    for (const [memberId, member] of team1Channel.members) {
                        try {
                            await member.voice.setChannel(settings.voiceChannels.waitingRoom);
                        } catch (err) {
                            console.error(`[VOICE-RESET] Failed to move member ${memberId}:`, err);
                        }
                    }
                }
                if (team2Channel) {
                    for (const [memberId, member] of team2Channel.members) {
                        try {
                            await member.voice.setChannel(settings.voiceChannels.waitingRoom);
                        } catch (err) {
                            console.error(`[VOICE-RESET] Failed to move member ${memberId}:`, err);
                        }
                    }
                }
                
                await new Promise(resolve => setTimeout(resolve, 1000));
            }

            if (team1Channel) await this.resetSingleChannel(team1Channel);
            if (team2Channel) await this.resetSingleChannel(team2Channel);
            
            await this.releaseChannelsFromInUse(team1ChannelId, team2ChannelId);

            await App.Redis.del(`teamVoiceGame:${gameId}`);
            await App.Redis.del(`gameCreatedAt:${gameId}`);
        } catch (error) {
            console.error('[VOICE-RESET] Error resetting channels:', error);
        }
    }

    private static async resetSingleChannel(channel: VoiceChannel): Promise<void> {
        await channel.lockPermissions();
    }

    static async releaseChannelsFromInUse(team1ChannelId: string, team2ChannelId: string): Promise<void> {
        const inUseData = await App.Redis.get('teamVoiceChannelsInUse');
        let inUseChannels: string[] = inUseData ? JSON.parse(inUseData) : [];

        inUseChannels = inUseChannels.filter(id => id !== team1ChannelId && id !== team2ChannelId);

        await App.Redis.set('teamVoiceChannelsInUse', JSON.stringify(inUseChannels));
    }

    static async getGameChannels(gameId: string): Promise<{ team1: string; team2: string } | null> {
        const gameChannelsData = await App.Redis.get(`teamVoiceGame:${gameId}`);
        if (!gameChannelsData) return null;
        return JSON.parse(gameChannelsData);
    }

    static async forceReleaseEmptyChannels(guild: Guild): Promise<void> {
        try {
            const inUseData = await App.Redis.get('teamVoiceChannelsInUse');
            if (!inUseData) return;

            const inUseChannels: string[] = JSON.parse(inUseData);
            console.log(`Checking ${inUseChannels.length} in-use channels for emptiness`);

            const channelsToRelease: string[] = [];
            const gameIdsToCleanup: string[] = [];

            for (const channelId of inUseChannels) {
                // Fetch channel with force: true to get fresh data from API, not stale cache
                let channel: VoiceChannel | null = null;
                try {
                    channel = await guild.channels.fetch(channelId, { force: true }) as VoiceChannel;
                } catch (error) {
                    console.log(`Channel ${channelId} no longer exists or failed to fetch, marking for release`);
                    channelsToRelease.push(channelId);
                    continue;
                }
                
                if (!channel) {
                    console.log(`Channel ${channelId} no longer exists, marking for release`);
                    channelsToRelease.push(channelId);
                    continue;
                }

                if (channel.members.size === 0) {
                    console.log(`Channel ${channel.name} (${channelId}) is empty, marking for release`);
                    channelsToRelease.push(channelId);
                }
            }

            if (channelsToRelease.length === 0) {
                console.log(`No empty channels found`);
                return;
            }

            const teamChannelsData = await App.Redis.get('teamVoiceChannels');
            if (teamChannelsData) {
                const teamChannels = JSON.parse(teamChannelsData);
                
                for (const channelPair of teamChannels) {
                    const bothEmpty = channelsToRelease.includes(channelPair.team1) && 
                                     channelsToRelease.includes(channelPair.team2);
                    
                    if (bothEmpty) {
                        gameIdsToCleanup.push(channelPair.gameId);
                    }
                }
            }

            const updatedInUse = inUseChannels.filter(channelId => !channelsToRelease.includes(channelId));
            await App.Redis.set('teamVoiceChannelsInUse', JSON.stringify(updatedInUse));

            for (const gameId of gameIdsToCleanup) {
                await App.Redis.del(`teamVoiceGame:${gameId}`);
            }

            console.log(`Released ${channelsToRelease.length} channels. Now ${updatedInUse.length} in use.`);

        } catch (error) {
            console.error('Error in forceReleaseEmptyChannels:', error);
        }
    }
} 