import App from '../index';
import { Channel } from 'discord.js';

export async function safeFetchChannel(channelId: string, context?: string): Promise<Channel | null> {
  try {
    if (!channelId) return null;
    const ch = await App.client.channels.fetch(channelId);
    return ch ?? null;
  } catch (e: any) {
    const code = e?.code;
    if (code === 10003) {
      console.warn(`[safeFetchChannel] Unknown Channel (10003) id=${channelId}${context ? ' ctx=' + context : ''}`);
      return null;
    }
    if (code === 50001 || code === 50013) { 
      console.warn(`[safeFetchChannel] Missing access/permission id=${channelId} code=${code}${context ? ' ctx=' + context : ''}`);
      return null;
    }
    console.error(`[safeFetchChannel] Unexpected error fetching channel id=${channelId}${context ? ' ctx=' + context : ''}`, e);
    return null;
  }
}

export default safeFetchChannel;