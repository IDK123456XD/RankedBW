import axios from 'axios';
import { HypixelPlayerResponse } from '../types/hypixelPlayerResponse';

export const getHypixelPlayerData = async (uuid: string, key: string) => {
    try {
        const request = await axios.get(`https://api.hypixel.net/v2/player?uuid=${uuid}`, {
            headers: {
                'API-Key': key
            }
        });

        return request.data as HypixelPlayerResponse;
    } catch (err) {
        console.log(err);
        return null;
    }
}