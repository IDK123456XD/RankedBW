/**
 * XP needed to go from `currentLevel` → `currentLevel + 1`
 * 
 * Level 1 → 2: 10 000  
 * Level 2 → 3: 12 500  
 * Level 3 → 4: 15 000  
 * …etc., with an increment of +2 500 each level.
 */
export function xpForNextLevel(currentLevel: number): number {
  return 2_500 * currentLevel + 7_500;
}

/**
 * Cumulative XP required to reach a given `level` from level 1.
 *  - to reach level 1: 0 XP  
 *  - to reach level 2: 10 000 XP  
 *  - to reach level 3: 10 000 + 12 500 = 22 500 XP  
 *  - etc.
 * 
 * Closed-form of:  
 *   sum_{i=1..(level-1)} [2 500*i + 7 500]
 */
export function totalXpToReachLevel(level: number): number {
  const n = level - 1;
  // sum = 2 500 * (n(n+1)/2)  + 7 500 * n
  //     = 1 250 n(n+1)       + 7 500 n
  return 1_250 * n * (n + 1) + 7_500 * n;
}

/**
 * Given a total XP, figure out:
 *  - currentLevel,
 *  - xpIntoLevel      (how much XP they've earned since hitting that level),
 *  - xpNeededForNext  (xpForNextLevel(currentLevel)),
 *  - xpRemaining      (xpNeededForNext - xpIntoLevel)
 */
export function getPlayerProgress(totalXp: number) {
  // Solve:  totalXpToReachLevel(level) <= totalXp
  // Let n = level - 1.  We need the largest integer n ≥ 0 such that
  //   1 250 n(n+1) + 7 500 n  ≤ totalXp
  // ⇔ 1 250 n² + 8 750 n - totalXp ≤ 0
  //
  // Quadratic formula:
  const a = 1_250;
  const b = 8_750;
  const c = -totalXp;
  const disc = b * b - 4 * a * c;
  const sqrtDisc = Math.sqrt(disc);
  // positive root for n:
  const n = Math.floor((-b + sqrtDisc) / (2 * a));
  const level = n + 1;

  const xpIntoLevel = totalXp - totalXpToReachLevel(level);
  const xpNeededForNext = xpForNextLevel(level);
  const xpRemaining = xpNeededForNext - xpIntoLevel;

  return {
    level,
    xpIntoLevel,
    xpNeededForNext,
    xpRemaining,
  };
}

/**
 * Helper function to convert old level + xp system to new totalXp system
 * Assumes the old system had a flat 1000 XP per level
 */
export function convertOldLevelSystemToTotalXp(oldLevel: number, oldXp: number): number {
  // Calculate what the totalXp should be based on old level (assuming 1000 XP per level)
  const baseXpFromLevels = (oldLevel - 1) * 1000;
  return baseXpFromLevels + oldXp;
}

/**
 * Calculates XP rewards for a player based on game results
 * @param currentElo - Player's current ELO rating
 * @param isWinner - Whether the player was on the winning team
 * @param isMvp - Whether the player received MVP
 * @returns Total XP reward for the game
 */
export function calculateXpReward(currentElo: number, isWinner: boolean, isMvp: boolean): number {
    let totalXp = 0;
    
    // Base XP for win/loss
    if (isWinner) {
        totalXp += 30 * currentElo;  // 30 * elo for wins
    } else {
        totalXp += 15 * currentElo;  // 15 * elo for losses
    }
    
    // MVP bonus
    if (isMvp) {
        totalXp += 5 * currentElo;   // 5 * elo for MVP
    }
    
    return totalXp;
} 