import { Settings } from "@common/database/generated";
import { ALLOWED_MAPS } from "../settings";

export async function checkQueueOpen(dbSettings: Settings) {
    if (!dbSettings.queuesOpen) return false;

    const maps = ALLOWED_MAPS.filter(map => map.gameStyle.some(y => y === dbSettings.gameStyle) && map.in_rotation);

    if (maps.length === 0) return false;

    return true;
}