import {
  ActivityType,
  Client,
  Collection,
  IntentsBitField,
  Partials,
  REST,
  Routes,
} from 'discord.js';
import { config } from 'dotenv';

import fs from 'fs';
import path from 'path';

import { CronJob } from 'cron';
import { Redis } from 'ioredis';
import {
  AllCommandTypes,
  ChildCommand,
  Command,
  ParentCommand,
} from './commands';
import connectors from '@common/database';
import Event from './events';
import Task from './tasks';
import { CommandInterface } from './types/discord';
import Logger from './utils/logger';
import './utils/prototypes';

config({
  path: path.join(__dirname, '..', '.env'),
  override: true
});

interface Constructor<T> {
  new(): T;
}

export interface CommandCategoryInfo {
  name: string;
  description: string;
  commands: AllCommandTypes[];
  sub?: CommandCategoryInfo[];
}

export default class App {
  public static initiated = false;

  public static client = new Client({
    intents: [
      IntentsBitField.Flags.Guilds,
      IntentsBitField.Flags.GuildMembers,
      IntentsBitField.Flags.GuildVoiceStates,
      IntentsBitField.Flags.MessageContent,
      IntentsBitField.Flags.GuildMessages,
      IntentsBitField.Flags.DirectMessages,
      IntentsBitField.Flags.GuildMessageReactions,
    ],
    partials: [
      Partials.Message,
      Partials.Channel,
      Partials.Reaction,
      Partials.GuildMember,
      Partials.User,
      Partials.ThreadMember,
    ],
  });

  public static directories = [
    path.join(__dirname, 'events'),
    path.join(__dirname, 'tasks'),
    path.join(__dirname, 'commands'),
  ];

  public static commands: AllCommandTypes[] = [];
  public static commandMenu: CommandCategoryInfo[] = [];

  public static events: Collection<string, Event> = new Collection();

  public static tasks: Collection<string, Task> = new Collection();
  public static cronJobs: Collection<string, CronJob> = new Collection();

  public static registeredCommands: CommandInterface[] = [];

  public static privateRest = new REST({ version: '10' });
  public static Redis: Redis;
  public static RedisSub: Redis;

  public static async init() {
    if (!this.initiated) {
      process.stdin.resume();

      this.privateRest.setToken(process.env.DISCORD_BOT_TOKEN);

      process.on('uncaughtException', (err) => {
        Logger.error('UNCAUGHT_EXCEPTION', err);
      });

      ['exit', 'SIGINT', 'SIGTERM', 'SIGQUIT', 'SIGUSR1', 'SIGUSR2']
        .forEach(signal => process.on(signal, () => {
          this.shutdown();
        }));

      this.Redis = await connectors.connectRedis();
      this.RedisSub = await connectors.connectRedis('subscriber');

      this.client.login(process.env.DISCORD_BOT_TOKEN);

      this.client.once('ready', (client) => {
        Logger.info(
          'BOT',
          `Connected to discord user ${client.user.tag}!`,
        );

        this.client.user.setStatus('online');
        this.client.user.setActivity({
          name: 'Ranked Bedwars',
          type: ActivityType.Watching
        });
        this.directories.forEach((x) => this.loadModules(x));
        this.loadSlashCommands();
        this.initiated = true;
      });

    }
  }

  private static loadModules(directoryPath: string): void {
    const directoryStats = fs.statSync(directoryPath);
    if (!directoryStats.isDirectory()) {
      Logger.error(
        'LOAD_MODULES',
        `The ${directoryPath} directory is not available.`,
      );
    }

    const files = fs.readdirSync(directoryPath);
    files.forEach((file) => {
      const filePath = path.join(directoryPath, file);
      const fileStats = fs.statSync(filePath);

      if (fileStats.isDirectory()) {
        this.loadModules(filePath);
        return;
      }
      if (
        !fileStats.isFile()
        || !/^.*\.(js|ts|jsx|tsx)$/i.test(file)
        || path.parse(filePath).name === 'index'
      ) return;

      const module = require(filePath);
      // If the file does not have a class, then don't use it
      let ModuleFunction: Constructor<Event | Task | AllCommandTypes> | null = null;
      if (typeof module === 'function') ModuleFunction = module;
      else if (module && module.default) ModuleFunction = module.default;

      if (!ModuleFunction) return;

      try {
        const moduleObject = new ModuleFunction();
        if (
          moduleObject &&
          moduleObject instanceof Event &&
          moduleObject.eventNames?.length
        ) {
          if (this.events.has(filePath)) {
            Logger.error(
              'LOAD_MODULES',
              `Event at ${filePath} is already loaded!`,
            );
            throw new Error(`Event at ${filePath} is already loaded!`);
          } else {
            for (const eventName of moduleObject.eventNames) {
              this.client.addListener(
                eventName,
                async (...args) => moduleObject.handle.bind(moduleObject)(...args, eventName),
              );
            }
            this.events.set(filePath, moduleObject);
          }

        } else if (
          moduleObject instanceof Task &&
          moduleObject?.taskName
        ) {
          if (this.tasks.has(moduleObject.taskName)) {
            Logger.warn(
              'LOAD_MODULES',
              `Duplicate task ${moduleObject.taskName}.`,
            );
          } else {
            this.tasks.set(moduleObject.taskName, moduleObject);

            if (moduleObject.onStart) moduleObject.execute();

            const newCronJob = new CronJob(
              moduleObject.cronTime,
              function () {
                moduleObject.execute.bind(moduleObject)();
              },
              null,
              true,
              moduleObject.timezone
            );

            this.cronJobs.set(moduleObject.taskName, newCronJob);

            newCronJob.start();

            Logger.info(
              'LOAD_MODULES',
              `Task ${moduleObject.taskName} loaded, interval ${moduleObject.cronTime}. (Timezone: ${moduleObject.timezone || 'UTC'})`,
            );
          }
        } else if (
          moduleObject instanceof Command
          || moduleObject instanceof ParentCommand
          || moduleObject instanceof ChildCommand
        ) {
          this.commands.push(moduleObject);
        } else {
          console.log(moduleObject);
          Logger.error(
            'LOAD_MODULES',
            `The ${directoryPath} directory is not available.`,
          );
        }
      } catch (err) {
        Logger.warn('LOAD_MODULES', `${filePath} is not a class:\n${err}`);
      }
    });

    // Load the command menu
    this.commandMenu = this.generateCommandMenu();
  }

  private static checkCommandUniqueness(formattedCommands: any[]): void {
    const commandNames = new Set<string>();
    const duplicateCommands: Array<{ name: string; parent?: string }> = [];

    for (const command of formattedCommands) {
      const commandName = command.name;

      // Check for duplicate top-level command names
      if (commandNames.has(commandName)) {
        duplicateCommands.push({ name: commandName });
      } else {
        commandNames.add(commandName);
      }

      // Check for duplicate subcommand names within parent commands
      if (command.options && Array.isArray(command.options)) {
        const subcommandNames = new Set<string>();

        for (const option of command.options) {
          if (option.type === 1) { // Subcommand type
            const subcommandName = option.name;

            if (subcommandNames.has(subcommandName)) {
              duplicateCommands.push({
                name: subcommandName,
                parent: commandName
              });
            } else {
              subcommandNames.add(subcommandName);
            }
          }
        }
      }
    }

    // If duplicates found, log them and exit
    if (duplicateCommands.length > 0) {
      Logger.error('SLASH_COMMANDS', 'Duplicate commands detected:');

      for (const duplicate of duplicateCommands) {
        if (duplicate.parent) {
          Logger.error('SLASH_COMMANDS', `  - Subcommand "${duplicate.name}" in parent command "${duplicate.parent}"`);
        } else {
          Logger.error('SLASH_COMMANDS', `  - Top-level command "${duplicate.name}"`);
        }
      }

      Logger.error('SLASH_COMMANDS', 'Process terminated due to duplicate commands.');
      process.exit(1);
    }
  }

  private static async loadSlashCommands() {
    try {
      // Format the parent slash commands to include child in them
      this.commands = this.commands
        .map((command) => {
          if (command instanceof ChildCommand || command instanceof Command) return command;

          if (command instanceof ParentCommand) {
            const childSlashCommands = command.childCommands.map(
              (x) => x.slashCommand,
            );

            for (const childCommand of childSlashCommands) {
              command.slashCommand.addSubcommand(childCommand);
            }

            return command;
          }

          Logger.warn('SLASH_COMMANDS', `Faulty command type ${command}`);
          return null;
        })
        .filter((x) => !!x);

      const formattedCommands = this.commands
        .map((command) => {
          if (command instanceof ChildCommand) return null;
          if (command instanceof ParentCommand || command instanceof Command) {
            return command.slashCommand;
          }
          return null;
        })
        .filter((x) => !!x);

      // Check for duplicate commands
      this.checkCommandUniqueness(formattedCommands);

      const registeredCommands = await this.privateRest.put(
        Routes.applicationCommands(this.client.user.id),
        { body: formattedCommands },
      ) as CommandInterface[];

      // Update the slash commands on the client
      this.registeredCommands = registeredCommands;

      Logger.info('BOT', `${formattedCommands.length} Slash commands loaded successfully`);
    } catch (err) {
      Logger.error('SLASH_COMMANDS', err);
    }
  }

  private static async shutdown() {
    this.client.destroy();
    process.exit(0);
  }

  private static generateCommandMenu(): CommandCategoryInfo[] {
    const categoryPaths = getCategoryPaths();

    const fetchCommandMenuFromFolder = (folderPath: string) => {
      const folderStats = fs.statSync(folderPath);
      if (!folderStats.isDirectory()) return;

      const files = fs.readdirSync(folderPath);
      const commands: AllCommandTypes[] = [];
      const subCategories: CommandCategoryInfo[] = [];

      const indexFilePath = path.join(folderPath, 'index.js');
      const indexFileStats = fs.statSync(indexFilePath);
      if (!indexFileStats.isFile()) return;

      const indexFileData = require(indexFilePath);
      const indexDefaultFunction = indexFileData.default;
      if (!indexDefaultFunction) return;

      const categoryName = indexDefaultFunction.name as string;
      const categoryDescription = indexDefaultFunction.description as string;

      for (const file of files) {
        const filePath = path.join(folderPath, file);
        const fileStats = fs.statSync(filePath);

        if (fileStats.isDirectory()) {
          // Run it as a sub category
          const subcategory = fetchCommandMenuFromFolder(filePath);
          if (subcategory) subCategories.push(subcategory);
        } else if (
          fileStats.isFile()
          && /^.*\.(js|ts|jsx|tsx)$/i.test(file)
          && path.parse(filePath).name !== 'index'
        ) {
          const fileData = require(filePath);
          if (!fileData.default) continue;
          commands.push(new fileData.default());
        }
      }

      if (!categoryName || !categoryDescription) return;
      else if (commands.length === 0 && subCategories.length === 0) {
        Logger.warn('COMMAND_MENU', `Category ${folderPath} does not have any commands or sub categories.`);
        return;
      }

      return {
        name: categoryName,
        description: categoryDescription,
        commands,
        sub: subCategories
      } as CommandCategoryInfo;
    };

    // Initialize the looking of the command menu
    return categoryPaths.map(fetchCommandMenuFromFolder).filter(x => !!x);
  }
}

App.init();

const getCategoryPaths = () => {
  const commandsFolder = path.join(__dirname, 'commands');
  const folderStats = fs.statSync(commandsFolder);
  if (!folderStats.isDirectory()) return [];

  const files = fs.readdirSync(commandsFolder);
  const paths = [];

  for (const file of files) {
    const filePath = path.join(commandsFolder, file);
    const fileStats = fs.statSync(filePath);

    if (fileStats.isDirectory()) {
      // Run it as a sub category
      paths.push(filePath);
    }
  }

  return paths;
};
