import { Coin } from "@common/database/generated";
import { Decimal } from "@common/database/generated/runtime/library";

export interface DepositJob {
    userId: string;
    txId: string;
    address: string;
    coin: Coin;
    amount: Decimal;
    event: 'unconfirmed-tx' | 'tx-confirmation';
    confirmations: number;
    blockHeight: number | null;
    seenAt: string;
}