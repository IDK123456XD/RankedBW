-- AlterEnum
ALTER TYPE "GameStatus" ADD VALUE 'AUTO_CLOSED';
