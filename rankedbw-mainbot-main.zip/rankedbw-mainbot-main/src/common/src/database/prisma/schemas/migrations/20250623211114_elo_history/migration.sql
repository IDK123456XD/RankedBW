-- CreateEnum
CREATE TYPE "EloHistoryReason" AS ENUM ('GameWin', 'GameLoss', 'ClaimElo', 'ManualAdjustment', 'MVP');

-- CreateTable
CREATE TABLE "EloHistory" (
    "id" TEXT NOT NULL,
    "elo" INTEGER NOT NULL,
    "reason" "EloHistoryReason" NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "EloHistory_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "EloHistory" ADD CONSTRAINT "EloHistory_userId_fkey" FOREIGN KEY ("userId") REFERENCES "Player"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
