-- AlterTable
ALTER TABLE "Settings" ADD COLUMN     "claimEloEnabled" BOOLEAN NOT NULL DEFAULT true;
