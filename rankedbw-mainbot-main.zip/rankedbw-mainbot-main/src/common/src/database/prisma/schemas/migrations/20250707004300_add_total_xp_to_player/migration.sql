/*
  Warnings:

  - You are about to drop the column `totalXp` on the `PlayerStatistics` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Player" ADD COLUMN     "totalXp" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "PlayerStatistics" DROP COLUMN "totalXp";
