/*
  Warnings:

  - You are about to drop the column `team` on the `GamePlayer` table. All the data in the column will be lost.
  - You are about to drop the `Map` table. If the table is not empty, all the data it contains will be lost.

*/
-- AlterTable
ALTER TABLE "GamePlayer" DROP COLUMN "team";

-- DropTable
DROP TABLE "Map";

-- DropEnum
DROP TYPE "TeamColors";
