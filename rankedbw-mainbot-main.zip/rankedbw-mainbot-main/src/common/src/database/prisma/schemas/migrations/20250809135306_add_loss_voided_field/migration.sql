-- AlterTable
ALTER TABLE "Game" ADD COLUMN     "lossVoided" BOOLEAN NOT NULL DEFAULT false;
