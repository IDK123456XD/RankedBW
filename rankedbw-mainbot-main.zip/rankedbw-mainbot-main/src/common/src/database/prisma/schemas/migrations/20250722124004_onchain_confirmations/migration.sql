-- AlterTable
ALTER TABLE "OnChainTx" ADD COLUMN     "confirmations" INTEGER DEFAULT 0;
