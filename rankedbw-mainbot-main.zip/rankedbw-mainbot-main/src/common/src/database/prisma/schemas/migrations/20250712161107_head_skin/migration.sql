-- AlterTable
ALTER TABLE "Player" ADD COLUMN     "headSkin" TEXT;
