BEGIN;
  CREATE TYPE "ScreenshareStatus_new" AS ENUM ('OPEN','CLAIMED','CLOSED','EXPIRED');

  ALTER TABLE "screenshares" ALTER COLUMN "status" DROP DEFAULT;

  -- Convert old → new in‐flight:
  ALTER TABLE "screenshares"
    ALTER COLUMN "status"
    TYPE "ScreenshareStatus_new"
    USING (
      CASE status
        WHEN 'TIMED_OUT' THEN 'EXPIRED'
        ELSE status::text
      END
    )::"ScreenshareStatus_new";

  ALTER TYPE "ScreenshareStatus"     RENAME TO "ScreenshareStatus_old";
  ALTER TYPE "ScreenshareStatus_new" RENAME TO "ScreenshareStatus";
  DROP TYPE "ScreenshareStatus_old";

  ALTER TABLE "screenshares" ALTER COLUMN "status" SET DEFAULT 'OPEN';
COMMIT;