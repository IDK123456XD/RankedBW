-- AlterTable
ALTER TABLE "BlockcypherWallet" ADD COLUMN     "walletAddresses" TEXT[];
