/*
  Warnings:

  - You are about to drop the column `level` on the `Player` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Player" DROP COLUMN "level";
