-- AlterTable
ALTER TABLE "GamePlayer" ADD COLUMN     "eloDiff" INTEGER NOT NULL DEFAULT 0;
