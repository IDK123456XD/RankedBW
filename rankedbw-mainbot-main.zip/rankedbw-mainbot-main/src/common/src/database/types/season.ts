import { Prisma } from "../generated";

export const IncludeCurrentSeasonStatistics =
  Prisma.validator<Prisma.PlayerInclude>()({
    PlayerStatistics: {
      where: {
        season: {
          active: true,
        },
      },
      include: {
        season: true,
      },
      take: 1,
    },
  });

export type PlayerIncludingSeasonStatistics = Prisma.PlayerGetPayload<{
  include: typeof IncludeCurrentSeasonStatistics;
}>;
