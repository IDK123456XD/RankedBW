export interface HypixelPlayerResponse {
    success: boolean
    player: Player
}

export interface Player {
    _id: string
    uuid: string
    firstLogin: number
    playername: string
    lastLogin: number
    displayname: string
    achievementsOneTime: string[]
    lastLogout: number
    stats: Stats
    networkExp: number
    achievements: Achievements
    karma: number
    achievementPoints: number
    achievementTracking: any[]
    challenges: Challenges2
    socialMedia: SocialMedia
    achievementRewardsNew: AchievementRewardsNew
    leveling: Leveling
    vanityMeta: VanityMeta
    petConsumables: PetConsumables
    seasonal: Seasonal
    monthlycrates: Monthlycrates
    newPackageRank: string
    lastAdsenseGenerateTime: number
    lastClaimedReward: number
    rewardHighScore: number
    rewardScore: number
    rewardStreak: number
    totalDailyRewards: number
    totalRewards: number
    quests: Quests
    eugene: Eugene
    parkourCheckpointBests: ParkourCheckpointBests
    parkourCompletions: ParkourCompletions
    channel: string
    housingMeta: HousingMeta
    tourney: Tourney
    adsense_tokens: number
    questSettings: QuestSettings
    monthlyPackageRank: string
    mostRecentMonthlyPackageRank: string
    rankPlusColor: string
    mostRecentGameType: string
}

export interface Stats {
    Arcade: Arcade
    BuildBattle: BuildBattle
    SkyBlock: SkyBlock
    Battleground: Battleground
    Arena: Arena
    GingerBread: GingerBread
    Paintball: Paintball
    Quake: Quake
    VampireZ: VampireZ
    Walls: Walls
    Walls3: Walls3
    MCGO: Mcgo
    SuperSmash: SuperSmash
    SkyWars: SkyWars
    TNTGames: Tntgames
    UHC: Uhc
    HungerGames: HungerGames
    SpeedUHC: SpeedUhc
    Bedwars: Bedwars
    WoolGames: WoolGames
    MurderMystery: MurderMystery
    Duels: Duels
    Pit: Pit
    Housing: Housing
}

export interface Arcade {
    monthly_coins_b: number
    weekly_coins_a: number
    coins: number
    dec2016_achievements2: boolean
    dec2016_achievements: boolean
    dropper: Dropper
    dive_best_score_party: number
    dive_total_score_party: number
    frozen_floor_round_wins_party: number
    lab_escape_best_time_party: number
    lawn_moower_mowed_best_score_party: number
    lawn_moower_mowed_total_score_party: number
    round_wins_party: number
    spider_maze_best_time_party: number
    the_floor_is_lava_best_time_party: number
    total_stars_party: number
    basic_zombie_kills_zombies: number
    best_round_zombies: number
    best_round_zombies_alienarcadium: number
    best_round_zombies_alienarcadium_normal: number
    blob_zombie_kills_zombies: number
    bullets_hit_zombies: number
    bullets_shot_zombies: number
    chgluglu_zombie_kills_zombies: number
    clown_zombie_kills_zombies: number
    deaths_zombies: number
    deaths_zombies_alienarcadium: number
    deaths_zombies_alienarcadium_normal: number
    doors_opened_zombies: number
    doors_opened_zombies_alienarcadium: number
    doors_opened_zombies_alienarcadium_normal: number
    fastest_time_10_zombies: number
    fastest_time_10_zombies_alienarcadium_normal: number
    fastest_time_20_zombies: number
    fastest_time_20_zombies_alienarcadium_normal: number
    ghast_zombie_kills_zombies: number
    giant_zombie_kills_zombies: number
    headshots_zombies: number
    iron_golem_zombie_kills_zombies: number
    mega_magma_zombie_kills_zombies: number
    pig_zombie_zombie_kills_zombies: number
    players_revived_zombies: number
    players_revived_zombies_alienarcadium: number
    players_revived_zombies_alienarcadium_normal: number
    rainbow_zombie_kills_zombies: number
    sentinel_zombie_kills_zombies: number
    skeleton_zombie_kills_zombies: number
    space_blaster_zombie_kills_zombies: number
    space_grunt_zombie_kills_zombies: number
    the_old_one_zombie_kills_zombies: number
    times_knocked_down_zombies: number
    times_knocked_down_zombies_alienarcadium: number
    times_knocked_down_zombies_alienarcadium_normal: number
    total_rounds_survived_zombies: number
    total_rounds_survived_zombies_alienarcadium: number
    total_rounds_survived_zombies_alienarcadium_normal: number
    windows_repaired_zombies: number
    windows_repaired_zombies_alienarcadium: number
    windows_repaired_zombies_alienarcadium_normal: number
    worm_small_zombie_kills_zombies: number
    worm_zombie_kills_zombies: number
    zombie_kills_zombies: number
    zombie_kills_zombies_alienarcadium: number
    zombie_kills_zombies_alienarcadium_normal: number
    mega_blob_zombie_kills_zombies: number
    gifts_grinch_simulator_v2: number
    charged_creeper_zombie_kills_zombies: number
    giant_rainbow_zombie_kills_zombies: number
    lastTourneyAd: number
    gifts_grinch_simulator_v2_tourney_grinch_simulator_1: number
    losses_grinch_simulator_v2_tourney_grinch_simulator_1: number
    wins_grinch_simulator_v2_tourney_grinch_simulator_1: number
}

export interface Dropper {
    fails: number
    games_played: number
    map_stats: MapStats
    maps_completed: number
    fastest_game: number
    games_finished: number
}

export interface MapStats {
    drainage: Drainage
    launchzone: Launchzone
    space: Space
    castle: Castle
    floatingislands: Floatingislands
    kingdommines: Kingdommines
    upsidedown: Upsidedown
    vortex: Vortex
    painted: Painted
    sweets: Sweets
    time: Time
    vintage: Vintage
    bbq: Bbq
    retro: Retro
    atlantis: Atlantis
    maelstrom: Maelstrom
    raindrops: Raindrops
    well: Well
}

export interface Drainage {
    best_time: number
    completions: number
}

export interface Launchzone {
    best_time: number
    completions: number
}

export interface Space {
    best_time: number
    completions: number
}

export interface Castle {
    best_time: number
    completions: number
}

export interface Floatingislands {
    best_time: number
    completions: number
}

export interface Kingdommines {
    best_time: number
    completions: number
}

export interface Upsidedown {
    best_time: number
    completions: number
}

export interface Vortex {
    best_time: number
    completions: number
}

export interface Painted {
    best_time: number
    completions: number
}

export interface Sweets {
    best_time: number
    completions: number
}

export interface Time {
    best_time: number
    completions: number
}

export interface Vintage {
    best_time: number
    completions: number
}

export interface Bbq {
    best_time: number
    completions: number
}

export interface Retro {
    best_time: number
    completions: number
}

export interface Atlantis {
    best_time: number
    completions: number
}

export interface Maelstrom {
    best_time: number
    completions: number
}

export interface Raindrops {
    best_time: number
    completions: number
}

export interface Well {
    best_time: number
    completions: number
}

export interface BuildBattle {
    wins_solo_normal: number
    wins: number
    coins: number
    correct_guesses: number
    games_played: number
    monthly_coins_b: number
    score: number
    weekly_coins_b: number
}

export interface SkyBlock {
    profiles: Profiles
}

export interface Profiles {
    '84e3e0251d284915bc76763b717ccaa2': N84e3e0251d284915bc76763b717ccaa2
}

export interface N84e3e0251d284915bc76763b717ccaa2 {
    profile_id: string
    cute_name: string
}

export interface Battleground {
    coins: number
}

export interface Arena {
    coins: number
}

export interface GingerBread {
    coins: number
}

export interface Paintball {
    coins: number
}

export interface Quake {
    coins: number
}

export interface VampireZ {
    coins: number
}

export interface Walls {
    coins: number
}

export interface Walls3 {
    coins: number
}

export interface Mcgo {
    coins: number
}

export interface SuperSmash {
    coins: number
}

export interface SkyWars {
    coins: number
    souls: number
    levelFormatted: string
    packages: string[]
    cosmetic_tokens: number
    lucky_explained_last: number
    lucky_explained: number
    perkslot: Perkslot
    toggle_mega_arrow_recovery: boolean
    toggle_mega_blazing_arrows: boolean
    toggle_mega_mining_expertise: boolean
    toggle_mega_rusher: boolean
    toggle_mega_tank: boolean
    toggle_mega_notoriety: boolean
    toggle_mega_nourishment: boolean
    toggle_mega_marksmanship: boolean
    toggle_mega_bridger: boolean
    toggle_mega_environmental_expert: boolean
    toggle_mega_lucky_charm: boolean
    toggle_mega_necromancer: boolean
    toggle_mega_black_magic: boolean
    toggle_ranked_armorer_perk: boolean
    toggle_ranked_bowman_perk: boolean
    toggle_ranked_champion_perk: boolean
    toggle_ranked_magician_perk: boolean
    toggle_ranked_scout_perk: boolean
    toggle_ranked_athlete_perk: boolean
    toggle_ranked_blacksmith_perk: boolean
    toggle_ranked_healer_perk: boolean
    toggle_ranked_pyromancer_perk: boolean
    toggle_ranked_hound_perk: boolean
    toggle_ranked_paladin_perk: boolean
    toggle_ranked_arrow_recovery: boolean
    toggle_ranked_blazing_arrows: boolean
    toggle_ranked_last_stand: boolean
    toggle_ranked_mining_expertise: boolean
    toggle_ranked_rusher: boolean
    toggle_ranked_tough_skin: boolean
    toggle_ranked_bridger: boolean
    toggle_ranked_environmental_expert: boolean
    toggle_solo_arrow_recovery: boolean
    toggle_solo_blazing_arrows: boolean
    toggle_solo_marksmanship: boolean
    toggle_solo_mining_expertise: boolean
    solo_resistance_boost: number
    toggle_solo_resistance_boost: boolean
    toggle_solo_speed_boost: boolean
    toggle_solo_knowledge: boolean
    'toggle_solo_annoy-o-mite': boolean
    solo_savior: number
    toggle_solo_savior: boolean
    toggle_solo_nourishment: boolean
    toggle_solo_revenge: boolean
    solo_fat: number
    toggle_solo_fat: boolean
    toggle_solo_bridger: boolean
    toggle_solo_environmental_expert: boolean
    toggle_solo_lucky_charm: boolean
    toggle_solo_necromancer: boolean
    toggle_solo_black_magic: boolean
    toggle_solo_robbery: boolean
    toggle_solo_frost: boolean
    toggle_solo_barbarian: boolean
    toggle_team_arrow_recovery: boolean
    toggle_team_blazing_arrows: boolean
    toggle_team_mining_expertise: boolean
    team_resistance_boost: number
    toggle_team_resistance_boost: boolean
    toggle_team_speed_boost: boolean
    toggle_team_knowledge: boolean
    'toggle_team_annoy-o-mite': boolean
    team_savior: number
    toggle_team_savior: boolean
    toggle_team_nourishment: boolean
    toggle_team_marksmanship: boolean
    team_fat: number
    toggle_team_fat: boolean
    toggle_team_bridger: boolean
    toggle_team_environmental_expert: boolean
    toggle_team_lucky_charm: boolean
    toggle_team_necromancer: boolean
    toggle_team_black_magic: boolean
    toggle_team_robbery: boolean
    toggle_team_frost: boolean
    toggle_team_diamondpiercer: boolean
    toggle_team_barbarian: boolean
    games_played_skywars: number
    skywars_experience: number
    arrows_hit_lab: number
    arrows_hit_lab_kit_mining_team_default: number
    arrows_hit_lab_solo: number
    arrows_shot_lab: number
    arrows_shot_lab_kit_mining_team_default: number
    arrows_shot_lab_solo: number
    blocks_broken_lab: number
    blocks_placed_lab: number
    bow_kills_lab: number
    bow_kills_lab_kit_mining_team_default: number
    bow_kills_lab_solo: number
    chests_opened_lab: number
    chests_opened_lab_kit_mining_team_default: number
    chests_opened_lab_solo: number
    coins_gained_lab: number
    deaths_lab: number
    deaths_lab_kit_mining_team_default: number
    deaths_lab_solo: number
    egg_thrown_lab: number
    kills_lab: number
    kills_lab_kit_mining_team_default: number
    kills_lab_solo: number
    kills_monthly_b: number
    kills_weekly_b: number
    lastMode: string
    longest_bow_kill_lab: number
    longest_bow_kill_lab_kit_mining_team_default: number
    longest_bow_kill_lab_solo: number
    longest_bow_shot_lab: number
    longest_bow_shot_lab_kit_mining_team_default: number
    longest_bow_shot_lab_solo: number
    losses_lab: number
    losses_lab_kit_mining_team_default: number
    losses_lab_solo: number
    most_kills_game_lab: number
    most_kills_game_lab_kit_mining_team_default: number
    most_kills_game_lab_solo: number
    quits_lab: number
    souls_gathered_lab: number
    survived_players_lab: number
    survived_players_lab_kit_mining_team_default: number
    survived_players_lab_solo: number
    time_played_lab: number
    time_played_lab_kit_mining_team_default: number
    time_played_lab_solo: number
    win_streak_lab: number
    mobs_killed_lab: number
    mobs_killed_lab_kit_mining_team_default: number
    mobs_killed_lab_solo: number
    void_kills_lab: number
    void_kills_lab_kit_mining_team_default: number
    void_kills_lab_solo: number
    skywars_christmas_boxes: number
}

export interface Perkslot {
    normal: Normal
    insane: Insane
}

export interface Normal {
    '2': string
    '1': string
    '3': string
}

export interface Insane {
    '1': string
    '3': string
    '2': string
}

export interface Tntgames {
    coins: number
    lastTourneyAd: number
}

export interface Uhc {
    coins: number
}

export interface HungerGames {
    coins: number
}

export interface SpeedUhc {
    coins: number
}

export interface Bedwars {
    packages: string[]
    bedwars_boxes: number
    first_join_7: boolean
    Experience: number
    games_played_bedwars_1: number
    four_three_winstreak: number
    winstreak: number
    _items_purchased_bedwars: number
    beds_broken_bedwars: number
    coins: number
    emerald_resources_collected_bedwars: number
    entity_attack_final_kills_bedwars: number
    entity_attack_kills_bedwars: number
    final_kills_bedwars: number
    four_three__items_purchased_bedwars: number
    four_three_beds_broken_bedwars: number
    four_three_emerald_resources_collected_bedwars: number
    four_three_entity_attack_final_kills_bedwars: number
    four_three_entity_attack_kills_bedwars: number
    four_three_final_kills_bedwars: number
    four_three_games_played_bedwars: number
    four_three_gold_resources_collected_bedwars: number
    four_three_iron_resources_collected_bedwars: number
    four_three_items_purchased_bedwars: number
    four_three_kills_bedwars: number
    four_three_permanent_items_purchased_bedwars: number
    four_three_resources_collected_bedwars: number
    four_three_wins_bedwars: number
    games_played_bedwars: number
    gold_resources_collected_bedwars: number
    iron_resources_collected_bedwars: number
    items_purchased_bedwars: number
    kills_bedwars: number
    permanent_items_purchased_bedwars: number
    resources_collected_bedwars: number
    wins_bedwars: number
    deaths_bedwars: number
    entity_attack_deaths_bedwars: number
    four_three_deaths_bedwars: number
    four_three_entity_attack_deaths_bedwars: number
    four_three_void_final_kills_bedwars: number
    four_three_void_kills_bedwars: number
    void_final_kills_bedwars: number
    void_kills_bedwars: number
    four_three_void_deaths_bedwars: number
    void_deaths_bedwars: number
    beds_lost_bedwars: number
    entity_attack_final_deaths_bedwars: number
    fall_deaths_bedwars: number
    final_deaths_bedwars: number
    four_three_beds_lost_bedwars: number
    four_three_entity_attack_final_deaths_bedwars: number
    four_three_fall_deaths_bedwars: number
    four_three_final_deaths_bedwars: number
    four_three_losses_bedwars: number
    losses_bedwars: number
    eight_two_winstreak: number
    eight_two__items_purchased_bedwars: number
    eight_two_beds_broken_bedwars: number
    eight_two_beds_lost_bedwars: number
    eight_two_deaths_bedwars: number
    eight_two_emerald_resources_collected_bedwars: number
    eight_two_entity_attack_deaths_bedwars: number
    eight_two_entity_attack_kills_bedwars: number
    eight_two_final_deaths_bedwars: number
    eight_two_final_kills_bedwars: number
    eight_two_fire_tick_kills_bedwars: number
    eight_two_games_played_bedwars: number
    eight_two_gold_resources_collected_bedwars: number
    eight_two_iron_resources_collected_bedwars: number
    eight_two_items_purchased_bedwars: number
    eight_two_kills_bedwars: number
    eight_two_losses_bedwars: number
    eight_two_magic_kills_bedwars: number
    eight_two_permanent_items_purchased_bedwars: number
    eight_two_resources_collected_bedwars: number
    eight_two_void_deaths_bedwars: number
    eight_two_void_final_deaths_bedwars: number
    eight_two_void_final_kills_bedwars: number
    eight_two_void_kills_bedwars: number
    fire_tick_kills_bedwars: number
    magic_kills_bedwars: number
    void_final_deaths_bedwars: number
    eight_two_entity_attack_final_kills_bedwars: number
    eight_two_magic_deaths_bedwars: number
    magic_deaths_bedwars: number
    diamond_resources_collected_bedwars: number
    eight_two_diamond_resources_collected_bedwars: number
    eight_two_entity_attack_final_deaths_bedwars: number
    eight_two_fall_deaths_bedwars: number
    eight_two_fall_kills_bedwars: number
    fall_kills_bedwars: number
    favorite_slots: string
    four_four_winstreak: number
    fall_final_deaths_bedwars: number
    four_four__items_purchased_bedwars: number
    four_four_beds_lost_bedwars: number
    four_four_entity_attack_kills_bedwars: number
    four_four_fall_final_deaths_bedwars: number
    four_four_final_deaths_bedwars: number
    four_four_games_played_bedwars: number
    four_four_gold_resources_collected_bedwars: number
    four_four_iron_resources_collected_bedwars: number
    four_four_items_purchased_bedwars: number
    four_four_kills_bedwars: number
    four_four_losses_bedwars: number
    four_four_resources_collected_bedwars: number
    four_four_diamond_resources_collected_bedwars: number
    four_four_entity_attack_final_kills_bedwars: number
    four_four_final_kills_bedwars: number
    four_four_permanent_items_purchased_bedwars: number
    four_four_void_final_deaths_bedwars: number
    four_four_void_kills_bedwars: number
    four_four_beds_broken_bedwars: number
    four_four_deaths_bedwars: number
    four_four_entity_attack_deaths_bedwars: number
    four_four_entity_attack_final_deaths_bedwars: number
    four_four_fall_kills_bedwars: number
    four_four_void_deaths_bedwars: number
    four_four_emerald_resources_collected_bedwars: number
    four_four_wins_bedwars: number
    eight_two_wins_bedwars: number
    bedwars_halloween_boxes: number
    eight_two_magic_final_deaths_bedwars: number
    magic_final_deaths_bedwars: number
    eight_one_winstreak: number
    eight_one__items_purchased_bedwars: number
    eight_one_beds_broken_bedwars: number
    eight_one_beds_lost_bedwars: number
    eight_one_deaths_bedwars: number
    eight_one_diamond_resources_collected_bedwars: number
    eight_one_entity_attack_deaths_bedwars: number
    eight_one_entity_attack_final_deaths_bedwars: number
    eight_one_entity_attack_final_kills_bedwars: number
    eight_one_entity_attack_kills_bedwars: number
    eight_one_final_deaths_bedwars: number
    eight_one_final_kills_bedwars: number
    eight_one_games_played_bedwars: number
    eight_one_gold_resources_collected_bedwars: number
    eight_one_iron_resources_collected_bedwars: number
    eight_one_items_purchased_bedwars: number
    eight_one_kills_bedwars: number
    eight_one_losses_bedwars: number
    eight_one_permanent_items_purchased_bedwars: number
    eight_one_resources_collected_bedwars: number
    eight_one_void_deaths_bedwars: number
    eight_one_void_final_kills_bedwars: number
    eight_one_void_kills_bedwars: number
    free_event_key_bedwars_halloween_boxes_2023: boolean
    Bedwars_openedChests: number
    Bedwars_openedCommons: number
    Bedwars_openedRares: number
    chest_history_new: string[]
    activeDeathCry: string
    activeKillEffect: string
    activeNPCSkin: string
    selected_challenge_type: string
    favourites_2: string
    eight_one_wins_bedwars: number
    four_four_projectile_kills_bedwars: number
    projectile_kills_bedwars: number
    fall_final_kills_bedwars: number
    four_four_fall_final_kills_bedwars: number
    four_four_fall_deaths_bedwars: number
    entity_explosion_kills_bedwars: number
    four_four_entity_explosion_kills_bedwars: number
    four_four_magic_final_deaths_bedwars: number
    entity_explosion_final_deaths_bedwars: number
    four_four_entity_explosion_final_deaths_bedwars: number
    eight_one_emerald_resources_collected_bedwars: number
    eight_one_entity_explosion_final_deaths_bedwars: number
    eight_one_fire_tick_final_kills_bedwars: number
    fire_tick_final_kills_bedwars: number
    eight_one_fall_kills_bedwars: number
    eight_one_void_final_deaths_bedwars: number
    eight_two_entity_explosion_final_kills_bedwars: number
    entity_explosion_final_kills_bedwars: number
    four_three_diamond_resources_collected_bedwars: number
    practice: Practice
    activeBedDestroy: string
    four_three_void_final_deaths_bedwars: number
    four_four_projectile_deaths_bedwars: number
    projectile_deaths_bedwars: number
    four_four_void_final_kills_bedwars: number
    bw_challenge_no_team_upgrades: number
    total_challenges_completed: number
    challenges: Challenges
    bw_unique_challenges_completed: number
    bw_challenge_no_utilities: number
    bw_challenge_selfish: number
    bw_challenge_slow_generator: number
    bw_challenge_assassin: number
    bw_challenge_reset_armor: number
    bw_challenge_invisible_shop: number
    four_four_magic_deaths_bedwars: number
    four_four_magic_final_kills_bedwars: number
    magic_final_kills_bedwars: number
    bw_challenge_collector: number
    bw_challenge_woodworker: number
    bw_challenge_sponge: number
    bw_challenge_toxic_rain: number
    bw_challenge_defuser: number
    bw_challenge_mining_fatigue: number
    bw_challenge_no_healing: number
    bw_challenge_hotbar: number
    bw_challenge_weighted_items: number
    bw_challenge_knockback_stick_only: number
    bw_challenge_no_swords: number
    bw_challenge_archer_only: number
    four_four_projectile_final_kills_bedwars: number
    projectile_final_kills_bedwars: number
    activeIslandTopper: string
    activeProjectileTrail: string
    activeSprays: string
    activeVictoryDance: string
    Bedwars_openedEpics: number
    eight_one_magic_deaths_bedwars: number
    eight_two_magic_final_kills_bedwars: number
    four_three_fall_final_kills_bedwars: number
    four_three_magic_deaths_bedwars: number
    four_three_magic_final_kills_bedwars: number
    bw_challenge_patriot: number
    bw_challenge_stamina: number
    four_three_fall_kills_bedwars: number
    four_three_magic_final_deaths_bedwars: number
    bw_challenge_no_sprint: number
    bw_challenge_capped_resources: number
    four_four_magic_kills_bedwars: number
    four_four_fire_tick_kills_bedwars: number
    bw_challenge_stop_light: number
    eight_one_magic_final_kills_bedwars: number
    bw_challenge_delayed_hitting: number
    four_three_projectile_final_kills_bedwars: number
    bw_challenge_master_assassin: number
    bw_challenge_no_shift: number
    four_three_entity_explosion_kills_bedwars: number
    bw_challenge_no_hitting: number
    bw_challenge_protect_the_president: number
    four_four_entity_explosion_final_kills_bedwars: number
    fire_tick_final_deaths_bedwars: number
    four_four_fire_tick_final_deaths_bedwars: number
    four_three_projectile_kills_bedwars: number
    bw_challenge_cant_touch_this: number
    eight_one_magic_final_deaths_bedwars: number
    eight_two_fire_tick_final_deaths_bedwars: number
    eight_two_entity_explosion_kills_bedwars: number
    eight_two_fall_final_kills_bedwars: number
    eight_two_projectile_deaths_bedwars: number
    eight_two_entity_explosion_deaths_bedwars: number
    entity_explosion_deaths_bedwars: number
    activeGlyph: string
    eight_two_fall_final_deaths_bedwars: number
    eight_two_fire_tick_final_kills_bedwars: number
    eight_one_magic_kills_bedwars: number
    eight_two_fire_tick_deaths_bedwars: number
    fire_tick_deaths_bedwars: number
    eight_two_entity_explosion_final_deaths_bedwars: number
    bedwars_christmas_boxes: number
    Bedwars_openedLegendaries: number
    activeKillMessages: string
    free_event_key_bedwars_christmas_boxes_2023: boolean
    slumber: Slumber
    eight_two_lucky_winstreak: number
    eight_two_lucky__items_purchased_bedwars: number
    eight_two_lucky_beds_broken_bedwars: number
    eight_two_lucky_beds_lost_bedwars: number
    eight_two_lucky_deaths_bedwars: number
    eight_two_lucky_entity_attack_deaths_bedwars: number
    eight_two_lucky_entity_attack_final_kills_bedwars: number
    eight_two_lucky_entity_attack_kills_bedwars: number
    eight_two_lucky_final_deaths_bedwars: number
    eight_two_lucky_final_kills_bedwars: number
    eight_two_lucky_games_played_bedwars: number
    eight_two_lucky_gold_resources_collected_bedwars: number
    eight_two_lucky_iron_resources_collected_bedwars: number
    eight_two_lucky_items_purchased_bedwars: number
    eight_two_lucky_kills_bedwars: number
    eight_two_lucky_losses_bedwars: number
    eight_two_lucky_magic_final_deaths_bedwars: number
    eight_two_lucky_magic_kills_bedwars: number
    eight_two_lucky_permanent_items_purchased_bedwars: number
    eight_two_lucky_resources_collected_bedwars: number
    eight_two_lucky_void_deaths_bedwars: number
    eight_two_lucky_void_kills_bedwars: number
    eight_one_fall_deaths_bedwars: number
    eight_two_swap_winstreak: number
    eight_two_swap__items_purchased_bedwars: number
    eight_two_swap_beds_broken_bedwars: number
    eight_two_swap_beds_lost_bedwars: number
    eight_two_swap_deaths_bedwars: number
    eight_two_swap_diamond_resources_collected_bedwars: number
    eight_two_swap_emerald_resources_collected_bedwars: number
    eight_two_swap_entity_attack_deaths_bedwars: number
    eight_two_swap_entity_attack_final_kills_bedwars: number
    eight_two_swap_entity_attack_kills_bedwars: number
    eight_two_swap_fall_deaths_bedwars: number
    eight_two_swap_final_deaths_bedwars: number
    eight_two_swap_final_kills_bedwars: number
    eight_two_swap_games_played_bedwars: number
    eight_two_swap_gold_resources_collected_bedwars: number
    eight_two_swap_iron_resources_collected_bedwars: number
    eight_two_swap_items_purchased_bedwars: number
    eight_two_swap_kills_bedwars: number
    eight_two_swap_losses_bedwars: number
    eight_two_swap_permanent_items_purchased_bedwars: number
    eight_two_swap_resources_collected_bedwars: number
    eight_two_swap_void_deaths_bedwars: number
    eight_two_swap_void_final_deaths_bedwars: number
    eight_two_swap_void_final_kills_bedwars: number
    eight_two_swap_void_kills_bedwars: number
    four_four_swap__items_purchased_bedwars: number
    four_four_swap_beds_lost_bedwars: number
    four_four_swap_deaths_bedwars: number
    four_four_swap_emerald_resources_collected_bedwars: number
    four_four_swap_entity_attack_deaths_bedwars: number
    four_four_swap_final_deaths_bedwars: number
    four_four_swap_final_kills_bedwars: number
    four_four_swap_games_played_bedwars: number
    four_four_swap_gold_resources_collected_bedwars: number
    four_four_swap_iron_resources_collected_bedwars: number
    four_four_swap_items_purchased_bedwars: number
    four_four_swap_kills_bedwars: number
    four_four_swap_permanent_items_purchased_bedwars: number
    four_four_swap_resources_collected_bedwars: number
    four_four_swap_void_final_deaths_bedwars: number
    four_four_swap_void_final_kills_bedwars: number
    four_four_swap_void_kills_bedwars: number
    four_four_swap_wins_bedwars: number
    four_four_swap_winstreak: number
    eight_two_rush_winstreak: number
    eight_two_rush__items_purchased_bedwars: number
    eight_two_rush_beds_lost_bedwars: number
    eight_two_rush_deaths_bedwars: number
    eight_two_rush_emerald_resources_collected_bedwars: number
    eight_two_rush_entity_attack_deaths_bedwars: number
    eight_two_rush_entity_attack_kills_bedwars: number
    eight_two_rush_final_deaths_bedwars: number
    eight_two_rush_games_played_bedwars: number
    eight_two_rush_gold_resources_collected_bedwars: number
    eight_two_rush_iron_resources_collected_bedwars: number
    eight_two_rush_items_purchased_bedwars: number
    eight_two_rush_kills_bedwars: number
    eight_two_rush_losses_bedwars: number
    eight_two_rush_magic_final_deaths_bedwars: number
    eight_two_rush_resources_collected_bedwars: number
    eight_two_rush_void_deaths_bedwars: number
    eight_two_rush_void_kills_bedwars: number
    eight_two_rush_beds_broken_bedwars: number
    eight_two_rush_diamond_resources_collected_bedwars: number
    eight_two_rush_entity_attack_final_kills_bedwars: number
    eight_two_rush_final_kills_bedwars: number
    eight_two_rush_permanent_items_purchased_bedwars: number
    eight_two_rush_void_final_deaths_bedwars: number
    eight_two_rush_fall_final_deaths_bedwars: number
    eight_two_rush_entity_attack_final_deaths_bedwars: number
    two_four_winstreak: number
    two_four_deaths_bedwars: number
    two_four_final_deaths_bedwars: number
    two_four_games_played_bedwars: number
    two_four_gold_resources_collected_bedwars: number
    two_four_iron_resources_collected_bedwars: number
    two_four_losses_bedwars: number
    two_four_magic_deaths_bedwars: number
    two_four_resources_collected_bedwars: number
    selected_ultimate: string
    eight_two_ultimate_winstreak: number
    eight_two_ultimate__items_purchased_bedwars: number
    eight_two_ultimate_beds_broken_bedwars: number
    eight_two_ultimate_beds_lost_bedwars: number
    eight_two_ultimate_deaths_bedwars: number
    eight_two_ultimate_diamond_resources_collected_bedwars: number
    eight_two_ultimate_emerald_resources_collected_bedwars: number
    eight_two_ultimate_entity_attack_final_kills_bedwars: number
    eight_two_ultimate_entity_attack_kills_bedwars: number
    eight_two_ultimate_final_deaths_bedwars: number
    eight_two_ultimate_final_kills_bedwars: number
    eight_two_ultimate_games_played_bedwars: number
    eight_two_ultimate_gold_resources_collected_bedwars: number
    eight_two_ultimate_iron_resources_collected_bedwars: number
    eight_two_ultimate_items_purchased_bedwars: number
    eight_two_ultimate_kills_bedwars: number
    eight_two_ultimate_permanent_items_purchased_bedwars: number
    eight_two_ultimate_resources_collected_bedwars: number
    eight_two_ultimate_void_deaths_bedwars: number
    eight_two_ultimate_void_final_deaths_bedwars: number
    eight_two_ultimate_void_final_kills_bedwars: number
    eight_two_ultimate_void_kills_bedwars: number
    eight_two_ultimate_wins_bedwars: number
    castle__items_purchased_bedwars: number
    castle_beds_lost_bedwars: number
    castle_entity_attack_final_deaths_bedwars: number
    castle_final_deaths_bedwars: number
    castle_games_played_bedwars: number
    castle_gold_resources_collected_bedwars: number
    castle_iron_resources_collected_bedwars: number
    castle_items_purchased_bedwars: number
    castle_losses_bedwars: number
    castle_permanent_items_purchased_bedwars: number
    castle_resources_collected_bedwars: number
    castle_winstreak: number
    eight_one_fall_final_kills_bedwars: number
    eight_one_fall_final_deaths_bedwars: number
}

export interface Practice {
    selected: string
    records: Records
    bridging: Bridging
    mlg: Mlg
    fireball_jumping: FireballJumping
    pearl_clutching: PearlClutching
}

export interface Records {
    'bridging_distance_30:elevation_NONE:angle_STRAIGHT:': number
}

export interface Bridging {
    failed_attempts: number
    blocks_placed: number
    successful_attempts: number
}

export interface Mlg {
    successful_attempts: number
}

export interface FireballJumping {
    failed_attempts: number
    successful_attempts: number
}

export interface PearlClutching {
    successful_attempts: number
    failed_attempts: number
}

export interface Challenges {
    bw_challenge_no_team_upgrades_best_time: number
    bw_challenge_no_utilities_best_time: number
    bw_challenge_selfish_best_time: number
    bw_challenge_slow_generator_best_time: number
    bw_challenge_assassin_best_time: number
    bw_challenge_reset_armor_best_time: number
    bw_challenge_invisible_shop_best_time: number
    bw_challenge_collector_best_time: number
    bw_challenge_woodworker_best_time: number
    bw_challenge_sponge_best_time: number
    bw_challenge_toxic_rain_best_time: number
    bw_challenge_defuser_best_time: number
    bw_challenge_mining_fatigue_best_time: number
    bw_challenge_no_healing_best_time: number
    bw_challenge_hotbar_best_time: number
    bw_challenge_weighted_items_best_time: number
    bw_challenge_knockback_stick_only_best_time: number
    bw_challenge_no_swords_best_time: number
    bw_challenge_archer_only_best_time: number
    bw_challenge_patriot_best_time: number
    bw_challenge_stamina_best_time: number
    bw_challenge_no_sprint_best_time: number
    bw_challenge_capped_resources_best_time: number
    bw_challenge_stop_light_best_time: number
    bw_challenge_delayed_hitting_best_time: number
    bw_challenge_master_assassin_best_time: number
    bw_challenge_no_shift_best_time: number
    bw_challenge_no_hitting_best_time: number
    bw_challenge_protect_the_president_best_time: number
    bw_challenge_cant_touch_this_best_time: number
}

export interface Slumber {
    fredgie: Fredgie
    quest: Quest
    bag_type: string
    tickets: number
    tickets_given_doorman: number
    tickets_requirement_met: boolean
    total_tickets_earned: number
    phase: Phase
    room: Room
    boon_multiplier: number
    phasethree: Phasethree
    minion: Minion
    wallet_full_warning: boolean
    sandman: Sandman
}

export interface Fredgie {
    should_update_index: boolean
    dialogue_index: number
}

export interface Quest {
    gambler_george: GamblerGeorge
    npc: Npc
    started: Started
    lastStarted: LastStarted
    lastCompleted: LastCompleted
    objective: Objective
    completed: Completed
    item: Item
}

export interface GamblerGeorge {
    gamble_games_won: number
    won_last_game: boolean
    should_reward: boolean
}

export interface Npc {
    talk: Talk
}

export interface Talk {
    DoorManNpc: boolean
    HotelReceptionistNpc: boolean
    HostessKatrinaNpc: boolean
    FredericFerntonNpc: boolean
    LadySaichiNpc: boolean
    TicketMachineNpc: boolean
    GeneralDakuNpc: boolean
    JohnIndigosNpc: boolean
    LaundryGuyNpc: boolean
    JohnIndigosPhaseTwoNpc: boolean
    BlackSmithNpc: boolean
    KingFlutNpc: boolean
    HammerNpc: boolean
    OasisSpiritNpc: boolean
    BlackSmithRobertoNpc: boolean
    ArcadePlayerNpc: boolean
    SpaceManNpc: boolean
    JetsMcTurboNpc: boolean
    RatmanNpc: boolean
    QuizShowHostNpc: boolean
    HermesNpc: boolean
    SkyBlockPlayerNpc: boolean
    DonEspressoNpc: boolean
    JimmyNpc: boolean
    BimmyNpc: boolean
    GamblerGeorgeNpc: boolean
    ChefBuckyNpc: boolean
    ChefGarryJamseyNpc: boolean
    HammerPartTwoNpc: boolean
    CEONpc: boolean
    BillStarrNpc: boolean
    WallyNpc: boolean
    PeterNpc: boolean
    InspectorMyaSterlingNpc: boolean
    LaundryGalNpc: boolean
    JeremyJaggerNpc: boolean
    MasterMeyerNpc: boolean
    CombatArtistSallyNpc: boolean
    GizzyMoonpowderNpc: boolean
    LesterBrodyNpc: boolean
    ElectricianRusselNpc: boolean
    SlumberVillagerNpc: boolean
    JohnIndigosPhaseThreeNpc: boolean
    SandmanNpc: boolean
}

export interface Started {
    npc_reception_start: boolean
    npc_lady_saichi: boolean
    npc_general_daku: boolean
    npc_john_pireso: boolean
    phase_two_asc: boolean
    npc_laundry: boolean
    phase_three_asc: boolean
    npc_blacksmith: boolean
    npc_king_flut: boolean
    npc_hammer: boolean
    npc_oasis: boolean
    npc_blacksmith_apprentice: boolean
    npc_arcade_player: boolean
    npc_spaceman: boolean
    npc_jets_mcturbo: boolean
    npc_the_ratman: boolean
    npc_quiz_show_host: boolean
    npc_hermes: boolean
    npc_skyblock_player: boolean
    npc_don_espresso: boolean
    npc_jimmy_bimmy: boolean
    npc_gambler_george: boolean
    npc_bucky: boolean
    npc_hammer_part_two: boolean
    npc_executives: boolean
    npc_bill_starr: boolean
    npc_wally: boolean
    npc_peter: boolean
    npc_inspector: boolean
    npc_laundry_gal: boolean
    npc_jeremy_jagger: boolean
    npc_master_meyer: boolean
    staff_wallet_upgrade: boolean
    npc_combat_artist_sally: boolean
    npc_gizzy_moonpowder: boolean
    npc_lester_brody: boolean
    npc_electrician_russel: boolean
    phase_four_ascension_q1: boolean
    phase_four_ascension_q2: boolean
    phase_four_ascension_q3: boolean
    phase_four_ascension_q4: boolean
    phase_four_ascension_q5: boolean
    phase_four_ascension_wallet_q: boolean
    npc_meet_the_sandman: boolean
}

export interface LastStarted {
    npc_reception_start: number
    npc_lady_saichi: number
    npc_general_daku: number
    npc_john_pireso: number
    phase_two_asc: number
    npc_laundry: number
    phase_three_asc: number
    npc_blacksmith: number
    npc_king_flut: number
    npc_hammer: number
    npc_oasis: number
    npc_blacksmith_apprentice: number
    npc_arcade_player: number
    npc_spaceman: number
    npc_jets_mcturbo: number
    npc_the_ratman: number
    npc_quiz_show_host: number
    npc_hermes: number
    npc_skyblock_player: number
    npc_don_espresso: number
    npc_jimmy_bimmy: number
    npc_gambler_george: number
    npc_bucky: number
    npc_hammer_part_two: number
    npc_executives: number
    npc_bill_starr: number
    npc_wally: number
    npc_peter: number
    npc_inspector: number
    npc_laundry_gal: number
    npc_jeremy_jagger: number
    npc_master_meyer: number
    staff_wallet_upgrade: number
    npc_combat_artist_sally: number
    npc_gizzy_moonpowder: number
    npc_lester_brody: number
    npc_electrician_russel: number
    phase_four_ascension_q1: number
    phase_four_ascension_q2: number
    phase_four_ascension_q3: number
    phase_four_ascension_q4: number
    phase_four_ascension_q5: number
    phase_four_ascension_wallet_q: number
    npc_meet_the_sandman: number
}

export interface LastCompleted {
    npc_reception_start: number
    npc_john_pireso: number
    npc_general_daku: number
    npc_lady_saichi: number
    phase_two_asc: number
    npc_blacksmith_apprentice: number
    npc_laundry: number
    npc_hammer: number
    npc_king_flut: number
    npc_oasis: number
    npc_blacksmith: number
    phase_three_asc: number
    npc_arcade_player: number
    npc_quiz_show_host: number
    npc_the_ratman: number
    npc_don_espresso: number
    npc_jets_mcturbo: number
    npc_jimmy_bimmy: number
    npc_skyblock_player: number
    npc_bucky: number
    npc_hammer_part_two: number
    npc_gambler_george: number
    npc_hermes: number
    npc_bill_starr: number
    npc_spaceman: number
    npc_executives: number
    npc_wally: number
    npc_peter: number
    npc_laundry_gal: number
    npc_inspector: number
    npc_master_meyer: number
    staff_wallet_upgrade: number
    npc_jeremy_jagger: number
    npc_lester_brody: number
    npc_electrician_russel: number
    phase_four_ascension_q1: number
    phase_four_ascension_q2: number
    phase_four_ascension_q3: number
    phase_four_ascension_q4: number
    phase_four_ascension_q5: number
    phase_four_ascension_wallet_q: number
    npc_combat_artist_sally: number
    npc_gizzy_moonpowder: number
    npc_john_indigos_hammer: number
    npc_meet_the_sandman: number
}

export interface Objective {
    receptionist_introduction: boolean
    john_pireso_map: boolean
    general_daku_tea: boolean
    lady_saichi_mattress: boolean
    phase_two_recp: boolean
    blacksmith_apprentice_iron: boolean
    blacksmith_apprentice_coins: boolean
    blacksmith_apprentice_iron_repeat: boolean
    laundry_manager_sheets: boolean
    blacksmith_iron_bars: boolean
    blacksmith_golden_ticket: boolean
    blacksmith_apprentice_coins_repeat: boolean
    hammer_coins: boolean
    blacksmith_mold: boolean
    king_flut_pillow: boolean
    laundry_manager_sheets_repeat: boolean
    king_flut_amulet: boolean
    blacksmith_amulet: boolean
    oasis_souls: boolean
    blacksmith_water: boolean
    phase_three_recp: boolean
    arcade_quarters: boolean
    arcade_quarters_repeat: boolean
    ratman_pillow: boolean
    ratman_bedsheets: boolean
    ratman_iron_bars: boolean
    ratman_spark_plug: boolean
    chess_tickets: boolean
    don_espresso_gold: boolean
    jets_iron_bars: boolean
    jets_emeralds: boolean
    jets_cables: boolean
    jets_nether_stars: boolean
    chess_wool_cables: boolean
    chess_tokens_of_ferocity: boolean
    skyblock_player_leaves: boolean
    bucky_sky_tea_leaves: boolean
    bucky_fragments: boolean
    hammer_part_two_silver_blade: boolean
    gambler_george_win: boolean
    hermes_mystery_boxes: boolean
    bill_starr_blitz: boolean
    spaceman_nether_stars: boolean
    executives_meeting_numbers: boolean
    wally_nether_stars: boolean
    wally_bed_sheets: boolean
    peter_escape: boolean
    inspector_clue_weapon: boolean
    inspector_photo: boolean
    jagger_wool: boolean
    jagger_iron: boolean
    jagger_gold: boolean
    jagger_emerald: boolean
    laundry_gal_pillows: boolean
    inspector_gloves: boolean
    inspector_air_freshener: boolean
    inspector_work_boots: boolean
    master_meyer: boolean
    master_meyer_repeat: boolean
    jagger_diamond: boolean
    lester_brody: boolean
    electrician_russel: boolean
    phase_four_ascension_o1: boolean
    phase_four_ascension_o2: boolean
    phase_four_ascension_o3: boolean
    phase_four_ascension_o4: boolean
    phase_four_ascension_o5: boolean
    electrician_russel_repeat: boolean
    combat_artist_sally: boolean
    gizzy_moonpowder: boolean
    combat_artist_sally_repeat: boolean
    gizzy_moonpowder_repeat: boolean
    lester_brody_repeat: boolean
    bucky_sky_tea_leaves_repeat: boolean
    bucky_fragments_repeat: boolean
    meet_the_sandman: boolean
}

export interface Completed {
    npc_reception_start: boolean
    npc_john_pireso: boolean
    npc_general_daku: boolean
    npc_lady_saichi: boolean
    phase_two_asc: boolean
    npc_blacksmith_apprentice: boolean
    npc_laundry: boolean
    npc_hammer: boolean
    npc_king_flut: boolean
    npc_oasis: boolean
    npc_blacksmith: boolean
    phase_three_asc: boolean
    npc_arcade_player: boolean
    npc_quiz_show_host: boolean
    npc_the_ratman: boolean
    npc_don_espresso: boolean
    npc_jets_mcturbo: boolean
    npc_jimmy_bimmy: boolean
    npc_skyblock_player: boolean
    npc_bucky: boolean
    npc_hammer_part_two: boolean
    npc_gambler_george: boolean
    npc_hermes: boolean
    npc_bill_starr: boolean
    npc_spaceman: boolean
    npc_executives: boolean
    npc_wally: boolean
    npc_peter: boolean
    npc_laundry_gal: boolean
    npc_inspector: boolean
    npc_master_meyer: boolean
    staff_wallet_upgrade: boolean
    npc_jeremy_jagger: boolean
    npc_lester_brody: boolean
    npc_electrician_russel: boolean
    phase_four_ascension_q1: boolean
    phase_four_ascension_q2: boolean
    phase_four_ascension_q3: boolean
    phase_four_ascension_q4: boolean
    phase_four_ascension_q5: boolean
    phase_four_ascension_wallet_q: boolean
    npc_combat_artist_sally: boolean
    npc_gizzy_moonpowder: boolean
    npc_john_indigos_hammer: boolean
    npc_meet_the_sandman: boolean
}

export interface Item {
    slumber_item_bed_sheets: number
    slumber_item_indigos_map: number
    slumber_item_trusty_rope: number
    slumber_item_ender_dust: number
    slumber_item_imperial_leather: number
    slumber_item_perfume: number
    slumber_item_iron_nugget: number
    slumber_item_comfy_pillow: number
    slumber_item_silver_coins: number
    slumber_item_soul: number
    slumber_item_golden_ticket: number
    slumber_item_weapon_mold: number
    slumber_item_missing_amulet: number
    slumber_item_amulet: number
    slumber_item_oasis_water: number
    slumber_item_enchanted_hammer: number
    slumber_item_ratman_mask: number
    slumber_item_spark_plug: number
    slumber_item_limbo_dust: number
    slumber_item_emerald_shard: number
    slumber_item_token_of_ferocity: number
    slumber_item_timeworn_mystery_box: number
    slumber_item_gold_bar: number
    slumber_item_nether_star: number
    slumber_item_dwarven_mithril: number
    slumber_item_cable: number
    slumber_item_discarded_kart_wheel: number
    slumber_item_silver_blade_replay: number
    slumber_item_proof_of_success: number
    slumber_item_blitz_star: number
    slumber_item_faded_blitz_star: number
    slumber_item_moon_stone_nugget: number
    slumber_item_block_of_mega_walls_obsidian: number
    slumber_item_murder_weapon: number
    slumber_item_victim_photo: number
    slumber_item_air_freshener: number
    slumber_item_gloves: number
    slumber_item_boots: number
    slumber_item_diamond_fragment: number
    slumber_item_cleaned_up_murder_knife: number
    slumber_item_unused_bomb_materials: number
    slumber_item_glowing_sand_paper: number
}

export interface Phase {
    current: number
}

export interface Room {
    room_1: boolean
    room_2: boolean
    room_3: boolean
    room_8: boolean
    room_10: boolean
    room_12: boolean
    room_7: boolean
    room_6: boolean
    room_11: boolean
    room_4: boolean
    room_5: boolean
    room_9: boolean
    owners_office: boolean
}

export interface Phasethree {
    completed_quests: number
}

export interface Minion {
    ender_dust: number
    games: number
    tickets: number
}

export interface Sandman {
    ticket_multiplier: number
    exp_multiplier: number
}

export interface WoolGames {
    progression: Progression
    coins: number
}

export interface Progression {
    available_layers: number
}

export interface MurderMystery {
    murdermystery_books: string[]
    detective_chance: number
    murderer_chance: number
    coins: number
    coins_pickedup: number
    coins_pickedup_MURDER_DOUBLE_UP: number
    coins_pickedup_gold_rush: number
    coins_pickedup_gold_rush_MURDER_DOUBLE_UP: number
    deaths: number
    deaths_MURDER_DOUBLE_UP: number
    deaths_gold_rush: number
    deaths_gold_rush_MURDER_DOUBLE_UP: number
    games: number
    games_MURDER_DOUBLE_UP: number
    games_gold_rush: number
    games_gold_rush_MURDER_DOUBLE_UP: number
    wins: number
    wins_MURDER_DOUBLE_UP: number
    wins_gold_rush: number
    wins_gold_rush_MURDER_DOUBLE_UP: number
    mm_christmas_chests: number
}

export interface Duels {
    moved_to_redis_3: boolean
    show_lb_option: string
    chat_enabled: string
    leaderboardPage_goals: number
    no_debuff_rookie_title_prestige: number
    combo_rookie_title_prestige: number
    tnt_games_rookie_title_prestige: number
    sumo_rookie_title_prestige: number
    bridge_rookie_title_prestige: number
    parkour_rookie_title_prestige: number
    boxing_rookie_title_prestige: number
    bow_rookie_title_prestige: number
    classic_rookie_title_prestige: number
    op_rookie_title_prestige: number
    blitz_rookie_title_prestige: number
    mega_walls_rookie_title_prestige: number
    all_modes_rookie_title_prestige: number
    uhc_rookie_title_prestige: number
    skywars_rookie_title_prestige: number
    selected_1_new: string
    selected_2_new: string
    games_played_duels: number
    bow_shots: number
    classic_duel_bow_shots: number
    classic_duel_damage_dealt: number
    classic_duel_health_regenerated: number
    classic_duel_melee_hits: number
    classic_duel_melee_swings: number
    classic_duel_rounds_played: number
    damage_dealt: number
    health_regenerated: number
    melee_hits: number
    melee_swings: number
    rounds_played: number
    bow_hits: number
    classic_duel_bow_hits: number
    sumo_duel_melee_hits: number
    sumo_duel_melee_swings: number
    sumo_duel_rounds_played: number
    rematch_option_1: string
    duels_recently_played2: string
    maps_won_on: string[]
    coins: number
    best_overall_winstreak: number
    current_winstreak: number
    best_all_modes_winstreak: number
    best_uhc_winstreak: number
    best_skywars_winstreak: number
    best_mega_walls_winstreak: number
    best_blitz_winstreak: number
    current_sumo_winstreak: number
    best_op_winstreak: number
    best_classic_winstreak: number
    best_bow_winstreak: number
    best_no_debuff_winstreak: number
    best_combo_winstreak: number
    best_tnt_games_winstreak: number
    best_sumo_winstreak: number
    best_bridge_winstreak: number
    best_parkour_winstreak: number
    best_boxing_winstreak: number
    best_arena_winstreak: number
    best_winstreak_mode_sumo_duel: number
    current_winstreak_mode_sumo_duel: number
    kills: number
    sumo_duel_kills: number
    sumo_duel_wins: number
    wins: number
    deaths: number
    losses: number
    sumo_duel_deaths: number
    sumo_duel_losses: number
    classic_duel_deaths: number
    classic_duel_losses: number
}

export interface Pit {
    profile: Profile
    pit_stats_ptl: PitStatsPtl
}

export interface Profile {
    moved_achievements_1: boolean
    outgoing_offers: any[]
    spire_stash_inv: SpireStashInv
    moved_achievements_2: boolean
    leaderboard_stats: LeaderboardStats
    last_save: number
    inv_contents: InvContents
    zero_point_three_gold_transfer: boolean
    inv_armor: InvArmor
    spire_stash_armor: SpireStashArmor
    cash_during_prestige_0: number
}

export interface SpireStashInv {
    type: number
    data: number[]
}

export interface LeaderboardStats { }

export interface InvContents {
    type: number
    data: number[]
}

export interface InvArmor {
    type: number
    data: number[]
}

export interface SpireStashArmor {
    type: number
    data: number[]
}

export interface PitStatsPtl {
    joins: number
}

export interface Housing {
    packages: string[]
}

export interface Achievements {
    arcade_miniwalls_winner: number
    arcade_arcade_banker: number
    general_challenger: number
    arcade_arcade_winner: number
    buildbattle_buildbattle_points: number
    skyblock_minion_lover: number
    skyblock_treasury: number
    skyblock_harvester: number
    skyblock_gatherer: number
    skyblock_excavator: number
    skywars_you_re_a_star: number
    bedwars_level: number
    summer_shopaholic: number
    bedwars_beds: number
    bedwars_bedwars_killer: number
    bedwars_wins: number
    bedwars_collectors_edition: number
    skyblock_augmentation: number
    skyblock_domesticator: number
    skyblock_concoctor: number
    halloween2017_pumpkinator: number
    general_wins: number
    general_quest_master: number
    bedwars_loot_box: number
    bedwars_bedwars_challenger: number
    skywars_kills_solo: number
    arcade_dropper_skydiver: number
    arcade_party_super_star: number
    general_coins: number
    woolgames_mountain_of_wool: number
    buildbattle_guess_the_build_guesses: number
    buildbattle_build_battle_score: number
    arcade_zombies_nice_shot: number
    arcade_zombies_round_progression: number
    arcade_zombies_high_round: number
    christmas2017_present_collector: number
    christmas2017_no_christmas: number
    murdermystery_hoarder: number
    bedwars_slumber_ticket_master: number
    christmas2017_advent_2023: number
    christmas2017_best_presents: number
    duels_duels_traveller: number
    duels_duels_winner: number
    duels_duels_win_streak: number
}

export interface Challenges2 {
    all_time: AllTime
}

export interface AllTime {
    BEDWARS__offensive: number
    BEDWARS__support: number
    ARCADE__dropper_challenge: number
    BUILD_BATTLE__top_3_challenge: number
    ARCADE__zombies_challenge: number
    BEDWARS__defensive: number
    DUELS__feed_the_void_challenge: number
}

export interface SocialMedia {
    links: Links
    prompt: boolean
}

export interface Links {
    DISCORD: string
}

export interface AchievementRewardsNew {
    for_points_200: number
    for_points_300: number
    for_points_400: number
    for_points_500: number
    for_points_600: number
    for_points_700: number
    for_points_800: number
    for_points_900: number
    for_points_1000: number
    for_points_1100: number
    for_points_1200: number
    for_points_1300: number
    for_points_1400: number
    for_points_1500: number
    for_points_1600: number
    for_points_1700: number
    for_points_1800: number
    for_points_1900: number
}

export interface Leveling {
    claimedRewards: number[]
}

export interface VanityMeta {
    packages: string[]
}

export interface PetConsumables {
    CAKE: number
    COOKIE: number
    FEATHER: number
    GOLD_RECORD: number
    HAY_BLOCK: number
    LAVA_BUCKET: number
    LEASH: number
    MELON: number
    MILK_BUCKET: number
    MUSHROOM_SOUP: number
    PUMPKIN_PIE: number
    RED_ROSE: number
    STICK: number
    WATER_BUCKET: number
    APPLE: number
    BAKED_POTATO: number
    BONE: number
    MAGMA_CREAM: number
    RAW_FISH: number
    SLIME_BALL: number
    WHEAT: number
    WOOD_SWORD: number
    ROTTEN_FLESH: number
    CARROT_ITEM: number
    COOKED_BEEF: number
    PORK: number
    BREAD: number
}

export interface Seasonal {
    halloween: Halloween
    silver: number
    christmas: Christmas
}

export interface Halloween {
    '2023': N2023
}

export interface N2023 {
    bingo: Bingo
    levelling: Levelling
}

export interface Bingo {
    easy: Easy
}

export interface Easy {
    objectives: Objectives
}

export interface Objectives {
    Bedwarsdiamond: number
    Bedwarsshopoftraps: number
}

export interface Levelling {
    experience: number
}

export interface Christmas {
    '2023': N20232
}

export interface N20232 {
    presents: Presents
    levelling: Levelling2
    adventRewards: AdventRewards
    bingo: Bingo2
}

export interface Presents {
    ARCADE_1: boolean
    BEDWARS_1: boolean
    MAIN_LOBBY_1: boolean
    BEDWARS_2: boolean
    MAIN_LOBBY_2: boolean
}

export interface Levelling2 {
    experience: number
}

export interface AdventRewards {
    day1: number
    day2: number
    day4: number
    day5: number
    day6: number
    day7: number
    day9: number
    day10: number
    day11: number
    day12: number
    day13: number
    day15: number
    day17: number
    day19: number
    day21: number
    day22: number
    day23: number
    day25: number
}

export interface Bingo2 {
    easy: Easy2
}

export interface Easy2 {
    objectives: Objectives2
}

export interface Objectives2 {
    Bedwarsdiamond: number
    Arcadegrinchrookie: number
    Bedwarsholidaybedbug: number
}

export interface Monthlycrates {
    '11-2023': N112023
    '12-2023': N122023
    '1-2024': N12024
}

export interface N112023 {
    REGULAR: boolean
    VIP: boolean
    VIP_PLUS: boolean
    MVP: boolean
    MVP_PLUS: boolean
}

export interface N122023 {
    NORMAL: boolean
    VIP: boolean
    VIP_PLUS: boolean
    MVP: boolean
    MVP_PLUS: boolean
}

export interface N12024 {
    MVP_PLUS: boolean
    MVP: boolean
    VIP_PLUS: boolean
    VIP: boolean
    NORMAL: boolean
}

export interface Quests {
    bedwars_daily_win: BedwarsDailyWin
    bedwars_daily_one_more: BedwarsDailyOneMore
    bedwars_daily_bed_breaker: BedwarsDailyBedBreaker
    bedwars_daily_final_killer: BedwarsDailyFinalKiller
    bedwars_weekly_bed_elims: BedwarsWeeklyBedElims
    bedwars_weekly_dream_win: BedwarsWeeklyDreamWin
    bedwars_weekly_challenges_win: BedwarsWeeklyChallengesWin
    bedwars_weekly_final_killer: BedwarsWeeklyFinalKiller
    bedwars_weekly_pumpkinator: BedwarsWeeklyPumpkinator
    bedwars_daily_nightmares: BedwarsDailyNightmares
    bedwars_daily_gifts: BedwarsDailyGifts
    build_battle_player: BuildBattlePlayer
    build_battle_winner: BuildBattleWinner
    build_battle_weekly: BuildBattleWeekly
    build_battle_christmas: BuildBattleChristmas
    build_battle_christmas_weekly: BuildBattleChristmasWeekly
    pit_daily_kills: PitDailyKills
    pit_daily_contract: PitDailyContract
    pit_weekly_gold: PitWeeklyGold
    arcade_gamer: ArcadeGamer
    arcade_winner: ArcadeWinner
    arcade_specialist: ArcadeSpecialist
    skywars_solo_win: SkywarsSoloWin
    skywars_solo_kills: SkywarsSoloKills
    skywars_team_win: SkywarsTeamWin
    skywars_team_kills: SkywarsTeamKills
    skywars_arcade_win: SkywarsArcadeWin
    skywars_corrupt_win: SkywarsCorruptWin
    skywars_weekly_kills: SkywarsWeeklyKills
    skywars_weekly_arcade_win_all: SkywarsWeeklyArcadeWinAll
    skywars_special_north_pole: SkywarsSpecialNorthPole
    skywars_daily_tokens: SkywarsDailyTokens
    skywars_weekly_free_loot_chest: SkywarsWeeklyFreeLootChest
    duels_player: DuelsPlayer
    duels_killer: DuelsKiller
    duels_winner: DuelsWinner
    duels_weekly_kills: DuelsWeeklyKills
    duels_weekly_wins: DuelsWeeklyWins
}

export interface BedwarsDailyWin {
    completions: Completion[]
}

export interface Completion {
    time: number
}

export interface BedwarsDailyOneMore {
    completions: Completion2[]
}

export interface Completion2 {
    time: number
}

export interface BedwarsDailyBedBreaker {
    completions: Completion3[]
    active: Active
}

export interface Completion3 {
    time: number
}

export interface Active {
    objectives: Objectives3
    started: number
}

export interface Objectives3 {
    bedwars_weekly_final_killer: number
}

export interface BedwarsDailyFinalKiller {
    completions: Completion4[]
    active: Active2
}

export interface Completion4 {
    time: number
}

export interface Active2 {
    objectives: Objectives4
    started: number
}

export interface Objectives4 {
    bedwars_daily_final_killer: number
}

export interface BedwarsWeeklyBedElims {
    completions: Completion5[]
}

export interface Completion5 {
    time: number
}

export interface BedwarsWeeklyDreamWin {
    active: Active3
}

export interface Active3 {
    objectives: Objectives5
    started: number
}

export interface Objectives5 { }

export interface BedwarsWeeklyChallengesWin {
    completions: Completion6[]
    active: Active4
}

export interface Completion6 {
    time: number
}

export interface Active4 {
    objectives: Objectives6
    started: number
}

export interface Objectives6 { }

export interface BedwarsWeeklyFinalKiller {
    completions: Completion7[]
    active: Active5
}

export interface Completion7 {
    time: number
}

export interface Active5 {
    objectives: Objectives7
    started: number
}

export interface Objectives7 {
    bedwars_weekly_final_killer: number
}

export interface BedwarsWeeklyPumpkinator {
    completions: Completion8[]
}

export interface Completion8 {
    time: number
}

export interface BedwarsDailyNightmares {
    completions: Completion9[]
}

export interface Completion9 {
    time: number
}

export interface BedwarsDailyGifts {
    completions: Completion10[]
}

export interface Completion10 {
    time: number
}

export interface BuildBattlePlayer {
    active: Active6
}

export interface Active6 {
    objectives: Objectives8
    started: number
}

export interface Objectives8 { }

export interface BuildBattleWinner {
    active: Active7
}

export interface Active7 {
    objectives: Objectives9
    started: number
}

export interface Objectives9 { }

export interface BuildBattleWeekly {
    active: Active8
}

export interface Active8 {
    objectives: Objectives10
    started: number
}

export interface Objectives10 { }

export interface BuildBattleChristmas {
    active: Active9
}

export interface Active9 {
    objectives: Objectives11
    started: number
}

export interface Objectives11 { }

export interface BuildBattleChristmasWeekly {
    active: Active10
}

export interface Active10 {
    objectives: Objectives12
    started: number
}

export interface Objectives12 { }

export interface PitDailyKills {
    active: Active11
}

export interface Active11 {
    objectives: Objectives13
    started: number
}

export interface Objectives13 { }

export interface PitDailyContract {
    active: Active12
}

export interface Active12 {
    objectives: Objectives14
    started: number
}

export interface Objectives14 { }

export interface PitWeeklyGold {
    active: Active13
}

export interface Active13 {
    objectives: Objectives15
    started: number
}

export interface Objectives15 { }

export interface ArcadeGamer {
    completions: Completion11[]
    active: Active14
}

export interface Completion11 {
    time: number
}

export interface Active14 {
    objectives: Objectives16
    started: number
}

export interface Objectives16 { }

export interface ArcadeWinner {
    completions: Completion12[]
    active: Active15
}

export interface Completion12 {
    time: number
}

export interface Active15 {
    objectives: Objectives17
    started: number
}

export interface Objectives17 { }

export interface ArcadeSpecialist {
    completions: Completion13[]
    active: Active16
}

export interface Completion13 {
    time: number
}

export interface Active16 {
    objectives: Objectives18
    started: number
}

export interface Objectives18 { }

export interface SkywarsSoloWin {
    active: Active17
}

export interface Active17 {
    objectives: Objectives19
    started: number
}

export interface Objectives19 { }

export interface SkywarsSoloKills {
    active: Active18
}

export interface Active18 {
    objectives: Objectives20
    started: number
}

export interface Objectives20 { }

export interface SkywarsTeamWin {
    active: Active19
}

export interface Active19 {
    objectives: Objectives21
    started: number
}

export interface Objectives21 { }

export interface SkywarsTeamKills {
    active: Active20
}

export interface Active20 {
    objectives: Objectives22
    started: number
}

export interface Objectives22 { }

export interface SkywarsArcadeWin {
    active: Active21
}

export interface Active21 {
    objectives: Objectives23
    started: number
}

export interface Objectives23 { }

export interface SkywarsCorruptWin {
    active: Active22
}

export interface Active22 {
    objectives: Objectives24
    started: number
}

export interface Objectives24 { }

export interface SkywarsWeeklyKills {
    active: Active23
}

export interface Active23 {
    objectives: Objectives25
    started: number
}

export interface Objectives25 { }

export interface SkywarsWeeklyArcadeWinAll {
    active: Active24
}

export interface Active24 {
    objectives: Objectives26
    started: number
}

export interface Objectives26 { }

export interface SkywarsSpecialNorthPole {
    active: Active25
}

export interface Active25 {
    objectives: Objectives27
    started: number
}

export interface Objectives27 { }

export interface SkywarsDailyTokens {
    active: Active26
}

export interface Active26 {
    objectives: Objectives28
    started: number
}

export interface Objectives28 { }

export interface SkywarsWeeklyFreeLootChest {
    active: Active27
}

export interface Active27 {
    objectives: Objectives29
    started: number
}

export interface Objectives29 { }

export interface DuelsPlayer {
    completions: Completion14[]
}

export interface Completion14 {
    time: number
}

export interface DuelsKiller {
    active: Active28
}

export interface Active28 {
    objectives: Objectives30
    started: number
}

export interface Objectives30 {
    kill: number
}

export interface DuelsWinner {
    completions: Completion15[]
}

export interface Completion15 {
    time: number
}

export interface DuelsWeeklyKills {
    active: Active29
}

export interface Active29 {
    objectives: Objectives31
    started: number
}

export interface Objectives31 {
    kill: number
}

export interface DuelsWeeklyWins {
    active: Active30
}

export interface Active30 {
    objectives: Objectives32
    started: number
}

export interface Objectives32 {
    win: number
}

export interface Eugene {
    dailyTwoKExp: number
}

export interface ParkourCheckpointBests {
    BedwarsSpring2023: BedwarsSpring2023
}

export interface BedwarsSpring2023 {
    '0': number
    '1': number
    '2': number
    '3': number
    '4': number
    '5': number
    '6': number
}

export interface ParkourCompletions {
    BedwarsSpring2023: BedwarsSpring20232[]
}

export interface BedwarsSpring20232 {
    timeStart: number
    timeTook: number
}

export interface HousingMeta {
    packages: string[]
}

export interface Tourney {
    first_join_lobby: number
    grinch_simulator_1: GrinchSimulator1
    total_tributes: number
}

export interface GrinchSimulator1 {
    games_played: number
    playtime: number
    tributes_earned: number
    first_win: number
    claimed_ranking_reward: number
}

export interface QuestSettings {
    autoActivate: boolean
}
