import InfocardCommand from './infocard';

export default InfocardCommand;