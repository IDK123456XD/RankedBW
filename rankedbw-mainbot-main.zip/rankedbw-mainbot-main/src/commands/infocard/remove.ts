import { AutocompleteInteraction, ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import fs from 'fs';
import path from 'path';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class InfoCardRemoveCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Remove an infocard from the database.')
        .addStringOption((option) =>
            option
                .setName('name')
                .setDescription('The name of the infocard you want to remove.')
                .setRequired(true)
                .setAutocomplete(true)
        )

    requiredRoles: string[] = [settings.roles.administrator, settings.roles.owner, settings.roles.developer];

    async autocomplete(interaction: AutocompleteInteraction) {
        const focusedOption = interaction.options.getFocused(true);
        if (focusedOption.name !== 'card') return interaction.respond([]);

        const cardName = focusedOption.value as string;
        const infocards = await prisma.infocard.findMany();

        const choices = infocards.filter(card => card.name.toLowerCase().includes(cardName.toLowerCase())).map(card => ({
            name: card.name,
            value: card.name
        }));

        await interaction.respond(choices);
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error('You must run this command in the server!', 'Not in Server')],
                ephemeral: true,
            });
            return;
        }

        const name = interaction.options.getString('name');

        // Check if infocard exists
        const infocard = await prisma.infocard.findUnique({
            where: {
                name: name
            }
        });

        if (!infocard) {
            await interaction.reply({
                embeds: [embeds.error(`Infocard **${name}** does not exist!`, 'Not Found')],
                ephemeral: true,
            });
            return;
        }

        // Delete the image file
        const filePath = path.join('./assets/images/infocards', infocard.image);
        if (fs.existsSync(filePath)) {
            try {
                fs.unlinkSync(filePath);
            } catch (error) {
                console.error(`Failed to delete image file: ${error}`);
                // Continue with database removal even if file deletion fails
            }
        }

        // Delete the infocard from the database
        await prisma.infocard.delete({
            where: {
                id: infocard.id
            }
        });

        await interaction.reply({
            embeds: [embeds.success(`Infocard **${name}** has been removed from the database.`, 'Infocard Removed')],
        });
    }
} 