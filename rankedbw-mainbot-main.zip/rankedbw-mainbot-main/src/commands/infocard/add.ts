import { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import fs from 'fs';
import path from 'path';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';
import { InfocardColor } from '@common/database/generated/client';

export default class InfoCardAddCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Add an infocard to the database.')
        .addStringOption((option) =>
            option
                .setName('name')
                .setDescription('The name of the infocard you want to add.')
                .setRequired(true)
        )
        .addAttachmentOption((option) =>
            option
                .setName('image')
                .setDescription('The image of the infocard you want to add.')
                .setRequired(true)
        )
        .addStringOption((option) =>
            option
                .setName('color')
                .addChoices(
                    { name: 'Light', value: 'light' },
                    { name: 'Dark', value: 'dark' }
                )
                .setDescription('The color of the infocard you want to add.')
                .setRequired(true)
        )
        .addBooleanOption((option) =>
            option
                .setName('grant_all')
                .setDescription('Whether the infocard should be granted to all users.')
                .setRequired(false)
        )

    requiredRoles: string[] = [settings.roles.administrator, settings.roles.owner, settings.roles.developer];

    async execute(interaction: ChatInputCommandInteraction) {
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error('You must run this command in the server!', 'Not in Server')],
                ephemeral: true,
            });
            return;
        }

        const name = interaction.options.getString('name');
        const image = interaction.options.getAttachment('image');
        const color = interaction.options.getString('color');
        const grantAll = interaction.options.getBoolean('grant_all');
        if (!image) {
            await interaction.reply({
                embeds: [embeds.error('You must provide an image!', 'No Image')],
                ephemeral: true,
            });
            return;
        }

        // Check if the file is an image
        if (!image.contentType || !image.contentType.startsWith('image/')) {
            await interaction.reply({
                embeds: [embeds.error('The file must be an image!', 'Invalid File')],
                ephemeral: true,
            });
            return;
        }

        // Check if infocard with the same name already exists
        const existingInfocard = await prisma.infocard.findUnique({
            where: {
                name: name
            }
        });

        if (existingInfocard) {
            await interaction.reply({
                embeds: [embeds.error('An infocard with this name already exists!', 'Duplicate Name')],
                ephemeral: true,
            });
            return;
        }

        // Create the directory if it doesn't exist
        const infocardsDir = './assets/images/infocards';
        if (!fs.existsSync(infocardsDir)) {
            fs.mkdirSync(infocardsDir, { recursive: true });
        }

        // Download and save the image
        const response = await fetch(image.url);
        const buffer = Buffer.from(await response.arrayBuffer());

        // Generate a unique filename using the infocard name
        const fileExtension = path.extname(image.name);
        const fileName = `${name.toLowerCase().replace(/\s+/g, '_')}${fileExtension}`;
        const filePath = path.join(infocardsDir, fileName);

        fs.writeFileSync(filePath, new Uint8Array(buffer));

        // Create the infocard in the database
        const newInfocard = await prisma.infocard.create({
            data: {
                name,
                image: fileName,
                color: color as InfocardColor,
            }
        });

        if (grantAll) {
            const players = await prisma.player.findMany({
                select: { id: true },
            });

            await prisma.infocard.update({
                where: { id: newInfocard.id },
                data: {
                    players: {
                        connect: players.map(p => ({ id: p.id })),
                    },
                },
            });
        }

        const attachment = new AttachmentBuilder(buffer, { name: fileName });
        await interaction.reply({
            embeds: [embeds.success(`Infocard **${name}** has been added to the database.`, 'Infocard Added').setImage(`attachment://${fileName}`)],
            files: [attachment],
        });
    }
}