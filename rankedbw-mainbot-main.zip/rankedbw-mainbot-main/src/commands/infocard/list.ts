import { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import fs from 'fs';
import path from 'path';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class InfoCardListCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('List all available infocards.')

    async execute(interaction: ChatInputCommandInteraction) {
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!member) {
            await interaction.reply({
                embeds: [embeds.error('You must run this command in the server!', 'Not in Server')],
                ephemeral: true,
            });
            return;
        }

        // Fetch all infocards from the database
        const infocards = await prisma.infocard.findMany({
            orderBy: {
                name: 'asc'
            }
        });

        if (infocards.length === 0) {
            await interaction.reply({
                embeds: [embeds.error('No infocards found in the database!', 'No Infocards')],
                ephemeral: true,
            });
            return;
        }

        // Start the infocard display with pagination
        await startInfocardList(interaction, infocards);
    }
}

async function startInfocardList(interaction: ChatInputCommandInteraction, infocards: any[]) {
    let infocardIndex = 0;
    const infocardsDir = './assets/images/infocards';

    const displayInfocard = async (index: number) => {
        const infocard = infocards[index];
        const imagePath = path.join(infocardsDir, infocard.image);

        // Check if the image file exists
        let imageBuffer: Buffer | null = null;
        if (fs.existsSync(imagePath)) {
            imageBuffer = fs.readFileSync(imagePath);
        }

        const embed = embeds.normal(
            `**Name:** ${infocard.name}\n**Image:** ${infocard.image}${!imageBuffer ? '\n⚠️ *Image file not found*' : ''}`,
            `Infocard \`${index + 1}\`/\`${infocards.length}\``
        );

        if (imageBuffer) {
            embed.setImage(`attachment://${infocard.image}`);
        }

        return {
            embeds: [embed],
            files: imageBuffer ? [new AttachmentBuilder(imageBuffer, { name: infocard.image })] : [],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-infocard_previous`)
                        .setLabel('Previous')
                        .setEmoji('⬅️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(index === 0),
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-infocard_next`)
                        .setLabel('Next')
                        .setEmoji('➡️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(index === infocards.length - 1),
                )
            ] as ActionRowBuilder<ButtonBuilder>[]
        };
    };

    await interaction.reply(await displayInfocard(infocardIndex));

    const collector = interaction.channel.createMessageComponentCollector({
        filter: (i) => i.user.id === interaction.user.id && (
            i.customId === `${interaction.id}-infocard_previous` ||
            i.customId === `${interaction.id}-infocard_next`
        ),
        time: 60 * 1000, // 1 minute timeout
    });

    collector.on('collect', async (i) => {
        if (i.customId === `${interaction.id}-infocard_previous`) {
            if (infocardIndex === 0) return;
            infocardIndex--;
        } else if (i.customId === `${interaction.id}-infocard_next`) {
            if (infocardIndex === infocards.length - 1) return;
            infocardIndex++;
        }

        await i.deferUpdate();
        await interaction.editReply(await displayInfocard(infocardIndex));
    });

    collector.on('end', () => {
        // Remove buttons when collector ends
        interaction.editReply({ components: [] }).catch(() => { });
    });
}

// Remove the old background list function since it's not needed for this command
async function startBackgroundList(interaction: ChatInputCommandInteraction, backgroundList: string[]) {
    let backgroundIndex = 0;

    await interaction.reply({
        embeds: [embeds.normal(
            `Background Name: ${backgroundList[backgroundIndex].split('.')[0].toProperCase()}`,
            `Background \`${backgroundIndex + 1}\`/\`${backgroundList.length}\``
        ).setImage(`attachment://${backgroundList[backgroundIndex]}`)],
        files: [
            new AttachmentBuilder(
                fs.readFileSync(`./assets/images/info_backgrounds/${backgroundList[backgroundIndex]}`),
                { name: `${backgroundList[backgroundIndex]}` }
            )
        ],
        components: [
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`${interaction.id}-background_previous`)
                    .setLabel('Previous')
                    .setEmoji('⬅️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(backgroundIndex === 0),
                new ButtonBuilder()
                    .setCustomId(`${interaction.id}-background_next`)
                    .setLabel('Next')
                    .setEmoji('➡️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(backgroundIndex === backgroundList.length - 1),
            )
        ] as ActionRowBuilder<ButtonBuilder>[]
    });

    const collector = interaction.channel.createMessageComponentCollector({
        filter: (i) => i.user.id === interaction.user.id && (
            i.customId === `${interaction.id}-background_previous` ||
            i.customId === `${interaction.id}-background_next`
        ),
        time: 30 * 1000,
    });

    collector.on('collect', async (i) => {
        if (i.customId === `${interaction.id}-background_previous`) {
            if (backgroundIndex === 0) return;
            backgroundIndex--;
        } else if (i.customId === `${interaction.id}-background_next`) {
            if (backgroundIndex === backgroundList.length - 1) return;
            backgroundIndex++;
        }

        await i.deferUpdate();

        await interaction.editReply({
            embeds: [embeds.normal(
                `Background Name: ${backgroundList[backgroundIndex].split('.')[0].toProperCase()}`,
                `Background \`${backgroundIndex + 1}\`/\`${backgroundList.length}\``
            ).setImage(`attachment://${backgroundList[backgroundIndex]}`)],
            files: [new AttachmentBuilder(
                fs.readFileSync(`./assets/images/info_backgrounds/${backgroundList[backgroundIndex]}`),
                { name: `${backgroundList[backgroundIndex]}` }
            )],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-background_previous`)
                        .setLabel('Previous')
                        .setEmoji('⬅️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(backgroundIndex === 0),
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-background_next`)
                        .setLabel('Next')
                        .setEmoji('➡️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(backgroundIndex === backgroundList.length - 1),
                )
            ] as ActionRowBuilder<ButtonBuilder>[]
        });
    });
}