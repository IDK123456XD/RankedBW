import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class InfoCardReloadCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('reload')
        .setDescription('Reload all infocards.')

    requiredRoles: string[] = [settings.roles.administrator, settings.roles.owner, settings.roles.developer];

    async execute(interaction: ChatInputCommandInteraction) {
        const defaultInfoCard = await prisma.infocard.findFirst({
            where: {
                name: "default"
            }
        });

        if (!defaultInfoCard) {
            await interaction.reply({
                embeds: [embeds.error('Default infocard not found!', 'Infocard Not Found')]
            });
            return;
        }

        const updates = await prisma.player.updateMany({
            where: {
                selectedInfocardId: null
            },
            data: {
                selectedInfocardId: defaultInfoCard.id
            }
        });

        await interaction.reply({
            embeds: [embeds.success(`Granted ${updates.count} players access to default info card!`, 'Infocards Reloaded')]
        });
    }
} 