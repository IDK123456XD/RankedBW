import { AttachmentBuilder, AutocompleteInteraction, ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import fs from 'fs';
import path from 'path';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class InfoCardGrantCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('grant')
        .setDescription('Grant an infocard to a player.')
        .addUserOption((option) =>
            option
                .setName('player')
                .setDescription('The player to grant the infocard to.')
                .setRequired(true)
        )
        .addStringOption((option) =>
            option
                .setName('card')
                .setDescription('The name of the infocard to grant.')
                .setRequired(true)
                .setAutocomplete(true)
        )

    requiredRoles: string[] = [settings.roles.administrator, settings.roles.owner, settings.roles.developer];

    async autocomplete(interaction: AutocompleteInteraction) {
        const focusedOption = interaction.options.getFocused(true);
        if (focusedOption.name !== 'card') return interaction.respond([]);

        const cardName = focusedOption.value as string;
        const infocards = await prisma.infocard.findMany();

        const choices = infocards.filter(card => card.name.toLowerCase().includes(cardName.toLowerCase())).map(card => ({
            name: card.name,
            value: card.name
        }));

        await interaction.respond(choices);
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error('You must run this command in the server!', 'Not in Server')],
                ephemeral: true,
            });
            return;
        }

        const targetUser = interaction.options.getUser('player');
        const cardName = interaction.options.getString('card');

        // Check if the player exists in the database
        const player = await prisma.player.findUnique({
            where: {
                userId: targetUser.id
            },
            include: {
                infocards: true
            }
        });

        if (!player) {
            await interaction.reply({
                embeds: [embeds.error(`Player ${targetUser.username} is not registered!`, 'Player Not Found')],
                ephemeral: true,
            });
            return;
        }

        // Check if the infocard exists
        const infocard = await prisma.infocard.findUnique({
            where: {
                name: cardName
            }
        });

        if (!infocard) {
            await interaction.reply({
                embeds: [embeds.error(`Infocard **${cardName}** does not exist!`, 'Infocard Not Found')],
                ephemeral: true,
            });
            return;
        }

        // Check if the player already has this infocard
        const hasCard = player.infocards.some(card => card.id === infocard.id);
        if (hasCard) {
            await interaction.reply({
                embeds: [embeds.error(`Player ${targetUser.username} already has the infocard **${cardName}**!`, 'Already Has Card')],
                ephemeral: true,
            });
            return;
        }

        // Grant the infocard to the player
        await prisma.player.update({
            where: {
                id: player.id
            },
            data: {
                infocards: {
                    connect: {
                        id: infocard.id
                    }
                }
            }
        });

        // Get the image file for the embed
        const filePath = path.join('./assets/images/infocards', infocard.image);
        let attachment = null;

        if (fs.existsSync(filePath)) {
            const imageBuffer = fs.readFileSync(filePath);
            attachment = new AttachmentBuilder(imageBuffer, { name: infocard.image });
        }

        const successEmbed = embeds.success(
            `Granted infocard **${cardName}** to ${targetUser.username}!`,
            'Infocard Granted'
        );

        if (attachment) {
            successEmbed.setImage(`attachment://${infocard.image}`);
            await interaction.reply({
                embeds: [successEmbed],
                files: [attachment]
            });
        } else {
            await interaction.reply({
                embeds: [successEmbed]
            });
        }
    }
} 