import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import InfoCardAddCommand from './add';
import InfoCardRemoveCommand from './remove';
import InfoCardGrantCommand from './grant';
import InfoCardUngrantCommand from './ungrant';
import InfoCardListCommand from './list';
import InfoCardReloadCommand from './reload';

export default class InfocardCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('infocard')
        .setDescription('Run infocard commands.')

    childCommands: ChildCommand[] = [
        new InfoCardAddCommand(),
        new InfoCardRemoveCommand(),
        new InfoCardGrantCommand(),
        new InfoCardUngrantCommand(),
        new InfoCardListCommand(),
        new InfoCardReloadCommand()
    ];
} 