import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import { prisma } from '@common/database/connectors/prisma';

export default class PartyKickCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('kick')
        .setDescription('Kick someone from your party.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to invite.')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player', true);

        const party = await prisma.party.findFirst({
            where: {
                leader: interaction.user.id
            }
        });
        if (!party) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> You must be a party leader to run this command!',
            });
        }

        if (!party.members.includes(player.id)) {
            return await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> ${player} is not in your party!`,
            });
        }

        if (player.id === interaction.user.id) {
            return await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> You cannot kick yourself from your own party!`,
            });
        }

        await prisma.party.update({
            where: {
                id: party.id
            },
            data: {
                members: party.members.filter(member => member !== player.id)
            }
        });

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> Kicked <@${player.id}> from your party!`,
        });
    }
}