import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandSubcommandBuilder, User } from 'discord.js';
import { ChildCommand } from '..';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class PartyInviteCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('invite')
        .setDescription('Invite someone to your party.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to invite.')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player', true);

        const checks = await partyChecks(interaction.user, player);
        if (checks) return await interaction.reply({ content: checks, ephemeral: true });

        await interaction.reply({
            content: `<@${player.id}>`,
            embeds: [
                embeds.normal(
                    `<@${interaction.user.id}> invited you to their party.\nTo accept their invite please click on the Accept button or use \`/party accept ${player.username}\` to join the party. This invite expires <t:${Math.floor(Date.now() / 1000) + 120}:R>.`,
                    'Party Invitation', false
                )
            ],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`${interaction.user.id}-party-invite-accept`)
                        .setLabel('Accept')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId(`${interaction.user.id}-party-invite-decline`)
                        .setLabel('Decline')
                        .setStyle(ButtonStyle.Danger),
                )
            ] as ActionRowBuilder<ButtonBuilder>[]
        });

        const partyMessage = await interaction.fetchReply();
        const newParty = await prisma.party.upsert({
            where: {
                leader: interaction.user.id
            },
            create: {
                leader: interaction.user.id,
                autoWarp: true,
                invites: [player.id]
            },
            update: {
                invites: {
                    push: player.id
                }
            }
        });

        const collector = interaction.channel.createMessageComponentCollector({
            filter: i => (
                i.customId === `${interaction.user.id}-party-invite-accept` ||
                i.customId === `${interaction.user.id}-party-invite-decline`
            )
                && i.user.id === player.id
                && i.message.id === partyMessage.id,
            time: 2 * 60 * 1000,
        });

        collector.on('collect', async i => {
            if (i.customId === `${interaction.user.id}-party-invite-accept`) {
                const checks = await partyChecks(interaction.user, i.user, true);
                if (checks) return await i.reply({ content: checks, ephemeral: true });

                await prisma.party.update({
                    where: {
                        id: newParty.id
                    },
                    data: {
                        members: [...newParty.members, i.user.id]
                    }
                });

                await partyMessage.edit({
                    content: `${interaction.member}`,
                    embeds: [
                        embeds.success(`${i.user} has accepted ${interaction.member}'s party invite!`, '', false)
                    ],
                    components: []
                });

                // Send reply to the person who accepted
                await i.reply({
                    content: `<:rbw_check:1387585062530322443> Joined <@${interaction.user.id}>'s party!`,
                    ephemeral: true
                });

                // Stop the collector since someone accepted
                collector.stop('accepted');
            } else {
                await partyMessage.edit({
                    content: `${interaction.member}`,
                    embeds: [embeds.error(`${i.user} has declined ${interaction.member}'s party invite!`, 'Party Invite', false)],
                    components: []
                });

                // Send reply to the person who declined
                await i.reply({
                    content: `<:rbw_cross:1387585103563063387> You declined <@${interaction.user.id}>'s party invite.`,
                    ephemeral: true
                });

                // Stop the collector since someone declined
                collector.stop('declined');
            }
        });

        collector.on('end', async (collected, reason) => {
            // Only edit the message if it expired without anyone responding
            if (reason === 'time') {
                await prisma.party.update({
                    where: {
                        id: newParty.id
                    },
                    data: {
                        invites: newParty.invites.filter(id => id !== player.id)
                    }
                });

                await partyMessage.edit({
                    content: `${interaction.member}`,
                    embeds: [embeds.error(`Your party invite to ${player} has expired!`, 'Party Invite', false)],
                    components: []
                });
            }
        });
    }
}

export async function partyChecks(
    inviter: User,
    invitee: User,
    isAccepting = false
): Promise<string | null> {
    const settings = await prisma.settings.findFirst();
    if (!settings?.partyEnabled) {
        return '<:rbw_cross:1387585103563063387> Parties are currently disabled!';
    }

    // Must be registered
    const inviterData = await prisma.player.findFirst({ where: { userId: inviter.id } });
    if (!inviterData) {
        return '<:rbw_cross:1387585103563063387> You must be registered to use parties!';
    }

    // No self-invite
    if (inviter.id === invitee.id) {
        return '<:rbw_cross:1387585103563063387> You cannot invite yourself!';
    }

    // Check ignore list (only when sending)
    if (!isAccepting) {
        const inviteeData = await prisma.player.findFirst({ where: { userId: invitee.id } });
        if (inviteeData?.partyIgnoreList.includes(inviter.id)) {
            return '<:rbw_cross:1387585103563063387> You are on their ignore list!';
        }
    }

    // Find existing party for inviter (leader) or invitee (any)
    const inviterParty = await prisma.party.findFirst({
        where: {
            OR: [
                { leader: inviter.id },
                { members: { has: inviter.id } }
            ]
        }
    });
    const inviteeParty = await prisma.party.findFirst({
        where: {
            OR: [
                { leader: invitee.id },
                { members: { has: invitee.id } }
            ]
        }
    });

    if (isAccepting) {
        // Only the original leader can be accepted from
        if (!inviterParty || inviterParty.leader !== inviter.id) {
            return '<:rbw_cross:1387585103563063387> Party no longer exists!';
        }
        if (!inviterParty.invites.includes(invitee.id)) {
            return '<:rbw_cross:1387585103563063387> No active invite found!';
        }
    } else {
        // 1) Inviter must either not be in a party, or if they are, must be the leader
        if (inviterParty && inviterParty.leader !== inviter.id) {
            return '<:rbw_cross:1387585103563063387> You must be the party leader to invite!';
        }
        // 2) Invitee must not already be in any party
        if (inviteeParty) {
            return '<:rbw_cross:1387585103563063387> That user is already in a party!';
        }
        // 3) No duplicate pending invite
        if (inviterParty?.invites.includes(invitee.id)) {
            return '<:rbw_cross:1387585103563063387> You have already invited this user!';
        }
        // 4) After this invite, party size (leader + members) cannot exceed settings.partySize
        const currentMembers = inviterParty ? inviterParty.members.length : 0;
        // members excludes the leader, so max members = partySize - 1
        if (currentMembers >= settings.partySize - 1) {
            return `<:rbw_cross:1387585103563063387> Party is full (max ${settings.partySize}).`;
        }
    }

    return null;
}