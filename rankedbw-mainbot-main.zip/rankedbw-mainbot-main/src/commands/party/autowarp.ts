import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import { prisma } from '@common/database/connectors/prisma';

export default class PartyAutoWarpCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('autowarp')
        .setDescription('Toggle party autowarp status.')

    async execute(interaction: ChatInputCommandInteraction) {
        const party = await prisma.party.findFirst({
            where: {
                leader: interaction.user.id
            }
        });

        if (!party) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> You must be a party leader to run this command!',
            });
        }

        await prisma.party.update({
            where: {
                id: party.id
            },
            data: {
                autoWarp: !party.autoWarp
            }
        });

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> You have ${party.autoWarp ? 'disabled' : 'enabled'} party autowarp!`,
        });
    }
}