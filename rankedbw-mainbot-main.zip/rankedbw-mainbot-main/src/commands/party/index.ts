export default {
    name: 'Party',
    description: 'Party commands.',
}