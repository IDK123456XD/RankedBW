import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import App from '../..';
import { prisma } from '@common/database/connectors/prisma';
import { GameStatus } from '@common/database/generated';

export default class PartyDisbandCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('disband')
        .setDescription('Disband your party.')

    async execute(interaction: ChatInputCommandInteraction) {
        const party = await prisma.party.findFirst({
            where: {
                leader: interaction.user.id
            }
        });
        if (!party) {
            return await interaction.reply({
                embeds: [embeds.error('You must be a party leader to run this command!')],
                ephemeral: true
            });
        }

        // Check if any party members are in queue channels and move them to waiting room
        const queueChannels = [
            settings.voiceChannels.queue1,
            settings.voiceChannels.queue2,
            settings.voiceChannels.queue3,
            settings.voiceChannels.queue4,
            settings.voiceChannels.queue5
        ];

        const movedMembers = [];

        for (const memberId of party.members) {
            const inGame = await prisma.game.findFirst({
                where: {
                    status: GameStatus.PENDING,
                    players: {
                        some: {
                            user: {
                                userId: memberId
                            }
                        }
                    }
                }
            });
            if (inGame) continue;

            try {
                const member = await interaction.guild.members.fetch(memberId);
                if (member.voice.channel && queueChannels.includes(member.voice.channelId)) {
                    await App.Redis.publish('queue:move', JSON.stringify({
                        memberId: member.id,
                        channelId: settings.voiceChannels.waitingRoom,
                        guildId: settings.guild
                    }));
                    movedMembers.push(member);
                }
            } catch (error) {
                // Continue if member fetch fails
            }
        }

        // Send alert if members were moved from queue
        if (movedMembers.length > 0) {
            const alertsChannel = await interaction.guild.channels.fetch(settings.channels.alerts);
            if (alertsChannel && alertsChannel.isTextBased()) {
                await alertsChannel.send({
                    content: `${movedMembers.map(m => m.toString()).join(' ')} You have been removed from the queue because your party has been disbanded.`
                });
            }
        }

        await prisma.party.delete({
            where: {
                id: party.id
            }
        });

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> You have disbanded your party!`,
        });
    }
}