import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import PartyInviteCommand from './invite';
import PartyKickCommand from './kick';
import PartyDisbandCommand from './disband';
import PartyDisbandAllCommand from './disbandall';
import PartyTransferCommand from './promote';
import PartyListCommand from './list';
import PartyAutoWarpCommand from './autowarp';
import PartyWarpCommand from './warp';
import PartyIgnoreCommand from './ignore';
import PartyLeaveCommand from './leave';
import PartyInvitesCommand from './invites';
import PartyAcceptCommand from './accept';

export default class PartyCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('party')
        .setDescription('Run party commands.')

    childCommands: ChildCommand[] = [
        new PartyInviteCommand(),
        new PartyKickCommand(),
        new PartyDisbandCommand(),
        new PartyDisbandAllCommand(),
        new PartyTransferCommand(),
        new PartyListCommand(),
        new PartyAutoWarpCommand(),
        new PartyWarpCommand(),
        new PartyIgnoreCommand(),
        new PartyLeaveCommand(),
        new PartyInvitesCommand(),
        new PartyAcceptCommand()
    ];
}