import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import embeds from '../../utils/discord/embeds';
import { getSettingsDocument } from '../../utils/settings';
import { prisma } from '@common/database/connectors/prisma';

export default class PartyInvitesCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('invites')
        .setDescription('Shows a list of the current pending invites to the party you are in.')

    async execute(interaction: ChatInputCommandInteraction) {
        const dbSettings = await getSettingsDocument();

        if (!dbSettings.partyEnabled) {
            await interaction.reply({
                embeds: [embeds.error('Parties are currently disabled!', 'Party System')],
                ephemeral: true
            });

            return;
        }

        const party = await prisma.party.findFirst({
            where: {
                OR: [
                    {
                        leader: interaction.user.id
                    },
                    {
                        members: {
                            has: interaction.user.id
                        }
                    }
                ]
            }
        });
        if (!party) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> You are not in a party!',
            });
        }

        const invitesList = party.invites && party.invites.length > 0
            ? party.invites.map(x => `- <@${x}>`).join('\n')
            : 'No pending invites';

        await interaction.reply({
            embeds: [embeds.normal(invitesList, 'Party Invites')],
        });
    }
}