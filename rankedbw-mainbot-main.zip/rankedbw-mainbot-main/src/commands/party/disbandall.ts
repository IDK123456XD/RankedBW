import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import sendLogs from '../../utils/logs';
import App from '../..';
import { prisma } from '@common/database/connectors/prisma';
import { GameStatus } from '@common/database/generated';

export default class PartyDisbandAllCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('disbandall')
        .setDescription('Disband all parties.')

    requiredRoles: string[] = [
        settings.roles.administrator,
        settings.roles.owner,
        settings.roles.developer
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply();

        try {
            const parties = await prisma.party.findMany();

            if (parties.length === 0) {
                return await interaction.editReply({
                    embeds: [embeds.normal('No parties found to disband.', 'Party Disband All')]
                });
            }

            const disbandedParties = [];
            const allMovedMembers = [];

            // Voice channels to check for queue members
const queueChannels = [
    settings.voiceChannels.queue1,
    settings.voiceChannels.queue2,
    settings.voiceChannels.queue3,
    settings.voiceChannels.queue4,
    settings.voiceChannels.queue5,
    settings.voiceChannels.queue6
];            // Process each party
            for (const party of parties) {
                if (!party) continue;

                // Check if any party members are in queue channels and move them to waiting room
                const partyMovedMembers = [];

                for (const memberId of [party.leader, ...party.members]) {
                    const inGame = await prisma.game.findFirst({
                        where: {
                            status: GameStatus.PENDING,
                            players: {
                                some: {
                                    user: {
                                        userId: memberId
                                    }
                                }
                            }
                        }
                    });
                    if (inGame) continue;

                    try {
                        const member = await interaction.guild.members.fetch(memberId);
                        if (member.voice.channel && queueChannels.includes(member.voice.channelId)) {
                            await App.Redis.publish('queue:move', JSON.stringify({
                                memberId: member.id,
                                channelId: settings.voiceChannels.waitingRoom,
                                guildId: settings.guild
                            }));
                            partyMovedMembers.push(member);
                            allMovedMembers.push(member);
                        }
                    } catch (error) {
                        // Continue if member fetch fails
                    }
                }

                // Disband the party
                await prisma.party.delete({
                    where: {
                        id: party.id
                    }
                });

                disbandedParties.push({
                    leader: party.leader,
                    memberCount: party.members.length + 1, // +1 for leader
                    movedFromQueue: partyMovedMembers.length
                });
            }

            // Send alert to members who were moved from queue
            if (allMovedMembers.length > 0) {
                const alertsChannel = await interaction.guild.channels.fetch(settings.channels.alerts);
                if (alertsChannel && alertsChannel.isTextBased()) {
                    await alertsChannel.send({
                        content: `${allMovedMembers.map(m => m.toString()).join(' ')} You have been removed from the queue because all parties have been disbanded by an administrator.`
                    });
                }
            }

            // Create summary embed
            const totalMembers = disbandedParties.reduce((sum, party) => sum + party.memberCount, 0);
            const totalMovedFromQueue = allMovedMembers.length;

            let description = `Successfully disbanded **${disbandedParties.length}** parties affecting **${totalMembers}** total members.`;

            if (totalMovedFromQueue > 0) {
                description += `\n\n**${totalMovedFromQueue}** members were moved from queue channels to the waiting room.`;
            }

            // Log the action
            await sendLogs(
                `**${interaction.user.username}** disbanded all parties`,
                'Mass Party Disband',
                undefined,
                undefined,
                [
                    { name: 'Parties Disbanded', value: disbandedParties.length.toString(), inline: true },
                    { name: 'Total Members Affected', value: totalMembers.toString(), inline: true },
                    { name: 'Members Moved from Queue', value: totalMovedFromQueue.toString(), inline: true }
                ]
            );

            await interaction.editReply({
                embeds: [embeds.success(description, 'All Parties Disbanded')]
            });

        } catch (error) {
            console.error('Error in disbandall command:', error);
            await interaction.editReply({
                embeds: [embeds.error('An error occurred while disbanding parties. Please try again.')]
            });
        }
    }
} 