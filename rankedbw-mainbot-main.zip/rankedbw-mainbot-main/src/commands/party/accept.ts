import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import { partyChecks } from './invite';
import { prisma } from '@common/database/connectors/prisma';
import _ from 'lodash';

export default class PartyAcceptCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('accept')
        .setDescription('Accept a players party invite.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to accept the invite from.')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player', true);

        const checks = await partyChecks(player, interaction.user, true);
        if (checks) return await interaction.reply({ content: checks, ephemeral: true });

        const party = await prisma.party.findFirst({
            where: {
                invites: {
                    has: player.id
                }
            }
        });

        if (!party) {
            return await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> ${player.username} has not invited you to their party!`,
            });
        }

        await prisma.party.update({
            where: {
                id: party.id
            },
            data: {
                members: _.uniq([...party.members, interaction.user.id]),
                invites: party.invites.filter(id => id !== player.id)
            }
        });

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> Joined ${player.username}'s party!`,
        });
    }
}
