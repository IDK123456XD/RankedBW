import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class PartyListCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('List the players of your party.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to list the party of.')
                .setRequired(false)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player');

        await interaction.deferReply();

        const userId = player?.id ?? interaction.user.id;
        const party = await prisma.party.findFirst({
            where: {
                OR: [
                    {
                        leader: userId
                    },
                    {
                        members: {
                            has: userId
                        }
                    }
                ]
            }
        });

        if (!party && !player) {
            return await interaction.editReply({
                content: '<:rbw_cross:1387585103563063387> You must be in a party to run this command!',
            });
        } else if (!party) {
            return await interaction.editReply({
                embeds: [embeds.error(`${player} is not in a party!`)],
            });
        }

        const settingsDoc = await prisma.settings.findFirst();
        const idleTime = party.lastVcJoin ? (Date.now() - new Date(party.lastVcJoin).getTime()).timeFormat() : 'N/A';

        await interaction.editReply({
            embeds: [embeds.normal(
                `**Created At**: <t:${Math.round(new Date(party.createdAt).getTime() / 1000)}>\n` +
                `**Idle Time**: ${idleTime}\n` +
                `**Auto Warp**: \`${party.autoWarp ? 'On' : 'Off'}\`\n` +
                `**Leader**: <@${party.leader}>\n` +
                `**Members** [\`${party.members.length + 1}\`/\`${settingsDoc.partySize}\`]:\n- <@${party.leader}>\n${party.members.map(member => `- <@${member}>`).join('\n')}`,
                'Party System'
            )],
        });
    }
}