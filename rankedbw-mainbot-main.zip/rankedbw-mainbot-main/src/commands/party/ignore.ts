import { ChatInputCommandInteraction, MessageFlags, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import { prisma } from '@common/database/connectors/prisma';

export default class PartyIgnoreCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('ignore')
        .setDescription('Ignore a players party invites.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to ignore.')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player', true);

        const userData = await prisma.player.findFirst({
            where: {
                userId: interaction.user.id
            }
        });

        if (!userData) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> You must be registered to use this command!',
                flags: MessageFlags.Ephemeral,
            });
        }

        await prisma.player.update({
            where: {
                userId: interaction.user.id
            },
            data: {
                partyIgnoreList: userData.partyIgnoreList.includes(player.id) ? userData.partyIgnoreList.filter(x => x !== player.id) : [...userData.partyIgnoreList, player.id]
            }
        })

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> ${userData.partyIgnoreList.includes(player.id) ? `You are now ignoring party invites from ${player}!` : `You are no longer ignoring party invites from ${player}!`}`,
            flags: MessageFlags.Ephemeral,
        });
    }
}