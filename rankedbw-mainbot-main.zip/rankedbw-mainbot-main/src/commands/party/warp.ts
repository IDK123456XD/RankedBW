import { ChatInputCommandInteraction, GuildMember, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import App from '../..';
import { prisma } from '@common/database/connectors/prisma';

export default class PartyWarpCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('warp')
        .setDescription('Warp your party members to your voice channel.')

    async execute(interaction: ChatInputCommandInteraction) {
        const party = await prisma.party.findFirst({
            where: {
                leader: interaction.user.id
            }
        });
        if (!party) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> You must be a party leader to run this command!',
            });
        }

        const partyLeaderMember = await interaction.guild.members.fetch(party.leader);
        if (!partyLeaderMember || !partyLeaderMember.voice.channel) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> You must be in a voice channel to run this command!',
            });
        }

        const membersToWarp: GuildMember[] = [];
        for (const userId of party.members) {
            const member = await interaction.guild.members.fetch(userId);
            if (!member || !member.voice.channel) continue;

            membersToWarp.push(member);
        }

        if (!membersToWarp.length) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> There are no party members to warp!',
            });
        }

        await Promise.all(
            membersToWarp.map(async member => {
                await App.Redis.setex(`partyWarp:${member.id}`, 10, 'true');
                
                return App.Redis.publish(
                    "queue:move",
                    JSON.stringify({
                        memberId: member.id,
                        channelId: partyLeaderMember.voice.channel.id,
                        guildId: interaction.guild.id,
                    })
                );
            })
        );

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> Your party has been warped!`,
        });
    }
}