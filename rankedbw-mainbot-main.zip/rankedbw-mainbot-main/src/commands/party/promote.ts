import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import { prisma } from '@common/database/connectors/prisma';
import _ from 'lodash';

export default class PartyPromoteCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('promote')
        .setDescription('Promote a member of your party to party leader.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to promote.')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player', true);

        const party = await prisma.party.findFirst({
            where: {
                leader: interaction.user.id
            }
        });
        if (!party) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> You must be a party leader to run this command!',
            });
        }

        if (player.id === interaction.user.id) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> You cannot promote yourself to party leader!',
            });
        }

        if (!party.members.includes(player.id)) {
            return await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> That player is not in your party!`,
            });
        }

        const updatedMembers = party.members
            .filter(id => id !== player.id)
            .concat(interaction.user.id);

        await prisma.party.update({
            where: {
                id: party.id
            },
            data: {
                leader: player.id,
                members: _.uniq(updatedMembers)
            }
        });

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> Promoted <@${player.id}> to the leader of your party.`,
        });
    }
}