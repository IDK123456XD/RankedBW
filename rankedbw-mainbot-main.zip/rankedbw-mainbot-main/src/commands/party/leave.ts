import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import App from '../..';
import settings from '../../settings';
import { prisma } from '@common/database/connectors/prisma';
import { GameStatus } from '@common/database/generated';

export default class PartyLeaveCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('leave')
        .setDescription('Leave your party.');

    async execute(interaction: ChatInputCommandInteraction) {
        const party = await prisma.party.findFirst({
            where: {
                OR: [
                    {
                        leader: interaction.user.id
                    },
                    {
                        members: {
                            has: interaction.user.id
                        }
                    }
                ]
            }
        });
        if (!party) {
            return await interaction.reply({
                content: '<:rbw_cross:1387585103563063387> You are not part of a party!',
            });
        }

        // Check if any party members are in queue channels and move them to waiting room
        const queueChannels = [
            settings.voiceChannels.queue1,
            settings.voiceChannels.queue2,
            settings.voiceChannels.queue3,
            settings.voiceChannels.queue4,
            settings.voiceChannels.queue5
        ];

        const movedMembers = [];

        for (const memberId of party.members) {
            const inGame = await prisma.game.findFirst({
                where: {
                    status: GameStatus.PENDING,
                    players: {
                        some: {
                            user: {
                                userId: memberId
                            }
                        }
                    }
                }
            });
            if (inGame) continue;

            try {
                const member = await interaction.guild.members.fetch(memberId);
                if (member.voice.channel && queueChannels.includes(member.voice.channelId)) {
                    await App.Redis.publish('queue:move', JSON.stringify({
                        memberId: member.id,
                        channelId: settings.voiceChannels.waitingRoom,
                        guildId: settings.guild
                    }));
                    movedMembers.push(member);
                }
            } catch (error) { }
        }

        if (movedMembers.length > 0) {
            const alertsChannel = await interaction.guild.channels.fetch(settings.channels.alerts);
            if (alertsChannel && alertsChannel.isTextBased()) {
                await alertsChannel.send({
                    content: `${movedMembers.map(m => m.toString()).join(' ')} You have been removed from the queue because someone left the party.`
                });
            }
        }

        if (party.leader === interaction.user.id) {
            await prisma.party.delete({
                where: {
                    id: party.id
                }
            });

            await interaction.reply({
                content: '<:rbw_check:1387585062530322443> You have disbanded your party!',
            });
        } else {
            await prisma.party.update({
                where: {
                    id: party.id
                },
                data: {
                    members: party.members.filter(member => member !== interaction.user.id)
                }
            });

            await interaction.reply({
                content: '<:rbw_check:1387585062530322443> You have left the party!',
            });
        }
    }
}