import { ChatInputCommandInteraction, MessageFlags, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import fs from 'fs';
import embeds from '../../utils/discord/embeds';
import path from 'path';
import { prisma } from '@common/database/connectors/prisma';

export default class RulesCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('rules')
        .setDescription('Show the season ruleset.')

    async execute(interaction: ChatInputCommandInteraction) {
        const settings = await prisma.settings.findFirst();
        if (!settings?.ruleset) {
            return interaction.reply({
                embeds: [embeds.error('No ruleset found.')]
            });
        }

        const season = await prisma.season.findFirst({
            where: {
                active: true
            }
        });

        await interaction.reply({
            embeds: [
                embeds.normal(settings.ruleset, season.name + ' Rules:', false)
            ],
        });
    }
}