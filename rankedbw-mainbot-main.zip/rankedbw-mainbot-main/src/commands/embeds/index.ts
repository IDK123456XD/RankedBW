export default {
    name: 'Embeds',
    description: 'Generate a bunch of different embeds.',
}