import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import HowToRegisterCommand from './howtoregister';
import settings from '../../settings';

export default class EmbedCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('embeds')
        .setDescription('Generate a bunch of different embeds.')

    requiredRoles: string[] = [settings.roles.owner, settings.roles.administrator];

    childCommands: ChildCommand[] = [
        new HowToRegisterCommand(),
    ];
} 