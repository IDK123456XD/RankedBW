import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';

export default class HowToRegisterCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('howtoregister')
        .setDescription('Generate the how to register panels.')

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.channel.send({
            embeds: [
                embeds.normal(
                    '**Link your current Discord Username to your Hypixel Account**\n\n' +
                    `Run the command \`/register (Username)\` in the <#${settings.channels.register}> channel.\n` +
                    '*Changes might take up to a few minutes to take effect.*',
                    'Wondering how to get registered?'
                ).setImage('https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExbDM5eGNlajdzNzh5N2ttNzkxNGhmM3B1ajl0dTZkMzc3bDFnamJxYiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/vzOPo3G826KvydyuwS/giphy.gif')
            ],
        });

        await interaction.reply({
            embeds: [
                embeds.success(
                    'Successfully generated the how to register panels.'
                ),
            ],
            ephemeral: true,
        });
    }
}