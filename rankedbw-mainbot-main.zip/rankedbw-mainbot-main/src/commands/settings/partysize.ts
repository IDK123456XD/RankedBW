import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class PartySizeCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('partysize')
        .setDescription('Change the max party size.')
        .addNumberOption(option =>
            option.setName('party-size')
                .setDescription('Set a party size. (ex. 1, 2, 3, 4)')
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.developer,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const partySize = interaction.options.getNumber('party-size', true);
        const settings = await prisma.settings.findFirst();

        if (settings.partySize === partySize) {
            return await interaction.reply({
                embeds: [embeds.error(`Party size is already set to **${partySize}**.`)],
                ephemeral: true,
            });
        }

        await prisma.settings.update({
            where: {
                id: settings.id
            },
            data: {
                partySize: partySize
            }
        });

        await interaction.reply({
            embeds: [
                embeds.success(`Party size has been set to **${partySize}**.`)
            ],
            ephemeral: true,
        });
    }
}