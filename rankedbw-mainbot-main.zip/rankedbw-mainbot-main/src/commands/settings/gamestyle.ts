import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { getSettingsDocument } from '../../utils/settings';
import { GameStyles } from '@common/database/generated';
import { prisma } from '@common/database/connectors/prisma';

export default class GameStyleCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('gamestyle')
        .setDescription('Change the bedwars queue game style.')
        .addStringOption(option =>
            option.setName('style')
                .setDescription('The style of bedwars.')
                .addChoices(...Object.values(GameStyles).map(style => ({ name: style, value: style })))
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.developer,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const type = interaction.options.getString('style', true) as GameStyles;
        const settings = await getSettingsDocument();

        await prisma.settings.update({
            where: {
                id: settings.id
            },
            data: {
                gameStyle: type,
                teamSize: type === GameStyles.v1v1 ? 1 : type === GameStyles.v2v2 ? 2 : 4
            }
        })

        await interaction.reply({
            embeds: [
                embeds.success(`The bedwars queue game style has been set to \`${type}\`!`, 'Game Style Set')
            ],
            ephemeral: true,
        });
    }
}