import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { getSettingsDocument } from '../../utils/settings';
import { prisma } from '@common/database/connectors/prisma';

export default class ClaimEloSettingsCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('claimelo')
        .setDescription('Toggle claim elo functionality on or off.')
        .addStringOption(option =>
            option.setName('toggle')
                .setDescription('Toggle claim elo on or off.')
                .addChoices(...[
                    { name: 'on', value: 'on' },
                    { name: 'off', value: 'off' }
                ])
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.administrator,
        settings.roles.developer,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const toggle = interaction.options.getString('toggle', true) === 'on' ? true : false;
        const settings = await getSettingsDocument();

        await prisma.settings.update({
            where: {
                id: settings.id
            },
            data: {
                claimEloEnabled: toggle
            }
        });

        await interaction.reply({
            embeds: [
                embeds.success(`Claim ELO functionality has been **${toggle ? 'enabled' : 'disabled'}**.`)
            ],
            ephemeral: true,
        });
    }
} 