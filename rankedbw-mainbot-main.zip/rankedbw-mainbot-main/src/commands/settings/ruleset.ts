import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import axios from 'axios';
import { prisma } from '@common/database/connectors/prisma';

export default class RulesetCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('ruleset')
        .setDescription('Change the bedwars queue ruleset.')
        .addAttachmentOption(option =>
            option.setName('ruleset')
                .setDescription('The ruleset to set.')
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.developer,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const ruleset = interaction.options.getAttachment('ruleset', true);
        const rulesetText = await axios.get(ruleset.url);
        const textData = rulesetText.data.toString();

        const settings = await prisma.settings.findFirst();
        if (!settings) {
            await prisma.settings.create({
                data: {
                    ruleset: textData
                }
            });
        } else {
            await prisma.settings.update({
                where: {
                    id: settings.id
                },
                data: {
                    ruleset: textData
                }
            });
        }

        await interaction.reply({
            embeds: [
                embeds.normal(textData, 'The Ruleset Has Been Set!')
            ],
            ephemeral: true,
        });
    }
}