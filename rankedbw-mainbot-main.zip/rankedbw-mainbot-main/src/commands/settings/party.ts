import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { getSettingsDocument } from '../../utils/settings';
import { prisma } from '@common/database/connectors/prisma';

export default class PartyToggleCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('party')
        .setDescription('Toggle parties on or off.')
        .addStringOption(option =>
            option.setName('toggle')
                .setDescription('Toggle parties on or off.')
                .addChoices(...[
                    { name: 'on', value: 'on' },
                    { name: 'off', value: 'off' }
                ])
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.developer,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const toggle = interaction.options.getString('toggle', true) === 'on' ? true : false;
        const settings = await getSettingsDocument();

        await prisma.settings.update({
            where: {
                id: settings.id
            },
            data: {
                partyEnabled: toggle
            }
        });

        await interaction.reply({
            embeds: [
                embeds.success(`Parties have been **${toggle ? 'enabled' : 'disabled'}**.`)
            ],
            ephemeral: true,
        });
    }
}