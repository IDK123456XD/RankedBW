import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { getHypixelPlayerData } from '../../utils/hypixel';
import { getUUID } from '../../utils/minecraft';
import { getSettingsDocument } from '../../utils/settings';
import { prisma } from '@common/database/connectors/prisma';

export default class HypixelApiKeyCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('hypixelapikey')
        .setDescription('Change the current Hypixel API key.')
        .addStringOption(option =>
            option.setName('key')
                .setDescription('Set the current API key.')
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.developer,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const key = interaction.options.getString('key', true);
        const settings = await getSettingsDocument();

        await prisma.settings.update({
            where: {
                id: settings.id
            },
            data: {
                hypixelAPIKey: key
            }
        })

        await interaction.reply({
            embeds: [
                embeds.success(`The Hypixel API key has been set to ||\`${key}\`||!`, 'API Key Set')
            ],
            ephemeral: true,
        });
    }
}