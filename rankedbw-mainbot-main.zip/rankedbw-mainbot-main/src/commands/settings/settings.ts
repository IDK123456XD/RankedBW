import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import PartySizeCommand from './partysize';
import PartyToggleCommand from './party';
import GameStyleCommand from './gamestyle';
import HypixelApiKeyCommand from './hypixelapikey';
import PickingCommand from './picking';
import RulesetCommand from './ruleset';
import ClaimEloSettingsCommand from './claimelo';

export default class SettingsCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('settings')
        .setDescription('Change Ranked Bedwars settings.')

    childCommands: ChildCommand[] = [
        new PartySizeCommand(),
        new PartyToggleCommand(),
        new GameStyleCommand(),
        new HypixelApiKeyCommand(),
        new PickingCommand(),
        new RulesetCommand(),
        new ClaimEloSettingsCommand(),
    ];
} 