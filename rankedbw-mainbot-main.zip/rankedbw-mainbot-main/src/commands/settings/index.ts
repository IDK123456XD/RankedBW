export default {
    name: 'Settings',
    description: 'Change Ranked Bedwars settings.',
}