import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { getSettingsDocument } from '../../utils/settings';
import { PickingTypes } from '@common/database/generated';
import { prisma } from '@common/database/connectors/prisma';

export default class PickingCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('picking')
        .setDescription('Change the way picking players in queue works.')
        .addStringOption(option =>
            option.setName('pick-type')
                .setDescription('Select the picking phase setup.')
                .addChoices(...[
                    { name: 'Random', value: 'random' },
                    { name: '1 1 1 1', value: '1' },
                    { name: '1 2 2 1', value: '2' },
                ])
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.developer,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const pickType = interaction.options.getString('pick-type', true);

        const settings = await getSettingsDocument();
        const newPickingType = pickType === '1' ? PickingTypes.one : pickType === '2' ? PickingTypes.two : PickingTypes.random;
        if (settings.pickingType === newPickingType) {
            interaction.reply({
                embeds: [
                    embeds.error(`The picking sequence is already set to **${newPickingType}**.`)
                ],
                ephemeral: true,
            });
            return;
        }

        await prisma.settings.update({
            where: {
                id: settings.id
            },
            data: {
                pickingType: newPickingType
            }
        });

        await interaction.reply({
            embeds: [
                embeds.success(`The picking sequence has been set to **${newPickingType}**.`)
            ],
            ephemeral: true,
        });
    }
}