export default {
    name: 'PUGS Spec',
    description: 'Run PUGS Spec commands.',
}