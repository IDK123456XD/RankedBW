import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import PugsSpecAddCommand from './add';
import PugsSpecRemoveCommand from './remove';

export default class PugsSpecCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('pugsspec')
        .setDescription('Run PUGS Spec commands.')

    childCommands: ChildCommand[] = [
        new PugsSpecAddCommand(),
        new PugsSpecRemoveCommand()
    ];
}