export default {
    name: 'PUGS Trial',
    description: 'Run PUGS Trial commands.',
}