import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import PugsTrialAddCommand from './add';
import PugsTrialRemoveCommand from './remove';

export default class PugsTrialCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('pugstrial')
        .setDescription('Run PUGS Trial commands.')

    childCommands: ChildCommand[] = [
        new PugsTrialAddCommand(),
        new PugsTrialRemoveCommand()
    ];
}