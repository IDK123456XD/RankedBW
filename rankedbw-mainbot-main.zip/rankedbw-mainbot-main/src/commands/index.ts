import {
  AutocompleteInteraction,
  ChatInputCommandInteraction,
  MessageFlags,
  SlashCommandBuilder,
  SlashCommandOptionsOnlyBuilder,
  SlashCommandSubcommandBuilder,
  SlashCommandSubcommandsOnlyBuilder,
} from "discord.js";
import embeds from "../utils/discord/embeds";


export type AllCommandTypes = Command | ParentCommand | ChildCommand;

export abstract class ParentCommand {
  abstract slashCommand: SlashCommandBuilder;
  abstract childCommands: ChildCommand[];
  requiredRoles: string[] = [];

  async canRun(interaction: ChatInputCommandInteraction | AutocompleteInteraction) {
    if (this.requiredRoles.length > 0) {
      const member = await interaction.guild.members.fetch(interaction.user.id);
      if (!member) return false;

      if (this.requiredRoles.some((x) => member.roles.cache.has(x))) return true;

      if (interaction instanceof ChatInputCommandInteraction) {
        await interaction.reply({
          embeds: [
            embeds.error(
              `You must have one of the following roles to run this command:\n${this.requiredRoles.map((x) => `<@&${x}>`).join('\n')}`,
              ``,
              false
            )
          ],
          flags: [MessageFlags.Ephemeral]
        });
      }

      return false;
    }

    return true;
  }
}

export abstract class ChildCommand {
  abstract slashCommand: SlashCommandSubcommandBuilder;
  maintenance: boolean = false;
  requiredRoles: string[] = [];

  async canRun(interaction: ChatInputCommandInteraction | AutocompleteInteraction) {
    if (this.requiredRoles.length > 0) {
      const member = await interaction.guild.members.fetch(interaction.user.id);
      if (!member) return false;

      if (this.requiredRoles.some((x) => member.roles.cache.has(x))) return true;

      if (interaction instanceof ChatInputCommandInteraction) {
        await interaction.reply({
          embeds: [
            embeds.error(
              `You must have one of the following roles to run this command:\n${this.requiredRoles.map((x) => `<@&${x}>`).join('\n')}`,
              ``,
              false
            )
          ],
          flags: [MessageFlags.Ephemeral]
        });
      }

      return false;
    }

    return true;
  }

  abstract execute(
    _interaction: ChatInputCommandInteraction
  ): Promise<any>;

  async autocomplete(
    _interaction: AutocompleteInteraction
  ): Promise<void> {
    return;
  }
}

export abstract class Command {
  abstract slashCommand:
    | SlashCommandBuilder
    | SlashCommandOptionsOnlyBuilder
    | SlashCommandSubcommandsOnlyBuilder
    | Omit<SlashCommandBuilder, "addSubcommand" | "addSubcommandGroup">;
  maintenance: boolean = false;
  requiredRoles: string[] = [];

  async canRun(interaction: ChatInputCommandInteraction | AutocompleteInteraction) {
    if (this.requiredRoles.length > 0) {
      const member = await interaction.guild.members.fetch(interaction.user.id);
      if (!member) return false;

      if (this.requiredRoles.some((x) => member.roles.cache.has(x))) return true;

      if (interaction instanceof ChatInputCommandInteraction) {
        await interaction.reply({
          embeds: [
            embeds.error(
              `You must have one of the following roles to run this command:\n${this.requiredRoles.map((x) => `<@&${x}>`).join('\n')}`,
              ``,
              false
            )
          ],
          flags: [MessageFlags.Ephemeral]
        });
      }

      return false;
    }

    return true;
  }

  abstract execute(
    _interaction: ChatInputCommandInteraction
  ): Promise<any>;

  async autocomplete(
    _interaction: AutocompleteInteraction
  ): Promise<void> {
    return;
  }
}