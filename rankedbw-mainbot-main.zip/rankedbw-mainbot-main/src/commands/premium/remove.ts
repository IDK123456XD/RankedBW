import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';

export default class PremiumRemoveCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Remove a player from the premium role.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The discord user you want to remove.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for removing the player from Premium.')
                .setRequired(false)
        )

    requiredRoles: string[] = [settings.roles.premiumManager, settings.roles.administrator, settings.roles.owner];

    async execute(interaction: ChatInputCommandInteraction) {
        const discordUser = interaction.options.getUser('discord-user');
        const reason = interaction.options.getString('reason');

        const premiumRole = await interaction.guild.roles.fetch(settings.roles.premium);
        if (!premiumRole) {
            interaction.reply({
                embeds: [embeds.error('Premium role not found.')],
                ephemeral: true,
            });
            return;
        }

        const member = await interaction.guild.members.fetch(discordUser.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not found as a member in this guild.`)],
                ephemeral: true,
            });
            return;
        }

        if (!member.roles.cache.has(premiumRole.id)) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not part of the premium role.`)],
                ephemeral: true,
            });
            return;
        }

        await member.roles.remove(premiumRole);
        
        // Log to premium logs channel
        const premiumLogsChannel = await interaction.guild.channels.fetch(settings.channels.premiumLogs);
        if (premiumLogsChannel && premiumLogsChannel.isTextBased()) {
            const logMessage = `${interaction.user} has removed ${discordUser} from PREMIUM.${reason ? `\n**Reason:** ${reason}` : ''}`;
            await premiumLogsChannel.send({
                embeds: [embeds.error(logMessage, 'Premium Role Removed', false)]
            });
        }

        await interaction.reply({
            content: `${discordUser} has been removed from PREMIUM.`,
        });
    }
}