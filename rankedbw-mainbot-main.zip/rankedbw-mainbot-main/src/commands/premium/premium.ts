import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import PremiumAddCommand from './add';
import PremiumRemoveCommand from './remove';
import PremiumListCommand from './list';

export default class PremiumCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('premium')
        .setDescription('Run premium commands.')

    childCommands: ChildCommand[] = [
        new PremiumAddCommand(),
        new PremiumRemoveCommand(),
        new PremiumListCommand()
    ];
} 