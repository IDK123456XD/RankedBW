import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import Paginator from '../../utils/discord/paginator';
import { prisma } from '@common/database/connectors/prisma';

export default class PremiumListCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('List all of the premium players.')

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply();

        try {
            const guild = await interaction.guild.fetch();
            const premiumRole = await guild.roles.fetch(settings.roles.premium);
            const premiumManagerRole = await guild.roles.fetch(settings.roles.premiumManager);

            if (!premiumRole) {
                await interaction.editReply({
                    embeds: [embeds.error('Premium role not found.')],
                });
                return;
            }

            if (!premiumManagerRole) {
                await interaction.editReply({
                    embeds: [embeds.error('Premium Manager role not found.')],
                });
                return;
            }

            // Fetch guild members to populate the cache
            await guild.members.fetch();

            // Get managers and regular members
            const premiumManagers = Array.from(premiumManagerRole.members.values());
            const premiumPlayers = Array.from(premiumRole.members.values());

            // Filter out managers from regular members list to avoid duplicates
            const managerIds = new Set(premiumManagers.map(m => m.id));
            const filteredPremiumPlayers = premiumPlayers.filter(player => !managerIds.has(player.id));

            // Build the member list with hierarchy
            let membersList = '';

            // Add managers section
            if (premiumManagers.length > 0) {
                membersList += `**Premium Managers (${premiumManagers.length}):**\n`;
                for (const manager of premiumManagers) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: manager.id }
                    });
                    membersList += `${manager} | \`${playerData?.minecraftName || manager.user.username}\`\n`;
                }
                membersList += '\n';
            }

            // Add regular members section (excluding managers)
            if (filteredPremiumPlayers.length > 0) {
                membersList += `**Premium Members (${filteredPremiumPlayers.length}):**\n`;
                for (const player of filteredPremiumPlayers) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: player.id }
                    });
                    membersList += `${player} | \`${playerData?.minecraftName || player.user.username}\`\n`;
                }
            }

            if (!membersList.trim()) {
                await interaction.editReply({
                    embeds: [embeds.error('No premium players found.')],
                });
                return;
            }

            // Split the content for pagination
            const lines = membersList.trim().split('\n');
            const totalPages = Math.ceil(lines.length / 30);

            if (totalPages <= 1) {
                // Single page, no pagination needed
                await interaction.editReply({
                    embeds: [embeds.normal(membersList, 'Premium List', false)]
                });
            } else {
                // Multiple pages, use pagination
                await new Paginator(interaction, totalPages, async (pageIndex) => {
                    const pageLines = lines.slice(pageIndex * 30, (pageIndex + 1) * 30);

                    return embeds.normal(
                        pageLines.join('\n'),
                        'Premium List', false
                    );
                }, 0, false, false).start()
            }
        } catch (error) {
            console.error('Error fetching Premium members:', error);
            await interaction.editReply({
                embeds: [embeds.error('Failed to fetch Premium members. Please try again.')],
            });
        }
    }
}