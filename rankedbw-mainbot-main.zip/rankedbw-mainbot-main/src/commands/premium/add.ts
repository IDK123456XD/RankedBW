import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class PremiumAddCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Add a player to the premium role.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The discord user you want to add.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for adding the player to Premium.')
                .setRequired(false)
        )
        .addBooleanOption(option =>
            option.setName('announce')
                .setDescription('Whether to post an announcement about this addition.')
                .setRequired(false)
        )

    requiredRoles: string[] = [
        settings.roles.premiumManager,
        settings.roles.administrator,
        settings.roles.owner,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const discordUser = interaction.options.getUser('discord-user');
        const reason = interaction.options.getString('reason');
        const announce = interaction.options.getBoolean('announce') ?? false;

        const premiumRole = await interaction.guild.roles.fetch(settings.roles.premium);
        if (!premiumRole) {
            interaction.reply({
                embeds: [embeds.error('Premium role not found.')],
                ephemeral: true,
            });
            return;
        }

        const member = await interaction.guild.members.fetch(discordUser.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not found as a member in this guild.`)],
                ephemeral: true,
            });
            return;
        }

        if (member.roles.cache.has(premiumRole.id)) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is already in the premium role.`)],
                ephemeral: true,
            });
            return;
        }

        await member.roles.add(premiumRole);

        // Post announcement if requested
        if (announce) {
            const premiumAnnouncements = await interaction.guild.channels.fetch(settings.channels.premiumAnnouncements);
            if (premiumAnnouncements && premiumAnnouncements.isTextBased()) {
                const player = await prisma.player.findFirst({
                    where: {
                        userId: discordUser.id
                    }
                });

                await premiumAnnouncements.send({
                    content: `${discordUser}`,
                    embeds: [
                        embeds.success(
                            `:tada: Congratulations ${discordUser}` +
                            (player ? ` (\`${player.minecraftName}\`)!` : '!') +
                            ' You have been accepted into Premium.',
                            'Premium Role Added',
                            false
                        )
                    ],
                });
            }
        }

        // Log to premium logs channel
        const premiumLogsChannel = await interaction.guild.channels.fetch(settings.channels.premiumLogs);
        if (premiumLogsChannel && premiumLogsChannel.isTextBased()) {
            const logMessage = `${interaction.user} has added ${discordUser} to PREMIUM.${reason ? `\n**Reason:** ${reason}` : ''}`;
            await premiumLogsChannel.send({
                embeds: [embeds.success(logMessage, 'Premium Role Added', false)]
            });
        }

        await interaction.reply({
            content: `${discordUser} has been added to PREMIUM.`,
        });
    }
}