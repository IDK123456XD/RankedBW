export default {
    name: 'Premium',
    description: 'Run premium commands.',
}