import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings, { ELO_DATA } from "../../settings";
import embeds from "../../utils/discord/embeds";
import sendLogs from "../../utils/logs";
import { prisma } from "@common/database/connectors/prisma";
import App from "../..";

export default class UnregisterCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName("unregister")
        .setDescription("Unregister a player from Rank Bedwars")
        .addStringOption((option) =>
            option
                .setName("discord-id")
                .setDescription("The discord id you want to unregister.")
                .setRequired(true)
        );

    requiredRoles: string[] = [settings.roles.seniorModerator, settings.roles.developer, settings.roles.administrator, settings.roles.owner];

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply();

        const discordId = interaction.options.getString("discord-id");
        if (!discordId) {
            await interaction.editReply({
                embeds: [
                    embeds.error("The Discord ID you provided is invalid!", "Registration"),
                ],
            });
            return;
        }

        const player = await prisma.player.findUnique({
            where: {
                userId: discordId,
            },
        });

        if (!player) {
            await interaction.editReply({
                embeds: [
                    embeds.error("That user is not registered!", "Registration"),
                ],
            });
            return;
        }

        try {
            const member = await interaction.guild.members.fetch(
                player.userId
            );

            if (member) {
                if (member.roles.cache.has(settings.roles.registered)) {
                    await App.Redis.publish(
                        "change:role",
                        JSON.stringify({
                            memberId: member.id,
                            roleId: settings.roles.registered,
                            guildId: settings.guild,
                            action: "remove",
                        })
                    );
                }

                // Remove all ELO rank roles
                const rankRoleIds = ELO_DATA.map((rank) => rank.roleId);
                for (const roleId of rankRoleIds) {
                    if (member.roles.cache.has(roleId)) {
                        await App.Redis.publish(
                            "change:role",
                            JSON.stringify({
                                memberId: member.id,
                                roleId: roleId,
                                guildId: settings.guild,
                                action: "remove",
                            })
                        );
                    }
                }

                // Reset nickname if it was set by the bot (starts with [ELO])
                if (
                    member.nickname?.startsWith("[") &&
                    member.nickname.includes("] ")
                ) {
                    await App.Redis.publish(
                        "change:nickname",
                        JSON.stringify({
                            memberId: member.id,
                            nickname: null,
                            guildId: interaction.guild.id,
                        })
                    );
                }
            }
        } catch { }

        await sendLogs(
            `Minecraft account **${player.minecraftName}** (UUID: ${player.uuid}) has been unregistered from Discord user <@${player.userId}> by ${interaction.user}.`,
            "Unregistration"
        );

        await prisma.player.delete({
            where: {
                id: player.id,
            },
        });

        await interaction.editReply({
            embeds: [
                embeds.success("Player unregistered successfully!", "Unregistration"),
            ],
        });
    }
}
