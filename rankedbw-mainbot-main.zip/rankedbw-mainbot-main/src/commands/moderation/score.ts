import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import { GameHandler } from "../../utils/gameHandler";

export default class ScoreCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("score")
    .setDescription("Score a game.")
    .addStringOption((option) =>
      option
        .setName("gameid")
        .setDescription("The game to score.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("winningteam")
        .setDescription("The winning team (1 or 2).")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option.setName("reason").setDescription("The reason for the score.").setRequired(true)
    )
    .addUserOption((option) =>
      option.setName("mvp1").setDescription("The mvps.").setRequired(true)
    )
    .addUserOption((option) =>
      option.setName("mvp2").setDescription("The loser.").setRequired(false)
    )
    .addUserOption((option) =>
      option.setName("mvp3").setDescription("The loser.").setRequired(false)
    );

  requiredRoles: string[] = [settings.roles.helper, settings.roles.moderator, settings.roles.seniorModerator, settings.roles.administrator, settings.roles.owner];

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();

    const gameId = interaction.options.getString("gameid", true);
    const winningTeam = interaction.options.getString("winningteam", true);
    const reason = interaction.options.getString("reason", true);

    const mvpIds = [
      interaction.options.getUser("mvp1", true).id,
      interaction.options.getUser("mvp2", false)?.id,
      interaction.options.getUser("mvp3", false)?.id
    ].filter(x => !!x) as string[];

    const result = await GameHandler.scoreGame(gameId, interaction.guild, parseInt(winningTeam), mvpIds, interaction.user.id, true, reason);

    await interaction.editReply({
      content: result,
    });
  }
}
