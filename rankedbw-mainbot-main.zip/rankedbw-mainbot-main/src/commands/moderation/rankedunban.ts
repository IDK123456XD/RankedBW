import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';
import { PunishmentType } from '@common/database/generated';

export default class RankedUnbanCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('rankedunban')
        .setDescription('Unban a player from ranked.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to punishment.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('The reason for the punishment.')
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.administrator,
        settings.roles.seniorModerator,
        settings.roles.moderator,
        settings.roles.screenshareManager,
        settings.roles.ssAppeals,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player');
        const reason = interaction.options.getString('reason');

        const member = await interaction.guild.members.fetch(player.id);
        if (!member) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> Please provide a valid player.`,
            });
            return;
        }

        if (!member.roles.cache.has(settings.roles.rankedBan)) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> This player is not currently banned from ranked.`,
            });
            return;
        }

        const playerData = await prisma.player.findFirst({
            where: {
                userId: player.id
            }
        });
        if (!playerData) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> This player does not exist in our database.`,
            });
            return;
        }

        await member.roles.remove(settings.roles.rankedBan);

        const punishment = await prisma.punishment.create({
            data: {
                type: PunishmentType.rankedunban,
                reason,
                staff: interaction.user.id,
                expired: false,
                Player: {
                    connect: {
                        id: playerData.id
                    }
                }
            }
        });

        await prisma.player.update({
            where: {
                id: playerData.id
            },
            data: {
                leftRoleIds: {
                    set: playerData.leftRoleIds.filter(roleId => roleId !== settings.roles.rankedBan)
                }
            }
        });

        const logChannel = await interaction.guild.channels.fetch(settings.channels.punishmentLogs);
        if (logChannel && logChannel.isTextBased()) {
            await logChannel.send({
                embeds: [
                    embeds.normal(
                        `${player} has been unbanned from ranked for **${reason}**.`,
                        'Ranked Unban Issued',
                        false
                    ).addFields([
                        { name: 'User', value: `${player}`, inline: true },
                        { name: 'Moderator', value: `${interaction.user}`, inline: true },
                        { name: 'Reason', value: `\`${reason}\``, inline: true },
                    ])
                ]
            });
        }

        const punishments = await interaction.guild.channels.fetch(settings.channels.punishments);
        if (punishments && punishments.isTextBased()) {
            await punishments.send({
                content: `<@${player.id}>`,
                embeds: [
                    embeds.success(
                        `**User:** ${player}\n**Reason:** ${reason}\n\nThe punishment has been removed from your punishment history.`,
                        '`✅` Ranked Ban Removed',
                        false
                    ).setColor('#40ff56')
                        .setThumbnail('https://images-ext-1.discordapp.net/external/DF9hM2A0XmdL2Q5anEZqyom9XlPGhK8DO5TCymCmfwA/https/i.imgur.com/yka7bke.png?format=webp&quality=lossless&width=200&height=200')
                ]
            });
        }

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> Unbanned \`${player.username}\` from the ranked queue.`,
        });
    }
}