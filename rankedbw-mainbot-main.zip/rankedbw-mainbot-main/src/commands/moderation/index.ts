export default {
    name: 'Moderation',
    description: 'A bunch of different moderation commands.',
}