import { 
    ChatInputCommandInteraction,
    SlashCommandBuilder,
    EmbedBuilder 
} from 'discord.js';
import { Command } from '..';
import { TeamVoiceManager } from '../../utils';
import settings from '../../settings';

export default class VoiceCleanupCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('voicecleanup')
        .setDescription('Force clean up of voice chats"');
    
    requiredRoles: string[] = [
        settings.roles.helper, 
        settings.roles.moderator, 
        settings.roles.seniorModerator, 
        settings.roles.administrator, 
        settings.roles.owner
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const guild = interaction.guild;
            if (!guild) {
                await interaction.editReply({
                    content: '❌ This command can only be used in a server.'
                });
                return;
            }

            await TeamVoiceManager.forceReleaseEmptyChannels(guild);

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Voice Channel Cleanup Complete')
                .setDescription('Successfully released all empty voice channels from the in-use list.')
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in voicecleanup command:', error);
            
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ Cleanup Failed')
                .setDescription('An error occurred while cleaning up voice channels.')
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }
}