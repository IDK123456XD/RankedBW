import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import { GameHandler } from "../../utils/gameHandler";

export default class VoidCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("void")
    .setDescription("Voids a game and undoes stat changes if already scored.")
    .addStringOption((option) =>
      option
        .setName("gameid")
        .setDescription("The game id you want to void.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option.setName("reason").setDescription("The reason for the void.").setRequired(true)
    );

  requiredRoles: string[] = [settings.roles.helper, settings.roles.moderator, settings.roles.seniorModerator, settings.roles.administrator, settings.roles.owner];

  async execute(interaction: ChatInputCommandInteraction) {
    const gameId = interaction.options.getString("gameid", true);
    const reason = interaction.options.getString("reason", true);

    await interaction.deferReply();

    const voidStatus = await GameHandler.voidGame(gameId, interaction.guild, false, interaction.user.id, reason);

    await interaction.editReply({
      content: voidStatus,
    });
  }
}
