import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '../..';
import settings from '../../../settings';
import embeds from '../../../utils/discord/embeds';
import App from '../../..';

export default class QueueUnlockCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('unlock')
        .setDescription('Unlock queue channels (remove capacity limit).')
        .addStringOption(option =>
            option.setName('queue')
                .setDescription('Select which queue to unlock')
                .addChoices(
                    { name: 'Queue 1 (0-300)', value: settings.voiceChannels.queue1 },
                    { name: 'Queue 2 (300-600)', value: settings.voiceChannels.queue2 },
                    { name: 'Queue 3 (600+)', value: settings.voiceChannels.queue3 },
                    { name: 'Queue 4 (800+)', value: settings.voiceChannels.queue4 },
                    { name: 'Queue 5 (PUGS)', value: settings.voiceChannels.queue5 },
                    { name: 'Queue 6 (0-600)', value: settings.voiceChannels.queue6 },
                    { name: 'All Queues', value: 'all' }
                )
                .setRequired(true))

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.developer,
        settings.roles.administrator,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const selectedQueue = interaction.options.getString('queue', true);
        
    const queueChannels = [
        { id: settings.voiceChannels.queue1, name: 'Queue 1' },
        { id: settings.voiceChannels.queue2, name: 'Queue 2' },
        { id: settings.voiceChannels.queue3, name: 'Queue 3' },
        { id: settings.voiceChannels.queue4, name: 'Queue 4' },
        { id: settings.voiceChannels.queue5, name: 'Queue 5' },
        { id: settings.voiceChannels.queue6, name: 'Queue 6' },
    ];        await interaction.deferReply({ ephemeral: true });

        // Get current lock status
        const lockStatusData = await App.Redis.get('queueLockStatus');
        let lockStatus: Record<string, boolean> = {};
        if (lockStatusData) {
            lockStatus = JSON.parse(lockStatusData);
        }

        let statusMessage = '**Queues Unlocked:**\n\n';
        let channelsToUnlock = selectedQueue === 'all' ? queueChannels : queueChannels.filter(q => q.id === selectedQueue);

        for (const queueInfo of channelsToUnlock) {
            const queueChannel = await interaction.guild.channels.fetch(queueInfo.id);

            if (!queueChannel || !queueChannel.isVoiceBased()) continue;

            // Unlock the channel (remove user limit - set to 0 for unlimited)
            await queueChannel.edit({ userLimit: 0 });

            // Update lock status
            lockStatus[queueInfo.id] = false;

            statusMessage += `**${queueChannel.name}:** 🔓 Unlocked (capacity restored)\n`;
        }

        // Store updated lock status in Redis
        await App.Redis.set('queueLockStatus', JSON.stringify(lockStatus));

        // Send alert to alerts channel about queue unlock
        const alertsChannel = await interaction.guild.channels.fetch(settings.channels.botLogs);
        if (alertsChannel && alertsChannel.isTextBased()) {
            const queueText = selectedQueue === 'all' ? 'All queues' : channelsToUnlock[0]?.name || 'Queue';
            await alertsChannel.send({
                content: `🔓 **${queueText} ${selectedQueue === 'all' ? 'have' : 'has'} been unlocked** by <@${interaction.user.id}>. Players can now join normally.`
            });
        }

        const summaryText = selectedQueue === 'all' 
            ? `**All queues are now unlocked and available for players to join.**`
            : `**${channelsToUnlock[0]?.name} is now unlocked and available for players to join.**`;

        await interaction.editReply({
            embeds: [embeds.success(
                statusMessage + `\n${summaryText}`,
                'Queue(s) Unlocked'
            )],
        });
    }
} 