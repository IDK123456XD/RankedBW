import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder, ChannelType, CategoryChannel } from 'discord.js';
import { ChildCommand } from '../..';
import settings from '../../../settings';
import embeds from '../../../utils/discord/embeds';
import App from '../../..';

export default class QueueTeamVcsCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('teamvcs')
        .setDescription('Recreate team voice channels (deletes all existing team VCs and creates 50 new ones)');

    requiredRoles: string[] = [settings.roles.administrator, settings.roles.owner];

    private generateRandomId(): string {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < 4; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const guild = interaction.guild;
            if (!guild) {
                await interaction.editReply({
                    embeds: [embeds.error('This command must be run in a server!', 'No Guild')]
                });
                return;
            }

            // Get the teams category
            const teamsCategoryChannel = guild.channels.cache.get(settings.categories.teams);
            if (!teamsCategoryChannel || teamsCategoryChannel.type !== ChannelType.GuildCategory) {
                await interaction.editReply({
                    embeds: [embeds.error('Teams category not found or is not a category channel!', 'Category Missing')]
                });
                return;
            }

            const teamsCategory = teamsCategoryChannel as CategoryChannel;

            // Delete all existing voice channels in the teams category
            const existingChannels = guild.channels.cache.filter(
                channel => channel.parentId === settings.categories.teams && 
                channel.type === ChannelType.GuildVoice
            );

            let deletedCount = 0;
            for (const [, channel] of existingChannels) {
                try {
                    await channel.delete('Recreating team voice channels');
                    deletedCount++;
                } catch (error) {
                    console.error(`Failed to delete channel ${channel.name}:`, error);
                }
            }

            // Create 50 new team voice channels (25 pairs)
            let createdCount = 0;
            const createdChannels = [];

            for (let i = 0; i < 25; i++) {
                const gameId = this.generateRandomId();
                
                try {
                    // Create Team 1 channel
                    const team1Channel = await guild.channels.create({
                        name: `Game ${gameId} | Team 1`,
                        type: ChannelType.GuildVoice,
                        parent: settings.categories.teams,
                        permissionOverwrites: teamsCategory.permissionOverwrites.cache.map(overwrite => ({
                            id: overwrite.id,
                            allow: overwrite.allow,
                            deny: overwrite.deny,
                            type: overwrite.type
                        }))
                    });

                    // Create Team 2 channel
                    const team2Channel = await guild.channels.create({
                        name: `Game ${gameId} | Team 2`,
                        type: ChannelType.GuildVoice,
                        parent: settings.categories.teams,
                        permissionOverwrites: teamsCategory.permissionOverwrites.cache.map(overwrite => ({
                            id: overwrite.id,
                            allow: overwrite.allow,
                            deny: overwrite.deny,
                            type: overwrite.type
                        }))
                    });

                    createdChannels.push({
                        gameId,
                        team1: team1Channel.id,
                        team2: team2Channel.id
                    });

                    createdCount += 2;
                } catch (error) {
                    console.error(`Failed to create team channels for game ${gameId}:`, error);
                }

                // Add a small delay to avoid rate limits
                if (i % 5 === 0) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }

            // Store the channel pairs in Redis for later use
            await App.Redis.set('teamVoiceChannels', JSON.stringify(createdChannels));

            await interaction.editReply({
                embeds: [embeds.success(
                    `Successfully recreated team voice channels!\n\n` +
                    `**Deleted:** ${deletedCount} old channels\n` +
                    `**Created:** ${createdCount} new channels (${createdChannels.length} pairs)\n\n` +
                    `Team voice channels are now ready for games.`,
                    'Team Voice Channels Updated'
                )]
            });

        } catch (error) {
            console.error('Error in teamvcs command:', error);
            await interaction.editReply({
                embeds: [embeds.error(
                    'An error occurred while recreating team voice channels. Check console for details.',
                    'Command Failed'
                )]
            });
        }
    }
} 