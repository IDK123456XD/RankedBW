import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '../..';
import settings from '../../../settings';
import embeds from '../../../utils/discord/embeds';
import App from '../../..';

export default class QueueLockCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('lock')
        .setDescription('Lock queue channels (set capacity to 1 and kick all members).')
        .addStringOption(option =>
            option.setName('queue')
                .setDescription('Select which queue to lock')
                .addChoices(
                    { name: 'Queue 1 (0-300)', value: settings.voiceChannels.queue1 },
                    { name: 'Queue 2 (300-600)', value: settings.voiceChannels.queue2 },
                    { name: 'Queue 3 (600+)', value: settings.voiceChannels.queue3 },
                    { name: 'Queue 4 (800+)', value: settings.voiceChannels.queue4 },
                    { name: 'Queue 5 (PUGS)', value: settings.voiceChannels.queue5 },
                    { name: 'Queue 6 (0-600)', value: settings.voiceChannels.queue6 },
                    { name: 'All Queues', value: 'all' }
                )
                .setRequired(true))

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.developer,
        settings.roles.administrator,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const selectedQueue = interaction.options.getString('queue', true);
        
    const queueChannels = [
        { id: settings.voiceChannels.queue1, name: 'Queue 1' },
        { id: settings.voiceChannels.queue2, name: 'Queue 2' },
        { id: settings.voiceChannels.queue3, name: 'Queue 3' },
        { id: settings.voiceChannels.queue4, name: 'Queue 4' },
        { id: settings.voiceChannels.queue5, name: 'Queue 5' },
        { id: settings.voiceChannels.queue6, name: 'Queue 6' },
    ];        await interaction.deferReply({ ephemeral: true });

        // Get current lock status
        const lockStatusData = await App.Redis.get('queueLockStatus');
        let lockStatus: Record<string, boolean> = {};
        if (lockStatusData) {
            lockStatus = JSON.parse(lockStatusData);
        }

        let statusMessage = '**Queues Locked:**\n\n';
        let totalKicked = 0;
        let channelsToLock = selectedQueue === 'all' ? queueChannels : queueChannels.filter(q => q.id === selectedQueue);

        for (const queueInfo of channelsToLock) {
            const queueChannel = await interaction.guild.channels.fetch(queueInfo.id);

            if (!queueChannel || !queueChannel.isVoiceBased()) continue;

            // Count members before kicking
            const memberCount = queueChannel.members.size;
            totalKicked += memberCount;

            // Lock the channel (set user limit to 1)
            await queueChannel.edit({ userLimit: 1 });

            // Update lock status
            lockStatus[queueInfo.id] = true;

            // Move all members to waiting room
            for (const member of queueChannel.members.values()) {
                await App.Redis.publish('queue:move', JSON.stringify({
                    memberId: member.id,
                    channelId: settings.voiceChannels.waitingRoom,
                    guildId: settings.guild
                }));
            }

            statusMessage += `**${queueChannel.name}:** 🔒 Locked (${memberCount} members moved)\n`;
        }

        // Store updated lock status in Redis
        await App.Redis.set('queueLockStatus', JSON.stringify(lockStatus));

        // Clear the queue in Redis if all queues are locked
        if (selectedQueue === 'all') {
            await App.Redis.del('currentQueue');
        } else {
            // Remove only members from the locked queue
            const currentlyQueueing = await App.Redis.lrange('currentQueue', 0, -1);
            if (currentlyQueueing.length > 0) {
                const filteredQueue = currentlyQueueing.filter(memberData => {
                    const member = JSON.parse(memberData);
                    return member.queueChannelId !== selectedQueue;
                });
                await App.Redis.del('currentQueue');
                if (filteredQueue.length > 0) {
                    await App.Redis.rpush('currentQueue', ...filteredQueue);
                }
            }
        }

        // Send alert to alerts channel about queue lock
        const alertsChannel = await interaction.guild.channels.fetch(settings.channels.botLogs);
        if (alertsChannel && alertsChannel.isTextBased()) {
            const queueText = selectedQueue === 'all' ? 'All queues' : channelsToLock[0]?.name || 'Queue';
            await alertsChannel.send({
                content: `🔒 **${queueText} ${selectedQueue === 'all' ? 'have' : 'has'} been locked** by <@${interaction.user.id}>. ${totalKicked} members were moved to waiting room.`
            });
        }

        const summaryText = selectedQueue === 'all' 
            ? `**Total members moved:** ${totalKicked}\n**All queues are now locked and restricted to 1 member each.**`
            : `**Members moved:** ${totalKicked}\n**${channelsToLock[0]?.name} is now locked and restricted to 1 member.**`;

        await interaction.editReply({
            embeds: [embeds.success(
                statusMessage + `\n${summaryText}`,
                'Queue(s) Locked'
            )],
        });
    }
} 