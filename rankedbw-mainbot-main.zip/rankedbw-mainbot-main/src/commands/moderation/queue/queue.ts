import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '../..';
import QueueReloadCommand from './reload';
import QueueLockCommand from './lock';
import QueueUnlockCommand from './unlock';
import QueueTeamVcsCommand from './teamvcs';

export default class QueueCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('queue')
        .setDescription('Run queue management commands.');

    childCommands: ChildCommand[] = [
        new QueueReloadCommand(),
        new QueueLockCommand(),
        new QueueUnlockCommand(),
        new QueueTeamVcsCommand()
    ];
    
    requiredRoles: string[] = [];
} 