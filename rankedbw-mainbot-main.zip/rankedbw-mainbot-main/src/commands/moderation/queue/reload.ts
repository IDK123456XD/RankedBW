import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder, PermissionFlagsBits } from 'discord.js';
import { ChildCommand } from '../..';
import settings, { ELO_DATA } from '../../../settings';
import embeds from '../../../utils/discord/embeds';
import App from '../../..';

interface QueueRestrictions {
    queueChannelId: string;
    channelName: string;
    minElo: number;
    maxElo: number;
    requiredRoles: string[];
    specialRoles: string[];
}

export default class QueueReloadCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('reload')
        .setDescription('Reload all queue channels and update ELO restrictions based on channel permissions.')

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.developer,
        settings.roles.administrator,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
const queueChannels = [
    { id: settings.voiceChannels.queue1, name: 'Queue 1' },
    { id: settings.voiceChannels.queue2, name: 'Queue 2' },
    { id: settings.voiceChannels.queue3, name: 'Queue 3' },
    { id: settings.voiceChannels.queue4, name: 'Queue 4' },
    { id: settings.voiceChannels.queue5, name: 'Queue 5' },
    { id: settings.voiceChannels.queue6, name: 'Queue 6' },
];        await interaction.deferReply({ ephemeral: true });

        // Get current lock status before reloading
        const lockStatusData = await App.Redis.get('queueLockStatus');
        let lockStatus: Record<string, boolean> = {};
        if (lockStatusData) {
            lockStatus = JSON.parse(lockStatusData);
        }

        const queueRestrictions: QueueRestrictions[] = [];
        let statusMessage = '**Queue Restrictions Updated:**\n\n';

        for (const queueInfo of queueChannels) {
            const queueChannel = await interaction.guild.channels.fetch(queueInfo.id);

            if (!queueChannel || !queueChannel.isVoiceBased()) continue;

            // Preserve lock status - only clear if queue is not locked
            const isLocked = lockStatus[queueInfo.id] === true;
            if (!isLocked) {
                await queueChannel.edit({ userLimit: 0 });
                queueChannel.members.forEach(member => member.voice.setChannel(null));
            } else {
                // Keep locked queues at capacity 1
                await queueChannel.edit({ userLimit: 1 });
                // Move any members that might be in locked queues
                queueChannel.members.forEach(member => member.voice.setChannel(null));
            }

            // Analyze channel permissions using actual channel name
            const restrictions = await this.analyzeChannelPermissions(queueChannel, queueChannel.name);
            queueRestrictions.push(restrictions);

            // Add to status message using actual channel name and lock status
            const lockEmoji = isLocked ? '🔒 ' : '';
            statusMessage += `**${lockEmoji}${queueChannel.name}:**\n`;
            if (restrictions.minElo !== -1 && restrictions.maxElo !== -1) {
                statusMessage += `• ELO Range: ${restrictions.minElo} - ${restrictions.maxElo === 9999 ? '∞' : restrictions.maxElo}\n`;
            } else if (restrictions.minElo !== -1) {
                statusMessage += `• Min ELO: ${restrictions.minElo}\n`;
            } else {
                statusMessage += `• No ELO restrictions\n`;
            }
            
            if (restrictions.specialRoles.length > 0) {
                statusMessage += `• Special Roles: ${restrictions.specialRoles.map(roleId => `<@&${roleId}>`).join(', ')}\n`;
            }

            if (isLocked) {
                statusMessage += `• Status: Locked (capacity limited to 1)\n`;
            }
            statusMessage += '\n';
        }

        // Store restrictions in Redis
        await App.Redis.set('queueRestrictions', JSON.stringify(queueRestrictions));
        await App.Redis.set('queueRestrictionsLastRefresh', Date.now().toString());

        await interaction.editReply({
            embeds: [embeds.success(statusMessage, 'Queues Reloaded & Restrictions Updated')],
        });
    }

    private async analyzeChannelPermissions(channel: any, channelName: string): Promise<QueueRestrictions> {
        const restrictions: QueueRestrictions = {
            queueChannelId: channel.id,
            channelName: channelName,
            minElo: -1,
            maxElo: -1,
            requiredRoles: [],
            specialRoles: []
        };

        // Get all role overwrites that allow CONNECT
        const allowedRoles: string[] = [];
        const specialRoleIds = [
            settings.roles.administrator,
            settings.roles.owner,
            settings.roles.developer,
            settings.roles.staff,
            settings.roles.moderator,
            settings.roles.seniorModerator,
            settings.roles.pups,
            settings.roles.pugs,
            settings.roles.pugsTrial,
            settings.roles.pugsSpec,
            settings.roles.premium,
            settings.roles.pit,
            settings.roles.helper
        ];

        // Check each permission overwrite
        for (const [roleId, overwrite] of channel.permissionOverwrites.cache) {
            // Skip @everyone and user overwrites
            if (roleId === channel.guild.id || overwrite.type === 1) continue;

            // Check if role has CONNECT permission
            if (overwrite.allow.has(PermissionFlagsBits.Connect)) {
                allowedRoles.push(roleId);
            }
        }

        // If no specific overwrites, check @everyone permissions
        if (allowedRoles.length === 0) {
            const everyoneOverwrite = channel.permissionOverwrites.cache.get(channel.guild.id);
            if (!everyoneOverwrite || !everyoneOverwrite.deny.has(PermissionFlagsBits.Connect)) {
                // @everyone can connect, so no restrictions
                restrictions.minElo = 0;
                restrictions.maxElo = 9999;
                return restrictions;
            }
        }

        // Analyze ELO roles
        const eloRoles = allowedRoles.filter(roleId => 
            ELO_DATA.some(eloData => eloData.roleId === roleId)
        );

        if (eloRoles.length > 0) {
            const eloRanges = eloRoles.map(roleId => {
                const eloData = ELO_DATA.find(data => data.roleId === roleId);
                return eloData ? { min: eloData.min, max: eloData.max } : null;
            }).filter(range => range !== null);

            if (eloRanges.length > 0) {
                restrictions.minElo = Math.min(...eloRanges.map(r => r.min));
                restrictions.maxElo = Math.max(...eloRanges.map(r => r.max));
            }
        }

        // Check for special roles
        const presentSpecialRoles = allowedRoles.filter(roleId => 
            specialRoleIds.includes(roleId)
        );

        restrictions.specialRoles = presentSpecialRoles;
        restrictions.requiredRoles = allowedRoles;

        return restrictions;
    }
} 