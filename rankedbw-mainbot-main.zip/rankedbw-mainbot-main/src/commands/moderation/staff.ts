import { ChatInputCommandInteraction, Role, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';

const staffRoleHigherarchy = ['helper', 'moderator', 'seniorModerator', 'administrator', 'owner'];

export default class StaffCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('staff')
        .setDescription('Staff role system command.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The discord user they want to make/remove staff from.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('role')
                .setDescription('The role they would like to add/remove.')
                .addChoices(...staffRoleHigherarchy.map(role => ({ name: role, value: role })))
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.administrator,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const commandRunnerMember = await interaction.guild.members.fetch(interaction.user.id);
        const discordUser = interaction.options.getUser('discord-user');
        const discordUserMember = await interaction.guild.members.fetch(discordUser.id);
        const roleName = interaction.options.getString('role', true);
        const role = await interaction.guild.roles.fetch((settings.roles as any)[roleName] as string) as Role;

        const staffRoles = commandRunnerMember.roles.cache.filter(role => staffRoleHigherarchy.some(x => (settings.roles as any)[x] === role.id));
        const highestStaffRole = staffRoles.reduce((prev, curr) => (prev.comparePositionTo(curr) > 0 ? prev : curr));
        if (highestStaffRole.comparePositionTo(role) <= 0) {
            await interaction.reply({
                embeds: [
                    embeds.error('You cannot give a role that is equal to or higher than your highest staff role.')
                ],
                ephemeral: true,
            });
            return;
        }

        const staffAnnouncements = await interaction.guild.channels.fetch(settings.channels.staffAnnouncements);
        if (!staffAnnouncements?.isTextBased()) {
            await interaction.reply({
                embeds: [
                    embeds.error('Could not find staff announcements channel.')
                ],
                ephemeral: true,
            });
            return;
        }

        if (discordUserMember.roles.cache.has(role.id)) {
            await discordUserMember.roles.remove(role);

            if (discordUserMember.roles.cache.has(settings.roles.staff))
                await discordUserMember.roles.remove(settings.roles.staff);

            await staffAnnouncements.send({
                embeds: [
                    embeds.normal(
                        `${interaction.member} has kicked ${discordUser} from the **${role.name}** team!`,
                        'Staff Demotion'
                    )
                ],
            });

            await interaction.reply({
                embeds: [
                    embeds.success(
                        `${interaction.member} has kicked ${discordUser} from the **${role.name}** team!`,
                        'Staff Demotion'
                    )
                ],
                ephemeral: true,
            });
            return;
        }

        let newStaff = false;
        let highestPastStaffRole: Role = null;
        if (!discordUserMember.roles.cache.has(settings.roles.staff)) {
            newStaff = true;
            await discordUserMember.roles.add(settings.roles.staff);
        } else {
            const pastStaffRoles = discordUserMember.roles.cache.filter(role =>
                staffRoleHigherarchy.some(x => (settings.roles as any)[x] === role.id));
            for (const pastStaffRole of pastStaffRoles.values()) {
                await discordUserMember.roles.remove(pastStaffRole);
            }

            highestPastStaffRole = pastStaffRoles.reduce((prev, curr) => (prev.comparePositionTo(curr) > 0 ? prev : curr));
        }

        await discordUserMember.roles.add(role);

        const promotion = highestPastStaffRole?.comparePositionTo(role) < 0;
        await staffAnnouncements.send({
            embeds: [
                embeds.normal(
                    newStaff
                        ? `${interaction.member} welcomes ${discordUser} to the staff team as a **${role.name}**.`
                        : `${interaction.member} has ${promotion ? 'promoted' : 'demoted'} ${discordUser} to **${role.name}**.`,
                    (newStaff ? 'New Staff Member' : promotion ? 'Staff Promotion' : 'Staff Demotion')
                )
            ],
        });

        await interaction.reply({
            embeds: [
                embeds.success(
                    newStaff
                        ? `${interaction.member} welcomes ${discordUser} to the staff team as a **${role.name}**.`
                        : `${interaction.member} has ${promotion ? 'promoted' : 'demoted'} ${discordUser} to **${role.name}**.`,
                    (newStaff ? 'New Staff Member' : promotion ? 'Staff Promotion' : 'Staff Demotion')
                )
            ],
            ephemeral: true,
        });
    }
}