import { ChatInputCommandInteraction, GuildMember, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import embeds from "../../utils/discord/embeds";
import { prisma } from "@common/database/connectors/prisma";
import { totalXpToReachLevel, getPlayerProgress } from "../../utils/leveling";
import { changePlayerElo } from "../../utils/elo";
import { EloHistoryReason } from "@common/database/generated/client";
import sendLogs from "../../utils/logs";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import { refreshEloData } from "../../utils/eloChecker";

export default class SetstatCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("modify")
    .setDescription("Modify a specific stat for a player.")
    .addUserOption((option) =>
      option
        .setName("discord-user")
        .setDescription("The discord user you want to modify the stat for.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("stat")
        .setDescription("The stat you want to modify.")
        .setRequired(true)
        .addChoices(
          { name: "ELO", value: "elo" },
          { name: "Wins", value: "wins" },
          { name: "Losses", value: "losses" },
          { name: "MVPs", value: "mvps" },
          { name: "Games Played", value: "gamesPlayed" },
          { name: "Level", value: "level" },
          { name: "XP", value: "xp" },
          { name: "Streak", value: "streak" }
        )
    )
    .addIntegerOption((option) =>
      option
        .setName("value")
        .setDescription("The value to modify the stat to.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("The reason for modifying this stat.")
        .setRequired(true)
    );

  requiredRoles: string[] = [
    settings.roles.moderator,
    settings.roles.owner,
    settings.roles.administrator,
    settings.roles.seniorModerator,
    settings.roles.developer,
  ];

  async execute(interaction: ChatInputCommandInteraction) {
    const discordUser = interaction.options.getUser("discord-user", true);
    const stat = interaction.options.getString("stat", true);
    const value = interaction.options.getInteger("value", true);
    const reason = interaction.options.getString("reason", true);

    const player = await prisma.player.findUnique({
      where: {
        userId: discordUser.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });

    if (!player) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> ${discordUser.username} is not registered.`,
      });
      return;
    }

    const guildMember = await interaction.guild.members.fetch(discordUser.id);
    if (!guildMember) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> ${discordUser.username} is not in the server.`,
      });
      return;
    }

    await interaction.deferReply();

    const statNames: Record<string, string> = {
      elo: "ELO",
      wins: "Wins",
      losses: "Losses",
      gamesPlayed: "Games Played",
      mvps: "MVPs",
      level: "Level",
      xp: "XP",
      peakElo: "Peak ELO",
      streak: "Streak",
    };

    let displayStat: string;
    let displayValue: number;
    let originalValue: number;

    if (stat === "elo") {
      // Use the helper function for ELO changes
      const result = await changePlayerElo(
        player,
        value,
        EloHistoryReason.ManualAdjustment,
        reason
      );

      if (!result.success) {
        await interaction.editReply({
          content: `<:rbw_cross:1387585103563063387> Failed to update ELO. Please try again.`,
        });
        return;
      }

      displayStat = "ELO";
      displayValue = value;
      originalValue = result.prevElo || player.PlayerStatistics[0].elo;

      // Log ELO changes manually since we're using the basic helper function
      await sendLogs(
        `**${interaction.user.username}** changed **${player.minecraftName
        }**'s ELO from \`${originalValue}\` to \`${displayValue}\` (${displayValue > originalValue ? "+" : ""
        }${displayValue - originalValue}).\n**Reason:** ${reason}`,
        "ELO Modified"
      );
    } else if (stat === "level") {
      // Validate level value
      if (value < 1) {
        await interaction.editReply({
          content: `<:rbw_cross:1387585103563063387> Level must be at least 1.`,
        });
        return;
      }

      // When modifying level, set totalXp to exactly what's needed to reach that level
      // This puts them at the start of that level with 0 XP progress
      const requiredTotalXp = totalXpToReachLevel(value);

      await prisma.player.update({
        where: {
          id: player.id,
        },
        data: {
          totalXp: requiredTotalXp,
        },
      });

      displayStat = "Level";
      displayValue = value;
      originalValue = getPlayerProgress(player.totalXp).level;

      // Log level changes
      await sendLogs(
        `**${interaction.user.username}** changed **${player.minecraftName}**'s ${statNames[stat]} from \`${originalValue}\` to \`${displayValue}\`.\n**Reason:** ${reason}`,
        "Stat Change"
      );
    } else if (stat === "xp") {
      // Validate XP value (must be non-negative)
      if (value < 0) {
        await interaction.editReply({
          content: `<:rbw_cross:1387585103563063387> XP towards next level cannot be negative.`,
        });
        return;
      }

      // When setting XP towards next level, calculate based on current level
      const currentProgress = getPlayerProgress(player.totalXp);
      const baseXpForCurrentLevel = totalXpToReachLevel(currentProgress.level);
      const newTotalXp = baseXpForCurrentLevel + value;

      await prisma.player.update({
        where: {
          id: player.id,
        },
        data: {
          totalXp: newTotalXp,
        },
      });

      displayStat = "XP";
      displayValue = value;
      originalValue = currentProgress.xpIntoLevel;

      // Log XP changes
      await sendLogs(
        `**${interaction.user.username}** modified **${player.minecraftName}**'s ${statNames[stat]} from \`${originalValue}\` to \`${displayValue}\`.\n**Reason:** ${reason}`,
        "Stat Change"
      );
    } else if (stat === "streak") {
      await prisma.playerStatistics.update({
        where: {
          playerId_seasonId: {
            playerId: player.id,
            seasonId: player.PlayerStatistics[0].seasonId
          }
        },
        data: {
          streak: value
        }
      });

      displayStat = "Streak";
      displayValue = value;
      originalValue = player.PlayerStatistics[0].streak;

      // Log streak changes
      await sendLogs(
        `**${interaction.user.username}** modified **${player.minecraftName}**'s ${statNames[stat]} from \`${originalValue}\` to \`${displayValue}\`.\n**Reason:** ${reason}`,
        "Stat Change"
      );
    } else {
      // For other stats (wins, losses, mvps, gamesPlayed), set directly
      originalValue = player[stat as keyof typeof player] as number;
      displayStat = statNames[stat] || stat;
      displayValue = value;

      await prisma.playerStatistics.update({
        where: {
          playerId_seasonId: {
            playerId: player.id,
            seasonId: player.PlayerStatistics[0].seasonId
          }
        },
        data: {
          [stat]: value
        }
      })

      // Log other stat changes
      await sendLogs(
        `**${interaction.user.username}** modified **${player.minecraftName}**'s ${statNames[stat]} from \`${originalValue}\` to \`${displayValue}\`.\n**Reason:** ${reason}`,
        "Stat Change"
      );
    }

    const updatedPlayerData = await prisma.player.findUnique({
      where: {
        userId: discordUser.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });

    await refreshEloData(guildMember, updatedPlayerData);

    const finalStatName = statNames[displayStat] || displayStat;
    await interaction.editReply({
      content: `<:rbw_check:1387585062530322443> Modified \`${player.minecraftName}\`'s ${finalStatName} from \`${originalValue}\` to \`${displayValue}\`. Reason: \`${reason}\``,
    });
  }
}
