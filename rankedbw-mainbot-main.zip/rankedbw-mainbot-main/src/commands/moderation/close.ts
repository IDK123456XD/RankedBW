import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import settings from '../../settings';
import { prisma } from '@common/database/connectors/prisma';
import { TeamVoiceManager } from '../../utils/teamVoiceManager';
import { GameStatus } from '@common/database/generated';
import { abortPickingSession } from '../../tasks/queuing/captainPicking';
import App from '../..';

export default class CloseCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('close')
        .setDescription('Closes a game thread and resets team channels without voiding.')

    requiredRoles: string[] = [
        settings.roles.moderator,
        settings.roles.seniorModerator,
        settings.roles.administrator,
        settings.roles.owner,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const game = await prisma.game.findFirst({
            where: {
                queueThreadChannelId: interaction.channel.id
            },
            include: {
                players: {
                    include: {
                        user: true
                    }
                }
            }
        });

        if (!game) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> This is not a game thread.`,
                ephemeral: true
            });
            return;
        }

        // Check if this game has an active picking session and abort it silently
        const activePickingData = await App.Redis.get(`activePicking:${game.gameId}`);
        if (activePickingData) {
            console.log(`Game ${game.gameId} has an active picking session, aborting it before close`);
            try {
                await abortPickingSession(game.gameId);
            } catch (error) {
                console.error(`Error aborting picking session for game ${game.gameId}:`, error);
            }
        }

        // Send the response immediately
        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> The game has been closed and will be cleaned up in 30 seconds.`,
        });

        await new Promise(resolve => setTimeout(resolve, 30000));

        // Update game status to VOIDED only if the game is pending after the 30 second delay
        if (game.status === GameStatus.PENDING) {
            await prisma.game.update({
                where: {
                    id: game.id
                },
                data: {
                    status: GameStatus.VOIDED
                }
            });
        }

        const resetChannelsPromise = TeamVoiceManager.resetChannelsAfterGame(interaction.guild, game.gameId).catch(error => {
            console.error('Error resetting channels after game close:', error);
        });

        // Archive and lock the channel in parallel with sending the response
        const archivePromise = interaction.channel?.isThread() 
            ? Promise.all([
                interaction.channel.setArchived(true),
                interaction.channel.setLocked(true)
            ])
            : Promise.resolve();

        // Wait for all operations to complete in the background
        await Promise.all([resetChannelsPromise, archivePromise]);
    }
}