import { ChatInputCommandInteraction, SlashCommandBuilder, TextChannel } from 'discord.js';
import { Command } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';
import { PunishmentType } from '@common/database/generated';

export default class UnmuteCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('unmute')
        .setDescription('Unmute a player.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to punishment.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('The reason for the punishment.')
                .setRequired(true)
        )

    requiredRoles: string[] = [settings.roles.moderator, settings.roles.seniorModerator, settings.roles.administrator, settings.roles.owner];

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player');
        const reason = interaction.options.getString('reason');

        const member = await interaction.guild.members.fetch(player.id);
        if (!member) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> Please provide a valid player.`,
            });
            return;
        }

        if (!member.roles.cache.has(settings.roles.muted)) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> This player is not currently muted.`,
            });
            return;
        }

        const playerData = await prisma.player.findFirst({
            where: {
                userId: player.id
            }
        });

        if (!playerData) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> This player does not exist in our database.`,
            });
            return;
        }

        await member.roles.remove(settings.roles.muted);

        await prisma.punishment.create({
            data: {
                type: PunishmentType.unmute,
                reason,
                staff: interaction.user.id,
                expired: false,
                Player: {
                    connect: {
                        id: playerData.id
                    }
                }
            }
        })

        const punishments = await interaction.guild.channels.fetch(settings.channels.punishments);
        if (punishments && punishments.isTextBased()) {
            await punishments.send({
                content: `${player}`,
                embeds: [
                    embeds.normal(
                        `**User:** ${player}\n**Reason:** ${reason}\n\nIn the future if you face another punishment, it will likely increase due to your punishment history.`,
                        '`✅` Server Unmuted'
                    ).setColor('#40ff56')
                        .setThumbnail('https://images-ext-1.discordapp.net/external/DF9hM2A0XmdL2Q5anEZqyom9XlPGhK8DO5TCymCmfwA/https/i.imgur.com/yka7bke.png?format=webp&quality=lossless&width=200&height=200')
                ]
            });
        }

        const punishmentLogs = await interaction.guild.channels.fetch(settings.channels.punishmentLogs) as TextChannel;
        if (!punishmentLogs) return;

        await punishmentLogs.send({
            embeds: [
                embeds.normal(
                    `${player} has been unmuted for **${reason}**.`,
                    'Mute Removed',
                    false
                ).addFields([
                    { name: 'User', value: `${member}`, inline: true },
                    { name: 'Moderator', value: `${interaction.user}`, inline: true },
                    { name: 'Reason', value: `\`${reason}\``, inline: true },
                ])
            ]
        });

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> \`${player.username}\` has been unmuted for **${reason}**.`,
        });
    }
}