import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandBuilder, Interaction, ButtonInteraction } from 'discord.js';
import { Command } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import Paginator from '../../utils/discord/paginator';
import { prisma } from '@common/database/connectors/prisma';
import { Punishment, PunishmentType, Player } from '@common/database/generated/client';

export default class PunishmentsCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('punishments')
        .setDescription('Get a list of all the punishments a player has.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to fetch punishments for.')
                .setRequired(true)
        )

    requiredRoles: string[] = [settings.roles.staff];

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player');

        const playerData: (Player & { punishments: Punishment[] }) | null = await prisma.player.findFirst({
            where: {
                userId: player.id
            },
            include: {
                punishments: {
                    orderBy: {
                        createdAt: 'desc'
                    }
                }
            }
        });

        if (!playerData || playerData.punishments.length === 0) {
            await interaction.reply({
                embeds: [embeds.error('This player does not exist in our database or has no punishments.')]
            });
            return;
        }

        const activePunishments = playerData.punishments.filter((p: Punishment) =>
            (p.type === PunishmentType.mute || p.type === PunishmentType.rankedban || p.type === PunishmentType.strike) && !p.expired && (!p.expiresAt || p.expiresAt.getTime() > Date.now())
        );

        const strikes = activePunishments.filter((p: Punishment) => p.type === PunishmentType.strike);
        const activeMutes = activePunishments.filter((p: Punishment) => p.type === PunishmentType.mute);
        const activeRankedBans = activePunishments.filter((p: Punishment) => p.type === PunishmentType.rankedban);

        const initialEmbed = embeds.normal(
            `📋 Punishments for **${player.username}**`,
            `Showing current active punishments for **${player.username}**.`
        );

        let description = '';

        if (activeMutes.length > 0) {
            description += '**🔇 Active Mutes:**\n';
            activeMutes.forEach((mute: Punishment) => {
                const expiryTimestamp = mute.expiresAt ? Math.floor(new Date(mute.expiresAt).getTime() / 1000) : 'N/A';
                description += `\`Reason:\` ${mute.reason} (Expires: ${expiryTimestamp !== 'N/A' ? `<t:${expiryTimestamp}:R>` : 'Never'})\n`;
            });
            description += '\n';
        }

        if (activeRankedBans.length > 0) {
            description += '**⛔ Active Ranked Bans:**\n';
            activeRankedBans.forEach((ban: Punishment) => {
                const expiryTimestamp = ban.expiresAt ? Math.floor(new Date(ban.expiresAt).getTime() / 1000) : 'N/A';
                description += `\`Reason:\` ${ban.reason} (Expires: ${expiryTimestamp !== 'N/A' ? `<t:${expiryTimestamp}:R>` : 'Never'})\n`;
            });
            description += '\n';
        }

        if (strikes.length > 0) {
            description += `**⚠️ Strikes: ${strikes.length}**\n`;
            strikes.forEach((strike: Punishment, index: number) => {
                description += `\`#${index + 1}:\` ${strike.reason}\n`;
            });
            description += '\n';
        }

        if (description === '') {
            description = 'This player has no active punishments.';
        }

        initialEmbed.setDescription(description);

        const viewPreviousButton = new ButtonBuilder()
            .setCustomId('view_previous_punishments')
            .setLabel('View Previous Punishments')
            .setStyle(ButtonStyle.Primary);

        const row = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(viewPreviousButton);

        await interaction.reply({
            embeds: [initialEmbed],
            components: [row]
        });

        const filter = (i: Interaction) => i.isButton() && i.customId === 'view_previous_punishments' && i.user.id === interaction.user.id;
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async (i: ButtonInteraction) => {
            if (i.customId === 'view_previous_punishments') {
                await i.deferUpdate();

                const previousPunishments = playerData.punishments.filter((p: Punishment) =>
                    (p.type === PunishmentType.rankedunban || p.type === PunishmentType.unmute || p.type === PunishmentType.strikeRemove) ||
                    (p.type === PunishmentType.mute && p.expired) ||
                    (p.type === PunishmentType.rankedban && p.expired) ||
                    (p.type === PunishmentType.strike && p.expired)
                );

                if (previousPunishments.length === 0) {
                    await i.editReply({
                        embeds: [embeds.error('This player has no previous punishments.')],
                        components: []
                    });
                    return;
                }

                const punishmentsPerPage = 5;
                const totalPages = Math.ceil(previousPunishments.length / punishmentsPerPage);

                await new Paginator(i, totalPages, async (pageIndex: number) => {
                    const pagePunishments = previousPunishments.slice(pageIndex * punishmentsPerPage, pageIndex * punishmentsPerPage + punishmentsPerPage);

                    const embed = embeds.normal(
                        `📜 Previous Punishments for **${player.username}**`,
                        `Showing **${pagePunishments.length}** of **${previousPunishments.length}** previous punishment${previousPunishments.length === 1 ? '' : 's'} • Page **${pageIndex + 1}**/**${totalPages}**`
                    );

                    pagePunishments.forEach((punishment: Punishment, index: number) => {
                        const punishmentNumber = (pageIndex * punishmentsPerPage) + index + 1;
                        const punishmentType = punishment.type.charAt(0).toUpperCase() + punishment.type.slice(1);

                        let descriptionValue = `**Staff:** <@${punishment.staff}>\n**Reason:** \`${punishment.reason}\``;

                        if (punishment.type === PunishmentType.rankedunban || punishment.type === PunishmentType.unmute || punishment.type === PunishmentType.strikeRemove) {
                            descriptionValue = `**Punishment Revoked by Staff:** <@${punishment.staff}>\n**Reason for Revocation:** \`${punishment.reason}\``;
                        } else if (punishment.expiresAt) {
                            const expiryTimestamp = Math.floor(new Date(punishment.expiresAt).getTime() / 1000);
                            const isExpired = punishment.expired;
                            descriptionValue += `\n**Expiry:** <t:${expiryTimestamp}:R> ${isExpired ? '*(Expired)*' : '*(Active)*'}`;
                        }

                        embed.addFields({
                            name: `**${punishmentType}** #${punishmentNumber}`,
                            value: descriptionValue,
                            inline: false
                        });
                    });

                    embed.setFooter({
                        text: `Total previous punishments: ${previousPunishments.length} • Use the buttons to navigate pages`
                    });

                    return embed;
                }, 0, true).start();
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                interaction.editReply({ components: [] });
            }
        });
    }
}