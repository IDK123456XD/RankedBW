import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import embeds from "../../utils/discord/embeds";
import { prisma } from "@common/database/connectors/prisma";
import { PunishmentType } from "@common/database/generated";
import { changePlayerElo, calculateStrikeRemovalAmount } from "../../utils/elo";
import { EloHistoryReason } from "@common/database/generated/client";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

export default class StrikeRemoveCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("strikeremove")
    .setDescription("Remove the most recent strike from a player.")
    .addUserOption((option) =>
      option
        .setName("player")
        .setDescription("The player to remove strike from.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("The reason for removing the strike.")
        .setRequired(true)
    );

  requiredRoles: string[] = [
    settings.roles.owner,
    settings.roles.administrator,
    settings.roles.seniorModerator,
    settings.roles.moderator,
  ];

  async execute(interaction: ChatInputCommandInteraction) {
    const player = interaction.options.getUser("player");
    const reason = interaction.options.getString("reason");

    const member = await interaction.guild.members.fetch(player.id);
    if (!member) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> Please provide a valid player.`,
      });
      return;
    }

    const playerData = await prisma.player.findFirst({
      where: {
        userId: player.id,
      },
      include: {
        punishments: {
          where: {
            type: PunishmentType.strike,
          },
          orderBy: {
            id: "desc",
          },
        },
        ...IncludeCurrentSeasonStatistics,
      },
    });

    if (!playerData) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> This player does not exist in our database.`,
      });
      return;
    }

    const strikes = playerData.punishments;
    if (strikes.length === 0) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> This player has no strikes to remove.`,
      });
      return;
    }

    const punishment = await prisma.punishment.create({
      data: {
        type: PunishmentType.strikeRemove,
        reason,
        staff: interaction.user.id,
        expired: false,
        Player: {
          connect: {
            id: playerData.id,
          },
        },
      },
    });

    // Calculate the proper restoration amount to prevent elo floor bugs
    const restorationAmount = await calculateStrikeRemovalAmount(playerData.id);
    const newElo = playerData.PlayerStatistics[0].elo + restorationAmount;

    const result = await changePlayerElo(
      playerData,
      newElo,
      EloHistoryReason.StrikeRemove,
      "Player Strike Removed"
    );

    if (!result.success) {
      console.error("Failed to update ELO for strike removal");
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> Failed to update ELO. Please try again.`,
      });
      return;
    }

    // Get updated player data to calculate new effective strikes after removal
    const updatedPlayerData = await prisma.player.findFirst({
      where: {
        userId: player.id,
      },
      include: {
        punishments: {
          where: {
            expired: false,
          },
        },
      },
    });

    // Calculate effective strikes after the strike removal
    const strikeAmount = updatedPlayerData.punishments.filter(
      (punishment) => punishment.type === PunishmentType.strike
    ).length;
    const strikeRemoveAmount = updatedPlayerData.punishments.filter(
      (punishment) => punishment.type === PunishmentType.strikeRemove
    ).length;
    const effectiveStrikes = strikeAmount - strikeRemoveAmount;

    const punishments = await interaction.guild.channels.fetch(
      settings.channels.punishments
    );
    if (punishments && punishments.isTextBased()) {
      await punishments.send({
        content: `${player}`,
        embeds: [
          embeds
            .normal(
              `**User:** ${player}\n**Reason:** ${reason}\n**ELO Restored:** +${restorationAmount} ELO\n\nThe most recent strike has been removed from your punishment history.`,
              "`✅` Strike Removed"
            )
            .setColor("#40ff56")
            .setThumbnail(
              "https://images-ext-1.discordapp.net/external/DF9hM2A0XmdL2Q5anEZqyom9XlPGhK8DO5TCymCmfwA/https/i.imgur.com/yka7bke.png?format=webp&quality=lossless&width=200&height=200"
            ),
        ],
      });
    }

    const punishmentLogs = await interaction.guild.channels.fetch(
      settings.channels.punishmentLogs
    );
    if (punishmentLogs && punishmentLogs.isTextBased()) {
      await punishmentLogs.send({
        embeds: [
          embeds
            .normal(
              `${player}'s most recent strike has been removed for **${reason}**.`,
              "Strike Removed"
            )
            .addFields([
              { name: "User", value: `${player}`, inline: true },
              { name: "Moderator", value: `${interaction.user}`, inline: true },
              {
                name: "Reason for Removal",
                value: `\`${reason}\``,
                inline: true,
              },
              {
                name: "Total Strikes",
                value: `${effectiveStrikes}`,
                inline: true,
              },
              {
                name: "ELO Change",
                value: `+${restorationAmount} (${playerData.PlayerStatistics[0].elo} → ${newElo})`,
                inline: true,
              },
            ]),
        ],
      });
    }

    await interaction.reply({
      content: `<:rbw_check:1387585062530322443> \`${player.username}\`'s most recent strike has been removed for **${reason}**. Restored ${restorationAmount} ELO.`,
    });
  }
}
