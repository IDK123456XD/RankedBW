import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import embeds from "../../utils/discord/embeds";
import { prisma } from "@common/database/connectors/prisma";
import { PunishmentType } from "@common/database/generated";

export default class MuteCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("mute")
    .setDescription("Mute a player.")
    .addUserOption((option) =>
      option
        .setName("player")
        .setDescription("The player to punishment.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("duration")
        .setDescription("The duration of the punishment.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("The reason for the punishment.")
        .setRequired(true)
    );

  requiredRoles: string[] = [settings.roles.helper, settings.roles.moderator, settings.roles.seniorModerator, settings.roles.administrator, settings.roles.owner];

  async execute(interaction: ChatInputCommandInteraction) {
    const player = interaction.options.getUser("player");
    const reason = interaction.options.getString("reason");
    const duration = interaction.options.getString("duration");

    const member = await interaction.guild.members.fetch(player.id);
    if (!member) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> Please provide a valid player.`,
      });
      return;
    }

    if (member.roles.cache.has(settings.roles.muted)) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> This player is already muted.`,
      });
      return;
    }

    const playerData = await prisma.player.findFirst({
      where: {
        userId: player.id,
      },
    });

    if (!playerData) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> This player does not exist in our database.`,
      });
      return;
    }

    const numberDuration = duration.convertDurationToMillis();
    if (!numberDuration) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> Please provide a valid duration.`,
      });
      return;
    }

    await member.roles.add(settings.roles.muted);

    const newPunishment = await prisma.punishment.create({
      data: {
        expired: false,
        Player: {
          connect: {
            id: playerData.id,
          },
        },
        type: PunishmentType.mute,
        reason,
        staff: interaction.user.id,
        expiresAt: new Date(Date.now() + numberDuration),
      },
    });

    const expiryDate = Math.round(new Date(Date.now() + numberDuration).getTime() / 1000);
    const punishments = await interaction.guild.channels.fetch(
      settings.channels.punishments
    );
    if (punishments && punishments.isTextBased()) {
      await punishments.send({
        content: `${player}`,
        embeds: [
          embeds
            .normal(
              `**User:** ${player}\n**Reason:** ${reason}\n**Duration:** ${duration} (<t:${expiryDate}:R>)\n\nIf you wish to appeal this punishment, please create an appeal ticket <#${settings.channels.support}> and staff will be swift to help.`,
              "`🔔` Server Muted",
              false
            )
            .setColor('#FAE773')
            .setThumbnail('https://images-ext-1.discordapp.net/external/eR65G3p4FJlGfQN_49CIuhdkVNx7HNOyPp1DjYo8C1E/https/i.imgur.com/yUKazkw.png?format=webp&quality=lossless&width=200&height=200')
        ],
      });
    }
    const logChannel = await interaction.guild.channels.fetch(
      settings.channels.muteLogs
    );
    if (logChannel && logChannel.isTextBased()) {
      await logChannel.send({
        embeds: [
          embeds
            .normal(
              `${player} has been muted for **${reason}**.`,
              "Player Muted",
              false
            )
            .addFields([
              { name: "User", value: `${player}`, inline: true },
              { name: "Moderator", value: `${interaction.user}`, inline: true },
              { name: "Duration", value: `${duration}`, inline: true },
              {
                name: "Expires",
                value: `<t:${expiryDate}> (<t:${expiryDate}:R>)`,
                inline: true,
              },
              { name: "Reason", value: `\`${reason}\``, inline: true },
            ]),
        ],
      });
    }

    await interaction.reply({
      content: `<:rbw_check:1387585062530322443> \`${player.username}\` has been muted for **${reason}**.`,
    });
  }
}
