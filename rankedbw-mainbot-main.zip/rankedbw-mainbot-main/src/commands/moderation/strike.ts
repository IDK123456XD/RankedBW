import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  User,
} from "discord.js";
import { Command } from "..";
import App from "../..";
import settings from "../../settings";
import embeds from "../../utils/discord/embeds";
import { prisma } from "@common/database/connectors/prisma";
import { PunishmentType } from "@common/database/generated";
import "./../../utils/prototypes";
import { changePlayerElo } from "../../utils/elo";
import { EloHistoryReason } from "@common/database/generated/client";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

export default class StrikeCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("strike")
    .setDescription("Strike a player.")
    .addUserOption((option) =>
      option
        .setName("player")
        .setDescription("The player to punishment.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("The reason for the punishment.")
        .setRequired(true)
    );

  requiredRoles: string[] = [settings.roles.helper, settings.roles.moderator, settings.roles.seniorModerator, settings.roles.administrator, settings.roles.owner];

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();

    const player = interaction.options.getUser("player");
    const reason = interaction.options.getString("reason");

    const member = await interaction.guild.members.fetch(player.id);
    if (!member) {
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> Please provide a valid player.`,
      });
      return;
    }

    const playerData = await prisma.player.findFirst({
      where: {
        userId: player.id,
      },
      include: {
        punishments: true,
      },
    });
    if (!playerData) {
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> This player does not exist in our database.`,
      });
      return;
    }

    // Give the strike first
    await giveStrike(player.id, reason, interaction.user);

    await interaction.editReply({
      content: `<:rbw_check:1387585062530322443> \`${player.username}\` has been striked for **${reason}**.`,
    });

    const punishments = await interaction.guild.channels.fetch(
      settings.channels.punishments
    );
    if (punishments && punishments.isTextBased()) {
      await punishments.send({
        content: `<@${player.id}>`,
        embeds: [
          embeds
            .error(
              `**User:** ${player}\n**Reason:** ${reason}\n**ELO Deducted:** -30 ELO\n\nIf you wish to appeal this punishment, please create an appeal ticket <#${settings.channels.support}> and staff will be swift to help.`,
              "`🔶` Strike Issued",
              false
            )
            .setColor("#D8833B")
            .setThumbnail(
              "https://images-ext-1.discordapp.net/external/-pEG4zquOwTqK5Q_lpI-Gh2aRtccYfSzfv45R7LRwrE/https/i.imgur.com/DZxXEr8.png?format=webp&quality=lossless&width=320&height=320"
            ),
        ],
      });
    }
  }
}

export async function giveStrike(
  playerId: string,
  reason: string,
  moderator?: User
) {
  const playerData = await prisma.player.findFirst({
    where: {
      userId: playerId,
    },
    include: {
      punishments: {
        where: {
          expired: false,
        },
      },
      ...IncludeCurrentSeasonStatistics,
    },
  });

  if (!playerData) {
    console.error(`Player not found in database for Discord ID: ${playerId}`);
    return;
  }

  const guild = await App.client.guilds.fetch(settings.guild);
  if (!guild) return;

  const member = await guild.members.fetch(playerData.userId);
  if (!member) return;

  await prisma.punishment.create({
    data: {
      type: PunishmentType.strike,
      reason,
      staff: moderator?.id || "System",
      expired: false,
      Player: {
        connect: {
          id: playerData.id,
        },
      },
    },
  });

  // Deduct 30 ELO for the strike, but don't go below 0
  const eloDeducted = 30;
  const newElo = playerData.PlayerStatistics[0].elo - eloDeducted;

  // Update ELO using helper function for proper history tracking
  if (eloDeducted > 0) {
    const result = await changePlayerElo(
      playerData,
      newElo,
      EloHistoryReason.Strike,
      "Player Strike Given"
    );

    if (!result.success) {
      console.error("Failed to update ELO for strike");
      // Continue with the rest of the strike process even if ELO update fails
    }
  }

  const strikeAmount =
    playerData.punishments.filter((punishment) => punishment.type === "strike")
      .length + 1;
  const strikeRemoveAmount = playerData.punishments.filter(
    (punishment) => punishment.type === "strikeRemove"
  ).length;
  const effectiveStrikes = strikeAmount - strikeRemoveAmount;

  let shouldBan = false;
  let banDuration = 0;
  let banReason = "";
  let isSeasonLongBan = false;

  if (effectiveStrikes === 2) {
    shouldBan = true;
    banDuration = 43200000; // 12 hours
    banReason = "2 strikes";
  } else if (effectiveStrikes === 3) {
    shouldBan = true;
    banDuration = 86400000; // 1 day
    banReason = "3 strikes";
  } else if (effectiveStrikes === 4) {
    shouldBan = true;
    banDuration = 259200000; // 3 days
    banReason = "4 strikes";
  } else if (effectiveStrikes === 5) {
    shouldBan = true;
    banDuration = 604800000; // 1 week
    banReason = "5 strikes";
  } else if (effectiveStrikes === 6) {
    shouldBan = true;
    banDuration = 1209600000; // 2 weeks
    banReason = "6 strikes";
  } else if (effectiveStrikes >= 7) {
    shouldBan = true;
    isSeasonLongBan = true;
    banReason = "7+ strikes (season-long ban)";
  }

  if (shouldBan) {
    const unexpiredRankedBan = playerData.punishments.find(
      (punishment) =>
        punishment.type === "rankedban" &&
        !punishment.expired &&
        (punishment.expiresAt === null || punishment.expiresAt > new Date())
    );

    if (!member.roles.cache.has(settings.roles.rankedBan)) {
      await App.Redis.publish(
        "change:role",
        JSON.stringify({
          memberId: member.id,
          roleId: settings.roles.rankedBan,
          guildId: settings.guild,
          action: "add",
        })
      );
    }

    if (isSeasonLongBan) {
      if (unexpiredRankedBan) {
        await prisma.punishment.update({
          where: {
            id: unexpiredRankedBan.id,
          },
          data: {
            expiresAt: null,
            reason: banReason,
          },
        });
      } else {
        await prisma.punishment.create({
          data: {
            type: PunishmentType.rankedban,
            reason: banReason,
            staff: moderator?.id || "System",
            expiresAt: null,
            expired: false,
            Player: {
              connect: {
                id: playerData.id,
              },
            },
          },
        });
      }

      const logChannel = await guild.channels.fetch(
        settings.channels.punishmentLogs
      );
      if (logChannel && logChannel.isTextBased()) {
        await logChannel.send({
          content: `${member}`,
          embeds: [
            embeds
              .normal(
                `You have been banned from ranked for **${banReason}**.`,
                "Season-Long Ranked Ban Issued"
              )
              .addFields([
                { name: "User", value: `${member}`, inline: true },
                {
                  name: "Moderator",
                  value: moderator ? `${moderator}` : "Automatic",
                  inline: true,
                },
                {
                  name: "Duration",
                  value: "Until end of season",
                  inline: true,
                },
                { name: "Reason", value: `\`${banReason}\``, inline: true },
              ]),
          ],
        });
      }

      const punishments = await guild.channels.fetch(
        settings.channels.punishments
      );
      if (punishments && punishments.isTextBased()) {
        await punishments.send({
          content: `<@${playerData.userId}>`,
          embeds: [
            embeds
              .error(
                `**User:** ${member}\n**Reason:** ${banReason}\n**Duration:** Until end of season\n\nIf you wish to appeal this punishment, please create an appeal ticket <#${settings.channels.support}> and staff will be swift to help.`,
                "`⛔️` Season-Long Ban",
                false
              )
              .setColor("#ff0000")
              .setThumbnail(
                "https://images-ext-1.discordapp.net/external/-pEG4zquOwTqK5Q_lpI-Gh2aRtccYfSzfv45R7LRwrE/https/i.imgur.com/DZxXEr8.png?format=webp&quality=lossless&width=200&height=200"
              ),
          ],
        });
      }
    } else {
      if (unexpiredRankedBan) {
        await prisma.punishment.update({
          where: {
            id: unexpiredRankedBan.id,
          },
          data: {
            expiresAt: new Date(
              unexpiredRankedBan.expiresAt!.getTime() + banDuration
            ),
            reason: banReason,
          },
        });
      } else {
        await prisma.punishment.create({
          data: {
            type: PunishmentType.rankedban,
            reason: banReason,
            staff: moderator?.id || "System",
            expiresAt: new Date(Date.now() + banDuration),
            expired: false,
            Player: {
              connect: {
                id: playerData.id,
              },
            },
          },
        });
      }

      const expiryDate = Math.round(
        new Date(Date.now() + banDuration).getTime() / 1000
      );
      const logChannel = await guild.channels.fetch(
        settings.channels.punishmentLogs
      );
      if (logChannel && logChannel.isTextBased()) {
        await logChannel.send({
          content: `${member}`,
          embeds: [
            embeds
              .normal(
                `You have been banned from ranked for **${banReason}**.`,
                "Ranked Ban Issued"
              )
              .addFields([
                { name: "User", value: `${member}`, inline: true },
                {
                  name: "Moderator",
                  value: moderator ? `${moderator}` : "Automatic",
                  inline: true,
                },
                {
                  name: "Duration",
                  value: banDuration.timeFormat(),
                  inline: true,
                },
                {
                  name: "Expires",
                  value: `<t:${expiryDate}> (<t:${expiryDate}:R>)`,
                  inline: true,
                },
                { name: "Reason", value: `\`${banReason}\``, inline: true },
              ]),
          ],
        });
      }

      const punishments = await guild.channels.fetch(
        settings.channels.punishments
      );
      if (punishments && punishments.isTextBased()) {
        await punishments.send({
          content: `<@${playerData.userId}>`,
          embeds: [
            embeds
              .error(
                `**User:** ${member}\n**Reason:** ${banReason}\n**Duration:** ${banDuration.timeFormat()}\n\nIf you wish to appeal this punishment, please create an appeal ticket <#${settings.channels.support
                }> and staff will be swift to help.`,
                "`⛔️` Ranked Ban",
                false
              )
              .setColor("#ffb029")
              .setThumbnail(
                "https://images-ext-1.discordapp.net/external/-pEG4zquOwTqK5Q_lpI-Gh2aRtccYfSzfv45R7LRwrE/https/i.imgur.com/DZxXEr8.png?format=webp&quality=lossless&width=200&height=200"
              ),
          ],
        });
      }
    }
  }

  const logChannel = await guild.channels.fetch(
    settings.channels.punishmentLogs
  );
  if (logChannel && logChannel.isTextBased()) {
    await logChannel.send({
      content: `${member}`,
      embeds: [
        embeds
          .normal(
            `${member} has been striked for **${reason}**.`,
            "Strike Issued"
          )
          .addFields([
            { name: "User", value: `${member}`, inline: true },
            {
              name: "Moderator",
              value: moderator ? `${moderator}` : "Automatic",
              inline: true,
            },
            { name: "Reason", value: `\`${reason}\``, inline: true },
            {
              name: "Total Strikes",
              value: `${effectiveStrikes}`,
              inline: true,
            },
            {
              name: "ELO Change",
              value: `-${eloDeducted} (${playerData.PlayerStatistics[0].elo} → ${newElo})`,
              inline: true,
            },
          ]),
      ],
    });
  }
}

export async function resetStrikesForSeason() {
  try {
    console.log("Resetting all strikes for new season...");

    // Mark all strike and strikeRemove punishments as expired
    await prisma.punishment.updateMany({
      where: {
        type: {
          in: [PunishmentType.strike, PunishmentType.strikeRemove],
        },
        expired: false,
      },
      data: {
        expired: true,
      },
    });

    const guild = await App.client.guilds.fetch(settings.guild);
    if (guild) {
      // Log the strike reset
      const logChannel = await guild.channels.fetch(
        settings.channels.punishmentLogs
      );
      if (logChannel && logChannel.isTextBased()) {
        await logChannel.send({
          embeds: [
            embeds
              .normal(
                "All strikes have been reset for the new season. Ranked bans remain active.",
                "🔄 Season Strike Reset"
              )
              .setColor("#00ff00"),
          ],
        });
      }
    }

    console.log("Strike reset completed successfully");
    return true;
  } catch (error) {
    console.error("Error resetting strikes for season:", error);
    return false;
  }
}
