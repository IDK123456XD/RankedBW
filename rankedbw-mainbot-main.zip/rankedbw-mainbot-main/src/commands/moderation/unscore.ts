import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import { GameHandler } from "@/utils/gameHandler";

export default class UnscoreCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("unscore")
    .setDescription("Unscore a game.")
    .addStringOption((option) =>
      option
        .setName("gameid")
        .setDescription("The game to unscore.")
        .setRequired(true)
    );

  requiredRoles: string[] = [settings.roles.helper, settings.roles.moderator, settings.roles.seniorModerator, settings.roles.administrator, settings.roles.owner];

  async execute(interaction: ChatInputCommandInteraction) {
    const gameId = interaction.options.getString("gameid", true);

    await interaction.deferReply();

    const result = await GameHandler.unscoreGame(gameId);

    await interaction.editReply({
      content: result,
    });
  }
}
