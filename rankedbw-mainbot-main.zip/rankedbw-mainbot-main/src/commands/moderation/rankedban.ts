import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';
import { PunishmentType } from '@common/database/generated';

export default class RankedBanCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('rankedban')
        .setDescription('Ban a player from ranked.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to punishment.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('The duration of the punishment.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('The reason for the punishment.')
                .setRequired(true)
        )

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.administrator,
        settings.roles.seniorModerator,
        settings.roles.moderator,
        settings.roles.screenshare,
        settings.roles.screenshareManager,
        settings.roles.ssAppeals
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player');
        const reason = interaction.options.getString('reason');
        const duration = interaction.options.getString('duration');

        const playerData = await prisma.player.findFirst({
            where: {
                userId: player.id
            }
        });
        if (!playerData) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> This player does not exist in our database.`,
            });
            return;
        }

        const numberDuration = duration.convertDurationToMillis();
        if (!numberDuration) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> Please provide a valid duration.`,
            });
            return;
        }

        try {
            const member = await interaction.guild.members.fetch(player.id);

            if (member) await member.roles.add(settings.roles.rankedBan).catch(() => { });
        } catch { }

        await prisma.punishment.create({
            data: {
                type: PunishmentType.rankedban,
                reason,
                staff: interaction.user.id,
                expiresAt: new Date(Date.now() + numberDuration),
                expired: false,
                Player: {
                    connect: {
                        id: playerData.id
                    }
                }
            }
        });

        await prisma.player.update({
            where: {
                id: playerData.id
            },
            data: {
                leftRoleIds: {
                    push: settings.roles.rankedBan
                }
            }
        });

        const expiryDate = Math.round(new Date(Date.now() + numberDuration).getTime() / 1000);
        const logChannel = await interaction.guild.channels.fetch(settings.channels.punishmentLogs);
        if (logChannel && logChannel.isTextBased()) {
            await logChannel.send({
                embeds: [
                    embeds.normal(
                        `${player} has been banned from ranked for **${reason}**.`,
                        'Ranked Ban Issued',
                        false
                    ).addFields([
                        { name: 'User', value: `${player}`, inline: true },
                        { name: 'Moderator', value: `${interaction.user}`, inline: true },
                        { name: 'Duration', value: `${duration}`, inline: true },
                        {
                            name: 'Expires',
                            value: `<t:${expiryDate}> (<t:${expiryDate}:R>)`,
                            inline: true
                        },
                        { name: 'Reason', value: `\`${reason}\``, inline: true },
                    ])
                ]
            });
        }

        const punishments = await interaction.guild.channels.fetch(settings.channels.punishments);
        if (punishments && punishments.isTextBased()) {
            await punishments.send({
                content: `<@${player.id}>`,
                embeds: [
                    embeds.error(
                        `**User:** ${player}\n**Reason:** ${reason}\n**Duration:** ${duration} (<t:${expiryDate}:R>)\n\nIf you wish to appeal this punishment, please create an appeal ticket in <#${settings.channels.support}> and staff will be swift to help.`,
                        '`⛔️` Ranked Banned',
                        false
                    ).setColor('#ff3643')
                        .setThumbnail('https://images-ext-1.discordapp.net/external/NfrkEaDWm5eMqd804pBsriW6QiCuRro5lyyfDAZNKP8/https/i.imgur.com/80XWo7Q.png?format=webp&quality=lossless&width=200&height=200')
                ]
            });
        }

        await interaction.reply({
            content: `<:rbw_check:1387585062530322443> Banned \`${player.username}\` from the ranked queue.`,
        });
    }
}