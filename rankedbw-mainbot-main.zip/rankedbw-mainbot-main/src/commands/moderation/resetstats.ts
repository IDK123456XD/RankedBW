import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import { prisma } from "@common/database/connectors/prisma";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import { refreshEloData } from "../../utils/eloChecker";

export default class ResetStatsCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("resetstats")
    .setDescription("Reset a player's stats.")
    .addUserOption((option) =>
      option
        .setName("player")
        .setDescription("The player to reset stats for.")
        .setRequired(true)
    );

  requiredRoles: string[] = [
    settings.roles.moderator,
    settings.roles.seniorModerator,
    settings.roles.administrator,
    settings.roles.owner,
  ];

  async execute(interaction: ChatInputCommandInteraction) {
    const player = interaction.options.getUser("player");

    const guildMember = await interaction.guild.members.fetch(player.id);
    if (!guildMember) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> This player is not in the server.`,
      });
      return;
    }

    const playerData = await prisma.player.findFirst({
      where: {
        userId: player.id,
      },
    });

    if (!playerData) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> This player does not exist in our database.`,
      });
      return;
    }

    const activeSeason = await prisma.season.findFirst({
      where: {
        active: true,
      },
    });

    await prisma.playerStatistics.update({
      where: {
        playerId_seasonId: {
          playerId: playerData.id,
          seasonId: activeSeason.id,
        },
      },
      data: {
        claimedELO: false,
        elo: 0,
        wins: 0,
        mvps: 0,
        gamesPlayed: 0,
        losses: 0,
        streak: 0,
        position: 0,
        peakElo: 0,
        lastStatResetAt: new Date(),
      },
    });

    const updatedPlayerData = await prisma.player.findUnique({
      where: {
        userId: playerData.userId,
      },
      include: IncludeCurrentSeasonStatistics,
    });

    await refreshEloData(guildMember, updatedPlayerData);

    const botLogsChannel = await interaction.guild.channels.fetch(
      settings.channels.botLogs
    );
    if (botLogsChannel && botLogsChannel.isTextBased()) {
      await botLogsChannel.send({
        content: `<:rbw_check:1387585062530322443> <@${interaction.user.id}> reset \`${player.username}\`'s stats.`,
      });
    }

    await interaction.reply({
      content: `<:rbw_check:1387585062530322443> Reset \`${player.username}\`'s stats.`,
    });
  }
}
