import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import { prisma } from "@common/database/connectors/prisma";
import { changePlayerElo } from "../../utils/elo";
import { EloHistoryReason } from "@common/database/generated/client";
import settings, { ELO_DATA } from "../../settings";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

export default class MvpCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("mvp")
    .setDescription("Adds an mvp to a game.")
    .addStringOption((option) =>
      option
        .setName("gameid")
        .setDescription("The game id you want to add an mvp to.")
        .setRequired(true)
    )
    .addUserOption((option) =>
      option
        .setName("player")
        .setDescription("The player you want to add an mvp to.")
        .setRequired(true)
    );

  requiredRoles: string[] = [settings.roles.helper, settings.roles.moderator, settings.roles.seniorModerator, settings.roles.administrator, settings.roles.owner];

  async execute(interaction: ChatInputCommandInteraction) {
    const gameId = interaction.options.getString("gameid", true);
    const player = interaction.options.getUser("player", true);

    const game = await prisma.game.findFirst({
      where: {
        gameId,
      },
      include: {
        players: {
          include: {
            user: {
              include: IncludeCurrentSeasonStatistics,
            },
          },
        },
      },
    });

    if (!game) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> Game with ID ${gameId} not found.`,
      });
      return;
    }

    const gamePlayer = game.players.find((x) => x.user.userId === player.id);
    if (!gamePlayer) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> This player is not in this game.`,
      });
      return;
    }

    if (gamePlayer.mvp) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> This player is already an mvp.`,
      });
      return;
    }

    // Get the elo data for MVP bonus calculation
    const currentSeasonStats = gamePlayer.user.PlayerStatistics.find(x => x.season.active);
    if (!currentSeasonStats) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> This player has no active season stats.`,
      });
      return;
    }

    const eloData = ELO_DATA.find((x) => x.min <= gamePlayer.preElo && x.max >= gamePlayer.preElo);
    if (!eloData) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> Could not find elo data for this player.`,
      });
      return;
    }

    const mvpEloBonus = eloData.mvp;
    const newElo = currentSeasonStats.elo + mvpEloBonus;
    const mvpXpBonus = 5 * gamePlayer.preElo;

    // Update GamePlayer to mark as MVP and update postElo
    await prisma.gamePlayer.update({
      where: {
        id: gamePlayer.id,
      },
      data: {
        mvp: true,
        postElo: newElo,
      },
    });

    // Apply elo change with proper history tracking
    await changePlayerElo(gamePlayer.user, newElo, EloHistoryReason.MVP, `MVP Manually Added: ${gameId}`);

    // Update Player with MVP count and XP bonus
    await prisma.playerStatistics.update({
      where: {
        playerId_seasonId: {
          playerId: gamePlayer.user.id,
          seasonId: currentSeasonStats.seasonId,
        },
      },
      data: {
        mvps: {
          increment: 1,
        },
        player: {
          update: {
            totalXp: {
              increment: mvpXpBonus,
            },
          },
        },
      },
    });

    await interaction.reply({
      content: `<:rbw_check:1387585062530322443> ${player} has been awarded MVP for game **${gameId}** and received **+${mvpEloBonus}** elo!`,
    });
  }
}
