import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import embeds from "../../utils/discord/embeds";
import { refreshEloData } from "../../utils/eloChecker";
import sendLogs from "../../utils/logs";
import { fetchFullBodySkin, fetchHeadSkin, getUUID } from "../../utils/minecraft";
import { getSettingsDocument } from "../../utils/settings";
import { prisma } from "@common/database/connectors/prisma";
import App from "../..";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

export default class ForceRegisterCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("forceregister")
    .setDescription("Force register a player to Rank Bedwars")
    .addStringOption((option) =>
      option
        .setName("minecraft-name")
        .setDescription("Your Minecraft Name")
        .setRequired(true)
    )
    .addUserOption((option) =>
      option
        .setName("discord-user")
        .setDescription("The discord user you want to add.")
        .setRequired(true)
    );

  requiredRoles: string[] = [settings.roles.seniorModerator, settings.roles.developer, settings.roles.administrator, settings.roles.owner];

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();

    const discordUser = interaction.options.getUser("discord-user");
    const minecraftName = interaction.options.getString("minecraft-name", true);

    const uuid = await getUUID(minecraftName);
    if (!uuid) {
      await interaction.editReply({
        embeds: [
          embeds.error("That Minecraft name does not exist!", "Registration"),
        ],
      });
      return;
    }

    const nameTaken = await prisma.player.findFirst({
      where: {
        userId: {
          not: discordUser.id,
        },
        minecraftName: {
          equals: minecraftName,
          mode: "insensitive",
        },
      },
    });

    if (nameTaken) {
      await interaction.editReply({
        embeds: [
          embeds.error(`That Minecraft name is already taken by <@${nameTaken.userId}>!`, "Registration"),
        ],
      });
      return;
    }

    const dbSettings = await getSettingsDocument();
    if (!dbSettings || !dbSettings.hypixelAPIKey) {
      await interaction.editReply({
        embeds: [
          embeds.error(
            "An error occurred while fetching the Hypixel API Key.\n" +
            "Please contact a developer or administrator regarding this issue",
            "Registration Error"
          ),
        ],
      });
      return;
    }

    const activeSeason = await prisma.season.findFirst({
      where: {
        active: true,
      },
    });

    const defaultInfoCard = await prisma.infocard.findFirst({
      where: {
        name: "default",
      },
    });

    if (!defaultInfoCard) {
      await interaction.editReply({
        embeds: [
          embeds.error("An error occurred while fetching the default infocard.", "Registration"),
        ],
      });
      return;
    }

    const fullBodySkin = await fetchFullBodySkin(uuid);
    const headSkin = await fetchHeadSkin(uuid);

    let player = await prisma.player.findFirst({
      where: {
        userId: discordUser.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });

    let refresh = false;
    if (player) {
      refresh = true;

      player = await prisma.player.update({
        where: {
          userId: discordUser.id,
        },
        data: {
          minecraftName,
          uuid,
          fullBodySkin,
          headSkin,
          selectedInfocard: {
            connect: {
              id: defaultInfoCard.id,
            },
          },
        },
        include: IncludeCurrentSeasonStatistics,
      });
    }

    if (!player) {
      try {
        player = await prisma.player.create({
          data: {
            userId: discordUser.id,
            minecraftName,
            uuid,
            fullBodySkin,
            headSkin,
            selectedInfocard: {
              connect: {
                id: defaultInfoCard.id,
              },
            },
            PlayerStatistics: {
              create: {
                seasonId: activeSeason.id,
              },
            },
          },
          include: IncludeCurrentSeasonStatistics,
        });
      } catch (error: any) {
        if (error.code === 'P2002' && error.meta?.target?.includes('uuid')) {
          // Find the existing player with this UUID to get their Discord ID
          const existingPlayer = await prisma.player.findUnique({
            where: { uuid: uuid }
          });
          
          await interaction.editReply({
            embeds: [
              embeds.error(
                `This user is already registered to another Discord account, unregister them first. (${existingPlayer?.userId || 'unknown'})`,
                "Registration"
              ),
            ],
          });
          return;
        }
        // Re-throw other errors
        throw error;
      }
    }

    const member = await interaction.guild.members.fetch(discordUser.id);
    if (!member) return;

    try {
      if (!member.roles.cache.has(settings.roles.registered)) {
        await App.Redis.publish(
          "change:role",
          JSON.stringify({
            memberId: member.id,
            roleId: settings.roles.registered,
            guildId: settings.guild,
            action: "add",
          })
        );
      }
    } catch (err) {
      void err;
    }

    await refreshEloData(member, player);

    // Build the response message
    const responseMessage = refresh
      ? `You have refreshed ${discordUser}'s data and re-registered them as ${minecraftName}!`
      : `You have registered ${discordUser}'s as ${minecraftName}!`;

    await interaction.editReply({
      embeds: [
        embeds.normal(
          responseMessage,
          refresh ? "Re-Registration" : "Registration"
        ),
      ],
    });

    await sendLogs(
      `${interaction.user} has force registered ${discordUser} as **${minecraftName}**.`,
      "Force Registration"
    );
  }
}
