import { ChatInputCommandInteraction, ColorResolvable, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';

export default class EmbedCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('embed')
        .setDescription('Send an embed in the discord.')
        .addStringOption(option =>
            option.setName('description')
                .setDescription('The description of the embed.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('title')
                .setDescription('The title of the embed.')
                .setRequired(false)
        )
        .addStringOption(option =>
            option.setName('image')
                .setDescription('An image link.')
                .setRequired(false)
        )
        .addStringOption(option =>
            option.setName('link')
                .setDescription('The link of the embed.')
                .setRequired(false)
        )
        .addStringOption(option =>
            option.setName('color')
                .setDescription('The color of the embed.')
                .setRequired(false)
        )
        .addStringOption(option =>
            option.setName('thumbnail')
                .setDescription('The thumbnail of the embed.')
                .setRequired(false)
        )
        .addBooleanOption(option =>
            option.setName('footer')
                .setDescription('The footer of the embed.')
                .setRequired(false)
        );

    requiredRoles: string[] = [
        settings.roles.owner,
        settings.roles.administrator,
        settings.roles.developer,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const description = interaction.options.getString('description');
        const title = interaction.options.getString('title');
        const image = interaction.options.getString('image') || null;
        const link = interaction.options.getString('link') || null;
        const color = interaction.options.getString('color') as ColorResolvable || '#7289DA';
        const thumbnail = interaction.options.getString('thumbnail') || null;
        const footerBool = interaction.options.getBoolean('footer');

        try {
            await interaction.channel.send({
                embeds: [
                    embeds.normal(
                        description.replace(/\\n/g, '\n'),
                        title,
                        footerBool
                    )
                        .setColor(color)
                        .setImage(image)
                        .setURL(link)
                        .setThumbnail(thumbnail)
                ],
            });

            await interaction.reply({
                embeds: [embeds.success('The embed has been sent.', 'Embed')],
                ephemeral: true,
            });
        } catch (error) {
            await interaction.reply({
                embeds: [embeds.error(
                    'An error occured while sending the embed.\n\n' +
                    `\`\`\`${error.toString()}\`\`\``
                )],
                ephemeral: true,
            });
            return;
        }
    }
}