import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings, { ELO_DATA } from "../../settings";
import { prisma } from "@common/database/connectors/prisma";
import { GameStatus, EloHistoryReason } from "@common/database/generated";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import { changePlayerElo } from "../../utils/elo";
import { GameHandler } from "../../utils/gameHandler";

export default class LossVoidCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("lossvoid")
    .setDescription("Voids a loss and undoes elo changes for the losing team only.")
    .addStringOption((option) =>
      option
        .setName("gameid")
        .setDescription("The game id you want to lossvoid.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option.setName("reason").setDescription("The reason for the lossvoid.").setRequired(true)
    );

  requiredRoles: string[] = [settings.roles.moderator, settings.roles.seniorModerator, settings.roles.administrator, settings.roles.owner];

  async execute(interaction: ChatInputCommandInteraction) {
    const gameId = interaction.options.getString("gameid", true);
    const reason = interaction.options.getString("reason", true);

    await interaction.deferReply();

    try {
      // Find the game with all player data
      const game = await prisma.game.findFirst({
        where: {
          gameId,
        },
        include: {
          players: {
            include: {
              user: {
                include: IncludeCurrentSeasonStatistics,
              },
            },
          },
        },
      });

      if (!game) {
        await interaction.editReply({
          content: `<:rbw_cross:1387585103563063387> Game with ID \`${gameId}\` not found.`,
        });
        return;
      }

      // Check if game is in SCORED status
      if (game.status !== GameStatus.SCORED) {
        await interaction.editReply({
          content: `<:rbw_cross:1387585103563063387> Game \`${gameId}\` has not been scored yet. Only scored games can be lossvoided.`,
        });
        return;
      }

      // Check if game has already been lossvoided
      if (game.lossVoided) {
        await interaction.editReply({
          content: `<:rbw_cross:1387585103563063387> Game \`${gameId}\` has already been lossvoided. You cannot lossvoid the same game twice.`,
        });
        return;
      }

      // Get losing team players (players where win = false)
      const losingPlayers = game.players.filter(player => !player.win);

      if (losingPlayers.length === 0) {
        await interaction.editReply({
          content: `<:rbw_cross:1387585103563063387> No losing players found in game \`${gameId}\`. This might be a tied game or data issue.`,
        });
        return;
      }

      // Process each losing player
      for (const player of losingPlayers) {
        const currentSeasonStats = player.user.PlayerStatistics.find(x => x.season.active);
        if (!currentSeasonStats) {
          console.error(`No active season stats found for player ${player.user.userId} when lossvoiding game ${gameId}`);
          continue;
        }

        // Check if this game was played before the player reset their stats
        if (currentSeasonStats.lastStatResetAt && game.createdAt < currentSeasonStats.lastStatResetAt) {
          console.log(`Skipping lossvoid for player ${player.user.userId} in game ${gameId} - game was played before stats were reset`);
          continue;
        }

        // Additional validation: check if they have a loss to remove
        if (currentSeasonStats.losses === 0 || currentSeasonStats.gamesPlayed === 0) {
          console.log(`Skipping lossvoid for player ${player.user.userId} in game ${gameId} - no losses to remove (stats may have been reset)`);
          continue;
        }

        // Get the elo data for loss amount calculation based on preElo
        const eloData = ELO_DATA.find((x) => x.min <= player.preElo && x.max >= player.preElo);
        if (!eloData) {
          console.error(`No elo data found for player ${player.user.userId} with preElo ${player.preElo} when lossvoiding game ${gameId}`);
          continue;
        }

        // Add back the loss amount for their rank (this preserves MVP bonuses already in their current elo)
        const lossAmount = eloData.loss;
        const newElo = currentSeasonStats.elo + lossAmount;
        
        await changePlayerElo(
          player.user,
          newElo,
          EloHistoryReason.ManualAdjustment,
          `Loss Voided ${gameId} - ${reason}`
        );

        // Update player statistics to remove the loss from their record
        await prisma.playerStatistics.update({
          where: {
            id: currentSeasonStats.id,
          },
          data: {
            losses: Math.max(0, currentSeasonStats.losses - 1), // Decrement losses, but don't go below 0
            gamesPlayed: Math.max(0, currentSeasonStats.gamesPlayed - 1), // Decrement games played
          },
        });

        // Reverse the loss streak change since we're voiding the loss
        // Use player.userId which is the database Player.id (consistent with gameHandler.ts usage)
        await GameHandler.reversePlayerStreak(
          player.userId, // This is the Player.id (database ID)
          currentSeasonStats.seasonId,
          false // This was a loss that we're now voiding
        );
      }

      // Mark the game as lossvoided and update the reason
      const updatedReason = game.reason 
        ? `${game.reason} | Loss Voided: ${reason}`
        : `Loss Voided: ${reason}`;

      await prisma.game.update({
        where: {
          id: game.id,
        },
        data: {
          lossVoided: true,
          reason: updatedReason,
        },
      });

      await interaction.editReply({
        content: `<:rbw_check:1387585062530322443> Game **${gameId}** has been lossvoided and the loss elo has been restored.`,
      });

    } catch (error) {
      console.error("Error in lossvoid command:", error);
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> An error occurred while processing the lossvoid. Please try again or contact an administrator.`,
      });
    }
  }
}
