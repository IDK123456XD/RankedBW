import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import embeds from "../../utils/discord/embeds";
import { prisma } from "@common/database/connectors/prisma";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import { refreshEloData } from "../../utils/eloChecker";
import App from "../..";

export default class TogglePrefixCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("toggleprefix")
    .setDescription("Toggle your discord elo prefix.");

  requiredRoles = [
    settings.roles.prime,
    settings.roles.primePlus,
    settings.roles.primePlusPlus,
    settings.roles.staff,
    settings.roles.supporter,
    settings.roles.supporterPlus,
    settings.roles.creator,
  ];

  async execute(interaction: ChatInputCommandInteraction) {
    const playerData = await prisma.player.findFirst({
      where: {
        userId: interaction.user.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });
    if (!playerData) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You are not registered yet. Please use the \`/register\` command.`,
      });
      return;
    }

    const newEloPrefix = !playerData.eloPrefix;

    const newPlayerData = await prisma.player.update({
      where: {
        id: playerData.id,
      },
      data: {
        eloPrefix: newEloPrefix,
      },
      include: IncludeCurrentSeasonStatistics,
    });

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!member) {
      await interaction.reply({
        embeds: [embeds.error("Could not fetch your Discord member data.")],
      });
      return;
    }

    await refreshEloData(member, newPlayerData);

    const nickname = newPlayerData.minecraftName + (newPlayerData.nickname !== null ? ` | ${newPlayerData.nickname}` : '');

    await App.Redis.publish(
      "change:nickname",
      JSON.stringify({
        memberId: member.id,
        nickname: nickname,
        guildId: settings.guild,
      })
    );

    await interaction.reply({
      content: `<:rbw_check:1387585062530322443> Your elo prefix has been toggled ${newEloPrefix ? "on" : "off"
        }.`,
    });
  }
}
