import { AttachmentBuilder, ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import { generateInfoImage } from '../../images/info';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class InfoCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('info')
        .setDescription('Get your player info card.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Check a specific discord user\'s info.')
                .setRequired(false)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const user = interaction.options.getUser('user', false);
        const minecraftName = interaction.options.getString('minecraft-name', false);

        if (user && minecraftName) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> You cannot specify a user and a minecraft name at the same time.`,
            });
            return;
        }

        const playerData = await prisma.player.findFirst({
            where: {
                userId: user?.id ?? interaction.user.id
            },
        });

        if (!playerData) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> ${user ? `${user} is not registered in our system as a player.` : minecraftName ? `The minecraft player **${minecraftName}** is not registered in our system.` : 'You are not registered in our system as a player.'}`,
            });
            return;
        }

        await interaction.deferReply();

        const infoImage = await generateInfoImage(playerData.id);
        if (!infoImage) {
            await interaction.editReply({
                content: `<:rbw_cross:1387585103563063387> An error occurred while generating the info card.`,
            });
            return;
        }

        await interaction.editReply({
            files: [new AttachmentBuilder(infoImage, { name: `${playerData.minecraftName}_infocard.png` })]
        });
    }
}