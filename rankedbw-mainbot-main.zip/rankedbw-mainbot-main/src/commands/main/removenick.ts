import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import { prisma } from "@common/database/connectors/prisma";
import App from "../..";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

export default class RanksCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("removenick")
    .setDescription("Remove your nick from discord and the bot.");

  async execute(interaction: ChatInputCommandInteraction) {
    const playerData = await prisma.player.findFirst({
      where: {
        userId: interaction.user.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });
    if (!playerData) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You are not registered yet. Please use the \`/register\` command.`,
      });
      return;
    }

    if (!playerData.nickname) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You do not have a nickname set.`,
      });
      return;
    }

    await prisma.player.update({
      where: {
        id: playerData.id,
      },
      data: {
        nickname: null,
      },
    });

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!member) return;

    await App.Redis.publish(
      "change:nickname",
      JSON.stringify({
        memberId: member.id,
        nickname: `[${playerData.PlayerStatistics[0].elo}] ${playerData.minecraftName}`,
        guildId: interaction.guild.id,
      })
    );

    await interaction.reply({
      content: `<:rbw_check:1387585062530322443> Your nickname has been removed.`,
    });
  }
}
