import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import { ELO_DATA } from "../../settings";
import embeds from "../../utils/discord/embeds";
import { eloToRank, eloToRole } from "../../utils/eloChecker";
import { prisma } from "@common/database/connectors/prisma";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

export default class RanksCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("ranks")
    .setDescription("Checkout all the ranks available.");

  async execute(interaction: ChatInputCommandInteraction) {
    const playerData = await prisma.player.findFirst({
      where: {
        userId: interaction.user.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });
    const rank = playerData
      ? eloToRank(playerData.PlayerStatistics[0].elo)
      : "Unranked";
    const roleId = playerData
      ? eloToRole(playerData.PlayerStatistics[0].elo)
      : null;

    await interaction.reply({
      embeds: [
        embeds.normal(
          `**Your current rank:** ${roleId ? `<@&${roleId}>` : rank}\n\n` +
          ELO_DATA.map(
            (x) =>
              `${x.emoji} <@&${x.roleId}>: **${x.min} Elo** \`+${x.gain}\` \`-${x.loss}\` MVP: \`+${x.mvp}\``
          ).join("\n"),
          "Ranked Bedwars ELO System",
          false
        ),
      ],
    });
  }
}
