import { ChannelType, ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { checkQueueOpen } from '../../utils/queues';
import { getSettingsDocument } from '../../utils/settings';
import { prisma } from '@common/database/connectors/prisma';

export default class JoinCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('join')
        .setDescription('Join a queue channel.')
        .addStringOption(option =>
            option.setName('queue')
                .setDescription('Select which queue you would like to join')
                .addChoices(...[
                    { name: 'Queue 1', value: 'queue1' },
                    { name: 'Queue 2', value: 'queue2' },
                    { name: 'Queue 3', value: 'queue3' },
                    { name: 'Queue 4', value: 'queue4' },
                    { name: 'Queue 5', value: 'queue5' },
                ])
                .setRequired(false)
        )

    maintenance = true;

    async execute(interaction: ChatInputCommandInteraction) {
        const dbSettings = await getSettingsDocument();
        if (!await checkQueueOpen(dbSettings)) {
            await interaction.reply({
                embeds: [embeds.error('Queues are currently closed.', 'Queue Closed')],
                ephemeral: true
            });
            return;
        }

        const queue = interaction.options.getString('queue') ?? 'queue1';

        const playerData = await prisma.player.findFirst({
            where: {
                userId: interaction.user.id
            }
        });
        if (!playerData) {
            await interaction.reply({
                embeds: [
                    embeds.error('You are not registered in our database. Please run the command `/register <username>` then try this command again.')
                ],
                ephemeral: true
            });
            return;
        }

        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!member || !member.voice.channel) {
            await interaction.reply({
                embeds: [embeds.error('You must be in a voice channel to run this command!')],
                ephemeral: true
            });
            return;
        }

        // const currentlyQueueing = await App.Redis.lrange('', 0, -1);
        // if (currentlyQueueing.length > 0) {
        //     const parsedQueue = currentlyQueueing.map(x => JSON.parse(x) as RedisQueueMember);
        //     const queueMember = parsedQueue.find(x => x.userId === interaction.user.id);
        //     if (queueMember) {
        //         await interaction.reply({
        //             embeds: [embeds.error('You are already in the queue.')],
        //             ephemeral: true
        //         });
        //         return;
        //     }
        // }

        const queueChannel = queue === 'queue1'
            ? await interaction.guild.channels.fetch(settings.voiceChannels.queue1)
            : queue === 'queue2'
                ? await interaction.guild.channels.fetch(settings.voiceChannels.queue2)
                : queue === 'queue3'
                    ? await interaction.guild.channels.fetch(settings.voiceChannels.queue3)
                    : queue === 'queue4'
                        ? await interaction.guild.channels.fetch(settings.voiceChannels.queue4)
                        : queue === 'queue5'
                            ? await interaction.guild.channels.fetch(settings.voiceChannels.queue5)
                            : await interaction.guild.channels.fetch(settings.voiceChannels.queue6);

        if (!queueChannel || queueChannel.type !== ChannelType.GuildVoice) {
            await interaction.reply({
                embeds: [embeds.error('The queue channel does not exist.')],
                ephemeral: true
            });
            return;
        }

        await interaction.reply({
            embeds: [embeds.success(
                `You will queue into **${queueChannel}** when the queue is filled.\n` +
                'Make sure to stay in a voice channel, leaving one will void your /join.',
                'Queue Joined'
            )],
            ephemeral: true
        });
    }
}