import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import embeds from "../../utils/discord/embeds";
import { refreshEloData } from "../../utils/eloChecker";
import { getHypixelPlayerData } from "../../utils/hypixel";
import { fetchFullBodySkin, fetchHeadSkin, getUUID, updatePlayerProfile } from "../../utils/minecraft";
import { getSettingsDocument } from "../../utils/settings";
import { prisma } from "@common/database/connectors/prisma";
import App from "../..";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

export default class RegisterCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("register")
    .setDescription("Register yourself to Ranked Bedwars")
    .addStringOption((option) =>
      option
        .setName("minecraft-name")
        .setDescription("Your Minecraft Name")
        .setRequired(true)
    );

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();

    const minecraftName = interaction.options.getString("minecraft-name", true);
    const uuid = await getUUID(minecraftName);
    if (!uuid) {
      await interaction.editReply({
        embeds: [
          embeds.error("That Minecraft name does not exist!", "Registration"),
        ],
      });
      return;
    }

    const nameTaken = await prisma.player.findFirst({
      where: {
        minecraftName: {
          equals: minecraftName,
          mode: "insensitive",
        },
      },
    });

    if (nameTaken && nameTaken.userId !== interaction.user.id) {
      await updatePlayerProfile(nameTaken);
      await interaction.editReply({
        embeds: [
          embeds.error(
            "You are already registered! Please use `/update` or `/rename` instead.",
            "Registration"
          ),
        ],
      });
      return;
    }

    const dbSettings = await getSettingsDocument();
    if (!dbSettings || !dbSettings.hypixelAPIKey) {
      await interaction.editReply({
        embeds: [
          embeds.error(
            "An error occurred while fetching the Hypixel API Key.\n" +
            "Please contact a developer or administrator regarding this issue",
            "Registration Error"
          ),
        ],
      });
      return;
    }

    const hypixelData = await getHypixelPlayerData(
      uuid,
      dbSettings.hypixelAPIKey
    );

    if (!hypixelData) {
      await interaction.editReply({
        embeds: [
          embeds.error(
            "An error occured while checking if your Discord account is linked to your Hypixel account!",
            "Registration"
          ),
        ],
      });
      return;
    } else if (
      !hypixelData?.player?.socialMedia?.links?.DISCORD ||
      (hypixelData?.player?.socialMedia?.links?.DISCORD.toLowerCase() !==
        interaction.user.username.toLowerCase() &&
        hypixelData?.player?.socialMedia?.links?.DISCORD.toLowerCase() !==
        interaction.user.tag.toLowerCase())
    ) {
      await interaction.editReply({
        embeds: [
          embeds.error(
            `You must link your Discord account to your Hypixel account!\nCheckout <#${settings.channels.howToRegister}> for more information.`,
            "Registration"
          ),
        ],
      });
      return;
    }

    const activeSeason = await prisma.season.findFirst({
      where: {
        active: true,
      },
    });

    const defaultInfoCard = await prisma.infocard.findFirst({
      where: {
        name: "default",
      },
    });

    if (!defaultInfoCard) {
      await interaction.editReply({
        embeds: [
          embeds.error("An error occurred while fetching the default infocard.", "Registration"),
        ],
      });
      return;
    }

    const fullBodySkin = await fetchFullBodySkin(uuid);
    const headSkin = await fetchHeadSkin(uuid);

    let player = await prisma.player.findFirst({
      where: {
        userId: interaction.user.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });

    let refresh = false;
    if (player) {
      refresh = true;

      player = await prisma.player.update({
        where: {
          id: player.id,
        },
        data: {
          minecraftName: hypixelData.player.displayname,
          uuid: uuid,
          fullBodySkin,
          headSkin,
          selectedInfocard: {
            connect: {
              id: defaultInfoCard.id,
            },
          },
        },
        include: IncludeCurrentSeasonStatistics
      });
    } else {
      try {
        player = await prisma.player.create({
          data: {
            userId: interaction.user.id,
            minecraftName: hypixelData.player.displayname,
            uuid: uuid,
            fullBodySkin,
            headSkin,
            selectedInfocard: {
              connect: {
                id: defaultInfoCard?.id,
              },
            },
            PlayerStatistics: {
              create: {
                seasonId: activeSeason.id,
              },
            },
          },
          include: IncludeCurrentSeasonStatistics,
        });
      } catch (error: any) {
        if (error.code === 'P2002' && error.meta?.target?.includes('uuid')) {
          // Find the existing player with this UUID to get their Discord ID
          const existingPlayer = await prisma.player.findUnique({
            where: { uuid: uuid }
          });
          
          await interaction.editReply({
            embeds: [
              embeds.error(
                `You are already registered to another Discord account, create a ticket to get your account merged. (${existingPlayer?.userId || 'unknown'})`,
                "Registration"
              ),
            ],
          });
          return;
        }
        // Re-throw other errors
        throw error;
      }
    }

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!member) return;

    try {
      if (!member.roles.cache.has(settings.roles.registered)) {
        await App.Redis.publish(
          "change:role",
          JSON.stringify({
            memberId: member.id,
            roleId: settings.roles.registered,
            guildId: settings.guild,
            action: "add",
          })
        );
      }
    } catch (err) {
      void err;
    }

    await refreshEloData(member, player);

    // Build the response message
    const responseMessage = refresh
      ? `You have refreshed your data and have been registered as **${minecraftName}**!`
      : `You have been registered as **${minecraftName}**!`;

    await interaction.editReply({
      embeds: [embeds.normal(responseMessage, "Registration")],
    });
  }
}
