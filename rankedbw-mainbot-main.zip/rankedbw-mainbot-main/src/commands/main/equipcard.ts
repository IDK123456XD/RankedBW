import { ActionRowBuilder, AttachmentBuilder, AutocompleteInteraction, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import fs from 'fs';
import path from 'path';
import { Command } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';

export default class EquipCardCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('equipcard')
        .setDescription('Equip an infocard to use on your profile.')
        .addStringOption(option =>
            option.setName('card')
                .setDescription('The name of the infocard to equip.')
                .setRequired(false)
                .setAutocomplete(true)
        )

    async autocomplete(interaction: AutocompleteInteraction) {
        const focusedOption = interaction.options.getFocused(true);
        if (focusedOption.name !== 'card') return interaction.respond([]);

        const cardName = focusedOption.value as string;
        const infocards = await prisma.infocard.findMany();

        const choices = infocards.filter(card => card.name.toLowerCase().includes(cardName.toLowerCase())).map(card => ({
            name: card.name,
            value: card.name
        }));

        await interaction.respond(choices);
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const cardName = interaction.options.getString('card');

        // Get the player data
        const playerData = await prisma.player.findUnique({
            where: {
                userId: interaction.user.id
            },
            include: {
                infocards: true,
                selectedInfocard: true
            }
        });

        if (!playerData) {
            await interaction.reply({
                embeds: [embeds.error('You are not registered in our system as a player.', 'Not Registered')],
                ephemeral: true
            });
            return;
        }

        // If no card name is provided, show a list of the player's infocards
        if (!cardName) {
            if (playerData.infocards.length === 0) {
                await interaction.reply({
                    embeds: [embeds.error('You do not have any infocards to equip.', 'No Infocards')],
                    ephemeral: true
                });
                return;
            }

            await startInfocardList(interaction, playerData.infocards, playerData.selectedInfocard?.id);
            return;
        }

        // Find the infocard by name
        const infocard = playerData.infocards.find(card =>
            card.name.toLowerCase() === cardName.toLowerCase()
        );

        if (!infocard) {
            await interaction.reply({
                embeds: [embeds.error(`You do not own an infocard named **${cardName}**.`, 'Infocard Not Found')],
                ephemeral: true
            });
            return;
        }

        // Update the player's selected infocard
        await prisma.player.update({
            where: {
                id: playerData.id
            },
            data: {
                selectedInfocard: {
                    connect: {
                        id: infocard.id
                    }
                }
            }
        });

        // Display the equipped infocard
        const infocardPath = path.join('./assets/images/infocards', infocard.image);
        if (fs.existsSync(infocardPath)) {
            const attachment = new AttachmentBuilder(infocardPath, { name: infocard.image });
            await interaction.reply({
                embeds: [embeds.success(`You have equipped the **${infocard.name}** infocard.`, 'Infocard Equipped')
                    .setImage(`attachment://${infocard.image}`)],
                files: [attachment]
            });
        } else {
            await interaction.reply({
                embeds: [embeds.success(`You have equipped the **${infocard.name}** infocard.`, 'Infocard Equipped')]
            });
        }
    }
}

async function startInfocardList(interaction: ChatInputCommandInteraction, infocards: any[], selectedInfocardId: string | undefined) {
    let infocardIndex = 0;

    const infocard = infocards[infocardIndex];
    const infocardPath = path.join('./assets/images/infocards', infocard.image);

    let attachment = null;
    if (fs.existsSync(infocardPath)) {
        attachment = new AttachmentBuilder(infocardPath, { name: infocard.image });
    }

    const isEquipped = selectedInfocardId === infocard.id;

    await interaction.reply({
        embeds: [embeds.normal(
            `Infocard: **${infocard.name}**${isEquipped ? ' (Equipped)' : ''}`,
            `Infocard \`${infocardIndex + 1}\`/\`${infocards.length}\``
        ).setImage(attachment ? `attachment://${infocard.image}` : null)],
        files: attachment ? [attachment] : [],
        components: [
            new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder()
                    .setCustomId(`${interaction.id}-infocard_previous`)
                    .setLabel('Previous')
                    .setEmoji('⬅️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(infocardIndex === 0),
                new ButtonBuilder()
                    .setCustomId(`${interaction.id}-infocard_next`)
                    .setLabel('Next')
                    .setEmoji('➡️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(infocardIndex === infocards.length - 1),
                new ButtonBuilder()
                    .setCustomId(`${interaction.id}-infocard_equip`)
                    .setLabel(isEquipped ? 'Equipped' : 'Equip')
                    .setEmoji('✅')
                    .setStyle(isEquipped ? ButtonStyle.Success : ButtonStyle.Secondary)
                    .setDisabled(isEquipped)
            )
        ]
    });

    const collector = interaction.channel.createMessageComponentCollector({
        filter: (i) => i.user.id === interaction.user.id && (
            i.customId === `${interaction.id}-infocard_previous` ||
            i.customId === `${interaction.id}-infocard_next` ||
            i.customId === `${interaction.id}-infocard_equip`
        ),
        time: 60 * 1000,
    });

    collector.on('collect', async (i) => {
        if (i.customId === `${interaction.id}-infocard_previous`) {
            if (infocardIndex === 0) return;
            infocardIndex--;
        } else if (i.customId === `${interaction.id}-infocard_next`) {
            if (infocardIndex === infocards.length - 1) return;
            infocardIndex++;
        } else if (i.customId === `${interaction.id}-infocard_equip`) {
            // Equip the selected infocard
            await prisma.player.update({
                where: {
                    userId: interaction.user.id
                },
                data: {
                    selectedInfocard: {
                        connect: {
                            id: infocards[infocardIndex].id
                        }
                    }
                }
            });

            // Update the selected infocard ID
            selectedInfocardId = infocards[infocardIndex].id;
        }

        await i.deferUpdate();

        const currentInfocard = infocards[infocardIndex];
        const currentInfocardPath = path.join('./assets/images/infocards', currentInfocard.image);

        let currentAttachment = null;
        if (fs.existsSync(currentInfocardPath)) {
            currentAttachment = new AttachmentBuilder(currentInfocardPath, { name: currentInfocard.image });
        }

        const isCurrentEquipped = selectedInfocardId === currentInfocard.id;

        await interaction.editReply({
            embeds: [embeds.normal(
                `Infocard: **${currentInfocard.name}**${isCurrentEquipped ? ' (Equipped)' : ''}`,
                `Infocard \`${infocardIndex + 1}\`/\`${infocards.length}\``
            ).setImage(currentAttachment ? `attachment://${currentInfocard.image}` : null)],
            files: currentAttachment ? [currentAttachment] : [],
            components: [
                new ActionRowBuilder<ButtonBuilder>().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-infocard_previous`)
                        .setLabel('Previous')
                        .setEmoji('⬅️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(infocardIndex === 0),
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-infocard_next`)
                        .setLabel('Next')
                        .setEmoji('➡️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(infocardIndex === infocards.length - 1),
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-infocard_equip`)
                        .setLabel(isCurrentEquipped ? 'Equipped' : 'Equip')
                        .setEmoji('✅')
                        .setStyle(isCurrentEquipped ? ButtonStyle.Success : ButtonStyle.Secondary)
                        .setDisabled(isCurrentEquipped)
                )
            ]
        });
    });

    collector.on('end', async () => {
        try {
            await interaction.editReply({
                components: []
            });
        } catch (error) {
            // Ignore errors if the message was deleted
        }
    });
} 