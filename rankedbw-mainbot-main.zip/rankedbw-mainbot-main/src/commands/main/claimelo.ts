import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import { CLAIM_ELO_DATA } from "../../settings";
import embeds from "../../utils/discord/embeds";
import { prisma } from "@common/database/connectors/prisma";
import { changePlayerElo } from "../../utils/elo";
import { EloHistoryReason } from "@common/database/generated/client";
import { getSettingsDocument } from "../../utils/settings";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import App from "../..";

export default class ClaimEloCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("claimelo")
    .setDescription("Claim elo depending on what role you have.");

  async execute(interaction: ChatInputCommandInteraction) {
    // Check if claim elo functionality is enabled
    const settings = await getSettingsDocument();
    if (!settings.claimEloEnabled) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> Claim ELO is currently disabled!`,
      });
      return;
    }

    const lockKey = `claimelo:${interaction.user.id}`;
    const lockExists = await App.Redis.exists(lockKey);
    if (lockExists) {
      interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You are already claiming elo!`,
      });
      return;
    }

    await App.Redis.setex(lockKey, 60, 'processing');

    const activeSeason = await prisma.season.findFirst({
      where: {
        active: true,
      },
    });
    if (!activeSeason) {
      interaction.reply({
        content: `<:rbw_cross:1387585103563063387> No active season found!`,
      });
      await App.Redis.del(lockKey);
      return;
    }

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!member) {
      interaction.reply({
        embeds: [
          embeds.error(
            "You must be a member of the server to run this command!"
          ),
        ],
        ephemeral: true,
      });
      await App.Redis.del(lockKey);
      return;
    }

    const highestRole = CLAIM_ELO_DATA.filter((x) =>
      member.roles.cache.has(x.role)
    ).sort((a, b) => b.amount - a.amount)[0];
    if (!highestRole) {
      interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You do not have a role that can claim elo!`,
      });
      await App.Redis.del(lockKey);
      return;
    }

    const playerData = await prisma.player.findFirst({
      where: {
        userId: interaction.user.id,
      },
      include: {
        gamePlayer: true,
        ...IncludeCurrentSeasonStatistics,
      },
    });

    if (!playerData) {
      interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You must be registered to use this command!`,
      });
      await App.Redis.del(lockKey);
      return;
    }

    let activeSeasonStatistics = await prisma.playerStatistics.findFirst({
      where: {
        playerId: playerData.id,
        seasonId: activeSeason.id,
      },
    });

    if (!activeSeasonStatistics) {
      activeSeasonStatistics = await prisma.playerStatistics.create({
        data: {
          playerId: playerData.id,
          seasonId: activeSeason.id,
        },
      });
    }

    if (activeSeasonStatistics?.claimedELO) {
      interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You have already claimed your ELO for this season!`,
      });
      await App.Redis.del(lockKey);
      return;
    }

    // Only check if they played games this season

    if (activeSeasonStatistics && activeSeasonStatistics?.gamesPlayed !== 0) {
      interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You cannot claim elo after playing a game!`,
      });
      await App.Redis.del(lockKey);
      return;
    }

    if (activeSeasonStatistics.elo > 0) {
      interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You cannot claim elo if you have more than 0 elo!`,
      });
      await App.Redis.del(lockKey);
      return;
    }

    // Update ELO using helper function for proper history tracking
    const result = await changePlayerElo(
      playerData,
      highestRole.amount,
      EloHistoryReason.ClaimElo,
      "ELO Claimed"
    );

    if (!result.success) {
      await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> Failed to claim ELO. Please try again.`,
      });
      await App.Redis.del(lockKey);
      return;
    }

    // Mark as claimed
    await prisma.playerStatistics.update({
      where: {
        id: activeSeasonStatistics.id,
      },
      data: {
        claimedELO: true,
      },
    });

    await interaction.reply({
      content: `<:rbw_check:1387585062530322443> You have claimed **${highestRole.amount}** elo!`,
    });

    await App.Redis.del(lockKey);
  }
}
