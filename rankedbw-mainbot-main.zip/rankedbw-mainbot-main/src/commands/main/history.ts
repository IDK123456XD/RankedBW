import { AutocompleteInteraction, ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';
import Paginator from '../../utils/discord/paginator';

// Emoji mapping for different ELO history reasons
const reasonEmojis = {
    GameWin: '🏆',
    GameLoss: '❌',
    ClaimElo: '🎯',
    ManualAdjustment: '⚙️',
    MVP: '🌟',
    Strike: '🔶',
    StrikeRemove: '✅',
    GameVoid: '🚫'
};

export default class HistoryCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('history')
        .setDescription('Shows a player\'s ELO history.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('The player to check history for (defaults to yourself).')
                .setRequired(false)
        )
        .addStringOption(option =>
            option.setName('season')
                .setDescription('The season to check history for (defaults to current season).')
                .setRequired(false)
                .setAutocomplete(true)
        );

    async autocomplete(interaction: AutocompleteInteraction) {

        const focusedOption = interaction.options.getFocused(true);
        if (focusedOption.name !== 'season') return interaction.respond([]);

        const seasonName = focusedOption.value as string;
        const seasons = await prisma.season.findMany();

        const choices = seasons.filter(season => season.name.toLowerCase().includes(seasonName.toLowerCase())).map(season => ({
            name: season.name,
            value: season.name
        }));

        await interaction.respond(choices);
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const targetUser = interaction.options.getUser('player') || interaction.user;
        const seasonName = interaction.options.getString('season');

        // Find the player in the database
        const player = await prisma.player.findFirst({
            where: { userId: targetUser.id }
        });

        if (!player) {
            return interaction.reply({
                content: `<:rbw_cross:1387585103563063387> Player not found in the database.`,
            });
        }

        // Find the season (current active one if not specified)
        let season;
        if (seasonName) {
            season = await prisma.season.findFirst({
                where: { name: seasonName }
            });

            if (!season) {
                return interaction.reply({
                    content: `<:rbw_cross:1387585103563063387> Season "${seasonName}" not found.`,
                });
            }
        } else {
            season = await prisma.season.findFirst({
                where: { active: true }
            });

            if (!season) {
                return interaction.reply({
                    content: `<:rbw_cross:1387585103563063387> No active season found.`,
                });
            }
        }

        // Count total history entries for pagination
        const totalEntries = await prisma.eloHistory.count({
            where: {
                userId: player.id,
                seasonId: season.id
            }
        });

        if (totalEntries === 0) {
            return interaction.reply({
                content: `<:rbw_cross:1387585103563063387> No ELO history found for **${player.minecraftName}** in season **${season.name}**.`,
            });
        }

        // Calculate total pages (10 entries per page)
        const pageCount = Math.ceil(totalEntries / 10);

        // Start pagination
        await new Paginator(interaction, pageCount, async (pageIndex) => {
            const historyEntries = await prisma.eloHistory.findMany({
                where: {
                    userId: player.id,
                    seasonId: season.id
                },
                orderBy: { createdAt: 'desc' },
                skip: pageIndex * 10,
                take: 10
            });

            const entriesText = historyEntries.map(entry => {
                const emoji = reasonEmojis[entry.reason] || '📝';
                const timestamp = `<t:${Math.floor(entry.createdAt.getTime() / 1000)}:R>`;
                return `${emoji} **${entry.elo}** ELO - ${entry.extraReason} ${timestamp}`;
            }).join('\n');

            return embeds.normal(
                entriesText,
                `ELO History for ${player.minecraftName} (Season: ${season.name})`
            );
        }, 0, false).start();
    }
}
