import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import embeds from '../../utils/discord/embeds';
import { ALLOWED_MAPS } from '../../settings';

export default class MapCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('map')
        .setDescription('View the maps in the queue.')
        .addStringOption(option =>
            option.setName('map-name')
                .setDescription('The name of the map.')
                .setRequired(false)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const mapName = interaction.options.getString('map-name');
        const maps = ALLOWED_MAPS.filter(map => map.name.toLowerCase() === mapName?.toLowerCase() || mapName === null);
        if (!maps.length) {
            return interaction.reply({
                embeds: [embeds.error('There are no maps in the database.', 'No Maps')],
                ephemeral: true
            });
        }

        await interaction.reply({
            embeds: [
                embeds.normal('Queue Maps', 'Here are the maps in the queue.').addFields(
                    maps.map(map => {
                        return {
                            name: `${map.name.toProperCase()}`,
                            value: `Height Limit: ${map.height_limit}`
                        }
                    })
                )
            ],
            ephemeral: false,
        });
    }
}