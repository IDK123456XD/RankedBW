import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  Guild,
  AutocompleteInteraction,
} from "discord.js";
import { Command } from "..";
import App from "../..";
import embeds from "../../utils/discord/embeds";
import Paginator from "../../utils/discord/paginator";
import { prisma } from "@common/database/connectors/prisma";
import { getPlayerProgress } from "../../utils/leveling";
import settings from "../../settings";

export const LeaderboardCategories = [
  "Best Streak",
  "Elo",
  "Losses",
  "Level",
  "MVPs",
  "Peak Elo",
  "Screenshares",
  "Streak",
  "Win/Loss Ratio",
  "Wins",
  "Worst Streak",
  "Claimed Screenshares",
  "Games Played",
] as const;

function getPositionDisplay(pos: number): string {
  switch (pos) {
    case 1:
      return ":first_place:";
    case 2:
      return ":second_place:";
    case 3:
      return ":third_place:";
    default:
      return `#${pos}`;
  }
}

export default class LeaderboardCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("leaderboard")
    .setDescription("View leaderboards for different categories.")
    .addStringOption((option) =>
      option
        .setName("category")
        .setDescription("The leaderboard category to view.")
        .setRequired(false)
        .addChoices(
          ...LeaderboardCategories.map((x) => ({ name: x, value: x }))
        )
    )
    .addStringOption((option) =>
      option
        .setName("season")
        .setDescription("The season to view (leave empty for current season).")
        .setRequired(false)
        .setAutocomplete(true)
    )
    .addIntegerOption((option) =>
      option
        .setName("page")
        .setDescription("The page number to view (defaults to 1).")
        .setRequired(false)
        .setMinValue(1)
    );

  async autocomplete(interaction: AutocompleteInteraction) {
    const focusedOption = interaction.options.getFocused(true);
    if (focusedOption.name !== "season") return interaction.respond([]);

    const seasonName = focusedOption.value as string;
    const seasons = await prisma.season.findMany();

    const choices = seasons
      .filter((season) =>
        season.name.toLowerCase().includes(seasonName.toLowerCase())
      )
      .map((season) => ({
        name: season.name,
        value: season.name,
      }));

    await interaction.respond(choices);
  }

  async execute(interaction: ChatInputCommandInteraction) {
    const category = (interaction.options.getString("category") ??
      "Elo") as (typeof LeaderboardCategories)[number];
    const seasonName = interaction.options.getString("season");
    const requestedPage = interaction.options.getInteger("page");

    // Get season info
    let season = null;
    if (seasonName) {
      season = await prisma.season.findUnique({
        where: { name: seasonName },
      });
      if (!season) {
        await interaction.reply({
          embeds: [
            embeds.error(`Season "${seasonName}" not found.`, "Season Error"),
          ],
          ephemeral: true,
        });
        return;
      }
    } else {
      // Get current active season
      season = await prisma.season.findFirst({
        where: { active: true },
      });
    }

    let playerCount: number;
    if (category === "Claimed Screenshares") {
      // Fetch all players with season statistics to filter by role
      const allPlayers = await prisma.playerStatistics.findMany({
        where: { seasonId: season?.id },
        select: { 
          player: { select: { userId: true } }
        },
      });
      const guildMembers = await interaction.guild.members.fetch();

      const screensharerPlayerIds = allPlayers.filter(
        (playerStat) =>
          guildMembers.has(playerStat.player.userId) &&
          guildMembers
            .get(playerStat.player.userId)
            ?.roles.cache.has(settings.roles.screenshare)
      );

      playerCount = screensharerPlayerIds.length;
    } else {
      playerCount = await prisma.player.count();
    }

    if (playerCount === 0) {
      await interaction.reply({
        embeds: [
          embeds.error(
            "There are currently no players registered or no screensharers found for this leaderboard.",
            "Leaderboard Fetching Error"
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    const pageIndex = requestedPage ? requestedPage - 1 : 0;
    const totalPages = Math.ceil(playerCount / 10);

    if (requestedPage && pageIndex >= totalPages) {
      await interaction.reply({
        embeds: [
          embeds.error(
            `Page ${requestedPage} doesn\'t exist. Maximum page is ${totalPages}.`,
            "Page Error"
          ),
        ],
        ephemeral: true,
      });
      return;
    }

    await new Paginator(
      interaction,
      totalPages - 1,
      async (currentPageIndex) => {
        const data = await getLeaderboardData(
          category,
          currentPageIndex,
          season,
          interaction.guild
        );
        if (!data)
          return embeds.error(
            "An error occurred while fetching the leaderboard data.",
            "Leaderboard Fetching Error"
          );

        const seasonSuffix = season ? ` • ${season.name}` : "";
        const embed = embeds.normal(data, `${category} Leaderboard`);

        // Set custom footer that will be processed by Paginator
        embed.setFooter({
          text: `Page PAGE of TOTAL_PAGES${seasonSuffix}`,
        });

        return embed;
      },
      pageIndex,
      false,
      false
    ).start();
  }
}

const calculateLeaderboardPos = (i: number, pageIndex: number) =>
  i + 1 + pageIndex * 10;

async function getLeaderboardData(
  category: (typeof LeaderboardCategories)[number],
  pageIndex: number,
  season: any,
  guild: Guild
) {
  const seasonFilter = season ? `season:${season.id}` : "all-seasons";
  let leaderboardData = await App.Redis.get(
    `leaderboard:${category}:${seasonFilter}:${pageIndex}`
  );
  if (leaderboardData) return leaderboardData;

  // Simple aggregations from Player table
  if (category === "Elo") {
    const data = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      orderBy: { elo: "desc" },
      skip: pageIndex * 10,
      take: 10,
      select: { player: { select: { minecraftName: true } }, elo: true },
    });
    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.player.minecraftName
          }** • ${player.elo}`
      )
      .join("\n");
  } else if (category === "Wins") {
    const data = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      orderBy: { wins: "desc" },
      skip: pageIndex * 10,
      take: 10,
      select: { player: { select: { minecraftName: true } }, wins: true },
    });
    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.player.minecraftName
          }** • ${player.wins}`
      )
      .join("\n");
  } else if (category === "Losses") {
    const data = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      orderBy: { losses: "desc" },
      skip: pageIndex * 10,
      take: 10,
      select: { player: { select: { minecraftName: true } }, losses: true },
    });
    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.player.minecraftName
          }** • ${player.losses}`
      )
      .join("\n");
  } else if (category === "MVPs") {
    const data = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      orderBy: { mvps: "desc" },
      skip: pageIndex * 10,
      take: 10,
      select: { player: { select: { minecraftName: true } }, mvps: true },
    });
    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.player.minecraftName
          }** • ${player.mvps}`
      )
      .join("\n");
  } else if (category === "Level") {
    const data = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      orderBy: { player: { totalXp: "desc" } },
      skip: pageIndex * 10,
      take: 10,
      select: { player: { select: { minecraftName: true, totalXp: true } } },
    });
    leaderboardData = data
      .map((player, i) => {
        const progress = getPlayerProgress(player.player.totalXp);
        return `**${getPositionDisplay(
          calculateLeaderboardPos(i, pageIndex)
        )} ${player.player.minecraftName}** • ${progress.level}`;
      })
      .join("\n");
  } else if (category === "Streak") {
    const data = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      orderBy: { streak: "desc" },
      skip: pageIndex * 10,
      take: 10,
      select: { player: { select: { minecraftName: true } }, streak: true },
    });
    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.player.minecraftName
          }** • ${player.streak}`
      )
      .join("\n");
  } else if (category === "Best Streak") {
    const data = await prisma.player.findMany({
      orderBy: { winStreak: "desc" },
      skip: pageIndex * 10,
      take: 10,
      select: { minecraftName: true, winStreak: true },
    });
    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.minecraftName
          }** • ${player.winStreak}`
      )
      .join("\n");
  } else if (category === "Win/Loss Ratio") {
    // Calculate WLR with raw SQL for better performance
      const query = `
      SELECT
        p."minecraftName",
        ps.wins::float    AS wins,
        ps.losses::float  AS losses,
        CASE
          WHEN ps.losses = 0 THEN ps.wins::float
          ELSE ps.wins::float / ps.losses::float
        END               AS wlr
      FROM "PlayerStatistics" ps
      -- only include stats from the current active season
      INNER JOIN "Season" s
        ON s.id = ps."seasonId"
        AND s.active = TRUE
      INNER JOIN "Player" p
        ON p.id = ps."playerId"
      WHERE ps.wins > 0
        OR ps.losses > 0
      ORDER BY wlr DESC
      LIMIT 10
      OFFSET $1
    `;
    const results = (await prisma.$queryRawUnsafe(
      query,
      pageIndex * 10
    )) as Array<{
      minecraftName: string;
      wins: number;
      losses: number;
      wlr: number;
    }>;
    leaderboardData = results
      .map((row, i) =>
        `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${row.minecraftName}** • ${row.wlr.toFixed(2)}`
      )
      .join("\n");
  } else if (category === "Peak Elo") {
    // Get peak elo from EloHistory table
    let query = `
            SELECT 
                p."minecraftName",
                MAX(eh.elo) as peakElo
            FROM "EloHistory" eh
            JOIN "Player" p ON eh."userId" = p.id
        `;
    let values: any[] = [];

    if (season) {
      query += ` WHERE eh."seasonId" = $1`;
      values.push(season.id);
    }

    query += `
            GROUP BY p."minecraftName", p.id
            ORDER BY peakElo DESC
            LIMIT 10 OFFSET $${values.length + 1}
        `;
    values.push(pageIndex * 10);

    const results = (await prisma.$queryRawUnsafe(query, ...values)) as any[];
    leaderboardData = results
      .map(
        (row, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${row.minecraftName
          }** • ${row.peakelo}`
      )
      .join("\n");
  } else if (category === "Worst Streak") {
    // For worst streak, we'll use negative streak values or losses streak
    const data = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      orderBy: { streak: "asc" },
      skip: pageIndex * 10,
      take: 10,
      select: { player: { select: { minecraftName: true } }, streak: true },
    });
    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.player.minecraftName
          }** • ${player.streak}`
      )
      .join("\n");
  } else if (category === "Screenshares") {
    // This seems to be a custom stat - using gamesPlayed as a placeholder
    // You may need to add a screenshares field to the Player model
    const data = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      orderBy: { gamesPlayed: "desc" },
      skip: pageIndex * 10,
      take: 10,
      select: {
        player: { select: { minecraftName: true } },
        gamesPlayed: true,
      },
    });
    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.player.minecraftName
          }** • ${player.gamesPlayed}`
      )
      .join("\n");
  } else if (category === "Claimed Screenshares") {
    const allPlayers = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      select: {
        player: { select: { userId: true, minecraftName: true } },
        claimedScreenshares: true,
      },
    });
    const guildMembers = await guild.members.fetch();

    const filteredPlayers = allPlayers.filter(
      (player) =>
        guildMembers.has(player.player.userId) &&
        guildMembers
          .get(player.player.userId)
          ?.roles.cache.has(settings.roles.screenshare)
    );

    filteredPlayers.sort(
      (a, b) => b.claimedScreenshares - a.claimedScreenshares
    );

    const data = filteredPlayers.slice(pageIndex * 10, pageIndex * 10 + 10);

    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.player.minecraftName
          }** • ${player.claimedScreenshares}`
      )
      .join("\n");
  } else if (category === "Games Played") {
    const data = await prisma.playerStatistics.findMany({
      where: { seasonId: season?.id },
      orderBy: { gamesPlayed: "desc" },
      skip: pageIndex * 10,
      take: 10,
      select: {
        player: { select: { minecraftName: true } },
        gamesPlayed: true,
      },
    });

    leaderboardData = data
      .map(
        (player, i) =>
          `**${getPositionDisplay(calculateLeaderboardPos(i, pageIndex))} ${player.player.minecraftName
          }** • ${player.gamesPlayed}`
      )
      .join("\n");
  }

  if (!leaderboardData?.length) return;

  await App.Redis.set(
    `leaderboard:${category}:${seasonFilter}:${pageIndex}`,
    leaderboardData,
    "EX",
    300
  );
  return leaderboardData;
}