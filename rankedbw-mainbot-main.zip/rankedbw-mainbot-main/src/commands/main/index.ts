export default {
    name: 'Game',
    description: 'A bunch of different game commands.',
}

export { default as game } from './game';
export { default as history } from './history';
export { default as queuestats } from './queuestats';
export { default as status } from './status';
export { default as update } from './update';
export { default as userinfo } from './userinfo';