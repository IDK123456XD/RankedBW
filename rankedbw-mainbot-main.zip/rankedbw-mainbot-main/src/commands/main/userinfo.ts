import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';

export default class UserInfoCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('Shows discord user ID, Minecraft UUID, and registration date.')
        .addUserOption(option =>
            option.setName('discordid')
                .setDescription('The Discord user to get information about (defaults to yourself).')
                .setRequired(false)
        )
        .addStringOption(option =>
            option.setName('mc_uuid')
                .setDescription('The Minecraft UUID to get information about.')
                .setRequired(false)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const targetUser = interaction.options.getUser('discordid') || interaction.user;
        const mcUuid = interaction.options.getString('mc_uuid');

        // Query conditions based on provided options
        const whereClause = mcUuid
            ? { minecraftUuid: mcUuid }
            : { userId: targetUser.id };

        // Get player data from database
        const player = await prisma.player.findFirst({
            where: whereClause
        });

        if (!player) {
            return interaction.reply({
                embeds: [embeds.error('Player not found in the database.')],
                ephemeral: true
            });
        }

        // Format registration date
        const registeredAt = player.createdAt
            ? `<t:${Math.floor(player.createdAt.getTime() / 1000)}:F> (<t:${Math.floor(player.createdAt.getTime() / 1000)}:R>)`
            : 'Unknown';

        const userInfoEmbed = embeds.normal(
            `
            **Discord ID:** ${player.userId}
            **Discord Tag:** <@${player.userId}>
            **Minecraft Username:** ${player.minecraftName}
            **Minecraft UUID:** \`${player.uuid}\`
            **Registered:** ${registeredAt}
            `,
            'User Information'
        );

        return interaction.reply({
            embeds: [userInfoEmbed]
        });
    }
} 