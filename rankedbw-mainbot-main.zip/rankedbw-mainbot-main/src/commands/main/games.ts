import { AutocompleteInteraction, ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import embeds from '../../utils/discord/embeds';
import Paginator from '../../utils/discord/paginator';
import { prisma } from '@common/database/connectors/prisma';
import { GameStatus } from '@common/database/generated/client';

export default class GamesCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('games')
        .setDescription('Check all your past games.')
        .addUserOption(option =>
            option.setName('player')
                .setDescription('Check a specific discord user\'s games.')
                .setRequired(false)
        )
        .addStringOption(option =>
            option.setName('season')
                .setDescription('Check a specific season\'s games.')
                .setRequired(false)
                .setAutocomplete(true)
        )

    async autocomplete(interaction: AutocompleteInteraction) {

        const focusedOption = interaction.options.getFocused(true);
        if (focusedOption.name !== 'season') return interaction.respond([]);

        const seasonName = focusedOption.value as string;
        const seasons = await prisma.season.findMany();

        const choices = seasons.filter(season => season.name.toLowerCase().includes(seasonName.toLowerCase())).map(season => ({
            name: season.name,
            value: season.name
        }));

        await interaction.respond(choices);
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const player = interaction.options.getUser('player', false);
        const seasonName = interaction.options.getString('season', false);

        // Get the target user ID (either specified player or command user)
        const targetUserId = player ? player.id : interaction.user.id;

        // Find the player data
        const playerData = await prisma.player.findFirst({
            where: {
                userId: targetUserId
            }
        });

        if (!playerData) {
            await interaction.reply({
                embeds: [
                    embeds.error(
                        player ? `${player.username} is not registered.` : 'You are not registered.',
                        'Games Fetching Error'
                    )
                ],
                ephemeral: true
            });
            return;
        }

        // Find season if specified
        let season = null;
        if (seasonName) {
            season = await prisma.season.findFirst({
                where: {
                    name: {
                        contains: seasonName,
                        mode: 'insensitive'
                    }
                }
            });

            if (!season) {
                await interaction.reply({
                    embeds: [
                        embeds.error(
                            `Season "${seasonName}" not found.`,
                            'Games Fetching Error'
                        )
                    ],
                    ephemeral: true
                });
                return;
            }
        }

        // Get player's games with optional season filter
        const playerWithGames = await prisma.player.findUnique({
            where: {
                id: playerData.id
            },
            include: {
                gamePlayer: {
                    include: {
                        Game: {
                            include: {
                                players: true,
                                season: true
                            },
                            ...(season ? { where: { seasonId: season.id } } : { where: { season: { active: true } } })
                        }
                    },
                    orderBy: {
                        Game: {
                            gameId: 'desc'
                        }
                    }
                }
            }
        });

        const gamePlayerData = playerWithGames?.gamePlayer || [];

        if (!gamePlayerData.length) {
            await interaction.reply({
                embeds: [
                    embeds.error(
                        player
                            ? `${player.username} has not played any games${season ? ` in season "${season.name}"` : ''}.`
                            : `You have not played any games${season ? ` in season "${season.name}"` : ''}.`,
                        'Games Fetching Error'
                    )
                ],
                ephemeral: true
            });
            return;
        }

        await new Paginator(interaction, Math.ceil(gamePlayerData.length / 10), async (pageIndex) => {
            // Sort the games by createdAt descending (most recent first)
            const sortedGamePlayerData = gamePlayerData
                .filter(x => x.Game !== null)
                .sort((a, b) => {
                    const dateA = new Date(a.Game.createdAt).getTime();
                    const dateB = new Date(b.Game.createdAt).getTime();
                    return dateB - dateA; // Most recent first
                });

            const games = sortedGamePlayerData
                .slice(pageIndex * 10, pageIndex * 10 + 10)
                .map(x => x.Game);

            return embeds.normal(
                games.map(game => {
                    const playerGameData = game.players.find(x => x.userId === playerData.id);
                    let statusText = 'Unknown';
                    let statusEmoji = '❓';

                    switch (game.status) {
                        case GameStatus.PENDING:
                            statusText = 'Pending';
                            statusEmoji = '🕒';
                            break;
                        case GameStatus.SUBMITTED:
                            statusText = 'Submitted';
                            statusEmoji = '📝';
                            break;
                        case GameStatus.MANUAL_REVIEW:
                            statusText = 'Manual Review';
                            statusEmoji = '👀';
                            break;
                        case GameStatus.SCORED:
                            statusText = playerGameData?.win ? 'Won' : 'Lost';
                            statusEmoji = playerGameData?.win ? '🏆' : '❌';
                            break;
                        case GameStatus.VOIDED:
                            statusText = 'Voided';
                            statusEmoji = '🚫';
                            break;
                    }

                    let displayEmoji = statusEmoji;
                    if (playerGameData?.mvp) {
                        // If MVP, show status emoji (trophy/X) followed by crown
                        displayEmoji = `${statusEmoji}👑`;
                    }

                    return `${displayEmoji} ${game.gameId}`;
                }).join('\n'),
                `${playerData.minecraftName}'s Games${season ? ` - Season: ${season.name}` : ''}`
            );
        }, 0, false, true, true).start();
    }
}