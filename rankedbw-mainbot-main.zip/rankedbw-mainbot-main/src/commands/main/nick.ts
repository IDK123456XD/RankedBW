import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import embeds from "../../utils/discord/embeds";
import { prisma } from "@common/database/connectors/prisma";
import App from "../..";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

const FORBIDDEN_NICKNAME_WORDS = ["nigger", "nigga", "faggot", "cunt", "whore"];

export default class RanksCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("nick")
    .setDescription("Set your Hypixel nickname in discord.")
    .addStringOption((option) =>
      option
        .setName("nick-name")
        .setDescription("The Hypixel ingame nickname you currently have.")
        .setRequired(true)
    );

  async execute(interaction: ChatInputCommandInteraction) {
    const nick = interaction.options.getString("nick-name", true);

    if (nick.length > 16) {
      return await interaction.reply({
        embeds: [
          embeds.error("Your nickname cannot be longer than 16 characters."),
        ],
        ephemeral: true,
      });
    }

    if (nick.includes(" ")) {
      return await interaction.reply({
        embeds: [embeds.error("Your nickname cannot contain spaces.")],
        ephemeral: true,
      });
    }

    const lowerCaseNick = nick.toLowerCase();
    for (const word of FORBIDDEN_NICKNAME_WORDS) {
      if (lowerCaseNick.includes(word)) {
        return await interaction.reply({
          embeds: [embeds.error("Your nickname contains forbidden language.")],
          ephemeral: true,
        });
      }
    }

    const playerData = await prisma.player.findFirst({
      where: {
        userId: interaction.user.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });

    if (!playerData) {
      return await interaction.reply({
        content: `<:rbw_cross:1387585103563063387> You are not registered yet. Please use the \`/register\` command.`,
      });
    }

    await prisma.player.update({
      where: {
        id: playerData.id,
      },
      data: {
        nickname: nick,
      },
    });

    const member = await interaction.guild.members.fetch(interaction.user.id);

    await App.Redis.publish(
      "change:nickname",
      JSON.stringify({
        memberId: member.id,
        nickname: `[${playerData.PlayerStatistics[0].elo}] ${playerData.minecraftName} | ${nick}`,
        guildId: interaction.guild.id,
      })
    );

    await interaction.reply({
      content: `<:rbw_check:1387585062530322443> Your Hypixel nickname has been set to \`${nick}\`.`,
    });
  }
}
