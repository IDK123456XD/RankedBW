import { ActionRowBuilder, ChatInputCommandInteraction, ModalBuilder, ModalSubmitInteraction, SlashCommandBuilder, TextInputBuilder, TextInputStyle } from "discord.js";
import settings from "../../settings";
import { prisma } from "@common/database/connectors/prisma";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import { refreshEloData } from "../../utils/eloChecker";
import { Command } from "..";

const MAX_RESET_COUNT = {
    [settings.roles.creator]: 1,
    [settings.roles.primePlusPlus]: Infinity,
    [settings.roles.primePlus]: 2,
    [settings.roles.prime]: 1,
    [settings.roles.supporterPlus]: 1,
};

export default class StatResetCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName("statreset")
        .setDescription("Reset your player statistics.");

    requiredRoles: string[] = [
        settings.roles.prime,
        settings.roles.primePlus,
        settings.roles.primePlusPlus,
        settings.roles.creator,
        settings.roles.supporterPlus
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const guildMember = await interaction.guild.members.fetch(interaction.user.id);
        if (!guildMember) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> You must be in the server to run this command.`,
            });
            return;
        }

        const playerData = await prisma.player.findFirst({
            where: {
                userId: interaction.user.id,
            },
            include: {
                ...IncludeCurrentSeasonStatistics,
            },
        });

        if (!playerData) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> Please use the \`/register\` command to register your account.`,
            });
            return;
        }

        const statResetCount = playerData.PlayerStatistics.find(x => x.season.active)?.statResetCount ?? 0;

        let maxAllowedResets = 0;
        for (const role of guildMember.roles.cache.values()) {
            const allowed = MAX_RESET_COUNT[role.id];
            if (allowed !== undefined && allowed > maxAllowedResets) {
                maxAllowedResets = allowed;
            }
        }

        if (statResetCount >= maxAllowedResets) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> You have reached the maximum number of stat resets (${maxAllowedResets}) for your highest role.`,
            });
            return;
        }

        await interaction.showModal(new ModalBuilder()
            .setCustomId('statreset-confirmation')
            .setTitle('Stat Reset Confirmation')
            .addComponents(
                new ActionRowBuilder<TextInputBuilder>().addComponents(
                    new TextInputBuilder()
                        .setCustomId('statreset-confirmation-input')
                        .setLabel("Confirm stat reset?")
                        .setPlaceholder("Type 'confirm' to confirm")
                        .setStyle(TextInputStyle.Short)
                )
            ));

        let modal: ModalSubmitInteraction;
        try {
            modal = await interaction.awaitModalSubmit({
                filter: i => i.customId === 'statreset-confirmation' && i.user.id === interaction.user.id,
                time: 30_000
            });
        } catch {
            return interaction.followUp({
                ephemeral: true,
                content: `<:rbw_cross:…> You did not confirm the stat reset in time.`,
            });
        }

        await modal.deferReply({ ephemeral: true });

        const activeSeason = await prisma.season.findFirst({
            where: {
                active: true,
            },
        });

        await prisma.playerStatistics.update({
            where: {
                playerId_seasonId: {
                    playerId: playerData.id,
                    seasonId: activeSeason.id,
                },
            },
            data: {
                claimedELO: false,
                elo: 0,
                wins: 0,
                mvps: 0,
                gamesPlayed: 0,
                losses: 0,
                streak: 0,
                position: 0,
                peakElo: 0,
                statResetCount: {
                    increment: 1,
                },
                lastStatResetAt: new Date(),
            },
        });

        const updatedPlayerData = await prisma.player.findUnique({
            where: {
                userId: playerData.userId,
            },
            include: IncludeCurrentSeasonStatistics,
        });

        await refreshEloData(guildMember, updatedPlayerData);

        const botLogsChannel = await interaction.guild.channels.fetch(
            settings.channels.botLogs
        );
        if (botLogsChannel && botLogsChannel.isTextBased()) {
            await botLogsChannel.send({
                content: `<:rbw_check:1387585062530322443> <@${interaction.user.id}> reset their stats.`,
            });
        }

        await modal.followUp({
            content: `<:rbw_check:1387585062530322443> Your statistics have been reset.`,
        });
    }
}
