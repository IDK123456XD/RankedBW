import { 
    ChatInputCommandInteraction, 
    SlashCommandBuilder, 
} from 'discord.js';
import { Command } from '..';
import embeds from '../../utils/discord/embeds';
import { ELO_DATA } from '../../settings';
import settings from '../../settings';
import App from '../..';

export default class StatusCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('status')
        .setDescription('Shows the uptime of the bot and status of all queues and worker bots.')
        .addStringOption(option => 
            option.setName('queue')
                .setDescription('Show detailed information for a specific queue')
                .addChoices(
                    { name: 'Queue 1', value: settings.voiceChannels.queue1 },
                    { name: 'Queue 2', value: settings.voiceChannels.queue2 },
                    { name: 'Queue 3', value: settings.voiceChannels.queue3 },
                    { name: 'Queue 4', value: settings.voiceChannels.queue4 },
                    { name: 'Queue 5', value: settings.voiceChannels.queue5 },
                    { name: 'Queue 6', value: settings.voiceChannels.queue6 },
                    { name: 'All Queues', value: 'all' }
                )
                .setRequired(false));
                
    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply({ ephemeral: false });

        const queueOption = interaction.options.getString('queue');
        
        if (queueOption) {
            await this.showQueueDetails(interaction, queueOption);
        } else {
            await this.showGeneralStatus(interaction);
        }
    }

    private async showGeneralStatus(interaction: ChatInputCommandInteraction) {
        // Get bot start time
        const startTime = process.uptime();
        const uptime = this.formatUptime(startTime);

        // Get last refresh time
        const lastRefreshTime = await App.Redis.get('queueRestrictionsLastRefresh');
        const lastRefresh = lastRefreshTime ? 
            `<t:${Math.floor(parseInt(lastRefreshTime) / 1000)}:R>` : 'Never';

        // Get lock status
        const lockStatusData = await App.Redis.get('queueLockStatus');
        let lockStatus: Record<string, boolean> = {};
        if (lockStatusData) {
            lockStatus = JSON.parse(lockStatusData);
        }

        // Get queue members count directly from voice channels
        const guild = interaction.guild;
        let queue1Count = 0, queue2Count = 0, queue3Count = 0, queue4Count = 0, queue5Count = 0, queue6Count = 0;
        
        try {
            const queue1 = await guild.channels.fetch(settings.voiceChannels.queue1);
            if (queue1?.isVoiceBased()) queue1Count = queue1.members.size;
        } catch {}
        
        try {
            const queue2 = await guild.channels.fetch(settings.voiceChannels.queue2);
            if (queue2?.isVoiceBased()) queue2Count = queue2.members.size;
        } catch {}
        
        try {
            const queue3 = await guild.channels.fetch(settings.voiceChannels.queue3);
            if (queue3?.isVoiceBased()) queue3Count = queue3.members.size;
        } catch {}
        
        try {
            const queue4 = await guild.channels.fetch(settings.voiceChannels.queue4);
            if (queue4?.isVoiceBased()) queue4Count = queue4.members.size;
        } catch {}
        
        try {
            const queue5 = await guild.channels.fetch(settings.voiceChannels.queue5);
            if (queue5?.isVoiceBased()) queue5Count = queue5.members.size;
        } catch {}
        
        try {
            const queue6 = await guild.channels.fetch(settings.voiceChannels.queue6);
            if (queue6?.isVoiceBased()) queue6Count = queue6.members.size;
        } catch {}
        
        // Get lock emojis for each queue
        const queue1Lock = lockStatus[settings.voiceChannels.queue1] ? '🔒' : '';
        const queue2Lock = lockStatus[settings.voiceChannels.queue2] ? '🔒' : '';
        const queue3Lock = lockStatus[settings.voiceChannels.queue3] ? '🔒' : '';
        const queue4Lock = lockStatus[settings.voiceChannels.queue4] ? '🔒' : '';
        const queue5Lock = lockStatus[settings.voiceChannels.queue5] ? '🔒' : '';
        const queue6Lock = lockStatus[settings.voiceChannels.queue6] ? '🔒' : '';

        const statusEmbed = embeds.normal(
            `
            **Bot Uptime:** ${uptime}
            **Last Restrictions Refresh:** ${lastRefresh}

            **Queue Members:**
            🎮 ${queue1Lock}Queue 1: **${queue1Count}** members
            🎮 ${queue2Lock}Queue 2: **${queue2Count}** members  
            🎮 ${queue3Lock}Queue 3: **${queue3Count}** members
            🎮 ${queue4Lock}Queue 4: **${queue4Count}** members
            🎮 ${queue5Lock}Queue 5: **${queue5Count}** members
            🎮 ${queue6Lock}Queue 6: **${queue6Count}** members

            *Use \`/status queue:[queue]\` for detailed queue permissions*
            `,
            'System Status'
        );

        return interaction.editReply({
            embeds: [statusEmbed]
        });
    }

    private async showQueueDetails(interaction: ChatInputCommandInteraction, queueChannelId: string) {
        if (queueChannelId === 'all') {
            return await this.showAllQueuesDetails(interaction);
        }

        // Get queue restrictions
        const queueRestrictionsData = await App.Redis.get('queueRestrictions');
        let queueRestrictions: any[] = [];
        if (queueRestrictionsData) {
            queueRestrictions = JSON.parse(queueRestrictionsData);
        }

        // Get lock status
        const lockStatusData = await App.Redis.get('queueLockStatus');
        let lockStatus: Record<string, boolean> = {};
        if (lockStatusData) {
            lockStatus = JSON.parse(lockStatusData);
        }

        const queueRestriction = queueRestrictions.find((r: any) => r.queueChannelId === queueChannelId);
        const isLocked = lockStatus[queueChannelId] === true;

        // Get current queue members directly from voice channel
        let currentMemberCount = 0;
        try {
            const channel = await interaction.guild.channels.fetch(queueChannelId);
            if (channel?.isVoiceBased()) {
                currentMemberCount = channel.members.size;
            }
        } catch (e) {
            console.error(`Failed to fetch queue channel ${queueChannelId}:`, e);
        }

        let permissionInfo = 'No restrictions found. Run `/queue reload` to refresh.';
        let queueName = 'Unknown Queue';
        
        if (queueRestriction) {
            queueName = queueRestriction.channelName || 'Queue';
            
            let eloInfo = '';
            if (queueRestriction.minElo !== -1 || queueRestriction.maxElo !== -1) {
                const minElo = queueRestriction.minElo !== -1 ? queueRestriction.minElo : 0;
                const maxElo = queueRestriction.maxElo !== -1 && queueRestriction.maxElo !== 9999 ? 
                    queueRestriction.maxElo : '∞';
                eloInfo = `**ELO Range:** ${minElo} - ${maxElo}\n`;
            }

            let eloRoles = '';
            if (queueRestriction.requiredRoles && queueRestriction.requiredRoles.length > 0) {
                const eloRoleIds = queueRestriction.requiredRoles.filter((roleId: string) => 
                    ELO_DATA.some(eloData => eloData.roleId === roleId)
                );
                if (eloRoleIds.length > 0) {
                    eloRoles = `**Required ELO Roles:**\n${eloRoleIds.map((roleId: string) => `<@&${roleId}>`).join(', ')}\n`;
                }
            }

            let specialRoles = '';
            if (queueRestriction.specialRoles && queueRestriction.specialRoles.length > 0) {
                specialRoles = `**Special Bypass Roles:**\n${queueRestriction.specialRoles.map((roleId: string) => `<@&${roleId}>`).join(', ')}\n`;
            }

            permissionInfo = `${eloInfo}${eloRoles}${specialRoles}`;
            if (!permissionInfo.trim()) {
                permissionInfo = 'No specific restrictions configured.';
            }
        }

        // Add lock status info
        let lockInfo = '';
        if (isLocked) {
            lockInfo = `**Status:** 🔒 Locked (capacity limited to 1)\n`;
        }

        const lockEmoji = isLocked ? '🔒 ' : '';

        const detailsEmbed = embeds.normal(
            `
            **Current Members:** ${currentMemberCount}

            **Permissions:**
            ${permissionInfo}

            ${lockInfo}**Channel:** <#${queueChannelId}>
            `,
            `${lockEmoji}${queueName} Details`
        );

        return interaction.editReply({
            embeds: [detailsEmbed]
        });
    }

    private async showAllQueuesDetails(interaction: ChatInputCommandInteraction) {
        // Get queue restrictions
        const queueRestrictionsData = await App.Redis.get('queueRestrictions');
        let queueRestrictions: any[] = [];
        if (queueRestrictionsData) {
            queueRestrictions = JSON.parse(queueRestrictionsData);
        }

        // Get lock status
        const lockStatusData = await App.Redis.get('queueLockStatus');
        let lockStatus: Record<string, boolean> = {};
        if (lockStatusData) {
            lockStatus = JSON.parse(lockStatusData);
        }

        const queueChannelIds = [
            settings.voiceChannels.queue1,
            settings.voiceChannels.queue2,
            settings.voiceChannels.queue3,
            settings.voiceChannels.queue4,
            settings.voiceChannels.queue5,
            settings.voiceChannels.queue6
        ];
        
        let allQueuesInfo = '';

        for (const channelId of queueChannelIds) {
            // Get current queue members directly from voice channel
            let currentMemberCount = 0;
            try {
                const channel = await interaction.guild.channels.fetch(channelId);
                if (channel?.isVoiceBased()) {
                    currentMemberCount = channel.members.size;
                }
            } catch {}

            const queueRestriction = queueRestrictions.find((r: any) => r.queueChannelId === channelId);
            const isLocked = lockStatus[channelId] === true;

            const queueName = queueRestriction?.channelName || `Queue ${queueChannelIds.indexOf(channelId) + 1}`;
            const lockEmoji = isLocked ? '🔒 ' : '';
            
            allQueuesInfo += `**${lockEmoji}${queueName}:** ${currentMemberCount} members\n`;
            
            if (queueRestriction) {
                if (queueRestriction.minElo !== -1 || queueRestriction.maxElo !== -1) {
                    const minElo = queueRestriction.minElo !== -1 ? queueRestriction.minElo : 0;
                    const maxElo = queueRestriction.maxElo !== -1 && queueRestriction.maxElo !== 9999 ? 
                        queueRestriction.maxElo : '∞';
                    allQueuesInfo += `• ELO: ${minElo} - ${maxElo}\n`;
                }
                
                if (queueRestriction.specialRoles && queueRestriction.specialRoles.length > 0) {
                    allQueuesInfo += `• Special Roles: ${queueRestriction.specialRoles.length} role(s)\n`;
                }
            } else {
                allQueuesInfo += `• No restrictions configured\n`;
            }

            if (isLocked) {
                allQueuesInfo += `• Status: 🔒 Locked (capacity: 1)\n`;
            }
            
            allQueuesInfo += '\n';
        }

        const lastRefreshTime = await App.Redis.get('queueRestrictionsLastRefresh');
        const lastRefresh = lastRefreshTime ? 
            `<t:${Math.floor(parseInt(lastRefreshTime) / 1000)}:R>` : 'Never';

        const allQueuesEmbed = embeds.normal(
            `
            **Last Refresh:** ${lastRefresh}

            ${allQueuesInfo}

            *Use \`/status queue:[channel]\` for detailed permissions*
            `,
            'All Queue Details'
        );

        return interaction.editReply({
            embeds: [allQueuesEmbed]
        });
    }

    private formatUptime(seconds: number): string {
        const days = Math.floor(seconds / (3600 * 24));
        const hours = Math.floor((seconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);

        const parts = [];
        if (days > 0) parts.push(`${days} day${days !== 1 ? 's' : ''}`);
        if (hours > 0) parts.push(`${hours} hour${hours !== 1 ? 's' : ''}`);
        if (minutes > 0) parts.push(`${minutes} minute${minutes !== 1 ? 's' : ''}`);
        if (secs > 0 || parts.length === 0) parts.push(`${secs} second${secs !== 1 ? 's' : ''}`);

        return parts.join(', ');
    }
} 