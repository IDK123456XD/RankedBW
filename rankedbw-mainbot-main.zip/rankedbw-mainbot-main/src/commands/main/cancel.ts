import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';
import { getSettingsDocument } from '../../utils/settings';
import App from '../..';
import { GameHandler } from '../../utils/gameHandler';
import { GameStatus } from '@common/database/generated';

export default class CancelCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('cancel')
        .setDescription('Cancels and voids the game.')

    async execute(interaction: ChatInputCommandInteraction) {
        const game = await prisma.game.findFirst({
            where: {
                queueThreadChannelId: interaction.channel.id
            },
            include: {
                players: {
                    include: {
                        user: true
                    }
                }
            }
        });

        if (!game) {
            await interaction.reply({
                embeds: [embeds.error('This command can only be used in a game queue channel.', 'Not in Queue')],
                ephemeral: true,
            });
            return;
        }

        if (game.status === GameStatus.VOIDED) {
            await interaction.reply({
                embeds: [embeds.error('This game has already been voided.', 'Game Voided')],
                ephemeral: true,
            });
            return;
        }

        const gamePlayerIds = game.players.map(x => x.user.userId);
        if (!gamePlayerIds.includes(interaction.user.id)) {
            await interaction.reply({
                embeds: [embeds.error('You can only cancel a game you are in.', 'Not In Game')],
                ephemeral: true,
            });
            return;
        }

        const voidVotes = await App.Redis.get(`${game.id}-voidVotes`);

        if (voidVotes) {
            await interaction.reply({
                embeds: [embeds.error('A vote to void the game has already been started.', 'Vote Started')],
                ephemeral: true,
            });
            return;
        }

        const dbSettings = await getSettingsDocument();
        const votesRequired = dbSettings.teamSize + 1;
        const playersVoted: string[] = [];
        const voidMessage = await interaction.channel.send({
            embeds: [embeds.normal(
                'A vote to void the game has been started. You have 60 seconds to decide.',
                `Required Votes: \`${playersVoted.length}\`/\`${votesRequired}\``
            )],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-void`)
                        .setLabel('Vote Void')
                        .setEmoji('🏴')
                        .setStyle(ButtonStyle.Primary)
                ) as ActionRowBuilder<ButtonBuilder>
            ],
        });

        const collector = interaction.channel.createMessageComponentCollector({
            filter: (i) => i.customId === `${interaction.id}-void`,
            time: 60000,
        });

        await App.Redis.set(`${game.id}-voidVotes`, JSON.stringify(playersVoted));

        collector.on('collect', async (i) => {
            if (playersVoted.includes(i.user.id) || !gamePlayerIds.includes(i.user.id)) {
                await i.reply({
                    embeds: [embeds.error('You have already voted or you are not in this game.', 'Vote Error')],
                    ephemeral: true
                });
                return;
            }

            playersVoted.push(i.user.id);
            await App.Redis.set(`${game.id}-voidVotes`, JSON.stringify(playersVoted));

            await i.update({
                embeds: [embeds.normal(
                    'A vote to void the game has been started. You have 60 seconds to decide.',
                    `Required Votes: \`${playersVoted.length}\`/\`${votesRequired}\``
                )],
                components: [
                    new ActionRowBuilder().addComponents(
                        new ButtonBuilder()
                            .setCustomId(`${interaction.id}-void`)
                            .setLabel('Vote Void')
                            .setEmoji('🏴')
                            .setStyle(ButtonStyle.Primary)
                    ) as ActionRowBuilder<ButtonBuilder>
                ],
            });

            if (playersVoted.length >= votesRequired) {
                collector.emit('end', collector.collected, 'void');
            }
        });

        collector.on('end', async (collected, reason) => {
            if (reason === 'void') await GameHandler.voidGame(game.gameId, interaction.guild, true);

            await App.Redis.del(`${game.id}-voidVotes`);

            await voidMessage.edit({
                embeds: [embeds.normal(
                    reason === 'void' ? 'The game has been voided.' : 'The vote to void the game has expired.',
                    `Vote ${reason === 'void' ? 'Passed' : 'Failed'}`
                )],
                components: []
            });
        });

        await interaction.reply({
            embeds: [embeds.success('Vote to void the game has been started!', 'Vote Started')],
            ephemeral: true,
        });
    }
}