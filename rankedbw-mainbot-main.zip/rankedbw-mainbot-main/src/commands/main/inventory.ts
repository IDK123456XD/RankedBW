import { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, EmbedBuilder, SlashCommandBuilder } from 'discord.js';
import fs from 'fs';
import path from 'path';
import { Command } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';

export default class InventoryCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('inventory')
        .setDescription('View your inventory of infocards.')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('View another user\'s inventory.')
                .setRequired(false)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;

        // Get the player data
        const playerData = await prisma.player.findUnique({
            where: {
                userId: targetUser.id
            },
            include: {
                infocards: true,
                selectedInfocard: true
            }
        });

        if (!playerData) {
            await interaction.reply({
                embeds: [embeds.error(
                    targetUser.id === interaction.user.id
                        ? 'You are not registered in our system as a player.'
                        : `${targetUser.username} is not registered in our system as a player.`,
                    'Not Registered'
                )],
                ephemeral: true
            });
            return;
        }

        if (playerData.infocards.length === 0) {
            await interaction.reply({
                embeds: [embeds.error(
                    targetUser.id === interaction.user.id
                        ? 'You do not have any infocards in your inventory.'
                        : `${targetUser.username} does not have any infocards in their inventory.`,
                    'No Infocards'
                )],
                ephemeral: true
            });
            return;
        }

        // Display the player's infocards
        await showInventory(interaction, playerData, targetUser.username);
    }
}

async function showInventory(interaction: ChatInputCommandInteraction, playerData: any, username: string) {
    let pageIndex = 0;
    const itemsPerPage = 1; // Show one infocard per page
    const totalPages = Math.ceil(playerData.infocards.length / itemsPerPage);

    // Function to generate embed for the current page
    const generatePageEmbed = async (page: number): Promise<{ embed: EmbedBuilder, attachment: AttachmentBuilder | null }> => {
        const startIdx = page * itemsPerPage;
        const endIdx = Math.min(startIdx + itemsPerPage, playerData.infocards.length);

        const infocard = playerData.infocards[startIdx];
        const isEquipped = playerData.selectedInfocard?.id === infocard.id;

        const embed = embeds.normal(
            `${username}'s Inventory - Infocards`,
            `Page ${page + 1}/${totalPages}`
        )
            .addFields(
                { name: 'Name', value: infocard.name, inline: true },
                { name: 'Status', value: isEquipped ? '✅ Equipped' : 'Not Equipped', inline: true }
            );

        // Add image if it exists
        const infocardPath = path.join('./assets/images/infocards', infocard.image);
        let attachment = null;

        if (fs.existsSync(infocardPath)) {
            attachment = new AttachmentBuilder(infocardPath, { name: infocard.image });
            embed.setImage(`attachment://${infocard.image}`);
        }

        return { embed, attachment };
    };

    // Generate the initial page
    const { embed, attachment } = await generatePageEmbed(pageIndex);

    // Send the initial message with pagination buttons
    const message = await interaction.reply({
        embeds: [embed],
        files: attachment ? [attachment] : [],
        components: [
            new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder()
                    .setCustomId(`${interaction.id}-inventory_prev`)
                    .setLabel('Previous')
                    .setEmoji('⬅️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(pageIndex === 0),
                new ButtonBuilder()
                    .setCustomId(`${interaction.id}-inventory_next`)
                    .setLabel('Next')
                    .setEmoji('➡️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(pageIndex === totalPages - 1)
            )
        ],
        fetchReply: true
    });

    // Create a collector for the pagination buttons
    const collector = interaction.channel.createMessageComponentCollector({
        filter: (i) =>
            i.user.id === interaction.user.id &&
            (i.customId === `${interaction.id}-inventory_prev` || i.customId === `${interaction.id}-inventory_next`),
        time: 60000 // 1 minute timeout
    });

    collector.on('collect', async (i) => {
        if (i.customId === `${interaction.id}-inventory_prev`) {
            if (pageIndex > 0) pageIndex--;
        } else if (i.customId === `${interaction.id}-inventory_next`) {
            if (pageIndex < totalPages - 1) pageIndex++;
        }

        await i.deferUpdate();

        const newPage = await generatePageEmbed(pageIndex);

        await interaction.editReply({
            embeds: [newPage.embed],
            files: newPage.attachment ? [newPage.attachment] : [],
            components: [
                new ActionRowBuilder<ButtonBuilder>().addComponents(
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-inventory_prev`)
                        .setLabel('Previous')
                        .setEmoji('⬅️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(pageIndex === 0),
                    new ButtonBuilder()
                        .setCustomId(`${interaction.id}-inventory_next`)
                        .setLabel('Next')
                        .setEmoji('➡️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(pageIndex === totalPages - 1)
                )
            ]
        });
    });

    collector.on('end', async () => {
        try {
            await interaction.editReply({
                components: [] // Remove buttons when collector ends
            });
        } catch (error) {
            // Ignore errors if the message was deleted
        }
    });
} 