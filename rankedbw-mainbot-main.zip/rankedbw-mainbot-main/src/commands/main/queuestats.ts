import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";

export default class QueueStatsCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("queuestats")
    .setDescription("Shows the stats of players in the current game queue.");

  maintenance: boolean = true;

  async execute(interaction: ChatInputCommandInteraction) {
    // await interaction.deferReply();

    // // Get the queue for the current channel
    // const queueDataRaw = await App.Redis.get(`queue:${interaction.channelId}`);
    // if (!queueDataRaw) {
    //   return interaction.editReply({
    //     content: `<:rbw_cross:1387585103563063387> Game not found.`,
    //   });
    // }

    // const queueData = JSON.parse(queueDataRaw) as Queue;

    // if (!queueData || queueData.players.length === 0) {
    //   return interaction.editReply({
    //     content: `<:rbw_cross:1387585103563063387> Game not found.`,
    //   });
    // }

    // Fetch player data for everyone in the queue
    // const playerIds = queueData.players;
    // const players = await prisma.player.findMany({
    //   where: {
    //     userId: {
    //       in: playerIds,
    //     },
    //   },
    //   select: {
    //     userId: true,
    //     minecraftName: true,
    //     totalXp: true,
    //     ...IncludeCurrentSeasonStatistics,
    //   },
    // });

    // if (players.length === 0) {
    //   return interaction.editReply({
    //     content: `<:rbw_cross:1387585103563063387> Could not find player data for the current queue.`,
    //   });
    // }

    // // Sort players by ELO
    // players.sort(
    //   (a, b) => b.PlayerStatistics[0].elo - a.PlayerStatistics[0].elo
    // );

    // // Create the stats embed
    // let statsContent = "";

    // for (const player of players) {
    //   const winRate =
    //     player.PlayerStatistics[0].wins + player.PlayerStatistics[0].losses > 0
    //       ? (
    //           (player.PlayerStatistics[0].wins /
    //             (player.PlayerStatistics[0].wins +
    //               player.PlayerStatistics[0].losses)) *
    //           100
    //         ).toFixed(1)
    //       : "0.0";

    //   statsContent += `**${player.minecraftName}**\n`;
    //   statsContent += `ELO: \`${player.PlayerStatistics[0].elo}\` | W/L: \`${
    //     player.PlayerStatistics[0].wins
    //   }/${player.PlayerStatistics[0].losses}\` (${winRate}%) | Streak: \`${
    //     player.PlayerStatistics[0].streak
    //   }\` | MVPs: \`${player.PlayerStatistics[0].mvps}\` | Level: \`${
    //     getPlayerProgress(player.totalXp).level
    //   }\`\n\n`;
    // }

    // const statsEmbed = embeds.normal(
    //   statsContent || "No player stats available.",
    //   `Queue Stats (${players.length} players)`
    // );

    // return interaction.editReply({
    //   embeds: [statsEmbed],
    // });
  }
}
