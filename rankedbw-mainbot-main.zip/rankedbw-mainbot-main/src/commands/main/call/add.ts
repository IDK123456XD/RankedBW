import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder, PermissionFlagsBits, GuildMember } from 'discord.js';
import { ChildCommand } from '../..';
import settings from '../../../settings';
import { TeamVoiceManager } from '../../../utils/teamVoiceManager';

export default class CallAddCommand extends ChildCommand {
  slashCommand = new SlashCommandSubcommandBuilder()
    .setName("add")
    .setDescription("Add a player to your team voice channel.")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("The user you want to add.")
        .setRequired(true)
    );

  async execute(interaction: ChatInputCommandInteraction) {
    const discordUser = interaction.options.getUser("user", true);

    await interaction.deferReply();

        const member = await interaction.guild?.members.fetch(interaction.user.id);
        if (!member || !member.voice || !member.voice.channel) {
            await interaction.editReply({
                content: `<:rbw_cross:1387585103563063387> You must be in a voice channel to use this command.`,
            });
            return;
        }

    const channel = member.voice.channel;

    if (channel.parentId !== settings.categories.teams) {
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> You must be in a team voice channel to use this command.`,
      });
      return;
    }

    if (
      channel.permissionsFor(discordUser.id)?.has(PermissionFlagsBits.Connect)
    ) {
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> <@${discordUser.id}> already has access to the **${channel.name}** channel.`,
      });
      return;
    }

    await TeamVoiceManager.addCalledUser(
      channel.id,
      discordUser.id,
      interaction.guild
    );

    if (interaction.channel.isThread()) {
      await interaction.editReply({
        content: `<:rbw_check:1387585062530322443> Added \`${discordUser.username}\` to <#${channel.id}>.`,
      });
    } else {
      await interaction.editReply({
        content: `<:rbw_check:1387585062530322443> Added <@${discordUser.id}> to <#${channel.id}>.`,
      });
    }
  }
}
