import { ChatInputCommandInteraction, PermissionFlagsBits, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '../..';
import settings from '../../../settings';
import { prisma } from '@common/database/connectors/prisma';
import App from '../../..';

export default class CallRemoveCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Remove a friend from your game voice chat.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The discord user you want to uncall.')
                .setRequired(true)
        )

    async execute(interaction: ChatInputCommandInteraction) {
        const member = await interaction.guild.members.fetch(interaction.user.id);
        if (!member) return;

        const channel = member.voice.channel;
        if (!channel) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> You must be in a voice channel to use this command.`,
            });
            return;
        }

        if (channel.parentId !== settings.categories.teams) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> You must be in a teams voice channel to use this command.`,
            });
            return;
        }

        if (!channel.permissionsFor(member).has(PermissionFlagsBits.Connect)) {
            await interaction.reply({
                content: `<:rbw_cross:1387585103563063387> You do not have permission to uncall anyone from the **${channel.name}** channel.`,
            });
            return;
        }

        await interaction.deferReply();

        const discordUser = interaction.options.getUser('discord-user');
        if (!discordUser) {
            await interaction.editReply({
                content: `<:rbw_cross:1387585103563063387> You must specify a Discord user.`,
            });
            return;
        }

        const gameData = await prisma.game.findFirst({
            where: {
                OR: [
                    { team1Voice: member.voice.channelId },
                    { team2Voice: member.voice.channelId }
                ]
            },
            include: {
                players: {
                    include: {
                        user: true
                    }
                }
            }
        })

        if (!gameData) {
            await interaction.editReply({
                content: `<:rbw_cross:1387585103563063387> You must be in a game to use this command.`,
            });
            return;
        }

        if (gameData.players.some(x => x.user.userId === discordUser.id)) {
            await interaction.editReply({
                content: `<:rbw_cross:1387585103563063387> You cannot uncall someone who is already in your game.`,
            });
            return;
        }

        if (!channel.permissionsFor(discordUser.id).has(PermissionFlagsBits.Connect)) {
            await interaction.editReply({
                content: `<:rbw_cross:1387585103563063387> <@${discordUser.id}> has not been called into the **${channel.name}** channel.`,
            });
            return;
        }

        await channel.permissionOverwrites.create(discordUser.id, {
            Connect: false,
            Speak: false,
        });

        const removedMember = await interaction.guild.members.fetch(discordUser.id);
        if (removedMember?.voice?.channelId === channel.id) {
            await App.Redis.publish(
                "queue:move",
                JSON.stringify({
                  memberId: removedMember.id,
                  channelId: null,
                  guildId: interaction.guild.id,
                })
              );
        }


        await interaction.editReply({
            content: `<:rbw_check:1387585062530322443> Removed <@${discordUser.id}> from <#${channel.id}>.`,
        });
    }
}