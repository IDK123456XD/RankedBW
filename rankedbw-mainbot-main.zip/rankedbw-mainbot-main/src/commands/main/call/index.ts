export default {
    name: 'Call',
    description: 'Add or remove a player from a call.',
}

export { default as add } from './add';
export { default as remove } from './remove';
export { default as call } from './call';