import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '../..';
import CallAddCommand from './add';
import CallRemoveCommand from './remove';

export default class CallCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('call')
        .setDescription('Run call commands.')

    childCommands: ChildCommand[] = [
        new CallAddCommand(),
        new CallRemoveCommand()
    ];
} 