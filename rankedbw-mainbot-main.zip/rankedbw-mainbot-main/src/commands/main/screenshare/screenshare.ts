import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  ThreadAutoArchiveDuration,
  TextChannel,
  Colors,
} from "discord.js";
import { Command } from "../..";
import settings from "../../../settings";
import embeds from "../../../utils/discord/embeds";
import sendLogs from "../../../utils/logs";
import { prisma } from "@common/database/connectors/prisma";

export default class ScreenshareCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("screenshare")
    .setDescription("Request for a player to be screenshared.")
    .addUserOption((option) =>
      option
        .setName("player")
        .setDescription("The player to screenshare.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("The reason for the screenshare.")
        .setRequired(true)
    )
    .addAttachmentOption((option) =>
      option
        .setName("file")
        .setDescription('Screenshot of "don\'t log" message sent to player.')
        .setRequired(true)
    );

  async execute(interaction: ChatInputCommandInteraction) {
    const player = interaction.options.getUser("player");
    const reason = interaction.options.getString("reason");
    const dontLogFile = interaction.options.getAttachment("file");

    // Defer reply immediately since this command will take time
    await interaction.deferReply({ ephemeral: true });

    // Check if player is trying to screenshare themselves
    if (player.id === interaction.user.id) {
      await interaction.editReply({
        embeds: [embeds.error("You cannot screenshare yourself.")],
      });
      return;
    }

    // Validate the uploaded file
    if (!dontLogFile.contentType?.startsWith("image/")) {
      await interaction.editReply({
        embeds: [
          embeds.error("The uploaded file must be an image (PNG, JPG, etc.)."),
        ],
      });
      return;
    }

    const member = await interaction.guild.members.fetch(player.id);
    if (!member) {
      await interaction.editReply({
        embeds: [embeds.error("Please provide a valid player.")],
      });
      return;
    }

    const playerData = await prisma.player.findFirst({
      where: {
        userId: player.id,
      },
    });

    if (!playerData) {
      await interaction.editReply({
        embeds: [embeds.error("This player does not exist in our database.")],
      });
      return;
    }

    // Check for existing open screenshare for this player
    const existingScreenshare = await prisma.screenshare.findFirst({
      where: {
        targetUserId: player.id,
        status: {
          in: ["OPEN", "CLAIMED"],
        },
      },
    });

    if (existingScreenshare) {
      await interaction.editReply({
        embeds: [
          embeds.error("This player already has an open screenshare request."),
        ],
      });
      return;
    }

    // Get screenshareRequests channel
    const screenshareRequestsChannel = (await interaction.guild.channels.fetch(
      settings.channels.screenshareRequests
    ));
    if (!(screenshareRequestsChannel instanceof TextChannel)) {
      await interaction.editReply({
        embeds: [embeds.error("Screenshare requests channel not found.")],
      });
      return;
    }

    // Create the screenshare thread
    const threadName = `SS: @${player.username}`;
    const thread = await screenshareRequestsChannel.threads.create({
      name: threadName,
      type: ChannelType.PrivateThread,
      autoArchiveDuration: ThreadAutoArchiveDuration.OneHour,
      invitable: false,
      reason: `Screenshare request against ${player.tag} by ${interaction.user.tag}`,
    });

    const actionButtons = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`screenshare_claim_${thread.id}`)
        .setLabel("Claim")
        .setStyle(ButtonStyle.Success)
        .setEmoji("✅"),
      new ButtonBuilder()
        .setCustomId(`screenshare_close_${thread.id}`)
        .setLabel("Close")
        .setStyle(ButtonStyle.Danger)
        .setEmoji("🔒")
    );

    await thread.send({
      content: `${player.toString()} ${interaction.user.toString()}`,
      embeds: [embeds
        .normal(
          `A screenshare request has been made against ${player} by ${interaction.user}\n` +
          `**Reason:** ${reason}\n` +
          `Please wait for a staff member to claim this screenshare request, it will automatically close in 10 minutes if no one claims it.\n`,
          "Screenshare Request"
        )
        .setImage(dontLogFile.url)],
      components: [actionButtons],
    });

    const activeSeason = await prisma.season.findFirst({
      where: {
        active: true,
      },
    });

    // Increment the player's screenshare counter
    await prisma.playerStatistics.upsert({
      where: {
        playerId_seasonId: {
          playerId: playerData.id,
          seasonId: activeSeason.id,
        },
      },
      update: {
        screenshares: {
          increment: 1,
        },
      },
      create: {
        playerId: playerData.id,
        seasonId: activeSeason.id,
        screenshares: 1,
      },
    });

    // Send screenshare request message to the screenshareRequests channel
    const requestMessage = await screenshareRequestsChannel.send({
      embeds: [
        embeds.normal(
          `User ${interaction.user} has requested a screenshare for ${player}.\n\n` +
          `Reason: \`${reason}\`\n` +
          `Status: \`OPEN\``,
          "Screenshare Request",
          false
        ).setColor(Colors.Yellow)
      ],
    });

    // Create screenshare record in database
    await prisma.screenshare.create({
      data: {
        threadId: thread.id,
        targetUserId: player.id,
        requesterUserId: interaction.user.id,
        reason: reason,
        dontLogImageUrl: dontLogFile.url,
        status: "OPEN",
        requestMessageId: requestMessage.id,
      },
    });

    // Send to activeScreenshares channel
    const activeScreensharesChannel = await interaction.guild.channels.fetch(
      settings.channels.activeScreenshares
    );

    if (activeScreensharesChannel?.isTextBased()) {
      const activeEmbed = embeds.normal(
        `User ${interaction.user} has requested a screenshare for ${player} ${thread}.\n\n` +
        `Reason: \`${reason}\`\n` +
        `Status: \`OPEN\``,
        "Screenshare Request",
        false
      ).setColor(Colors.Yellow);

      const viewButton = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId(`screenshare_view_${thread.id}`)
          .setLabel("View Screenshare")
          .setStyle(ButtonStyle.Primary)
          .setEmoji("👁️")
      );

      await activeScreensharesChannel.send({
        content: `<@&${settings.roles.screenshare}>`,
        embeds: [activeEmbed],
        components: [viewButton],
      });
    }

    await interaction.editReply({
      embeds: [embeds.success(`Screenshare request created: ${thread}`)],
    });

    // Send logs after successful reply (don't await to prevent blocking)
    sendLogs(
      `${interaction.user} has created a screenshare request against ${player} for \`${reason}\`. Don't log screenshot attached.`,
      "Screenshare Request"
    ).catch((error) => {
      console.error("Error sending screenshare creation log:", error);
    });
  }
}
