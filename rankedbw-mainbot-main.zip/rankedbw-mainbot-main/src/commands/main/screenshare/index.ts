export default {
    name: 'Screenshare',
    description: 'Screenshare request and management commands.',
}