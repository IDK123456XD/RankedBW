import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';
import { Command } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';
import { GameStatus } from '@common/database/generated';

const formatDuration = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export default class GameCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('game')
        .setDescription('Shows information about a specified game.')
        .addStringOption(option =>
            option.setName('gameid')
                .setDescription('The ID of the game to view.')
                .setRequired(true)
        );

    async execute(interaction: ChatInputCommandInteraction) {
        const gameIdParam = interaction.options.getString('gameid');

        // Fetch the game from the database
        const game = await prisma.game.findFirst({
            where: {
                gameId: {
                    equals: gameIdParam,
                    mode: 'insensitive'
                }
            },
            include: {
                players: {
                    include: {
                        user: true
                    }
                }
            }
        });

        if (!game) {
            return interaction.reply({
                embeds: [embeds.error('Game not found. Please provide a valid game ID.')],
                ephemeral: true
            });
        }

        const team1 = game.players.filter(p => p.discordTeam === 1);
        const team2 = game.players.filter(p => p.discordTeam === 2);

        const gameDuration = game.status !== GameStatus.PENDING ? Math.floor((game.updatedAt.getTime() - game.createdAt.getTime()) / 1000) : 0;

        const formatPlayerName = (player: any) => {
            return `<@${player.user.userId}> - ${player.win ? '🟩' : '🟥'}${player.mvp ? ' 🔥' : ''}`;
        };

        const gameEmbed = embeds.normal(
            undefined,
            `Game ${game.gameId}`
        ).addFields([
            {
                name: "Team 1",
                value: team1.map(p => formatPlayerName(p)).join('\n') || 'None',
                inline: true
            },
            {
                name: "Team 2",
                value: team2.map(p => formatPlayerName(p)).join('\n') || 'None',
                inline: true
            },
            {
                name: "Thread",
                value: game.queueThreadChannelId ? `<#${game.queueThreadChannelId}>` : 'Not specified',
                inline: true
            },
            {
                name: "Status",
                value: `\`${game.status}\``,
                inline: true
            },
            {
                name: "Started At",
                value: `<t:${Math.floor(game.createdAt.getTime() / 1000)}:R>`,
                inline: true
            },
            {
                name: "Scored At",
                value: `<t:${Math.floor(game.updatedAt.getTime() / 1000)}:R>`,
                inline: true
            },
            {
                name: "Duration",
                value: formatDuration(gameDuration),
                inline: true
            }
        ]);

        if (game.reason) {
            gameEmbed.setFooter({
                text: `Reason: ${game.reason}`
            });
        }

        return interaction.reply({
            embeds: [gameEmbed]
        });
    }
} 