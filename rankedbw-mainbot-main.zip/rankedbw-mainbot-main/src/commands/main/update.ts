import {
  ChatInputCommandInteraction,
  GuildMember,
  SlashCommandBuilder,
} from "discord.js";
import { Command } from "..";
import { prisma } from "@common/database/connectors/prisma";
import embeds from "../../utils/discord/embeds";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import { refreshEloData } from "../../utils/eloChecker";

export default class UpdateCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("update")
    .setDescription("Updates your roles and ELO prefix to match the database.");

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true });

    // Get the player data from the database
    const player = await prisma.player.findUnique({
      where: {
        userId: interaction.user.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });

    if (!player) {
      return interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> You are not registered in our database. Please use \`/register\` first.`,
      });
    }

    const member = interaction.member as GuildMember;
    if (!member) {
      return interaction.editReply({
        embeds: [embeds.error("Could not fetch your Discord member data.")],
      });
    }

    await refreshEloData(member, player);

    return interaction.editReply({
      content: `<:rbw_check:1387585062530322443> Your roles and ELO prefix have been updated.`,
    });
  }
}
