import { ChatInputCommandInteraction, SlashCommandBuilder } from "discord.js";
import { Command } from "..";
import settings from "../../settings";
import embeds from "../../utils/discord/embeds";
import { refreshEloData } from "../../utils/eloChecker";
import { getHypixelPlayerData } from "../../utils/hypixel";
import { fetchFullBodySkin, fetchHeadSkin, getUUID, updatePlayerProfile } from "../../utils/minecraft";
import { getSettingsDocument } from "../../utils/settings";
import { prisma } from "@common/database/connectors/prisma";
import App from "../..";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

export default class RenameCommand extends Command {
  slashCommand = new SlashCommandBuilder()
    .setName("rename")
    .setDescription("Rename yourself to Rank Bedwars")
    .addStringOption((option) =>
      option
        .setName("minecraft-name")
        .setDescription("Your Minecraft Name")
        .setRequired(true)
    );

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply();

    const minecraftName = interaction.options.getString("minecraft-name", true);
    const uuid = await getUUID(minecraftName);
    if (!uuid) {
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> That Minecraft name does not exist!`,
      });
      return;
    }

    const nameTaken = await prisma.player.findFirst({
      where: {
        minecraftName: {
          equals: minecraftName,
          mode: "insensitive",
        },
      },
    });

    if (nameTaken && nameTaken.userId !== interaction.user.id) {
      await updatePlayerProfile(nameTaken);
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> That Minecraft name is already taken by a registered user!`,
      });
      return;
    }

    const dbSettings = await getSettingsDocument();
    if (!dbSettings || !dbSettings.hypixelAPIKey) {
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> An error occurred while fetching the Hypixel API Key.`,
      });
      return;
    }

    const hypixelData = await getHypixelPlayerData(
      uuid,
      dbSettings.hypixelAPIKey
    );
    if (!hypixelData) {
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> An error occured while checking your linked Discord account!`,
      });
      return;
    } else if (
      !hypixelData?.player?.socialMedia?.links?.DISCORD ||
      (hypixelData?.player?.socialMedia?.links?.DISCORD.toLowerCase() !==
        interaction.user.username.toLowerCase() &&
        hypixelData?.player?.socialMedia?.links?.DISCORD.toLowerCase() !==
        interaction.user.tag.toLowerCase())
    ) {
      await interaction.editReply({
        embeds: [
          embeds.error(
            `You must link your Discord account to your Hypixel account!\nCheckout <#${settings.channels.howToRegister}> for more information.`,
            "Registration"
          ),
        ],
      });
      return;
    }

    let player = await prisma.player.findFirst({
      where: {
        userId: interaction.user.id,
      },
      include: IncludeCurrentSeasonStatistics,
    });
    let refresh = false;
    if (player) {
      refresh = true;

      const fullBodySkin = await fetchFullBodySkin(uuid);
      const headSkin = await fetchHeadSkin(uuid);

      player = await prisma.player.update({
        where: {
          id: player.id,
        },
        data: {
          minecraftName: hypixelData.player.displayname,
          uuid: uuid,
          fullBodySkin,
          headSkin,
        },
        include: IncludeCurrentSeasonStatistics,

      });
    }

    if (!player) {
      await interaction.editReply({
        content: `<:rbw_cross:1387585103563063387> You are not registered, please use \`/register\` to register!`,
      });
      return;
    }

    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!member) return;

    try {
      if (!member.roles.cache.has(settings.roles.registered)) {
        await App.Redis.publish(
          "change:role",
          JSON.stringify({
            memberId: member.id,
            roleId: settings.roles.registered,
            guildId: settings.guild,
            action: "add",
          })
        );
      }
    } catch (err) {
      void err;
    }

    await refreshEloData(member, player);

    // Build the response message
    const responseMessage = refresh
      ? `You have refreshed your data and have been renamed to \`${minecraftName}\`!`
      : `You have been renamed to \`${minecraftName}\`!`;

    await interaction.editReply({
      content: `<:rbw_check:1387585062530322443> ${responseMessage}`,
    });
  }
}
