import OpenAI from "openai";
import {
  ThreadChannel,
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonBuilder,
  ButtonStyle,
  Attachment,
} from "discord.js";
import { Command } from "..";
import embeds from "../../utils/discord/embeds";
import { prisma } from "@common/database/connectors/prisma";
import {
  GameStatus,
  Game,
  GamePlayer,
  Player,
} from "@common/database/generated/client";
import settings from "../../settings";
import App from "../..";
import sendLogs from "../../utils/logs";
import { getSettingsDocument } from "../../utils/settings";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import { closeGame } from "../../utils/closeGame";
import { GameHandler } from "../../utils/gameHandler";

// Define a type for game players including their user data
type GamePlayerWithUser = GamePlayer & { user: Player };

export interface BedwarsGameResults {
  firstKiller: { name: string; kills: number };
  secondKiller: { name: string; kills: number };
  thirdKiller: { name: string; kills: number };
  winners: {
    players: string[];
  };
  losers: {
    players: string[];
  };
  manualReviewNeeded?: boolean;
}

export default class SubmitScreenshotCommand extends Command {
  private openai: OpenAI; // Declare OpenAI instance as a class property

  constructor() {
    super();
    this.openai = new OpenAI({ apiKey: process.env.OPENAI_KEY }); // Initialize in constructor
  }

  slashCommand = new SlashCommandBuilder()
    .setName("submit")
    .setDescription("Submit a screenshot of game stats.")
    .addAttachmentOption((opt) =>
      opt
        .setName("screenshot")
        .setDescription("Screenshot of the game stats.")
        .setRequired(true)
    );

  // Modern structured output schema
  private readonly responseSchema = {
    type: "object",
    properties: {
      firstKiller: {
        type: "object",
        description: "The player who got 1st Killer and their kill count",
        properties: {
          name: { type: "string", description: "Player name as shown" },
          kills: { type: "integer", description: "Number of kills" },
        },
        required: ["name", "kills"],
      },
      secondKiller: {
        type: "object",
        description: "The player who got 2nd Killer and their kill count",
        properties: {
          name: { type: "string" },
          kills: { type: "integer" },
        },
        required: ["name", "kills"],
      },
      thirdKiller: {
        type: "object",
        description: "The player who got 3rd Killer and their kill count",
        properties: {
          name: { type: "string" },
          kills: { type: "integer" },
        },
        required: ["name", "kills"],
      },
      winners: {
        type: "object",
        description: "The remaining team and its players",
        properties: {
          players: {
            type: "array",
            items: { type: "string" },
            description:
              "List of player names near the top of the screenshot after the winning team color",
          },
        },
        required: ["players"],
      },
      losers: {
        type: "object",
        description: "The losing team and its players",
        properties: {
          players: {
            type: "array",
            items: { type: "string" },
            description:
              "List all of the players who were not included in the winners team",
          },
        },
        required: ["players"],
      },
      manualReviewNeeded: {
        type: "boolean",
        description:
          "Set to true if there is any reasonable doubt about the accuracy of the extracted data. This should be used if the image is unclear, blurry, or if any data point seems ambiguous or contradictory.",
        default: false,
      },
    },
    required: ["firstKiller", "secondKiller", "thirdKiller", "winners"],
    additionalProperties: false,
  } as const;

  private async handleAIScoringFailure(
    interaction: ChatInputCommandInteraction,
    game: Game & { players: GamePlayerWithUser[] },
    screenshot: Attachment,
    data: BedwarsGameResults,
    error: string
  ): Promise<void> {
    console.error("AI scoring failed:", error);
    console.log(data);

    try {
      // Send to failed games channel for manual scoring
      const failedGamesChannel = await interaction.guild.channels.fetch(
        settings.channels.failedGames
      );

      let manualScoreMessageId: string | null = null;

      if (failedGamesChannel?.isTextBased()) {
        const team1Players = game.players.filter(
          (p: GamePlayerWithUser) => p.discordTeam === 1
        );
        const team2Players = game.players.filter(
          (p: GamePlayerWithUser) => p.discordTeam === 2
        );

        const playerOptions = game.players.slice(0, 25).map((p: GamePlayerWithUser) => {
          const displayName = p.user.nickname
            ? `${p.user.minecraftName} | ${p.user.nickname}`
            : p.user.minecraftName;

          return new StringSelectMenuOptionBuilder()
            .setLabel(displayName)
            .setValue(`${p.user.userId}`)
            .setDescription(`Team ${p.discordTeam}`);
        });

        let selectMenuRow: ActionRowBuilder<StringSelectMenuBuilder> | undefined;
        if (playerOptions.length > 0) {
          const maxValues = Math.min(3, playerOptions.length);
          const mvpSelectMenu = new StringSelectMenuBuilder()
            .setCustomId(`manual_score_mvp_${game.gameId}`)
            .setPlaceholder(`Select MVPs (1-${maxValues} players)`)
            .setMinValues(1)
            .setMaxValues(maxValues)
            .addOptions(playerOptions);

          selectMenuRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(mvpSelectMenu);
        }

        // Create action buttons
        const actionButtons =
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder()
              .setCustomId(`manual_score_team1_${game.gameId}`)
              .setLabel("Team 1 Wins")
              .setStyle(ButtonStyle.Success)
              .setEmoji("🥇"),
            new ButtonBuilder()
              .setCustomId(`manual_score_team2_${game.gameId}`)
              .setLabel("Team 2 Wins")
              .setStyle(ButtonStyle.Success)
              .setEmoji("🥇"),
            new ButtonBuilder()
              .setCustomId(`manual_score_void_${game.gameId}`)
              .setLabel("Void Game")
              .setStyle(ButtonStyle.Danger)
              .setEmoji("❌")
          );

        const failedEmbed = embeds
          .normal(
            `**Game ID:** ${game.gameId}\n` +
            `**Thread:** <#${game.queueThreadChannelId}>\n` +
            `**Submitted by:** ${interaction.user}\n` +
            `**AI Error:** ${error || "Unknown error"}\n\n` +
            `**Team 1 (${team1Players.length}):**\n` +
            `${team1Players
              .map((p: GamePlayerWithUser) => {
                const displayName = p.user.nickname
                  ? `${p.user.minecraftName} | ${p.user.nickname}`
                  : p.user.minecraftName;
                return `<@${p.user.userId}> (${displayName})`;
              })
              .join("\n")}\n\n` +
            `**Team 2 (${team2Players.length}):**\n` +
            `${team2Players
              .map((p: GamePlayerWithUser) => {
                const displayName = p.user.nickname
                  ? `${p.user.minecraftName} | ${p.user.nickname}`
                  : p.user.minecraftName;
                return `<@${p.user.userId}> (${displayName})`;
              })
              .join("\n")}`,
            "AI Scoring Failed - Manual Review Required"
          )
          .setImage(screenshot.url);

        const componentRows = [] as any[];
        if (selectMenuRow) componentRows.push(selectMenuRow);
        componentRows.push(actionButtons);

        const manualScoreMessage = await failedGamesChannel.send({
          embeds: [failedEmbed],
          components: componentRows,
        });
        manualScoreMessageId = manualScoreMessage.id;
      }

      await App.Redis.set(
        `manualScore:${game.gameId}`,
        JSON.stringify({
          gameId: game.gameId,
          gameDatabaseId: game.id,
          threadId: game.queueThreadChannelId,

          submittedBy: interaction.user.id,
          players: game.players.map((p: GamePlayerWithUser) => ({
            userId: p.user.userId,
            minecraftName: p.user.minecraftName,
            nickname: p.user.nickname,
            discordTeam: p.discordTeam,
            gamePlayerId: p.id,
          })),
          selectedMvps: [],
          winningTeam: null,
          messageId: manualScoreMessageId, // Store the message ID
        })
      ); // Expire after 1 hour

      await prisma.game.update({
        where: { id: game.id },
        data: {
          status: GameStatus.MANUAL_REVIEW,
        },
      });

      // Send logs to scoring channel
      await sendLogs(
        `AI failed to score Game **#${game.gameId}**. Game sent to failed games channel for manual review.
        **Reason:** ${error || "Unknown error"}
        **Screenshot:** ${screenshot.url}
        **Submitted by:** ${interaction.user}`,
        "AI Scoring Failed - Manual Review",
        undefined,
        settings.channels.scoring
      );
    } catch (handleError) {
      console.error("Error handling AI scoring failure:", handleError);
      // No need to edit reply here, initial reply already sent.
      await sendLogs(
        `Critical Error in handling AI scoring failure for Game **#${game.gameId}**.
        **Error:** ${handleError.message || "Unknown error during failure handling"}
        **Screenshot:** ${screenshot.url}
        **Submitted by:** ${interaction.user}`,
        "AI Scoring Critical Error",
        undefined,
        settings.channels.scoring
      );
    }
  }

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true });

    try {
      const game = await prisma.game.findFirst({
        where: {
          queueThreadChannelId: interaction.channelId,
        },
        include: {
          players: {
            include: {
              user: {
                include: IncludeCurrentSeasonStatistics,
              },
            },
          },
        },
      });

      if (!game) {
        return await interaction.editReply({
          embeds: [embeds.error("This is not a valid game channel.")],
        });
      }

      // Check game status to prevent double submissions/scorings
      if (
        game.status !== GameStatus.PENDING &&
        game.status !== GameStatus.VOIDED
      ) {
        return await interaction.editReply({
          embeds: [
            embeds.error(
              `This game has already been ${game.status
                .toLowerCase()
                .replace("_", " ")}.` +
              ` You cannot submit scores for it again.`
            ),
          ],
        });
      }

      const screenshotAttachment = interaction.options.getAttachment(
        "screenshot",
        true
      );

      if (!screenshotAttachment.contentType?.startsWith("image")) {
        return await interaction.editReply({
          embeds: [embeds.error("The attached file is not an image.")],
        });
      }

      // Update game status to SUBMITTED
      await prisma.game.update({
        where: { id: game.id },
        data: { status: GameStatus.SUBMITTED },
      });

      // Lock the game channel (thread) immediately
      const gameThread = interaction.channel as ThreadChannel;
      if (gameThread && gameThread.isThread()) {
        await gameThread.setLocked(true);
        await gameThread.setArchived(true);
      }

      // Immediate reply to the user (ephemeral)
      await interaction.editReply({
        content: `<:rbw_check:1387585062530322443> Screenshot submitted!`,
      });

      // Send non-ephemeral notice in the game channel
      await interaction.channel.send({
        embeds: [
          embeds.normal(
            `A screenshot has been submitted for this game by ${interaction.user}.` +
            ` The game is now being processed by the AI.` +
            `\n\nAll game channels will close and players will be moved to the waiting room in 30 seconds.`,
            "Game Submission Received"
          ).setImage(screenshotAttachment.url),
        ],
      });

      // Schedule closeGame after 30 seconds, regardless of AI outcome
      setTimeout(async () => {
        await closeGame(interaction, game);
      }, 30000); // 30 seconds delay

      const team1List = game.players
        .filter((x: any) => x.discordTeam === 1)
        .map((x: any) => `${x.user.minecraftName}${x.user.nickname ? ` | ${x.user.nickname}` : ''}`)
        .join(", ");

      const team2List = game.players
        .filter((x: any) => x.discordTeam === 2)
        .map((x: any) => `${x.user.minecraftName}${x.user.nickname ? ` | ${x.user.nickname}` : ''}`)
        .join(", ");

      const dbSettings = await getSettingsDocument();
      const teamSize = dbSettings.teamSize;

      // 2. Call OpenAI with specific error handling
      const model = process.env.OPENAI_MODEL || "gpt-4.1";
      let resp;
      try {
        resp = await this.openai.chat.completions.create({
        model,
        messages: [
          {
            role: "system",
            content: `You are analyzing a Minecraft BedWars screenshot. Your goal is to accurately extract game results. 
                        - The game has a team size of ${teamSize} players per team. 
                        - Extract: 1st Killer (name & kills), 2nd Killer (name & kills), 3rd Killer (name & kills), Winners (all ${teamSize} players), and Losers (all ${teamSize} players).
                        - Focus on the final game summary screen, typically showing 'GAME STATS' or similar. 
                        - When determining the winning team, prioritize the team with the majority of its players present in the winning message, even if not all team members are shown. 
                        - Only ONE full team can win. If Team 1 wins, ALL players on Team 1 are winners, and ALL players on Team 2 are losers. If Team 2 wins, ALL players on Team 2 are winners, and ALL players on Team 1 are losers. There are no in-betweens or individual winners/losers from opposing teams.
                        - Each player can only earn one MVP per game.
                        - Ensure all extracted player names are clearly visible and match one of the provided in-game names exactly, or a close nickname. 
                        - You must infer the status of all players from the game (provided in the 'possible in-game player names' list) as either winners or losers, even if they are not explicitly shown in the screenshot. 
                        - The 'winners' array MUST contain exactly ${teamSize} player names. If fewer are explicitly identified, infer the remaining winners from the provided player list. 
                        - The 'losers' array MUST contain exactly ${teamSize} player names. If fewer are explicitly identified, infer the remaining losers from the provided player list.
                        - Make sure to include all players in the losers list, even if they are not explicitly shown in the screenshot.
                        - If there is any reasonable doubt about the accuracy of the extracted data (e.g., blurry image, ambiguous text, names not clearly matching the provided list, or contradictory information), set 'manualReviewNeeded' to true. Otherwise, set it to false. 
                        - If at least 3 of the players in the winning team from the screenshot do not match with one of the provided team lists, set 'manualReviewNeeded' to true.
                        - The player team 1 and team 2 lists can include both the player minecraft name and nickname in the format of minecraftName | nickname.
                        - In the screenshot the player may have either the nickname or the minecraft name, so you must check both.
                        - Some players nicknames might not be present in the screenshot if they are not nicked in the game.
                        - Make sure to return the players minecraftName and not the nickname of the player even if the nickname is shown in the screenshot.
                        - If the screenshot is not clear enough to determine the winners and losers, set 'manualReviewNeeded' to true.
                        - ONLY set 'manualReviewNeeded' to true if you are genuinely uncertain and believe a human needs to intervene.
                        - If there is text that contains [VIP], [VIP+], [MVP], [MVP+], or [MVP++] in the screenshot, ignore that as it's not part the player name, but to the right of it is the actual player's name.
                        - In the screenshot under the "Bed Wars" text in the minecraft chat in the bottom left of the screenshot, there is a color either (red, blue, green, or yellow) that indicates the list of the winning players.`,
          },
          {
            role: "system",
            content: `Here are the possible in‑game players on team 1: ${team1List} and here are the possible in‑game players on team 2: ${team2List}`,
          },
          {
            role: "user",
            content: [
              {
                type: "image_url",
                image_url: { url: screenshotAttachment.url },
              },
            ],
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "bedwars_game_results",
            schema: this.responseSchema,
          },
        },
      });
      } catch (apiError: any) {
        await this.handleAIScoringFailure(
          interaction,
          game as any,
          screenshotAttachment,
          {
            firstKiller: { name: "", kills: 0 },
            secondKiller: { name: "", kills: 0 },
            thirdKiller: { name: "", kills: 0 },
            winners: { players: [] },
            losers: { players: [] },
            manualReviewNeeded: true
          },
          `AI scoring failed: ${apiError.message || apiError}`
        );
        return;
      }

      // 3. Parse OpenAI response with error handling
      let data: BedwarsGameResults;
      try {
        data = JSON.parse(resp.choices[0].message.content!) as BedwarsGameResults;
      } catch (parseError: any) {
        await this.handleAIScoringFailure(
          interaction,
          game as any,
          screenshotAttachment,
          {
            firstKiller: { name: "", kills: 0 },
            secondKiller: { name: "", kills: 0 },
            thirdKiller: { name: "", kills: 0 },
            winners: { players: [] },
            losers: { players: [] },
            manualReviewNeeded: true
          },
          `Failed to parse AI response: ${parseError.message}`
        );
        return;
      }

      try {
        console.log("AI raw result (game", game.gameId, "):", JSON.stringify(data));
      } catch {}

      const allPlayerNameVariants = game.players.map((p: any) => ({
        minecraft: p.user.minecraftName,
        nickname: p.user.nickname?.toLowerCase()
      }));
      const winnerSet = new Set(
        data.winners.players.map(w => w.toLowerCase())
      );
      if (!data.losers.players.length || data.losers.players.length !== teamSize) {
        const inferredLosers = game.players
          .filter((p: any) => {
            const nameLower = p.user.minecraftName.toLowerCase();
            const nickLower = p.user.nickname?.toLowerCase();
            return !Array.from(winnerSet).some((w: string) => w === nameLower || (nickLower && w === nickLower));
          })
          .map((p: any) => p.user.minecraftName);
        data.losers.players = inferredLosers.slice(0, teamSize); 
      }

      // Validate that we have the required data and check manual review flag
      const invalidReason = checkInvalidAiResponse(data, teamSize);
      if (typeof invalidReason === 'string') {
        this.handleAIScoringFailure(interaction, game, screenshotAttachment, data, invalidReason);

        return;
      }

      // Find winning/losing team
  const team1 = game.players.filter((p: any) => p.discordTeam === 1);
  const team2 = game.players.filter((p: any) => p.discordTeam === 2);

      // 3. Count how many from each team appear in aiWinnerNames
      const matchCount = (team: GamePlayerWithUser[]) =>
        team.reduce((count, p) => {
          const nameLower = p.user.minecraftName.toLowerCase();
          const nickLower = p.user.nickname?.toLowerCase();
          return count + (data.winners.players.some(n =>
            n.toLowerCase() === nameLower ||
            (nickLower && n.toLowerCase() === nickLower)
          ) ? 1 : 0);
        }, 0);

      // 4. Pick the side with more matches
      const winningTeamNumber = matchCount(team1) >= matchCount(team2) ? 1 : 2;

      // 4. Pick MVPs
      const killers = [data.firstKiller, data.secondKiller, data.thirdKiller];
      const maxKills = Math.max(...killers.map((k) => k.kills));
      const mvps = killers.filter((k) => k.kills === maxKills).map((k) => k.name);
      const mvpDiscordUserIds = game.players
        .filter((x: any) => mvps.some(p => p.toLowerCase() === x.user.minecraftName.toLowerCase() || p.toLowerCase() === x.user.nickname?.toLowerCase()))
        .map((x: any) => x.user.userId);

      await GameHandler.scoreGame(game.gameId, interaction.guild, winningTeamNumber, mvpDiscordUserIds, undefined, true);
    } catch (error: any) {
      console.error("Error during submit command execution:", error);

      if (interaction.deferred || interaction.replied) {
        await interaction.editReply({
          embeds: [
            embeds.error(
              `An unexpected error occurred during game submission: ${error.message || "Unknown error"}`
            ),
          ],
        });
      } else {
        await interaction.reply({
          embeds: [
            embeds.error(
              `An unexpected error occurred during game submission: ${error.message || "Unknown error"}`
            ),
          ],
          ephemeral: true,
        });
      }

      await sendLogs(
        `Critical Error in /submit command for Game **#${interaction.channelId}**.
        **Error:** ${error.message || "Unknown error"}
        **Submitted by:** ${interaction.user}`,
        "Submit Command Critical Error",
        undefined,
        settings.channels.scoring
      );
    }
  }
}

function checkInvalidAiResponse(data: BedwarsGameResults, teamSize: number) {
  if (!data.firstKiller?.name) return 'First Killer is not set';
  if (!data.secondKiller?.name) return 'Second Killer is not set';
  if (!data.thirdKiller?.name) return 'Third Killer is not set';
  if (!data.winners?.players?.length) return 'Winners are not set';
  if (data.winners.players.length !== teamSize) return 'Winners are not set';
  if (data.manualReviewNeeded) return 'Manual review requested by AI';
  return null;
}