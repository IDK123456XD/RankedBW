import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, ComponentType, Interaction, SlashCommandBuilder, StringSelectMenuBuilder } from 'discord.js';
import { ChildCommand, Command, ParentCommand } from '.';
import App, { CommandCategoryInfo } from '..';
import embeds from '../utils/discord/embeds';

export default class HelpCommand extends Command {
    slashCommand = new SlashCommandBuilder()
        .setName('help')
        .setDescription('View information on all commands.')
        .addStringOption((option) =>
            option
                .setName('category')
                .setDescription('The category of commands to view.')
                .setRequired(false)
                .addChoices(...buildOptions())
        );

    async execute(interaction: ChatInputCommandInteraction,) {
        const optionCategory = interaction.options.getString('category');
        const categorySequence: string[] = optionCategory ? [optionCategory] : [];
        const category = getCategory(categorySequence);

        await interaction.reply({
            embeds: [buildEmbed(category)],
            components: buildActionRow(interaction, category)
        });

        const collector = interaction.channel?.createMessageComponentCollector({
            filter: (i) => i.user.id === interaction.user.id &&
                i.customId.includes(interaction.id) &&
                i.customId.includes('help-'),
            time: 60000,
        });

        collector?.on('collect', async (i) => {
            if (i.componentType !== ComponentType.Button && i.componentType !== ComponentType.StringSelect) return;

            if (i.componentType === ComponentType.StringSelect && i.customId.includes('help-category')) {
                await i.deferUpdate();

                categorySequence.push(i.values[0]);
                const category = getCategory(categorySequence);

                await interaction.editReply({
                    embeds: [buildEmbed(category)],
                    components: buildActionRow(interaction, category)
                });
            } else if (i.componentType === ComponentType.Button && i.customId.includes('help-back')) {
                await i.deferUpdate();
                categorySequence.pop();

                const category = getCategory(categorySequence);
                await interaction.editReply({
                    embeds: [buildEmbed(category)],
                    components: buildActionRow(interaction, category)
                });
            }
        });

        collector?.on('end', async () => {
            await interaction.editReply({
                components: [],
            });
        });
    }
}

function getCategory(categorySequence: string[]) {
    let category = App.commandMenu.find(x => x.name === categorySequence[0]);
    if (category && category.sub.length > 0 && categorySequence.length > 1) {
        for (let i = 1; i < categorySequence.length; i++) {
            category = category.sub.find(x => x.name === categorySequence[i]);
        }
    }
    return category;
}

function buildFields(category?: CommandCategoryInfo) {
    if (!category) return [
        ...App.commandMenu.map((x, i) => ({
            name: `${i + 1}. ${x.name}`,
            value: x.description,
            inline: false
        }))
    ]
    else {
        const parentCommand = category.commands.find(x => x instanceof ParentCommand);
        const formattedCommands = [];

        for (const command of category.commands) {
            if (command instanceof ChildCommand) {
                formattedCommands.push({
                    name: `/${parentCommand?.slashCommand.name} ${command.slashCommand.name}`,
                    value: command.slashCommand.description,
                    inline: false
                });
            } else if (command instanceof Command) {
                formattedCommands.push({
                    name: `/${command.slashCommand.name}`,
                    value: command.slashCommand.description,
                    inline: false
                });
            }
        }

        return formattedCommands;
    }
}

function buildEmbed(category?: CommandCategoryInfo) {
    return embeds
        .normal(null, 'Ranked Bedwars Help Menu' + (category ? ` - ${category.name}` : ''))
        .setThumbnail(App.client.user?.displayAvatarURL())
        .addFields(buildFields(category))
}

function buildActionRow(interaction: Interaction, category?: CommandCategoryInfo) {
    const options = !category
        ? App.commandMenu.map(x => ({
            label: x.name,
            value: x.name,
            description: x.description.length > 97
                ? x.description.slice(0, 97) + '...'
                : x.description
        }))
        : category.sub.map(x => ({
            label: x.name,
            value: x.name,
            description: x.description.length > 97
                ? x.description.slice(0, 97) + '...'
                : x.description
        }));

    const components = [];
    if (options.length) {
        components.push(
            new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId(`help-category:${interaction.id}`)
                    .setPlaceholder('Select a Category')
                    .addOptions(options),
            ) as ActionRowBuilder<StringSelectMenuBuilder>
        )
    }

    if (category) {
        components.push(
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`help-back:${interaction.id}`)
                    .setLabel('Back')
                    .setStyle(ButtonStyle.Secondary),
            ) as ActionRowBuilder<ButtonBuilder>
        )
    }

    return components;
}

function buildOptions(category?: CommandCategoryInfo) {
    const options = !category
        ? App.commandMenu.map(x => ({ name: x.name, value: x.name }))
        : category.sub.map(x => ({ name: x.name, value: x.name }));

    return options;
}