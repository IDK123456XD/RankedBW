import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import PitAddCommand from './add';
import PitRemoveCommand from './remove';
import PitListCommand from './list';

export default class PitCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('pit')
        .setDescription('Run pit commands.')

    childCommands: ChildCommand[] = [
        new PitAddCommand(),
        new PitRemoveCommand(),
        new PitListCommand()
    ];
} 