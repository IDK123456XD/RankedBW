import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';

export default class PitRemoveCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Remove a player from the pit role.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The discord user you want to remove.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for removing the player from PIT.')
                .setRequired(false)
        )

    requiredRoles: string[] = [settings.roles.pitOwner, settings.roles.pitManager, settings.roles.administrator, settings.roles.owner];

    async execute(interaction: ChatInputCommandInteraction) {
        const discordUser = interaction.options.getUser('discord-user');
        const reason = interaction.options.getString('reason');

        const pitRole = await interaction.guild.roles.fetch(settings.roles.pit);
        if (!pitRole) {
            interaction.reply({
                embeds: [embeds.error('PIT role not found.')],
                ephemeral: true,
            });
            return;
        }

        const member = await interaction.guild.members.fetch(discordUser.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not found as a member in this guild.`)],
                ephemeral: true,
            });
            return;
        }

        if (!member.roles.cache.has(pitRole.id)) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not part of the PIT role.`)],
                ephemeral: true,
            });
            return;
        }

        await member.roles.remove(pitRole);
        
        // Log to pit logs channel
        const pitLogsChannel = await interaction.guild.channels.fetch(settings.channels.pitLogs);
        if (pitLogsChannel && pitLogsChannel.isTextBased()) {
            const logMessage = `${interaction.user} has removed ${discordUser} from PIT.${reason ? `\n**Reason:** ${reason}` : ''}`;
            await pitLogsChannel.send({
                embeds: [embeds.error(logMessage, 'PIT Role Removed', false)]
            });
        }

        await interaction.reply({
            content: `${discordUser} has been removed from PIT.`,
        });
    }
}