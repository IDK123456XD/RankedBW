export default {
    name: 'Pit',
    description: 'Run pit commands.',
}