import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import Paginator from '../../utils/discord/paginator';
import { prisma } from '@common/database/connectors/prisma';

export default class PitListCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('List all of the pit players.')

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply();

        try {
            const guild = await interaction.guild.fetch();
            const pitOwnerRole = await guild.roles.fetch(settings.roles.pitOwner);
            const pitRole = await guild.roles.fetch(settings.roles.pit);
            const pitManagerRole = await guild.roles.fetch(settings.roles.pitManager);

            if (!pitRole) {
                await interaction.editReply({
                    embeds: [embeds.error('PIT role not found.')],
                });
                return;
            }

            if (!pitManagerRole) {
                await interaction.editReply({
                    embeds: [embeds.error('PIT Manager role not found.')],
                });
                return;
            }

            if (!pitOwnerRole) {
                await interaction.editReply({
                    embeds: [embeds.error('PIT Owner role not found.')],
                });
                return;
            }

            // Fetch guild members to populate the cache
            await guild.members.fetch();

            // Get managers and regular members
            const pitOwners = Array.from(pitOwnerRole.members.values());
            const pitManagers = Array.from(pitManagerRole.members.values());
            const pitPlayers = Array.from(pitRole.members.values());

            // Filter out managers from regular members list to avoid duplicates
            const ownerIds = new Set(pitOwners.map(o => o.id));
            const managerIds = new Set(pitManagers.map(m => m.id));
            const filteredPitPlayers = pitPlayers.filter(player => !ownerIds.has(player.id) && !managerIds.has(player.id));

            // Build the member list with hierarchy
            let membersList = '';

            if (pitOwners.length > 0) {
                membersList += `**PIT Owners (${pitOwners.length}):**\n`;
                for (const owner of pitOwners) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: owner.id }
                    });
                    membersList += `${owner} | \`${playerData?.minecraftName || owner.user.username}\`\n`;
                }
                membersList += '\n';
            }

            // Add managers section
            if (pitManagers.length > 0) {
                membersList += `**PIT Managers (${pitManagers.length}):**\n`;
                for (const manager of pitManagers) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: manager.id }
                    });
                    membersList += `${manager} | \`${playerData?.minecraftName || manager.user.username}\`\n`;
                }
                membersList += '\n';
            }

            // Add regular members section (excluding managers)
            if (filteredPitPlayers.length > 0) {
                membersList += `**PIT Members (${filteredPitPlayers.length}):**\n`;
                for (const player of filteredPitPlayers) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: player.id }
                    });
                    membersList += `${player} | \`${playerData?.minecraftName || player.user.username}\`\n`;
                }
            }

            if (!membersList.trim()) {
                await interaction.editReply({
                    embeds: [embeds.error('No PIT players found.')],
                });
                return;
            }

            // Split the content for pagination
            const lines = membersList.trim().split('\n');
            const totalPages = Math.ceil(lines.length / 30);

            if (totalPages <= 1) {
                // Single page, no pagination needed
                await interaction.editReply({
                    embeds: [embeds.normal(membersList, 'PIT List', false)]
                });
            } else {
                // Multiple pages, use pagination
                await new Paginator(interaction, totalPages, async (pageIndex) => {
                    const pageLines = lines.slice(pageIndex * 30, (pageIndex + 1) * 30);

                    return embeds.normal(
                        pageLines.join('\n'),
                        'PIT List', false
                    );
                }, 0, false, false).start()
            }

        } catch (error) {
            console.error('Error fetching PIT members:', error);
            await interaction.editReply({
                embeds: [embeds.error('Failed to fetch PIT members. Please try again.')],
            });
        }
    }
}