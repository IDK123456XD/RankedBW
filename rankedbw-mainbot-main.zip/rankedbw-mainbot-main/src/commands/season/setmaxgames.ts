import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '../index';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class SeasonSetMaxGamesCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('setmaxgames')
        .setDescription('Sets the maximum number of scored games allowed for the active season.')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('The maximum number of games. (0 = no limit)')
                .setRequired(true)
        );

    requiredRoles: string[] = [
        settings.roles.administrator,
        settings.roles.owner,
    ];

    async execute(interaction: ChatInputCommandInteraction) {
        const amount = interaction.options.getInteger('amount', true);

        if (amount < 0) {
            await interaction.reply({
                embeds: [embeds.error('Amount cannot be negative.', 'Invalid Amount')],
                ephemeral: true,
            });
            return;
        }

        const activeSeason = await prisma.season.findFirst({
            where: { active: true }
        });

        if (!activeSeason) {
            await interaction.reply({
                embeds: [embeds.error('No active season found to set max games for.', 'No Active Season')],
                ephemeral: true,
            });
            return;
        }

        await prisma.season.update({
            where: { id: activeSeason.id },
            data: {
                maxGames: amount
            }
        });

        await interaction.reply({
            embeds: [embeds.success(`Max games for season **${activeSeason.name}** has been set to **${amount}**.`, 'Max Games Set')],
        });
    }
} 