import {
  ChatInputCommandInteraction,
  SlashCommandSubcommandBuilder,
} from "discord.js";
import { ChildCommand } from "..";
import { prisma } from "@common/database/connectors/prisma";
import embeds from "../../utils/discord/embeds";
import App from "../../index";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";
import { refreshEloData } from "../../utils/eloChecker";

export default class SeasonEndCommand extends ChildCommand {
  slashCommand = new SlashCommandSubcommandBuilder()
    .setName("end")
    .setDescription("End the current active season");

  async execute(interaction: ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true });

    // Find the active season
    const activeSeason = await prisma.season.findFirst({
      where: {
        active: true,
      },
    });

    if (!activeSeason) {
      return interaction.editReply({
        embeds: [embeds.error("There is no active season to end.")],
      });
    }

    // Get top players for this season
    const topPlayers = await prisma.playerStatistics.findMany({
      where: {
        seasonId: activeSeason.id,
      },
      orderBy: {
        elo: "desc",
      },
      take: 3,
      include: {
        player: {
          select: {
            minecraftName: true,
          },
        },
      },
    });

    // End the season
    await prisma.season.update({
      where: {
        id: activeSeason.id,
      },
      data: {
        active: false,
        endDate: new Date(),
      },
    });

    // Create top player records
    const topPlayerData = topPlayers.map((player, index) => ({
      playerId: player.playerId,
      finalElo: player.elo,
      position: index + 1,
      seasonId: activeSeason.id,
    }));

    if (topPlayerData.length > 0) {
      await prisma.seasonTopPlayer.createMany({
        data: topPlayerData
      });
    }

    // Reset all players' stats and roles
    const allPlayers = await prisma.player.findMany({
      include: IncludeCurrentSeasonStatistics,
    });
    const guild = await App.client.guilds.fetch(interaction.guildId);

    if (!guild) {
      console.error("Guild not found for role reset.");
      return interaction.editReply({
        embeds: [
          embeds.error(
            "Failed to reset player roles: Discord guild not found."
          ),
        ],
      });
    }

    let playersResetCount = 0;
    for (const player of allPlayers) {
      try {
        // Reset player stats in the database
        await prisma.player.update({
          where: {
            id: player.id,
          },
          data: {
            totalXp: 0,
            lastPlayed: null,
            nickname: null,
          },
        });

        // Refresh player's Discord roles and nickname
        const member = await guild.members
          .fetch(player.userId)
          .catch((): null => null);
        if (member) {
          await refreshEloData(member, player);
        } else {
          console.log(
            `Could not find Discord member for player ${player.minecraftName} (${player.userId}). Skipping role refresh.`
          );
        }
        playersResetCount++;
      } catch (error) {
        console.error(
          `Failed to reset stats and roles for player ${player.minecraftName} (${player.userId}):`,
          error
        );
      }
    }

    // Format top players for the announcement
    const topPlayersText = topPlayers
      .map(
        (player, index) =>
          `${index + 1}. ${player.player.minecraftName} (${player.elo} ELO)`
      )
      .join("\n");

    const successEmbed = embeds.success(
      `
            Season "${activeSeason.name}" has ended!
            
            **Top Players:**
            ${topPlayersText || "No top players recorded for this season."}
            
            **✅ Actions Completed:**
            - Season ended and top players recorded
            - All player stats reset for the new season
            - All active players' roles have been updated to Coal
            - ${playersResetCount} players had their stats and roles reset.

            Thank you to everyone who participated. A new season can now be started.
            `,
      "Season Ended"
    );

    return interaction.editReply({
      embeds: [successEmbed],
    });
  }
}
