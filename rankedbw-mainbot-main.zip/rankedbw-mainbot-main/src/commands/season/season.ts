import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import SeasonStartCommand from './start';
import SeasonEndCommand from './end';
import SeasonEditNameCommand from './editname';
import SeasonArchiveCommand from './archive';
import SeasonSetMaxGamesCommand from './setmaxgames';
import SeasonListCommand from './list';
import SeasonInfoCommand from './info';
import settings from '../../settings';

export default class SeasonCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('season')
        .setDescription('Run season commands.')

    requiredRoles: string[] = [settings.roles.developer, settings.roles.owner];

    childCommands: ChildCommand[] = [
        new SeasonStartCommand(),
        new SeasonEndCommand(),
        new SeasonEditNameCommand(),
        new SeasonArchiveCommand(),
        new SeasonSetMaxGamesCommand(),
        new SeasonListCommand(),
        new SeasonInfoCommand(),
    ];
} 