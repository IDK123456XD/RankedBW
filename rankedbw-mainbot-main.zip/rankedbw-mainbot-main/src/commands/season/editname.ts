import { AutocompleteInteraction, ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';

export default class SeasonEditNameCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('editname')
        .setDescription('Rename a season')
        .addStringOption(option =>
            option
                .setName('season')
                .setDescription('The name of the season to edit')
                .setRequired(true)
                .setAutocomplete(true)
        )
        .addStringOption(option =>
            option
                .setName('new_name')
                .setDescription('The new name for the season')
                .setRequired(true)
        );

    async autocomplete(interaction: AutocompleteInteraction) {

        const focusedOption = interaction.options.getFocused(true);
        if (focusedOption.name !== 'season') return interaction.respond([]);

        const seasonName = focusedOption.value as string;
        const seasons = await prisma.season.findMany();

        const choices = seasons.filter(season => season.name.toLowerCase().includes(seasonName.toLowerCase())).map(season => ({
            name: season.name,
            value: season.name
        }));

        await interaction.respond(choices);
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const seasonName = interaction.options.getString('season');
        const newName = interaction.options.getString('new_name');

        // Find the season
        const season = await prisma.season.findFirst({
            where: {
                name: seasonName
            }
        });

        if (!season) {
            return interaction.reply({
                embeds: [embeds.error(`Season "${seasonName}" not found.`)],
                ephemeral: true
            });
        }

        // Check if the new name already exists
        const existingSeason = await prisma.season.findFirst({
            where: {
                name: newName
            }
        });

        if (existingSeason) {
            return interaction.reply({
                embeds: [embeds.error(`A season with the name "${newName}" already exists.`)],
                ephemeral: true
            });
        }

        // Update the season name
        await prisma.season.update({
            where: {
                id: season.id
            },
            data: {
                name: newName
            }
        });

        return interaction.reply({
            embeds: [embeds.success(`Season "${seasonName}" has been renamed to "${newName}".`, 'Season Renamed')]
        });
    }
} 