export default {
    name: 'Season',
    description: 'Commands related to season management.',
}
