import { AutocompleteInteraction, ChatInputCommandInteraction, SlashCommandBuilder, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand, Command } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';
import { GameStatus } from '@common/database/generated';

export default class SeasonInfoCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('info')
        .setDescription('Get information about a season')
        .addStringOption(option =>
            option
                .setName('season')
                .setDescription('The name of the season to get information about')
                .setRequired(false)
                .setAutocomplete(true)
        );

    async autocomplete(interaction: AutocompleteInteraction) {

        const focusedOption = interaction.options.getFocused(true);
        if (focusedOption.name !== 'season') return interaction.respond([]);

        const seasonName = focusedOption.value as string;
        const seasons = await prisma.season.findMany();

        const choices = seasons.filter(season => season.name.toLowerCase().includes(seasonName.toLowerCase())).map(season => ({
            name: season.name,
            value: season.name
        }));

        await interaction.respond(choices);
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const seasonName = interaction.options.getString('season');

        let season;

        // If no season name is provided, get the current active season
        if (!seasonName) {
            season = await prisma.season.findFirst({
                where: {
                    active: true
                },
                include: {
                    topPlayers: {
                        include: {
                            player: true
                        },
                        orderBy: {
                            position: 'asc'
                        },
                        take: 3
                    }
                }
            });

            if (!season) {
                return interaction.reply({
                    embeds: [embeds.error('There is no active season currently.')],
                    ephemeral: true
                });
            }
        } else {
            // Get the specified season
            season = await prisma.season.findFirst({
                where: {
                    name: seasonName
                },
                include: {
                    topPlayers: {
                        include: {
                            player: true
                        },
                        orderBy: {
                            position: 'asc'
                        },
                        take: 3
                    }
                }
            });

            if (!season) {
                return interaction.reply({
                    embeds: [embeds.error(`Season "${seasonName}" not found.`)],
                    ephemeral: true
                });
            }
        }

        // Get game count for this season
        const gameCount = await prisma.game.count({
            where: {
                seasonId: season.id,
                status: GameStatus.SCORED,
            }
        });

        // Format top players
        let topPlayersText = 'No top players yet';

        if (season.topPlayers.length > 0) {
            topPlayersText = season.topPlayers.map(tp =>
                `${tp.position}. ${tp.player.minecraftName} (${tp.finalElo} ELO)`
            ).join('\n');
        }

        const seasonEmbed = embeds.normal(
            `
            **Season Name:** ${season.name}
            **Status:** ${season.active ? 'Active' : 'Ended'}
            **Start Date:** <t:${Math.floor(season.startDate.getTime() / 1000)}:F>
            ${season.endDate ? `**End Date:** <t:${Math.floor(season.endDate.getTime() / 1000)}:F>` : ''}
            **Games Played:** ${gameCount}
            ${season.archived ? '**This season is archived**' : ''}
            
            **Top Players:**
            ${topPlayersText}
            `,
            'Season Information'
        );

        return interaction.reply({
            embeds: [seasonEmbed]
        });
    }
} 