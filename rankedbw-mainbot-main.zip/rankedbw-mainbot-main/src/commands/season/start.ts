import {
  ChatInputCommandInteraction,
  SlashCommandSubcommandBuilder,
} from "discord.js";
import { ChildCommand } from "..";
import { prisma } from "@common/database/connectors/prisma";
import embeds from "../../utils/discord/embeds";
import { resetStrikesForSeason } from "../moderation/strike";
import settings from "../../settings";
import { PunishmentType } from "@common/database/generated";
import App from "../../index";
import { IncludeCurrentSeasonStatistics } from "@common/database/types/season";

export default class SeasonStartCommand extends ChildCommand {
  slashCommand = new SlashCommandSubcommandBuilder()
    .setName("start")
    .setDescription("Start a new season")
    .addStringOption((option) =>
      option
        .setName("name")
        .setDescription("The name of the new season")
        .setRequired(true)
    );

  async execute(interaction: ChatInputCommandInteraction) {
    const newSeasonName = interaction.options.getString("name");

    await interaction.deferReply(); // Defer reply as this might take time

    // Check if there's already an active season
    const activeSeason = await prisma.season.findFirst({
      where: {
        active: true,
      },
    });

    if (activeSeason) {
      return interaction.editReply({
        embeds: [
          embeds.error(
            "There is already an active season. Please end it before starting a new one."
          ),
        ],
      });
    }

    // Check if the season name already exists
    const existingSeason = await prisma.season.findFirst({
      where: {
        name: newSeasonName,
      },
    });

    if (existingSeason) {
      return interaction.editReply({
        embeds: [
          embeds.error(
            `A season with the name "${newSeasonName}" already exists.`
          ),
        ],
      });
    }

    // Reset all strikes for the new season
    const strikeResetSuccess = await resetStrikesForSeason();
    if (!strikeResetSuccess) {
      return interaction.editReply({
        embeds: [
          embeds.error(
            "Failed to reset strikes for the new season. Please try again or contact an administrator."
          ),
        ],
      });
    }

    // Clear season-long ranked bans (those with expiresAt: null)
    const seasonLongBansCleared = await this.clearSeasonLongRankedBans();

    // Create the new season
    const newSeason = await prisma.season.create({
      data: {
        name: newSeasonName,
        active: true,
      },
    });

    const allPlayers = await prisma.player.findMany({
      include: IncludeCurrentSeasonStatistics,
    });

    // Create new stats for all players
    await prisma.playerStatistics.createMany({
      data: allPlayers.map((player) => ({
        playerId: player.id,
        seasonId: newSeason.id,
      })),
    });

    const successEmbed = embeds.success(
      `
            Season "${newSeasonName}" has been started successfully!
            
            **✅ Actions Completed:**
            - New season created and activated
            - All strikes have been reset
            - ${seasonLongBansCleared} season-long ranked ban${seasonLongBansCleared === 1 ? "" : "s"
      } cleared
            
            **Note:** Regular time-based ranked bans remain active and will continue as normal.
            
            **Next steps:**
            - Set the ruleset for this season using the appropriate commands
            - Configure game style and queue settings
            - Make any other necessary adjustments to settings
            
            The season is now active and ready for games.
            `,
      "🎉 New Season Started"
    );

    return interaction.editReply({
      embeds: [successEmbed],
    });
  }

  private async clearSeasonLongRankedBans(): Promise<number> {
    try {
      console.log("Clearing season-long ranked bans...");

      // Find all active season-long ranked bans (expiresAt: null)
      const seasonLongBans = await prisma.punishment.findMany({
        where: {
          type: PunishmentType.rankedban,
          expired: false,
          expiresAt: null,
        },
        include: {
          Player: true,
        },
      });

      console.log(
        `Found ${seasonLongBans.length} season-long ranked bans to clear`
      );

      const guild = await App.client.guilds.fetch(settings.guild);
      if (!guild) {
        console.error("Could not fetch guild for clearing season-long bans");
        return 0;
      }

      let clearedCount = 0;

      for (const ban of seasonLongBans) {
        try {
          // Mark the punishment as expired
          await prisma.punishment.update({
            where: {
              id: ban.id,
            },
            data: {
              expired: true,
            },
          });

          // Remove the ranked ban role from the user
          const member = await guild.members.fetch(ban.Player.userId);
          if (member && member.roles.cache.has(settings.roles.rankedBan)) {
            await App.Redis.publish(
              "change:role",
              JSON.stringify({
                memberId: member.id,
                roleId: settings.roles.rankedBan,
                guildId: settings.guild,
                action: "remove",
              })
            );
          }

          // Create an unban record for logging purposes
          await prisma.punishment.create({
            data: {
              type: PunishmentType.rankedunban,
              reason: "Season-long ban cleared for new season",
              staff: "System",
              expired: false,
              Player: {
                connect: {
                  id: ban.Player.id,
                },
              },
            },
          });

          clearedCount++;

          // Log the unban
          const logChannel = await guild.channels.fetch(
            settings.channels.punishmentLogs
          );
          if (logChannel && logChannel.isTextBased()) {
            await logChannel.send({
              embeds: [
                embeds
                  .normal(
                    `${member} has been unbanned from ranked due to new season start.`,
                    "Season-Long Ban Cleared",
                    false
                  )
                  .addFields([
                    { name: "User", value: `${member}`, inline: true },
                    {
                      name: "Original Reason",
                      value: `\`${ban.reason}\``,
                      inline: true,
                    },
                    {
                      name: "Cleared By",
                      value: "System (New Season)",
                      inline: true,
                    },
                  ]),
              ],
            });
          }

          // Notify the user in punishments channel
          const punishmentsChannel = await guild.channels.fetch(
            settings.channels.punishments
          );
          if (punishmentsChannel && punishmentsChannel.isTextBased()) {
            await punishmentsChannel.send({
              content: `<@${ban.Player.userId}>`,
              embeds: [
                embeds
                  .success(
                    `**User:** ${member}\n**Reason:** Season-long ban cleared for new season\n\nYou may now participate in ranked games for the new season.`,
                    "`✅` Season-Long Ban Cleared",
                    false
                  )
                  .setColor("#40ff56")
                  .setThumbnail(
                    "https://images-ext-1.discordapp.net/external/DF9hM2A0XmdL2Q5anEZqyom9XlPGhK8DO5TCymCmfwA/https/i.imgur.com/yka7bke.png?format=webp&quality=lossless&width=200&height=200"
                  ),
              ],
            });
          }
        } catch (error) {
          console.error(
            `Failed to clear season-long ban for user ${ban.Player.userId}:`,
            error
          );
        }
      }

      console.log(
        `Successfully cleared ${clearedCount} season-long ranked bans`
      );
      return clearedCount;
    } catch (error) {
      console.error("Error clearing season-long ranked bans:", error);
      return 0;
    }
  }
}
