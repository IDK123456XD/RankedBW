import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';
import { GameStatus } from '@common/database/generated';

export default class SeasonListCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('List all past seasons and their statistics.');

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply();

        try {
            const seasons = await prisma.season.findMany({
                orderBy: {
                    startDate: 'desc',
                },
                include: {
                    games: {
                        where: {
                            status: GameStatus.SCORED,
                        },
                    },
                },
            });

            if (seasons.length === 0) {
                return interaction.editReply({
                    embeds: [embeds.normal('No seasons found.')],
                });
            }

            const seasonList = seasons.map(season => {
                const gamesPlayed = season.games.length;
                const status = season.archived ? 'Archived' : 'Active';
                return `**Name:** ${season.name}\n**Games Played:** ${gamesPlayed}\n**Status:** ${status}`;
            }).join('\n\n');

            await interaction.editReply({
                embeds: [embeds.normal(seasonList, 'Past Seasons')],
            });

        } catch (error: any) {
            console.error('Error fetching season list:', error);
            await interaction.editReply({
                embeds: [embeds.error(`An error occurred while fetching seasons: ${error.message}`)],
            });
        }
    }
}
