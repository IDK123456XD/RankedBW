import { AutocompleteInteraction, ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import { prisma } from '@common/database/connectors/prisma';
import embeds from '../../utils/discord/embeds';

export default class SeasonArchiveCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('archive')
        .setDescription('Toggle archive status of a season')
        .addStringOption(option =>
            option
                .setName('season')
                .setDescription('The name of the season to archive/unarchive')
                .setRequired(true)
                .setAutocomplete(true)
        );

    async autocomplete(interaction: AutocompleteInteraction) {
        const focusedOption = interaction.options.getFocused(true);
        if (focusedOption.name !== 'season') return interaction.respond([]);

        const seasonName = focusedOption.value as string;
        const seasons = await prisma.season.findMany();

        const choices = seasons.filter(season => season.name.toLowerCase().includes(seasonName.toLowerCase())).map(season => ({
            name: season.name,
            value: season.name
        }));

        await interaction.respond(choices);
    }

    async execute(interaction: ChatInputCommandInteraction) {
        const seasonName = interaction.options.getString('season');

        // Find the season
        const season = await prisma.season.findFirst({
            where: {
                name: seasonName
            }
        });

        if (!season) {
            return interaction.reply({
                embeds: [embeds.error(`Season "${seasonName}" not found.`)],
                ephemeral: true
            });
        }

        // Toggle archive status
        const newArchiveStatus = !season.archived;

        await prisma.season.update({
            where: {
                id: season.id
            },
            data: {
                archived: newArchiveStatus
            }
        });

        const action = newArchiveStatus ? 'archived' : 'unarchived';

        return interaction.reply({
            embeds: [embeds.success(`Season "${seasonName}" has been ${action}.`, `Season ${action.charAt(0).toUpperCase() + action.slice(1)}`)]
        });
    }
} 