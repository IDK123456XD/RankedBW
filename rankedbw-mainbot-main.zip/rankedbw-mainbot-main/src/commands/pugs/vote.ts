import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';
import { VotingTypes } from '@common/database/generated';

export default class PUGSVoteCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('vote')
        .setDescription('Vote to add a PUGS player.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The discord user you want to add.')
                .setRequired(true)
        )

    requiredRoles: string[] = [settings.roles.pugsManager, settings.roles.pugsOwner, settings.roles.administrator, settings.roles.owner];

    async execute(interaction: ChatInputCommandInteraction) {
        const discordUser = interaction.options.getUser('discord-user');

        const pastVote = await prisma.voting.findFirst({
            where: {
                candidateId: discordUser.id,
                type: VotingTypes.pugs
            }
        });

        if (pastVote) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} already has a PUGS vote in progress.`)],
                ephemeral: true,
            });
            return;
        }

        const pugsRole = await interaction.guild.roles.fetch(settings.roles.pugs);
        if (!pugsRole) {
            interaction.reply({
                embeds: [embeds.error('PUGS role not found.')],
                ephemeral: true,
            });
            return;
        }

        const member = await interaction.guild.members.fetch(discordUser.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not found as a member in this guild.`)],
                ephemeral: true,
            });
            return;
        }

        if (member.roles.cache.has(pugsRole.id)) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is already in the pugs role.`)],
                ephemeral: true,
            });
            return;
        }

        const pugsVoting = await interaction.guild.channels.fetch(settings.channels.pugsVoting);
        if (!pugsVoting || !pugsVoting.isTextBased()) {
            interaction.reply({
                embeds: [embeds.error('PUGS voting channel not found.')],
                ephemeral: true,
            });
            return;
        }

        const message = await pugsVoting.send({
            content: `${discordUser}`,
            embeds: [
                embeds.success(
                    `A vote has been started for ${discordUser} to join PUGS.`,
                    'PUGS Vote Started',
                    false
                ).addFields([
                    {
                        name: 'Upvotes',
                        value: '0',
                        inline: true,
                    },
                    {
                        name: 'Downvotes',
                        value: '0',
                        inline: true,
                    },
                ])
            ],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('pugs-upvote')
                        .setLabel('Upvote')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('pugs-downvote')
                        .setLabel('Downvote')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('pugs-endvote')
                        .setLabel('End Vote')
                        .setStyle(ButtonStyle.Secondary),
                ) as ActionRowBuilder<ButtonBuilder>
            ]
        });

        await prisma.voting.create({
            data: {
                type: VotingTypes.pugs,
                candidateId: discordUser.id,
                messageId: message.id
            }
        });

        // Log to pugs logs channel
        const pugsLogsChannel = await interaction.guild.channels.fetch(settings.channels.pugsLogs);
        if (pugsLogsChannel && pugsLogsChannel.isTextBased()) {
            await pugsLogsChannel.send({
                embeds: [embeds.normal(
                    `A **vote has been started** for **${discordUser.tag}** (${discordUser}) to join PUGS by ${interaction.user}.`,
                    'PUGS Vote Started',
                    false
                )]
            });
        }

        await interaction.reply({
            embeds: [embeds.success(`PUGS voting started for ${discordUser}.`)],
            ephemeral: true,
        });
    }
}