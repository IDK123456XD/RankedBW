import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';

export default class PugsRemoveCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('remove')
        .setDescription('Remove a player from the PUGS role.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The discord user you want to remove.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for removing the player from PUGS.')
                .setRequired(false)
        )

    requiredRoles: string[] = [settings.roles.pugsManager, settings.roles.pugsOwner, settings.roles.administrator, settings.roles.owner];

    async execute(interaction: ChatInputCommandInteraction) {
        const discordUser = interaction.options.getUser('discord-user');
        const reason = interaction.options.getString('reason');

        const pugsRole = await interaction.guild.roles.fetch(settings.roles.pugs);
        if (!pugsRole) {
            interaction.reply({
                embeds: [embeds.error('PUGS role not found.')],
                ephemeral: true,
            });
            return;
        }

        const member = await interaction.guild.members.fetch(discordUser.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not found as a member in this guild.`)],
                ephemeral: true,
            });
            return;
        }

        if (!member.roles.cache.has(pugsRole.id)) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not part of the PUGS role.`)],
                ephemeral: true,
            });
            return;
        }

        await member.roles.remove(pugsRole);
        
        // Log to pugs logs channel
        const pugsLogsChannel = await interaction.guild.channels.fetch(settings.channels.pugsLogs);
        if (pugsLogsChannel && pugsLogsChannel.isTextBased()) {
            const logMessage = `${interaction.user} has removed ${discordUser} from PUGS.${reason ? `\n**Reason:** ${reason}` : ''}`;
            await pugsLogsChannel.send({
                embeds: [embeds.error(logMessage, 'PUGS Role Removed', false)]
            });
        }

        await interaction.reply({
            content: `${discordUser} has been removed from PUGS.`,
        });
    }
}