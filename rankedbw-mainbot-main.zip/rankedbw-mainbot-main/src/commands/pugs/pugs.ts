import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import PugsAddCommand from './add';
import PugsListCommand from './list';
import PugsMyvoteCommand from './myvote';
import PugsRemoveCommand from './remove';

export default class PugsCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('pugs')
        .setDescription('Run pugs commands.')

    childCommands: ChildCommand[] = [
        new PugsAddCommand(),
        new PugsRemoveCommand(),
        new PugsListCommand(),
        //new PugsVoteCommand(),
        //new PugsEndvoteCommand()
    ];
} 