export default {
    name: 'Pugs',
    description: 'Run pugs commands.',
}