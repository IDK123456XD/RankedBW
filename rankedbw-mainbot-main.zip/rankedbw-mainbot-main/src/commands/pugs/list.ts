import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import Paginator from '../../utils/discord/paginator';
import { prisma } from '@common/database/connectors/prisma';

export default class PugsListCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('list')
        .setDescription('List all of the PUGS players.')

    async execute(interaction: ChatInputCommandInteraction) {
        await interaction.deferReply();

        try {
            const guild = await interaction.guild.fetch();
            const pugsRole = await guild.roles.fetch(settings.roles.pugs);
            const pugsManagerRole = await guild.roles.fetch(settings.roles.pugsManager);
            const pugsTrialRole = await guild.roles.fetch(settings.roles.pugsTrial);
            const pugsOwnerRole = await guild.roles.fetch(settings.roles.pugsOwner);
            const pugsSpecRole = await guild.roles.fetch(settings.roles.pugsSpec);

            if (!pugsOwnerRole) {
                await interaction.editReply({
                    embeds: [embeds.error('PUGS Owner role not found.')],
                });
                return;
            }

            if (!pugsRole) {
                await interaction.editReply({
                    embeds: [embeds.error('PUGS role not found.')],
                });
                return;
            }

            if (!pugsManagerRole) {
                await interaction.editReply({
                    embeds: [embeds.error('PUGS Manager role not found.')],
                });
                return;
            }

            if (!pugsTrialRole) {
                await interaction.editReply({
                    embeds: [embeds.error('PUGS Trial role not found.')],
                });
                return;
            }

            if (!pugsSpecRole) {
                await interaction.editReply({
                    embeds: [embeds.error('PUGS Spec role not found.')],
                });
                return;
            }

            // Fetch guild members to populate the cache
            await guild.members.fetch();

            // Get managers and regular members
            const pugsManagers = Array.from(pugsManagerRole.members.values());
            const pugsPlayers = Array.from(pugsRole.members.values());
            const pugsTrialMembers = Array.from(pugsTrialRole.members.values());
            const pugsOwners = Array.from(pugsOwnerRole.members.values());
            const pugsSpecs = Array.from(pugsSpecRole.members.values());
            // Filter out managers from regular members list to avoid duplicates
            const managerIds = new Set(pugsManagers.map(m => m.id));
            const ownerIds = new Set(pugsOwners.map(o => o.id));
            const specIds = new Set(pugsSpecs.map(s => s.id));
            const filteredPugsPlayers = pugsPlayers.filter(player => !managerIds.has(player.id) && !ownerIds.has(player.id) && !specIds.has(player.id));

            // Build the member list with hierarchy
            let membersList = '';

            // Add pugs owners secstion
            if (pugsOwners.length > 0) {
                membersList += `**PUGS Owners (${pugsOwners.length}):**\n`;
                for (const owner of pugsOwners) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: owner.id }
                    });
                    membersList += `${owner} | \`${playerData?.minecraftName || owner.user.username}\`\n`;
                }
                membersList += '\n';
            }

            // Add managers section (excluding owners)
            if (pugsManagers.length > 0) {
                membersList += `**PUGS Managers (${pugsManagers.length}):**\n`;
                for (const manager of pugsManagers) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: manager.id }
                    });
                    membersList += `${manager} | \`${playerData?.minecraftName || manager.user.username}\`\n`;
                }
                membersList += '\n';
            }

            // Add regular members section (excluding managers and owners)
            if (filteredPugsPlayers.length > 0) {
                membersList += `**PUGS Members (${filteredPugsPlayers.length}):**\n`;
                for (const player of filteredPugsPlayers) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: player.id }
                    });
                    membersList += `${player} | \`${playerData?.minecraftName || player.user.username}\`\n`;
                }
                membersList += '\n';
            }

            // Add pugs trial members section
            if (pugsTrialMembers.length > 0) {
                membersList += `**PUGS Trial Members (${pugsTrialMembers.length}):**\n`;
                for (const player of pugsTrialMembers) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: player.id }
                    });
                    membersList += `${player} | \`${playerData?.minecraftName || player.user.username}\`\n`;
                }
                membersList += '\n';
            }
            // Add pugs spec section
            if (pugsSpecs.length > 0) {
                membersList += `**PUGS Specs (${pugsSpecs.length}):**\n`;
                for (const player of pugsSpecs) {
                    const playerData = await prisma.player.findFirst({
                        where: { userId: player.id }
                    });
                    membersList += `${player} | \`${playerData?.minecraftName || player.user.username}\`\n`;
                }
            }

            if (!membersList.trim()) {
                await interaction.editReply({
                    embeds: [embeds.error('No PUGS players found.')],
                });
                return;
            }

            // Split the content for pagination
            const lines = membersList.trim().split('\n');
            const totalPages = Math.ceil(lines.length / 30);

            if (totalPages <= 1) {
                // Single page, no pagination needed
                await interaction.editReply({
                    embeds: [embeds.normal(membersList, 'PUGS List', false)]
                });
            } else {
                // Multiple pages, use pagination
                await new Paginator(interaction, totalPages, async (pageIndex) => {
                    const pageLines = lines.slice(pageIndex * 30, (pageIndex + 1) * 30);

                    return embeds.normal(
                        pageLines.join('\n'),
                        'PUGS List', false
                    );
                }, 0, false, false).start()
            }

        } catch (error) {
            console.error('Error fetching PUGS members:', error);
            await interaction.editReply({
                embeds: [embeds.error('Failed to fetch PUGS members. Please try again.')],
            });
        }
    }
}