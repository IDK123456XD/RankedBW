import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';
import { VotingTypes } from '@common/database/generated';

export default class PugsMyvoteCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('myvote')
        .setDescription('Check how many pugs votes you have.')

    async execute(interaction: ChatInputCommandInteraction) {
        const voting = await prisma.voting.findFirst({
            where: {
                type: VotingTypes.pugs,
                candidateId: interaction.user.id
            }
        });

        if (!voting) {
            interaction.reply({
                embeds: [embeds.error('You do not currently have a running vote for PUGS.')],
                ephemeral: true,
            });
            return;
        }

        await interaction.reply({
            embeds: [
                embeds.success(
                    'Here are your current PUGS vote statistics.',
                    'PUGS Vote Stats'
                ).addFields([
                    {
                        name: 'Upvotes',
                        value: voting.upvoteVoters.length.toString(),
                        inline: true,
                    },
                    {
                        name: 'Downvotes',
                        value: voting.downvoteVoters.length.toString(),
                        inline: true,
                    },
                    {
                        name: 'Total Votes',
                        value: (voting.upvoteVoters.length + voting.downvoteVoters.length).toString(),
                        inline: true,
                    },
                ])
            ]
        })
    }
}