import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';
import { VotingTypes } from '@common/database/generated';

export default class PugsEndvoteCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('endvote')
        .setDescription('Ends a current PUGS vote.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The player you want to end the vote for.')
                .setRequired(true)
        )

    requiredRoles: string[] = [settings.roles.pugsManager, settings.roles.pugsOwner, settings.roles.administrator, settings.roles.owner];

    async execute(interaction: ChatInputCommandInteraction) {
        const discordUser = interaction.options.getUser('discord-user');

        const pastVote = await prisma.voting.findFirst({
            where: {
                candidateId: discordUser.id,
                type: VotingTypes.pugs
            }
        });

        if (!pastVote) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} does not have a PUGS vote in progress.`)],
                ephemeral: true,
            });
            return;
        }

        const member = await interaction.guild.members.fetch(discordUser.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not found as a member in this guild.`)],
                ephemeral: true,
            });
            return;
        }

        const pugsVoting = await interaction.guild.channels.fetch(settings.channels.pugsVoting);
        if (!pugsVoting || !pugsVoting.isTextBased()) {
            interaction.reply({
                embeds: [embeds.error('Pugs voting channel not found.')],
                ephemeral: true,
            });
            return;
        }

        // Log to pugs logs channel
        const pugsLogsChannel = await interaction.guild.channels.fetch(settings.channels.pugsLogs);

        if (pastVote.upvoteVoters.length > pastVote.downvoteVoters.length) {
            await member.roles.add(settings.roles.pugs);

            if (pugsLogsChannel && pugsLogsChannel.isTextBased()) {
                await pugsLogsChannel.send({
                    embeds: [embeds.success(
                        `**Vote ended** for **${discordUser.tag}** (${discordUser}) by ${interaction.user}.\n**Result:** PASSED (${pastVote.upvoteVoters.length} upvotes, ${pastVote.downvoteVoters.length} downvotes)\n**${discordUser.tag}** has been **added** to the PUGS role.`,
                        'PUGS Vote Ended - PASSED',
                        false
                    )]
                });
            }

            await interaction.reply({
                embeds: [embeds.success(`${discordUser} has been added to the PUGS role.`)],
                ephemeral: true,
            });

            await pugsVoting.send({
                content: `${discordUser}`,
                embeds: [embeds.success(`:tada: ${discordUser} has been added to the PUGS role.`, 'PUGS Role Added', false)],
            });
        } else {
            await member.roles.remove(settings.roles.pugs);

            if (pugsLogsChannel && pugsLogsChannel.isTextBased()) {
                await pugsLogsChannel.send({
                    embeds: [embeds.error(
                        `**Vote ended** for **${discordUser.tag}** (${discordUser}) by ${interaction.user}.\n**Result:** FAILED (${pastVote.upvoteVoters.length} upvotes, ${pastVote.downvoteVoters.length} downvotes)\n**${discordUser.tag}** was **not added** to the PUGS role.`,
                        'PUGS Vote Ended - FAILED',
                        false
                    )]
                });
            }

            await interaction.reply({
                embeds: [embeds.success(`❌ ${discordUser} has been removed from the PUGS role.`)],
                ephemeral: true,
            });
        }

        await prisma.voting.delete({
            where: {
                id: pastVote.id
            }
        });
    }
}