import { ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';

export default class PupsAddCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('add')
        .setDescription('Add a player to the PUPS role.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The discord user you want to add.')
                .setRequired(true)
        )
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for adding the player to PUPS.')
                .setRequired(false)
        )
        .addBooleanOption(option =>
            option.setName('announce')
                .setDescription('Whether to post an announcement about this addition.')
                .setRequired(false)
        )

    requiredRoles: string[] = [settings.roles.pupsOwner, settings.roles.pupsManager, settings.roles.administrator, settings.roles.owner];

    async execute(interaction: ChatInputCommandInteraction) {
        const discordUser = interaction.options.getUser('discord-user');
        const reason = interaction.options.getString('reason');
        const announce = interaction.options.getBoolean('announce') ?? false;

        const pupsRole = await interaction.guild.roles.fetch(settings.roles.pups);
        if (!pupsRole) {
            interaction.reply({
                embeds: [embeds.error('PUPS role not found.')],
                ephemeral: true,
            });
            return;
        }

        const member = await interaction.guild.members.fetch(discordUser.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not found as a member in this guild.`)],
                ephemeral: true,
            });
            return;
        }

        if (member.roles.cache.has(pupsRole.id)) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is already in the PUPS role.`)],
                ephemeral: true,
            });
            return;
        }

        await member.roles.add(pupsRole);

        // Post announcement if requested
        if (announce) {
            const pupsAnnouncements = await interaction.guild.channels.fetch(settings.channels.pupsAnnouncements);
            if (pupsAnnouncements && pupsAnnouncements.isTextBased()) {
                const player = await prisma.player.findFirst({
                    where: {
                        userId: discordUser.id
                    }
                });

                await pupsAnnouncements.send({
                    content: `${discordUser}`,
                    embeds: [
                        embeds.success(
                            `:tada: Congratulations ${discordUser}` +
                            (player ? ` (\`${player.minecraftName}\`)!` : '!') +
                            ' You have been accepted into PUPS.',
                            'PUPS Role Added',
                            false
                        )
                    ],
                });
            }
        }

        // Log to pups logs channel
        const pupsLogsChannel = await interaction.guild.channels.fetch(settings.channels.pupsLogs);
        if (pupsLogsChannel && pupsLogsChannel.isTextBased()) {
            const logMessage = `${interaction.user} has added ${discordUser} to PUPS.${reason ? `\n**Reason:** ${reason}` : ''}`;
            await pupsLogsChannel.send({
                embeds: [embeds.success(logMessage, 'PUPS Role Added', false)]
            });
        }

        await interaction.reply({
            content: `${discordUser} has been added to PUPS.`,
        });
    }
}