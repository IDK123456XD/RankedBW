import { SlashCommandBuilder } from 'discord.js';
import { ChildCommand, ParentCommand } from '..';
import PupsAddCommand from './add';
import PupsRemoveCommand from './remove';
import PupsListCommand from './list';
import PupsMyvoteCommand from './myvote';
import PupsVoteCommand from './vote';
import PupsEndvoteCommand from './endvote';

export default class PupsCommand extends ParentCommand {
    slashCommand = new SlashCommandBuilder()
        .setName('pups')
        .setDescription('Run pups commands.')

    childCommands: ChildCommand[] = [
        new PupsAddCommand(),
        new PupsRemoveCommand(),
        new PupsListCommand(),
        new PupsMyvoteCommand(),
        new PupsVoteCommand(),
        new PupsEndvoteCommand()
    ];
} 