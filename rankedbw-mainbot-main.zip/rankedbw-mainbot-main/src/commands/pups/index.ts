export default {
    name: 'Pups',
    description: 'Run pups commands.',
}