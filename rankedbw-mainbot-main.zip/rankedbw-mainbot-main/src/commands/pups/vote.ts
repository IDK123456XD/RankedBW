import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandSubcommandBuilder } from 'discord.js';
import { ChildCommand } from '..';
import settings from '../../settings';
import embeds from '../../utils/discord/embeds';
import { prisma } from '@common/database/connectors/prisma';
import { VotingTypes } from '@common/database/generated';

export default class PupsVoteCommand extends ChildCommand {
    slashCommand = new SlashCommandSubcommandBuilder()
        .setName('vote')
        .setDescription('Vote to add a PUPS player.')
        .addUserOption(option =>
            option.setName('discord-user')
                .setDescription('The discord user you want to add.')
                .setRequired(true)
        )

    requiredRoles: string[] = [settings.roles.pupsOwner, settings.roles.pupsManager, settings.roles.administrator, settings.roles.owner];

    async execute(interaction: ChatInputCommandInteraction) {
        const discordUser = interaction.options.getUser('discord-user');

        const pastVote = await prisma.voting.findFirst({
            where: {
                candidateId: discordUser.id,
                type: VotingTypes.pups
            }
        });

        if (pastVote) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} already has a PUPS vote in progress.`)],
                ephemeral: true,
            });
            return;
        }

        const pupsRole = await interaction.guild.roles.fetch(settings.roles.pups);
        if (!pupsRole) {
            interaction.reply({
                embeds: [embeds.error('Pups role not found.')],
                ephemeral: true,
            });
            return;
        }

        const member = await interaction.guild.members.fetch(discordUser.id);
        if (!member) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is not found as a member in this guild.`)],
                ephemeral: true,
            });
            return;
        }

        if (member.roles.cache.has(pupsRole.id)) {
            interaction.reply({
                embeds: [embeds.error(`${discordUser} is already in the pups role.`)],
                ephemeral: true,
            });
            return;
        }

        const pupsVoting = await interaction.guild.channels.fetch(settings.channels.pupsVoting);
        if (!pupsVoting || !pupsVoting.isTextBased()) {
            interaction.reply({
                embeds: [embeds.error('Pups voting channel not found.')],
                ephemeral: true,
            });
            return;
        }

        const message = await pupsVoting.send({
            content: `${discordUser}`,
            embeds: [
                embeds.success(
                    `A vote has been started for ${discordUser} to join PUPS.`,
                    'PUPS Vote Started',
                    false
                ).addFields([
                    {
                        name: 'Upvotes',
                        value: '0',
                        inline: true,
                    },
                    {
                        name: 'Downvotes',
                        value: '0',
                        inline: true,
                    },
                ])
            ],
            components: [
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('pups-upvote')
                        .setLabel('Upvote')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('pups-downvote')
                        .setLabel('Downvote')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('pups-endvote')
                        .setLabel('End Vote')
                        .setStyle(ButtonStyle.Secondary),
                ) as ActionRowBuilder<ButtonBuilder>
            ]
        });

        await prisma.voting.create({
            data: {
                type: VotingTypes.pups,
                candidateId: discordUser.id,
                messageId: message.id
            }
        });

        // Log to pups logs channel
        const pupsLogsChannel = await interaction.guild.channels.fetch(settings.channels.pupsLogs);
        if (pupsLogsChannel && pupsLogsChannel.isTextBased()) {
            await pupsLogsChannel.send({
                embeds: [embeds.normal(
                    `A **vote has been started** for **${discordUser.tag}** (${discordUser}) to join PUPS by ${interaction.user}.`,
                    'PUPS Vote Started',
                    false
                )]
            });
        }

        await interaction.reply({
            embeds: [embeds.success(`PUPS voting started for ${discordUser}.`)],
            ephemeral: true,
        });
    }
}