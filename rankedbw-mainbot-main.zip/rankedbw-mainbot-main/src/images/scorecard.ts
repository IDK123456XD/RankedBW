import { createCanvas, loadImage, registerFont } from "canvas";
import fs from "fs";
import path from "path";
import { ELO_DATA } from "../settings";
import { fetchHeadSkin } from "../utils/minecraft";
import { prisma } from "@common/database/connectors/prisma";

registerFont("./assets/fonts/AcherusFeral-Light.otf", { family: "AcherusFeral-Light" });

interface ScoringCardPlayer {
    userId: string;
    uuid: string;
    minecraftName: string;
    preElo: number;
    postElo: number;
    eloDiff: number;
    isMvp: boolean;
    isWinner: boolean;
    headSkin: string;
    discordTeam: number;
}

interface ScoringCardData {
    gameId: string;
    players: ScoringCardPlayer[];
    mapName?: string;
    seasonName?: string;
    scoringMethod: 'AI' | 'Manual' | 'Staff';
    scoredBy?: string;
}

export async function generateScoringCard(data: ScoringCardData): Promise<Buffer | null> {
    try {
        const canvas = createCanvas(1400, 800);
        const ctx = canvas.getContext("2d", { alpha: true });

        // Load the scoring background
        const backgroundPath = path.join("./assets/images", "scoring_background.png");
        if (!fs.existsSync(backgroundPath)) {
            console.error('Scoring background not found:', backgroundPath);
            return null;
        }

        const baseImage = await loadImage(backgroundPath);
        ctx.drawImage(baseImage, 0, 0, 1400, 800);

        // Load arrow image
        const arrowImagePath = path.join("./assets/images", "arrow.png");
        let arrowImage = null;
        if (fs.existsSync(arrowImagePath)) {
            arrowImage = await loadImage(arrowImagePath);
        }

        // Load MVP tag
        const mvpTagPath = path.join("./assets/images", "mvp_tag.png");
        let mvpTag = null;
        if (fs.existsSync(mvpTagPath)) {
            mvpTag = await loadImage(mvpTagPath);
        }

        // Separate winners and losers
        const winners = data.players.filter(p => p.isWinner);
        const losers = data.players.filter(p => !p.isWinner);

        // Set up text styling
        ctx.textAlign = "left";
        ctx.textBaseline = "middle";

        // Draw winners (top section - green area)
        await drawPlayerSection(ctx, winners, mvpTag, arrowImage, 133, 170, 74); // Starting at (163, 170)

        // Draw losers (bottom section - red/purple area)    
        const losersStartY = 480;
        await drawPlayerSection(ctx, losers, mvpTag, arrowImage, 133, losersStartY, 74);

        // Add game information
        await drawGameInfo(ctx, data);

        return canvas.toBuffer();
    } catch (error) {
        console.error('Error generating scoring card:', error);
        return null;
    }
}

async function drawPlayerSection(
    ctx: any,
    players: ScoringCardPlayer[],
    mvpTag: any,
    arrowImage: any,
    startX: number,
    startY: number,
    space: number,
): Promise<void> {
    for (let i = 0; i < players.length; i++) {
        const player = players[i];
        const y = startY + (i * space); // 80px spacing between rows

        await drawPlayer(ctx, player, mvpTag, arrowImage, startX, y);
    }
}

async function drawPlayer(
    ctx: any,
    player: ScoringCardPlayer,
    mvpTag: any,
    arrowImage: any,
    x: number,
    y: number,
): Promise<void> {
    const textColor = "#FFFFFF"; // White text
    const greyTextColor = "#989898"; // Light grey
    const eloChangePositive = "#84FFC4";
    const eloChangeNegative = "#FF9797";

    // Head dimensions
    const headSize = 50;
    const headPadding = 15;

    // Fixed column positions
    const headX = x; // 163
    const nameX = x + headSize + headPadding; // Adjust name position for head
    const rankCenterX = 825;
    const eloCenterX = 1150;

    // Get rank data for before and after ELO
    const preElo = player.postElo - player.eloDiff;
    const postElo = player.postElo;
    const preRankData = ELO_DATA.find(rank => preElo >= rank.min && preElo <= rank.max) ?? ELO_DATA[0];
    const postRankData = ELO_DATA.find(rank => postElo >= rank.min && postElo <= rank.max) ?? ELO_DATA[0];

    // Load rank images
    const preRankPath = `./assets/images/ranks/${preRankData.name.toLowerCase()} rank.png`;
    const postRankPath = `./assets/images/ranks/${postRankData.name.toLowerCase()} rank.png`;

    let preRankImage = null;
    let postRankImage = null;

    if (fs.existsSync(preRankPath)) {
        preRankImage = await loadImage(preRankPath);
    }
    if (fs.existsSync(postRankPath)) {
        postRankImage = await loadImage(postRankPath);
    }

    // Fetch and draw player head
    if (!player.headSkin && player.uuid) {
        const headSkin = await fetchHeadSkin(player.uuid);
        if (headSkin) {
            player.headSkin = headSkin;
            await prisma.player.update({
                where: { userId: player.userId },
                data: { headSkin },
            });
        }
    }

    const headBuffer = Buffer.from(player.headSkin, "base64");
    const headImage = await loadImage(headBuffer);

    // Draw head image if available
    if (headImage) {
        ctx.drawImage(headImage, headX, y - headSize / 2, headSize, headSize);
    }

    // Player name section
    const displayName = player.minecraftName;

    ctx.font = '40px "AcherusFeral-Light"';
    ctx.fillStyle = textColor;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(displayName, nameX, y);

    // MVP tag if applicable
    const nameWidth = ctx.measureText(displayName).width;
    if (player.isMvp && mvpTag) {
        ctx.drawImage(mvpTag, nameX + nameWidth + 20, y - 21, 118, 42);
    }

    // Rank section (centered at rankCenterX)
    const rankSize = 64;
    const rankChanged = preRankData.name !== postRankData.name;

    if (rankChanged && postRankImage) {
        // Calculate total width for centering: rank1 + arrow + rank2
        const arrowWidth = 30; // Arrow image width
        const arrowHeight = 20; // Arrow image height
        const totalRankWidth = rankSize + arrowWidth + rankSize;
        const startRankX = rankCenterX - (totalRankWidth / 2);

        // Pre rank
        if (preRankImage) {
            ctx.drawImage(preRankImage, startRankX, y - rankSize / 2, rankSize, rankSize);
        }

        // Arrow image
        if (arrowImage) {
            ctx.drawImage(arrowImage, startRankX + rankSize + (arrowWidth / 2) - (arrowWidth / 2), y - arrowHeight / 2, arrowWidth, arrowHeight);
        }

        // Post rank
        ctx.drawImage(postRankImage, startRankX + rankSize + arrowWidth, y - rankSize / 2, rankSize, rankSize);
    } else {
        // Just show current rank centered
        if (preRankImage) {
            ctx.drawImage(preRankImage, rankCenterX - rankSize / 2, y - rankSize / 2, rankSize, rankSize);
        }
    }

    // ELO section (centered at eloCenterX)
    const eloChangeText = player.eloDiff >= 0 ? `(+${player.eloDiff})` : `(${player.eloDiff})`;

    // Calculate total width for centering: preElo + arrow + postElo + change
    ctx.font = '40px "AcherusFeral-Light"';
    const preEloText = preElo.toString();
    const postEloText = postElo.toString();

    const preEloWidth = ctx.measureText(preEloText).width;
    const postEloWidth = ctx.measureText(postEloText).width;
    const changeWidth = ctx.measureText(eloChangeText).width;

    // Arrow image dimensions
    const arrowWidth = 30;
    const arrowHeight = 20;

    const totalEloWidth = preEloWidth + 30 + arrowWidth + 20 + postEloWidth + 30 + changeWidth;
    const startEloX = eloCenterX - (totalEloWidth / 2);

    let currentEloX = startEloX;

    // Pre ELO
    ctx.font = '32px "AcherusFeral-Light"';
    ctx.fillStyle = greyTextColor;
    ctx.textAlign = "left";
    ctx.fillText(preEloText, currentEloX, y);
    currentEloX += preEloWidth;

    // Arrow image
    if (arrowImage) {
        ctx.drawImage(arrowImage, currentEloX, y - arrowHeight / 2, arrowWidth, arrowHeight);
    }
    currentEloX += arrowWidth + 10;

    // Post ELO
    ctx.font = '32px "AcherusFeral-Light"';
    ctx.fillStyle = textColor;
    ctx.fillText(postEloText, currentEloX, y);
    currentEloX += postEloWidth + 10;

    // ELO change in green
    ctx.fillStyle = eloChangePositive;
    if (player.eloDiff < 0) {
        ctx.fillStyle = eloChangeNegative;
    }
    ctx.fillText(eloChangeText, currentEloX, y);
}

async function drawGameInfo(ctx: any, data: ScoringCardData): Promise<void> {
    const textColor = "#FFFFFF";

    // Game ID
    ctx.font = '28px "AcherusFeral-Light"';
    ctx.fillStyle = textColor;
    ctx.textAlign = "left";
    ctx.fillText(`Game ${data.gameId}`, 50, 766);
}

// Helper function to get rank data by ELO
function getRankDataByElo(elo: number) {
    return ELO_DATA.find(rank => elo >= rank.min && elo <= rank.max);
}