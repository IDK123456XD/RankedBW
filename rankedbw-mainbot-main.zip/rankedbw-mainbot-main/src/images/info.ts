import { createCanvas, loadImage, registerFont } from "canvas";
import fs from "fs";
import path from "path";
import App from "..";
import { getRankPlace } from "../utils/rank";
import { ELO_DATA } from "../settings";
import { prisma } from "@common/database/connectors/prisma";
import { fetchFullBodySkin } from "../utils/minecraft";
import { createId } from "@paralleldrive/cuid2";
import { getPlayerProgress } from "../utils/leveling";
import {
  IncludeCurrentSeasonStatistics,
} from "@common/database/types/season";

registerFont("./assets/fonts/Archive-Regular.otf", {
  family: "Archive-Regular",
});

export async function generateInfoImage(playerId: string) {
  const playerData = await prisma.player.findFirst({
    where: {
      id: playerId,
    },
    include: {
      gamePlayer: {
        include: {
          Game: {
            include: {
              players: true,
            },
          },
        },
      },
      selectedInfocard: true,
      ...IncludeCurrentSeasonStatistics,
    },
  });
  const canvas = createCanvas(700, 400);
  const ctx = canvas.getContext("2d", { alpha: true });

  // Load the user's selected infocard directly as the base
  try {
    let infocardFilename;

    if (playerData.selectedInfocard && playerData.selectedInfocard.image) {
      infocardFilename = playerData.selectedInfocard.image;
    }

    const infocardPath = path.join(
      "./assets/images/infocards",
      infocardFilename
    );

    if (!fs.existsSync(infocardPath)) {
      console.error("Infocard file not found:", infocardPath);
      return null;
    }

    const baseImage = await loadImage(infocardPath);

    ctx.drawImage(baseImage, 0, 0, 700, 400);
  } catch (error) {
    console.error("Error loading infocard:", error);
    return null;
  }

  let fontColor = "#000000";
  if (playerData.selectedInfocard && playerData.selectedInfocard.color) {
    fontColor =
      playerData.selectedInfocard.color === "dark" ? "#FFFFFF" : "#000000";
  }

  const eloData = ELO_DATA.find(
    (elo) =>
      playerData.PlayerStatistics[0].elo >= elo.min &&
      playerData.PlayerStatistics[0].elo <= elo.max
  );
  const rankImage = await loadImage(
    `./assets/images/ranks/${eloData.name.toLowerCase()} rank.png`
  );

  // * Player Name (centered above player skin)
  if (playerData.minecraftName.length < 11) {
    ctx.font = '30px "Archive-Regular"';
  } else if (playerData.minecraftName.length < 14) {
    ctx.font = '24px "Archive-Regular"';
  } else {
    ctx.font = '20px "Archive-Regular"';
  }

  ctx.fillStyle = fontColor;
  ctx.strokeStyle = fontColor;
  ctx.shadowColor = fontColor;
  ctx.shadowBlur = 10;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
  ctx.textAlign = "center";
  const textMetrics = ctx.measureText(playerData.minecraftName);
  const adjustedY = 55 + (textMetrics.actualBoundingBoxAscent - textMetrics.actualBoundingBoxDescent) / 2;
  ctx.fillText(playerData.minecraftName, 144, adjustedY);
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
  ctx.strokeStyle = "transparent";
  ctx.shadowColor = "transparent";

  if (!playerData.fullBodySkin && playerData.uuid) {
    const fullBodySkin = await fetchFullBodySkin(playerData.uuid);
    if (fullBodySkin) {
      playerData.fullBodySkin = fullBodySkin;
      await prisma.player.update({
        where: { id: playerData.id },
        data: { fullBodySkin },
      });
    }
  }

  // * Player Skin (left side)
  const buffer = Buffer.from(playerData.fullBodySkin, "base64");
  const skin = await loadImage(buffer);
  ctx.drawImage(skin, 88, 87, 115, 250);

  // * ELO (right side)
  ctx.font = '48px "Archive-Regular"';
  ctx.fillStyle = fontColor;
  ctx.strokeStyle = fontColor;
  ctx.shadowColor = fontColor;
  ctx.shadowBlur = 10;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
  ctx.textAlign = "center";
  ctx.fillText(playerData.PlayerStatistics[0].elo.toString(), 362, 258);
  ctx.shadowBlur = 0;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
  ctx.strokeStyle = "transparent";
  ctx.shadowColor = "transparent";

  // * Rank (right side, below ELO)
  const playerRank = await getRankPlace(playerData);
  ctx.font = '36px "Archive-Regular"'; // OpenSans-SemiBold for consistency

  // Set color based on rank position
  if (playerRank === 1) {
    ctx.fillStyle = "#EFBF04"; // Gold
  } else if (playerRank === 2) {
    ctx.fillStyle = "#B0B0B0"; // Silver
  } else if (playerRank === 3) {
    ctx.fillStyle = "#A0A0A0"; // Bronze
  } else {
    ctx.fillStyle = fontColor; // Black for all other ranks
  }

  ctx.textAlign = "center";
  ctx.fillText(`#${playerRank}`, 362, 118);

  // * Level and XP Progress (using new leveling system)

  // Calculate player progress using new system
  const playerProgress = getPlayerProgress(playerData.totalXp);
  const { level, xpIntoLevel, xpNeededForNext } = playerProgress;
  const xpPercentage = xpIntoLevel / xpNeededForNext;

  // Level display
  ctx.font = '18px "Archive-Regular"';
  ctx.fillStyle = fontColor;
  ctx.textAlign = "right";
  ctx.fillText(`LVL ${level}`, 658, 53);

  // XP Text with new progress system
  ctx.font = '15px "Archive-Regular"';
  ctx.fillStyle = fontColor;
  ctx.textAlign = "left";
  ctx.fillText(`${xpIntoLevel.toString()}`, 471, 53);
  ctx.fillStyle = "#C0C0C0"; // Light grey
  ctx.fillText(
    " / ",
    471 + ctx.measureText(`${xpIntoLevel.toString()}`).width,
    53
  );
  ctx.fillStyle = "#808080"; // Medium grey
  ctx.fillText(
    `${xpNeededForNext.toString()} XP`,
    471 +
    ctx.measureText(`${xpIntoLevel.toString()}`).width +
    ctx.measureText(" / ").width,
    53
  );
  ctx.fillStyle = fontColor;

  // Progress bar dimensions
  const barStartX = 472;
  const barStartY = 64;
  const barEndX = 659;
  const barHeight = 11;
  const barWidth = barEndX - barStartX; // 189 pixels
  const radius = barHeight / 2; // Half the height for pill shape

  // Draw filled progress bar with rounded ends
  const filledWidth = barWidth * xpPercentage;
  if (filledWidth > 0) {
    ctx.fillStyle = "#AC8FFF"; // Purple color
    ctx.beginPath();
    ctx.roundRect(barStartX, barStartY, filledWidth, barHeight, radius);
    ctx.fill();
  }

  // * Division (middle area with rank icon)
  ctx.drawImage(rankImage, 623, 107, 50, 50);
  ctx.font = '18px "Archive-Regular"';
  ctx.fillStyle = ELO_DATA.find((x) => x.name === eloData.name).color;
  ctx.textAlign = "center";
  ctx.fillText(eloData.name.toProperCase(), 144, 372);

  // * Peak ELO (Middle bottom)
  ctx.font = '28px "Archive-Regular"';
  ctx.fillStyle = fontColor;
  ctx.textAlign = "center";
  ctx.fillText(playerData.PlayerStatistics[0].peakElo.toString(), 362, 370);

  // * Game Stats (middle-right area) - Use direct fields from Player model
  const gamesWon = playerData.PlayerStatistics[0].wins;
  const gamesLost = playerData.PlayerStatistics[0].losses;
  const streak = playerData.PlayerStatistics[0].streak;

  const showStreak = streak > 1;

  const wlr =
    gamesLost === 0 ? gamesWon : Math.round((gamesWon / gamesLost) * 100) / 100;
  const mvpCount = playerData.PlayerStatistics[0].mvps;

  ctx.textAlign = "right";
  ctx.font = '28px "Archive-Regular"';


  // STREAK and WINS
  if (showStreak) {
    // Load streak icon
    const streakIcon = await loadImage('./assets/images/streakicon.png');
    
    // WINS (keep at far right)
    ctx.fillStyle = fontColor;
    ctx.fillText(gamesWon.toString(), 660, 185);
    
    // Calculate positioning for streak count (to the left of wins)
    const winsWidth = ctx.measureText(gamesWon.toString()).width;
    const streakWidth = ctx.measureText(streak.toString()).width;
    const streakX = 660 - winsWidth - 8; // 8px gap between streak count and wins
    
    // STREAK number
    ctx.fillStyle = "#FFA700"; // Orange color for streak count
    ctx.fillText(streak.toString(), streakX, 185);
    
    // Calculate positioning for streak icon (to the left of streak count)
    const iconSizeX = 16; // Smaller icon size
    const iconSizeY = 19; // Smaller icon size
    const iconX = streakX - streakWidth - iconSizeX - 5; // 5px gap between icon and streak count
    const iconY = 185 - iconSizeY / 2 - 10; // Center icon with text baseline, adjusted up by 2px
    
    // Draw streak icon
    ctx.drawImage(streakIcon, iconX, iconY, iconSizeX, iconSizeY);
  } else {
    // WINS
    ctx.fillStyle = fontColor;
    ctx.fillText(gamesWon.toString(), 660, 185);
  }

  // LOSSES
  ctx.fillStyle = fontColor;
  ctx.fillText(gamesLost.toString(), 660, 232);

  // WLR
  ctx.fillStyle = fontColor;
  ctx.fillText(wlr.toFixed(2), 660, 275);

  // MVPS
  ctx.fillStyle = fontColor;
  ctx.fillText(mvpCount.toString(), 660, 322);

  // Reset text alignment for any remaining operations
  ctx.textAlign = "center";

  // Handle GIF infocards if needed
  if (
    playerData.selectedInfocard &&
    playerData.selectedInfocard.image.toLowerCase().endsWith(".gif")
  ) {
    const genId = createId();

    if (!fs.existsSync(".temp/user_info"))
      await fs.promises.mkdir(".temp/user_info", { recursive: true });
    fs.writeFileSync(
      `.temp/user_info/${genId}-canvas.png`,
      new Uint8Array(canvas.toBuffer("image/png"))
    );

    await App.Redis.publish(
      "gifInfoImage",
      JSON.stringify({
        genId,
        gifId: playerData.selectedInfocard.image,
        isInfocard: true,
      })
    );

    await App.RedisSub.subscribe(`gifInfoImage:${genId}`);

    const generatedGif = await new Promise<Buffer>((resolve) => {
      App.RedisSub.on("message", async (channel, message) => {
        if (channel === `gifInfoImage:${genId}`) {
          if (message === "done") {
            const image = fs.readFileSync(`.temp/user_info/${genId}.gif`);
            resolve(image);
          } else {
            resolve(null);
          }
        }
      });
    });

    await App.Redis.unsubscribe(`gifInfoImage:${genId}`);
    await fs.promises.unlink(`.temp/user_info/${genId}.gif`);
    return generatedGif;
  }

  // For static images (PNG, JPG, etc.), return the canvas directly
  return canvas.toBuffer();
}