/**
 * One-time cleanup script for orphaned game threads
 * Hardcoded values for immediate use
 * 
 * Setup:
 * 1. npm install discord.js @prisma/client
 * 2. node cleanup-orphaned-threads.js
 */

const { Client, GatewayIntentBits } = require('discord.js');
const { PrismaClient } = require('./src/common/src/database/generated');

// Hardcoded configuration
const CONFIG = {
    DATABASE_URL: 'postgres://postgres:foje3NAWC9olTnoyoyo8TuvON0xurqviWb7jdCu7jpxz5JmVaGpvACgyb856YCpf@54.37.74.142:5436/postgres',
    GUILD_ID: '1020646109992992828',
    GAMES_CHANNEL_ID: '1393395893423702057',
    TOKEN: 'ODYyOTA1MDM5MDUxNjg1OTA4.GyoAAB.q_CHhc0Tr6sKw0NLiiiZvt0IQkNy_ol0r75hJk'
};

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

const prisma = new PrismaClient({
    datasources: {
        db: {
            url: CONFIG.DATABASE_URL
        }
    }
});

// Rate limiting settings to avoid Discord API limits
const DELAY_BETWEEN_OPERATIONS = 20; 
const BATCH_SIZE = 50; 
const DELAY_BETWEEN_BATCHES = 1000; 

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function cleanupOrphanedThreads() {
    try {
        console.log('Starting orphaned thread cleanup...');
        console.log('⚠️  Rate limiting enabled to avoid Discord API limits');
        console.log('🔧 Using hardcoded configuration for one-time cleanup');
        
        console.log(`Fetching guild ${CONFIG.GUILD_ID}...`);
        const guild = await client.guilds.fetch(CONFIG.GUILD_ID);
        console.log(`✅ Connected to guild: ${guild.name}`);
        
        console.log(`Fetching games channel ${CONFIG.GAMES_CHANNEL_ID}...`);
        const gamesChannel = await guild.channels.fetch(CONFIG.GAMES_CHANNEL_ID);
        
        if (!gamesChannel?.isTextBased()) {
            console.error('❌ Games channel not found or not text-based');
            return;
        }
        
        console.log(`✅ Found games channel: ${gamesChannel.name}`);
        console.log('Fetching all threads (this may take a while)...');
        
        // Fetch only ACTIVE threads (we want to archive completed games)
        const threads = await gamesChannel.threads.fetchActive();
        await sleep(DELAY_BETWEEN_OPERATIONS);
        
        const activeThreads = [...threads.threads.values()];
        console.log(`📊 Found ${activeThreads.length} active threads to analyze`);
        
        let orphanedCount = 0;
        let cleanedCount = 0;
        let processedCount = 0;
        
        // Process threads in batches to avoid rate limits
        for (let i = 0; i < activeThreads.length; i += BATCH_SIZE) {
            const batch = activeThreads.slice(i, i + BATCH_SIZE);
            console.log(`\n🔍 Processing batch ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(activeThreads.length / BATCH_SIZE)} (${batch.length} threads)`);
            
            for (const thread of batch) {
                processedCount++;
                
                // Check if thread name matches game pattern
                const gameIdMatch = thread.name.match(/^Game ([A-Z0-9]{4})$/);
                if (!gameIdMatch) {
                    console.log(`⏭️  Skipping non-game thread: ${thread.name}`);
                    continue;
                }
                
                const gameId = gameIdMatch[1];
                console.log(`🔍 Checking Game ${gameId}...`);
                
                // Check if there's a corresponding game in the database
                const game = await prisma.game.findFirst({
                    where: { gameId: gameId }
                });
                
                // Criteria for archiving: Game exists but status is NOT PENDING (i.e., game is complete)
                const shouldArchive = game && game.status !== 'PENDING';
                
                if (shouldArchive) {
                    orphanedCount++;
                    console.log(`🏁 COMPLETED GAME THREAD: ${thread.name}`);
                    console.log(`   📅 Created: ${thread.createdAt.toLocaleString()}`);
                    console.log(`   🎮 Game status: ${game.status}`);
                    console.log(`   📊 Should be archived`);
                } else if (!game) {
                    orphanedCount++;
                    console.log(`🚨 ORPHANED THREAD FOUND: ${thread.name}`);
                    console.log(`   📅 Created: ${thread.createdAt.toLocaleString()}`);
                    console.log(`   🗄️  Database game: MISSING`);
                } else {
                    console.log(`   ⏳ Active pending game: ${thread.name} (${game.status})`);
                }
                
                if (shouldArchive || !game) {
                    
                    // Actually clean up the thread (no confirmation needed since we're being specific)
                    try {
                        // First archive the thread
                        await thread.setArchived(true);
                        
                        // Small delay to ensure archive operation completes
                        await sleep(100);
                        
                        // Then lock it
                        await thread.setLocked(true);
                        
                        // Verify both operations succeeded
                        await thread.fetch(); // Refresh thread data
                        if (thread.archived && thread.locked) {
                            cleanedCount++;
                            console.log(`   ✅ CLEANED: Archived and locked thread`);
                        } else {
                            console.log(`   ⚠️  PARTIAL: Thread state - Archived: ${thread.archived}, Locked: ${thread.locked}`);
                            cleanedCount++; // Still count as cleaned since we tried
                        }
                    } catch (error) {
                        console.error(`   ❌ ERROR cleaning thread: ${error.message}`);
                    }
                }
                
                // Rate limit between each thread operation
                await sleep(DELAY_BETWEEN_OPERATIONS);
            }
            
            // Longer delay between batches
            if (i + BATCH_SIZE < activeThreads.length) {
                console.log(`⏳ Waiting ${DELAY_BETWEEN_BATCHES / 1000} seconds before next batch...`);
                await sleep(DELAY_BETWEEN_BATCHES);
            }
        }
        
        console.log(`\n📊 FINAL SUMMARY:`);
        console.log(`✅ Total active threads processed: ${processedCount}`);
        console.log(`🏁 Completed/orphaned threads found: ${orphanedCount}`);
        console.log(`🧹 Threads successfully archived: ${cleanedCount}`);
        
        if (orphanedCount === 0) {
            console.log(`\n🎉 Great! No orphaned threads found.`);
        } else if (cleanedCount === orphanedCount) {
            console.log(`\n🎉 All orphaned threads have been successfully cleaned up!`);
        } else {
            console.log(`\n⚠️  Some threads could not be cleaned due to errors. Check the log above.`);
        }
        
    } catch (error) {
        console.error('❌ Fatal error during cleanup:', error);
        if (error.code === 50001) {
            console.error('🔒 Missing access permissions. Make sure your Discord account has manage messages/threads permission in the server.');
        } else if (error.code === 50013) {
            console.error('🔒 Missing permissions to edit/archive threads. You need manage threads permission.');
        } else if (error.status === 429) {
            console.error('⏰ Rate limited by Discord. The script includes delays but you may need to wait longer between runs.');
        }
    } finally {
        console.log('\n🔄 Cleaning up connections...');
        await prisma.$disconnect();
        client.destroy();
        console.log('✅ Cleanup script finished.');
        process.exit(0);
    }
}

client.once('ready', () => {
    console.log(`✅ Connected to Discord as: ${client.user.tag}`);
    console.log(`🏠 In ${client.guilds.cache.size} server(s)`);
    cleanupOrphanedThreads();
});

console.log('🚀 Starting cleanup script...');
console.log('🔑 Logging in with bot token...');

client.login(CONFIG.TOKEN).catch(error => {
    console.error('❌ Failed to login to Discord:');
    if (error.code === 'TOKEN_INVALID') {
        console.error('🔑 Invalid Discord token in hardcoded CONFIG');
    } else {
        console.error(error);
    }
    process.exit(1);
});
