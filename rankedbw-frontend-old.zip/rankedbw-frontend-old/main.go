package main

import (
	"html/template"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/gin-gonic/gin"
)

func customLogger() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()

		c.Next()

		latency := time.Since(start)
		method := c.Request.Method
		path := c.Request.URL.Path
		statusCode := c.Writer.Status()
		userAgent := c.Request.UserAgent()

		log.Printf("Request Auditor | %-6s %-30s | %3d | %13v | %s",
			method, path, statusCode, latency, userAgent)
	}
}

func main() {
	os.Setenv("GIN_MODE", "debug")

	r := gin.Default()

	err := r.SetTrustedProxies([]string{"127.0.0.1", "0.0.0.0", "::1"})
	if err != nil {
		log.Printf("Warning: Failed to set trusted proxies: %v", err)
	}

	r.Use(customLogger())

	r.Static("/static", "./static")
	r.StaticFile("/favicon.ico", "./static/images/logo.png")

	tmpl := template.Must(template.ParseGlob("templates/*.html"))
	r.SetHTMLTemplate(tmpl)

	r.GET("/", func(c *gin.Context) {
		c.HTML(http.StatusOK, "index.html", nil)
	})
	r.GET("/staff", func(c *gin.Context) {
		c.HTML(http.StatusOK, "staff.html", nil)
	})

	log.Println("<-------------------------------RANKED BW FRONTEND-------------------------------->")
	for _, route := range r.Routes() {
		log.Printf("Go Routes | %-6s %-30s --> %s", route.Method, route.Path, route.Handler)
	}
	log.Println("<--------------------------------------------------------------------------------->")

	r.Run(":3010")
}
