const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .page-load-animation {
        animation: fadeInUp 0.8s cubic-bezier(0.25, 0.1, 0.25, 1) forwards;
    }
    
    .staff-category {
        margin-bottom: 40px;
    }
    
    .staff-row {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .staff-card {
        opacity: 0;
        transform: translateX(-20px);
        transition: all 0.5s cubic-bezier(0.25, 0.1, 0.25, 1);
        transition-property: opacity, transform;
        will-change: transform, opacity;
    }
    
    .staff-card.visible {
        opacity: 1;
        transform: translateX(0);
    }
    
    .staff-card:hover {
        transform: translateY(-5px) scale(1.02);
    }
    
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    
    .staff-section {
        animation: fadeIn 0.8s ease-out forwards;
    }
    
    .staff-list {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
    }
`;
document.head.appendChild(style);

document.addEventListener('DOMContentLoaded', function() {
    const header = document.querySelector('header');
    const headerHeight = header ? header.offsetHeight : 80; 
    let isScrolling = false;
    
    const updateActiveNav = () => {
        if (isScrolling) return;
        
        const scrollPosition = window.scrollY + (headerHeight / 2); 
        const viewportHeight = window.innerHeight;
        const sections = document.querySelectorAll('.staff-category');
        let activeSection = null;
        let maxVisible = 0;
        
        console.log('--- Scroll Update ---');
        console.log('Scroll Y:', window.scrollY, '| Header Height:', headerHeight, '| Viewport Height:', viewportHeight);
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - headerHeight - 20;
            const sectionBottom = sectionTop + section.offsetHeight;
            const sectionId = section.getAttribute('id');
            
            if (!sectionId) return;
            
            const isInView = sectionTop <= scrollPosition && sectionBottom >= scrollPosition;
            
            const visibleTop = Math.max(0, scrollPosition - sectionTop);
            const visibleBottom = Math.min(viewportHeight, sectionBottom - scrollPosition);
            const visibleHeight = Math.min(visibleBottom, sectionBottom - scrollPosition, viewportHeight) - 
                                Math.max(0, scrollPosition - sectionTop);
            
            if (isInView && visibleHeight > maxVisible) {
                maxVisible = visibleHeight;
                activeSection = `#${sectionId}`;
                console.log('Section in view:', sectionId, '| Visible height:', visibleHeight);
            }
        });
        
        if (!activeSection) {
            let minDistance = Infinity;
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop - headerHeight - 20;
                const sectionBottom = sectionTop + section.offsetHeight;
                const sectionId = section.getAttribute('id');
                
                if (!sectionId) return;
                
                let distance;
                if (scrollPosition + viewportHeight < sectionTop) {
                    distance = sectionTop - scrollPosition;
                } else if (scrollPosition > sectionBottom) {
                    distance = scrollPosition - sectionBottom;
                } else {
                    distance = 0;
                }
                
                if (distance < minDistance) {
                    minDistance = distance;
                    activeSection = `#${sectionId}`;
                }
            });
        }
        
        if (window.scrollY < 100) {
            activeSection = '#owners';
            console.log('Near top, defaulting to #owners');
        }
        
        if (activeSection) {
            console.log('Setting active section:', activeSection);
            document.querySelectorAll('.staff-nav-item').forEach(item => {
                const isActive = item.getAttribute('href') === activeSection;
                item.classList.toggle('active', isActive);
                if (isActive) {
                    console.log(' - Activated nav item:', item.textContent.trim());
                }
            });
        } else {
            console.log('No active section found');
        }
    };
    
    document.querySelectorAll('.staff-nav-item').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                isScrolling = true;
                
                document.querySelectorAll('.staff-nav-item').forEach(navItem => {
                    navItem.classList.remove('active');
                });
                this.classList.add('active');
                
                const headerOffset = headerHeight + 20;
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
                
                if (history.replaceState) {
                    history.replaceState(null, null, targetId);
                } else {
                    window.location.hash = targetId;
                }
                
                setTimeout(() => {
                    isScrolling = false;
                }, 1000);
            }
        });
    });
    
    let ticking = false;
    
    const handleScroll = () => {
        if (!ticking) {
            window.requestAnimationFrame(() => {
                updateActiveNav();
                ticking = false;
            });
            ticking = true;
        }
    };
    
    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('wheel', handleScroll, { passive: true });
    
    if (window.location.hash) {
        const targetElement = document.querySelector(window.location.hash);
        if (targetElement) {
            setTimeout(() => {
                const headerOffset = headerHeight + 20;
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
                
                setTimeout(updateActiveNav, 100);
            }, 100);
        }
    } else {
        setTimeout(updateActiveNav, 100);
    }
    
    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(updateActiveNav, 100);
    });
    
    const staffSection = document.querySelector('.staff-section');
    if (staffSection) {
        staffSection.classList.add('page-load-animation');
    }
    
    const cards = document.querySelectorAll('.staff-card');
    cards.forEach(card => {
        card.style.opacity = '1';
        card.style.transform = 'translateX(0)';
    });
});

function initAnimations() {
    const cards = document.querySelectorAll('.staff-card');
    
    function isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top <= (window.innerHeight * 1.1) &&
            rect.bottom >= -100
        );
    }

    const staffCategories = document.querySelectorAll('.staff-category');
    
    let lastScrollTop = 0;
    
    function animateCategories() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const isScrollingUp = scrollTop < lastScrollTop;
        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
        
        staffCategories.forEach((category) => {
            const categoryInView = isInViewport(category);
            const cards = category.querySelectorAll('.staff-card');
            
            if (categoryInView) {
                if (!category.classList.contains('visible')) {
                    category.classList.add('visible');
                    cards.forEach((card, index) => {
                        setTimeout(() => {
                            card.classList.add('visible');
                        }, 100 * index);
                    });
                }
            } else if (isScrollingUp) {
                if (category.classList.contains('visible')) {
                    cards.forEach(card => {
                        card.classList.remove('visible');
                    });
                    category.classList.remove('visible');
                }
            }
        });
    }

    let ticking = false;
    
    function onScroll() {
        if (!ticking) {
            window.requestAnimationFrame(() => {
                animateCategories();
                ticking = false;
            });
            ticking = true;
        }
    }
    
    let scrollTimeout;
    
    function handleScroll() {
        if (!scrollTimeout) {
            scrollTimeout = requestAnimationFrame(function() {
                updateActiveNav();
                animateOnScroll();
                scrollTimeout = null;
            });
        }
    }
    
    updateActiveNav();
    
    animateCategories();
    
    window.addEventListener('scroll', onScroll, { passive: true });
    
    window.addEventListener('wheel', onScroll, { passive: true });
    window.addEventListener('touchmove', onScroll, { passive: true });
    
    let resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            animateCategories();
        }, 100);
    });
}
