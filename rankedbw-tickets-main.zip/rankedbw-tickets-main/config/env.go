package config

import "os"

func GetBotToken() string                  { return os.Getenv("BOT_TOKEN") }
func GetDevGuildID() string                { return os.Getenv("DEV_GUILD_ID") }
func GetDeveloperID() string               { return os.Getenv("DEVELOPER_ID") }
func GetMongoDBURL() string                { return os.Getenv("MONGODB_URL") }
func GetDragonflyURL() string              { return os.Getenv("DRAGONFLY_URL") }
func GetSupportRoleID() string             { return os.Getenv("SUPPORT_ROLE_ID") }
func GetPingTicketsRoleID() string         { return os.Getenv("PING_TICKETS_ROLE_ID") }
func GetPriorityTicketRoleIDs() string     { return os.Getenv("PRIORITY_TICKET_ROLE_IDS") }
func GetTranscriptsChannelID() string      { return os.Getenv("TRANSCRIPTS_CHANNEL_ID") }
func GetTicketBlacklistRoleID() string     { return os.Getenv("TICKET_BLACKLIST_ROLE_ID") }
func GetLimitOneTicketCategory() string    { return os.Getenv("LIMIT_ONE_TICKET_CATEGORY") }
func GetStaffOwnerID() string              { return os.Getenv("STAFF_OWNER_ID") }
func GetStaffAdminID() string              { return os.Getenv("STAFF_ADMIN_ID") }
func GetStaffDeveloperID() string          { return os.Getenv("STAFF_DEVELOPER_ID") }
func GetStaffSeniorModID() string          { return os.Getenv("STAFF_SENIOR_MOD_ID") }
func GetStaffModeratorID() string          { return os.Getenv("STAFF_MODERATOR_ID") }
func GetStaffHelperID() string             { return os.Getenv("STAFF_HELPER_ID") }
func GetStaffScreenshareManagerID() string { return os.Getenv("STAFF_SCREENSHARE_MANAGER_ID") }
func GetStaffScreensharerID() string       { return os.Getenv("STAFF_SCREENSHARER_ID") }

func GetStaffRoleID(roleName string) string {
	switch roleName {
	case "owner":
		return GetStaffOwnerID()
	case "admin":
		return GetStaffAdminID()
	case "developer":
		return GetStaffDeveloperID()
	case "senior_mod":
		return GetStaffSeniorModID()
	case "moderator":
		return GetStaffModeratorID()
	case "helper":
		return GetStaffHelperID()
	case "screenshare_manager":
		return GetStaffScreenshareManagerID()
	case "screensharer":
		return GetStaffScreensharerID()
	default:
		return ""
	}
}

func GetAllStaffRoleIDs() []string {
	return []string{
		GetStaffOwnerID(),
		GetStaffAdminID(),
		GetStaffDeveloperID(),
		GetStaffSeniorModID(),
		GetStaffModeratorID(),
		GetStaffHelperID(),
		GetStaffScreenshareManagerID(),
		GetStaffScreensharerID(),
	}
}
