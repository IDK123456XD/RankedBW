package utils

import (
	"github.com/bwmarrin/discordgo"
)

func CreateEmbed(title, description string, color int) *discordgo.MessageEmbed {
	return &discordgo.MessageEmbed{
		Title:       title,
		Description: description,
		Color:       color,
	}
}

func CreateSuccessEmbed(title, description string) *discordgo.MessageEmbed {
	return CreateEmbed(title, description, 0x00FF00)
}

func CreateErrorEmbed(title, description string) *discordgo.MessageEmbed {
	return CreateEmbed(title, description, 0xFF0000)
}

func CreateInfoEmbed(title, description string) *discordgo.MessageEmbed {
	return CreateEmbed(title, description, 0x3498DB)
}

func CreateWarningEmbed(title, description string) *discordgo.MessageEmbed {
	return CreateEmbed(title, description, 0xFFA500)
}
