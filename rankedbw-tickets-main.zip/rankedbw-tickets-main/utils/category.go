package utils

import (
	"context"
	"fmt"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"

	"go.mongodb.org/mongo-driver/bson"
)

func GetCategoryID(ctx context.Context, category models.TicketCategory, guildID string) string {
	key := fmt.Sprintf("ticket:category:%s", category)
	categoryID := database.Dragonfly.Get(ctx, key).Val()

	if categoryID != "" {
		return categoryID
	}

	var mapping models.CategoryMapping
	err := database.GetCategoryMappingsCollection().FindOne(ctx, bson.M{
		"category": string(category),
		"guild_id": guildID,
	}).Decode(&mapping)

	if err != nil {
		return ""
	}

	database.Dragonfly.Set(ctx, key, mapping.CategoryID, 0)

	return mapping.CategoryID
}
