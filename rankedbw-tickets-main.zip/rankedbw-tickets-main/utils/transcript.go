package utils

import (
	"encoding/json"
	"fmt"
	"io"
	"rankedbw-tickets/config"
	"time"

	"github.com/bwmarrin/discordgo"
)

type TranscriptMessage struct {
	ID        string    `json:"id"`
	Author    string    `json:"author"`
	AuthorID  string    `json:"author_id"`
	Content   string    `json:"content"`
	Timestamp time.Time `json:"timestamp"`
	Embeds    int       `json:"embeds_count"`
}

type Transcript struct {
	TicketID     string              `json:"ticket_id"`
	ChannelName  string              `json:"channel_name"`
	CreatorID    string              `json:"creator_id"`
	CreatorTag   string              `json:"creator_tag"`
	ClosedBy     string              `json:"closed_by"`
	ClosedByTag  string              `json:"closed_by_tag"`
	ClosedAt     time.Time           `json:"closed_at"`
	CloseReason  string              `json:"close_reason"`
	Messages     []TranscriptMessage `json:"messages"`
	MessageCount int                 `json:"message_count"`
}

func GenerateTranscript(s *discordgo.Session, channelID, ticketID, creatorID, creatorTag, closedBy, closedByTag, closeReason string) error {
	messages, err := s.ChannelMessages(channelID, 100, "", "", "")
	if err != nil {
		return fmt.Errorf("failed to fetch messages: %v", err)
	}

	transcriptMessages := make([]TranscriptMessage, 0, len(messages))
	for i := len(messages) - 1; i >= 0; i-- {
		msg := messages[i]
		transcriptMessages = append(transcriptMessages, TranscriptMessage{
			ID:        msg.ID,
			Author:    msg.Author.Username,
			AuthorID:  msg.Author.ID,
			Content:   msg.Content,
			Timestamp: msg.Timestamp,
			Embeds:    len(msg.Embeds),
		})
	}

	channel, err := s.Channel(channelID)
	if err != nil {
		return fmt.Errorf("failed to fetch channel: %v", err)
	}

	transcript := Transcript{
		TicketID:     ticketID,
		ChannelName:  channel.Name,
		CreatorID:    creatorID,
		CreatorTag:   creatorTag,
		ClosedBy:     closedBy,
		ClosedByTag:  closedByTag,
		ClosedAt:     time.Now(),
		CloseReason:  closeReason,
		Messages:     transcriptMessages,
		MessageCount: len(transcriptMessages),
	}

	transcriptJSON, err := json.MarshalIndent(transcript, "", "  ")
	if err != nil {
		return fmt.Errorf("failed to marshal transcript: %v", err)
	}

	transcriptsChannelID := config.GetTranscriptsChannelID()
	if transcriptsChannelID == "" {
		return nil
	}

	embed := CreateInfoEmbed("Ticket Transcript", fmt.Sprintf(
		"**Ticket ID:** %s\n**Channel:** %s\n**Creator:** <@%s> (%s)\n**Closed By:** <@%s> (%s)\n**Reason:** %s\n**Messages:** %d",
		ticketID, channel.Name, creatorID, creatorTag, closedBy, closedByTag, closeReason, len(transcriptMessages),
	))

	_, _ = s.ChannelMessageSendEmbed(transcriptsChannelID, embed)

	reader := &jsonReader{data: transcriptJSON}
	_, err = s.ChannelFileSendWithMessage(transcriptsChannelID, fmt.Sprintf("Transcript for ticket `%s`", ticketID), fmt.Sprintf("transcript-%s.json", ticketID), reader)

	return err
}

type jsonReader struct {
	data []byte
	pos  int
}

func (r *jsonReader) Read(p []byte) (n int, err error) {
	if r.pos >= len(r.data) {
		return 0, io.EOF
	}
	n = copy(p, r.data[r.pos:])
	r.pos += n
	if r.pos >= len(r.data) {
		return n, io.EOF
	}
	return n, nil
}
