package handlers

import (
	"context"
	"fmt"
	"rankedbw-tickets/config"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"rankedbw-tickets/utils"
	"strings"
	"time"

	"github.com/bwmarrin/discordgo"
	"go.mongodb.org/mongo-driver/bson"
)

func HandleButtonInteraction(s *discordgo.Session, i *discordgo.InteractionCreate) {
	customID := i.MessageComponentData().CustomID

	if strings.HasPrefix(customID, "ticket_create_") {
		handleTicketCreate(s, i, customID)
		return
	}

	if strings.HasPrefix(customID, "ticket_claim:") {
		handleTicketClaim(s, i, customID)
		return
	}

	if strings.HasPrefix(customID, "ticket_close_button:") {
		handleTicketCloseButton(s, i, customID)
		return
	}

	if strings.HasPrefix(customID, "ticket_close_confirm:") {
		handleTicketCloseConfirm(s, i, customID)
		return
	}

	if customID == "ticket_close_cancel" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseUpdateMessage,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateInfoEmbed("Cancelled", "Ticket close cancelled."),
				},
				Components: []discordgo.MessageComponent{},
			},
		})
		return
	}
}

func handleTicketCreate(s *discordgo.Session, i *discordgo.InteractionCreate, customID string) {
	ctx := context.Background()
	category := models.TicketCategory(strings.TrimPrefix(customID, "ticket_create_"))

	member, err := s.GuildMember(i.GuildID, i.Member.User.ID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to fetch member information."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	blacklistRoleID := config.GetTicketBlacklistRoleID()
	if blacklistRoleID != "" && utils.HasRole(member, blacklistRoleID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Blacklisted", "You are blacklisted from creating tickets."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if category == models.CategoryPriority {
		priorityRoleIDs := config.GetPriorityTicketRoleIDs()
		if priorityRoleIDs != "" {
			allowedRoles := strings.Split(priorityRoleIDs, ",")
			hasAccess := false
			for _, roleID := range allowedRoles {
				roleID = strings.TrimSpace(roleID)
				if utils.HasRole(member, roleID) {
					hasAccess = true
					break
				}
			}
			if !hasAccess {
				s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							utils.CreateErrorEmbed("（ミ￣ー￣ミ）", "You don't have permission to create priority tickets you need at least Prime or higher."),
						},
						Flags: discordgo.MessageFlagsEphemeral,
					},
				})
				return
			}
		}
	}

	if config.GetLimitOneTicketCategory() == "1" {
		existingTicket := database.Dragonfly.Get(ctx, fmt.Sprintf("ticket:user:%s:%s", i.Member.User.ID, category)).Val()
		if existingTicket != "" {
			var dbTicket models.Ticket
			err := database.GetTicketsCollection().FindOne(ctx, bson.M{
				"creator_id": i.Member.User.ID,
				"category":   string(category),
				"status":     models.TicketStatusOpen,
			}).Decode(&dbTicket)

			if err != nil {
				database.Dragonfly.Del(ctx, fmt.Sprintf("ticket:user:%s:%s", i.Member.User.ID, category))
			} else {
				s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							utils.CreateErrorEmbed("Error", fmt.Sprintf("You already have an open %s ticket: <#%s>", category.Display(), existingTicket)),
						},
						Flags: discordgo.MessageFlagsEphemeral,
					},
				})
				return
			}
		}
	}

	modal := getModalForCategory(category)
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseModal,
		Data: &discordgo.InteractionResponseData{
			CustomID:   fmt.Sprintf("ticket_modal:%s", category),
			Title:      fmt.Sprintf("%s Ticket", category.Display()),
			Components: modal,
		},
	})
}

func getModalForCategory(category models.TicketCategory) []discordgo.MessageComponent {
	switch category {
	case models.CategoryGeneral:
		return []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question1",
						Label:       "What can we help you with?",
						Style:       discordgo.TextInputParagraph,
						Placeholder: "Describe your issue or question...",
						Required:    true,
						MaxLength:   1000,
					},
				},
			},
		}
	case models.CategoryReport:
		return []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question1",
						Label:       "Discord ID / IGN of player",
						Style:       discordgo.TextInputShort,
						Placeholder: "Player's Discord ID or In-Game Name",
						Required:    true,
						MaxLength:   100,
					},
				},
			},
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question2",
						Label:       "What offense did they commit?",
						Style:       discordgo.TextInputParagraph,
						Placeholder: "Describe the rule violation...",
						Required:    true,
						MaxLength:   500,
					},
				},
			},
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question3",
						Label:       "Proof (links to screenshots, videos, etc.)",
						Style:       discordgo.TextInputParagraph,
						Placeholder: "Provide links to evidence...",
						Required:    false,
						MaxLength:   500,
					},
				},
			},
		}
	case models.CategoryAppeals:
		return []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question1",
						Label:       "What punishment are you appealing?",
						Style:       discordgo.TextInputShort,
						Placeholder: "Ban, mute, strike, etc.",
						Required:    true,
						MaxLength:   100,
					},
				},
			},
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question2",
						Label:       "Why should we revoke this punishment?",
						Style:       discordgo.TextInputParagraph,
						Placeholder: "Explain your reasoning...",
						Required:    true,
						MaxLength:   1000,
					},
				},
			},
		}
	case models.CategoryScoring:
		return []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question1",
						Label:       "Issue Type (Stats / Game)",
						Style:       discordgo.TextInputShort,
						Placeholder: "Stats Issue or Game Issue",
						Required:    true,
						MaxLength:   50,
					},
				},
			},
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question2",
						Label:       "Game ID (if applicable)",
						Style:       discordgo.TextInputShort,
						Placeholder: "RBW Game ID number",
						Required:    false,
						MaxLength:   100,
					},
				},
			},
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question3",
						Label:       "Describe the issue",
						Style:       discordgo.TextInputParagraph,
						Placeholder: "What's wrong and what should it be?",
						Required:    true,
						MaxLength:   1000,
					},
				},
			},
		}
	case models.CategoryStore:
		return []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question1",
						Label:       "What have you purchased?",
						Style:       discordgo.TextInputParagraph,
						Placeholder: "Describe the item, package, or rank...",
						Required:    true,
						MaxLength:   500,
					},
				},
			},
		}
	case models.CategoryPayouts:
		return []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question1",
						Label:       "What prize did you win?",
						Style:       discordgo.TextInputParagraph,
						Placeholder: "Tournament/event name and prize...",
						Required:    true,
						MaxLength:   500,
					},
				},
			},
		}
	case models.CategoryPriority:
		return []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question1",
						Label:       "Priority Issue Type",
						Style:       discordgo.TextInputShort,
						Placeholder: "Store/Report/Other",
						Required:    true,
						MaxLength:   50,
					},
				},
			},
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question2",
						Label:       "Describe the priority issue",
						Style:       discordgo.TextInputParagraph,
						Placeholder: "Explain why this requires priority attention...",
						Required:    true,
						MaxLength:   1000,
					},
				},
			},
		}
	default:
		return []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.TextInput{
						CustomID:    "question1",
						Label:       "Describe your issue",
						Style:       discordgo.TextInputParagraph,
						Placeholder: "Tell us what you need help with...",
						Required:    true,
						MaxLength:   1000,
					},
				},
			},
		}
	}
}

func HandleModalSubmit(s *discordgo.Session, i *discordgo.InteractionCreate) {
	customID := i.ModalSubmitData().CustomID
	if !strings.HasPrefix(customID, "ticket_modal:") {
		return
	}

	category := models.TicketCategory(strings.TrimPrefix(customID, "ticket_modal:"))
	createTicketFromModal(s, i, category)
}

func formatQAForCategory(category models.TicketCategory, responses map[string]string) string {
	switch category {
	case models.CategoryGeneral:
		return fmt.Sprintf("**What can we help you with?**\n%s", responses["question1"])
	case models.CategoryReport:
		return fmt.Sprintf("**Discord ID / IGN of player you're reporting:**\n%s\n\n**What offense did they commit?**\n%s\n\n**Proof:**\n%s",
			responses["question1"], responses["question2"], getOrDefault(responses, "question3", "No proof provided"))
	case models.CategoryAppeals:
		return fmt.Sprintf("**What punishment are you appealing?**\n%s\n\n**Why should we revoke this punishment?**\n%s",
			responses["question1"], responses["question2"])
	case models.CategoryScoring:
		return fmt.Sprintf("**Issue Type:**\n%s\n\n**Game ID:**\n%s\n\n**Issue Description:**\n%s",
			responses["question1"], getOrDefault(responses, "question2", "N/A"), responses["question3"])
	case models.CategoryStore:
		return fmt.Sprintf("**What have you purchased?**\n%s", responses["question1"])
	case models.CategoryPayouts:
		return fmt.Sprintf("**What prize did you win?**\n%s", responses["question1"])
	default:
		return fmt.Sprintf("**Issue Description:**\n%s", responses["question1"])
	}
}

func getOrDefault(m map[string]string, key, defaultValue string) string {
	if val, ok := m[key]; ok && val != "" {
		return val
	}
	return defaultValue
}

func createTicketFromModal(s *discordgo.Session, i *discordgo.InteractionCreate, category models.TicketCategory) {
	ctx := context.Background()

	categoryID := utils.GetCategoryID(ctx, category, i.GuildID)
	if categoryID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Ticket category not found. Please contact an administrator."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	channelName := fmt.Sprintf("ticket-%s", i.Member.User.Username)
	supportRoleID := config.GetSupportRoleID()
	pingRoleID := config.GetPingTicketsRoleID()
	if pingRoleID == "" {
		pingRoleID = supportRoleID
	}

	channel, err := s.GuildChannelCreateComplex(i.GuildID, discordgo.GuildChannelCreateData{
		Name:     channelName,
		Type:     discordgo.ChannelTypeGuildText,
		ParentID: categoryID,
		PermissionOverwrites: []*discordgo.PermissionOverwrite{
			{
				ID:   i.GuildID,
				Type: discordgo.PermissionOverwriteTypeRole,
				Deny: discordgo.PermissionViewChannel,
			},
			{
				ID:    i.Member.User.ID,
				Type:  discordgo.PermissionOverwriteTypeMember,
				Allow: discordgo.PermissionViewChannel | discordgo.PermissionSendMessages | discordgo.PermissionReadMessageHistory,
			},
			{
				ID:    supportRoleID,
				Type:  discordgo.PermissionOverwriteTypeRole,
				Allow: discordgo.PermissionViewChannel | discordgo.PermissionSendMessages | discordgo.PermissionReadMessageHistory,
			},
		},
	})
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to create ticket channel."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed("Ticket Created", fmt.Sprintf("Your ticket has been created: <#%s>", channel.ID)),
			},
			Flags: discordgo.MessageFlagsEphemeral,
		},
	})

	ticketID := fmt.Sprintf("%s-%d", category, time.Now().Unix())

	modalData := i.ModalSubmitData()
	responses := make(map[string]string)
	for _, row := range modalData.Components {
		for _, comp := range row.(*discordgo.ActionsRow).Components {
			if textInput, ok := comp.(*discordgo.TextInput); ok {
				responses[textInput.CustomID] = textInput.Value
			}
		}
	}

	qaDescription := formatQAForCategory(category, responses)
	qaEmbed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("%s %s Ticket Information", category.Emoji(), category.Display()),
		Description: qaDescription,
		Color:       0x5865F2,
		Footer: &discordgo.MessageEmbedFooter{
			Text: fmt.Sprintf("Opened by %s", i.Member.User.String()),
		},
		Timestamp: time.Now().Format(time.RFC3339),
	}

	qaMsg, err := s.ChannelMessageSendComplex(channel.ID, &discordgo.MessageSend{
		Content: fmt.Sprintf("<@%s> <@&%s>", i.Member.User.ID, pingRoleID),
		Embeds:  []*discordgo.MessageEmbed{qaEmbed},
		Components: []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.Button{
						Label:    "Claim",
						Style:    discordgo.SuccessButton,
						CustomID: fmt.Sprintf("ticket_claim:%s", ticketID),
					},
					discordgo.Button{
						Label:    "Close",
						Style:    discordgo.DangerButton,
						CustomID: fmt.Sprintf("ticket_close_button:%s", ticketID),
					},
				},
			},
		},
	})
	if err == nil {
		s.ChannelMessagePin(channel.ID, qaMsg.ID)
	}

	ticket := models.Ticket{
		TicketID:      ticketID,
		ChannelID:     channel.ID,
		CategoryID:    categoryID,
		Category:      category,
		Status:        models.TicketStatusOpen,
		CreatorID:     i.Member.User.ID,
		CreatorTag:    i.Member.User.String(),
		CreatedAt:     time.Now(),
		PinnedMessage: qaMsg.ID,
	}
	database.GetTicketsCollection().InsertOne(ctx, ticket)
	database.Dragonfly.Set(ctx, fmt.Sprintf("ticket:channel:%s", channel.ID), ticketID, 0)
	database.Dragonfly.Set(ctx, fmt.Sprintf("ticket:user:%s:%s", i.Member.User.ID, category), channel.ID, 0)
}

func handleTicketClaim(s *discordgo.Session, i *discordgo.InteractionCreate, customID string) {
	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to claim tickets."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	ctx := context.Background()
	ticketID := strings.TrimPrefix(customID, "ticket_claim:")

	var ticket models.Ticket
	err := database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to find ticket."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if ticket.ClaimedBy != "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Already Claimed", fmt.Sprintf("This ticket is already claimed by <@%s>.", ticket.ClaimedBy)),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	now := time.Now()
	database.GetTicketsCollection().UpdateOne(ctx,
		bson.M{"ticket_id": ticketID},
		bson.M{
			"$set": bson.M{
				"claimed_by": i.Member.User.ID,
				"claimed_at": now,
			},
		},
	)

	claim := models.TicketClaim{
		UserID:    i.Member.User.ID,
		TicketID:  ticketID,
		ClaimedAt: now,
	}
	database.GetTicketClaimsCollection().InsertOne(ctx, claim)

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed("Ticket Claimed", fmt.Sprintf("<@%s> has claimed this ticket.", i.Member.User.ID)),
			},
		},
	})
}

func handleTicketCloseButton(s *discordgo.Session, i *discordgo.InteractionCreate, customID string) {
	ctx := context.Background()
	ticketID := strings.TrimPrefix(customID, "ticket_close_button:")

	var ticket models.Ticket
	err := database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to find ticket."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	isCreator := i.Member.User.ID == ticket.CreatorID
	hasPermission := utils.HasPermission(s, i.GuildID, i.Member.User.ID)

	if !isCreator && !hasPermission {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "Only the ticket creator or support staff can close this ticket."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if isCreator && !hasPermission {
		embed := utils.CreateWarningEmbed("Close Ticket", "Are you sure you want to close this ticket?")
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{embed},
				Components: []discordgo.MessageComponent{
					discordgo.ActionsRow{
						Components: []discordgo.MessageComponent{
							discordgo.Button{
								Label:    "Close",
								Style:    discordgo.DangerButton,
								CustomID: fmt.Sprintf("ticket_close_confirm:%s:Resolved", ticketID),
							},
							discordgo.Button{
								Label:    "Keep Open",
								Style:    discordgo.SecondaryButton,
								CustomID: "ticket_close_cancel",
							},
						},
					},
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateInfoEmbed("Closing Ticket", "This ticket will be closed in 3 seconds..."),
			},
		},
	})

	utils.GenerateTranscript(s, i.ChannelID, ticketID, ticket.CreatorID, ticket.CreatorTag, i.Member.User.ID, i.Member.User.String(), "Resolved")

	time.Sleep(3 * time.Second)
	closeTicketNow(s, i.GuildID, i.ChannelID, ticketID, ticket.CreatorID, ticket.CreatorTag, i.Member.User.ID, i.Member.User.String(), "Resolved")
}

func handleTicketCloseConfirm(s *discordgo.Session, i *discordgo.InteractionCreate, customID string) {
	parts := strings.SplitN(strings.TrimPrefix(customID, "ticket_close_confirm:"), ":", 2)
	if len(parts) != 2 {
		return
	}

	ticketID := parts[0]
	reason := parts[1]

	ctx := context.Background()
	var ticket models.Ticket
	err := database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)
	if err != nil {
		return
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseUpdateMessage,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateInfoEmbed("Closing Ticket", "This ticket will be closed in 3 seconds..."),
			},
			Components: []discordgo.MessageComponent{},
		},
	})

	utils.GenerateTranscript(s, i.ChannelID, ticketID, ticket.CreatorID, ticket.CreatorTag, i.Member.User.ID, i.Member.User.String(), reason)

	time.Sleep(3 * time.Second)
	closeTicketNow(s, i.GuildID, i.ChannelID, ticketID, ticket.CreatorID, ticket.CreatorTag, i.Member.User.ID, i.Member.User.String(), reason)
}

func closeTicketNow(s *discordgo.Session, guildID, channelID, ticketID, creatorID, creatorTag, closerID, closerTag, reason string) {
	ctx := context.Background()

	now := time.Now()
	database.GetTicketsCollection().UpdateOne(ctx,
		bson.M{"ticket_id": ticketID},
		bson.M{
			"$set": bson.M{
				"status":       models.TicketStatusClosed,
				"closed_at":    now,
				"closed_by":    closerID,
				"close_reason": reason,
			},
		},
	)

	var ticket models.Ticket
	database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)

	database.Dragonfly.Del(ctx, fmt.Sprintf("ticket:channel:%s", channelID))
	database.Dragonfly.Del(ctx, fmt.Sprintf("ticket:user:%s:%s", creatorID, ticket.Category))

	s.ChannelDelete(channelID)

	dmChannel, err := s.UserChannelCreate(creatorID)
	if err == nil {
		duration := now.Sub(ticket.CreatedAt)
		hours := int(duration.Hours())
		minutes := int(duration.Minutes()) % 60

		description := fmt.Sprintf("Your ticket has been closed.\n\n**Reason:** %s\n**Closed by:** <@%s>", reason, closerID)

		if ticket.ClaimedBy != "" {
			description += fmt.Sprintf("\n**Claimed by:** <@%s>", ticket.ClaimedBy)
		}

		description += fmt.Sprintf("\n\n**Opened At:** <t:%d:F>\n**Closed At:** <t:%d:F>\n**Open For:** %dh %dm",
			ticket.CreatedAt.Unix(), now.Unix(), hours, minutes)

		embed := utils.CreateInfoEmbed("Ticket Closed", description)
		s.ChannelMessageSendEmbed(dmChannel.ID, embed)
	}
}
