package handlers

import (
	"rankedbw-tickets/commands/tickets"
	"rankedbw-tickets/config"

	"github.com/bwmarrin/discordgo"
)

func HandleInteractionCreate(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if i.GuildID != config.GetDevGuildID() {
		if i.Type == discordgo.InteractionApplicationCommand {
			s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						{
							Title:       "⚠️ Wrong Context",
							Description: "This bot only performs it's duties in one and only 1 specific discord server none of it's commands or functionality will work here",
							Color:       0xFFCC00,
						},
					},
					Flags: discordgo.MessageFlagsEphemeral,
				},
			})
		}
		return
	}

	switch i.Type {
	case discordgo.InteractionApplicationCommand:
		if i.ApplicationCommandData().Name == "ticket" {
			tickets.GetHandler(s, i)
		}
	case discordgo.InteractionMessageComponent:
		HandleButtonInteraction(s, i)
	case discordgo.InteractionModalSubmit:
		HandleModalSubmit(s, i)
	}
}
