package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/database"
	"rankedbw-tickets/utils"

	"github.com/bwmarrin/discordgo"
)

func RemoveHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to use this command."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	ctx := context.Background()
	ticketID := database.Dragonfly.Get(ctx, fmt.Sprintf("ticket:channel:%s", i.ChannelID)).Val()
	if ticketID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "This is not a ticket channel."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options[0].Options

	var targetID string
	var successMessage string
	var isUser bool

	for _, opt := range options {
		if opt.Name == "user" && opt.UserValue(s) != nil {
			targetUser := opt.UserValue(s)
			if targetUser.ID == s.State.User.ID {
				s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Description: "🥚 You can't remove me silly if you do who will handle all these tickets huh? But if you really want to remove me and did not mean this as a joke it really hurts my feelings and me knowing you would do such a thing :(",
								Color:       0xFFD700,
							},
						},
						Flags: discordgo.MessageFlagsEphemeral,
					},
				})
				return
			}
			targetID = targetUser.ID
			successMessage = fmt.Sprintf("<@%s> has been removed from the ticket.", targetID)
			isUser = true
			break
		} else if opt.Name == "role" && opt.RoleValue(s, i.GuildID) != nil {
			targetRole := opt.RoleValue(s, i.GuildID)
			targetID = targetRole.ID
			successMessage = fmt.Sprintf("<@&%s> has been removed from the ticket.", targetID)
			break
		}
	}

	if targetID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "You must provide either a user or a role."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	err := s.ChannelPermissionDelete(i.ChannelID, targetID)
	if err != nil {
		errorMsg := "Failed to remove from ticket."
		if isUser {
			errorMsg = "Failed to remove user from ticket."
		} else {
			errorMsg = "Failed to remove role from ticket."
		}
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", errorMsg),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	title := "User Removed"
	if !isUser {
		title = "Role Removed"
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed(title, successMessage),
			},
		},
	})
}
