package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/config"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"rankedbw-tickets/utils"
	"strings"
	"time"

	"github.com/bwmarrin/discordgo"
	"go.mongodb.org/mongo-driver/bson"
)

func OpenHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx := context.Background()

	options := i.ApplicationCommandData().Options[0].Options
	category := models.TicketCategory(options[0].StringValue())

	member, err := s.GuildMember(i.GuildID, i.Member.User.ID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to fetch member information."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	blacklistRoleID := config.GetTicketBlacklistRoleID()
	if blacklistRoleID != "" && utils.HasRole(member, blacklistRoleID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Blacklisted", "You are blacklisted from creating tickets."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if category == models.CategoryPriority {
		priorityRoleIDs := config.GetPriorityTicketRoleIDs()
		if priorityRoleIDs != "" {
			allowedRoles := strings.Split(priorityRoleIDs, ",")
			hasAccess := false
			for _, roleID := range allowedRoles {
				roleID = strings.TrimSpace(roleID)
				if utils.HasRole(member, roleID) {
					hasAccess = true
					break
				}
			}
			if !hasAccess {
				s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							utils.CreateErrorEmbed("（ミ￣ー￣ミ）", "You don't have permission to create priority tickets you need at least Prime or higher."),
						},
						Flags: discordgo.MessageFlagsEphemeral,
					},
				})
				return
			}
		}
	}

	if config.GetLimitOneTicketCategory() == "1" {
		existingTicket := database.Dragonfly.Get(ctx, fmt.Sprintf("ticket:user:%s:%s", i.Member.User.ID, category)).Val()
		if existingTicket != "" {
			var dbTicket models.Ticket
			err := database.GetTicketsCollection().FindOne(ctx, bson.M{
				"creator_id": i.Member.User.ID,
				"category":   string(category),
				"status":     models.TicketStatusOpen,
			}).Decode(&dbTicket)

			if err != nil {
				database.Dragonfly.Del(ctx, fmt.Sprintf("ticket:user:%s:%s", i.Member.User.ID, category))
			} else {
				s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							utils.CreateErrorEmbed("Error", fmt.Sprintf("You already have an open %s ticket: <#%s>", category.Display(), existingTicket)),
						},
						Flags: discordgo.MessageFlagsEphemeral,
					},
				})
				return
			}
		}
	}

	categoryID := utils.GetCategoryID(ctx, category, i.GuildID)
	if categoryID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Ticket category not found. Please contact an administrator."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	channelName := fmt.Sprintf("ticket-%s", i.Member.User.Username)
	supportRoleID := config.GetSupportRoleID()
	pingRoleID := config.GetPingTicketsRoleID()
	if pingRoleID == "" {
		pingRoleID = supportRoleID
	}

	channel, err := s.GuildChannelCreateComplex(i.GuildID, discordgo.GuildChannelCreateData{
		Name:     channelName,
		Type:     discordgo.ChannelTypeGuildText,
		ParentID: categoryID,
		PermissionOverwrites: []*discordgo.PermissionOverwrite{
			{
				ID:   i.GuildID,
				Type: discordgo.PermissionOverwriteTypeRole,
				Deny: discordgo.PermissionViewChannel,
			},
			{
				ID:    i.Member.User.ID,
				Type:  discordgo.PermissionOverwriteTypeMember,
				Allow: discordgo.PermissionViewChannel | discordgo.PermissionSendMessages | discordgo.PermissionReadMessageHistory,
			},
			{
				ID:    supportRoleID,
				Type:  discordgo.PermissionOverwriteTypeRole,
				Allow: discordgo.PermissionViewChannel | discordgo.PermissionSendMessages | discordgo.PermissionReadMessageHistory,
			},
		},
	})
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to create ticket channel."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed("Ticket Created", fmt.Sprintf("Your ticket has been created: <#%s>", channel.ID)),
			},
			Flags: discordgo.MessageFlagsEphemeral,
		},
	})

	ticketID := fmt.Sprintf("%s-%d", category, time.Now().Unix())

	var description string
	switch category {
	case models.CategoryGeneral:
		description = "Thank you for contacting support. A staff member will be with you shortly.\n\n**What can we help you with?**"
	case models.CategoryReport:
		description = "Thank you for contacting support. A staff member will be with you shortly.\n\n**Discord ID / IGN of player you're reporting.**\n\n**What offense did they commit?**\n\n**Do you have any proof? Provide links to screenshots, videos, or other evidence.**"
	case models.CategoryAppeals:
		description = "Thank you for contacting support. A staff member will be with you shortly.\n\n**What punishment would you like to appeal? Specify the ban, mute, or strike you're appealing.**\n\n**Why should we revoke this punishment? Explain your reasoning for why this appeal should be granted.**"
	case models.CategoryScoring:
		description = "Thank you for contacting support. A staff member will be with you shortly.\n\n**Stats Issues:**\n**Which stat is wrong, and why?** Please specify the stat and explain the discrepancy.\n\n**Ranked Game Issues:**\n**What is the Game ID?** Please provide the game ID number from RBW\n\n**What is the issue with your game?**\n- I need the game voided\n- I need the game scored\n- The game wasn't Scored Correctly"
	case models.CategoryStore:
		description = "Thank you for contacting support. A staff member will be with you shortly.\n\n**What have you purchased?** Describe the item, package, or rank you bought."
	case models.CategoryPayouts:
		description = "Thank you for contacting support. A staff member will be with you shortly.\n\n**What prize did you win?** Specify the tournament or event prize you're claiming."
	default:
		description = "Thank you for contacting support. A staff member will be with you shortly."
	}

	embed := utils.CreateInfoEmbed(fmt.Sprintf("%s %s Ticket", category.Emoji(), category.Display()), description)

	msg, err := s.ChannelMessageSendComplex(channel.ID, &discordgo.MessageSend{
		Content: fmt.Sprintf("<@%s> <@&%s>", i.Member.User.ID, pingRoleID),
		Embeds:  []*discordgo.MessageEmbed{embed},
		Components: []discordgo.MessageComponent{
			discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{
					discordgo.Button{
						Label:    "Claim",
						Style:    discordgo.SuccessButton,
						CustomID: fmt.Sprintf("ticket_claim:%s", ticketID),
					},
					discordgo.Button{
						Label:    "Close",
						Style:    discordgo.DangerButton,
						CustomID: fmt.Sprintf("ticket_close_button:%s", ticketID),
					},
				},
			},
		},
	})
	if err == nil {
		s.ChannelMessagePin(channel.ID, msg.ID)
	}

	ticket := models.Ticket{
		TicketID:      ticketID,
		ChannelID:     channel.ID,
		CategoryID:    categoryID,
		Category:      category,
		Status:        models.TicketStatusOpen,
		CreatorID:     i.Member.User.ID,
		CreatorTag:    i.Member.User.String(),
		CreatedAt:     time.Now(),
		PinnedMessage: msg.ID,
	}
	database.GetTicketsCollection().InsertOne(ctx, ticket)
	database.Dragonfly.Set(ctx, fmt.Sprintf("ticket:channel:%s", channel.ID), ticketID, 0)
	database.Dragonfly.Set(ctx, fmt.Sprintf("ticket:user:%s:%s", i.Member.User.ID, category), channel.ID, 0)
}
