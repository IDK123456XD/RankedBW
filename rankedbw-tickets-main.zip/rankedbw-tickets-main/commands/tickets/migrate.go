package tickets

import (
	"context"
	"encoding/json"
	"fmt"
	"rankedbw-tickets/config"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"strings"

	"github.com/bwmarrin/discordgo"
	"go.mongodb.org/mongo-driver/bson"
)

func MigrateHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if i.Member.User.ID != config.GetDeveloperID() {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Description: "🔒 You don't have permission to run migrations.",
						Color:       0xFF0000,
					},
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options
	if len(options) == 0 {
		respondError(s, i, "No migration type specified.")
		return
	}

	subOptions := options[0].Options
	if len(subOptions) == 0 {
		respondError(s, i, "No migration type specified.")
		return
	}

	migrationType := subOptions[0].StringValue()

	if migrationType == "add priority tickets" {
		handleAddPriorityTickets(s, i)
	} else if migrationType == "sync categories to db" {
		handleSyncCategoriesToDB(s, i)
	} else if migrationType == "recreate panel" {
		handleRecreatePanel(s, i)
	} else {
		respondError(s, i, fmt.Sprintf("Unknown migration type: %s", migrationType))
	}
}

func handleAddPriorityTickets(s *discordgo.Session, i *discordgo.InteractionCreate) {
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Flags: discordgo.MessageFlagsEphemeral,
		},
	})

	ctx := context.Background()

	var panelData struct {
		ChannelID string `json:"channel_id" bson:"channel_id"`
		MessageID string `json:"message_id" bson:"message_id"`
	}

	val, err := database.Dragonfly.Get(ctx, "persistent:ticket_panel").Result()
	if err == nil {
		if err := json.Unmarshal([]byte(val), &panelData); err != nil {
			followUpError(s, i, "Failed to parse panel data from cache.")
			return
		}
	} else {
		var persistentMsg models.PersistentMessage
		err := database.GetPersistentMessagesCollection().FindOne(ctx, bson.M{
			"type": "ticket_panel",
		}).Decode(&persistentMsg)

		if err != nil {
			followUpError(s, i, "Failed to find ticket panel. Please run /ticket setup first.")
			return
		}

		panelData.ChannelID = persistentMsg.ChannelID
		panelData.MessageID = persistentMsg.MessageID

		cacheData, _ := json.Marshal(panelData)
		database.Dragonfly.Set(ctx, "persistent:ticket_panel", cacheData, 0)
	}

	msg, err := s.ChannelMessage(panelData.ChannelID, panelData.MessageID)
	if err != nil {
		followUpError(s, i, "Failed to fetch ticket panel message.")
		return
	}

	if strings.Contains(msg.Embeds[0].Description, "🛑") {
		followUpError(s, i, "Priority tickets already exist in the panel.")
		return
	}

	guildChannels, err := s.GuildChannels(i.GuildID)
	if err != nil {
		followUpError(s, i, "Failed to fetch guild channels.")
		return
	}

	var priorityCategoryID string
	for _, ch := range guildChannels {
		if ch.Type == discordgo.ChannelTypeGuildCategory && strings.EqualFold(ch.Name, "priority") {
			priorityCategoryID = ch.ID
			break
		}
	}

	if priorityCategoryID == "" {
		priorityCategory, err := s.GuildChannelCreateComplex(i.GuildID, discordgo.GuildChannelCreateData{
			Name: "🛑 PRIORITY TICKETS 🛑",
			Type: discordgo.ChannelTypeGuildCategory,
		})
		if err != nil {
			followUpError(s, i, "Failed to create Priority category.")
			return
		}
		priorityCategoryID = priorityCategory.ID
	}

	categoryKey := "ticket:category:" + string(models.CategoryPriority)
	if err := database.Dragonfly.Set(ctx, categoryKey, priorityCategoryID, 0).Err(); err != nil {
		followUpError(s, i, "Failed to store category in cache.")
		return
	}

	categoryMapping := models.CategoryMapping{
		Category:   models.CategoryPriority,
		CategoryID: priorityCategoryID,
		GuildID:    i.GuildID,
	}
	database.GetCategoryMappingsCollection().InsertOne(ctx, categoryMapping)

	newDescription := msg.Embeds[0].Description + "\n🛑 **PRIORITY** - For priority support issues (restricted access)"

	var actionRows []*discordgo.ActionsRow
	if len(msg.Components) > 0 {
		for _, component := range msg.Components {
			if actionRow, ok := component.(*discordgo.ActionsRow); ok {
				actionRows = append(actionRows, actionRow)
			}
		}
	}

	priorityButton := discordgo.Button{
		Label:    "Priority",
		Style:    discordgo.DangerButton,
		CustomID: "ticket_create_priority",
		Emoji: &discordgo.ComponentEmoji{
			Name: "🛑",
		},
	}

	if len(actionRows) > 0 {
		lastRow := actionRows[len(actionRows)-1]
		if len(lastRow.Components) < 5 {
			lastRow.Components = append(lastRow.Components, priorityButton)
		} else {
			actionRows = append(actionRows, &discordgo.ActionsRow{
				Components: []discordgo.MessageComponent{priorityButton},
			})
		}
	} else {
		actionRows = append(actionRows, &discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{priorityButton},
		})
	}

	var components []discordgo.MessageComponent
	for _, row := range actionRows {
		components = append(components, row)
	}

	embeds := []*discordgo.MessageEmbed{
		{
			Title:       msg.Embeds[0].Title,
			Description: newDescription,
			Color:       msg.Embeds[0].Color,
		},
	}

	editedMsg, err := s.ChannelMessageEditComplex(&discordgo.MessageEdit{
		Channel:    panelData.ChannelID,
		ID:         panelData.MessageID,
		Embeds:     &embeds,
		Components: &components,
	})
	if err != nil {
		followUpError(s, i, fmt.Sprintf("Failed to update panel: %v", err))
		return
	}

	database.Dragonfly.Del(ctx, "persistent:ticket_panel")

	newPanelData, _ := json.Marshal(map[string]string{
		"channel_id": editedMsg.ChannelID,
		"message_id": editedMsg.ID,
	})
	database.Dragonfly.Set(ctx, "persistent:ticket_panel", newPanelData, 0)

	s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{
			{
				Description: "✅ Successfully added Priority tickets to the panel!\n\n" +
					"**Created:**\n" +
					"• Priority category channel\n" +
					"• Priority button in ticket panel\n\n" +
					"**Note:** Don't forget to set `PRIORITY_TICKET_ROLE_IDS` in your .env file (comma-separated role IDs).",
				Color: 0x00FF00,
			},
		},
	})
}

func respondError(s *discordgo.Session, i *discordgo.InteractionCreate, message string) {
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				{
					Description: "❌ " + message,
					Color:       0xFF0000,
				},
			},
			Flags: discordgo.MessageFlagsEphemeral,
		},
	})
}

func followUpError(s *discordgo.Session, i *discordgo.InteractionCreate, message string) {
	s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{
			{
				Description: "❌ " + message,
				Color:       0xFF0000,
			},
		},
	})
}

func handleSyncCategoriesToDB(s *discordgo.Session, i *discordgo.InteractionCreate) {
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Flags: discordgo.MessageFlagsEphemeral,
		},
	})

	ctx := context.Background()

	categories := []models.TicketCategory{
		models.CategoryGeneral,
		models.CategoryReport,
		models.CategoryAppeals,
		models.CategoryScoring,
		models.CategoryStore,
		models.CategoryPayouts,
		models.CategoryPriority,
	}

	synced := 0
	failed := 0
	var syncDetails strings.Builder

	for _, cat := range categories {
		key := fmt.Sprintf("ticket:category:%s", cat)
		categoryID := database.Dragonfly.Get(ctx, key).Val()

		if categoryID == "" {
			syncDetails.WriteString(fmt.Sprintf("⚠️ %s: Not found in cache\n", cat.Display()))
			failed++
			continue
		}

		categoryMapping := models.CategoryMapping{
			Category:   cat,
			CategoryID: categoryID,
			GuildID:    i.GuildID,
		}

		_, err := database.GetCategoryMappingsCollection().InsertOne(ctx, categoryMapping)
		if err != nil {
			syncDetails.WriteString(fmt.Sprintf("❌ %s: Failed to save\n", cat.Display()))
			failed++
		} else {
			syncDetails.WriteString(fmt.Sprintf("✅ %s: Synced (ID: %s)\n", cat.Display(), categoryID[:8]+"...)"))
			synced++
		}
	}

	summary := fmt.Sprintf("**Sync Complete**\n\nSynced: %d\nFailed: %d\n\n%s",
		synced, failed, syncDetails.String())

	s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{
			{
				Description: summary,
				Color:       0x00FF00,
			},
		},
	})
}

func handleRecreatePanel(s *discordgo.Session, i *discordgo.InteractionCreate) {
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Flags: discordgo.MessageFlagsEphemeral,
		},
	})

	ctx := context.Background()
	devGuildID := config.GetDevGuildID()

	var panelData struct {
		ChannelID string `json:"channel_id" bson:"channel_id"`
		MessageID string `json:"message_id" bson:"message_id"`
	}

	var persistentMsg models.PersistentMessage
	err := database.GetPersistentMessagesCollection().FindOne(ctx, bson.M{
		"type": "ticket_panel",
	}).Decode(&persistentMsg)

	if err != nil {
		followUpError(s, i, "Failed to find existing ticket panel.")
		return
	}

	panelData.ChannelID = persistentMsg.ChannelID
	panelData.MessageID = persistentMsg.MessageID

	channel, chanErr := s.Channel(panelData.ChannelID)
	if chanErr != nil || channel.GuildID != devGuildID {
		followUpError(s, i, "Panel found but not in dev guild. Please run /ticket setup in dev guild first.")
		return
	}

	s.ChannelMessageDelete(panelData.ChannelID, panelData.MessageID)

	embed := &discordgo.MessageEmbed{
		Title:       "Ranked Bedwars Support",
		Description: "Select the category that best fits your needs:\n\n💬 **General** — Ask questions and get help\n🚨 **Report** — Report a player for breaking the rules\n⚖️ **Appeal** — Appeal a strike, mute, or ban\n🎯 **Scoring** — Dispute game outcomes or stats\n🛍️ **Store** — Store or payment issues\n💸 **Payouts** — Prize claims and payouts\n🛑 **Priority** — For priority support issues. Restricted to Prime or higher\n\n**Click a button below to open a ticket**",
		Color:       0x5865F2,
	}

	buttons := []discordgo.MessageComponent{
		discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{
				discordgo.Button{
					Label:    "General",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_general",
					Emoji: &discordgo.ComponentEmoji{
						Name: "💬",
					},
				},
				discordgo.Button{
					Label:    "Report",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_report",
					Emoji: &discordgo.ComponentEmoji{
						Name: "🚨",
					},
				},
				discordgo.Button{
					Label:    "Appeals",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_appeals",
					Emoji: &discordgo.ComponentEmoji{
						Name: "⚖️",
					},
				},
			},
		},
		discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{
				discordgo.Button{
					Label:    "Scoring",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_scoring",
					Emoji: &discordgo.ComponentEmoji{
						Name: "🎯",
					},
				},
				discordgo.Button{
					Label:    "Store",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_store",
					Emoji: &discordgo.ComponentEmoji{
						Name: "🛍️",
					},
				},
				discordgo.Button{
					Label:    "Payouts",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_payouts",
					Emoji: &discordgo.ComponentEmoji{
						Name: "💸",
					},
				},
				discordgo.Button{
					Label:    "Priority",
					Style:    discordgo.DangerButton,
					CustomID: "ticket_create_priority",
					Emoji: &discordgo.ComponentEmoji{
						Name: "🛑",
					},
				},
			},
		},
	}

	msg, err := s.ChannelMessageSendComplex(panelData.ChannelID, &discordgo.MessageSend{
		Embeds:     []*discordgo.MessageEmbed{embed},
		Components: buttons,
	})
	if err != nil {
		followUpError(s, i, fmt.Sprintf("Failed to create new panel: %v", err))
		return
	}

	database.GetPersistentMessagesCollection().DeleteMany(ctx, bson.M{"type": "ticket_panel"})

	newPersistentMsg := models.PersistentMessage{
		MessageID: msg.ID,
		ChannelID: panelData.ChannelID,
		Type:      "ticket_panel",
	}
	database.GetPersistentMessagesCollection().InsertOne(ctx, newPersistentMsg)

	cacheData, _ := json.Marshal(map[string]string{
		"channel_id": msg.ChannelID,
		"message_id": msg.ID,
	})
	database.Dragonfly.Set(ctx, "persistent:ticket_panel", cacheData, 0)

	s.InteractionResponseEdit(i.Interaction, &discordgo.WebhookEdit{
		Embeds: &[]*discordgo.MessageEmbed{
			{
				Description: "✅ Successfully recreated ticket panel with all categories!\n\n**New Panel:**\n• Channel: <#" + msg.ChannelID + ">\n• Message ID: " + msg.ID + "\n\n**Categories:**\n💬 General\n🚨 Report\n⚖️ Appeals\n🎯 Scoring\n🛍️ Store\n💸 Payouts\n🛑 Priority",
				Color:       0x00FF00,
			},
		},
	})
}
