package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"rankedbw-tickets/utils"
	"time"

	"github.com/bwmarrin/discordgo"
	"go.mongodb.org/mongo-driver/bson"
)

var CloseCommand = &discordgo.ApplicationCommand{
	Name:        "close",
	Description: "Close a ticket",
	Options: []*discordgo.ApplicationCommandOption{
		{
			Type:        discordgo.ApplicationCommandOptionString,
			Name:        "reason",
			Description: "Reason for closing the ticket",
			Required:    true,
		},
	},
}

func CloseHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx := context.Background()

	ticketID := database.Dragonfly.Get(ctx, fmt.Sprintf("ticket:channel:%s", i.ChannelID)).Val()
	if ticketID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "This is not a ticket channel."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	var ticket models.Ticket
	err := database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to find ticket."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options[0].Options
	reason := "Resolved"
	if len(options) > 0 {
		reason = options[0].StringValue()
	}
	isCreator := i.Member.User.ID == ticket.CreatorID
	hasPermission := utils.HasPermission(s, i.GuildID, i.Member.User.ID)

	if !isCreator && !hasPermission {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to close this ticket."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if isCreator && !hasPermission {
		embed := utils.CreateWarningEmbed("Close Ticket", fmt.Sprintf("Are you sure you want to close this ticket?\n**Reason:** %s", reason))
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{embed},
				Components: []discordgo.MessageComponent{
					discordgo.ActionsRow{
						Components: []discordgo.MessageComponent{
							discordgo.Button{
								Label:    "Close",
								Style:    discordgo.DangerButton,
								CustomID: fmt.Sprintf("ticket_close_confirm:%s:%s", ticketID, reason),
							},
							discordgo.Button{
								Label:    "Keep Open",
								Style:    discordgo.SecondaryButton,
								CustomID: "ticket_close_cancel",
							},
						},
					},
				},
			},
		})
		return
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateInfoEmbed("Closing Ticket", "This ticket will be closed in 3 seconds..."),
			},
		},
	})

	go func() {
		_ = utils.GenerateTranscript(s, i.ChannelID, ticketID, ticket.CreatorID, ticket.CreatorTag, i.Member.User.ID, i.Member.User.String(), reason)

		if hasPermission {
			closeRecord := models.TicketClose{
				UserID:   i.Member.User.ID,
				TicketID: ticketID,
				ClosedAt: time.Now(),
				Method:   "close",
			}
			database.GetTicketClosesCollection().InsertOne(ctx, closeRecord)
		}

		time.Sleep(3 * time.Second)

		closeTicketNow(s, i.GuildID, i.ChannelID, ticketID, ticket.CreatorID, ticket.CreatorTag, i.Member.User.ID, i.Member.User.String(), reason)
	}()
}
