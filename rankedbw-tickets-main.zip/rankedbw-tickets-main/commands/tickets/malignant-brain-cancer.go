package tickets

import (
	"context"
	"rankedbw-tickets/config"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"

	"github.com/bwmarrin/discordgo"
)

func MalignantBrainCancerHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if i.Member.User.ID != config.GetDeveloperID() {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					{
						Description: "🌸 Bot feels pretty good at the moment its brain does not have brain cancer yet",
						Color:       0xFF69B4,
					},
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	ctx := context.Background()

	categories := []models.TicketCategory{
		models.CategoryGeneral,
		models.CategoryReport,
		models.CategoryAppeals,
		models.CategoryScoring,
		models.CategoryStore,
		models.CategoryPayouts,
		models.CategoryPriority,
	}

	for _, cat := range categories {
		key := "ticket:category:" + string(cat)
		database.Dragonfly.Del(ctx, key)
	}

	database.Dragonfly.Del(ctx, "persistent:ticket_panel")

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				{
					Description: "AHHHHHHHHHHHHHHHHHH IT HURTS SO MUCH IM DYING AHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH OHHHHHHHHHHHHHHHHHHHH MYYYYYYYYYYYYYYYYYY GOOOOOOOOOOOOOOOOOOOOOOOOOOOD",
					Color:       0xFF0000,
				},
			},
			Flags: discordgo.MessageFlagsEphemeral,
		},
	})
}
