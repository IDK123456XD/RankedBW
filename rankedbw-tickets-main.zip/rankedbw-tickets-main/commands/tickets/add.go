package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/database"
	"rankedbw-tickets/utils"

	"github.com/bwmarrin/discordgo"
)

func AddHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to use this command."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	ctx := context.Background()
	ticketID := database.Dragonfly.Get(ctx, fmt.Sprintf("ticket:channel:%s", i.ChannelID)).Val()
	if ticketID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "This is not a ticket channel."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options[0].Options

	var targetID string
	var targetType discordgo.PermissionOverwriteType
	var successMessage string
	var isUser bool

	for _, opt := range options {
		if opt.Name == "user" && opt.UserValue(s) != nil {
			targetUser := opt.UserValue(s)
			if targetUser.ID == s.State.User.ID {
				s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{
							{
								Description: "🥚 Awhh It feels really good knowing I'm wanted somewhere in this world but silly I'm already here... Always was.. :)",
								Color:       0xFFD700,
							},
						},
						Flags: discordgo.MessageFlagsEphemeral,
					},
				})
				return
			}
			targetID = targetUser.ID
			targetType = discordgo.PermissionOverwriteTypeMember
			successMessage = fmt.Sprintf("<@%s> has been added to the ticket.", targetID)
			isUser = true
			break
		} else if opt.Name == "role" && opt.RoleValue(s, i.GuildID) != nil {
			targetRole := opt.RoleValue(s, i.GuildID)
			targetID = targetRole.ID
			targetType = discordgo.PermissionOverwriteTypeRole
			successMessage = fmt.Sprintf("<@&%s> has been added to the ticket.", targetID)
			break
		}
	}

	if targetID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "You must provide either a user or a role."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	err := s.ChannelPermissionSet(i.ChannelID, targetID, targetType,
		discordgo.PermissionViewChannel|discordgo.PermissionSendMessages|discordgo.PermissionReadMessageHistory,
		0)
	if err != nil {
		errorMsg := "Failed to add to ticket."
		if isUser {
			errorMsg = "Failed to add user to ticket."
		} else {
			errorMsg = "Failed to add role to ticket."
		}
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", errorMsg),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	title := "User Added"
	if !isUser {
		title = "Role Added"
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed(title, successMessage),
			},
		},
	})
}
