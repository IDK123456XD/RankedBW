package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/config"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"rankedbw-tickets/utils"
	"sort"

	"github.com/bwmarrin/discordgo"
	"go.mongodb.org/mongo-driver/bson"
)

func StatsHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx := context.Background()
	options := i.ApplicationCommandData().Options[0].Options

	if len(options) > 0 {
		userID := options[0].UserValue(s).ID

		cursor, err := database.GetTicketClaimsCollection().Find(ctx, bson.M{"user_id": userID}, nil)
		if err != nil {
			s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						utils.CreateErrorEmbed("Error", "Failed to fetch statistics."),
					},
					Flags: discordgo.MessageFlagsEphemeral,
				},
			})
			return
		}
		defer cursor.Close(ctx)

		var claims []models.TicketClaim
		if err := cursor.All(ctx, &claims); err != nil {
			s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						utils.CreateErrorEmbed("Error", "Failed to decode statistics."),
					},
					Flags: discordgo.MessageFlagsEphemeral,
				},
			})
			return
		}

		closeCursor, err := database.GetTicketClosesCollection().Find(ctx, bson.M{"user_id": userID}, nil)
		if err != nil {
			s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						utils.CreateErrorEmbed("Error", "Failed to fetch close statistics."),
					},
					Flags: discordgo.MessageFlagsEphemeral,
				},
			})
			return
		}
		defer closeCursor.Close(ctx)

		var closes []models.TicketClose
		if err := closeCursor.All(ctx, &closes); err != nil {
			s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{
						utils.CreateErrorEmbed("Error", "Failed to decode close statistics."),
					},
					Flags: discordgo.MessageFlagsEphemeral,
				},
			})
			return
		}

		totalClaims := len(claims)
		totalCloses := len(closes)

		lastClaim := "Never"
		if totalClaims > 0 {
			sort.Slice(claims, func(i, j int) bool {
				return claims[i].ClaimedAt.Before(claims[j].ClaimedAt)
			})
			lastClaim = fmt.Sprintf("<t:%d:R>", claims[len(claims)-1].ClaimedAt.Unix())
		}

		lastClose := "Never"
		if totalCloses > 0 {
			sort.Slice(closes, func(i, j int) bool {
				return closes[i].ClosedAt.Before(closes[j].ClosedAt)
			})
			lastClose = fmt.Sprintf("<t:%d:R>", closes[len(closes)-1].ClosedAt.Unix())
		}

		member, err := s.GuildMember(i.GuildID, userID)
		hasStaffRole := false
		if err == nil {
			supportRoleID := config.GetSupportRoleID()
			for _, roleID := range member.Roles {
				if roleID == supportRoleID {
					hasStaffRole = true
					break
				}
			}
		}

		if totalClaims == 0 && totalCloses == 0 && !hasStaffRole {
			embed := utils.CreateErrorEmbed("Not a Staff Member", "This silly goose is not a staff member... how would they handle tickets?")
			s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{embed},
				},
			})
			return
		}

		warning := ""
		if !hasStaffRole {
			warning = "⚠️ **Warning:** This user is not a staff member\n\n"
		}

		embed := utils.CreateInfoEmbed("Ticket Statistics", fmt.Sprintf(
			"%s**User:** <@%s>\n**Total Claims:** %d\n**Total Closes:** %d\n**Last Claim:** %s\n**Last Close:** %s",
			warning, userID, totalClaims, totalCloses, lastClaim, lastClose,
		))

		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{embed},
			},
		})
		return
	}

	claimsPipeline := bson.A{
		bson.M{"$group": bson.M{
			"_id":   "$user_id",
			"count": bson.M{"$sum": 1},
		}},
		bson.M{"$sort": bson.M{"count": -1}},
		bson.M{"$limit": 10},
	}

	cursor, err := database.GetTicketClaimsCollection().Aggregate(ctx, claimsPipeline)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to fetch leaderboard."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}
	defer cursor.Close(ctx)

	var claimResults []struct {
		UserID string `bson:"_id"`
		Count  int    `bson:"count"`
	}
	if err := cursor.All(ctx, &claimResults); err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to decode leaderboard."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	closesPipeline := bson.A{
		bson.M{"$group": bson.M{
			"_id":   "$user_id",
			"count": bson.M{"$sum": 1},
		}},
		bson.M{"$sort": bson.M{"count": -1}},
		bson.M{"$limit": 10},
	}

	closeCursor, err := database.GetTicketClosesCollection().Aggregate(ctx, closesPipeline)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to fetch close leaderboard."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}
	defer closeCursor.Close(ctx)

	var closeResults []struct {
		UserID string `bson:"_id"`
		Count  int    `bson:"count"`
	}
	if err := closeCursor.All(ctx, &closeResults); err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to decode close leaderboard."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	closesByUser := make(map[string]int)
	for _, result := range closeResults {
		closesByUser[result.UserID] = result.Count
	}

	sort.Slice(claimResults, func(i, j int) bool {
		return claimResults[i].Count > claimResults[j].Count
	})

	description := ""
	for idx, result := range claimResults {
		closes := closesByUser[result.UserID]

		member, err := s.GuildMember(i.GuildID, result.UserID)
		warningIcon := ""
		if err == nil {
			supportRoleID := config.GetSupportRoleID()
			hasStaffRole := false
			for _, roleID := range member.Roles {
				if roleID == supportRoleID {
					hasStaffRole = true
					break
				}
			}
			if !hasStaffRole {
				warningIcon = "⚠️ "
			}
		}

		description += fmt.Sprintf("%d. %s<@%s> - %d claims, %d closes\n", idx+1, warningIcon, result.UserID, result.Count, closes)
	}

	if description == "" {
		description = "No claims yet."
	}

	embed := utils.CreateInfoEmbed("Ticket Claims Leaderboard", description)

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}
