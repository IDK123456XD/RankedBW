package tickets

import (
	"rankedbw-tickets/config"
	"rankedbw-tickets/utils"

	"github.com/bwmarrin/discordgo"
)

func UnblacklistHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to use this command."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options[0].Options
	targetUser := options[0].UserValue(s)

	blacklistRoleID := config.GetTicketBlacklistRoleID()
	if blacklistRoleID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Blacklist role is not configured."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	err := s.GuildMemberRoleRemove(i.GuildID, targetUser.ID, blacklistRoleID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to unblacklist user."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed("User Unblacklisted", "User <@"+targetUser.ID+"> has been removed from the ticket blacklist."),
			},
		},
	})
}
