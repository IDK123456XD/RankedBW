package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/config"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"rankedbw-tickets/utils"

	"github.com/bwmarrin/discordgo"
	"go.mongodb.org/mongo-driver/bson"
)

func UnlockHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	ctx := context.Background()

	ticketID := database.Dragonfly.Get(ctx, fmt.Sprintf("ticket:channel:%s", i.ChannelID)).Val()
	if ticketID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("OOPSIES!", "HUH this is not a ticket channel... BUT IF IT IS... Contact wirespider87 ASAP!! (〇□〇)"),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	var ticket models.Ticket
	err := database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("OOPSIES!", "failed to find ticket in database. CONTACT wirespider87 ASAP!! ●﹏●"),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "awh gurl you don't have permission to unlock tickets. (ㆆ_ㆆ)"),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	err = s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseDeferredChannelMessageWithSource,
	})

	if err != nil {
		return
	}

	supportRoleID := config.GetSupportRoleID()

	allStaffRoleIDs := config.GetAllStaffRoleIDs()
	for _, roleID := range allStaffRoleIDs {
		if roleID == "" {
			continue
		}
		err = s.ChannelPermissionDelete(i.ChannelID, roleID)
		if err != nil {
			continue
		}
	}

	err = s.ChannelPermissionSet(i.ChannelID, supportRoleID, discordgo.PermissionOverwriteTypeRole, discordgo.PermissionViewChannel|discordgo.PermissionSendMessages, 0)
	if err != nil {
		s.FollowupMessageCreate(i.Interaction, true, &discordgo.WebhookParams{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateErrorEmbed("Error", "failed to restore support role permissions PLEASEEE contact wirespider87!! (╯°□°）╯︵ ┻━┻"),
			},
			Flags: discordgo.MessageFlagsEphemeral,
		})
		return
	}

	s.FollowupMessageCreate(i.Interaction, true, &discordgo.WebhookParams{
		Embeds: []*discordgo.MessageEmbed{
			{
				Title:       "Ticket Unlocked! <3",
				Description: "This ticket has been unlocked. ヽ(＾Д＾)ﾉ",
				Color:       0x00FF00,
			},
		},
	})
}
