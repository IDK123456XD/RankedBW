package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"rankedbw-tickets/utils"
	"time"

	"github.com/bwmarrin/discordgo"
	"go.mongodb.org/mongo-driver/bson"
)

func ClaimHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to use this command."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	ctx := context.Background()
	ticketID := database.Dragonfly.Get(ctx, fmt.Sprintf("ticket:channel:%s", i.ChannelID)).Val()
	if ticketID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "This is not a ticket channel."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	var ticket models.Ticket
	err := database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to find ticket."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if ticket.ClaimedBy != "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Already Claimed", fmt.Sprintf("This ticket is already claimed by <@%s>.", ticket.ClaimedBy)),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	now := time.Now()
	database.GetTicketsCollection().UpdateOne(ctx,
		bson.M{"ticket_id": ticketID},
		bson.M{
			"$set": bson.M{
				"claimed_by": i.Member.User.ID,
				"claimed_at": now,
			},
		},
	)

	claim := models.TicketClaim{
		UserID:    i.Member.User.ID,
		TicketID:  ticketID,
		ClaimedAt: now,
	}
	database.GetTicketClaimsCollection().InsertOne(ctx, claim)

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed("Ticket Claimed", fmt.Sprintf("<@%s> has claimed this ticket.", i.Member.User.ID)),
			},
		},
	})
}
