package tickets

import (
	"github.com/bwmarrin/discordgo"
)

type CommandHandler func(s *discordgo.Session, i *discordgo.InteractionCreate)

type RegisteredCommand struct {
	Command *discordgo.ApplicationCommand
	Handler CommandHandler
}

var TicketCommand = &discordgo.ApplicationCommand{
	Name:        "ticket",
	Description: "Manage tickets",
	Options: []*discordgo.ApplicationCommandOption{
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "setup",
			Description: "Setup the ticket panel",
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "open",
			Description: "Open a new ticket",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionString,
					Name:        "category",
					Description: "Ticket category",
					Required:    true,
					Choices: []*discordgo.ApplicationCommandOptionChoice{
						{Name: "General", Value: "general"},
						{Name: "Report", Value: "report"},
						{Name: "Appeals", Value: "appeals"},
						{Name: "Scoring", Value: "scoring"},
						{Name: "Store", Value: "store"},
						{Name: "Payouts", Value: "payouts"},
						{Name: "Priority", Value: "priority"},
					},
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "close",
			Description: "Close a ticket",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionString,
					Name:        "reason",
					Description: "Reason for closing the ticket",
					Required:    false,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "fclose",
			Description: "Force close a ticket without confirmation",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionString,
					Name:        "reason",
					Description: "Reason for closing the ticket",
					Required:    false,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "claim",
			Description: "Claim a ticket",
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "rename",
			Description: "Rename the ticket channel",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionString,
					Name:        "name",
					Description: "New name for the ticket channel",
					Required:    true,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "stats",
			Description: "View ticket claim statistics",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionUser,
					Name:        "user",
					Description: "User to view stats for (optional)",
					Required:    false,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "transfer",
			Description: "Transfer a ticket to another support staff member",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionUser,
					Name:        "user",
					Description: "User to transfer the ticket to",
					Required:    true,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "topic",
			Description: "Set the ticket channel topic",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionString,
					Name:        "message",
					Description: "Topic message",
					Required:    true,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "add",
			Description: "Add a user or role to the ticket",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionUser,
					Name:        "user",
					Description: "User to add to the ticket",
					Required:    false,
				},
				{
					Type:        discordgo.ApplicationCommandOptionRole,
					Name:        "role",
					Description: "Role to add to the ticket",
					Required:    false,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "remove",
			Description: "Remove a user or role from the ticket",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionUser,
					Name:        "user",
					Description: "User to remove from the ticket",
					Required:    false,
				},
				{
					Type:        discordgo.ApplicationCommandOptionRole,
					Name:        "role",
					Description: "Role to remove from the ticket",
					Required:    false,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "blacklist",
			Description: "Blacklist a user from creating tickets",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionUser,
					Name:        "user",
					Description: "User to blacklist",
					Required:    true,
				},
				{
					Type:        discordgo.ApplicationCommandOptionString,
					Name:        "reason",
					Description: "Reason for blacklist",
					Required:    true,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "unblacklist",
			Description: "Remove a user from the ticket blacklist",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionUser,
					Name:        "user",
					Description: "User to unblacklist",
					Required:    true,
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "move",
			Description: "Move ticket to another category",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionString,
					Name:        "category",
					Description: "Category to move to",
					Required:    true,
					Choices: []*discordgo.ApplicationCommandOptionChoice{
						{Name: "General", Value: "general"},
						{Name: "Report", Value: "report"},
						{Name: "Appeals", Value: "appeals"},
						{Name: "Scoring", Value: "scoring"},
						{Name: "Store", Value: "store"},
						{Name: "Payouts", Value: "payouts"},
						{Name: "Priority", Value: "priority"},
					},
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "lock",
			Description: "Lock ticket to a specific staff position",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionString,
					Name:        "role",
					Description: "Role to lock the ticket to",
					Required:    true,
					Choices: []*discordgo.ApplicationCommandOptionChoice{
						{Name: "Owner", Value: "owner"},
						{Name: "Admin", Value: "admin"},
						{Name: "Developer", Value: "developer"},
						{Name: "Senior Mod", Value: "senior_mod"},
						{Name: "Moderator", Value: "moderator"},
						{Name: "Helper", Value: "helper"},
						{Name: "Screenshare Manager", Value: "screenshare_manager"},
						{Name: "Screensharer", Value: "screensharer"},
					},
				},
			},
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "unlock",
			Description: "Unlock ticket and restore access to all staff",
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "malignant-brain-cancer",
			Description: "Gives ticket bot malignant brain cancer",
		},
		{
			Type:        discordgo.ApplicationCommandOptionSubCommand,
			Name:        "migrate",
			Description: "Run migration commands (developer only)",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Type:        discordgo.ApplicationCommandOptionString,
					Name:        "type",
					Description: "Migration type to run",
					Required:    true,
					Choices: []*discordgo.ApplicationCommandOptionChoice{
						{Name: "Add Priority Tickets", Value: "add priority tickets"},
						{Name: "Sync Categories to DB", Value: "sync categories to db"},
						{Name: "Recreate Panel", Value: "recreate panel"},
					},
				},
			},
		},
	},
}

func GetCommands() []*discordgo.ApplicationCommand {
	return []*discordgo.ApplicationCommand{TicketCommand}
}

func GetHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	data := i.ApplicationCommandData()
	if len(data.Options) == 0 {
		return
	}

	subCommand := data.Options[0].Name

	switch subCommand {
	case "setup":
		SetupHandler(s, i)
	case "open":
		OpenHandler(s, i)
	case "close":
		CloseHandler(s, i)
	case "fclose":
		ForceCloseHandler(s, i)
	case "claim":
		ClaimHandler(s, i)
	case "rename":
		RenameHandler(s, i)
	case "stats":
		StatsHandler(s, i)
	case "transfer":
		TransferHandler(s, i)
	case "topic":
		TopicHandler(s, i)
	case "add":
		AddHandler(s, i)
	case "remove":
		RemoveHandler(s, i)
	case "blacklist":
		BlacklistHandler(s, i)
	case "unblacklist":
		UnblacklistHandler(s, i)
	case "move":
		MoveHandler(s, i)
	case "lock":
		LockHandler(s, i)
	case "unlock":
		UnlockHandler(s, i)
	case "malignant-brain-cancer":
		MalignantBrainCancerHandler(s, i)
	case "migrate":
		MigrateHandler(s, i)
	}
}
