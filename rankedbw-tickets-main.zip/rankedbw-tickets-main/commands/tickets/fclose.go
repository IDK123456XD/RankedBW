package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"rankedbw-tickets/utils"
	"time"

	"github.com/bwmarrin/discordgo"
	"go.mongodb.org/mongo-driver/bson"
)

var ForceCloseCommand = &discordgo.ApplicationCommand{
	Name:        "fclose",
	Description: "Force close a ticket without confirmation (Support only)",
	Options: []*discordgo.ApplicationCommandOption{
		{
			Type:        discordgo.ApplicationCommandOptionString,
			Name:        "reason",
			Description: "Reason for closing the ticket",
			Required:    true,
		},
	},
}

func ForceCloseHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to use this command."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	ctx := context.Background()
	ticketID := database.Dragonfly.Get(ctx, fmt.Sprintf("ticket:channel:%s", i.ChannelID)).Val()
	if ticketID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "This is not a ticket channel."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	var ticket models.Ticket
	err := database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to find ticket."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options[0].Options
	reason := "Resolved"
	if len(options) > 0 {
		reason = options[0].StringValue()
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateInfoEmbed("Closing Ticket", "This ticket will be closed in 3 seconds..."),
			},
		},
	})

	go func() {
		_ = utils.GenerateTranscript(s, i.ChannelID, ticketID, ticket.CreatorID, ticket.CreatorTag, i.Member.User.ID, i.Member.User.String(), reason)

		closeRecord := models.TicketClose{
			UserID:   i.Member.User.ID,
			TicketID: ticketID,
			ClosedAt: time.Now(),
			Method:   "fclose",
		}
		database.GetTicketClosesCollection().InsertOne(ctx, closeRecord)

		time.Sleep(3 * time.Second)

		closeTicketNow(s, i.GuildID, i.ChannelID, ticketID, ticket.CreatorID, ticket.CreatorTag, i.Member.User.ID, i.Member.User.String(), reason)
	}()
}

func closeTicketNow(s *discordgo.Session, guildID, channelID, ticketID, creatorID, creatorTag, closerID, closerTag, reason string) {
	ctx := context.Background()

	now := time.Now()
	_, _ = database.GetTicketsCollection().UpdateOne(ctx,
		bson.M{"ticket_id": ticketID},
		bson.M{
			"$set": bson.M{
				"status":       models.TicketStatusClosed,
				"closed_at":    now,
				"closed_by":    closerID,
				"close_reason": reason,
			},
		},
	)

	var ticket models.Ticket
	_ = database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)

	database.Dragonfly.Del(ctx, fmt.Sprintf("ticket:channel:%s", channelID))
	database.Dragonfly.Del(ctx, fmt.Sprintf("ticket:user:%s:%s", creatorID, ticket.Category))

	_, _ = s.ChannelDelete(channelID)

	dmChannel, err := s.UserChannelCreate(creatorID)
	if err == nil {
		duration := now.Sub(ticket.CreatedAt)
		hours := int(duration.Hours())
		minutes := int(duration.Minutes()) % 60

		description := fmt.Sprintf("Your ticket has been force closed.\n\n**Reason:** %s\n**Force Closed by:** <@%s>", reason, closerID)

		if ticket.ClaimedBy != "" {
			description += fmt.Sprintf("\n**Claimed by:** <@%s>", ticket.ClaimedBy)
		}

		description += fmt.Sprintf("\n\n**Opened At:** <t:%d:F>\n**Force Closed At:** <t:%d:F>\n**Open For:** %dh %dm",
			ticket.CreatedAt.Unix(), now.Unix(), hours, minutes)

		embed := utils.CreateInfoEmbed("Ticket Force Closed", description)
		s.ChannelMessageSendEmbed(dmChannel.ID, embed)
	}
}
