package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"rankedbw-tickets/utils"

	"github.com/bwmarrin/discordgo"
	"go.mongodb.org/mongo-driver/bson"
)

func TransferHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to use this command."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	ctx := context.Background()
	ticketID := database.Dragonfly.Get(ctx, fmt.Sprintf("ticket:channel:%s", i.ChannelID)).Val()
	if ticketID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "This is not a ticket channel."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	var ticket models.Ticket
	err := database.GetTicketsCollection().FindOne(ctx, bson.M{"ticket_id": ticketID}).Decode(&ticket)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to find ticket."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options[0].Options
	targetUser := options[0].UserValue(s)

	database.GetTicketsCollection().UpdateOne(ctx,
		bson.M{"ticket_id": ticketID},
		bson.M{
			"$set": bson.M{
				"creator_id":  targetUser.ID,
				"creator_tag": targetUser.String(),
			},
		},
	)

	s.ChannelEdit(i.ChannelID, &discordgo.ChannelEdit{
		Name: fmt.Sprintf("ticket-%s", targetUser.Username),
	})

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed("Ticket Transferred", fmt.Sprintf("Ticket transferred to <@%s>", targetUser.ID)),
			},
		},
	})
}
