package tickets

import (
	"context"
	"fmt"
	"rankedbw-tickets/database"
	"rankedbw-tickets/models"
	"rankedbw-tickets/utils"

	"github.com/bwmarrin/discordgo"
)

func SetupHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to use this command."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed("Ticket Setup", "Setting up ticket panel..."),
			},
			Flags: discordgo.MessageFlagsEphemeral,
		},
	})

	categories := []models.TicketCategory{
		models.CategoryGeneral,
		models.CategoryReport,
		models.CategoryAppeals,
		models.CategoryScoring,
		models.CategoryStore,
		models.CategoryPayouts,
	}

	guild, err := s.Guild(i.GuildID)
	if err != nil {
		return
	}

	categoryIDs := make(map[models.TicketCategory]string)
	for _, cat := range categories {
		categoryName := fmt.Sprintf("%s %s TICKETS %s", cat.Emoji(), cat.Display(), cat.Emoji())

		var existingCategory *discordgo.Channel
		for _, ch := range guild.Channels {
			if ch.Type == discordgo.ChannelTypeGuildCategory && ch.Name == categoryName {
				existingCategory = ch
				break
			}
		}

		if existingCategory != nil {
			categoryIDs[cat] = existingCategory.ID
		} else {
			channel, err := s.GuildChannelCreateComplex(i.GuildID, discordgo.GuildChannelCreateData{
				Name: categoryName,
				Type: discordgo.ChannelTypeGuildCategory,
			})
			if err != nil {
				continue
			}
			categoryIDs[cat] = channel.ID
		}
	}

	ctx := context.Background()
	for cat, catID := range categoryIDs {
		key := fmt.Sprintf("ticket:category:%s", cat)
		database.Dragonfly.Set(ctx, key, catID, 0)

		categoryMapping := models.CategoryMapping{
			Category:   cat,
			CategoryID: catID,
			GuildID:    i.GuildID,
		}
		database.GetCategoryMappingsCollection().InsertOne(ctx, categoryMapping)
	}

	embed := &discordgo.MessageEmbed{
		Title:       "Ranked Bedwars Support",
		Description: "Select the category that best fits your needs:\n\n💬 **General** — Ask questions and get help\n🚨 **Report** — Report a player for breaking the rules.\n⚖️ **Appeals** — Appeal a strike, mute, or ban\n🎯 **Scoring** — Dispute game outcomes or stats\n🛍️ **Store** — Store or payment issues\n💸 **Payouts** — Prize claims and payouts\n\n**Click a button below to open a ticket**",
		Color:       0x5865F2,
	}

	buttons := []discordgo.MessageComponent{
		discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{
				discordgo.Button{
					Label:    "General",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_general",
					Emoji: &discordgo.ComponentEmoji{
						Name: "💬",
					},
				},
				discordgo.Button{
					Label:    "Report",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_report",
					Emoji: &discordgo.ComponentEmoji{
						Name: "🚨",
					},
				},
				discordgo.Button{
					Label:    "Appeals",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_appeals",
					Emoji: &discordgo.ComponentEmoji{
						Name: "⚖️",
					},
				},
			},
		},
		discordgo.ActionsRow{
			Components: []discordgo.MessageComponent{
				discordgo.Button{
					Label:    "Scoring",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_scoring",
					Emoji: &discordgo.ComponentEmoji{
						Name: "🎯",
					},
				},
				discordgo.Button{
					Label:    "Store",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_store",
					Emoji: &discordgo.ComponentEmoji{
						Name: "🛍️",
					},
				},
				discordgo.Button{
					Label:    "Payouts",
					Style:    discordgo.SecondaryButton,
					CustomID: "ticket_create_payouts",
					Emoji: &discordgo.ComponentEmoji{
						Name: "💸",
					},
				},
			},
		},
	}

	msg, err := s.ChannelMessageSendComplex(i.ChannelID, &discordgo.MessageSend{
		Embeds:     []*discordgo.MessageEmbed{embed},
		Components: buttons,
	})
	if err != nil {
		return
	}

	persistentMsg := models.PersistentMessage{
		MessageID: msg.ID,
		ChannelID: i.ChannelID,
		Type:      "ticket_panel",
	}
	database.GetPersistentMessagesCollection().InsertOne(ctx, persistentMsg)
}
