package tickets

import (
	"rankedbw-tickets/config"
	"rankedbw-tickets/utils"

	"github.com/bwmarrin/discordgo"
)

func BlacklistHandler(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !utils.HasPermission(s, i.GuildID, i.Member.User.ID) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Permission Denied", "You don't have permission to use this command."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options[0].Options
	targetUser := options[0].UserValue(s)
	reason := options[1].StringValue()

	blacklistRoleID := config.GetTicketBlacklistRoleID()
	if blacklistRoleID == "" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Blacklist role is not configured."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	err := s.GuildMemberRoleAdd(i.GuildID, targetUser.ID, blacklistRoleID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{
					utils.CreateErrorEmbed("Error", "Failed to blacklist user."),
				},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{
				utils.CreateSuccessEmbed("User Blacklisted", "User <@"+targetUser.ID+"> has been blacklisted from creating tickets.\n**Reason:** "+reason),
			},
		},
	})
}
