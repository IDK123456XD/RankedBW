package main

import (
	"log"
	"os"
	"os/signal"
	"rankedbw-tickets/commands/tickets"
	"rankedbw-tickets/config"
	"rankedbw-tickets/database"
	"rankedbw-tickets/handlers"

	"github.com/bwmarrin/discordgo"
	"github.com/joho/godotenv"
)

func main() {
	if err := godotenv.Load(); err != nil {
		log.Println("Warning: .env file not found")
	}

	database.ConnectMongoDB()
	database.ConnectDragonfly()

	dg, err := discordgo.New("Bot " + config.GetBotToken())
	if err != nil {
		log.Fatalf("Error creating Discord session: %v", err)
	}

	dg.AddHandler(handlers.HandleInteractionCreate)
	dg.AddHandler(func(s *discordgo.Session, r *discordgo.Ready) {
		log.Printf("Logged in as: %v#%v", s.State.User.Username, s.State.User.Discriminator)

		err := s.UpdateGameStatus(0, "bleehhh!")
		if err != nil {
			log.Printf("Error setting bot status: %v", err)
		}
	})

	dg.Identify.Intents = discordgo.IntentsGuilds | discordgo.IntentsGuildMessages | discordgo.IntentsGuildMembers

	err = dg.Open()
	if err != nil {
		log.Fatalf("Error opening connection: %v", err)
	}
	defer dg.Close()

	log.Println("Registering commands...")
	devGuildID := config.GetDevGuildID()

	commands := tickets.GetCommands()
	if devGuildID != "" {
		for _, cmd := range commands {
			_, err := dg.ApplicationCommandCreate(dg.State.User.ID, devGuildID, cmd)
			if err != nil {
				log.Printf("Cannot create '%v' command: %v", cmd.Name, err)
			}
		}
		log.Printf("Registered %d commands to dev guild", len(commands))
	} else {
		for _, cmd := range commands {
			_, err := dg.ApplicationCommandCreate(dg.State.User.ID, "", cmd)
			if err != nil {
				log.Printf("Cannot create '%v' command: %v", cmd.Name, err)
			}
		}
		log.Printf("Registered %d global commands", len(commands))
	}

	log.Println("Bot is now running. Press CTRL-C to exit.")
	sc := make(chan os.Signal, 1)
	signal.Notify(sc, os.Interrupt)
	<-sc

	log.Println("Shutting down gracefully...")
}
