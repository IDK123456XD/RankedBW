package models

import "time"

type TicketStatus string

const (
	TicketStatusOpen   TicketStatus = "OPEN"
	TicketStatusClosed TicketStatus = "CLOSED"
)

type TicketCategory string

const (
	CategoryGeneral  TicketCategory = "general"
	CategoryReport   TicketCategory = "report"
	CategoryAppeals  TicketCategory = "appeals"
	CategoryScoring  TicketCategory = "scoring"
	CategoryStore    TicketCategory = "store"
	CategoryPayouts  TicketCategory = "payouts"
	CategoryPriority TicketCategory = "priority"
)

func (tc TicketCategory) Display() string {
	switch tc {
	case CategoryGeneral:
		return "GENERAL"
	case CategoryReport:
		return "REPORT"
	case CategoryAppeals:
		return "APPEALS"
	case CategoryScoring:
		return "SCORING"
	case CategoryStore:
		return "STORE"
	case CategoryPayouts:
		return "PAYOUTS"
	case CategoryPriority:
		return "PRIORITY"
	default:
		return string(tc)
	}
}

func (tc TicketCategory) Emoji() string {
	switch tc {
	case CategoryGeneral:
		return "💬"
	case CategoryReport:
		return "🚨"
	case CategoryAppeals:
		return "⚖️"
	case CategoryScoring:
		return "🎯"
	case CategoryStore:
		return "🛍️"
	case CategoryPayouts:
		return "💸"
	case CategoryPriority:
		return "🛑"
	default:
		return ""
	}
}

type Ticket struct {
	TicketID      string         `json:"ticket_id" bson:"ticket_id"`
	ChannelID     string         `json:"channel_id" bson:"channel_id"`
	CategoryID    string         `json:"category_id" bson:"category_id"`
	Category      TicketCategory `json:"category" bson:"category"`
	Status        TicketStatus   `json:"status" bson:"status"`
	CreatorID     string         `json:"creator_id" bson:"creator_id"`
	CreatorTag    string         `json:"creator_tag" bson:"creator_tag"`
	ClaimedBy     string         `json:"claimed_by,omitempty" bson:"claimed_by,omitempty"`
	ClaimedAt     *time.Time     `json:"claimed_at,omitempty" bson:"claimed_at,omitempty"`
	CreatedAt     time.Time      `json:"created_at" bson:"created_at"`
	ClosedAt      *time.Time     `json:"closed_at,omitempty" bson:"closed_at,omitempty"`
	ClosedBy      string         `json:"closed_by,omitempty" bson:"closed_by,omitempty"`
	CloseReason   string         `json:"close_reason,omitempty" bson:"close_reason,omitempty"`
	PinnedMessage string         `json:"pinned_message,omitempty" bson:"pinned_message,omitempty"`
}

type TicketClaim struct {
	UserID    string    `json:"user_id" bson:"user_id"`
	TicketID  string    `json:"ticket_id" bson:"ticket_id"`
	ClaimedAt time.Time `json:"claimed_at" bson:"claimed_at"`
}

type TicketClose struct {
	UserID   string    `json:"user_id" bson:"user_id"`
	TicketID string    `json:"ticket_id" bson:"ticket_id"`
	ClosedAt time.Time `json:"closed_at" bson:"closed_at"`
	Method   string    `json:"method" bson:"method"`
}

type PersistentMessage struct {
	MessageID string `json:"message_id" bson:"message_id"`
	ChannelID string `json:"channel_id" bson:"channel_id"`
	Type      string `json:"type" bson:"type"`
}

type CategoryMapping struct {
	Category   TicketCategory `json:"category" bson:"category"`
	CategoryID string         `json:"category_id" bson:"category_id"`
	GuildID    string         `json:"guild_id" bson:"guild_id"`
}
