package database

import (
	"context"
	"log"
	"rankedbw-tickets/config"
	"time"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var MongoDB *mongo.Database

func ConnectMongoDB() {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	client, err := mongo.Connect(ctx, options.Client().ApplyURI(config.GetMongoDBURL()))
	if err != nil {
		log.Fatalf("Failed to connect to MongoDB: %v", err)
	}

	if err := client.Ping(ctx, nil); err != nil {
		log.Fatalf("Failed to ping MongoDB: %v", err)
	}

	MongoDB = client.Database("rankedbw_tickets")
	log.Println("Connected to MongoDB successfully")
}

func GetTicketsCollection() *mongo.Collection {
	return MongoDB.Collection("tickets")
}

func GetTicketClaimsCollection() *mongo.Collection {
	return MongoDB.Collection("ticket_claims")
}

func GetTicketClosesCollection() *mongo.Collection {
	return MongoDB.Collection("ticket_closes")
}

func GetPersistentMessagesCollection() *mongo.Collection {
	return MongoDB.Collection("persistent_messages")
}

func GetCategoryMappingsCollection() *mongo.Collection {
	return MongoDB.Collection("category_mappings")
}
