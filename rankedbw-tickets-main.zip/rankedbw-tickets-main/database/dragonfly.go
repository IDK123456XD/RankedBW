package database

import (
	"context"
	"log"
	"rankedbw-tickets/config"

	"github.com/redis/go-redis/v9"
)

var Dragonfly *redis.Client

func ConnectDragonfly() {
	opt, err := redis.ParseURL(config.GetDragonflyURL())
	if err != nil {
		log.Fatalf("Failed to parse Dragonfly URL: %v", err)
	}

	Dragonfly = redis.NewClient(opt)

	ctx := context.Background()
	if err := Dragonfly.Ping(ctx).Err(); err != nil {
		log.Fatalf("Failed to connect to Dragonfly: %v", err)
	}

	log.Println("Connected to Dragonfly successfully")
}
