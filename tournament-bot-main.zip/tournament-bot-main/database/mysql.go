package database

import (
	"database/sql"
	"fmt"
	"strings"
	"time"

	_ "github.com/go-sql-driver/mysql"
)

type MySQL struct {
	DB *sql.DB
}

func NewMySQL(user, password, host, port, database string) (*MySQL, error) {
	var addr string
	if port != "" {
		addr = fmt.Sprintf("%s:%s", host, port)
	} else {
		addr = host
	}

	dsn := fmt.Sprintf("%s:%s@tcp(%s)/?charset=utf8mb4&parseTime=True&loc=Local",
		user, password, addr)

	db, err := sql.Open("mysql", dsn)
	if err != nil {
		return nil, fmt.Errorf("failed to open MySQL connection: %v", err)
	}

	if err := db.Ping(); err != nil {
		return nil, fmt.Errorf("failed to ping MySQL: %v", err)
	}

	mysql := &MySQL{DB: db}
	if err := mysql.initTables(); err != nil {
		return nil, fmt.Errorf("failed to initialize tables: %v", err)
	}

	if err := mysql.runMigrations(); err != nil {
		return nil, fmt.Errorf("failed to run migrations: %v", err)
	}
	db.Close()
	dsn = fmt.Sprintf("%s:%s@tcp(%s)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		user, password, addr, database)

	db, err = sql.Open("mysql", dsn)
	if err != nil {
		return nil, fmt.Errorf("failed to open MySQL connection with database: %v", err)
	}

	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(10)
	db.SetConnMaxLifetime(5 * time.Minute)
	db.SetConnMaxIdleTime(1 * time.Minute)

	if err := db.Ping(); err != nil {
		return nil, fmt.Errorf("failed to ping MySQL with database: %v", err)
	}
	mysql.DB = db
	return mysql, nil
}

func (m *MySQL) executeWithRetry(operation func() error) error {
	maxRetries := 3
	baseDelay := 100 * time.Millisecond

	for attempt := 1; attempt <= maxRetries; attempt++ {
		err := operation()
		if err == nil {
			return nil
		}

		if isRetryableError(err) && attempt < maxRetries {
			delay := time.Duration(attempt) * baseDelay
			time.Sleep(delay)
			continue
		}

		return err
	}

	return fmt.Errorf("operation failed after %d attempts", maxRetries)
}

func isRetryableError(err error) bool {
	if err == nil {
		return false
	}
	errStr := err.Error()
	retryableErrors := []string{
		"connection refused",
		"broken pipe",
		"connection reset by peer",
		"timeout",
		"too many connections",
		"server has gone away",
		"connection lost",
	}
	for _, retryable := range retryableErrors {
		if strings.Contains(strings.ToLower(errStr), strings.ToLower(retryable)) {
			return true
		}
	}
	return false
}

func (m *MySQL) initTables() error {
	queries := []string{
		`CREATE DATABASE IF NOT EXISTS pugs_bot`,
		`USE pugs_bot`, `CREATE TABLE IF NOT EXISTS users (
			discord_id BIGINT PRIMARY KEY,
			username VARCHAR(255) NOT NULL,
			discriminator VARCHAR(10),
			avatar VARCHAR(255),
			pugs_wins INT DEFAULT 0,
			pups_wins INT DEFAULT 0,
			pit_wins INT DEFAULT 0,
			pugs_losses INT DEFAULT 0,
			pups_losses INT DEFAULT 0,
			pit_losses INT DEFAULT 0,
			first_win_timestamp TIMESTAMP NULL,
			last_win_timestamp TIMESTAMP NULL,
			first_loss_timestamp TIMESTAMP NULL,
			last_loss_timestamp TIMESTAMP NULL,
			win_awarded_by JSON,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			INDEX idx_pugs_wins (pugs_wins),
			INDEX idx_pups_wins (pups_wins),
			INDEX idx_pit_wins (pit_wins),
			INDEX idx_pugs_losses (pugs_losses),
			INDEX idx_pups_losses (pups_losses),
			INDEX idx_pit_losses (pit_losses)
		)`,
		`CREATE TABLE IF NOT EXISTS tournaments (
			id INT AUTO_INCREMENT PRIMARY KEY,
			tournament_type ENUM('PUGS', 'PUPS', 'PIT') NOT NULL,
			num_teams INT NOT NULL,
			players_per_team INT NOT NULL,
			status ENUM('CREATED', 'TEAMS_SET', 'COMPLETED') DEFAULT 'CREATED',
			winner_team INT NULL,
			created_by BIGINT NOT NULL,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			completed_at TIMESTAMP NULL,
			INDEX idx_tournament_type (tournament_type),
			INDEX idx_status (status)
		)`,
		`CREATE TABLE IF NOT EXISTS tournament_teams (
			id INT AUTO_INCREMENT PRIMARY KEY,
			tournament_id INT NOT NULL,
			team_number INT NOT NULL,
			player1_id BIGINT NULL,
			player2_id BIGINT NULL,
			player3_id BIGINT NULL,
			player4_id BIGINT NULL,
			FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
			UNIQUE KEY unique_tournament_team (tournament_id, team_number)
		)`,
		`CREATE TABLE IF NOT EXISTS win_logs (
			id INT AUTO_INCREMENT PRIMARY KEY,
			user_id BIGINT NOT NULL,
			tournament_type ENUM('PUGS', 'PUPS', 'PIT') NOT NULL,
			action ENUM('ADD', 'REMOVE', 'LOSS') NOT NULL,
			awarded_by BIGINT NOT NULL,
			tournament_id INT NULL,
			reason VARCHAR(500),
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			INDEX idx_user_id (user_id),
			INDEX idx_tournament_type (tournament_type),
			INDEX idx_awarded_by (awarded_by)
		)`,
	}

	for _, query := range queries {
		if _, err := m.DB.Exec(query); err != nil {
			return fmt.Errorf("failed to execute query '%s': %v", query, err)
		}
	}

	return nil
}

func (m *MySQL) runMigrations() error {
	var count int
	err := m.DB.QueryRow("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'pugs_bot' AND TABLE_NAME = 'users' AND COLUMN_NAME = 'pugs_losses'").Scan(&count)
	if err != nil || count == 0 {
		migrationQueries := []string{
			`ALTER TABLE users ADD COLUMN pugs_losses INT DEFAULT 0`,
			`ALTER TABLE users ADD COLUMN pups_losses INT DEFAULT 0`,
			`ALTER TABLE users ADD COLUMN pit_losses INT DEFAULT 0`,
			`ALTER TABLE users ADD COLUMN first_loss_timestamp TIMESTAMP NULL`,
			`ALTER TABLE users ADD COLUMN last_loss_timestamp TIMESTAMP NULL`,
			`CREATE INDEX idx_pugs_losses ON users (pugs_losses)`,
			`CREATE INDEX idx_pups_losses ON users (pups_losses)`,
			`CREATE INDEX idx_pit_losses ON users (pit_losses)`,
		}

		for _, query := range migrationQueries {
			if _, err := m.DB.Exec(query); err != nil {
				fmt.Printf("Migration warning: %v\n", err)
			}
		}
	}

	if _, err := m.DB.Exec(`ALTER TABLE win_logs MODIFY COLUMN action ENUM('ADD', 'REMOVE', 'LOSS', 'REMOVE_LOSS') NOT NULL`); err != nil {
		fmt.Printf("Migration warning for win_logs: %v\n", err)
	}

	return nil
}

func (m *MySQL) Close() error {
	return m.DB.Close()
}

func (m *MySQL) UpsertUser(userID int64, username, discriminator, avatar string) error {
	query := `INSERT INTO users (discord_id, username, discriminator, avatar) 
			  VALUES (?, ?, ?, ?) 
			  ON DUPLICATE KEY UPDATE 
			  username = VALUES(username), 
			  discriminator = VALUES(discriminator), 
			  avatar = VALUES(avatar),
			  updated_at = CURRENT_TIMESTAMP`

	_, err := m.DB.Exec(query, userID, username, discriminator, avatar)
	return err
}

func (m *MySQL) EnsureUserExists(userID int64) error {
	return m.executeWithRetry(func() error {
		query := `INSERT IGNORE INTO users (discord_id, username, discriminator, avatar) VALUES (?, 'Unknown', '0000', '')`
		_, err := m.DB.Exec(query, userID)
		return err
	})
}

func (m *MySQL) CreateTournament(tournamentType string, numTeams, playersPerTeam int, createdBy int64) (int64, error) {
	var tournamentID int64

	err := m.executeWithRetry(func() error {
		query := `INSERT INTO tournaments (tournament_type, num_teams, players_per_team, created_by) VALUES (?, ?, ?, ?)`
		result, err := m.DB.Exec(query, tournamentType, numTeams, playersPerTeam, createdBy)
		if err != nil {
			return err
		}

		tournamentID, err = result.LastInsertId()
		return err
	})

	return tournamentID, err
}

func (m *MySQL) SetTournamentTeam(tournamentID int64, teamNumber int, players []int64) error {
	return m.executeWithRetry(func() error {
		query := `INSERT INTO tournament_teams (tournament_id, team_number, player1_id, player2_id, player3_id, player4_id) 
				  VALUES (?, ?, ?, ?, ?, ?) 
				  ON DUPLICATE KEY UPDATE 
				  player1_id = VALUES(player1_id), 
				  player2_id = VALUES(player2_id), 
				  player3_id = VALUES(player3_id), 
				  player4_id = VALUES(player4_id)`

		playersCopy := make([]int64, len(players))
		copy(playersCopy, players)
		for len(playersCopy) < 4 {
			playersCopy = append(playersCopy, 0)
		}

		var player1, player2, player3, player4 interface{}
		if playersCopy[0] != 0 {
			player1 = playersCopy[0]
		}
		if playersCopy[1] != 0 {
			player2 = playersCopy[1]
		}
		if playersCopy[2] != 0 {
			player3 = playersCopy[2]
		}
		if playersCopy[3] != 0 {
			player4 = playersCopy[3]
		}

		_, err := m.DB.Exec(query, tournamentID, teamNumber, player1, player2, player3, player4)
		return err
	})
}

func (m *MySQL) CompleteTournament(tournamentID int64, winnerTeam int) error {
	return m.executeWithRetry(func() error {
		query := `UPDATE tournaments SET status = 'COMPLETED', winner_team = ?, completed_at = CURRENT_TIMESTAMP WHERE id = ?`
		_, err := m.DB.Exec(query, winnerTeam, tournamentID)
		return err
	})
}

func (m *MySQL) GetTournamentWinners(tournamentID int64) ([]int64, string, error) {
	query := `SELECT tt.player1_id, tt.player2_id, tt.player3_id, tt.player4_id, t.tournament_type 
			  FROM tournament_teams tt 
			  JOIN tournaments t ON tt.tournament_id = t.id 
			  WHERE t.id = ? AND tt.team_number = t.winner_team`

	var player1, player2, player3, player4 sql.NullInt64
	var tournamentType string

	err := m.DB.QueryRow(query, tournamentID).Scan(&player1, &player2, &player3, &player4, &tournamentType)
	if err != nil {
		return nil, "", err
	}

	var winners []int64
	if player1.Valid {
		winners = append(winners, player1.Int64)
	}
	if player2.Valid {
		winners = append(winners, player2.Int64)
	}
	if player3.Valid {
		winners = append(winners, player3.Int64)
	}
	if player4.Valid {
		winners = append(winners, player4.Int64)
	}

	return winners, tournamentType, nil
}

func (m *MySQL) AddWin(userID int64, tournamentType string, awardedBy int64, tournamentID *int64) error {
	return m.executeWithRetry(func() error {
		tx, err := m.DB.Begin()
		if err != nil {
			return err
		}
		defer tx.Rollback()

		if tournamentID != nil {
			var existingCount int
			checkQuery := `SELECT COUNT(*) FROM win_logs WHERE user_id = ? AND tournament_id = ? AND action = 'ADD'`
			if err := tx.QueryRow(checkQuery, userID, *tournamentID).Scan(&existingCount); err != nil {
				return err
			}
			if existingCount > 0 {
				return nil
			}
		}

		var updateQuery string
		switch tournamentType {
		case "PUGS":
			updateQuery = `UPDATE users SET pugs_wins = pugs_wins + 1, last_win_timestamp = CURRENT_TIMESTAMP WHERE discord_id = ?`
		case "PUPS":
			updateQuery = `UPDATE users SET pups_wins = pups_wins + 1, last_win_timestamp = CURRENT_TIMESTAMP WHERE discord_id = ?`
		case "PIT":
			updateQuery = `UPDATE users SET pit_wins = pit_wins + 1, last_win_timestamp = CURRENT_TIMESTAMP WHERE discord_id = ?`
		}
		if _, err := tx.Exec(updateQuery, userID); err != nil {
			return err
		}

		firstWinQuery := `UPDATE users SET first_win_timestamp = CURRENT_TIMESTAMP WHERE discord_id = ? AND first_win_timestamp IS NULL`
		if _, err := tx.Exec(firstWinQuery, userID); err != nil {
			return err
		}

		logQuery := `INSERT INTO win_logs (user_id, tournament_type, action, awarded_by, tournament_id) VALUES (?, ?, 'ADD', ?, ?)`
		if _, err := tx.Exec(logQuery, userID, tournamentType, awardedBy, tournamentID); err != nil {
			return err
		}

		return tx.Commit()
	})
}

func (m *MySQL) RemoveWin(userID int64, tournamentType string, removedBy int64) error {
	tx, err := m.DB.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	var updateQuery string
	switch tournamentType {
	case "PUGS":
		updateQuery = `UPDATE users SET pugs_wins = GREATEST(pugs_wins - 1, 0) WHERE discord_id = ?`
	case "PUPS":
		updateQuery = `UPDATE users SET pups_wins = GREATEST(pups_wins - 1, 0) WHERE discord_id = ?`
	case "PIT":
		updateQuery = `UPDATE users SET pit_wins = GREATEST(pit_wins - 1, 0) WHERE discord_id = ?`
	}

	if _, err := tx.Exec(updateQuery, userID); err != nil {
		return err
	}

	logQuery := `INSERT INTO win_logs (user_id, tournament_type, action, awarded_by) VALUES (?, ?, 'REMOVE', ?)`
	if _, err := tx.Exec(logQuery, userID, tournamentType, removedBy); err != nil {
		return err
	}

	return tx.Commit()
}

func (m *MySQL) GetUserWins(userID int64) (int, int, int, error) {
	query := `SELECT pugs_wins, pups_wins, pit_wins FROM users WHERE discord_id = ?`
	var pugsWins, pupsWins, pitWins int

	err := m.DB.QueryRow(query, userID).Scan(&pugsWins, &pupsWins, &pitWins)
	if err == sql.ErrNoRows {
		return 0, 0, 0, nil
	}
	return pugsWins, pupsWins, pitWins, err
}

func (m *MySQL) AddLoss(userID int64, tournamentType string, awardedBy int64, tournamentID *int64) error {
	return m.executeWithRetry(func() error {
		tx, err := m.DB.Begin()
		if err != nil {
			return err
		}
		defer tx.Rollback()

		if tournamentID != nil {
			var existingCount int
			checkQuery := `SELECT COUNT(*) FROM win_logs WHERE user_id = ? AND tournament_id = ? AND action = 'LOSS'`
			if err := tx.QueryRow(checkQuery, userID, *tournamentID).Scan(&existingCount); err != nil {
				return err
			}
			if existingCount > 0 {
				return nil
			}
		}

		var updateQuery string
		switch tournamentType {
		case "PUGS":
			updateQuery = `UPDATE users SET pugs_losses = pugs_losses + 1, last_loss_timestamp = CURRENT_TIMESTAMP WHERE discord_id = ?`
		case "PUPS":
			updateQuery = `UPDATE users SET pups_losses = pups_losses + 1, last_loss_timestamp = CURRENT_TIMESTAMP WHERE discord_id = ?`
		case "PIT":
			updateQuery = `UPDATE users SET pit_losses = pit_losses + 1, last_loss_timestamp = CURRENT_TIMESTAMP WHERE discord_id = ?`
		}
		if _, err := tx.Exec(updateQuery, userID); err != nil {
			return err
		}

		checkQuery := `SELECT COUNT(*) FROM win_logs WHERE user_id = ? AND action = 'LOSS'`
		var count int
		if err := tx.QueryRow(checkQuery, userID).Scan(&count); err != nil {
			return err
		}

		if count == 0 {
			firstLossQuery := `UPDATE users SET first_loss_timestamp = CURRENT_TIMESTAMP WHERE discord_id = ? AND first_loss_timestamp IS NULL`
			if _, err := tx.Exec(firstLossQuery, userID); err != nil {
				return err
			}
		}

		logQuery := `INSERT INTO win_logs (user_id, tournament_type, action, awarded_by, tournament_id) VALUES (?, ?, 'LOSS', ?, ?)`
		if _, err := tx.Exec(logQuery, userID, tournamentType, awardedBy, tournamentID); err != nil {
			return err
		}

		return tx.Commit()
	})
}

func (m *MySQL) RemoveLoss(userID int64, tournamentType string, removedBy int64) error {
	tx, err := m.DB.Begin()
	if err != nil {
		return err
	}
	defer tx.Rollback()

	var updateQuery string
	switch tournamentType {
	case "PUGS":
		updateQuery = `UPDATE users SET pugs_losses = GREATEST(pugs_losses - 1, 0) WHERE discord_id = ?`
	case "PUPS":
		updateQuery = `UPDATE users SET pups_losses = GREATEST(pups_losses - 1, 0) WHERE discord_id = ?`
	case "PIT":
		updateQuery = `UPDATE users SET pit_losses = GREATEST(pit_losses - 1, 0) WHERE discord_id = ?`
	}

	if _, err := tx.Exec(updateQuery, userID); err != nil {
		return err
	}

	logQuery := `INSERT INTO win_logs (user_id, tournament_type, action, awarded_by) VALUES (?, ?, 'REMOVE_LOSS', ?)`
	if _, err := tx.Exec(logQuery, userID, tournamentType, removedBy); err != nil {
		return err
	}

	return tx.Commit()
}

func (m *MySQL) GetUserLosses(userID int64) (int, int, int, error) {
	query := `SELECT pugs_losses, pups_losses, pit_losses FROM users WHERE discord_id = ?`
	var pugsLosses, pupsLosses, pitLosses int

	err := m.DB.QueryRow(query, userID).Scan(&pugsLosses, &pupsLosses, &pitLosses)
	if err == sql.ErrNoRows {
		return 0, 0, 0, nil
	}
	return pugsLosses, pupsLosses, pitLosses, err
}

func (m *MySQL) GetTournamentCreator(tournamentID int64) (int64, error) {
	var createdBy int64

	err := m.executeWithRetry(func() error {
		query := `SELECT created_by FROM tournaments WHERE id = ?`
		return m.DB.QueryRow(query, tournamentID).Scan(&createdBy)
	})

	if err != nil {
		return 0, err
	}
	return createdBy, nil
}

type PlayerStats struct {
	DiscordID          int64      `json:"discord_id"`
	PugsWins           int        `json:"pugs_wins"`
	PupsWins           int        `json:"pups_wins"`
	PitWins            int        `json:"pit_wins"`
	PugsLosses         int        `json:"pugs_losses"`
	PupsLosses         int        `json:"pups_losses"`
	PitLosses          int        `json:"pit_losses"`
	TotalWins          int        `json:"total_wins"`
	TotalLosses        int        `json:"total_losses"`
	FirstWinTimestamp  *time.Time `json:"first_win_timestamp"`
	LastWinTimestamp   *time.Time `json:"last_win_timestamp"`
	FirstLossTimestamp *time.Time `json:"first_loss_timestamp"`
	LastLossTimestamp  *time.Time `json:"last_loss_timestamp"`
	CreatedAt          time.Time  `json:"created_at"`
}

type WinLog struct {
	ID             int64     `json:"id"`
	UserID         int64     `json:"user_id"`
	TournamentType string    `json:"tournament_type"`
	Action         string    `json:"action"`
	AwardedBy      int64     `json:"awarded_by"`
	TournamentID   *int64    `json:"tournament_id"`
	CreatedAt      time.Time `json:"created_at"`
}

func (m *MySQL) GetPlayerStats(userID int64) (*PlayerStats, error) {
	query := `
		SELECT 
			discord_id, 
			COALESCE(pugs_wins, 0), 
			COALESCE(pups_wins, 0), 
			COALESCE(pit_wins, 0),
			COALESCE(pugs_losses, 0), 
			COALESCE(pups_losses, 0), 
			COALESCE(pit_losses, 0),
			COALESCE(pugs_wins, 0) + COALESCE(pups_wins, 0) + COALESCE(pit_wins, 0) as total_wins,
			COALESCE(pugs_losses, 0) + COALESCE(pups_losses, 0) + COALESCE(pit_losses, 0) as total_losses,
			first_win_timestamp,
			last_win_timestamp,
			first_loss_timestamp,
			last_loss_timestamp,
			created_at
		FROM users 
		WHERE discord_id = ?`

	stats := &PlayerStats{}
	err := m.DB.QueryRow(query, userID).Scan(
		&stats.DiscordID,
		&stats.PugsWins,
		&stats.PupsWins,
		&stats.PitWins,
		&stats.PugsLosses,
		&stats.PupsLosses,
		&stats.PitLosses,
		&stats.TotalWins,
		&stats.TotalLosses,
		&stats.FirstWinTimestamp,
		&stats.LastWinTimestamp,
		&stats.FirstLossTimestamp,
		&stats.LastLossTimestamp,
		&stats.CreatedAt,
	)

	if err == sql.ErrNoRows {
		return &PlayerStats{
			DiscordID: userID,
			PugsWins:  0,
			PupsWins:  0,
			PitWins:   0,
			TotalWins: 0,
		}, nil
	}

	return stats, err
}

func (m *MySQL) GetPlayerWinLogs(userID int64, limit int) ([]WinLog, error) {
	query := `
		SELECT id, user_id, tournament_type, action, awarded_by, tournament_id, created_at
		FROM win_logs 
		WHERE user_id = ? 
		ORDER BY created_at DESC 
		LIMIT ?`

	rows, err := m.DB.Query(query, userID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var logs []WinLog
	for rows.Next() {
		var log WinLog
		err := rows.Scan(
			&log.ID,
			&log.UserID,
			&log.TournamentType,
			&log.Action,
			&log.AwardedBy,
			&log.TournamentID,
			&log.CreatedAt,
		)
		if err != nil {
			return nil, err
		}
		logs = append(logs, log)
	}

	return logs, rows.Err()
}

func (m *MySQL) GetTopPlayers(tournamentType string, limit int) ([]PlayerStats, error) {
	var orderColumn string
	switch tournamentType {
	case "PUGS":
		orderColumn = "pugs_wins"
	case "PUPS":
		orderColumn = "pups_wins"
	case "PIT":
		orderColumn = "pit_wins"
	case "ALL":
		orderColumn = "(COALESCE(pugs_wins, 0) + COALESCE(pups_wins, 0) + COALESCE(pit_wins, 0))"
	default:
		return nil, fmt.Errorf("invalid tournament type: %s", tournamentType)
	}
	query := fmt.Sprintf(`
		SELECT 
			discord_id, 
			COALESCE(pugs_wins, 0), 
			COALESCE(pups_wins, 0), 
			COALESCE(pit_wins, 0),
			COALESCE(pugs_losses, 0),
			COALESCE(pups_losses, 0),
			COALESCE(pit_losses, 0),
			COALESCE(pugs_wins, 0) + COALESCE(pups_wins, 0) + COALESCE(pit_wins, 0) as total_wins,
			COALESCE(pugs_losses, 0) + COALESCE(pups_losses, 0) + COALESCE(pit_losses, 0) as total_losses,
			first_win_timestamp,
			last_win_timestamp,
			first_loss_timestamp,
			last_loss_timestamp,
			created_at
		FROM users 
		WHERE %s > 0
		ORDER BY %s DESC 
		LIMIT ?`, orderColumn, orderColumn)

	rows, err := m.DB.Query(query, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var players []PlayerStats
	for rows.Next() {
		var stats PlayerStats
		err := rows.Scan(
			&stats.DiscordID,
			&stats.PugsWins,
			&stats.PupsWins,
			&stats.PitWins,
			&stats.PugsLosses,
			&stats.PupsLosses,
			&stats.PitLosses,
			&stats.TotalWins,
			&stats.TotalLosses,
			&stats.FirstWinTimestamp,
			&stats.LastWinTimestamp,
			&stats.FirstLossTimestamp,
			&stats.LastLossTimestamp,
			&stats.CreatedAt,
		)
		if err != nil {
			return nil, err
		}
		players = append(players, stats)
	}

	return players, rows.Err()
}

func (m *MySQL) GetTournamentTeams(tournamentID int64) ([]TournamentTeam, string, error) {
	var teams []TournamentTeam
	var tournamentType string

	err := m.executeWithRetry(func() error {
		query := `
			SELECT 
				tt.team_number,
				tt.player1_id, tt.player2_id, tt.player3_id, tt.player4_id,
				t.tournament_type, t.num_teams, t.players_per_team, t.status
			FROM tournament_teams tt 
			JOIN tournaments t ON tt.tournament_id = t.id 
			WHERE t.id = ?
			ORDER BY tt.team_number`

		rows, err := m.DB.Query(query, tournamentID)
		if err != nil {
			return err
		}
		defer rows.Close()

		teams = []TournamentTeam{}
		var numTeams, playersPerTeam int
		var status string

		for rows.Next() {
			var team TournamentTeam
			var player1, player2, player3, player4 sql.NullInt64

			err := rows.Scan(
				&team.TeamNumber,
				&player1, &player2, &player3, &player4,
				&tournamentType, &numTeams, &playersPerTeam, &status,
			)
			if err != nil {
				return err
			}

			if player1.Valid {
				team.Players = append(team.Players, player1.Int64)
			}
			if player2.Valid {
				team.Players = append(team.Players, player2.Int64)
			}
			if player3.Valid {
				team.Players = append(team.Players, player3.Int64)
			}
			if player4.Valid {
				team.Players = append(team.Players, player4.Int64)
			}

			teams = append(teams, team)
		}

		if len(teams) == 0 {
			var exists bool
			checkQuery := `SELECT COUNT(*) > 0 FROM tournaments WHERE id = ?`
			err := m.DB.QueryRow(checkQuery, tournamentID).Scan(&exists)
			if err != nil {
				return err
			}
			if !exists {
				return fmt.Errorf("tournament not found")
			}

			basicQuery := `SELECT tournament_type, num_teams, players_per_team, status FROM tournaments WHERE id = ?`
			err = m.DB.QueryRow(basicQuery, tournamentID).Scan(&tournamentType, &numTeams, &playersPerTeam, &status)
			if err != nil {
				return err
			}
		}

		return rows.Err()
	})

	return teams, tournamentType, err
}

type TournamentTeam struct {
	TeamNumber int     `json:"team_number"`
	Players    []int64 `json:"players"`
}

func (m *MySQL) GetTournamentStatus(tournamentID int64) (string, error) {
	var status string

	err := m.executeWithRetry(func() error {
		query := `SELECT status FROM tournaments WHERE id = ?`
		return m.DB.QueryRow(query, tournamentID).Scan(&status)
	})

	if err == sql.ErrNoRows {
		return "", fmt.Errorf("tournament not found")
	}

	return status, err
}
