package database

import (
	"context"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
)

type Dragonfly struct {
	Client *redis.Client
}

func NewDragonfly(password, host, port string) (*Dragonfly, error) {
	var addr string
	if port != "" {
		addr = fmt.Sprintf("%s:%s", host, port)
	} else {
		addr = host
	}

	client := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password,
		DB:       0,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := client.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("failed to connect to Dragonfly: %v", err)
	}

	return &Dragonfly{Client: client}, nil
}

func (d *Dragonfly) Close() error {
	return d.Client.Close()
}

func (d *Dragonfly) Set(ctx context.Context, key string, value interface{}, expiration time.Duration) error {
	return d.Client.Set(ctx, key, value, expiration).Err()
}

func (d *Dragonfly) Get(ctx context.Context, key string) (string, error) {
	return d.Client.Get(ctx, key).Result()
}

func (d *Dragonfly) Del(ctx context.Context, keys ...string) error {
	return d.Client.Del(ctx, keys...).Err()
}

func (d *Dragonfly) Exists(ctx context.Context, keys ...string) (int64, error) {
	return d.Client.Exists(ctx, keys...).Result()
}

func (d *Dragonfly) IncrementCounter(ctx context.Context, key string, expiration time.Duration) (int64, error) {
	pipe := d.Client.Pipeline()
	incr := pipe.Incr(ctx, key)
	pipe.Expire(ctx, key, expiration)
	_, err := pipe.Exec(ctx)
	if err != nil {
		return 0, err
	}
	return incr.Val(), nil
}

func (d *Dragonfly) SetUserSession(ctx context.Context, userID string, sessionData string, expiration time.Duration) error {
	key := fmt.Sprintf("session:user:%s", userID)
	return d.Set(ctx, key, sessionData, expiration)
}

func (d *Dragonfly) GetUserSession(ctx context.Context, userID string) (string, error) {
	key := fmt.Sprintf("session:user:%s", userID)
	return d.Get(ctx, key)
}

func (d *Dragonfly) DeleteUserSession(ctx context.Context, userID string) error {
	key := fmt.Sprintf("session:user:%s", userID)
	return d.Del(ctx, key)
}
