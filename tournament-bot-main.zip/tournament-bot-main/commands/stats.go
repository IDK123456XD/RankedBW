package commands

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"pugs-bot/database"

	"github.com/bwmarrin/discordgo"
)

func (b *Bot) handleStats(s *discordgo.Session, i *discordgo.InteractionCreate) {
	options := i.ApplicationCommandData().Options
	if len(options) == 0 {
		return
	}

	subCommand := options[0]
	switch subCommand.Name {
	case "player":
		b.handleStatsPlayer(s, i, subCommand)
	case "top":
		b.handleStatsTop(s, i, subCommand)
	case "history":
		b.handleStatsHistory(s, i, subCommand)
	}
}

func (b *Bot) handleStatsPlayer(s *discordgo.Session, i *discordgo.InteractionCreate, subCommand *discordgo.ApplicationCommandInteractionDataOption) {
	var targetUser *discordgo.User

	if len(subCommand.Options) > 0 && subCommand.Options[0].UserValue(s) != nil {
		targetUser = subCommand.Options[0].UserValue(s)
	} else {
		targetUser = i.Member.User
	}

	playerID, _ := strconv.ParseInt(targetUser.ID, 10, 64)
	stats, err := b.MySQL.GetPlayerStats(playerID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to retrieve player statistics.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	var playerSinceText string
	if stats.TotalWins == 0 && stats.TotalLosses == 0 {
		playerSinceText = "Never"
	} else {
		playerSinceText = formatTimestamp(stats.CreatedAt)
	}

	embed := &discordgo.MessageEmbed{
		Title:     fmt.Sprintf("RBW Tournament Stats - %s", targetUser.Username),
		Color:     0x00d4ff,
		Thumbnail: &discordgo.MessageEmbedThumbnail{URL: targetUser.AvatarURL("64")},
		Fields: []*discordgo.MessageEmbedField{
			{
				Name:   "Tournament Wins",
				Value:  fmt.Sprintf("**PUGS:** %d\n**PUPS:** %d\n**PIT:** %d", stats.PugsWins, stats.PupsWins, stats.PitWins),
				Inline: true,
			},
			{
				Name:   "Tournament Losses",
				Value:  fmt.Sprintf("**PUGS:** %d\n**PUPS:** %d\n**PIT:** %d", stats.PugsLosses, stats.PupsLosses, stats.PitLosses),
				Inline: true,
			},
			{
				Name: "Total Statistics",
				Value: fmt.Sprintf("**Total Wins:** %d\n**Total Losses:** %d\n**Win Rate:** %.1f%%\n**Tournament Player Since:** %s",
					stats.TotalWins, stats.TotalLosses, calculateWinRate(stats.TotalWins, stats.TotalLosses), playerSinceText),
				Inline: false,
			},
		},
	}

	if stats.FirstWinTimestamp != nil {
		embed.Fields = append(embed.Fields, &discordgo.MessageEmbedField{
			Name:   "Win Timeline",
			Value:  fmt.Sprintf("**First Win:** %s\n**Last Win:** %s", formatTimestamp(*stats.FirstWinTimestamp), formatTimestamp(*stats.LastWinTimestamp)),
			Inline: true,
		})
	}

	if stats.FirstLossTimestamp != nil {
		embed.Fields = append(embed.Fields, &discordgo.MessageEmbedField{
			Name:   "Loss Timeline",
			Value:  fmt.Sprintf("**First Loss:** %s\n**Last Loss:** %s", formatTimestamp(*stats.FirstLossTimestamp), formatTimestamp(*stats.LastLossTimestamp)),
			Inline: true,
		})
	}

	goalInfo := getNextGoal(stats)
	if goalInfo != "" {
		embed.Fields = append(embed.Fields, &discordgo.MessageEmbedField{
			Name:   "Next Goal",
			Value:  goalInfo,
			Inline: false,
		})
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}

func (b *Bot) handleStatsTop(s *discordgo.Session, i *discordgo.InteractionCreate, subCommand *discordgo.ApplicationCommandInteractionDataOption) {
	tournamentType := "ALL"
	limit := 10

	for _, option := range subCommand.Options {
		switch option.Name {
		case "type":
			tournamentType = option.StringValue()
		case "limit":
			limit = int(option.IntValue())
		}
	}

	players, err := b.MySQL.GetTopPlayers(tournamentType, limit)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to retrieve leaderboard.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if len(players) == 0 {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Tournament Leaderboard",
					Description: fmt.Sprintf("No players found for %s tournaments yet.", tournamentType),
					Color:       0x95a5a6,
				}},
			},
		})
		return
	}

	var leaderboardText strings.Builder
	for i, player := range players {
		rank := i + 1
		var medal string
		switch rank {
		case 1:
			medal = "🥇"
		case 2:
			medal = "🥈"
		case 3:
			medal = "🥉"
		default:
			medal = fmt.Sprintf("`%d.`", rank)
		}

		var winsText string
		if tournamentType == "ALL" {
			winsText = fmt.Sprintf("%d total (%d PUGS, %d PUPS, %d PIT)",
				player.TotalWins, player.PugsWins, player.PupsWins, player.PitWins)
		} else {
			switch tournamentType {
			case "PUGS":
				winsText = fmt.Sprintf("%d wins", player.PugsWins)
			case "PUPS":
				winsText = fmt.Sprintf("%d wins", player.PupsWins)
			case "PIT":
				winsText = fmt.Sprintf("%d wins", player.PitWins)
			}
		}

		leaderboardText.WriteString(fmt.Sprintf("%s <@%d> - %s\n", medal, player.DiscordID, winsText))
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Top %d Players - %s", len(players), tournamentType),
		Description: leaderboardText.String(),
		Color:       0xffd700,
		Footer:      &discordgo.MessageEmbedFooter{Text: "/stats player @user"},
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}

func (b *Bot) handleStatsHistory(s *discordgo.Session, i *discordgo.InteractionCreate, subCommand *discordgo.ApplicationCommandInteractionDataOption) {
	var targetUser *discordgo.User
	limit := 10

	for _, option := range subCommand.Options {
		switch option.Name {
		case "player":
			if option.UserValue(s) != nil {
				targetUser = option.UserValue(s)
			}
		case "limit":
			limit = int(option.IntValue())
		}
	}

	if targetUser == nil {
		targetUser = i.Member.User
	}

	playerID, _ := strconv.ParseInt(targetUser.ID, 10, 64)
	logs, err := b.MySQL.GetPlayerWinLogs(playerID, limit)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to retrieve player history.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if len(logs) == 0 {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Tournament History",
					Description: fmt.Sprintf("No tournament history found for %s.", targetUser.Username),
					Color:       0x95a5a6,
				}},
			},
		})
		return
	}

	var historyText strings.Builder
	for _, log := range logs {
		var actionSymbol string
		if log.Action == "ADD" {
			actionSymbol = "+"
		} else if log.Action == "LOSS" {
			actionSymbol = "-"
		} else {
			actionSymbol = "-"
		}

		tournamentInfo := ""
		if log.TournamentID != nil {
			tournamentInfo = fmt.Sprintf(" (Tournament #%d)", *log.TournamentID)
		}

		historyText.WriteString(fmt.Sprintf("%s **%s** %s%s - <@%d>\n`%s`\n\n",
			actionSymbol, log.TournamentType, log.Action, tournamentInfo, log.AwardedBy, formatTimestamp(log.CreatedAt)))
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Recent History - %s", targetUser.Username),
		Description: historyText.String(),
		Color:       0x9b59b6,
		Footer:      &discordgo.MessageEmbedFooter{Text: fmt.Sprintf("Showing last %d entries", len(logs))},
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}

func formatTimestamp(t time.Time) string {
	return fmt.Sprintf("<t:%d:R>", t.Unix())
}

func calculateWinRate(wins, losses int) float64 {
	totalGames := wins + losses
	if totalGames == 0 {
		return 0.0
	}
	return (float64(wins) / float64(totalGames)) * 100
}

func getNextGoal(stats *database.PlayerStats) string {
	goals := []int{1, 10, 20, 25, 50}

	var result strings.Builder

	types := []struct {
		name  string
		wins  int
		promo string
	}{
		{"PUGS", stats.PugsWins, ""},
		{"PUPS", stats.PupsWins, ""},
		{"PIT", stats.PitWins, ""},
	}

	for _, t := range types {
		for _, goal := range goals {
			if t.wins < goal {
				remaining := goal - t.wins
				if goal == 25 && t.promo != "" {
					result.WriteString(fmt.Sprintf("**%s:** %d/%d to %s (%d more)\n", t.name, t.wins, goal, t.promo, remaining))
				} else if goal == 1 {
					result.WriteString(fmt.Sprintf("**%s:** %d/%d to Champion (%d more)\n", t.name, t.wins, goal, remaining))
				} else {
					result.WriteString(fmt.Sprintf("**%s:** %d/%d to Champion x%d (%d more)\n", t.name, t.wins, goal, goal, remaining))
				}
				break
			}
		}
	}
	return result.String()
}
