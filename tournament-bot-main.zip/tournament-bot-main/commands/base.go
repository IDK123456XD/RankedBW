package commands

import (
	"context"
	"fmt"
	"strconv"
	"time"

	"pugs-bot/database"

	"github.com/bwmarrin/discordgo"
)

type Bot struct {
	Session   *discordgo.Session
	MySQL     MySQLInterface
	Dragonfly DragonflyInterface
	Config    *Config
}

type Config struct {
	DevGuildID            string
	BotDevID              string
	PugsManagerRole       string
	PupsManagerRole       string
	PitManagerRole        string
	LogChannelID          string
	PugsTournamentChannel string
	PupsTournamentChannel string
	PitTournamentChannel  string

	PugsChampionRole    string
	PugsChampionX10Role string
	PugsChampionX20Role string
	PugsChampionX50Role string

	PupsChampionRole    string
	PupsChampionX10Role string
	PupsChampionX20Role string
	PupsChampionX50Role string
	PugsTrialRole       string
	PitChampionRole     string
	PitChampionX10Role  string
	PitChampionX20Role  string
	PitChampionX50Role  string
}

type MySQLInterface interface {
	UpsertUser(userID int64, username, discriminator, avatar string) error
	EnsureUserExists(userID int64) error
	CreateTournament(tournamentType string, numTeams, playersPerTeam int, createdBy int64) (int64, error)
	SetTournamentTeam(tournamentID int64, teamNumber int, players []int64) error
	CompleteTournament(tournamentID int64, winnerTeam int) error
	GetTournamentWinners(tournamentID int64) ([]int64, string, error)
	AddWin(userID int64, tournamentType string, awardedBy int64, tournamentID *int64) error
	RemoveWin(userID int64, tournamentType string, removedBy int64) error
	AddLoss(userID int64, tournamentType string, awardedBy int64, tournamentID *int64) error
	RemoveLoss(userID int64, tournamentType string, removedBy int64) error
	GetUserWins(userID int64) (int, int, int, error)
	GetUserLosses(userID int64) (int, int, int, error)
	GetPlayerStats(userID int64) (*database.PlayerStats, error)
	GetPlayerWinLogs(userID int64, limit int) ([]database.WinLog, error)
	GetTopPlayers(tournamentType string, limit int) ([]database.PlayerStats, error)
	GetTournamentTeams(tournamentID int64) ([]database.TournamentTeam, string, error)
	GetTournamentCreator(tournamentID int64) (int64, error)
	GetTournamentStatus(tournamentID int64) (string, error)
}

type DragonflyInterface interface {
	Set(ctx context.Context, key string, value interface{}, expiration time.Duration) error
	Get(ctx context.Context, key string) (string, error)
	IncrementCounter(ctx context.Context, key string, expiration time.Duration) (int64, error)
}

func NewBot(session *discordgo.Session, mysql MySQLInterface, dragonfly DragonflyInterface, config *Config) *Bot {
	return &Bot{
		Session:   session,
		MySQL:     mysql,
		Dragonfly: dragonfly,
		Config:    config,
	}
}

func (b *Bot) HandleInteraction(s *discordgo.Session, i *discordgo.InteractionCreate) {
	defer func() {
		if r := recover(); r != nil {
			fmt.Printf("   PANIC RECOVERED in HandleInteraction: %v\n", r)
			fmt.Printf("   Interaction ID: %s\n", i.Interaction.ID)
			fmt.Printf("   Command: %s\n", i.ApplicationCommandData().Name)
			fmt.Printf("   User: %s\n", i.Member.User.Username)
			fmt.Printf("   Time: %v\n", time.Now().Format("2006-01-02 15:04:05"))

			s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
				Type: discordgo.InteractionResponseChannelMessageWithSource,
				Data: &discordgo.InteractionResponseData{
					Embeds: []*discordgo.MessageEmbed{{
						Title:       "Bot Error",
						Description: "An unexpected error occurred. Please try again or contact an administrator.",
						Color:       0xff0000,
					}},
					Flags: discordgo.MessageFlagsEphemeral,
				},
			})
		}
	}()

	if i.ApplicationCommandData().Name == "" {
		return
	}

	commandName := i.ApplicationCommandData().Name

	go func() {
		defer func() {
			if r := recover(); r != nil {
				fmt.Printf("  PANIC in UpsertUser goroutine: %v\n", r)
			}
		}()

		user := i.Member.User
		userIDInt, _ := strconv.ParseInt(user.ID, 10, 64)
		if err := b.MySQL.UpsertUser(userIDInt, user.Username, user.Discriminator, ""); err != nil {
			fmt.Printf("Failed to update user info: %v\n", err)
		}
	}()

	switch commandName {
	case "tournament":
		b.handleTournament(s, i)
	case "pugs":
		b.handlePugs(s, i)
	case "pups":
		b.handlePups(s, i)
	case "pit":
		b.handlePit(s, i)
	case "stats":
		b.handleStats(s, i)
	}
}

func (b *Bot) hasManagerPermission(member *discordgo.Member, tournamentType string) bool {
	var requiredRole string
	switch tournamentType {
	case "PUGS":
		requiredRole = b.Config.PugsManagerRole
	case "PUPS":
		requiredRole = b.Config.PupsManagerRole
	case "PIT":
		requiredRole = b.Config.PitManagerRole
	default:
		return false
	}

	for _, roleID := range member.Roles {
		if roleID == requiredRole {
			return true
		}
	}

	return false
}

func (b *Bot) awardRoleBasedOnWins(s *discordgo.Session, guildID, userID string, tournamentType string, winCount int) {
	var rolesToAdd []string

	switch tournamentType {
	case "PUGS":
		if winCount >= 1 {
			rolesToAdd = append(rolesToAdd, b.Config.PugsChampionRole)
		}
		if winCount >= 10 {
			rolesToAdd = append(rolesToAdd, b.Config.PugsChampionX10Role)
		}
		if winCount >= 20 {
			rolesToAdd = append(rolesToAdd, b.Config.PugsChampionX20Role)
		}
		if winCount >= 50 {
			rolesToAdd = append(rolesToAdd, b.Config.PugsChampionX50Role)
		}
	case "PUPS":
		if winCount >= 1 {
			rolesToAdd = append(rolesToAdd, b.Config.PupsChampionRole)
		}
		if winCount >= 10 {
			rolesToAdd = append(rolesToAdd, b.Config.PupsChampionX10Role)
		}
		if winCount >= 20 {
			rolesToAdd = append(rolesToAdd, b.Config.PupsChampionX20Role)
		}
		if winCount >= 50 {
			rolesToAdd = append(rolesToAdd, b.Config.PupsChampionX50Role)
		}

	case "PIT":
		if winCount >= 1 {
			rolesToAdd = append(rolesToAdd, b.Config.PitChampionRole)
		}
		if winCount >= 10 {
			rolesToAdd = append(rolesToAdd, b.Config.PitChampionX10Role)
		}
		if winCount >= 20 {
			rolesToAdd = append(rolesToAdd, b.Config.PitChampionX20Role)
		}
		if winCount >= 50 {
			rolesToAdd = append(rolesToAdd, b.Config.PitChampionX50Role)
		}
	}

	for _, roleID := range rolesToAdd {
		if roleID != "" {
			err := s.GuildMemberRoleAdd(guildID, userID, roleID)
			if err != nil {
				fmt.Printf("Failed to add role %s to user %s: %v\n", roleID, userID, err)
			} else {
				fmt.Printf("Successfully added role %s to user %s\n", roleID, userID)
			}
		}
	}
}
