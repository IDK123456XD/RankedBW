package commands

import (
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/bwmarrin/discordgo"
)

var (
	processedInteractions = make(map[string]time.Time)
	interactionMutex      = sync.RWMutex{}
	cleanupRunning        = false
	cleanupMutex          = sync.Mutex{}
)

func (b *Bot) isInteractionProcessed(interactionID string) bool {
	interactionMutex.RLock()
	_, exists := processedInteractions[interactionID]
	interactionMutex.RUnlock()
	if exists {
		return true
	}
	return false
}

func (b *Bot) markInteractionProcessed(interactionID string) {
	interactionMutex.Lock()
	processedInteractions[interactionID] = time.Now()
	interactionMutex.Unlock()

	cleanupMutex.Lock()
	if !cleanupRunning {
		cleanupRunning = true
		cleanupMutex.Unlock()

		go func() {
			defer func() {
				cleanupMutex.Lock()
				cleanupRunning = false
				cleanupMutex.Unlock()
			}()

			ticker := time.NewTicker(5 * time.Minute)
			defer ticker.Stop()

			for range ticker.C {
				interactionMutex.Lock()
				cutoff := time.Now().Add(-2 * time.Hour)
				cleaned := 0
				for id, timestamp := range processedInteractions {
					if timestamp.Before(cutoff) {
						delete(processedInteractions, id)
						cleaned++
					}
				}

				interactionMutex.Unlock()
			}
		}()
	} else {
		cleanupMutex.Unlock()
	}
}

func (b *Bot) handlePugs(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !b.hasManagerPermission(i.Member, "PUGS") {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Permission Denied",
					Description: "You don't have permission to manage PUGS tournaments.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options
	if len(options) == 0 {
		return
	}

	subCommand := options[0]
	switch subCommand.Name {
	case "add":
		b.handleQuickAdd(s, i, subCommand, "PUGS")
	case "remove":
		b.handleQuickRemove(s, i, subCommand, "PUGS")
	}
}

func (b *Bot) handlePups(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !b.hasManagerPermission(i.Member, "PUPS") {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Permission Denied",
					Description: "You don't have permission to manage PUPS tournaments.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options
	if len(options) == 0 {
		return
	}

	subCommand := options[0]
	switch subCommand.Name {
	case "add":
		b.handleQuickAdd(s, i, subCommand, "PUPS")
	case "remove":
		b.handleQuickRemove(s, i, subCommand, "PUPS")
	}
}

func (b *Bot) handlePit(s *discordgo.Session, i *discordgo.InteractionCreate) {
	if !b.hasManagerPermission(i.Member, "PIT") {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Permission Denied",
					Description: "You don't have permission to manage PIT tournaments.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	options := i.ApplicationCommandData().Options
	if len(options) == 0 {
		return
	}

	subCommand := options[0]
	switch subCommand.Name {
	case "add":
		b.handleQuickAdd(s, i, subCommand, "PIT")
	case "remove":
		b.handleQuickRemove(s, i, subCommand, "PIT")
	}
}

func (b *Bot) handleQuickAdd(s *discordgo.Session, i *discordgo.InteractionCreate, subCommand *discordgo.ApplicationCommandInteractionDataOption, tournamentType string) {
	interactionID := i.Interaction.ID

	if b.isInteractionProcessed(interactionID) {
		return
	}

	b.markInteractionProcessed(interactionID)

	typeValue := subCommand.Options[0].StringValue()
	player := subCommand.Options[1].UserValue(s)

	playerID, _ := strconv.ParseInt(player.ID, 10, 64)
	awardedBy, _ := strconv.ParseInt(i.Member.User.ID, 10, 64)

	err := b.MySQL.EnsureUserExists(playerID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to ensure user exists in database.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	var count int
	var actionText, countText string
	var color int
	if typeValue == "win" {
		err = b.MySQL.AddWin(playerID, tournamentType, awardedBy, nil)
		if err == nil {
			switch tournamentType {
			case "PUGS":
				pugsWins, _, _, _ := b.MySQL.GetUserWins(playerID)
				count = pugsWins
			case "PUPS":
				_, pupsWins, _, _ := b.MySQL.GetUserWins(playerID)
				count = pupsWins
			case "PIT":
				_, _, pitWins, _ := b.MySQL.GetUserWins(playerID)
				count = pitWins
			}
			b.awardRoleBasedOnWins(s, i.GuildID, player.ID, tournamentType, count)
		}
		actionText = "Win Added"
		countText = "wins"
		color = 0x00ff00
	} else {
		err = b.MySQL.AddLoss(playerID, tournamentType, awardedBy, nil)
		if err == nil {
			switch tournamentType {
			case "PUGS":
				pugsLosses, _, _, _ := b.MySQL.GetUserLosses(playerID)
				count = pugsLosses
			case "PUPS":
				_, pupsLosses, _, _ := b.MySQL.GetUserLosses(playerID)
				count = pupsLosses
			case "PIT":
				_, _, pitLosses, _ := b.MySQL.GetUserLosses(playerID)
				count = pitLosses
			}
		}
		actionText = "Loss Added"
		countText = "losses"
		color = 0xff9900
	}
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: fmt.Sprintf("Failed to add %s %s.", tournamentType, typeValue),
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if b.Config.LogChannelID != "" {
		logEmbed := &discordgo.MessageEmbed{
			Title:       fmt.Sprintf("%s %s Added", tournamentType, strings.Title(typeValue)),
			Description: fmt.Sprintf("**Player:** <@%s>\n**Added by:** <@%s>\n**New Total:** %d %s", player.ID, i.Member.User.ID, count, countText),
			Color:       color,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		s.ChannelMessageSendEmbed(b.Config.LogChannelID, logEmbed)
	}
	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{{
				Title:       fmt.Sprintf("%s %s", tournamentType, actionText),
				Description: fmt.Sprintf("Added 1 %s %s to <@%s>\n**New Total:** %d %s", tournamentType, typeValue, player.ID, count, countText),
				Color:       color,
			}},
		},
	})

}

func (b *Bot) handleQuickRemove(s *discordgo.Session, i *discordgo.InteractionCreate, subCommand *discordgo.ApplicationCommandInteractionDataOption, tournamentType string) {
	interactionID := i.Interaction.ID
	if b.isInteractionProcessed(interactionID) {
		return
	}

	b.markInteractionProcessed(interactionID)

	typeValue := subCommand.Options[0].StringValue()
	player := subCommand.Options[1].UserValue(s)

	playerID, _ := strconv.ParseInt(player.ID, 10, 64)
	removedBy, _ := strconv.ParseInt(i.Member.User.ID, 10, 64)

	err := b.MySQL.EnsureUserExists(playerID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to ensure user exists in database.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	var count int
	var actionText, countText string
	var color int

	if typeValue == "win" {
		err = b.MySQL.RemoveWin(playerID, tournamentType, removedBy)
		if err == nil {
			switch tournamentType {
			case "PUGS":
				pugsWins, _, _, _ := b.MySQL.GetUserWins(playerID)
				count = pugsWins
			case "PUPS":
				_, pupsWins, _, _ := b.MySQL.GetUserWins(playerID)
				count = pupsWins
			case "PIT":
				_, _, pitWins, _ := b.MySQL.GetUserWins(playerID)
				count = pitWins
			}
			b.awardRoleBasedOnWins(s, i.GuildID, player.ID, tournamentType, count)
		}
		actionText = "Win Removed"
		countText = "wins"
		color = 0xff6b6b
	} else {
		err = b.MySQL.RemoveLoss(playerID, tournamentType, removedBy)
		if err == nil {
			switch tournamentType {
			case "PUGS":
				pugsLosses, _, _, _ := b.MySQL.GetUserLosses(playerID)
				count = pugsLosses
			case "PUPS":
				_, pupsLosses, _, _ := b.MySQL.GetUserLosses(playerID)
				count = pupsLosses
			case "PIT":
				_, _, pitLosses, _ := b.MySQL.GetUserLosses(playerID)
				count = pitLosses
			}
		}
		actionText = "Loss Removed"
		countText = "losses"
		color = 0xffcc66
	}
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: fmt.Sprintf("Failed to remove %s %s.", tournamentType, typeValue),
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if b.Config.LogChannelID != "" {
		logEmbed := &discordgo.MessageEmbed{
			Title:       fmt.Sprintf("%s %s Removed", tournamentType, strings.Title(typeValue)),
			Description: fmt.Sprintf("**Player:** <@%s>\n**Removed by:** <@%s>\n**New Total:** %d %s", player.ID, i.Member.User.ID, count, countText),
			Color:       color,
			Timestamp:   time.Now().Format(time.RFC3339),
		}
		s.ChannelMessageSendEmbed(b.Config.LogChannelID, logEmbed)
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{{
				Title:       fmt.Sprintf("%s %s", tournamentType, actionText),
				Description: fmt.Sprintf("Removed 1 %s %s from <@%s>\n**New Total:** %d %s", tournamentType, typeValue, player.ID, count, countText),
				Color:       color,
			}},
		},
	})
}
