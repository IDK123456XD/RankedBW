package commands

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"pugs-bot/database"

	"github.com/bwmarrin/discordgo"
)

func (b *Bot) handleTournament(s *discordgo.Session, i *discordgo.InteractionCreate) {
	options := i.ApplicationCommandData().Options
	if len(options) == 0 {
		return
	}
	subCommand := options[0]
	switch subCommand.Name {
	case "start":
		b.handleTournamentStart(s, i, subCommand)
	case "teams":
		b.handleTournamentTeams(s, i, subCommand)
	case "score":
		b.handleTournamentScore(s, i, subCommand)
	case "rewards":
		b.handleTournamentRewards(s, i, subCommand)
	}
}

func (b *Bot) handleTournamentStart(s *discordgo.Session, i *discordgo.InteractionCreate, subCommand *discordgo.ApplicationCommandInteractionDataOption) {
	tournamentType := subCommand.Options[0].StringValue()
	numTeams := int(subCommand.Options[1].IntValue())
	playersPerTeam := int(subCommand.Options[2].IntValue())

	if !b.hasManagerPermission(i.Member, tournamentType) {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Permission Denied",
					Description: fmt.Sprintf("You don't have permission to manage %s tournaments.", tournamentType),
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	createdBy, _ := strconv.ParseInt(i.Member.User.ID, 10, 64)
	tournamentID, err := b.MySQL.CreateTournament(tournamentType, numTeams, playersPerTeam, createdBy)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to create tournament.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("%s Tournament Created", tournamentType),
		Description: fmt.Sprintf("**Tournament ID:** `%d`\n**Teams:** %d\n**Players per team:** %d", tournamentID, numTeams, playersPerTeam),
		Color:       0x00ff00,
		Fields: []*discordgo.MessageEmbedField{
			{
				Name:  "Next Steps",
				Value: fmt.Sprintf("Use `/tournament teams %d [team] [players...]` to set team members", tournamentID),
			},
		},
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}

func (b *Bot) handleTournamentTeams(s *discordgo.Session, i *discordgo.InteractionCreate, subCommand *discordgo.ApplicationCommandInteractionDataOption) {
	tournamentID := subCommand.Options[0].IntValue()
	teamNumber := int(subCommand.Options[1].IntValue())

	var players []int64
	var playerMentions []string
	playerSet := make(map[int64]bool) 

	for j := 2; j < len(subCommand.Options); j++ {
		if subCommand.Options[j].UserValue(s) != nil {
			user := subCommand.Options[j].UserValue(s)
			playerID, _ := strconv.ParseInt(user.ID, 10, 64)

			if playerSet[playerID] {
				s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
					Type: discordgo.InteractionResponseChannelMessageWithSource,
					Data: &discordgo.InteractionResponseData{
						Embeds: []*discordgo.MessageEmbed{{
							Title:       "Duplicate Player",
							Description: fmt.Sprintf("<@%s> is already added to this team. Each player can only be added once per team.", user.ID),
							Color:       0xff0000,
						}},
						Flags: discordgo.MessageFlagsEphemeral,
					},
				})
				return
			}

			playerSet[playerID] = true
			players = append(players, playerID)
			playerMentions = append(playerMentions, fmt.Sprintf("<@%s>", user.ID))
		}
	}

	existingTeams, _, err := b.MySQL.GetTournamentTeams(tournamentID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to check existing tournament teams.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	for _, newPlayerID := range players {
		for _, existingTeam := range existingTeams {
			if existingTeam.TeamNumber == teamNumber {
				continue
			}

			for _, existingPlayerID := range existingTeam.Players {
				if newPlayerID == existingPlayerID {
					s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
						Type: discordgo.InteractionResponseChannelMessageWithSource,
						Data: &discordgo.InteractionResponseData{
							Embeds: []*discordgo.MessageEmbed{{
								Title:       "Player Already Assigned",
								Description: fmt.Sprintf("<@%d> is already assigned to Team %d. Players can only be on one team per tournament.", newPlayerID, existingTeam.TeamNumber),
								Color:       0xff0000,
							}},
							Flags: discordgo.MessageFlagsEphemeral,
						},
					})
					return
				}
			}
		}
	}

	err = b.MySQL.SetTournamentTeam(tournamentID, teamNumber, players)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to set team members.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("Team %d Set", teamNumber),
		Description: fmt.Sprintf("**Tournament ID:** `%d`\n**Players:** %s", tournamentID, strings.Join(playerMentions, ", ")),
		Color:       0x0099ff,
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
		},
	})
}

func (b *Bot) handleTournamentScore(s *discordgo.Session, i *discordgo.InteractionCreate, subCommand *discordgo.ApplicationCommandInteractionDataOption) {
	tournamentID := subCommand.Options[0].IntValue()
	winnerTeam := int(subCommand.Options[1].IntValue())
	teams, tournamentType, err := b.MySQL.GetTournamentTeams(tournamentID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to get tournament teams.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	status, err := b.MySQL.GetTournamentStatus(tournamentID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to check tournament status.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if status == "COMPLETED" {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Scored",
					Description: "Tournament has been scored.",
					Color:       0x26FF6F,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	var winningTeam *database.TournamentTeam
	for _, team := range teams {
		if team.TeamNumber == winnerTeam {
			winningTeam = &team
			break
		}
	}

	if winningTeam == nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{Embeds: []*discordgo.MessageEmbed{{
				Title:       "Error",
				Description: "Specified tournament does not exist.",
				Color:       0xff0000,
			}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	if len(winningTeam.Players) == 0 {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: fmt.Sprintf("Team %d has no players assigned. Cannot score tournament.", winnerTeam),
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	err = b.MySQL.CompleteTournament(tournamentID, winnerTeam)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to complete tournament.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	createdBy, err := b.MySQL.GetTournamentCreator(tournamentID)
	if err != nil {
		s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
			Type: discordgo.InteractionResponseChannelMessageWithSource,
			Data: &discordgo.InteractionResponseData{
				Embeds: []*discordgo.MessageEmbed{{
					Title:       "Error",
					Description: "Failed to get tournament creator.",
					Color:       0xff0000,
				}},
				Flags: discordgo.MessageFlagsEphemeral,
			},
		})
		return
	}

	awardedBy, _ := strconv.ParseInt(i.Member.User.ID, 10, 64)
	tournamentIDPtr := &tournamentID
	var winnerMentions []string
	var losingTeams []string

	for _, team := range teams {
		if team.TeamNumber == winnerTeam {
			for _, playerID := range team.Players {
				if playerID > 0 {
					err := b.MySQL.EnsureUserExists(playerID)
					if err != nil {
						fmt.Printf("Failed to ensure user %d exists: %v\n", playerID, err)
						continue
					}

					time.Sleep(100 * time.Millisecond)

					err = b.MySQL.AddWin(playerID, tournamentType, awardedBy, tournamentIDPtr)
					if err != nil {
						fmt.Printf("Failed to add win for user %d: %v\n", playerID, err)
						continue
					}

					time.Sleep(50 * time.Millisecond)

					var winCount int
					switch tournamentType {
					case "PUGS":
						pugsWins, _, _, _ := b.MySQL.GetUserWins(playerID)
						winCount = pugsWins
					case "PUPS":
						_, pupsWins, _, _ := b.MySQL.GetUserWins(playerID)
						winCount = pupsWins
					case "PIT":
						_, _, pitWins, _ := b.MySQL.GetUserWins(playerID)
						winCount = pitWins
					}

					playerIDStr := fmt.Sprintf("%d", playerID)
					b.awardRoleBasedOnWins(s, i.GuildID, playerIDStr, tournamentType, winCount)

					winnerMentions = append(winnerMentions, fmt.Sprintf("<@%d>", playerID))
				}
			}
		} else {
			var teamMentions []string
			for _, playerID := range team.Players {
				if playerID > 0 { 
					err := b.MySQL.EnsureUserExists(playerID)
					if err != nil {
						fmt.Printf("Failed to ensure user %d exists: %v\n", playerID, err)
						continue
					}

					time.Sleep(100 * time.Millisecond)

					err = b.MySQL.AddLoss(playerID, tournamentType, awardedBy, tournamentIDPtr)
					if err != nil {
						fmt.Printf("Failed to add loss for user %d: %v\n", playerID, err)
					}
					teamMentions = append(teamMentions, fmt.Sprintf("<@%d>", playerID))
				}
			}
			if len(teamMentions) > 0 {
				losingTeams = append(losingTeams, fmt.Sprintf("**Team %d:** %s", team.TeamNumber, strings.Join(teamMentions, ", ")))
			}
		}
	}

	description := fmt.Sprintf("**Tournament ID:** `%d`\n**Started by:** <@%d>\n**Winning Team:** %d\n**Winners:** %s",
		tournamentID, createdBy, winnerTeam, strings.Join(winnerMentions, ", "))

	if len(losingTeams) > 0 {
		description += "\n\n**Losing Teams:**\n" + strings.Join(losingTeams, "\n")
	}

	embed := &discordgo.MessageEmbed{
		Title:       fmt.Sprintf("%s Tournament Complete!", tournamentType),
		Description: description,
		Color:       0xffd700,
	}

	var channelID string
	switch tournamentType {
	case "PUGS":
		channelID = b.Config.PugsTournamentChannel
	case "PUPS":
		channelID = b.Config.PupsTournamentChannel
	case "PIT":
		channelID = b.Config.PitTournamentChannel
	}

	if channelID != "" {
		s.ChannelMessageSendEmbed(channelID, embed)
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{{
				Title:       "Tournament Complete",
				Description: fmt.Sprintf("Tournament %d completed! Results posted to tournament channel.", tournamentID),
				Color:       0x00ff00,
			}},
			Flags: discordgo.MessageFlagsEphemeral,
		},
	})
}

func (b *Bot) handleTournamentRewards(s *discordgo.Session, i *discordgo.InteractionCreate, subCommand *discordgo.ApplicationCommandInteractionDataOption) {
	tournamentType := subCommand.Options[0].StringValue()

	var embed *discordgo.MessageEmbed

	switch tournamentType {
	case "PUGS":
		embed = &discordgo.MessageEmbed{
			Title: "🏆 PUGS Tournament Rewards",
			Color: 0x00ff00,
			Fields: []*discordgo.MessageEmbedField{
				{
					Name:   "🥇 1 Win",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PugsChampionRole),
					Inline: true,
				},
				{
					Name:   "🏅 10 Wins",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PugsChampionX10Role),
					Inline: true,
				},
				{
					Name:   "🎖️ 20 Wins",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PugsChampionX20Role),
					Inline: true,
				},
				{
					Name:   "👑 50 Wins",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PugsChampionX50Role),
					Inline: true,
				},
			}, Footer: &discordgo.MessageEmbedFooter{
				Text: "Roles are automatically assigned when you reach the goal!",
			},
		}
	case "PUPS":
		embed = &discordgo.MessageEmbed{
			Title: "🏆 PUPS Tournament Rewards",
			Color: 0xff6600,
			Fields: []*discordgo.MessageEmbedField{
				{
					Name:   "🥇 1 Win",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PupsChampionRole),
					Inline: true,
				},
				{
					Name:   "🏅 10 Wins",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PupsChampionX10Role),
					Inline: true,
				},
				{
					Name:   "🎖️ 20 Wins",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PupsChampionX20Role),
					Inline: true,
				},
				{
					Name:   "👑 50 Wins",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PupsChampionX50Role),
					Inline: true,
				},
			},
			Footer: &discordgo.MessageEmbedFooter{
				Text: "Roles are automatically assigned when you reach the goal!",
			},
		}
	case "PIT":
		embed = &discordgo.MessageEmbed{
			Title: "🏆 PIT Tournament Rewards",
			Color: 0x9932cc,
			Fields: []*discordgo.MessageEmbedField{
				{
					Name:   "🥇 1 Win",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PitChampionRole),
					Inline: true,
				},
				{
					Name:   "🏅 10 Wins",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PitChampionX10Role),
					Inline: true,
				},
				{
					Name:   "🎖️ 20 Wins",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PitChampionX20Role),
					Inline: true,
				},
				{
					Name:   "👑 50 Wins",
					Value:  fmt.Sprintf("<@&%s>", b.Config.PitChampionX50Role),
					Inline: true,
				},
			},
			Footer: &discordgo.MessageEmbedFooter{
				Text: "When the goal is reached you will receive your role.",
			},
		}
	default:
		embed = &discordgo.MessageEmbed{
			Title:       "Invalid Tournament Type",
			Description: "Please use a valid tournament type (PUGS, PUPS, or PIT).",
			Color:       0xff0000,
		}
	}

	s.InteractionRespond(i.Interaction, &discordgo.InteractionResponse{
		Type: discordgo.InteractionResponseChannelMessageWithSource,
		Data: &discordgo.InteractionResponseData{
			Embeds: []*discordgo.MessageEmbed{embed},
			Flags:  discordgo.MessageFlagsEphemeral,
		},
	})
}
