package main

import (
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"pugs-bot/commands"
	"pugs-bot/config"
	"pugs-bot/database"

	"github.com/bwmarrin/discordgo"
)

func registerCommands(session *discordgo.Session) error {
	commands := []*discordgo.ApplicationCommand{
		{
			Name:        "tournament",
			Description: "Tournament management commands",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Name:        "start",
					Description: "Start a new tournament",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionString,
							Name:        "type",
							Description: "Tournament type",
							Required:    true,
							Choices: []*discordgo.ApplicationCommandOptionChoice{
								{Name: "PUGS", Value: "PUGS"},
								{Name: "PUPS", Value: "PUPS"},
								{Name: "PIT", Value: "PIT"},
							},
						},
						{
							Type:        discordgo.ApplicationCommandOptionInteger,
							Name:        "teams",
							Description: "Number of teams",
							Required:    true,
						},
						{
							Type:        discordgo.ApplicationCommandOptionInteger,
							Name:        "players_per_team",
							Description: "Players per team",
							Required:    true,
						},
					},
				},
				{
					Name:        "teams",
					Description: "Set tournament teams",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionInteger,
							Name:        "id",
							Description: "Tournament ID",
							Required:    true,
						},
						{
							Type:        discordgo.ApplicationCommandOptionInteger,
							Name:        "team",
							Description: "Team number",
							Required:    true,
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player1",
							Description: "First player",
							Required:    true,
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player2",
							Description: "Second player",
							Required:    false,
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player3",
							Description: "Third player",
							Required:    false,
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player4",
							Description: "Fourth player",
							Required:    false,
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player5",
							Description: "Fifth player",
							Required:    false,
						},
					},
				},
				{
					Name:        "score",
					Description: "Score a tournament",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionInteger,
							Name:        "id",
							Description: "Tournament ID",
							Required:    true,
						},
						{
							Type:        discordgo.ApplicationCommandOptionInteger,
							Name:        "winning_team",
							Description: "Winning team number",
							Required:    true,
						},
					},
				},
				{
					Name:        "rewards",
					Description: "Show tournament reward goals",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionString,
							Name:        "type",
							Description: "Tournament type",
							Required:    true,
							Choices: []*discordgo.ApplicationCommandOptionChoice{
								{Name: "PUGS", Value: "PUGS"},
								{Name: "PUPS", Value: "PUPS"},
								{Name: "PIT", Value: "PIT"},
							},
						},
					},
				},
			},
		}, {
			Name:        "pugs",
			Description: "PUGS win/loss management (PUGS managers only)",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Name:        "add",
					Description: "Add a win or loss",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionString,
							Name:        "type",
							Description: "Win or Loss",
							Required:    true,
							Choices: []*discordgo.ApplicationCommandOptionChoice{
								{Name: "Win", Value: "win"},
								{Name: "Loss", Value: "loss"},
							},
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player",
							Description: "Player to add win/loss for",
							Required:    true,
						},
					},
				},
				{
					Name:        "remove",
					Description: "Remove a win or loss",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionString,
							Name:        "type",
							Description: "Win or Loss",
							Required:    true,
							Choices: []*discordgo.ApplicationCommandOptionChoice{
								{Name: "Win", Value: "win"},
								{Name: "Loss", Value: "loss"},
							},
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player",
							Description: "Player to remove win/loss from",
							Required:    true,
						},
					},
				},
			},
		}, {
			Name:        "pups",
			Description: "PUPS win/loss management (PUPS managers only)",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Name:        "add",
					Description: "Add a win or loss",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionString,
							Name:        "type",
							Description: "Win or Loss",
							Required:    true,
							Choices: []*discordgo.ApplicationCommandOptionChoice{
								{Name: "Win", Value: "win"},
								{Name: "Loss", Value: "loss"},
							},
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player",
							Description: "Player to add win/loss for",
							Required:    true,
						},
					},
				},
				{
					Name:        "remove",
					Description: "Remove a win or loss",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionString,
							Name:        "type",
							Description: "Win or Loss",
							Required:    true,
							Choices: []*discordgo.ApplicationCommandOptionChoice{
								{Name: "Win", Value: "win"},
								{Name: "Loss", Value: "loss"},
							},
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player",
							Description: "Player to remove win/loss from",
							Required:    true,
						},
					},
				},
			},
		}, {
			Name:        "pit",
			Description: "PIT win/loss management (PIT managers only)",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Name:        "add",
					Description: "Add a win or loss",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionString,
							Name:        "type",
							Description: "Win or Loss",
							Required:    true,
							Choices: []*discordgo.ApplicationCommandOptionChoice{
								{Name: "Win", Value: "win"},
								{Name: "Loss", Value: "loss"},
							},
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player",
							Description: "Player to add win/loss for",
							Required:    true,
						},
					},
				},
				{
					Name:        "remove",
					Description: "Remove a win or loss",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionString,
							Name:        "type",
							Description: "Win or Loss",
							Required:    true,
							Choices: []*discordgo.ApplicationCommandOptionChoice{
								{Name: "Win", Value: "win"},
								{Name: "Loss", Value: "loss"},
							},
						},
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "player",
							Description: "Player to remove win/loss from",
							Required:    true,
						},
					},
				},
			},
		},
		{
			Name:        "stats",
			Description: "Player stats",
			Options: []*discordgo.ApplicationCommandOption{
				{
					Name:        "player",
					Description: "Show player stats",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionUser,
							Name:        "user",
							Description: "Player to show stats for",
							Required:    false,
						},
					},
				},
				{
					Name:        "leaderboard",
					Description: "Show tournament leaderboard",
					Type:        discordgo.ApplicationCommandOptionSubCommand,
					Options: []*discordgo.ApplicationCommandOption{
						{
							Type:        discordgo.ApplicationCommandOptionString,
							Name:        "type",
							Description: "Tournament type",
							Required:    true,
							Choices: []*discordgo.ApplicationCommandOptionChoice{
								{Name: "All", Value: "all"},
								{Name: "PUGS", Value: "PUGS"},
								{Name: "PUPS", Value: "PUPS"},
								{Name: "PIT", Value: "PIT"},
							},
						},
					},
				},
			},
		},
	}

	for _, cmd := range commands {
		_, err := session.ApplicationCommandCreate(session.State.User.ID, "", cmd)
		if err != nil {
			return fmt.Errorf("failed to create global command %s: %v", cmd.Name, err)
		}
	}

	return nil
}

func startRotatingStatus(session *discordgo.Session) {
	statuses := []string{
		"Managing Tournaments",
		"PUGS • PUPS • PIT",
	}

	currentIndex := 0

	err := session.UpdateGameStatus(0, statuses[currentIndex])
	if err != nil {
		fmt.Printf("Failed to set initial status: %v\n", err)
	}

	ticker := time.NewTicker(30 * time.Second)
	go func() {
		for range ticker.C {
			currentIndex = (currentIndex + 1) % len(statuses)
			err := session.UpdateGameStatus(0, statuses[currentIndex])
			if err != nil {
				fmt.Printf("Failed to update status: %v\n", err)
			}
		}
	}()
}

func main() {
	cfg, err := config.Load()
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}

	mysql, err := database.NewMySQL(cfg.MySQLUser, cfg.MySQLPassword, cfg.MySQLHost, cfg.MySQLPort, cfg.MySQLDatabase)
	if err != nil {
		log.Fatalf("Failed to connect to MySQL: %v", err)
	}
	defer mysql.Close()
	fmt.Println("Connected to MySQL successfully")

	dragonfly, err := database.NewDragonfly(cfg.DragonflyPassword, cfg.DragonflyHost, cfg.DragonflyPort)
	if err != nil {
		log.Fatalf("Failed to connect to Dragonfly: %v", err)
	}
	defer dragonfly.Close()
	fmt.Println("Connected to Dragonfly successfully")

	session, err := discordgo.New("Bot " + cfg.DiscordToken)
	if err != nil {
		log.Fatalf("Failed to create Discord session: %v", err)
	}

	session.Identify.Intents = discordgo.IntentsGuilds | discordgo.IntentsGuildMessages | discordgo.IntentsDirectMessages
	botConfig := &commands.Config{
		DevGuildID:            cfg.DevGuildID,
		BotDevID:              cfg.BotDevID,
		PugsManagerRole:       cfg.PugsManagerRole,
		PupsManagerRole:       cfg.PupsManagerRole,
		PitManagerRole:        cfg.PitManagerRole,
		LogChannelID:          cfg.LogChannelID,
		PugsTournamentChannel: cfg.PugsTournamentChannel,
		PupsTournamentChannel: cfg.PupsTournamentChannel,
		PitTournamentChannel:  cfg.PitTournamentChannel,

		PugsChampionRole:    cfg.PugsChampionRole,
		PugsChampionX10Role: cfg.PugsChampionX10Role,
		PugsChampionX20Role: cfg.PugsChampionX20Role,
		PugsChampionX50Role: cfg.PugsChampionX50Role,
		PupsChampionRole:    cfg.PupsChampionRole,
		PupsChampionX10Role: cfg.PupsChampionX10Role,
		PupsChampionX20Role: cfg.PupsChampionX20Role,
		PupsChampionX50Role: cfg.PupsChampionX50Role,

		PitChampionRole:    cfg.PitChampionRole,
		PitChampionX10Role: cfg.PitChampionX10Role,
		PitChampionX20Role: cfg.PitChampionX20Role,
		PitChampionX50Role: cfg.PitChampionX50Role,
	}
	bot := commands.NewBot(session, mysql, dragonfly, botConfig)
	session.AddHandler(bot.HandleInteraction)
	session.AddHandler(func(s *discordgo.Session, r *discordgo.Ready) {
		fmt.Printf("Bot is ready! Logged in as: %v#%v\n", s.State.User.Username, s.State.User.Discriminator)

		startRotatingStatus(s)
	})

	err = session.Open()
	if err != nil {
		log.Fatalf("Failed to open Discord session: %v", err)
	}
	defer session.Close()
	fmt.Println("Registering commands...")
	err = registerCommands(session)
	if err != nil {
		log.Fatalf("Failed to register commands: %v", err)
	}
	fmt.Println("Commands registered successfully")

	fmt.Println("Bot is now running.")
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, syscall.SIGTERM)
	<-stop

	fmt.Println("Gracefully shutting down...")
}
