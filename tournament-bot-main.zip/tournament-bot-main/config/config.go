package config

import (
	"os"

	"github.com/joho/godotenv"
)

type Config struct {
	DiscordToken          string
	DevGuildID            string
	BotDevID              string
	MySQLUser             string
	MySQLPassword         string
	MySQLHost             string
	MySQLPort             string
	MySQLDatabase         string
	DragonflyPassword     string
	DragonflyHost         string
	DragonflyPort         string
	PugsManagerRole       string
	PupsManagerRole       string
	PitManagerRole        string
	LogChannelID          string
	PugsTournamentChannel string
	PupsTournamentChannel string
	PitTournamentChannel  string

	PugsChampionRole    string
	PugsChampionX10Role string
	PugsChampionX20Role string
	PugsChampionX50Role string
	PupsChampionRole    string
	PupsChampionX10Role string
	PupsChampionX20Role string
	PupsChampionX50Role string

	PitChampionRole    string
	PitChampionX10Role string
	PitChampionX20Role string
	PitChampionX50Role string
}

func Load() (*Config, error) {
	err := godotenv.Load()
	if err != nil {
		return nil, err
	}
	return &Config{
		DiscordToken:          os.Getenv("DISCORD_TOKEN"),
		DevGuildID:            os.Getenv("DEV_GUILD_ID"),
		BotDevID:              os.Getenv("BOT_DEV_ID"),
		MySQLUser:             os.Getenv("MYSQL_USER"),
		MySQLPassword:         os.Getenv("MYSQL_PASSWORD"),
		MySQLHost:             os.Getenv("MYSQL_HOST"),
		MySQLPort:             os.Getenv("MYSQL_PORT"),
		MySQLDatabase:         os.Getenv("MYSQL_DATABASE"),
		DragonflyPassword:     os.Getenv("DRAGONFLY_PASSWORD"),
		DragonflyHost:         os.Getenv("DRAGONFLY_HOST"),
		DragonflyPort:         os.Getenv("DRAGONFLY_PORT"),
		PugsManagerRole:       os.Getenv("PUGS_MANAGER_ROLE"),
		PupsManagerRole:       os.Getenv("PUPS_MANAGER_ROLE"),
		PitManagerRole:        os.Getenv("PIT_MANAGER_ROLE"),
		LogChannelID:          os.Getenv("LOG_CHANNEL_ID"),
		PugsTournamentChannel: os.Getenv("PUGS_TOURNAMENT_CHANNEL"),
		PupsTournamentChannel: os.Getenv("PUPS_TOURNAMENT_CHANNEL"),
		PitTournamentChannel:  os.Getenv("PIT_TOURNAMENT_CHANNEL"),

		PugsChampionRole:    os.Getenv("PUGS_CHAMPION_ROLE"),
		PugsChampionX10Role: os.Getenv("PUGS_CHAMPION_X10_ROLE"),
		PugsChampionX20Role: os.Getenv("PUGS_CHAMPION_X20_ROLE"),
		PugsChampionX50Role: os.Getenv("PUGS_CHAMPION_X50_ROLE"),
		PupsChampionRole:    os.Getenv("PUPS_CHAMPION_ROLE"),
		PupsChampionX10Role: os.Getenv("PUPS_CHAMPION_X10_ROLE"),
		PupsChampionX20Role: os.Getenv("PUPS_CHAMPION_X20_ROLE"),
		PupsChampionX50Role: os.Getenv("PUPS_CHAMPION_X50_ROLE"),

		PitChampionRole:    os.Getenv("PIT_CHAMPION_ROLE"),
		PitChampionX10Role: os.Getenv("PIT_CHAMPION_X10_ROLE"),
		PitChampionX20Role: os.Getenv("PIT_CHAMPION_X20_ROLE"),
		PitChampionX50Role: os.Getenv("PIT_CHAMPION_X50_ROLE"),
	}, nil
}
